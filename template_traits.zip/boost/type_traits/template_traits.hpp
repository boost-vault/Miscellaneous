
// (C) Copyright Agust�n Berg� 2009
//
// Use, modification and distribution are subject to the boost Software License,
// Version 1.0. (See http://www.boost.org/LICENSE_1_0.txt).

//------------------------------------------------------------------------------

#ifndef BOOST_PP_IS_ITERATING

# ifndef BOOST_TYPE_TRAITS_TEMPLATE_TRAITS_HPP_INCLUDED
#   define BOOST_TYPE_TRAITS_TEMPLATE_TRAITS_HPP_INCLUDED

#   include <boost/config.hpp>

#   include <boost/preprocessor/cat.hpp>
#   include <boost/preprocessor/arithmetic/dec.hpp>
#   include <boost/preprocessor/arithmetic/inc.hpp>
#   include <boost/preprocessor/facilities/intercept.hpp>
#   include <boost/preprocessor/iteration/iterate.hpp>
#   include <boost/preprocessor/iteration/local.hpp>
#   include <boost/preprocessor/punctuation/comma.hpp>
#   include <boost/preprocessor/punctuation/comma_if.hpp>
#   include <boost/preprocessor/punctuation/paren.hpp>
#   include <boost/preprocessor/repetition/enum_params.hpp>
#   include <boost/preprocessor/seq/enum.hpp>
#   include <boost/preprocessor/seq/for_each_i.hpp>
#   include <boost/preprocessor/seq/size.hpp>

#   ifndef BOOST_TYPE_TRAITS_MAX_TEMPLATE_ARITY
#       define BOOST_TYPE_TRAITS_MAX_TEMPLATE_ARITY 8
#   endif 

namespace boost {
#ifndef BOOST_NO_TEMPLATE_PARTIAL_SPECIALIZATION

    template< typename T, T Value > struct nontype_template_argument
    {
        typedef T type;
        static const T value = Value;

        operator T() const
        {
            return value;
        }
    };

    template< typename Holder > struct template_template_argument
    {};

    template< typename T >
    struct template_traits
    {
        BOOST_STATIC_CONSTANT( unsigned, arity = 0 );
    };

// generate specializations
#   define BOOST_PP_ITERATION_LIMITS ( 1, BOOST_TYPE_TRAITS_MAX_TEMPLATE_ARITY )
#   define BOOST_PP_FILENAME_1 "template_traits.hpp" // this file
#   include BOOST_PP_ITERATE()
#   undef BOOST_PP_FILENAME_1
#   undef BOOST_PP_ITERATION_LIMITS

// register facility

// needed to avoid the CAT recursion in SEQ_ENUM and others, unfortunate
# if ~BOOST_PP_CONFIG_FLAGS() & BOOST_PP_CONFIG_MWCC()
#   define BOOST_TYPE_TRAITS_TEMPLATE_TRAITS_CAT(a, b)                          \
    BOOST_TYPE_TRAITS_TEMPLATE_TRAITS_CAT_I(a, b)
# else
#   define BOOST_TYPE_TRAITS_TEMPLATE_TRAITS_CAT(a, b)                          \
    BOOST_TYPE_TRAITS_TEMPLATE_TRAITS_CAT_OO((a, b))
#   define BOOST_TYPE_TRAITS_TEMPLATE_TRAITS_CAT_OO(par)                        \
    BOOST_TYPE_TRAITS_TEMPLATE_TRAITS_CAT_I ## par
# endif
#
# if ~BOOST_PP_CONFIG_FLAGS() & BOOST_PP_CONFIG_MSVC()
#   define BOOST_TYPE_TRAITS_TEMPLATE_TRAITS_CAT_I(a, b) a ## b
# else
#   define BOOST_TYPE_TRAITS_TEMPLATE_TRAITS_CAT_I(a, b)                        \
    BOOST_TYPE_TRAITS_TEMPLATE_TRAITS_CAT_II(a ## b)
#   define BOOST_TYPE_TRAITS_TEMPLATE_TRAITS_CAT_II(res) res
# endif

#   define BOOST_TYPE_TRAITS_TEMPLATE_TRAITS_SWITCH( r, data, i, elem )         \
    BOOST_TYPE_TRAITS_TEMPLATE_TRAITS_CAT(                                      \
        data                                                                    \
      , BOOST_TYPE_TRAITS_TEMPLATE_TRAITS_CAT(                                  \
            BOOST_TYPE_TRAITS_TEMPLATE_TRAITS_CASE_                             \
          , elem                                                                \
        ) BOOST_PP_COMMA() i BOOST_PP_RPAREN()                                  \
    )                                                                           \

#   define BOOST_TYPE_TRAITS_TEMPLATE_TRAITS_CASE_typename                      \
    _TYPENAME BOOST_PP_LPAREN() _                                               \

#   define BOOST_TYPE_TRAITS_TEMPLATE_TRAITS_CASE_class                         \
    _TYPENAME BOOST_PP_LPAREN() _                                               \

#   define BOOST_TYPE_TRAITS_TEMPLATE_TRAITS_CASE_nontype( NT )                 \
    _NONTYPE BOOST_PP_LPAREN() NT                                               \

#   define BOOST_TYPE_TRAITS_TEMPLATE_TRAITS_CASE_template                      \
    _TEMPLATE BOOST_PP_LPAREN()                                                 \

    // decl param cases
#   define BOOST_TYPE_TRAITS_TEMPLATE_TRAITS_PARAM_TYPENAME( _, i )             \
    BOOST_PP_COMMA_IF( i )                                                      \
    typename T##i                                                               \

#   define BOOST_TYPE_TRAITS_TEMPLATE_TRAITS_PARAM_NONTYPE( NT, i )             \
    BOOST_PP_COMMA_IF( i )                                                      \
    NT T##i                                                                     \

#   define BOOST_TYPE_TRAITS_TEMPLATE_TRAITS_PARAM_TEMPLATE( P, i )             \
    BOOST_PP_COMMA_IF( i )                                                      \
    template< BOOST_PP_SEQ_ENUM( P ) > class T##i                               \

    // decl rebind param cases
#   define BOOST_TYPE_TRAITS_TEMPLATE_TRAITS_REBIND_PARAM_TYPENAME( _, i )      \
    BOOST_PP_COMMA_IF( i )                                                      \
    typename RT##i                                                              \

#   define BOOST_TYPE_TRAITS_TEMPLATE_TRAITS_REBIND_PARAM_NONTYPE( NT, i )      \
    BOOST_PP_COMMA_IF( i )                                                      \
    NT RT##i                                                                    \

#   define BOOST_TYPE_TRAITS_TEMPLATE_TRAITS_REBIND_PARAM_TEMPLATE( P, i )      \
    BOOST_PP_COMMA_IF( i )                                                      \
    template< BOOST_PP_SEQ_ENUM( P ) > class RT##i                              \

    // decl argN_type cases
#   define BOOST_TYPE_TRAITS_TEMPLATE_TRAITS_ARG_TYPENAME( _, i )               \
    typedef T##i                                                                \
    BOOST_PP_CAT(                                                               \
        BOOST_PP_CAT(                                                           \
            arg                                                                 \
          , BOOST_PP_INC( i )                                                   \
        )                                                                       \
      , _type;                                                                  \
    )                                                                           \

#   define BOOST_TYPE_TRAITS_TEMPLATE_TRAITS_ARG_NONTYPE( NT, i )               \
    typedef nontype_template_argument< NT, T##i >                               \
    BOOST_PP_CAT(                                                               \
        BOOST_PP_CAT(                                                           \
            arg                                                                 \
          , BOOST_PP_INC( i )                                                   \
        )                                                                       \
      , _type;                                                                  \
    )                                                                           \

#   define BOOST_TYPE_TRAITS_TEMPLATE_TRAITS_ARG_TEMPLATE( P, i )               \
    template<                                                                   \
        template< BOOST_PP_SEQ_ENUM( P ) > class                                \
    > struct                                                                    \
    BOOST_PP_CAT(                                                               \
        BOOST_PP_CAT(                                                           \
            holder                                                              \
          , BOOST_PP_INC( i )                                                   \
        )                                                                       \
      , _type;                                                                  \
    )                                                                           \
    typedef template_template_argument<                                         \
        BOOST_PP_CAT(                                                           \
            BOOST_PP_CAT(                                                       \
                holder                                                          \
              , BOOST_PP_INC( i )                                               \
            )                                                                   \
          , _type                                                               \
        )< T##i >                                                               \
    >                                                                           \
    BOOST_PP_CAT(                                                               \
        BOOST_PP_CAT(                                                           \
            arg                                                                 \
          , BOOST_PP_INC( i )                                                   \
        )                                                                       \
      , _type;                                                                  \
    )                                                                           \

    // decl typed rebind params
#   define BOOST_TYPE_TRAITS_TEMPLATE_TRAITS_TYPED_REBIND_PARAM_TYPENAME( _, i )\
    BOOST_PP_COMMA_IF( i )                                                      \
    typename RT##i                                                              \

#   define BOOST_TYPE_TRAITS_TEMPLATE_TRAITS_TYPED_REBIND_PARAM_NONTYPE( NT, i )\
    BOOST_PP_COMMA_IF( i )                                                      \
    NT RT##i                                                                    \

#   define BOOST_TYPE_TRAITS_TEMPLATE_TRAITS_TYPED_REBIND_PARAM_TEMPLATE( P, i )\
    BOOST_PP_COMMA_IF( i )                                                      \
    template< template< BOOST_PP_SEQ_ENUM( P ) > class > class HT##i,           \
    template< BOOST_PP_SEQ_ENUM( P ) > class RT##i                              \

    // decl typed rebind partial specialization params
#   define BOOST_TYPE_TRAITS_TEMPLATE_TRAITS_TYPED_REBIND_TYPENAME( _, i )      \
    BOOST_PP_COMMA_IF( i )                                                      \
    RT##i                                                                       \

#   define BOOST_TYPE_TRAITS_TEMPLATE_TRAITS_TYPED_REBIND_NONTYPE( NT, i )      \
    BOOST_PP_COMMA_IF( i )                                                      \
    nontype_template_argument< NT, RT##i >                                      \

#   define BOOST_TYPE_TRAITS_TEMPLATE_TRAITS_TYPED_REBIND_TEMPLATE( P, i )      \
    BOOST_PP_COMMA_IF( i )                                                      \
    template_template_argument< HT##i < RT##i > >                               \

    // register template macro
    // A better alternative would be the define - include, as PP_ITERATION does.
    // This would allow to turn all the macros up to here into 'local' macros,
    // as well as generation of nicer code (not a one-liner).
#   define BOOST_TYPE_TRAITS_REGISTER_TEMPLATE_TRAITS( B, P )                   \
namespace boost {                                                               \
    template<                                                                   \
        BOOST_PP_SEQ_FOR_EACH_I(                                                \
            BOOST_TYPE_TRAITS_TEMPLATE_TRAITS_SWITCH                            \
          , BOOST_TYPE_TRAITS_TEMPLATE_TRAITS_PARAM                             \
          , P                                                                   \
        )                                                                       \
    >                                                                           \
    struct template_traits<                                                     \
        B< BOOST_PP_ENUM_PARAMS( BOOST_PP_SEQ_SIZE( P ), T ) >                  \
    >                                                                           \
    {                                                                           \
        BOOST_STATIC_CONSTANT( unsigned, arity = BOOST_PP_SEQ_SIZE( P ) );      \
                                                                                \
        BOOST_PP_SEQ_FOR_EACH_I(                                                \
            BOOST_TYPE_TRAITS_TEMPLATE_TRAITS_SWITCH                            \
          , BOOST_TYPE_TRAITS_TEMPLATE_TRAITS_ARG                               \
          , P                                                                   \
        )                                                                       \
                                                                                \
        template<                                                               \
            BOOST_PP_SEQ_FOR_EACH_I(                                            \
                BOOST_TYPE_TRAITS_TEMPLATE_TRAITS_SWITCH                        \
              , BOOST_TYPE_TRAITS_TEMPLATE_TRAITS_REBIND_PARAM                  \
              , P                                                               \
            )                                                                   \
        > struct rebind                                                         \
        {                                                                       \
            typedef                                                             \
                B< BOOST_PP_ENUM_PARAMS( BOOST_PP_SEQ_SIZE( P ), RT ) >         \
                type;                                                           \
        };                                                                      \
                                                                                \
        template<                                                               \
            BOOST_PP_ENUM_PARAMS(                                               \
                BOOST_PP_SEQ_SIZE( P )                                          \
              , typename BOOST_PP_INTERCEPT                                     \
            )                                                                   \
        > struct typed_rebind;                                                  \
                                                                                \
        template<                                                               \
            BOOST_PP_SEQ_FOR_EACH_I(                                            \
                BOOST_TYPE_TRAITS_TEMPLATE_TRAITS_SWITCH                        \
              , BOOST_TYPE_TRAITS_TEMPLATE_TRAITS_TYPED_REBIND_PARAM            \
              , P                                                               \
            )                                                                   \
        > struct typed_rebind<                                                  \
            BOOST_PP_SEQ_FOR_EACH_I(                                            \
                BOOST_TYPE_TRAITS_TEMPLATE_TRAITS_SWITCH                        \
              , BOOST_TYPE_TRAITS_TEMPLATE_TRAITS_TYPED_REBIND                  \
              , P                                                               \
            )                                                                   \
        >                                                                       \
        {                                                                       \
            typedef                                                             \
                B< BOOST_PP_ENUM_PARAMS( BOOST_PP_SEQ_SIZE( P ), RT ) >         \
                type;                                                           \
        };                                                                      \
    };                                                                          \
} // namespace boost

#endif // BOOST_NO_TEMPLATE_PARTIAL_SPECIALIZATION
} // namespace boost

#  endif // BOOST_TYPE_TRAITS_TEMPLATE_TRAITS_HPP_INCLUDED

#else // BOOST_PP_IS_ITERATING

// specialization pattern

    template<
        template<
            BOOST_PP_ENUM_PARAMS(
                BOOST_PP_ITERATION()
              , typename BOOST_PP_INTERCEPT
            )
        > class B
      , BOOST_PP_ENUM_PARAMS(
            BOOST_PP_ITERATION()
          , typename T
        )
    >
    struct template_traits<
        B< BOOST_PP_ENUM_PARAMS( BOOST_PP_ITERATION(), T ) >
    >
    {
        BOOST_STATIC_CONSTANT( unsigned, arity = BOOST_PP_ITERATION() );

#   define BOOST_PP_LOCAL_LIMITS (1, BOOST_PP_ITERATION())
#   define BOOST_PP_LOCAL_MACRO( n )                                            \
        typedef BOOST_PP_CAT( T, BOOST_PP_DEC( n ) ) arg##n##_type;             \

#   include BOOST_PP_LOCAL_ITERATE()

        template<
            BOOST_PP_ENUM_PARAMS(
                BOOST_PP_ITERATION()
              , typename T
            )
        > struct rebind
        {
            typedef
                B< BOOST_PP_ENUM_PARAMS( BOOST_PP_ITERATION(), T ) >
                type;
        };

        template<
            BOOST_PP_ENUM_PARAMS(
                BOOST_PP_ITERATION()
              , typename T
            )
        > struct typed_rebind
        {
            typedef
                B< BOOST_PP_ENUM_PARAMS( BOOST_PP_ITERATION(), T ) >
                type;
        };
    };

#endif // BOOST_PP_IS_ITERATING
