
// (C) Copyright Agust�n Berg� 2009
//
// Use, modification and distribution are subject to the boost Software License,
// Version 1.0. (See http://www.boost.org/LICENSE_1_0.txt).

//------------------------------------------------------------------------------

#ifndef BOOST_TYPE_TRAITS_IS_SAME_BASE_TEMPLATE_HPP_INCLUDED
#define BOOST_TYPE_TRAITS_IS_SAME_BASE_TEMPLATE_HPP_INCLUDED

#include <boost/preprocessor/cat.hpp>
#include <boost/preprocessor/arithmetic/inc.hpp>
#include <boost/preprocessor/repetition/enum.hpp>

#include <boost/type_traits/is_same.hpp>
#include <boost/type_traits/template_traits.hpp>

namespace boost {
#ifndef BOOST_NO_TEMPLATE_PARTIAL_SPECIALIZATION

    template<
        typename T, typename U
      , unsigned TArity = template_traits< T >::arity
      , unsigned UArity = template_traits< U >::arity
    >
    struct is_same_base_template
      : boost::mpl::false_
    {};

#define BOOST_TYPE_TRAITS_TEMPLATE_TRAITS_arg( z, n, text )                     \
    typename template_traits< T >::                                             \
    BOOST_PP_CAT(                                                               \
        BOOST_PP_CAT(                                                           \
            arg                                                                 \
          , BOOST_PP_INC( n )                                                   \
        )                                                                       \
      , _type                                                                   \
    )                                                                           \

#define BOOST_PP_LOCAL_LIMITS (1, BOOST_TYPE_TRAITS_MAX_TEMPLATE_ARITY)
#define BOOST_PP_LOCAL_MACRO( n )                                               \
    template< typename T, typename U >                                          \
    struct is_same_base_template< T, U, n, n >                                  \
      : boost::is_same<                                                         \
            T                                                                   \
          , typename template_traits< U >::template typed_rebind<               \
                BOOST_PP_ENUM( n, BOOST_TYPE_TRAITS_TEMPLATE_TRAITS_arg, ~ )    \
            >::type                                                             \
        >::type                                                                 \
    {};                                                                         \

#include BOOST_PP_LOCAL_ITERATE()

#endif // BOOST_NO_TEMPLATE_PARTIAL_SPECIALIZATION
} // namespace boost

#  endif // BOOST_TYPE_TRAITS_IS_SAME_BASE_TEMPLATE_HPP_INCLUDED
