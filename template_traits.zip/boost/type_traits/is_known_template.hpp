
// (C) Copyright Agust�n Berg� 2009
//
// Use, modification and distribution are subject to the boost Software License,
// Version 1.0. (See http://www.boost.org/LICENSE_1_0.txt).

//------------------------------------------------------------------------------

#ifndef BOOST_TYPE_TRAITS_IS_KNOWN_TEMPLATE_HPP_INCLUDED
#define BOOST_TYPE_TRAITS_IS_KNOWN_TEMPLATE_HPP_INCLUDED

#include <boost/mpl/bool.hpp>

#include <boost/type_traits/template_traits.hpp>

namespace boost {
#ifndef BOOST_NO_TEMPLATE_PARTIAL_SPECIALIZATION

    template< typename T, unsigned Arity = template_traits< T >::arity >
    struct is_known_template
      : boost::mpl::true_
    {};

    template< typename T >
    struct is_known_template< T, 0 >
      : boost::mpl::false_
    {};

#endif // BOOST_NO_TEMPLATE_PARTIAL_SPECIALIZATION
} // namespace boost

#  endif // BOOST_TYPE_TRAITS_IS_KNOWN_TEMPLATE_HPP_INCLUDED
