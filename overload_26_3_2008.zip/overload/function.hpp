/*=============================================================================
    Copyright (c) 2007-2008 Marco Costalba

    Use, modification and distribution is subject to the Boost Software
    License, Version 1.0. (See accompanying file LICENSE_1_0.txt or copy at
    http://www.boost.org/LICENSE_1_0.txt)
==============================================================================*/
#ifndef FUNCTION_HPP
#define FUNCTION_HPP

#include "util.hpp"

#include <stdexcept> // std::runtime_error exception

namespace overload_ns {

    /* The bad_function_call exception class is thrown when is invoked an
     * empty function, this happens when no function has been assigned to
     * the signature that corrsponds to the calling arguments.
     */
    struct bad_function_call : std::runtime_error
    {
      bad_function_call() : std::runtime_error("call to empty function") {}
    };

namespace detail {

    /* Helper to disambiguate a function from a functor, it works because
     * functions cannot be array elements.
     */
    template<typename Fun>
    struct is_function
    {
        template<class U> static false_t check(U(*)[1]);
        template<class U> static true_t check(...);

        static bool const
        value = (sizeof(check<Fun>(0)) == sizeof(true_t));
    };

    /* Our little home grown 'function' class implements a generalized callback
     * similar to boost.function but much more limited in scope and tailored
     * to just fulfill our needs.
     *
     * Class function is built on a 4 level hierarchy:
     *
     * - function: top level class where function data is stored and handled
     *
     * - forwarder: specializations to implement different kind of operator()
     *
     * - function_base: enables run-time polymorphism, depends on signature only
     *
     * - final_function_base: to remove redundant stuff from function_base
     */
    template<typename Sig> struct function_base;
    template<class Derived, typename Sig, typename Ptm> struct forwarder;

    template<typename Fun, typename Sig, typename Ptm = null_type*>
    struct function : forwarder<function<Fun, Sig, Ptm>, Sig, Ptm>
    {
        function& operator=(function const&); // fix a warning with MSVC /W4

        typedef typename remove_pointer<Fun>::type FF;
        typedef typename if_t<is_function<FF>, FF*, FF>::type F;

        F f; /* It's a functor or a function pointer */
        Ptm ptm;

        function(F fun, Ptm p = 0) : f(fun), ptm(p) {}
        function(F* fun_ptr, Ptm p = 0) : f(*fun_ptr), ptm(p) {}

        function* clone() const { return new function(*this); }

        bool empty() const { return false; }
    };

    /* Forwarder to a pointer to member function */
    template<class Derived, typename Sig, typename Ptm>
    struct forwarder : function_base<Sig>
    {
        typedef typename signature<Sig>::R  R;
        typedef typename signature<Sig>::A0 A0;
        typedef typename signature<Sig>::A1 A1;
        typedef typename signature<Sig>::A2 A2;

        Derived* d() { return static_cast<Derived*>(this); } // CRTP here

        R operator()() { return (d()->f.*d()->ptm)(); }
        R operator()(A0 a0) { return (d()->f.*d()->ptm)(a0); }
        R operator()(A0 a0, A1 a1) { return (d()->f.*d()->ptm)(a0, a1); }
        R operator()(A0 a0, A1 a1, A2 a2) { return (d()->f.*d()->ptm)(a0, a1, a2); }
    };

    /* Forwarder to a function or function object */
    template<class Derived, typename Sig>
    struct forwarder<Derived, Sig, null_type*> : function_base<Sig>
    {
        typedef typename signature<Sig>::R  R;
        typedef typename signature<Sig>::A0 A0;
        typedef typename signature<Sig>::A1 A1;
        typedef typename signature<Sig>::A2 A2;

        Derived* d() { return static_cast<Derived*>(this); } // CRTP here

        R operator()() { return d()->f(); }
        R operator()(A0 a0) { return d()->f(a0); }
        R operator()(A0 a0, A1 a1) { return d()->f(a0, a1); }
        R operator()(A0 a0, A1 a1, A2 a2) { return d()->f(a0, a1, a2); }
    };

    template<typename Derived>
    struct final_function_base
    {
        virtual ~final_function_base() {}

        virtual bool empty() const { return true; }

        virtual Derived* clone() const
        {
            return new Derived(*(static_cast<const Derived*>(this)));
        }
    };

    /* Start or argument arity dependant part */
    template<typename R>
    struct function_base<R()> : final_function_base<function_base<R()> >
    {
        virtual R operator()() { throw overload_ns::bad_function_call(); }
    };

    template<typename R, typename A0>
    struct function_base<R(A0)> : final_function_base<function_base<R(A0)> >
    {
        virtual R operator()(A0) { throw overload_ns::bad_function_call(); }
    };

    template<typename R, typename A0, typename A1>
    struct function_base<R(A0, A1)> : final_function_base<function_base<R(A0, A1)> >
    {
        virtual R operator()(A0, A1) { throw overload_ns::bad_function_call(); }
    };

    template<typename R, typename A0, typename A1, typename A2>
    struct function_base<R(A0, A1, A2)> : final_function_base<function_base<R(A0, A1, A2)> >
    {
        virtual R operator()(A0, A1, A2) { throw overload_ns::bad_function_call(); }
    };
}}

#endif
