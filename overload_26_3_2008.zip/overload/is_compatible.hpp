/*=============================================================================
    Copyright (c) 2007-2008 Marco Costalba

    Use, modification and distribution is subject to the Boost Software
    License, Version 1.0. (See accompanying file LICENSE_1_0.txt or copy at
    http://www.boost.org/LICENSE_1_0.txt)
==============================================================================*/
#ifndef IS_COMPATIBLE_HPP
#define IS_COMPATIBLE_HPP

#include "util.hpp"

namespace overload_ns { namespace detail {

    /* Helper to check if a pointer-to-member has a given signature */
    template<typename T, class Ptm, typename Sig>
    struct has_signature
    {
        typedef Sig T::* type;
        static const bool value = is_same<Ptm, type>::value;
    };

    template<class T, typename Sig>
    struct has_signature<T, null_type, Sig> { static const bool value = false; };

    /* Check if a function/functor Fun or if a pointer-to-member
     * Fun::*Ptm has a given signature Sig
     */
    template<typename Fun, typename Sig, typename Ptm = null_type>
    struct is_compatible
    {
        /* Our tag dispatching structs */
        struct ptm_tag;
        struct no_ptm_tag;

        /* Check for a function */
        template<class U, typename> static
        true_t check(no_ptm_tag*, typename enable_if<is_same<U, Sig> >::type);

        /* Check for a functor */
        template<class U, Sig U::*> struct helper;

        template<class U, typename> static
        true_t check(no_ptm_tag*, helper<U, &U::operator()>*);

        /* Check for a pointer-to-member */
        template<class U, typename P> static
        true_t check(ptm_tag*, typename enable_if<has_signature<U, P, Sig> >::type);

        /* Default */
        template<class U, typename P> static false_t check(...);

        typedef typename remove_pointer<Fun>::type F;

        static typename if_t<is_null<Ptm>, no_ptm_tag, ptm_tag>::type* tag;

        static bool const
        value = (sizeof(check<F, Ptm>(tag, 0)) == sizeof(true_t));
    };
}}

#endif
