/*=============================================================================
    Copyright (c) 2007-2008 Marco Costalba

    Use, modification and distribution is subject to the Boost Software
    License, Version 1.0. (See accompanying file LICENSE_1_0.txt or copy at
    http://www.boost.org/LICENSE_1_0.txt)
==============================================================================*/
#ifndef OVERLOAD_HPP
#define OVERLOAD_HPP

#include "is_compatible.hpp"
#include "function.hpp"

#include <memory> // std::auto_ptr

namespace overload_ns { namespace detail {

    /* This is the struct that defines operator() for a given signature,
     * each operator() forwards the call to a function wrapper class.
     */
    template <typename Base, typename Sig>
    struct function_caller;

    /* This is the base of any function_caller and is used to store
     * and manage a std::auto_ptr to the function wrapper class.
     */
    template <typename Base, typename Sig>
    struct function_holder : Base
    {
        function_holder() : fun_ptr(new function_base<Sig>()) {} /* fun_ptr is never empty */

        function_holder(function_holder const& f) { *this = f; }

        void operator=(function_holder const& f) /* We don't need any return value */
        {
            fun_ptr.reset(f.fun_ptr->clone());
            Base::operator=(f); /* Implcit upcasting of 'f' here */
        }

        std::auto_ptr<function_base<Sig> > fun_ptr;

        using Base::set;
        using Base::reset;
        using Base::is_set;

        template<typename Fun> /* Catch functions or function objects */
        void set(Fun fun, typename enable_if<is_compatible<Fun, Sig> >::type = 0)
        {
            fun_ptr.reset(new function<Fun, Sig>(fun));
        }

        template<typename Fun, typename Ptm> /* Catch pointers to member function */
        void set(Fun fun, Ptm ptm, typename enable_if<is_compatible<Fun, Sig, Ptm> >::type = 0)
        {
            fun_ptr.reset(new function<Fun, Sig, Ptm>(fun, ptm));
        }

        template<typename Fun>
        void reset(typename enable_if<is_same<Fun, Sig> >::type = 0)
        {
            fun_ptr.reset(new function_base<Sig>());
        }

        template<typename Fun>
        bool is_set(typename enable_if<is_same<Fun, Sig> >::type = 0) const
        {
            return !fun_ptr->empty();
        }
    };

    /* The base of our overload hierarchy */
    struct final_function_caller
    {
        struct final;
        void operator()(final*);
        void set(final*);
        void reset(final*);
        void is_set(final*) const;
    };

    /* The overload builder */
    template<typename Seq> struct make_overload;

    template<typename head, typename tail>
    struct make_overload<TL<head, tail> >
    : identity<    
               function_caller<typename make_overload<tail>::type, head> 
              > {};

    template<>
    struct make_overload<null_type> : identity<final_function_caller> {};

    /* Due to unknonw reasons the first overload should be a dummy one
     * to avoid compile errors under MSVC in some cases.
     */
     typedef void msvc_fix(null_type*);

    } /* namespace detail */

    /* Our public API here */
    template<typename sig1 = detail::null_type,
             typename sig2 = detail::null_type,
             typename sig3 = detail::null_type,
             typename sig4 = detail::null_type,
             typename sig5 = detail::null_type,
             typename sig6 = detail::null_type
            >
    struct overload : detail::make_overload<typename detail::make_type_list<detail::msvc_fix, sig1, sig2, sig3, sig4, sig5, sig6>::type>::type
    {
        overload() {}

        template<typename T1> explicit
        overload(T1 t1) { this->set(t1); }

        template<typename T1, typename T2>
        overload(T1 t1, T2 t2) { this->set(t1); this->set(t2); }

        template<typename T1, typename T2, typename T3>
        overload(T1 t1, T2 t2, T3 t3) { this->set(t1); this->set(t2); this->set(t3); }

        template<typename T1, typename T2, typename T3, typename T4>
        overload(T1 t1, T2 t2, T3 t3, T4 t4)
        { this->set(t1); this->set(t2); this->set(t3); this->set(t4); }

        template<typename T1, typename T2, typename T3, typename T4, typename T5>
        overload(T1 t1, T2 t2, T3 t3, T4 t4, T5 t5)
        { this->set(t1); this->set(t2); this->set(t3); this->set(t4); this->set(t5); }

        template<typename T1, typename T2, typename T3, typename T4, typename T5, typename T6>
        overload(T1 t1, T2 t2, T3 t3, T4 t4, T5 t5, T6 t6)
        { this->set(t1); this->set(t2); this->set(t3); this->set(t4); this->set(t5); this->set(t6); }
    };
}


namespace overload_ns { namespace detail {

    /* Start of argument arity dependant part
     *
     * Define one function_caller specialization each signature arity to
     * guarantee that only the correct operator() will be instantiated
     * for each signature.
     */
    template <typename Base, typename R>
    struct function_caller<Base, R()> : function_holder<Base, R()>
    {
        using Base::operator();

        R operator()() { return (*this->fun_ptr)(); }
    };

    template <typename Base, typename R, typename A0>
    struct function_caller<Base, R(A0)> : function_holder<Base, R(A0)>
    {
        using Base::operator();

        R operator()(A0 a0) { return (*this->fun_ptr)(a0); }
    };

    template <typename Base, typename R, typename A0, typename A1>
    struct function_caller<Base, R(A0, A1)> : function_holder<Base, R(A0, A1)>
    {
        using Base::operator();

        R operator()(A0 a0, A1 a1) { return (*this->fun_ptr)(a0, a1); }
    };

    template <typename Base, typename R, typename A0, typename A1, typename A2>
    struct function_caller<Base, R(A0, A1, A2)> : function_holder<Base, R(A0, A1, A2)>
    {
        using Base::operator();

        R operator()(A0 a0, A1 a1, A2 a2) { return (*this->fun_ptr)(a0, a1, a2); }
    };
}}

#endif
