/*
    Author: Marco Costalba (C) 2007-2008


 To compile:

	(gcc)  g++ -O2 -o test test.cpp
	(MSVC) cl /Ox /EHs test.cpp


 An overload it's a multi-signature function wrapper.

 Once defined on a set of signatures it is possible to assign with
 overload::set<>() any function, function object or even pointer
 to member function to the overload as long as the signature
 of the assigned function/functor matches one of the overload's
 signatures set.

 It is possible to assign many functions/functors as long as each
 one has a different signature, otherwise the latest assignment
 overwrites the earlier with the same signature.

 Overload uses copy semantic for functors, so that a copy of the
 assigned functor is stored. This implies that functors must be copy
 constructible.

 An overload supports value semantic itself being copy constructible
 and assignable.

 When overload is invoked the calling arguments are forwarded to the
 correct assigned function, an overload_ns::bad_function_call exception
 will be thrown if the corresponding signature slot is empty.

 User can call overload::is_set<Sig>() to check if slot corresponding
 to signature Sig is empty.

 Finally user can clear a slot corresponding to signature Sig with
 overload::reset<Sig>()

 Internally, given a set of signatures, overload instantiates a hierarchy
 of classes, one per signature, and each class defines an operator()
 that interface a given signature and forwards it's arguments to the
 assigned function/functor.

 When an overload is called compiler will link the correct operator()
 according to the argument's type and arity.

 Overload signatures rules should follow strictly what states C++ for
 overloading of operator() member functions, so as example if an overload
 is called with an argument for which no exact match occurs, but that can
 be converted by more then one overloaded operator() then a compile error
 occurs of type 'ambiguous call'.

 Anyhow implicit conversions at invocation time are supported as long as
 there is no ambigity on the function to call.

 Overload code is self contained, no external libraries are needed apart
 from the standard one.

 Because overloads support value semantic it is possible to store them in
 any kind of container to obtain a very powerful and flexible dispatcher.

 Following examples will clarify overload usage.
*/
#include "overload.hpp"

#include <cassert>
#include <iostream>
#include <string>
#include <map>

using std::string;

int foo1(char) { return -1; }

double foo2(int, char) { return 123.456; }

char foo3(string) { return 'x'; }

void foo4(string s1, string s2, string s3) { std::cout << s1 + s2 + s3; }

int foo5() { return 7; }

template<typename T>
T fooT(T const& t) { return -t; }

struct foo1_t
{
    int operator()(char) { return 123; }
    int operator()(char) const { return 123; }

    char foo3(string) { return 'y'; }
    int foo1(char) { return 8; }

    static char foo3_s(string) { return 's'; }
};

int main(int, char**)
{
    overload_ns::overload
    <   int(char)
      , double(int, char)
      , int()
      , double(double const&)
      , void(string, string, string)
      , char(string)
    > f(foo4, &foo1, fooT<double>);  /* Assign functions directly in the c'tor */

    /* Use is_set() to check if a given signature slot is empty */
    assert( f.is_set<int(char)>() == true );
    assert( f.is_set<int()>() == false );

    typedef int (Fun)();
    Fun* foo5_ptr(foo5);
    Fun& foo5_ref(foo5);

    /* Assign functions in any order as pointers, references or plain types */
    f.set(&foo2);
    f.set(foo5_ptr);
    f.set(foo5_ref);
    f.set(foo3);

    assert( f('x') == -1 );

    /* Assign functors as well as pointers, references or plain types */
    foo1_t functor;
    foo1_t& functor_ref(functor);

    f.set(&functor); // overwrites foo1()
    f.set( functor);
    f.set( functor_ref);

    /* Works also with const objects */
    const foo1_t const_functor(functor);

    f.set(&const_functor);
    f.set( const_functor);

    /* Implicit conversions are supported at invocation time */
    f("\nHello", " World", " I'm Marco\n");

    assert( f('x') == 123 );
    assert( f(123, 'x') > 123.455 && f(123, 'x') < 123.457 );
    assert( f("hello") == 'x' );
    assert( f() == 7 );
    assert( f(-3.0) > 2.9 && f(-3.0) < 3.1 );

    /* Try with static member function */
    f.set(foo1_t::foo3_s);

    assert( f("hello") == 's' );

    /* Assign a pointer to member function */
    f.set(&functor, &foo1_t::foo3); // overwrites foo3()
    f.set( functor, &foo1_t::foo1); // overwrites functor.operator()

    assert( f("hello") == 'y' );
    assert( f('x') == 8 );

    /* Finally, it is possible to reset a given signature */
    assert( f.is_set<int(char)>() == true );

    f.reset<int(char)>();

    assert( f.is_set<int(char)>() == false );

    /* An exception is thrown if an empty slot is called */
    try {
        f('x');
        assert(false); // fail if we arrive here
    }
    catch (overload_ns::bad_function_call& e)
    {
        std::cout << std::endl << e.what() << std::endl;
    }

    /* An overload is copy constructible and assignable */
    typedef overload_ns::overload<  int(char)
                                  , double(int, char)
                                  , int()
                                  , double(double const&)
                                  , void(string, string, string)
                                  , char(string)
                                 > Overload;
    Overload h(f), g;

    assert( h(123, 'x') > 123.455 && h(123, 'x') < 123.457 );
    assert( h("hello") == 'y' );

    g = h;

    assert( g(123, 'x') > 123.455 && g(123, 'x') < 123.457 );
    assert( g("hello") == 'y' );

    /* Because of value semantic we can store them in an array */
    Overload d[5];

    d[0].set(foo1);
    d[1].set(functor, &foo1_t::foo1);

    assert( d[0]('x') == -1 );
    assert( d[1]('x') == 8 );

    /* Any container is suitable, as example a std::map, so to
     * easily obtain a powerful runtime dynamic dispatcher with
     * multi-signature (heterogeneous function types) support.
     */
    std::map<string, Overload> m;

    m["First"] = g;
    m["Second"] = Overload(foo3, foo1);

    m["First"].set(functor, &foo1_t::foo1);

    assert( m["First"]('x') == 8 );
    assert( m["Second"]('x') == -1 );

    assert( m["First"]("hello") == 'y' );
    assert( m["Second"]("hello") == 'x' );

    std::cout << "\nTest successful\n" << std::endl;

    return 0;
}
