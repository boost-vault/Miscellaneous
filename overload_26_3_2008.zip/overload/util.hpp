/*=============================================================================
    Copyright (c) 2007-2008 Marco Costalba

    Use, modification and distribution is subject to the Boost Software
    License, Version 1.0. (See accompanying file LICENSE_1_0.txt or copy at
    http://www.boost.org/LICENSE_1_0.txt)
==============================================================================*/
#ifndef UTIL_HPP
#define UTIL_HPP

namespace overload_ns { namespace detail {

    struct null_type;

    /* Helper types that are guaranteed to have different sizeof() values */
    typedef char true_t;
    struct false_t { char padding[8]; };

    /* Wrapper for a type, used in metaprogramming expressions */
    template<typename T> struct identity { typedef T type; };

    /* Trait to get the plain type out of a pointer */
    template<class T> struct remove_pointer : identity<T> {};
    template<class T> struct remove_pointer<T*> : identity<T> {};

    /* Trait to compare two types */
    template<class T, class U> struct is_same { static const bool value = false; };
    template<class T> struct is_same<T, T> { static const bool value = true; };

    /* Helper to check for null_type */
    template<class T> struct is_null : is_same<T, null_type> {};

    /* Trait to implement type selection based on a const value */
    template<bool, typename T1, typename T2> struct if_c : identity<T1> {};
    template<typename T1, typename T2> struct if_c<false, T1, T2> : identity<T2> {};

    /* The same as above but with a type as the condition */
    template<typename C, typename T1, typename T2>
    struct if_t : if_c<C::value, T1, T2> {};

    /* Our SFINAE machinery, with a type as the condition */
    template<typename C>
    struct enable_if : if_t<C, identity<null_type*>, false_t>::type {};

    /* A simplified type list */
    template<class H, class T> struct TL;

    /* Get the n-th element of a type list, first is at 0 */
    template<int n, class TL> struct at_c;

    template<int n, class H, class T>
    struct at_c<n, TL<H, T> > : if_c<n == 0, identity<H>, typename
                                     if_t<is_null<T>, identity<T>,
                                           at_c<n - 1, T> >::type>::type {};

    /* Helper to build up a type list */
    template<class T1 = null_type, class T2 = null_type, class T3 = null_type,
             class T4 = null_type, class T5 = null_type, class T6 = null_type,
             class T7 = null_type>
    struct make_type_list : identity<TL<T1, typename make_type_list<T2, T3, T4, T5, T6, T7>::type> > {};

    template<>
    struct make_type_list<null_type, null_type, null_type, null_type, null_type, null_type, null_type>
    : identity<null_type> {};

    /* Convert a function signature to a type list */
    template<typename Sig> struct sig_to_tl;

    template<typename R>
    struct sig_to_tl<R()> : make_type_list<R> {};

    template<typename R, typename A0>
    struct sig_to_tl<R(A0)> : make_type_list<R, A0> {};

    template<typename R, typename A0, typename A1>
    struct sig_to_tl<R(A0, A1)> : make_type_list<R, A0, A1> {};

    template<typename R, typename A0, typename A1, typename A2>
    struct sig_to_tl<R(A0, A1, A2)> : make_type_list<R, A0, A1, A2> {};

    /* Helper to extract argument's types from a function signature */
    template<typename Sig>
    struct signature
    {
        typedef typename sig_to_tl<Sig>::type TL;

        typedef typename at_c<0, TL>::type  R;
        typedef typename at_c<1, TL>::type A0;
        typedef typename at_c<2, TL>::type A1;
        typedef typename at_c<3, TL>::type A2;
    };
}}

#endif
