
//////////////////////////////////////////////////////////////////////////////
// linear_algebra.hpp
// copyright (c) Jason Hise, 2005
//
//  Author: Jason Hise
// Created: 11.23.2005
// Purpose: Provide generic vector and matrix types,
//          and some common operations used with them
//
//////////////////////////////////////////////////////////////////////////////

#ifndef ENTROPY_LINEAR_ALGEBRA_HPP
#define ENTROPY_LINEAR_ALGEBRA_HPP

#include <cstddef>
#include <entropy/math.hpp>
#include <entropy/error.hpp>

namespace entropy
{
    // indexers for 2D through 4D vectors
    enum
    {
        _x,
        _y,
        _z,
        _w
    };

    // vector class
    template < typename Type, std::size_t Dim >
    struct vector
    {
    private:
        // store data in flat array
        Type data[Dim];

    public:
        inline vector (  )
        {
        }

        inline vector ( Type x )
        {
            data[_x] = x;
        }

        inline vector ( Type x, Type y )
        {
            data[_x] = x;
            data[_y] = y;
        }

        inline vector ( Type x, Type y, Type z )
        {
            data[_x] = x;
            data[_y] = y;
            data[_z] = z;
        }

        inline vector ( Type x, Type y, Type z, Type w )
        {
            data[_x] = x;
            data[_y] = y;
            data[_z] = z;
            data[_w] = w;
        }

        inline vector ( const vector < Type, Dim > & rhs )
        {
            *this = rhs;
        }

        // get vector component
        inline Type & operator [] ( std::size_t i )
        {
            return data[i];
        }

        // get vector component
        inline const Type & operator [] ( std::size_t i ) const
        {
            return data[i];
        }

        // compare vectors component by component
        inline bool operator == ( const vector < Type, Dim > & rhs ) const
        {
            for ( std::size_t i = 0; i < Dim; ++i )
            {
                if ( data[i] != rhs.data[i] ) return false;
            }
            return true;
        }

        // compare vectors component by component
        inline bool operator != ( const vector < Type, Dim > & rhs ) const
        {
            return !( *this == rhs );
        }

        // assign rhs to this
        inline vector < Type, Dim > & operator = (
            const vector < Type, Dim > & rhs )
        {
            for ( std::size_t i = 0; i < Dim; ++i )
            {
                data[i] = rhs.data[i];
            }
            return *this;
        }

        // add vector components of rhs to this
        inline vector < Type, Dim > & operator += (
            const vector < Type, Dim > & rhs )
        {
            for ( std::size_t i = 0; i < Dim; ++i )
            {
                data[i] += rhs.data[i];
            }
            return *this;
        }

        // subtract vector components of rhs from this
        inline vector < Type, Dim > & operator -= (
            const vector < Type, Dim > & rhs )
        {
            for ( std::size_t i = 0; i < Dim; ++i )
            {
                data[i] -= rhs.data[i];
            }
            return *this;
        }

        // scale vector by some factor
        inline vector < Type, Dim > & operator *= ( Type rhs )
        {
            for ( std::size_t i = 0; i < Dim; ++i )
            {
                data[i] *= rhs;
            }
            return *this;
        }

        // multiply components
        inline vector < Type, Dim > & operator *= (
            const vector < Type, Dim > & rhs )
        {
            for ( std::size_t i = 0; i < Dim; ++i )
            {
                data[i] *= rhs.data[i];
            }
            return *this;
        }

        // divide vector components by a scalar
        inline vector < Type, Dim > & operator /= ( Type rhs )
        {
            for ( std::size_t i = 0; i < Dim; ++i )
            {
                data[i] /= rhs;
            }
            return *this;
        }

        // divide components
        inline vector < Type, Dim > & operator /= (
            const vector < Type, Dim > & rhs )
        {
            for ( std::size_t i = 0; i < Dim; ++i )
            {
                data[i] /= rhs.data[i];
            }
            return *this;
        }

        // sum vector components
        inline vector < Type, Dim > operator + (
            const vector < Type, Dim > & rhs ) const
        {
            return vector < Type, Dim > ( *this ) += rhs;
        }

        // subtract vector components
        inline vector < Type, Dim > operator - (
            const vector < Type, Dim > & rhs ) const
        {
            return vector < Type, Dim > ( *this ) -= rhs;
        }

        // get a scaled vector
        inline vector < Type, Dim > operator * ( Type rhs ) const
        {
            return vector < Type, Dim > ( *this ) *= rhs;
        }

        // multiply vector components
        inline vector < Type, Dim > operator * (
            const vector < Type, Dim > & rhs ) const
        {
            return vector < Type, Dim > ( *this ) *= rhs;
        }

        // get an inverse scaled vector
        inline vector < Type, Dim > operator / ( Type rhs ) const
        {
            return vector < Type, Dim > ( *this ) /= rhs;
        }

        // divide vector components
        inline vector < Type, Dim > operator / (
            const vector < Type, Dim > & rhs ) const
        {
            return vector < Type, Dim > ( *this ) /= rhs;
        }

        // negate vector components
        inline vector < Type, Dim > operator - (  ) const
        {
            return *this * -1;
        }
    };

    // size 0 is undefined
    template < typename Type >
    struct vector < Type, 0 >;

    // multiply by scalar on the left
    template < typename Type, std::size_t Dim >
    inline vector < Type, Dim > operator * ( Type lhs,
        const vector < Type, Dim > & rhs )
    {
        vector < Type, Dim > ans;
        for ( std::size_t i = 0; i < Dim; ++i )
        {
            ans[i] = lhs * rhs[i];
        }
        return ans;
    }

    // inverse each component in the vector
    template < typename Type, std::size_t Dim >
    inline vector < Type, Dim > operator / ( Type lhs,
        const vector < Type, Dim > & rhs )
    {
        vector < Type, Dim > ans;
        for ( std::size_t i = 0; i < Dim; ++i )
        {
            ans[i] = lhs / rhs[i];
        }
        return ans;
    }

    // dot product
    template < typename Type, std::size_t Dim >
    inline Type dot_product ( const vector < Type, Dim > & lhs,
        const vector < Type, Dim > & rhs )
    {
        Type sum ( 0 );
        for ( std::size_t i = 0; i < Dim; ++i )
        {
            sum += lhs[i] * rhs[i];
        }
        return sum;
    }

    // vector length
    template < typename Type, std::size_t Dim >
    inline Type length ( const vector < Type, Dim > & vect )
    {
        return sqrt ( dot_product ( vect, vect ) );
    }

    // unit vector of same direction
    template < typename Type, std::size_t Dim >
    inline void normalize (
        vector < Type, Dim > & vect )
    {
        vect /= length ( vect );
    }

    // cross product
    template < typename Type >
    inline vector < Type, 3 > cross_product (
        const vector < Type, 3 > & lhs,
        const vector < Type, 3 > & rhs )
    {
        vector < Type, 3 > ans;
        ans[_x] = ( lhs[_y] * rhs[_z] - lhs[_z] * rhs[_y] );
        ans[_y] = ( lhs[_z] * rhs[_x] - lhs[_x] * rhs[_z] );
        ans[_z] = ( lhs[_x] * rhs[_y] - lhs[_y] * rhs[_x] );

        return ans;
    }

    // matrix class
    template < typename Type, std::size_t Rows, std::size_t Columns >
    struct matrix
    {
    private:
        // store rows as vectors
        vector < Type, Columns > data[Rows];

    public:
        // access a row
        inline vector < Type, Columns > & operator [] ( std::size_t y )
        {
            return data[y];
        }

        // access a row
        inline const vector < Type, Columns > & operator [] (
            std::size_t y ) const
        {
            return data[y];
        }

        // compare components of matricees
        inline bool operator == (
            const matrix < Type, Rows, Columns > & rhs ) const
        {
            for ( std::size_t i = 0; i < Rows; ++i )
            {
                if ( data[i] != rhs.data[i] ) return false;
            }
            return true;
        }

        // compare components of matricees
        inline bool operator != (
            const matrix < Type, Rows, Columns > & rhs ) const
        {
            return !( *this == rhs );
        }

        // add components of rhs to components of this
        inline matrix < Type, Rows, Columns > & operator += (
            const matrix < Type, Rows, Columns > & rhs )
        {
            for ( std::size_t i = 0; i < Rows; ++i )
            {
                data[i] += rhs.data[i];
            }
            return *this;
        }

        // subtract components of rhs from components of this
        inline matrix < Type, Rows, Columns > & operator -= (
            const matrix < Type, Rows, Columns > & rhs )
        {
            for ( std::size_t i = 0; i < Rows; ++i )
            {
                data[i] -= rhs.data[i];
            }
            return *this;
        }

        // scale all components in matrix
        inline matrix < Type, Rows, Columns > & operator *= (
            const Type & rhs )
        {
            for ( std::size_t i = 0; i < Rows; ++i )
            {
                data[i] *= rhs.data[i];
            }
            return *this;
        }

        // inverse scale all components in matrix
        inline matrix < Type, Rows, Columns > & operator /= (
            const Type & rhs )
        {
            for ( std::size_t i = 0; i < Rows; ++i )
            {
                data[i] /= rhs.data[i];
            }
            return *this;
        }

        // negate all components in matrix
        inline matrix < Type, Rows, Columns > operator - (  ) const
        {
            return *this * -1;
        }

        // add two matricees
        inline matrix < Type, Rows, Columns > operator + (
            const matrix < Type, Rows, Columns > & rhs ) const
        {
            return matrix < Type, Rows, Columns > ( *this ) += rhs;
        }

        // subtract two matricees
        inline matrix < Type, Rows, Columns > operator - ( 
            const matrix < Type, Rows, Columns > & rhs ) const
        {
            return matrix < Type, Rows, Columns > ( *this ) -= rhs;
        }

        // scale a matrix
        inline matrix < Type, Rows, Columns > operator * ( Type rhs ) const
        {
            return matrix < Type, Rows, Columns > ( *this ) *= rhs;
        }

        // inverse scale a matrix
        inline matrix < Type, Rows, Columns > operator / ( Type rhs ) const
        {
            return matrix < Type, Rows, Columns > ( *this ) /= rhs;
        }
    };

    // zero columns is undefined
    template < typename Type, std::size_t Rows >
    struct matrix < Type, Rows, 0 >;

    // zero rows is undefined
    template < typename Type, std::size_t Columns >
    struct matrix < Type, 0, Columns >;

    // multiply matricees of compatible size types
    template < typename Type, std::size_t X, std::size_t Y, std::size_t Z >
    inline matrix < Type, Y, Z > operator * (
        const matrix < Type, Y, X > & lhs,
        const matrix < Type, X, Z > & rhs )
    {
        matrix < Type, Y, Z > ans;
        for ( std::size_t y = 0; y < Y; ++y )
        {
            for ( std::size_t z = 0; z < Z; ++z )
            {
                ans[y][z] = 0;
                for ( std::size_t x = 0; x < X; ++x )
                {
                    ans[y][z] += lhs[y][x] * rhs[x][z];
                }
            }
        }
        return ans;
    }

    // compound assignment with multiply,
    // only makes sense for square matricees
    template < typename Type, std::size_t Dim >
    inline const matrix < Type, Dim, Dim > & operator *= (
        matrix < Type, Dim, Dim > & lhs,
        const matrix < Type, Dim, Dim > & rhs )
    {
        return lhs = lhs * rhs;
    }

    // get the transpose of a matrix
    template < typename Type, std::size_t Rows, std::size_t Columns >
    inline matrix < Type, Columns, Rows > transpose (
        const matrix < Type, Rows, Columns > & mat )
    {
        matrix < Type, Columns, Rows > ans;
        for ( std::size_t y = 0; y < Rows; ++y )
        {
            for ( std::size_t x = 0; x < Columns; ++x )
            {
                ans[x][y] = mat[y][x];
            }
        }
        return ans;
    }

    // scale by a constant on left
    template < typename Type, std::size_t Rows, std::size_t Columns >
    inline matrix < Type, Rows, Columns > operator * ( const Type & lhs,
        const matrix < Type, Rows, Columns > & rhs )
    {
        matrix < Type, Rows, Columns > ans;
        for ( std::size_t y = 0; y < Rows; ++y )
        {
            ans[y] = lhs * rhs[y];
        }
        return ans;
    }

    // inverse scale all components
    template < typename Type, std::size_t Rows, std::size_t Columns >
    inline matrix < Type, Rows, Columns > operator / ( const Type & lhs,
        const matrix < Type, Rows, Columns > & rhs )
    {
        matrix < Type, Rows, Columns > ans;
        for ( std::size_t y = 0; y < Rows; ++y )
        {
            ans[y] = lhs / rhs[y];
        }
        return ans;
    }

    // transform a vector using a matrix
    // vectors behave like 1 x N matricees (1 row, N cols)
    // where N is the dimension of the vector
    template < typename Type, std::size_t Dim >
    inline vector < Type, Dim > operator * (
        const vector < Type, Dim > & lhs,
        const matrix < Type, Dim, Dim > & rhs )
    {
        matrix < Type, 1, Dim > mat;
        mat[0] = lhs;
        return ( mat * rhs )[0];
    }

    // transform self using a matrix
    template < typename Type, std::size_t Dim >
    inline vector < Type, Dim > & operator *= (
        vector < Type, Dim > & lhs,
        const matrix < Type, Dim, Dim > & rhs )
    {
        return lhs = lhs * rhs;
    }

    // get matrix with all entries set to zero
    template < typename Type, std::size_t Rows, std::size_t Columns >
    inline matrix < Type, Rows, Columns > zero_matrix (  )
    {
        matrix < Type, Rows, Columns > ans;
        for ( std::size_t y = 0; y < Rows; ++y )
        {
            for ( std::size_t x = 0; x < Columns; ++x )
            {
                ans[y][x] = 0;
            }
        }

        return ans;
    }

    // return the identity matrix of the given size
    template < typename Type, std::size_t Dim >
    inline matrix < Type, Dim, Dim > identity_matrix (  )
    {
        matrix < Type, Dim, Dim > ans;
        for ( std::size_t y = 0; y < Dim; ++y )
        {
            for ( std::size_t x = 0; x < Dim; ++x )
            {
                ans[y][x] = ( y == x );
            }
        }
        return ans;
    }

    // get the multiplicitive inverse of a square matrix
    template < typename Type, std::size_t Dim >
    inline matrix < Type, Dim, Dim > inverse ( matrix < Type, Dim, Dim > m )
    {
        // save the identity and start our answer as it
        matrix < Type, Dim, Dim > ident =
            identity_matrix < Type, Dim > (  );
        matrix < Type, Dim, Dim > ans ( ident );

        // we will be doing Gauss-Jordan elimination to transform
        // m to the identity as we transform ans to the inverse

        // move column by column
        for ( std::size_t col = 0; col < Dim; ++col )
        {
            bool success;
            success = false;

            // then row by row, looking for a valid 'pivot point'
            // we start at col because all previously used pivot
            // points will have been swapped to above this position
            for ( std::size_t row = col; row < Dim; ++row )
            {
                // if we have a non zero entry this row will work
                if ( m[row][col] )
                {
                    // move this row in m up so that
                    // m[row][col] moves to m[col][col]
                    vector < Type, Dim > temp ( m[row] );
                    m[row] = m[col];
                    m[col] = temp;
                    // match action in ans
                    temp = ans[row];
                    ans[row] = ans[col];
                    ans[col] = temp;

                    Type ratio;

                    // iterate through all other rows
                    for ( std::size_t y = 0; y < Dim; ++y )
                    {
                        // key word being other ;)
                        if ( y == col ) continue;

                        // ratio is the percentage of the pivot row to
                        // subtract from this row in order to achieve
                        // a zero in the current column
                        ratio = m[y][col] / m[col][col];

                        // then do the subtraction
                        m[y] -= ratio * m[col];
                        // and mirror in ans
                        ans[y] -= ratio * ans[col];
                    }

                    // now scale this row to ensure a one on the diagonal
                    ratio = m[col][col];
                    m[col] /= ratio;
                    // and of course mirror the change in ans
                    ans[col] /= ratio;

                    success = 1;
                    break;
                }
            }

            if ( !success )
            {
                // matrix does not have an inverse, throw an exception
                error ( "matrix is singular" );
            }
        }

        return ans;
    }

    // get the matrix formed by removing the xth column and yth row
    template < typename Type, std::size_t Dim >
    inline matrix < Type, Dim - 1, Dim - 1 > cofactor (
        const matrix < Type, Dim, Dim > & mat,
        std::size_t x, std::size_t y )
    {
        matrix < Type, Dim - 1, Dim - 1 > ans;
        for ( std::size_t iy = 0; iy < Dim - 1; ++iy )
        {
            for ( std::size_t ix = 0; ix < Dim - 1; ++ix )
            {
                // if we are at or past the row or
                // column removed, we offset by one
                ans[iy][ix] =
                    mat[iy < y ? iy : iy + 1][ix < x ? ix : ix + 1];
            }
        }
        return ans;
    }

    // calculate the determinant of a square matrix
    template < typename Type, std::size_t Dim >
    inline Type determinant ( const matrix < Type, Dim, Dim > & mat )
    {
        // this could potentially be optimized to use
        // a row or column with the most zeros
        Type ans = 0;
        for ( std::size_t x = 0; x < Dim; ++x )
        {
            // alternately add and subtract each element in the top row
            // times the determinant of the cofactor of that position
            ans += ( x % 2 ? -1 : 1 ) * mat[0][x]
                * determinant ( cofactor ( mat, x, 0 ) );
        }
        return ans;
    }

    // determinant of size 1x1 is a special case, and is simply itself
    template < typename Type >
    inline Type determinant ( const matrix < Type, 1, 1 > & mat )
    {
        return mat[0][0];
    }
}

#endif//ENTROPY_LINEAR_ALGEBRA_HPP

//////////////////////////////////////////////////////////////////////////////
// Revision History:
//
//////////////////////////////////////////////////////////////////////////////
