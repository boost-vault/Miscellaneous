
//////////////////////////////////////////////////////////////////////////////
// quaternion.hpp
// copyright (c) Jason Hise, 2006
//
//  Author: Jason Hise
// Created: 01.20.2006
// Purpose: Provide generic quaternion type
//
//////////////////////////////////////////////////////////////////////////////

#ifndef ENTROPY_QUATERNION_HPP
#define ENTROPY_QUATERNION_HPP

#include <cstddef>
#include <entropy/math.hpp>
#include <entropy/linear_algebra.hpp>

namespace entropy
{
    template < typename Type >
    struct quaternion : public vector < Type, 4 >
    {
    public:
        // construct from components
        quaternion ( Type w = 0, Type i = 0, Type j = 0, Type k = 0 )
            : vector < Type, 4 > ( i, j, k, w )
        {
        }

        // construct from vector
        quaternion ( const vector < Type, 4 > & data )
            : vector < Type, 4 > ( data )
        {
        }

        // construct from a counter clockwise angle and an axis
        quaternion ( Type angle, vector < Type, 3 > axis )
        {
            normalize ( axis );

            Type sin_a ( sin ( angle / 2 ) );
            Type cos_a ( cos ( angle / 2 ) );

            (*this)[_w] = cos_a;
            (*this)[_x] = axis[_x] * sin_a;
            (*this)[_y] = axis[_y] * sin_a;
            (*this)[_z] = axis[_z] * sin_a;
        }

        // multiply quaternion by another quaternion
        quaternion & operator *= ( const quaternion < Type > & rhs )
        {
            vector < Type, 3 > lvec ( (*this)[_x], (*this)[_y], (*this)[_z] );
            vector < Type, 3 > rvec (     rhs[_x],     rhs[_y],     rhs[_z] );

            vector < Type, 3 > temp = (*this)[_w] * rvec +
                                          rhs[_w] * lvec +
                                      cross_product ( lvec, rvec );

            (*this)[_w] = (*this)[_w] * rhs[_w] - dot_product ( lvec, rvec );
            (*this)[_x] = temp[_x];
            (*this)[_y] = temp[_y];
            (*this)[_z] = temp[_z];

            return *this;
        }

        // quaternion multiplication
        quaternion < Type > operator * (
            const quaternion < Type > & rhs ) const
        {
            return quaternion < Type > ( *this ) *= rhs;
        }
    };

    // complex conjugate
    template < typename Type >
    quaternion < Type > conjugate ( const quaternion < Type > & quat )
    {
        return quaternion < Type > (
            quat[_w], -quat[_x], -quat[_y], -quat[_z] );
    }

    // length, must be overloaded because we have overloaded multiplication
    template < typename Type >
    Type length ( const quaternion < Type > & quat )
    {
        Type w = quat[_w];
        Type x = quat[_x];
        Type y = quat[_y];
        Type z = quat[_z];

        return sqrt ( w * w + x * x + y * y + z * z );
    }

    // multiplicitive inverse
    template < typename Type >
    quaternion < Type > inverse ( const quaternion < Type > & quat )
    {
        return conjugate ( quat ) / length ( quat );
    }

    // rotate a vector using a quaternion
    template < typename Type >
    vector < Type, 3 > rotate ( const vector < Type, 3 > & vect,
        const quaternion < Type > & quat )
    {
        quaternion v ( 0, vect[_x], vect[_y], vect[_z] );
        v = inverse ( quat ) * v * quat;
        return vector < Type, 3 > ( v[_x], v[_y], v[_z] );
    }
}

#endif//ENTROPY_QUATERNION_HPP

//////////////////////////////////////////////////////////////////////////////
// Revision History:
//
//////////////////////////////////////////////////////////////////////////////
