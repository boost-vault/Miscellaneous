
//////////////////////////////////////////////////////////////////////////////
// math.hpp
// copyright (c) Jason Hise, 2006
//
//  Author: Jason Hise
// Created: 01.18.2006
// Purpose: Provide generic math functions
//
//////////////////////////////////////////////////////////////////////////////

#ifndef ENTROPY_MATH_HPP
#define ENTROPY_MATH_HPP

#include <cstddef>
#include <cmath>

namespace entropy
{
    namespace // avoid ODR problems
    {
        const double e     = 2.71828182845904523536;
        const double e_x2  = 5.43656365691809047072;
        const double e_d2  = 1.35914091422952261768;

        const double pi    = 3.14159265358979323846;
        const double pi_x2 = 6.28318530717958647692;
        const double pi_d2 = 1.57079632679489661923;
    }

    // generic square root algorithm
    template < typename Type >
    Type sqrt ( const Type & val, std::size_t max_iter = 32 )
    {
        std::size_t i ( 0 );
        Type x = Type ( 1 );
        Type x2;

        while ( i++ < max_iter )
        {
            x2 = ( x + val / x ) / Type ( 2 );
            x = x2;
        }

        return x;
    }

    // generic natural logarithm algorithm
    template < typename Type >
    Type ln ( Type val, std::size_t max_iter = 32 )
    {
        Type ans = max_iter + 1;
        Type num;

        val -= 1;

        while ( max_iter )
        {
            num = ( max_iter + 1 ) / 2;
            num = num * num * val;
            ans = max_iter + num / ans;
            --max_iter;
        }

        return val / ans;
    }

    // overloads for built in cases
    inline float ln ( float val ) { return ::logf ( val ); }
    inline double ln ( double val ) { return ::log ( val ); }
    inline long double ln ( long double val ) { return ::logl ( val ); }

    // generic logarithm algorithm with specifiable base
    template < typename Type >
    Type log ( Type val, Type base, std::size_t max_iter = 32 )
    {
        return ln ( val, max_iter ) / ln ( base, max_iter );
    }

    // overloads for built in cases
    inline float log ( float val, float base )
        { return ln ( val ) / ln ( base ); }
    inline double log ( double val, double base )
        { return ln ( val ) / ln ( base ); }
    inline long double log ( long double val, long double base )
        { return ln ( val ) / ln ( base ); }

    // overloads for built in cases
    inline float sqrt ( float val ) { return ::sqrtf ( val ); }
    inline double sqrt ( double val ) { return ::sqrt ( val ); }
    inline long double sqrt ( long double val ) { return ::sqrtl ( val ); }

    // generic cosine algorithm
    template < typename Type >
    Type cos ( Type val, std::size_t max_iter = 32 )
    {
        Type pi_x2 ( static_cast < Type > ( entropy::pi_x2 ) );

        if ( val > pi_x2 )
        {
            std::size_t i ( val / pi_x2 );
            val -= i * pi_x2;
        }
        if ( val < -pi_x2 )
        {
            std::size_t i ( -val / pi_x2 );
            val += i * pi_x2;
        }
        Type ans ( 1 );
        Type nx2 ( -(val * val) );
        Type numer ( 1 );
        Type fact_next ( 0 );
        Type denom ( 1 );

        while ( max_iter )
        {
            numer *= nx2;
            ++fact_next;
            denom *= fact_next;
            ++fact_next;
            denom *= fact_next;
            ans += numer / denom;
            --max_iter;
        }

        return ans;
    }

    // overloads for built in cases
    inline float cos ( float val ) { return ::cosf ( val ); }
    inline double cos ( double val ) { return ::cos ( val ); }
    inline long double cos ( long double val ) { return ::cosl ( val ); }

    // generic sine algorithm
    template < typename Type >
    Type sin ( Type val, std::size_t max_iter = 32 )
    {
        Type pi_d2 ( static_cast < Type > ( entropy::pi_d2 ) );
        return cos ( val - pi_d2, max_iter );
    }

    // overloads for built in cases
    inline float sin ( float val ) { return ::sinf ( val ); }
    inline double sin ( double val ) { return ::sin ( val ); }
    inline long double sin ( long double val ) { return ::sinl ( val ); }

    // generic tangent algorithm
    template < typename Type >
    Type tan ( Type val, std::size_t max_iter = 32 )
    {
        return sin ( val, max_iter ) / cos ( val, max_iter );
    }

    // overloads for built in cases
    inline float tan ( float val ) { return ::tanf ( val ); }
    inline double tan ( double val ) { return ::tan ( val ); }
    inline long double tan ( long double val ) { return ::tanl ( val ); }

    // generic algorithm for inverse sine
    template < typename Type >
    Type asin ( Type val, std::size_t max_iter = 32 )
    {
        Type ans ( val );
        Type val_2 ( val * val );
        Type numer = val;
        Type numer_co = 1;
        Type denom = 1;
        Type next = 1;

        while ( max_iter )
        {
            numer_co *= next;
            numer *= val_2;
            denom *= next + 1;
            next += 2;
            ans += ( numer_co * numer ) / ( denom * next );
            --max_iter;
        }

        return ans;
    }

    // overloads for built in cases
    inline float asin ( float val ) { return ::asinf ( val ); }
    inline double asin ( double val ) { return ::asin ( val ); }
    inline long double asin ( long double val ) { return ::asinl ( val ); }

    // generic algorithm for inverse cosine
    template < typename Type >
    Type acos ( Type val, std::size_t max_iter = 32 )
    {
        return asin ( sqrt (
            1 - ( val * val ), max_iter ), max_iter );
    }

    // overloads for built in cases
    inline float acos ( float val ) { return ::acosf ( val ); }
    inline double acos ( double val ) { return ::acos ( val ); }
    inline long double acos ( long double val ) { return ::acosl ( val ); }

    // generic algorithm for inverse tangent
    template < typename Type >
    Type atan ( Type val, std::size_t max_iter = 32 )
    {
        return asin ( val / sqrt (
            ( val * val ) + 1, max_iter ), max_iter );
    }

    // overloads for built in cases
    inline float atan ( float val ) { return ::atanf ( val ); }
    inline double atan ( double val ) { return ::atan ( val ); }
    inline long double atan ( long double val ) { return ::atanl ( val ); }

    // no generic pow is available yet
    using ::pow;
}

#endif//ENTROPY_MATH_HPP

//////////////////////////////////////////////////////////////////////////////
// Revision History:
//
//////////////////////////////////////////////////////////////////////////////
