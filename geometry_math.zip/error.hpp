
//////////////////////////////////////////////////////////////////////////////
// error.hpp
// copyright (c) Jason Hise, 2006
//
//  Author: Jason Hise
// Created: 01.24.2005
// Purpose: Provide error handling functions
//
//////////////////////////////////////////////////////////////////////////////

#ifndef ENTROPY_ERROR_HPP
#define ENTROPY_ERROR_HPP

#include <stdexcept>

namespace entropy
{
    template < typename Type >
    inline void error ( const Type & t )
    {
        // make sure Type derives from exception
        const std::exception & ex ( t );
        throw t;
    }

    inline void error ( const char * msg )
    {
        throw std::runtime_error ( msg );
    }
}

#define ENTROPY_BEGIN_EAT_ERRORS try
#define ENTROPY_END_EAT_ERRORS catch ( ... ) {  }

#endif//ENTROPY_ERROR_HPP

//////////////////////////////////////////////////////////////////////////////
// Revision History:
//
//////////////////////////////////////////////////////////////////////////////
