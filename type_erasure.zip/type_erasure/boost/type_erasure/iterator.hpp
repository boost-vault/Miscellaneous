// Boost.TypeErasure library
//
// Copyright 2011 Steven Watanabe
//
// Distributed under the Boost Software License Version 1.0. (See
// accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)
//
// $Id: iterator.hpp 87 2011-05-22 16:54:04Z Steven $

#ifndef BOOST_TYPE_ERASURE_ITERATOR_HPP_INCLUDED
#define BOOST_TYPE_ERASURE_ITERATOR_HPP_INCLUDED

#include <iterator>
#include <boost/mpl/vector.hpp>
#include <boost/type_erasure/operators.hpp>
#include <boost/type_erasure/builtin.hpp>

namespace boost {
namespace type_erasure {

template<class T, class ValueType, class DifferenceType = std::ptrdiff_t, class Pointer = ValueType*, class Reference = ValueType&>
struct forward_iterator :
    boost::mpl::vector<
        copy_constructible<T>,
        constructible<T()>,
        equality_comparable<T>,
        dereferenceable<Reference, T>,
        incrementable<T>,
        assignable<T>
    >
{};

/// \cond show_operators

template<class T, class ValueType, class DifferenceType, class Pointer, class Reference, class Base>
struct concept_interface<forward_iterator<T, ValueType, DifferenceType, Pointer, Reference>, Base, T>
    : Base
{
    typedef typename rebind_any<Base, ValueType>::type value_type;
    typedef typename rebind_any<Base, Reference>::type reference;
    typedef DifferenceType difference_type;
    typedef Pointer pointer;
    typedef std::forward_iterator_tag iterator_category;
};

/// \endcond

}
}

#endif
