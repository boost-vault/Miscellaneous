// Boost.TypeErasure library
//
// Copyright 2011 Steven Watanabe
//
// Distributed under the Boost Software License Version 1.0. (See
// accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)
//
// $Id: vtable.hpp 31 2011-03-25 00:44:22Z Steven $

#if !defined(BOOST_PP_IS_ITERATING)

#ifndef BOOST_TYPE_ERASURE_DETAIL_VTABLE_HPP_INCLUDED
#define BOOST_TYPE_ERASURE_DETAIL_VTABLE_HPP_INCLUDED

#include <boost/mpl/at.hpp>
#include <boost/mpl/size.hpp>
#include <boost/preprocessor/cat.hpp>
#include <boost/preprocessor/iteration/iterate.hpp>
#include <boost/preprocessor/repetition/enum.hpp>
#include <boost/preprocessor/repetition/enum_params.hpp>
#include <boost/preprocessor/repetition/enum_trailing.hpp>
#include <boost/preprocessor/repetition/enum_trailing_params.hpp>
#include <boost/preprocessor/repetition/repeat.hpp>
#include <boost/type_erasure/detail/rebind_placeholders.hpp>
#include <boost/type_erasure/config.hpp>

namespace boost {
namespace type_erasure {
namespace detail {

template<int N>
struct make_vtable_impl;

template<class Seq>
struct make_vtable
{
    typedef typename make_vtable_impl<
        (::boost::mpl::size<Seq>::value)>::template apply<Seq>::type type;
};

template<int N>
struct make_vtable_init_impl;

template<class Seq, class Table>
struct make_vtable_init
{
    typedef typename make_vtable_init_impl<
        (::boost::mpl::size<Seq>::value)>::template apply<Seq, Table>::type type;
};

#define BOOST_PP_FILENAME_1 <boost/type_erasure/detail/vtable.hpp>
#define BOOST_PP_ITERATION_LIMITS (1, BOOST_TYPE_ERASURE_MAX_FUNCTIONS)
#include BOOST_PP_ITERATE()

}
}
}

#endif

#else

#define N BOOST_PP_ITERATION()

#define BOOST_TYPE_ERASURE_VTABLE_ENTRY(z, n, data)                     \
    typename BOOST_PP_CAT(T, n)::type BOOST_PP_CAT(t, n);               \
    typename BOOST_PP_CAT(T, n)::type lookup(BOOST_PP_CAT(T, n)*) const \
    {                                                                   \
        return BOOST_PP_CAT(t, n);                                      \
    }

#define BOOST_TYPE_ERASURE_VTABLE_COMPARE(z, n, data)                   \
    && BOOST_PP_CAT(t, n) == other.BOOST_PP_CAT(t, n)

#define BOOST_TYPE_ERASURE_VTABLE_INIT(z, n, data)  \
    BOOST_PP_CAT(data, n)::value

#define BOOST_TYPE_ERASURE_AT(z, n, data)       \
    typename ::boost::mpl::at_c<data, n>::type

#define BOOST_TYPE_ERASURE_CONVERT_ELEMENT(z, n, data)                  \
    BOOST_PP_CAT(t, n) = src.lookup(                                    \
        (typename ::boost::type_erasure::detail::rebind_placeholders<   \
            BOOST_PP_CAT(T, n), Bindings                                \
        >::type*)0                                                      \
    );

template<BOOST_PP_ENUM_PARAMS(N, class T)>
struct BOOST_PP_CAT(vtable_storage, N)
{
    BOOST_PP_REPEAT(N, BOOST_TYPE_ERASURE_VTABLE_ENTRY, ~)

    template<class Bindings, class Src>
    void convert_from(const Src& src)
    {
        BOOST_PP_REPEAT(N, BOOST_TYPE_ERASURE_CONVERT_ELEMENT, ~)
    }

    bool operator==(const BOOST_PP_CAT(vtable_storage, N)& other) const
    { return true BOOST_PP_REPEAT(N, BOOST_TYPE_ERASURE_VTABLE_COMPARE, ~); }
};

template<>
struct make_vtable_impl<N>
{
    template<class Seq>
    struct apply
    {
        typedef ::boost::type_erasure::detail::BOOST_PP_CAT(vtable_storage, N)<
            BOOST_PP_ENUM(N, BOOST_TYPE_ERASURE_AT, Seq)
        > type;
    };
};
template<class Table BOOST_PP_ENUM_TRAILING_PARAMS(N, class T)>
struct BOOST_PP_CAT(vtable_init, N)
{
    static const Table value;
};

template<class Table BOOST_PP_ENUM_TRAILING_PARAMS(N, class T)>
const Table BOOST_PP_CAT(vtable_init, N)<
    Table BOOST_PP_ENUM_TRAILING_PARAMS(N, T)>::value =
{
    BOOST_PP_ENUM(N, BOOST_TYPE_ERASURE_VTABLE_INIT, T)
};

template<>
struct make_vtable_init_impl<N>
{
    template<class Seq, class Table>
    struct apply
    {
        typedef ::boost::type_erasure::detail::BOOST_PP_CAT(vtable_init, N)<
            Table
            BOOST_PP_ENUM_TRAILING(N, BOOST_TYPE_ERASURE_AT, Seq)
        > type;
    };
};

#undef BOOST_TYPE_ERASURE_CONVERT_ELEMENT
#undef BOOST_TYPE_ERASURE_AT
#undef BOOST_TYPE_ERASURE_VTABLE_INIT
#undef BOOST_TYPE_ERASURE_VTABLE_COMPARE
#undef BOOST_TYPE_ERASURE_VTABLE_ENTRY
#undef N

#endif
