// Boost.TypeErasure library
//
// Copyright 2011 Steven Watanabe
//
// Distributed under the Boost Software License Version 1.0. (See
// accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)
//
// $Id: adapt_to_vtable.hpp 52 2011-04-04 23:03:28Z Steven $

#if !defined(BOOST_PP_IS_ITERATING)

#ifndef BOOST_TYPE_ERASURE_DETAIL_ADAPT_TO_VTABLE_HPP_INCLUDED
#define BOOST_TYPE_ERASURE_DETAIL_ADAPT_TO_VTABLE_HPP_INCLUDED

#include <boost/utility/addressof.hpp>
#include <boost/mpl/if.hpp>
#include <boost/mpl/eval_if.hpp>
#include <boost/mpl/not.hpp>
#include <boost/type_traits/function_traits.hpp>
#include <boost/type_traits/is_base_and_derived.hpp>
#include <boost/type_traits/remove_cv.hpp>
#include <boost/preprocessor/cat.hpp>
#include <boost/preprocessor/iteration/iterate.hpp>
#include <boost/preprocessor/repetition/enum.hpp>
#include <boost/preprocessor/repetition/enum_params.hpp>
#include <boost/preprocessor/repetition/enum_trailing_params.hpp>
#include <boost/preprocessor/repetition/enum_binary_params.hpp>
#include <boost/type_erasure/detail/storage.hpp>
#include <boost/type_erasure/is_placeholder.hpp>
#include <boost/type_erasure/config.hpp>

namespace boost {
namespace type_erasure {

struct primitive_concept_base;

namespace detail {

template<class T, class Bindings>
struct rebind_placeholders;

template<class T, class Bindings>
struct rebind_placeholders_in_argument;

template<class PrimitiveConcept, class Sig>
struct vtable_adapter;

template<class PrimitiveConcept, class Sig, class Bindings>
struct rebind_placeholders<vtable_adapter<PrimitiveConcept, Sig>, Bindings>
{
    typedef vtable_adapter<
        typename rebind_placeholders<PrimitiveConcept, Bindings>::type,
        typename rebind_placeholders_in_argument<Sig, Bindings>::type
    > type;
};

template<class T>
struct replace_param_for_vtable
{
    typedef typename ::boost::mpl::if_<
        ::boost::type_erasure::is_placeholder<typename ::boost::remove_cv<T>::type>,
        const ::boost::type_erasure::detail::storage&,
        T
    >::type type;
};

template<class T>
struct replace_param_for_vtable<T&>
{
    typedef typename ::boost::mpl::if_<
        ::boost::type_erasure::is_placeholder<typename ::boost::remove_cv<T>::type>,
        ::boost::type_erasure::detail::storage&,
        T&
    >::type type;
};

template<class T>
struct replace_param_for_vtable<const T&>
{
    typedef typename ::boost::mpl::if_<
        ::boost::type_erasure::is_placeholder<typename ::boost::remove_cv<T>::type>,
        const ::boost::type_erasure::detail::storage&,
        const T&
    >::type type;
};

template<class T>
struct replace_result_for_vtable
{
    typedef typename ::boost::mpl::if_<
        ::boost::type_erasure::is_placeholder<typename ::boost::remove_cv<T>::type>,
        ::boost::type_erasure::detail::storage,
        T
    >::type type;
};

template<class T>
struct replace_result_for_vtable<T&>
{
    typedef typename ::boost::mpl::if_<
        ::boost::type_erasure::is_placeholder<typename ::boost::remove_cv<T>::type>,
        ::boost::type_erasure::detail::storage&,
        T&
    >::type type;
};

template<class T>
struct replace_result_for_vtable<const T&>
{
    typedef typename ::boost::mpl::if_<
        ::boost::type_erasure::is_placeholder<typename ::boost::remove_cv<T>::type>,
        ::boost::type_erasure::detail::storage&,
        const T&
    >::type type;
};

template<class Sig>
struct get_vtable_signature;

template<class T>
struct is_internal_concept :
    ::boost::mpl::not_< ::boost::is_base_and_derived<primitive_concept_base, T> >
{};

template<class PrimitiveConcept>
struct adapt_to_vtable
{
    typedef ::boost::type_erasure::detail::vtable_adapter<
        PrimitiveConcept,
        typename ::boost::type_erasure::detail::get_vtable_signature<
            typename PrimitiveConcept::signature_type>::type
    > type;
};

template<class Concept>
struct maybe_adapt_to_vtable
{
    typedef typename ::boost::mpl::eval_if<
        ::boost::type_erasure::detail::is_internal_concept<Concept>,
        ::boost::mpl::identity<Concept>,
        ::boost::type_erasure::detail::adapt_to_vtable<Concept>
    >::type type;
};

#define BOOST_PP_FILENAME_1 <boost/type_erasure/detail/adapt_to_vtable.hpp>
#define BOOST_PP_ITERATION_LIMITS (0, BOOST_TYPE_ERASURE_MAX_ARITY)
#include BOOST_PP_ITERATE()

}
}
}

#endif

#else

#define N BOOST_PP_ITERATION()
#define BOOST_TYPE_ERASURE_EXTRACT(z, n, data)                  \
    ::boost::type_erasure::detail::extract<                     \
        typename traits::                                       \
        BOOST_PP_CAT(BOOST_PP_CAT(arg, BOOST_PP_INC(n)), _type) \
    >(BOOST_PP_CAT(arg, n))
#define BOOST_TYPE_ERASURE_REPLACE_PARAM(z, n, data)                    \
    typename ::boost::type_erasure::detail::replace_param_for_vtable<   \
        BOOST_PP_CAT(T, n)>::type

template<class PrimitiveConcept, class R
    BOOST_PP_ENUM_TRAILING_PARAMS(N, class T)>
struct vtable_adapter<PrimitiveConcept, R(BOOST_PP_ENUM_PARAMS(N, T))>
{
    typedef R (*type)(BOOST_PP_ENUM_PARAMS(N, T));
    static R value(BOOST_PP_ENUM_BINARY_PARAMS(N, T, arg))
    {
        typedef typename ::boost::function_traits<
            typename PrimitiveConcept::signature_type> traits;
        return PrimitiveConcept::apply(
            BOOST_PP_ENUM(N, BOOST_TYPE_ERASURE_EXTRACT, ~));
    }
};

template<class PrimitiveConcept
    BOOST_PP_ENUM_TRAILING_PARAMS(N, class T)>
struct vtable_adapter<PrimitiveConcept, ::boost::type_erasure::detail::storage&(BOOST_PP_ENUM_PARAMS(N, T))>
{
    typedef ::boost::type_erasure::detail::storage (*type)(BOOST_PP_ENUM_PARAMS(N, T));
    static ::boost::type_erasure::detail::storage value(BOOST_PP_ENUM_BINARY_PARAMS(N, T, arg))
    {
        typedef typename ::boost::function_traits<
            typename PrimitiveConcept::signature_type> traits;
        ::boost::type_erasure::detail::storage result;
        typename ::boost::remove_reference<typename traits::result_type>::type* p =
            ::boost::addressof(
                PrimitiveConcept::apply(BOOST_PP_ENUM(N, BOOST_TYPE_ERASURE_EXTRACT, ~)));
        result.data = const_cast<void*>(static_cast<const void*>(p));
        return result;
    }
};

template<class R BOOST_PP_ENUM_TRAILING_PARAMS(N, class T)>
struct get_vtable_signature<R(BOOST_PP_ENUM_PARAMS(N, T))>
{
    typedef typename ::boost::type_erasure::detail::replace_result_for_vtable<
        R
    >::type type(BOOST_PP_ENUM(N, BOOST_TYPE_ERASURE_REPLACE_PARAM, ~));
};

#undef BOOST_TYPE_ERASURE_REPLACE_PARAM
#undef BOOST_TYPE_ERASURE_EXTRACT
#undef N

#endif
