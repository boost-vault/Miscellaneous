// Boost.TypeErasure library
//
// Copyright 2011 Steven Watanabe
//
// Distributed under the Boost Software License Version 1.0. (See
// accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)
//
// $Id: primitive_concept.hpp 63 2011-04-05 23:48:10Z Steven $

#if !defined(BOOST_PP_IS_ITERATING)

#ifndef BOOST_TYPE_ERASURE_PRIMITIVE_CONCEPT_HPP_INCLUDED
#define BOOST_TYPE_ERASURE_PRIMITIVE_CONCEPT_HPP_INCLUDED

#include <boost/preprocessor/iteration/iterate.hpp>
#include <boost/preprocessor/repetition/enum_params.hpp>
#include <boost/preprocessor/repetition/enum_binary_params.hpp>
#include <boost/preprocessor/repetition/enum_trailing_params.hpp>
#include <boost/type_erasure/config.hpp>
#include <boost/type_erasure/call.hpp>

namespace boost {
namespace type_erasure {

/** INTERNAL ONLY */
struct primitive_concept_base {};

/**
 * The class template @ref primitive_concept can be used to
 * define new concepts.  You will need to pass the
 * derived class and the function signature.  Derived
 * classes are expected to provide a static apply
 * function with that signature.  Derived classes
 * should be defined as templates, as the library
 * expects to do placeholder substitution when it
 * maps the concept to a concrete set of types.
 *
 * For example, let's define a simplified version of
 * the @ref addable concept.
 *
 * \code
 * template<class T = _self>
 * struct addable : primitive_concept<addable<T, U>, T(const T&, const T&)>
 * {
 *     static T apply(const T& lhs, const T& rhs) { return lhs + rhs; }
 * };
 * \endcode
 *
 * Note that we make the argument default to @ref _self for convenience.
 * Now when you construct an @ref any that includes this concept with
 * an int, the @ref placeholder will be replaced with int, and the operation
 * @c addable<int>::apply will be captured.
 *
 * Placeholders are substituted according to the following rules:
 *  - If a template parameter is a [const] @ref placeholder [&] it
 *    will be replaced with [const] @c T [&], where @c T is the type
 *    that the placeholder binds to.
 *  - If a template parameter is a function type, then its parameters
 *    and return type will be substituted as above.
 *
 * Note in particular that placeholder substitution is <i>not</i>
 * recursive.  If one of the arguments is a class template with
 * a placeholder as an argument, it will not be substituted.
 */
template<class Derived, class Sig>
struct primitive_concept : primitive_concept_base
{
    /** INTERNAL ONLY */
    typedef Sig signature_type;
#ifdef BOOST_TYPE_ERASURE_DOXYGEN
    /** Applies the @ref primitive_concept to @c args.
     *
     * \pre There must be at least one @ref any in @c args.
     * \pre The bindings of every @ref any in @c args must be the same.
     *
     * \return The result of the @ref primitive_concept.  If the
     *         result type is a placeholder, the result will be
     *         converted to the appropriate @ref any type.
     */
    template<class... T>
    detail::unspecified operator()(U&&... args) const;
#endif
};

#ifndef BOOST_TYPE_ERASURE_DOXYGEN

#define BOOST_PP_FILENAME_1 <boost/type_erasure/primitive_concept.hpp>
#define BOOST_PP_ITERATION_LIMITS (1, BOOST_TYPE_ERASURE_MAX_ARITY)
#include BOOST_PP_ITERATE()

#endif

}
}

#endif

#else

#define N BOOST_PP_ITERATION()

template<class Derived, class R, BOOST_PP_ENUM_PARAMS(N, class T)>
struct primitive_concept<Derived, R(BOOST_PP_ENUM_PARAMS(N, T))> :
    ::boost::type_erasure::primitive_concept_base
{
    typedef R signature_type(BOOST_PP_ENUM_PARAMS(N, T));
    template<BOOST_PP_ENUM_PARAMS(N, class U)>
    typename ::boost::type_erasure::detail::BOOST_PP_CAT(call_impl, N)<
        R, BOOST_PP_ENUM_PARAMS(N, T), BOOST_PP_ENUM_PARAMS(N, U)>::type
    operator()(BOOST_PP_ENUM_BINARY_PARAMS(N, U, & arg)) const
    {
        return ::boost::type_erasure::call(*this, BOOST_PP_ENUM_PARAMS(N, arg));
    }
};

#undef N

#endif
