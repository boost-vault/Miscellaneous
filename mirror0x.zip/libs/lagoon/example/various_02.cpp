/**
 *  @example boost/lagoon/example/various_02.cpp
 *  This example shows the usage of the various utilities provided
 *  by Lagoon
 *
1*  Copyright 2008-2011 Matus Chochlik. Distributed under the Boost
 *  Software License, Version 1.0. (See accompanying file
 *  LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
 */

#include <boost/mirror/mirror.hpp>
#include <boost/lagoon/lagoon.hpp>
#include <boost/lagoon/range/contains.hpp>
#include <iostream>

int main(void)
{
        using namespace boost::lagoon;
        // check for classes in the global scope
        std::cout << (contains(
                reflected_global_scope()->members(),
                [](const shared<meta_named_scoped_object>& member)
                {
                        return member->is_class();
                }
        ) ? "Some" : "No") << " classes in the global scope" << std::endl;
        // check for class templates in the global scope
        std::cout << (contains(
                reflected_global_scope()->members(),
                [](const shared<meta_named_scoped_object>& member)
                {
                        return member->is_type_template();
                }
        ) ? "Some" : "No") << " class templates in the global scope" << std::endl;
        //
        return 0;
}

/* Example of output:
No classes in the global scope
No class templates in the global scope
*/
