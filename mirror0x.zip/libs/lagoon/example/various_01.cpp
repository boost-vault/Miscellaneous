/**
 *  @example boost/lagoon/example/various_01.cpp
 *  This example shows the usage of the various utilities provided
 *  by Lagoon
 *
 *  Copyright 2008-2010 Matus Chochlik. Distributed under the Boost
 *  Software License, Version 1.0. (See accompanying file
 *  LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
 */

#include <boost/mirror/mirror.hpp>
#include <boost/lagoon/lagoon.hpp>
#include <iostream>

int main(void)
{
        using namespace boost::lagoon;
        //
        // reflect the global scope
        auto meta_gs(reflected_global_scope());
        // reflect the wstring* type
        auto meta_w(reflected_type<std::wstring*>());
        // reflect the vector<string> type
        auto meta_v(reflected_type<std::vector<std::wstring> >());
        //
        // get the full name of the type
        std::cout << meta_w->full_name() << std::endl;
        std::cout << meta_v->full_name() << std::endl;
        // get the full name of the scope of the reflected type
        std::cout << meta_w->scope()->full_name() << std::endl;
        std::cout << meta_v->scope()->full_name() << std::endl;
        //
        // get the full name of the type used to define
        // the mstring type
        //
        // get the meta_templated_type interface, get the zeroth
        // parameter and print it full type name
        std::cout << meta_v.as<meta_templated_type>()->
                template_parameters().at(0)->full_name() <<
                std::endl;
        // get the meta_templated_type interface, get the first
        // parameter and print it full type name
        std::cout << meta_v.as<meta_templated_type>()->
                template_parameters().at(1)->full_name() <<
                std::endl;
        //
        return 0;
}

