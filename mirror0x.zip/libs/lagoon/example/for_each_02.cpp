/**
 *  @example boost/lagoon/example/for_each_02.cpp
 *  This example shows the usage of the namespace reflection functions
 *  and range for-each utility with lambda functions
 *
 *  Copyright 2008-2010 Matus Chochlik. Distributed under the Boost
 *  Software License, Version 1.0. (See accompanying file
 *  LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
 */

#include <boost/mirror/mirror.hpp>
#include <boost/lagoon/lagoon.hpp>
#include <boost/lagoon/range/for_each.hpp>
#include <iostream>

int main(void)
{
        using namespace boost::lagoon;
        //
        // execute the lambda function on each member of the global scope
        for_each(
                reflected_global_scope()->members(),
                [](shared<meta_named_scoped_object> member)
                {
                        // print the 'kind' of the meta-object (type,class,...)
                        // and the base name of the reflected object
                        // without the nested name specifier
                        std::cout
                                << member->self()->base_name()
                                << " "
                                << member->base_name()
                                << std::endl;
                }
        );
        return 0;
}

/* Example of output:
namespace std
namespace boost
type void
type bool
type char
type unsigned char
type wchar_t
type short int
type int
type long int
type unsigned short int
type unsigned int
type unsigned long int
type float
type double
type long double
*/
