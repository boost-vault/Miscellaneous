/**
 *  Copyright 2008-2010 Matus Chochlik. Distributed under the Boost
 *  Software License, Version 1.0. (See accompanying file
 *  LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
 */
#ifndef BOOST_LAGOON_LIBS_EXAMPLES_CLASSES_1011291729_HPP
#define BOOST_LAGOON_LIBS_EXAMPLES_CLASSES_1011291729_HPP

// just hijack the classes from Mirror's examples
#include "../../mirror/example/classes.hpp"

#endif
