/**
 *  @example boost/lagoon/example/for_each_04.cpp
 *  This example shows the usage of the namespace reflection functions
 *  and range for-each utility with lambda functions and the only_if
 *  range adapter
 *
 *  Copyright 2008-2010 Matus Chochlik. Distributed under the Boost
 *  Software License, Version 1.0. (See accompanying file
 *  LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
 */

#include <boost/mirror/mirror.hpp>
#include <boost/lagoon/lagoon.hpp>
#include <boost/lagoon/range/for_each.hpp>
#include <boost/lagoon/range/only_if.hpp>
#include <iostream>

int main(void)
{
        using namespace boost::lagoon;
        //
        // get the members of the global scope and filter only those
        // satisfying the predicate (the first lambda function)
        // (i.e. meta-objects for which the is_namespace member
        // function returns true) and call the second lambda function
        // on each element of the resulting range
        for_each(
                only_if(
                        reflected_global_scope()->members(),
                        [](const shared<meta_named_scoped_object>& member)
                        {
                                return member->is_namespace();
                        }
                ),
                [](const shared<meta_named_scoped_object>& member)
                {
                        std::cout
                                << member->self()->base_name()
                                << " "
                                << member->base_name()
                                << std::endl;
                }
        );
        return 0;
}

/* Example of output:
namespace std
namespace boost
*/
