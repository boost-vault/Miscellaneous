/**
 *  @example boost/lagoon/example/factories/tetrahedron_script.cpp
 *  This example shows the usage of the script-parsing automatically
 *  generated polymorphic factory to create instances of the test tetrahedron
 *  class.
 *
 *  Copyright 2008-2010 Matus Chochlik. Distributed under the Boost
 *  Software License, Version 1.0. (See accompanying file
 *  LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
 */

//
// We want to use Lagoon's polymorphic factories
#define BOOST_LAGOON_MT_WITH_MAKE_FACTORY 1
//
// We don't need to traverse through namespace members.
// Using this CT switch can greatly improve compile times
// and the resulting executable size if namespace member
// traversal is not needed
#define BOOST_LAGOON_NO_NAMESPACE_MEMBERS 1

#include <boost/mirror/mirror.hpp>
#include <boost/mirror/stream.hpp>
#include <boost/lagoon/lagoon.hpp>
#include <boost/lagoon/utils/script_factory.hpp>
#include <iostream>
#include <stdexcept>

#include "./tetrahedron.hpp"

int main(void)
{
        try
        {
                using namespace boost::lagoon;
                script_factory_builder builder;
                script_factory_input in;
                auto data = in.data();
                //
                auto meta_th = reflected_class<test::tetrahedron>();
                auto th_factory = meta_th->make_factory(
                        builder,
                        raw_ptr(&data)
                );

                const char* inputs[] = {
                        "test::tetrahedron( \
                                test::triangle( \
                                        test::vector(1, 0, 0), \
                                        test::vector(0, 1, 0), \
                                        test::vector() \
                                ), \
                                test::vector(0, 0, 6) \
                        )",
                        "test::tetrahedron( \
                                test::triangle( \
                                        test::vector(2, 0, 0), \
                                        test::vector(0, 2, 0), \
                                        test::vector(0.0) \
                                ), \
                                test::vector(0, 0, 3) \
                        )",
                        "test::tetrahedron( \
                                test::vector(0, 0, 0), \
                                test::vector(2, 0, 0), \
                                test::vector(0, 2, 0), \
                                test::vector(0, 0, 3) \
                        )",
                        "{{{1,0,0},{0,2,0},{0,0,0}},{0,0,3}}",
                        "{{3,0,0},{0,4,0},{0,0,0},{0,0,1}}"
                };
                const char** cur = inputs;
                const char** end = inputs + sizeof(inputs) / sizeof(inputs[0]);
                while(cur != end)
                {
                        std::string src(*cur++);
                        in.set(src);
                        // use the factory to construct a tetrahedron and calculate
                        // its volume and base area
                        raw_ptr pt = th_factory->new_();
                        test::tetrahedron& t = *raw_cast<test::tetrahedron*>(pt);
                        // ... and print them out
                        std::cout << "the volume is " << t.volume() << " " << std::flush;
                        std::cout << "the area of the base is " << t.base.area() << std::endl;
                        meta_th->delete_(pt);
                }
        }
        catch(std::exception const& error)
        {
                std::cerr << "Error: " << error.what() << std::endl;
        }
        //
        return 0;
}

/* Example of output:
the volume is 1 the area of the base is 0.5
the volume is 2 the area of the base is 2
the volume is 2 the area of the base is 2
the volume is 1 the area of the base is 1
the volume is 2 the area of the base is 6
*/
