/**
 *  @example boost/lagoon/example/factories/person_script.cpp
 *  This example shows the usage of the script-parsing automatically
 *  generated polymorphic factory to create instances of the test person
 *  class.
 *
 *  Copyright 2008-2011 Matus Chochlik. Distributed under the Boost
 *  Software License, Version 1.0. (See accompanying file
 *  LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
 */

//
// We want to use Lagoon's polymorphic factories
#define BOOST_LAGOON_MT_WITH_MAKE_FACTORY 1
//
// We don't need to traverse through namespace members.
// Using this CT switch can greatly improve compile times
// and the resulting executable size if namespace member
// traversal is not needed
#define BOOST_LAGOON_NO_NAMESPACE_MEMBERS 1

#include <boost/mirror/mirror.hpp>
#include <boost/mirror/stream.hpp>
#include <boost/lagoon/lagoon.hpp>
#include <boost/lagoon/utils/script_factory.hpp>
#include <iostream>
#include <stdexcept>

#include "./person.hpp"
int main(void)
{
        try
        {
                using namespace boost::lagoon;
                //
                script_factory_builder builder;
                script_factory_input in;
                auto data = in.data();
                //
                auto meta_person = reflected_class<test::person>();
                auto person_factory = meta_person->make_factory(
                        builder,
                        raw_ptr(&data)
                );
                int i = 0;
                std::string src;
                while(!std::getline(std::cin, src, ';').eof())
                {
                        in.set(src);
                        raw_ptr ppers = person_factory->new_();
                        test::person& pers = *raw_cast<test::person*>(ppers);
                        std::cout << boost::mirror::stream::to_json::from(
                                pers,
                                [&i](std::ostream& out)
                                { out << "person_" << i; }
                        ) << std::endl;
                        meta_person->delete_(ppers);
                        ++i;
                }
        }
        catch(std::exception const& error)
        {
                std::cerr << "Error: " << error.what() << std::endl;
        }
        //
        return 0;
}
/* Example of input
 |  test::person(
 |          '\u0414\u043C\u0438\u0301\u0442\u0440\u0438\u0439',
 |          '\u0418\u0432\u0430\u0301\u043D\u043E\u0432\u0438\u0446',
 |          '\u041C\u0435\u043D\u0414\u0435\u043B\u0435\u0301\u0435\u0432',
 |          '1834-02-08',
 |          male,
 |          75,
 |          175
 |  );
 |  test::person('Albert', 'Einstein', '1879-03-14', male, 70, 170);
 |  test::person('Marie', 'Sk\u0142odowska-Curie', '1867-11-07', female, 52, 165);
 */


/* Example of output:
 |  "person_0": {
 |      "first_name": "Дми́трий",
 |      "middle_name": "Ива́новиц",
 |      "family_name": "МенДеле́ев",
 |      "birth_date": {
 |          "tm_sec": 0,
 |          "tm_min": 0,
 |          "tm_hour": 0,
 |          "tm_mday": 8,
 |          "tm_mon": 1,
 |          "tm_year": -66,
 |          "tm_wday": 0,
 |          "tm_yday": 0,
 |          "tm_isdst": -1
 |      },
 |      "sex": "male",
 |      "weight": 75,
 |      "height": 175
 |  }
 |  "person_1": {
 |      "first_name": "Albert",
 |      "middle_name": "",
 |      "family_name": "Einstein",
 |      "birth_date": {
 |          "tm_sec": 0,
 |          "tm_min": 0,
 |          "tm_hour": 0,
 |          "tm_mday": 14,
 |          "tm_mon": 2,
 |          "tm_year": -21,
 |          "tm_wday": 0,
 |          "tm_yday": 0,
 |          "tm_isdst": -1
 |      },
 |      "sex": "male",
 |      "weight": 70,
 |      "height": 170
 |  }
 |  "person_2": {
 |      "first_name": "Marie",
 |      "middle_name": "",
 |      "family_name": "Skłodowska-Curie",
 |      "birth_date": {
 |          "tm_sec": 0,
 |          "tm_min": 0,
 |          "tm_hour": 0,
 |          "tm_mday": 7,
 |          "tm_mon": 10,
 |          "tm_year": -33,
 |          "tm_wday": 0,
 |          "tm_yday": 0,
 |          "tm_isdst": -1
 |      },
 |      "sex": "female",
 |      "weight": 52,
 |      "height": 165
 |  }
 */
