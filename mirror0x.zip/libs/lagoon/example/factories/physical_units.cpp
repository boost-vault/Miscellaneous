/**
 *  @example boost/lagoon/example/factories/physical_units.cpp
 *
 *  This example shows how to use a factory created by the factory generator
 *  with a script parsing plugin to generically construct instances
 *  of classes with non default constructors, from input strings.
 *
 *  Copyright 2006-2011 Matus Chochlik. Distributed under the Boost
 *  Software License, Version 1.0. (See accompanying file
 *  LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
 */

//
// We want to use Lagoon's polymorphic factories
#define BOOST_LAGOON_MT_WITH_MAKE_FACTORY 1
//
// We don't need to traverse through namespace members.
// Using this CT switch can greatly improve compile times
// and the resulting executable size if namespace member
// traversal is not needed
#define BOOST_LAGOON_NO_NAMESPACE_MEMBERS 1

#include <boost/mirror/mirror_base.hpp>
#include <boost/mirror/pre_registered/basic.hpp>
#include <boost/mirror/pre_registered/class/std/map.hpp>
#include <boost/mirror/pre_registered/class/std/set.hpp>
#include <boost/lagoon/lagoon.hpp>
#include <boost/lagoon/utils/script_factory.hpp>
#include <iostream>

#include "./tetrahedron.hpp"

int main(void)
{
        try
        {
                using namespace boost::lagoon;
                c_str_script_factory_builder builder;
                c_str_script_factory_input in;
                auto data = in.data();
                //
                typedef std::map<std::string, std::set<std::string> >
                        unit_map;
                auto meta_unit_map = reflected_class<unit_map>();
                auto unit_map_factory = meta_unit_map->make_factory(
                        builder,
                        raw_ptr(&data)
                );
                //
                const char input[] = "{ \
                        {'length', {'meter', 'inch', 'foot', 'yard', 'mile', 'furlong'}}, \
                        {'area', {'square meter', 'acre'}}, \
                        {'volume', {'liter', 'cubic meter', 'gallon', 'pint'}}, \
                        {'mass', {'kilogram', 'tonne', 'pound'}}, \
                        {'time', {'second', 'minute', 'hour', 'year', 'month', 'day'}}, \
                        {'electric current', {'ampere'}}, \
                        {'energy', {'joule'}}, \
                        {'force', {'newton', 'dyne'}}, \
                        {'power', {'watt'}}, \
                        {'frequency', {'hertz'}}, \
                        {'inductance', {'henry'}}, \
                        {'pressure', {'pascal', 'bar', 'atmosphere'}}, \
                        {'angle', {'degree', 'radian', 'gradian'}}, \
                        {'temperature', {'kelvin', 'degrees celsius', 'degrees fahrenheit'}} \
                }";
                in.set(input, input+sizeof(input));
                raw_ptr punits = unit_map_factory->new_();
                unit_map& units = *raw_cast<unit_map*>(punits);
                for(auto i = units.begin(), e = units.end(); i != e; ++i)
                {
                        std::cout << "Some units for '" << i->first << "': '";
                        auto j = i->second.begin(), f = i->second.end();
                        while(j != f)
                        {
                                std::cout << *j;
                                ++j;
                                if(j == f) std::cout << "'.";
                                else std::cout << "', '";
                        }
                        std::cout << std::endl;
                }
                meta_unit_map->delete_(punits);
        }
        catch(std::exception const& error)
        {
                std::cerr << "Error: " << error.what() << std::endl;
        }
        //
        return 0;
}

/* Example of output:
Some units for 'angle': 'degree', 'gradian', 'radian'.
Some units for 'area': 'acre', 'square meter'.
Some units for 'electric current': 'ampere'.
Some units for 'energy': 'joule'.
Some units for 'force': 'dyne', 'newton'.
Some units for 'frequency': 'hertz'.
Some units for 'inductance': 'henry'.
Some units for 'length': 'foot', 'furlong', 'inch', 'meter', 'mile', 'yard'.
Some units for 'mass': 'kilogram', 'pound', 'tonne'.
Some units for 'power': 'watt'.
Some units for 'pressure': 'atmosphere', 'bar', 'pascal'.
Some units for 'temperature': 'degrees celsius', 'degrees fahrenheit', 'kelvin'.
Some units for 'time': 'day', 'hour', 'minute', 'month', 'second', 'year'.
Some units for 'volume': 'cubic meter', 'gallon', 'liter', 'pint'.
 */
