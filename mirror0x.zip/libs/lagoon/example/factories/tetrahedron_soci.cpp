/**
 *  @example boost/lagoon/example/factories/tetrahedron_soci.cpp
 *  This example shows the usage of the SOCI based automatically
 *  generated polymorphic factory to create instances of the test tetrahedron
 *  class.
 *
 *  This example requires access to a local postgresql database named 'test'
 *  with a tables named 'vector', 'triangle' and 'tetrahedron'
 *  with (more or less) the following definition (containing some data):
 *
 *  @code
 *  CREATE TABLE vector(
 *      vector_id INTEGER PRIMARY KEY.
 *      x DOUBLE PRECISION NOT NULL,
 *      y DOUBLE PRECISION NOT NULL,
 *      z  DOUBLE PRECISION NOT NULL
 *  );
 *
 *  CREATE TABLE triangle (
 *      triangle_id INTEGER PRIMARY KEY,
 *      a_vector_id INTEGER NOT NULL,
 *      b_vector_id INTEGER NOT NULL,
 *      c_vector_id INTEGER NOT NULL
 *  );
 *  ALTER TABLE triangle ADD FOREIGN KEY (a_vector_id) REFERENCES vector;
 *  ALTER TABLE triangle ADD FOREIGN KEY (b_vector_id) REFERENCES vector;
 *  ALTER TABLE triangle ADD FOREIGN KEY (c_vector_id) REFERENCES vector;
 *
 *  CREATE TABLE tetrahedron (
 *      tetrahedron_id INTEGER PRIMARY KEY,
 *      base_triangle_id INTEGER NOT NULL,
 *      apex_vector_id INTEGER NOT NULL
 *  );
 *  ALTER TABLE tetrahedron ADD FOREIGN KEY (base_triangle_id) REFERENCES triangle;
 *  ALTER TABLE tetrahedron ADD FOREIGN KEY (apex_vector_id) REFERENCES vector;
 *  @endcode
 *
 *  Copyright 2008-2010 Matus Chochlik. Distributed under the Boost
 *  Software License, Version 1.0. (See accompanying file
 *  LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
 */

//
// We want to use Lagoon's polymorphic factories
#define BOOST_LAGOON_MT_WITH_MAKE_FACTORY 1
//
// We don't need to traverse through namespace members.
// Using this CT switch can greatly improve compile times
// and the resulting executable size if namespace member
// traversal is not needed
#define BOOST_LAGOON_NO_NAMESPACE_MEMBERS 1

#include <boost/mirror/mirror.hpp>
#include <boost/mirror/stream.hpp>
#include <boost/lagoon/lagoon.hpp>
#include <boost/lagoon/utils/soci_factory.hpp>
#include <soci-postgresql.h>
#include <iostream>
#include <stdexcept>

#include "./tetrahedron.hpp"
int main(void)
{
        try
        {
                using namespace boost::lagoon;
                using namespace soci;
                session test_db(postgresql, "dbname=test");
                rowset<row> dataset(
                        test_db.prepare <<
                        "SELECT "\
                                "vba.x AS base__a__x, "\
                                "vba.y AS base__a__y, "\
                                "vba.z AS base__a__z, "\
                                "vbb.x AS base__b__x, "\
                                "vbb.y AS base__b__y, "\
                                "vbb.z AS base__b__z, "\
                                "vbc.x AS base__c__x, "\
                                "vbc.y AS base__c__y, "\
                                "vbc.z AS base__c__z, "\
                                "va.x AS apex__x, "\
                                "va.y AS apex__y, "\
                                "va.z AS apex__z  "\
                        "FROM tetrahedron t "\
                        "JOIN triangle b ON(t.base_triangle_id = b.triangle_id) "\
                        "JOIN vector va ON(t.apex_vector_id = va.vector_id) "\
                        "JOIN vector vba ON(b.a_vector_id = vba.vector_id) "\
                        "JOIN vector vbb ON(b.b_vector_id = vbb.vector_id) "\
                        "JOIN vector vbc ON(b.c_vector_id = vbc.vector_id) "
                );
                auto r = dataset.begin(), e = dataset.end();
                int i = 0;
                soci_factory_builder builder;
                soci_fact_data data(r);
                auto meta_tetrahedron = reflected_class<test::tetrahedron>();
                auto tetrahedron_factory = meta_tetrahedron->make_factory(
                        builder,
                        raw_ptr(&data)
                );
                // make a tetrahedron object factory
                while(r != e)
                {
                        raw_ptr pt = tetrahedron_factory->new_();
                        test::tetrahedron& t = *raw_cast<test::tetrahedron*>(pt);
                        std::cout << boost::mirror::stream::to_json::from(
                                t,
                                [&i](std::ostream& out)
                                { out << "tetrahedron_" << i; }
                        ) << std::endl;
                        meta_tetrahedron->delete_(pt);
                        ++r;
                        ++i;
                }
        }
        catch(std::exception const& error)
        {
                std::cerr << "Error: " << error.what() << std::endl;
        }
        //
        return 0;
}

/* Sample data:
 |
 |  test=> SELECT * FROM vector;
 |   vector_id | x | y | z
 |  -----------+---+---+----
 |           0 | 0 | 0 |  0
 |           1 | 1 | 0 |  0
 |           2 | 0 | 1 |  0
 |           3 | 0 | 0 |  6
 |           4 | 0 | 0 | 24
 |  (5 rows)
 |
 |  test=> SELECT * FROM triangle ;
 |   triangle_id | a_vector_id | b_vector_id | c_vector_id
 |  -------------+-------------+-------------+-------------
 |             0 |           0 |           1 |           2
 |  (1 row)
 |
 |  test=> SELECT * FROM tetrahedron ;
 |   tetrahedron_id | base_triangle_id | apex_vector_id
 |  ----------------+------------------+----------------
 |                0 |                0 |              3
 |                1 |                0 |              4
 |  (2 rows)
 */

/* Example of output:
 |  "tetrahedron_0": {
 |      "base": {
 |          "a": {
 |              "x": 0,
 |              "y": 0,
 |              "z": 0
 |          },
 |          "b": {
 |              "x": 1,
 |              "y": 0,
 |              "z": 0
 |          },
 |          "c": {
 |              "x": 0,
 |              "y": 1,
 |              "z": 0
 |          }
 |      },
 |      "apex": {
 |          "x": 0,
 |          "y": 0,
 |          "z": 6
 |      }
 |  }
 |  the volume is 1
 |  the area of the base is 0.5
 |  "tetrahedron_1": {
 |      "base": {
 |          "a": {
 |              "x": 0,
 |              "y": 0,
 |              "z": 0
 |          },
 |          "b": {
 |              "x": 1,
 |              "y": 0,
 |              "z": 0
 |          },
 |          "c": {
 |              "x": 0,
 |              "y": 1,
 |              "z": 0
 |          }
 |      },
 |      "apex": {
 |          "x": 0,
 |          "y": 0,
 |          "z": 24
 |      }
 |  }
 |  the volume is 4
 |  the area of the base is 0.5
 */
