/**
 *  @example boost/lagoon/example/factories/person_pq.cpp
 *  This example shows the usage of the LIBPQ based automatically
 *  generated polymorphic factory to create instances of the test person
 *  class.
 *
 *  This example requires access to a local postgresql database named 'test'
 *  with a table named 'person' with (more or less) the following definition
 *  (containing some data):
 *
 *  @code
 *  CREATE TABLE person (
 *    first_name TEXT NOT NULL,
 *    middle_name TEXT.
 *    family_name TEXT NOT NULL,
 *    birth_date DATE,
 *    weight FLOAT,
 *    height FLOAT
 *  );
 *  @endcode
 *
 *  Copyright 2008-2010 Matus Chochlik. Distributed under the Boost
 *  Software License, Version 1.0. (See accompanying file
 *  LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
 */

//
// We want to use Lagoon's polymorphic factories
#define BOOST_LAGOON_MT_WITH_MAKE_FACTORY 1
//
// We don't need to traverse through namespace members.
// Using this CT switch can greatly improve compile times
// and the resulting executable size if namespace member
// traversal is not needed
#define BOOST_LAGOON_NO_NAMESPACE_MEMBERS 1

#include <boost/mirror/mirror.hpp>
#include <boost/mirror/stream.hpp>
#include <boost/lagoon/lagoon.hpp>
#include <boost/lagoon/utils/libpq_factory.hpp>
#include <iostream>
#include <stdexcept>

#include "./person.hpp"
int main(void)
{
        try
        {
                using namespace boost::lagoon;
                // connect to the database
                libpq_fact_db test_db("dbname=test");
                // query data about persons
                libpq_fact_result persons=test_db.query("SELECT * FROM person");
                // make a person object factory
                libpq_factory_builder builder;
                libpq_fact_data data(persons.data());
                auto meta_person = reflected_class<test::person>();
                auto person_factory = meta_person->make_factory(
                        builder,
                        raw_ptr(&data)
                );
                // go through the rows of the data-set
                while(!persons.empty())
                {
                        raw_ptr ppers = person_factory->new_();
                        test::person& pers = *raw_cast<test::person*>(ppers);
                        std::cout <<
                                // make a person from the data
                                // and write it to std output
                                boost::mirror::stream::to_json::from(
                                        pers,
                                        [&persons](std::ostream& out)
                                        {out << "person_" << persons.position();}
                                ) << std::endl;
                        meta_person->delete_(ppers);
                        persons.next();
                }
        }
        catch(std::exception const& error)
        {
                std::cerr << "Error: " << error.what() << std::endl;
        }
        //
        return 0;
}

/* Example of output:
 |  "person_0": {
 |      "first_name": "Johnny",
 |      "middle_name": "B",
 |      "family_name": "Goode",
 |      "birth_date": {
 |          "tm_sec": 0,
 |          "tm_min": 0,
 |          "tm_hour": 0,
 |          "tm_mday": 1,
 |          "tm_mon": 0,
 |          "tm_year": 10,
 |          "tm_wday": 6,
 |          "tm_yday": 0,
 |          "tm_isdst": 0
 |      },
 |      "weight": 80.1,
 |      "height": 180
 |  }
 */
