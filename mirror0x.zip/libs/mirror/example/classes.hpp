/**
 *  Copyright 2008-2011 Matus Chochlik. Distributed under the Boost
 *  Software License, Version 1.0. (See accompanying file
 *  LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
 */
#ifndef BOOST_MIRROR_LIBS_EXAMPLES_CLASSES_1011291729_HPP
#define BOOST_MIRROR_LIBS_EXAMPLES_CLASSES_1011291729_HPP

#include <boost/mirror/meta_class.hpp>
#include <boost/mirror/meta_enum.hpp>

namespace test {

struct A
{
        int a;
};

struct B
{
        bool b;
};

struct C
 : virtual public A
 , virtual public B
{
        char c;
};

struct D
 : virtual public A
 , virtual public B
{
        double d;
};

struct E
 : virtual public C
 , virtual public D
{
        double e;
};

struct F
 : public E
 , virtual public C
 , virtual public D
{
        float f;
};

struct G
{
        short g;
};

struct H
 : public F
 , public G
{
        long h;
};

enum class Ch
{
        null = '\0',
        bell = '\a',
        linefeed = '\n',
        carriage_return = '\r',
        horizontal_tab = '\t',
        formfeed = '\f'
};

class I
{
private:
        static int i;
        BOOST_MIRROR_FRIENDLY_CLASS(I);
public:
        int get_i(void) const
        {
                return i;
        }

        void set_i(int _i)
        {
                i = _i;
        }
};

int I::i = 0;

struct J : public I
{
        unsigned j;
};

} // namespace test

BOOST_MIRROR_REG_BEGIN

BOOST_MIRROR_REG_OBJECT_TAG(hidden)

BOOST_MIRROR_QREG_GLOBAL_SCOPE_NAMESPACE(test)

BOOST_MIRROR_REG_CLASS_BEGIN(struct, test, A)
BOOST_MIRROR_REG_CLASS_END

BOOST_MIRROR_TAG_TYPE(test::A, (hidden))

BOOST_MIRROR_REG_CLASS_BEGIN(struct, test, B)
BOOST_MIRROR_REG_CLASS_END

BOOST_MIRROR_TAG_TYPE(test::B, (hidden))

BOOST_MIRROR_REG_CLASS_BEGIN(struct, test, C)
// register base classes
BOOST_MIRROR_REG_BASE_CLASSES_BEGIN
        BOOST_MIRROR_REG_BASE_CLASS(virtual, _, test::A),
        BOOST_MIRROR_REG_BASE_CLASS(virtual, _, test::B)
BOOST_MIRROR_REG_BASE_CLASSES_END
// register member variables
BOOST_MIRROR_REG_CLASS_MEM_VARS_BEGIN
        BOOST_MIRROR_REG_CLASS_MEM_VAR(_, _, _, c)
BOOST_MIRROR_REG_CLASS_MEM_VARS_END
BOOST_MIRROR_REG_CLASS_END

BOOST_MIRROR_REG_CLASS_BEGIN(struct, test, D)
// register base classes
BOOST_MIRROR_REG_BASE_CLASSES_BEGIN
        BOOST_MIRROR_REG_BASE_CLASS(virtual, _, test::A),
        BOOST_MIRROR_REG_BASE_CLASS(virtual, _, test::B)
BOOST_MIRROR_REG_BASE_CLASSES_END
// register member variables
BOOST_MIRROR_REG_CLASS_MEM_VARS_BEGIN
        BOOST_MIRROR_REG_CLASS_MEM_VAR(_, _, _, d)
BOOST_MIRROR_REG_CLASS_MEM_VARS_END
BOOST_MIRROR_REG_CLASS_END

BOOST_MIRROR_REG_CLASS_BEGIN(struct, test, E)
// register base classes
BOOST_MIRROR_REG_BASE_CLASSES_BEGIN
        BOOST_MIRROR_REG_BASE_CLASS(virtual, _, test::C),
        BOOST_MIRROR_REG_BASE_CLASS(virtual, _, test::D)
BOOST_MIRROR_REG_BASE_CLASSES_END
// register member variables
BOOST_MIRROR_REG_CLASS_MEM_VARS_BEGIN
        BOOST_MIRROR_REG_CLASS_MEM_VAR(_, _, _, e)
BOOST_MIRROR_REG_CLASS_MEM_VARS_END
BOOST_MIRROR_REG_CLASS_END

BOOST_MIRROR_REG_CLASS_BEGIN(struct, test, F)
// register base classes
BOOST_MIRROR_REG_BASE_CLASSES_BEGIN
        BOOST_MIRROR_REG_BASE_CLASS(_, _, test::E),
        BOOST_MIRROR_REG_BASE_CLASS(virtual, _, test::C),
        BOOST_MIRROR_REG_BASE_CLASS(virtual, _, test::D)
BOOST_MIRROR_REG_BASE_CLASSES_END
// register member variables
BOOST_MIRROR_REG_CLASS_MEM_VARS_BEGIN
        BOOST_MIRROR_REG_CLASS_MEM_VAR(_, _, _, f)
BOOST_MIRROR_REG_CLASS_MEM_VARS_END
BOOST_MIRROR_REG_CLASS_END

BOOST_MIRROR_REG_CLASS_BEGIN(struct, test, G)
BOOST_MIRROR_REG_CLASS_MEM_VARS_BEGIN
        BOOST_MIRROR_REG_CLASS_MEM_VAR(_, _, _, g)
BOOST_MIRROR_REG_CLASS_MEM_VARS_END
BOOST_MIRROR_REG_CLASS_END

BOOST_MIRROR_REG_CLASS_BEGIN(struct, test, H)
// register base classes
BOOST_MIRROR_REG_BASE_CLASSES_BEGIN
        BOOST_MIRROR_REG_BASE_CLASS(_, _, test::F),
        BOOST_MIRROR_REG_BASE_CLASS(_, _, test::G)
BOOST_MIRROR_REG_BASE_CLASSES_END
// register member variables
BOOST_MIRROR_REG_CLASS_MEM_VARS_BEGIN
        BOOST_MIRROR_REG_CLASS_MEM_VAR(_, _, _, h)
BOOST_MIRROR_REG_CLASS_MEM_VARS_END
BOOST_MIRROR_REG_CLASS_END

BOOST_MIRROR_REG_ENUM_BEGIN(test, Ch)
        BOOST_MIRROR_REG_ENUM_VALUE(null)
        BOOST_MIRROR_REG_ENUM_VALUE(bell)
        BOOST_MIRROR_REG_ENUM_VALUE(linefeed)
        BOOST_MIRROR_REG_ENUM_VALUE(carriage_return)
        BOOST_MIRROR_REG_ENUM_VALUE(horizontal_tab)
        BOOST_MIRROR_REG_ENUM_VALUE(formfeed)
BOOST_MIRROR_REG_ENUM_END

BOOST_MIRROR_REG_CLASS_BEGIN(class, test, I)
BOOST_MIRROR_REG_CLASS_MEM_VARS_BEGIN
        BOOST_MIRROR_REG_CLASS_MEM_VAR_GET_SET(private, static, int, i, _.get_i(), _.set_i(_i))
BOOST_MIRROR_REG_CLASS_MEM_VARS_END
BOOST_MIRROR_REG_CLASS_END

BOOST_MIRROR_REG_CLASS_BEGIN(struct, test, J)
BOOST_MIRROR_REG_BASE_CLASSES_BEGIN
        BOOST_MIRROR_REG_BASE_CLASS(_, _, test::I)
BOOST_MIRROR_REG_BASE_CLASSES_END
BOOST_MIRROR_REG_CLASS_MEM_VARS_BEGIN
        BOOST_MIRROR_REG_CLASS_MEM_VAR(_, _, _, j)
BOOST_MIRROR_REG_CLASS_MEM_VARS_END
BOOST_MIRROR_REG_CLASS_END

BOOST_MIRROR_REG_END

#endif
