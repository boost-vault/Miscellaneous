/**
 *  @example boost/mirror/example/hello_world.cpp
 *  Simple yet not very useful hello world example.
 *  Shows the basics of namespace and type registration and reflection
 *
 *  Copyright 2008-2011 Matus Chochlik. Distributed under the Boost
 *  Software License, Version 1.0. (See accompanying file
 *  LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
 */

#include <boost/mirror/meta_namespace.hpp>
#include <boost/mirror/meta_type.hpp>
#include <iostream>

namespace Hello {

struct World { };

} // namespace Hello

BOOST_MIRROR_REG_BEGIN
// Register the Hello namespace
BOOST_MIRROR_QREG_GLOBAL_SCOPE_NAMESPACE(Hello)

// Register the ::Hello::World type
BOOST_MIRROR_REG_TYPE(Hello, World)

BOOST_MIRROR_REG_END

int main(void)
{
        using namespace boost::mirror;
        // reflect the Hello::World type and print its full name
        std::cout <<
                BOOST_MIRRORED_TYPE(Hello::World)::full_name() <<
                std::endl;
        //
        // get the scope of the Hello::World class (the Hello namespace)
        // and print its base name and then print the base name
        // of the Hello::World class
        std::cout <<
                boost::mirror::reflected<Hello::World>::type::scope::base_name() <<
                ", " <<
                boost::mirror::reflected_type<Hello::World>::base_name() <<
                "." <<
                std::endl;
        //
        return 0;
}

/* Example of output:
Hello::World
Hello, World.
*/
