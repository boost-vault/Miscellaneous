/**
 *  @file boost/mirror/example/factories/tetrahedron.hpp
 *
 *  Two classes used in some of the examples showing
 *  the use of meta-constructors and factories
 *
 *  Copyright 2008-2010 Matus Chochlik. Distributed under the Boost
 *  Software License, Version 1.0. (See accompanying file
 *  LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
 */

#ifndef BOOST_MIRROR_EXAMPLE_FACTORIES_TETRAHEDRON_1011291729_HPP
#define BOOST_MIRROR_EXAMPLE_FACTORIES_TETRAHEDRON_1011291729_HPP

#include <cmath>
#include <boost/mirror/meta_class.hpp>
#include <boost/mirror/pre_registered/type/native.hpp>

namespace test {

struct vector
{
        double x,y,z;

        vector(double _x, double _y, double _z)
         : x(_x)
         , y(_y)
         , z(_z)
        { }

        vector(double _w)
         : x(_w)
         , y(_w)
         , z(_w)
        { }

        vector(void)
         : x(0.0)
         , y(0.0)
         , z(0.0)
        { }

        // addition
        friend vector operator + (const vector& a, const vector& b)
        {
                return vector(a.x + b.x, a.y + b.y, a.z + b.z);
        }

        // subtraction
        friend vector operator - (const vector& a, const vector& b)
        {
                return vector(a.x - b.x, a.y - b.y, a.z - b.z);
        }

        // cross product
        friend vector operator % (const vector& a, const vector& b)
        {
                return vector(
                        a.y * b.z - a.z * b.y,
                        a.z * b.x - a.x * b.z,
                        a.x * b.y - a.y * b.x
                );
        }

        // dot product
        friend double operator * (const vector& a, const vector& b)
        {
                return a.x*b.x + a.y*b.y + a.z*b.z;
        }

        double length(void) const
        {
                return std::sqrt(x*x + y*y + z*z);
        }
};

struct triangle
{
        vector a, b, c;

        triangle(const vector& _a, const vector& _b, const vector& _c)
         : a(_a)
         , b(_b)
         , c(_c)
        { }

        triangle(void){ }


        double area(void) const
        {
                return ((b-a)%(c-a)).length()/2.0;
        }
};

struct tetrahedron
{
        triangle base;
        vector apex;

        tetrahedron(const triangle& _base, const vector& _apex)
         : base(_base)
         , apex(_apex)
        { }

        tetrahedron(
                const vector& a,
                const vector& b,
                const vector& c,
                const vector& d
        ): base(a, b, c)
         , apex(d)
        { }

        const vector& a(void) const {return base.a;}
        const vector& b(void) const {return base.b;}
        const vector& c(void) const {return base.c;}
        const vector& d(void) const {return apex;}

        void reset_apex(const vector& _apex)
        {
                apex = _apex;
        }

        void reset_apex(double x, double y, double z)
        {
                apex = vector(x, y, z);
        }

        double volume(void) const
        {
                return std::fabs(((a()-d())*((b()-d())%(c()-d()))))/6.0;
        }
};


} // namespace test


BOOST_MIRROR_REG_BEGIN

// register the ::test namespace
BOOST_MIRROR_QREG_GLOBAL_SCOPE_NAMESPACE(test)

// register the test::vector struct
BOOST_MIRROR_REG_CLASS_BEGIN(struct, test, vector)
  BOOST_MIRROR_REG_CLASS_MEM_VARS_BEGIN
    BOOST_MIRROR_REG_CLASS_MEM_VAR(_, _, _, x)
    BOOST_MIRROR_REG_CLASS_MEM_VAR(_, _, _, y)
    BOOST_MIRROR_REG_CLASS_MEM_VAR(_, _, _, z)
  BOOST_MIRROR_REG_CLASS_MEM_VARS_END

  BOOST_MIRROR_REG_CONSTRUCTORS_BEGIN
    BOOST_MIRROR_REG_CONSTRUCTOR_BEGIN(public, xyz)
      BOOST_MIRROR_REG_CONSTRUCTOR_PARAM(_, x)
      BOOST_MIRROR_REG_CONSTRUCTOR_PARAM(_, y)
      BOOST_MIRROR_REG_CONSTRUCTOR_PARAM(_, z)
    BOOST_MIRROR_REG_CONSTRUCTOR_END(xyz)

    BOOST_MIRROR_REG_CONSTRUCTOR_BEGIN(public, w)
      BOOST_MIRROR_REG_CONSTRUCTOR_PARAM(double, w)
    BOOST_MIRROR_REG_CONSTRUCTOR_END(w)

    BOOST_MIRROR_REG_DEFAULT_CONSTRUCTOR(_)
    BOOST_MIRROR_REG_COPY_CONSTRUCTOR(_)
  BOOST_MIRROR_REG_CONSTRUCTORS_END
BOOST_MIRROR_REG_CLASS_END

// register the test::triangle struct
BOOST_MIRROR_REG_CLASS_BEGIN(struct, test, triangle)
  BOOST_MIRROR_REG_CLASS_MEM_VARS_BEGIN
    BOOST_MIRROR_REG_CLASS_MEM_VAR(_, _, _, a)
    BOOST_MIRROR_REG_CLASS_MEM_VAR(_, _, _, b)
    BOOST_MIRROR_REG_CLASS_MEM_VAR(_, _, _, c)
  BOOST_MIRROR_REG_CLASS_MEM_VARS_END

  BOOST_MIRROR_REG_CONSTRUCTORS_BEGIN
    BOOST_MIRROR_REG_CONSTRUCTOR_BEGIN(public, abc)
      BOOST_MIRROR_REG_CONSTRUCTOR_PARAM(_, a)
      BOOST_MIRROR_REG_CONSTRUCTOR_PARAM(_, b)
      BOOST_MIRROR_REG_CONSTRUCTOR_PARAM(_, c)
    BOOST_MIRROR_REG_CONSTRUCTOR_END(abc)

    BOOST_MIRROR_REG_DEFAULT_CONSTRUCTOR(_)
    BOOST_MIRROR_REG_COPY_CONSTRUCTOR(_)
  BOOST_MIRROR_REG_CONSTRUCTORS_END
BOOST_MIRROR_REG_CLASS_END

// register the test::tetrahedron struct
BOOST_MIRROR_REG_CLASS_BEGIN(struct, test, tetrahedron)
  BOOST_MIRROR_REG_CLASS_MEM_VARS_BEGIN
    BOOST_MIRROR_REG_CLASS_MEM_VAR(_, _, _, base)
    BOOST_MIRROR_REG_CLASS_MEM_VAR(_, _, _, apex)
  BOOST_MIRROR_REG_CLASS_MEM_VARS_END

  BOOST_MIRROR_REG_CONSTRUCTORS_BEGIN
    BOOST_MIRROR_REG_CONSTRUCTOR_BEGIN(public, ba)
      BOOST_MIRROR_REG_CONSTRUCTOR_PARAM(_, base)
      BOOST_MIRROR_REG_CONSTRUCTOR_PARAM(_, apex)
    BOOST_MIRROR_REG_CONSTRUCTOR_END(ba)

    BOOST_MIRROR_REG_CONSTRUCTOR_BEGIN(public, abcd)
      BOOST_MIRROR_REG_CONSTRUCTOR_PARAM(test::vector, a)
      BOOST_MIRROR_REG_CONSTRUCTOR_PARAM(test::vector, b)
      BOOST_MIRROR_REG_CONSTRUCTOR_PARAM(test::vector, c)
      BOOST_MIRROR_REG_CONSTRUCTOR_PARAM(test::vector, d)
    BOOST_MIRROR_REG_CONSTRUCTOR_END(abcd)

    BOOST_MIRROR_REG_COPY_CONSTRUCTOR(_)
  BOOST_MIRROR_REG_CONSTRUCTORS_END

  BOOST_MIRROR_REG_MEM_FUNCTIONS_BEGIN
    BOOST_MIRROR_REG_MEM_FUNCTION_BEGIN(public, _, void, reset_apex, 1)
      BOOST_MIRROR_REG_MEM_FUNCTION_PARAM(_, apex)
    BOOST_MIRROR_REG_MEM_FUNCTION_END(reset_apex, 1, _)
    BOOST_MIRROR_REG_MEM_FUNCTION_BEGIN(public, _, void, reset_apex, 2)
      BOOST_MIRROR_REG_MEM_FUNCTION_PARAM(double, x)
      BOOST_MIRROR_REG_MEM_FUNCTION_PARAM(double, y)
      BOOST_MIRROR_REG_MEM_FUNCTION_PARAM(double, z)
    BOOST_MIRROR_REG_MEM_FUNCTION_END(reset_apex, 2, _)
  BOOST_MIRROR_REG_MEM_FUNCTIONS_END
BOOST_MIRROR_REG_CLASS_END

BOOST_MIRROR_REG_END

#endif

