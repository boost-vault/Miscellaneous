/**
 *  @file boost/mirror/example/factories/tetrahedron.hpp
 *
 *  Two classes used in some of the examples showing
 *  the use of meta-constructors and factories
 *
 *  Copyright 2008-2010 Matus Chochlik. Distributed under the Boost
 *  Software License, Version 1.0. (See accompanying file
 *  LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
 */

#ifndef BOOST_MIRROR_EXAMPLE_FACTORIES_TETRAHEDRON_1011291729_HPP
#define BOOST_MIRROR_EXAMPLE_FACTORIES_TETRAHEDRON_1011291729_HPP

#include <boost/mirror/meta_class.hpp>
#include <boost/mirror/meta_enum.hpp>
#include <boost/mirror/pre_registered/type/native.hpp>
#include <string>
#include <ctime>

namespace test {

enum class gender
{
        female,
        male
};

struct person
{
        std::string first_name;
        std::string middle_name;
        std::string family_name;

        std::tm birth_date;
        gender sex;

        float weight;
        float height;

        person(
                const std::string& _first_name,
                const std::string& _family_name,
                const std::tm _birth_date,
                gender _sex,
                float _weight,
                float _height
        ): first_name(_first_name)
         , family_name(_family_name)
         , birth_date(_birth_date)
         , sex(_sex)
         , weight(_weight)
         , height(_height)
        { }

        person(
                const std::string& _first_name,
                const std::string& _middle_name,
                const std::string& _family_name,
                const std::tm _birth_date,
                gender _sex,
                float _weight,
                float _height
        ): first_name(_first_name)
         , middle_name(_middle_name)
         , family_name(_family_name)
         , birth_date(_birth_date)
         , sex(_sex)
         , weight(_weight)
         , height(_height)
        { }

        void remeasure(float _weight, float _height)
        {
                weight = _weight;
                height = _height;
        }
};

} // namespace test

BOOST_MIRROR_REG_BEGIN

BOOST_MIRROR_QREG_GLOBAL_SCOPE_NAMESPACE(test)

BOOST_MIRROR_REG_ENUM_BEGIN(test, gender)
        BOOST_MIRROR_REG_ENUM_VALUE(female)
        BOOST_MIRROR_REG_ENUM_VALUE(male)
BOOST_MIRROR_REG_ENUM_END

BOOST_MIRROR_REG_CLASS_BEGIN(struct, test, person)
BOOST_MIRROR_REG_CLASS_MEM_VARS_BEGIN
        BOOST_MIRROR_REG_CLASS_MEM_VAR(_, _, _, first_name)
        BOOST_MIRROR_REG_CLASS_MEM_VAR(_, _, _, middle_name)
        BOOST_MIRROR_REG_CLASS_MEM_VAR(_, _, _, family_name)
        BOOST_MIRROR_REG_CLASS_MEM_VAR(_, _, _, birth_date)
        BOOST_MIRROR_REG_CLASS_MEM_VAR(_, _, _, sex)
        BOOST_MIRROR_REG_CLASS_MEM_VAR(_, _, _, weight)
        BOOST_MIRROR_REG_CLASS_MEM_VAR(_, _, _, height)
BOOST_MIRROR_REG_CLASS_MEM_VARS_END
BOOST_MIRROR_REG_CONSTRUCTORS_BEGIN
        BOOST_MIRROR_REG_COPY_CONSTRUCTOR(public)

        BOOST_MIRROR_REG_CONSTRUCTOR_BEGIN(public, 1)
                BOOST_MIRROR_REG_CONSTRUCTOR_PARAM(_, first_name)
                BOOST_MIRROR_REG_CONSTRUCTOR_PARAM(_, family_name)
                BOOST_MIRROR_REG_CONSTRUCTOR_PARAM(_, birth_date)
                BOOST_MIRROR_REG_CONSTRUCTOR_PARAM(_, sex)
                BOOST_MIRROR_REG_CONSTRUCTOR_PARAM(_, weight)
                BOOST_MIRROR_REG_CONSTRUCTOR_PARAM(_, height)
        BOOST_MIRROR_REG_CONSTRUCTOR_END(1)

        BOOST_MIRROR_REG_CONSTRUCTOR_BEGIN(public, 2)
                BOOST_MIRROR_REG_CONSTRUCTOR_PARAM(_, first_name)
                BOOST_MIRROR_REG_CONSTRUCTOR_PARAM(_, middle_name)
                BOOST_MIRROR_REG_CONSTRUCTOR_PARAM(_, family_name)
                BOOST_MIRROR_REG_CONSTRUCTOR_PARAM(_, birth_date)
                BOOST_MIRROR_REG_CONSTRUCTOR_PARAM(_, sex)
                BOOST_MIRROR_REG_CONSTRUCTOR_PARAM(_, weight)
                BOOST_MIRROR_REG_CONSTRUCTOR_PARAM(_, height)
        BOOST_MIRROR_REG_CONSTRUCTOR_END(2)
BOOST_MIRROR_REG_CONSTRUCTORS_END
BOOST_MIRROR_REG_MEM_FUNCTIONS_BEGIN
        BOOST_MIRROR_REG_MEM_FUNCTION_BEGIN(public, _, void, remeasure, _)
                BOOST_MIRROR_REG_MEM_FUNCTION_PARAM(_, weight)
                BOOST_MIRROR_REG_MEM_FUNCTION_PARAM(_, height)
        BOOST_MIRROR_REG_MEM_FUNCTION_END(remeasure,_,_)
BOOST_MIRROR_REG_MEM_FUNCTIONS_END
BOOST_MIRROR_REG_CLASS_END

BOOST_MIRROR_REG_END

#endif

