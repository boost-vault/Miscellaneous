/**
 *  @file boost/mirror/example/factories/input_ui.hpp
 *
 *  Simple console based user interface plug-in for boost::mirror::factory
 *  used in the examples in this directory
 *
 *  Copyright 2008-2010 Matus Chochlik. Distributed under the Boost
 *  Software License, Version 1.0. (See accompanying file
 *  LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
 */

#ifndef BOOST_MIRROR_EXAMPLE_FACTORIES_INPUT_UI_1011291729_HPP
#define BOOST_MIRROR_EXAMPLE_FACTORIES_INPUT_UI_1011291729_HPP

#include <iostream>
#include <sstream>

#include <boost/mirror/factory.hpp>
#include <boost/mirror/meta_class.hpp>
#include <boost/mirror/meta_enum.hpp>
#include <boost/mirror/pre_registered/type/native.hpp>
#include <boost/mirror/meta_prog.hpp>
#include <boost/mirror/utils/default_suppliers.hpp>
#include <boost/mirror/utils/enum_val_by_name.hpp>

namespace test {

/** Implementation of the input interface, used to produce
 *  values by prompting the user to enter a value on the
 *  console.
 */
template <class Product, typename IsEnum>
struct console_input_ui
{
        Product x;

        struct constr_param_name_printer
        {
                template <class IterInfo>
                inline void operator()(IterInfo) const
                {
                        if(!IterInfo::is_first::value)
                                std::cout << ", ";
                        std::cout << IterInfo::type::base_name();
                }
        };

        struct constr_context_printer
        {
                template <class IterInfo>
                inline void operator()(IterInfo) const
                {
                        if(!IterInfo::is_first::value)
                                std::cout << "::";
                        std::cout << IterInfo::type::base_name();
                }
        };

        template <typename X>
        static bool parse_input(const std::string& input, std::true_type, X& x)
        {
                auto opt_val = boost::mirror::enum_value_by_name<X>::get_opt(input);
                if(opt_val.first)
                {
                        x = opt_val.second;
                        return true;
                }
                return false;
        }

        template <typename X>
        static bool parse_input(const std::string& input, std::false_type, X& x)
        {
                std::stringstream tmp(input);
                tmp >> x;
                return tmp.good();
        }

        template <class ConstructionInfo>
        console_input_ui(
                int tabs,
                ConstructionInfo construction_info,
                const Product& _x
        ): x(_x)
        {
                using namespace boost::mirror;
                // get the meta-function
                //
                std::cout <<
                        std::string(tabs, '\t') <<
                        "Enter " <<
                        BOOST_MIRRORED_TYPE(Product)::full_name() <<
                        " " <<
                        ConstructionInfo::parameter::base_name() <<
                        " for " <<
                        ConstructionInfo::function::full_name() <<
                        "(";
                //
                mp::for_each_ii<typename ConstructionInfo::parameters>(
                        constr_param_name_printer()
                );
                std::cout << ") in context (";
                mp::for_each_ii<typename ConstructionInfo::context>(
                        constr_context_printer()
                );
                std::cout <<
                        ") [" <<
                        x <<
                        "]" <<
                        " = " <<
                        ::std::flush;
                //
                while(1)
                {
                        std::string input;
                        std::getline(std::cin, input);
                        if(!input.empty())
                                if(parse_input(input, IsEnum(), x))
                                        break;
                }
        }

        void finish(int){ }

        inline Product operator()(void)
        {
                return x;
        }
};

template <class Product, class Unused>
struct input_ui_enum : console_input_ui<Product, std::true_type>
{
        template <class ConstructionInfo>
        inline input_ui_enum(int tabs, ConstructionInfo construction_info)
         : console_input_ui<Product, std::true_type>(
                tabs,
                construction_info,
                Product()
        ){ }
};

/*  The general implementation of the input user interface template.
 *  Upon construction prints-out a banner and uses a factory
 *  configured to use the same input user interface to construct
 *  the Product.
 */
template <class Product, class Unused>
struct input_ui
{
        struct banner
        {
                template <class ConstructionInfo>
                banner(int tabs, ConstructionInfo)
                {
                        using namespace boost::mirror;
                        typedef typename ConstructionInfo::parameter param;
                        //
                        // print some prompt
                        std::cout <<
                                std::string(tabs, '\t') <<
                                "Get " <<
                                BOOST_MIRRORED_TYPE(Product)::full_name() <<
                                " " <<
                                param::base_name() <<
                                ::std::endl;
                }
        } b;

        typedef typename boost::mirror::factory_maker<
                ::test::input_ui,
                boost::mirror::default_fact_suppliers,
                ::test::input_ui_enum,
                Unused
        > maker;
        typename maker::template factory< Product >::type f;

        template <class ConstructionInfo>
        inline input_ui(int tabs, ConstructionInfo construction_info)
         : b(tabs, construction_info)
         , f(tabs, construction_info)
        { }

        void finish(int){ }

        inline Product operator()(void)
        {
                return f();
        }
};

#define BOOST_MIRROR_EXAMPLES_SPECIALIZE_CONSOLE_INPUT_UI(TYPE, DEFAULT) \
template <class Unused>  \
struct input_ui< TYPE, Unused> : console_input_ui< TYPE, std::false_type > \
{ \
        template <class ConstructionInfo> \
        inline input_ui(int tabs, ConstructionInfo construction_info) \
         : console_input_ui<TYPE, std::false_type>(\
                tabs, \
                construction_info, \
                DEFAULT \
        ){ } \
};

BOOST_MIRROR_EXAMPLES_SPECIALIZE_CONSOLE_INPUT_UI(double, 0.0)
BOOST_MIRROR_EXAMPLES_SPECIALIZE_CONSOLE_INPUT_UI(std::string, std::string())

/** A manager of this input user interface, which picks the
 *  constructor that will be used by the means of the result
 *  of the index member function (i.e. the zero-th registered
 *  constructor will be always used with this manager).
 */
template <class Unused>
struct input_ui<void, Unused>
{
        template <typename Context>
        input_ui(int _tabs, Context)
        { }

        void finish(int){ }

        template <class ConstructionInfo>
        inline int add_constructor(
                int tabs,
                ConstructionInfo
        ) const
        {
                return tabs + 1;
        }

        inline int index(void)
        {
                return 0;
        }
};

typedef boost::mirror::factory_maker<
        input_ui,
        boost::mirror::default_fact_suppliers,
        input_ui_enum,
        void
> input_ui_factory_maker;

typedef boost::mirror::invoker_maker<
        input_ui,
        boost::mirror::default_fact_suppliers,
        input_ui_enum,
        void
> input_ui_invoker_maker;

} // namespace test

#endif

