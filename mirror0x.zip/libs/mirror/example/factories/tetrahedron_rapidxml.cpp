/**
 *  @example boost/mirror/example/factories/tetrahedron_rapidxml.cpp
 *
 *  This example shows how to use a factory created by the factory generator
 *  with a xml parsing plugin to generically construct instances
 *  of classes with non default constructors, from input strings.
 *
 *  Copyright 2006-2010 Matus Chochlik. Distributed under the Boost
 *  Software License, Version 1.0. (See accompanying file
 *  LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
 */


#include <boost/mirror/factory.hpp>
#include <boost/mirror/meta_type.hpp>
#include <boost/mirror/utils/rapidxml_factory.hpp>
#include <iostream>

#include "./tetrahedron.hpp"

int main(void)
{
        using namespace boost::mirror;
        using namespace test;
        BOOST_MIRROR_USING_NAMESPACE(test);
        //
        // make the input object for the factory
        rapidxml_factory_input in;
        // create a factory plugged with the rapidxml parser
        rapidxml_factory_maker::factory<tetrahedron>::type f = in.data();
        //
        const char xml[] =
                "<?xml version='1.0' encoding='utf-8' ?>\n"
                "<data>\n"
                "        <t1>\n"
                "                <base>\n"
                "                        <a x='1' y='0' z='0'/>\n"
                "                        <b x='0' y='1' z='0'/>\n"
                "                        <c x='0' y='0' z='0'/>\n"
                "                </base>\n"
                "                <apex x='0' y='0' z='6'/>\n"
                "        </t1>\n"
                "        <t2>\n"
                "                <base>\n"
                "                        <a x='1' y='0' z='0'/>\n"
                "                        <b x='0' y='2' z='0'/>\n"
                "                        <c w='0'/>\n"
                "                </base>\n"
                "                <apex x='0' y='0' z='6'/>\n"
                "        </t2>\n"
                "        <t3>\n"
                "                <base>\n"
                "                        <a x='2' y='0' z='0'/>\n"
                "                        <b x='0' y='2' z='0'/>\n"
                "                        <c/>\n"
                "                </base>\n"
                "                <apex x='0' y='0' z='6'/>\n"
                "        </t3>\n"
                "        <t4>\n"
                "                <a x='2' y='0' z='0'/>\n"
                "                <b x='0' y='2' z='0'/>\n"
                "                <c/>\n"
                "                <d x='0' y='0' z='12'/>\n"
                "        </t4>\n"
                "</data>\n";

        rapidxml::xml_document<> doc;
        doc.parse<rapidxml::parse_non_destructive>((char*)xml);
        rapidxml::xml_node<>* root = doc.first_node("data");
        rapidxml::xml_node<>* src = root->first_node();
        //
        while(src != nullptr)
        {
                in.set(src);
                // use the factory to construct a tetrahedron and calculate
                // its volume and base area
                tetrahedron t(f());
                // ... and print them out
                std::cout << "the volume is " << t.volume() << " " << std::flush;
                std::cout << "the area of the base is " << t.base.area() << std::endl;
                // go to the next element
                src = src->next_sibling();
        }
        //
        return 0;
}

/* Example of output:
the volume is 1 the area of the base is 0.5
the volume is 2 the area of the base is 1
the volume is 4 the area of the base is 2
the volume is 8 the area of the base is 2
 */
