/**
 *  @example boost/mirror/example/various_02.cpp
 *  This example shows the usage of multiple utilities provided by Mirror.
 *
 *  More preciselly this example shows the usage of the reflection macros,
 *  base and full name getter functions, the scope member typedef of
 *  MetaScopedObject(s) and the meta-meta-objects
 *
 *  Copyright 2008-2010 Matus Chochlik. Distributed under the Boost
 *  Software License, Version 1.0. (See accompanying file
 *  LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
 */

#include <boost/mirror/mirror.hpp>
#include <iostream>

BOOST_MIRROR_NAMESPACE_BEGIN

template <typename MetaObject>
void print_info(void)
{
        std::cout
                << BOOST_MIRRORED_META_OBJECT(MetaObject)::base_name()
                << " "
                << MetaObject::base_name()
                << std::endl;
}

BOOST_MIRROR_NAMESPACE_END

int main(void)
{
        using namespace boost::mirror;
        //
        print_info<BOOST_MIRRORED_NAMESPACE(std)>();
        print_info<BOOST_MIRRORED_NAMESPACE(boost)>();
        print_info<BOOST_MIRRORED_NAMESPACE(boost::mirror)>();
        //
        print_info<BOOST_MIRRORED_TYPE(int)>();
        print_info<BOOST_MIRRORED_TYPE(int)::scope>();
        print_info<BOOST_MIRRORED_TYPE(std::wstring)>();
        print_info<BOOST_MIRRORED_TYPE(std::wstring)::scope>();
        //
        print_info<BOOST_MIRRORED_TEMPLATE(std::pair)>();
        print_info<BOOST_MIRRORED_TEMPLATE(std::tuple)>();
        print_info<BOOST_MIRRORED_TEMPLATE(std::tuple)::scope>();
        //
        return 0;
}

/* Example of output:
namespace std
namespace boost
namespace mirror
type int
global scope
type wstring
namespace std
template pair
template tuple
namespace std
*/
