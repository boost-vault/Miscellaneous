/**
 * @file boost/mirror/pre_registered/namespace/mirror.hpp
 * @brief Pre-registration of the ::mirror namespace with Mirror
 *
 *  Copyright 2008-2010 Matus Chochlik. Distributed under the Boost
 *  Software License, Version 1.0. (See accompanying file
 *  LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
 */

#ifndef BOOST_MIRROR_PRE_REGISTERED_NAMESPACE_MIRROR_1011291729_HPP
#define BOOST_MIRROR_PRE_REGISTERED_NAMESPACE_MIRROR_1011291729_HPP

#include <boost/mirror/meta_namespace.hpp>

BOOST_MIRROR_REG_BEGIN

// Pre register the ::mirror namespace with Mirror
BOOST_MIRROR_QREG_NESTED_NAMESPACE(boost, mirror)

BOOST_MIRROR_REG_END

#endif //include guard

