/**
 * @file boost/mirror/pre_registered/class/std/tm.hpp
 * @brief Pre-registration of the C++ tm struct with Mirror
 *
 *  Copyright 2008-2010 Matus Chochlik. Distributed under the Boost
 *  Software License, Version 1.0. (See accompanying file
 *  LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
 */

#ifndef BOOST_MIRROR_PRE_REGISTERED_CLASS_STD_TM_1012140553_HPP
#define BOOST_MIRROR_PRE_REGISTERED_CLASS_STD_TM_1012140553_HPP

#include <boost/mirror/meta_class.hpp>
#include <boost/mirror/pre_registered/namespace/std.hpp>
#include <ctime>

BOOST_MIRROR_REG_BEGIN

BOOST_MIRROR_REG_CLASS_BEGIN(struct, std, tm)
BOOST_MIRROR_REG_CLASS_MEM_VARS_BEGIN
        BOOST_MIRROR_REG_CLASS_MEM_VAR(_, _, _, tm_sec)
        BOOST_MIRROR_REG_CLASS_MEM_VAR(_, _, _, tm_min)
        BOOST_MIRROR_REG_CLASS_MEM_VAR(_, _, _, tm_hour)
        BOOST_MIRROR_REG_CLASS_MEM_VAR(_, _, _, tm_mday)
        BOOST_MIRROR_REG_CLASS_MEM_VAR(_, _, _, tm_mon)
        BOOST_MIRROR_REG_CLASS_MEM_VAR(_, _, _, tm_year)
        BOOST_MIRROR_REG_CLASS_MEM_VAR(_, _, _, tm_wday)
        BOOST_MIRROR_REG_CLASS_MEM_VAR(_, _, _, tm_yday)
        BOOST_MIRROR_REG_CLASS_MEM_VAR(_, _, _, tm_isdst)
BOOST_MIRROR_REG_CLASS_MEM_VARS_END
BOOST_MIRROR_REG_CONSTRUCTORS_BEGIN
        BOOST_MIRROR_REG_DEFAULT_CONSTRUCTOR(public)
        BOOST_MIRROR_REG_COPY_CONSTRUCTOR(public)
BOOST_MIRROR_REG_CONSTRUCTORS_END
BOOST_MIRROR_REG_CLASS_END

BOOST_MIRROR_REG_END

#endif //include guard

