/**
 * @file boost/mirror/pre_registered/class/std/string.hpp
 * @brief Pre-registration of the native C++ string classes with Mirror
 *
 *  Copyright 2008-2010 Matus Chochlik. Distributed under the Boost
 *  Software License, Version 1.0. (See accompanying file
 *  LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
 */

#ifndef BOOST_MIRROR_PRE_REGISTERED_CLASS_STD_STRING_1012140552_HPP
#define BOOST_MIRROR_PRE_REGISTERED_CLASS_STD_STRING_1012140552_HPP

#include <boost/mirror/meta_class.hpp>
#include <boost/mirror/pre_registered/namespace/std.hpp>
#include <string>

BOOST_MIRROR_REG_BEGIN

BOOST_MIRROR_REG_CLASS_BEGIN(class, std, string)
BOOST_MIRROR_REG_CONSTRUCTORS_BEGIN
        BOOST_MIRROR_REG_DEFAULT_CONSTRUCTOR(public)
        BOOST_MIRROR_REG_COPY_CONSTRUCTOR(public)

        BOOST_MIRROR_REG_CONSTRUCTOR_BEGIN(public, 0)
                BOOST_MIRROR_REG_CONSTRUCTOR_PARAM(::std::string, s)
                BOOST_MIRROR_REG_CONSTRUCTOR_PARAM(::std::size_t, pos)
                BOOST_MIRROR_REG_CONSTRUCTOR_PARAM(::std::size_t, n)
        BOOST_MIRROR_REG_CONSTRUCTOR_END(0)

        BOOST_MIRROR_REG_CONSTRUCTOR_BEGIN(public, 1)
                BOOST_MIRROR_REG_CONSTRUCTOR_PARAM(::std::size_t, n)
                BOOST_MIRROR_REG_CONSTRUCTOR_PARAM(char, c)
        BOOST_MIRROR_REG_CONSTRUCTOR_END(1)
BOOST_MIRROR_REG_CONSTRUCTORS_END
BOOST_MIRROR_REG_CLASS_END

BOOST_MIRROR_REG_CLASS_BEGIN(class, std, wstring)
BOOST_MIRROR_REG_CONSTRUCTORS_BEGIN
        BOOST_MIRROR_REG_DEFAULT_CONSTRUCTOR(public)
        BOOST_MIRROR_REG_COPY_CONSTRUCTOR(public)

        BOOST_MIRROR_REG_CONSTRUCTOR_BEGIN(public, 0)
                BOOST_MIRROR_REG_CONSTRUCTOR_PARAM(::std::wstring, s)
                BOOST_MIRROR_REG_CONSTRUCTOR_PARAM(::std::size_t, pos)
                BOOST_MIRROR_REG_CONSTRUCTOR_PARAM(::std::size_t, n)
        BOOST_MIRROR_REG_CONSTRUCTOR_END(0)

        BOOST_MIRROR_REG_CONSTRUCTOR_BEGIN(public, 1)
                BOOST_MIRROR_REG_CONSTRUCTOR_PARAM(::std::size_t, n)
                BOOST_MIRROR_REG_CONSTRUCTOR_PARAM(wchar_t, c)
        BOOST_MIRROR_REG_CONSTRUCTOR_END(1)
BOOST_MIRROR_REG_CONSTRUCTORS_END
BOOST_MIRROR_REG_CLASS_END

BOOST_MIRROR_REG_END

#endif //include guard

