/**
 * @file boost/mirror/pre_registered/class/std/set.hpp
 * @brief Pre-registration of the standard set template class with Mirror
 *
 *  Copyright 2008-2011 Matus Chochlik. Distributed under the Boost
 *  Software License, Version 1.0. (See accompanying file
 *  LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
 */

#ifndef BOOST_MIRROR_PRE_REGISTERED_CLASS_STD_SET_1102040952_HPP
#define BOOST_MIRROR_PRE_REGISTERED_CLASS_STD_SET_1102040952_HPP

#include <boost/mirror/meta_type_template.hpp>
#include <boost/mirror/meta_std_container.hpp>
#include <boost/mirror/pre_registered/namespace/std.hpp>
#include <boost/mirror/pre_registered/type/std/allocator.hpp>
#include <boost/mirror/pre_registered/type/std/functional.hpp>
#include <boost/mirror/pre_registered/type/std/initializer_list.hpp>
#include <set>

BOOST_MIRROR_REG_BEGIN

BOOST_MIRROR_REG_CLASS_TEMPLATE_BEGIN(
        (typename Element),
        struct, std, set, (Element)
)
BOOST_MIRROR_REG_CONSTRUCTORS_BEGIN
        BOOST_MIRROR_REG_DEFAULT_CONSTRUCTOR(public)
        BOOST_MIRROR_REG_COPY_CONSTRUCTOR(public)
        BOOST_MIRROR_REG_INITLIST_CONSTRUCTOR(public, Element, values)
BOOST_MIRROR_REG_CONSTRUCTORS_END
BOOST_MIRROR_REG_CLASS_END

BOOST_MIRROR_REG_STD_CONTAINER_TEMPLATE_BEGIN(
        (typename Element),
        std, set, (Element), Element
)
        BOOST_MIRROR_REG_STD_REV_CONTAINER_TRAVERSALS

        typedef boost::mirror::mp::range<
                BOOST_MIRROR_REG_STD_CONTAINER_OP(locator, begin),
                BOOST_MIRROR_REG_STD_CONTAINER_OP(locator, end),
                BOOST_MIRROR_REG_STD_CONTAINER_OP(locator, lower_bound_val),
                BOOST_MIRROR_REG_STD_CONTAINER_OP(locator, upper_bound_val)
        > locators;

        typedef boost::mirror::mp::range<
                BOOST_MIRROR_REG_STD_CONTAINER_OP(inserter, insert),
                BOOST_MIRROR_REG_STD_CONTAINER_OP(inserter, insert_pos)
        > inserters;

        typedef  boost::mirror::mp::range<
                BOOST_MIRROR_REG_STD_CONTAINER_OP(eraser, clear),
                BOOST_MIRROR_REG_STD_CONTAINER_OP(eraser, erase_pos),
                BOOST_MIRROR_REG_STD_CONTAINER_OP(eraser, erase_range),
                BOOST_MIRROR_REG_STD_CONTAINER_OP(eraser, erase_val)
        > erasers;
BOOST_MIRROR_REG_STD_CONTAINER_END

BOOST_MIRROR_REG_END

#endif //include guard

