/**
 * @file boost/mirror/pre_registered/class/std/vector.hpp
 * @brief Pre-registration of the standard vector template class with Mirror
 *
 *  Copyright 2008-2011 Matus Chochlik. Distributed under the Boost
 *  Software License, Version 1.0. (See accompanying file
 *  LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
 */

#ifndef BOOST_MIRROR_PRE_REGISTERED_CLASS_STD_VECTOR_1102040952_HPP
#define BOOST_MIRROR_PRE_REGISTERED_CLASS_STD_VECTOR_1102040952_HPP

#include <boost/mirror/meta_type_template.hpp>
#include <boost/mirror/meta_std_container.hpp>
#include <boost/mirror/pre_registered/namespace/std.hpp>
#include <boost/mirror/pre_registered/type/std/allocator.hpp>
#include <boost/mirror/pre_registered/type/std/initializer_list.hpp>
#include <vector>

BOOST_MIRROR_REG_BEGIN

BOOST_MIRROR_REG_CLASS_TEMPLATE_BEGIN(
        (typename Element),
        struct, std, vector, (Element)
)
BOOST_MIRROR_REG_CONSTRUCTORS_BEGIN
        BOOST_MIRROR_REG_DEFAULT_CONSTRUCTOR(public)
        BOOST_MIRROR_REG_COPY_CONSTRUCTOR(public)
        BOOST_MIRROR_REG_INITLIST_CONSTRUCTOR(public, Element, values)
        BOOST_MIRROR_REG_CONSTRUCTOR_BEGIN(public, 1)
                BOOST_MIRROR_REG_CONSTRUCTOR_PARAM(size_t, count)
                BOOST_MIRROR_REG_CONSTRUCTOR_PARAM(Element, value)
        BOOST_MIRROR_REG_CONSTRUCTOR_END(1)
BOOST_MIRROR_REG_CONSTRUCTORS_END
BOOST_MIRROR_REG_CLASS_END

BOOST_MIRROR_REG_STD_CONTAINER_TEMPLATE_BEGIN(
        (typename Element),
        std, vector, (Element), Element
)
        BOOST_MIRROR_REG_STD_REV_CONTAINER_TRAVERSALS

        typedef boost::mirror::mp::range<
                BOOST_MIRROR_REG_STD_CONTAINER_OP(locator, begin),
                BOOST_MIRROR_REG_STD_CONTAINER_OP(locator, end)
        > locators;

        typedef boost::mirror::mp::range<
                BOOST_MIRROR_REG_STD_CONTAINER_OP(inserter, push_back),
                BOOST_MIRROR_REG_STD_CONTAINER_OP(inserter, insert_pos),
                BOOST_MIRROR_REG_STD_CONTAINER_OP(inserter, insert_pos_multi)
        > inserters;

        typedef  boost::mirror::mp::range<
                BOOST_MIRROR_REG_STD_CONTAINER_OP(eraser, clear),
                BOOST_MIRROR_REG_STD_CONTAINER_OP(eraser, pop_back),
                BOOST_MIRROR_REG_STD_CONTAINER_OP(eraser, erase_pos),
                BOOST_MIRROR_REG_STD_CONTAINER_OP(eraser, erase_range)
        > erasers;
BOOST_MIRROR_REG_STD_CONTAINER_END

BOOST_MIRROR_REG_END

#endif //include guard

