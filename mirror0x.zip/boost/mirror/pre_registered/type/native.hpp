/**
 * @file boost/mirror/pre_registered/type/native.hpp
 * @brief Pre-registration of the native C++ types with Mirror
 *
 *  Copyright 2008-2011 Matus Chochlik. Distributed under the Boost
 *  Software License, Version 1.0. (See accompanying file
 *  LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
 */

#ifndef BOOST_MIRROR_PRE_REGISTERED_TYPE_NATIVE_1011291729_HPP
#define BOOST_MIRROR_PRE_REGISTERED_TYPE_NATIVE_1011291729_HPP

#include <boost/mirror/meta_namespace.hpp>
#include <boost/mirror/meta_class.hpp>
// pointers and references
#include <boost/mirror/pre_registered/type/_ptr_ref.hpp>
// const and volatile types
#include <boost/mirror/pre_registered/type/_const_volatile.hpp>
// array types
#include <boost/mirror/pre_registered/type/_array.hpp>
// function types
#include <boost/mirror/pre_registered/type/_free_fn.hpp>

BOOST_MIRROR_REG_BEGIN

BOOST_MIRROR_REG_GLOBAL_SCOPE_TYPE(void)

// helper macro for registering the native C++ types
// besides the basic type information is registered
// the default and copy constructors are also registered
#define BOOST_MIRROR_REG_NATIVE_TYPE_HELPER(TYPE) \
BOOST_MIRROR_REG_GLOBAL_SCOPE_TYPE(TYPE) \
namespace _class { \
template <> \
struct _< TYPE > : _defaults_native< TYPE, boost::mirror::spec_type_tag > \
{ }; \
}

BOOST_MIRROR_REG_NATIVE_TYPE_HELPER(bool)
BOOST_MIRROR_REG_NATIVE_TYPE_HELPER(char)
BOOST_MIRROR_REG_NATIVE_TYPE_HELPER(unsigned char)
BOOST_MIRROR_REG_NATIVE_TYPE_HELPER(wchar_t)
BOOST_MIRROR_REG_NATIVE_TYPE_HELPER(short int)
BOOST_MIRROR_REG_NATIVE_TYPE_HELPER(int)
BOOST_MIRROR_REG_NATIVE_TYPE_HELPER(long int)
BOOST_MIRROR_REG_NATIVE_TYPE_HELPER(unsigned short int)
BOOST_MIRROR_REG_NATIVE_TYPE_HELPER(unsigned int)
BOOST_MIRROR_REG_NATIVE_TYPE_HELPER(unsigned long int)
BOOST_MIRROR_REG_NATIVE_TYPE_HELPER(float)
BOOST_MIRROR_REG_NATIVE_TYPE_HELPER(double)
BOOST_MIRROR_REG_NATIVE_TYPE_HELPER(long double)

#undef BOOST_MIRROR_REG_NATIVE_TYPE_HELPER

BOOST_MIRROR_REG_END

#endif //include guard

