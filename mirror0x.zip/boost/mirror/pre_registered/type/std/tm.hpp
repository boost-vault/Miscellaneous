/**
 * @file boost/mirror/pre_registered/type/std/tm.hpp
 * @brief Pre-registration of the native C++ string types with Mirror
 *
 *  Copyright 2008-2010 Matus Chochlik. Distributed under the Boost
 *  Software License, Version 1.0. (See accompanying file
 *  LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
 */

#ifndef BOOST_MIRROR_PRE_REGISTERED_TYPE_STD_TM_1011291729_HPP
#define BOOST_MIRROR_PRE_REGISTERED_TYPE_STD_TM_1011291729_HPP

#include <boost/mirror/meta_type.hpp>
#include <boost/mirror/pre_registered/namespace/std.hpp>
#include <ctime>

BOOST_MIRROR_REG_BEGIN

BOOST_MIRROR_REG_TYPE_BEGIN(struct, std, tm)

BOOST_MIRROR_REG_END

#endif //include guard

