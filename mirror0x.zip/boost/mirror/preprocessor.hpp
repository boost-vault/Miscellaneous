/**
 * @file boost/mirror/preprocessor.hpp
 * @brief Various preprocessor utilities
 *
 *  Copyright 2008-2010 Matus Chochlik. Distributed under the Boost
 *  Software License, Version 1.0. (See accompanying file
 *  LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
 */

#ifndef BOOST_MIRROR_PREPROCESSOR_1011291729_HPP
#define BOOST_MIRROR_PREPROCESSOR_1011291729_HPP

#include <boost/mirror/config.hpp>

//  Macro expanding to nothing
#define BOOST_MIRROR_PP_EMPTY()

//  Macro doing the concatenation of two preprocessor tokens
#define BOOST_MIRROR_PP_CAT(A, B) BOOST_MIRROR_PP_CAT_I(A, B)
#define BOOST_MIRROR_PP_CAT_I(A, B) A ## B

// Variadic macro expanding into its arguments
#define BOOST_MIRROR_PP_EXPAND_ARGS(...) __VA_ARGS__

#endif //include guard

