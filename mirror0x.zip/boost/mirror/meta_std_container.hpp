/**
 * @file boost/mirror/meta_std_container.hpp
 * @brief Implementation of standard container registering and reflection
 *
 *
 *  Copyright 2008-2011 Matus Chochlik. Distributed under the Boost
 *  Software License, Version 1.0. (See accompanying file
 *  LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
 */

#ifndef BOOST_MIRROR_META_STD_CONTAINER_1104181551_HPP
#define BOOST_MIRROR_META_STD_CONTAINER_1104181551_HPP

#include <boost/mirror/meta_container.hpp>
#include <boost/mirror/auxiliary/std_containers.hpp>

BOOST_MIRROR_NAMESPACE_BEGIN

#ifdef BOOST_MIRROR_DOCUMENTATION_ONLY
/// This macro begins the registering of a standard container template
/**
 *  @param TEMPLATE_PARAMS the list of template parameters enclosed
 *  in parentheses. For example (typename A, typename B, typename C)
 *
 *  @param NAMESPACE the namespace where the container is defined
 *
 *  @param CONTAINER the base container class name.
 *
 *  @param PARAM_LIST the list of template parameter names enclosed
 *  in parentheses. For example (A, B, C).
 *
 *  @param ELEMENT the element type
 *
 *  @see BOOST_MIRROR_REG_STD_CONTAINER_END
 *  @ingroup registering_macros
 */
#define BOOST_MIRROR_REG_STD_CONTAINER_TEMPLATE_BEGIN( \
        TEMPLATE_PARAMS, \
        NAMESPACE, \
        CLASS, \
        PARAM_LIST, \
        ELEMENT \
)
#else
#define BOOST_MIRROR_REG_STD_CONTAINER_TEMPLATE_BEGIN( \
        TEMPLATE_PARAMS, \
        NAMESPACE, \
        CLASS, \
        PARAM_LIST, \
        ELEMENT \
) \
namespace _container { \
template < BOOST_MIRROR_PP_EXPAND_ARGS TEMPLATE_PARAMS > \
struct _< :: NAMESPACE :: CLASS < \
        BOOST_MIRROR_PP_EXPAND_ARGS PARAM_LIST \
> > \
{ \
        typedef :: NAMESPACE :: CLASS < \
                BOOST_MIRROR_PP_EXPAND_ARGS PARAM_LIST \
        > _this; \
        typedef simple_container_tag kind; \
        struct cntnr : _std_base<_this> \
        { \
                typedef ELEMENT elem_type;
#endif

#ifdef BOOST_MIRROR_DOCUMENTATION_ONLY
/// Ends the registering of a standard container
/**
 *
 *  @see BOOST_MIRROR_REG_STD_CONTAINER_TEMPLATE_BEGIN
 *  @ingroup registering_macros
 */
#define BOOST_MIRROR_REG_STD_CONTAINER_END
#else
#define BOOST_MIRROR_REG_STD_CONTAINER_END \
        }; \
        static cntnr _cntnr(std::integral_constant<int, 0>); \
        typedef std::integral_constant<int, 1> cntnr_count; \
}; \
} /* namespace _container */
#endif

#ifdef BOOST_MIRROR_DOCUMENTATION_ONLY
/// Registers the traversals of a standard forward container
/**
 *
 *  @see BOOST_MIRROR_REG_STD_CONTAINER_TEMPLATE_BEGIN
 *  @see BOOST_MIRROR_REG_STD_CONTAINER_END
 *  @see BOOST_MIRROR_REG_STD_REV_CONTAINER_TRAVERSALS
 *  @ingroup registering_macros
 */
#define BOOST_MIRROR_REG_STD_FWD_CONTAINER_TRAVERSALS
#else
#define BOOST_MIRROR_REG_STD_FWD_CONTAINER_TRAVERSALS \
        typedef boost::mirror::aux::meta_std_cntnr_trav_fwd<_this> \
                default_traversal; \
        typedef boost::mirror::mp::range< \
                boost::mirror::aux::meta_std_cntnr_trav_fwd<_this> \
        > traversals;
#endif

#ifdef BOOST_MIRROR_DOCUMENTATION_ONLY
/// Registers the traversals of a standard reversible container
/**
 *
 *  @see BOOST_MIRROR_REG_STD_CONTAINER_TEMPLATE_BEGIN
 *  @see BOOST_MIRROR_REG_STD_CONTAINER_END
 *  @see BOOST_MIRROR_REG_STD_FWD_CONTAINER_TRAVERSALS
 *  @ingroup registering_macros
 */
#define BOOST_MIRROR_REG_STD_REV_CONTAINER_TRAVERSALS
#else
#define BOOST_MIRROR_REG_STD_REV_CONTAINER_TRAVERSALS \
        typedef boost::mirror::aux::meta_std_cntnr_trav_fwd<_this> \
                default_traversal; \
        typedef boost::mirror::mp::range< \
                boost::mirror::aux::meta_std_cntnr_trav_fwd<_this>, \
                boost::mirror::aux::meta_std_cntnr_trav_bwd<_this> \
        > traversals;
#endif

#ifdef BOOST_MIRROR_DOCUMENTATION_ONLY
/// Registers a container operation (inserter, eraser, locator)
/**
 *
 *  @see BOOST_MIRROR_REG_STD_CONTAINER_TEMPLATE_BEGIN
 *  @see BOOST_MIRROR_REG_STD_CONTAINER_END
 *  @ingroup registering_macros
 */
#define BOOST_MIRROR_REG_STD_CONTAINER_OP(KIND, NAME)
#else
#define BOOST_MIRROR_REG_STD_CONTAINER_OP(KIND, NAME) \
        boost::mirror::aux::meta_std_ ## NAME ## _ ## KIND<_this>
#endif

BOOST_MIRROR_NAMESPACE_END

#endif //include guard

