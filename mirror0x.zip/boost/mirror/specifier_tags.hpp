/**
 *  @file boost/mirror/specifier_tags.hpp
 *  @brief Declaration of tags for various specifier keywords like
 *  virtual, public/protected/private, static, etc.
 *
 *
 *  Copyright 2008-2011 Matus Chochlik. Distributed under the Boost
 *  Software License, Version 1.0. (See accompanying file
 *  LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
 */

#ifndef BOOST_MIRROR_SPECIFIER_TAGS_1011291729_HPP
#define BOOST_MIRROR_SPECIFIER_TAGS_1011291729_HPP

#include <boost/mirror/preprocessor.hpp>
#include <boost/mirror/meta_prog/range.hpp>
#include <string>

BOOST_MIRROR_NAMESPACE_BEGIN

/** @defgroup specifier_tags Mirror - Specifier tags
 *
 *  Tag types designating various base-level construct specifiers
 *  like virtual, public/protected/private, static, etc.
 */

#define BOOST_MIRROR_IMPLEMENT_SPECIFIER_TAG_KEYWORD_FUNCTIONS(KEYWORD_STR) \
        static std::string keyword(void) \
        { \
                return std::string(KEYWORD_STR, sizeof(KEYWORD_STR) - 1); \
        }

/// Tag for a "non-specifier"
/** This tag is used by compile-time meta-objects that can have
 *  a specifier but do not have one. For example a member function
 *  can but does not have to be declared with a virtual, static or
 *  const specifier.
 *
 *  @ingroup specifier_tags
 */
struct spec__tag
{BOOST_MIRROR_IMPLEMENT_SPECIFIER_TAG_KEYWORD_FUNCTIONS("")};

typedef spec__tag spec_none_tag;

/// Tag indicating that the base level construct is virtual
/** This tag is used by compile-time meta-objects reflecting
 *  constructs like member functions or class inheritance and
 *  indicates that the member function is virtual or the base
 *  class in question is inherited virtually.
 *
 *  @ingroup specifier_tags
 */
struct spec_virtual_tag
{BOOST_MIRROR_IMPLEMENT_SPECIFIER_TAG_KEYWORD_FUNCTIONS("virtual")};

/// Tag indicating that the base level construct is non-virtual
/** This tag is used by compile-time meta-objects reflecting
 *  constructs like member functions or class inheritance and
 *  indicates that the member function is non-virtual or the base
 *  class in question is not inherited virtually.
 *
 *  @ingroup specifier_tags
 */
struct spec_non_virtual_tag : spec__tag { };

/// Tag indicating that the base level construct has static storage class
/** This tag is used by compile-time meta-objects reflecting
 *  constructs like class member variables or functions and
 *  indicates that the construct has static storage class.
 *
 *  @ingroup specifier_tags
 */
struct spec_static_tag
{BOOST_MIRROR_IMPLEMENT_SPECIFIER_TAG_KEYWORD_FUNCTIONS("static")};

/// Tag indicating that the base level construct has mutable storage class
/** This tag is used by compile-time meta-objects reflecting
 *  constructs like class member variables or functions and
 *  indicates that the construct has mutable storage class.
 *
 *  @ingroup specifier_tags
 */
struct spec_mutable_tag
{BOOST_MIRROR_IMPLEMENT_SPECIFIER_TAG_KEYWORD_FUNCTIONS("mutable")};

/// Tag indicating that the base level construct has automatic storage class
/** This tag is used by compile-time meta-objects reflecting
 *  constructs like class member variables or functions and
 *  indicates that the construct has automatic storage class.
 *
 *  @ingroup specifier_tags
 */
struct spec_auto_tag : spec__tag { };

/// Tag indicating that the base level construct has extern storage class
/** This tag is used by compile-time meta-objects reflecting
 *  constructs like global variables, etc. and indicates that
 *  the construct has extern storage class.
 *
 *  @ingroup specifier_tags
 */
struct spec_extern_tag
{BOOST_MIRROR_IMPLEMENT_SPECIFIER_TAG_KEYWORD_FUNCTIONS("extern")};

/// Tag indicating that the base level construct has register storage class
/** This tag is used by compile-time meta-objects reflecting
 *  constructs like global variables, etc. and indicates that
 *  the construct has register storage class.
 *
 *  @ingroup specifier_tags
 */
struct spec_register_tag
{BOOST_MIRROR_IMPLEMENT_SPECIFIER_TAG_KEYWORD_FUNCTIONS("register")};

/// Tag indicating that the base level construct has thread_local storage class
/** This tag is used by compile-time meta-objects reflecting
 *  constructs like global variables, members, etc. and indicates that
 *  the construct has thread_local storage class.
 *
 *  @ingroup specifier_tags
 */
struct spec_thread_local_tag
{BOOST_MIRROR_IMPLEMENT_SPECIFIER_TAG_KEYWORD_FUNCTIONS("thread_local")};

/// Tag indicating that the base level construct is const
/** This tag is used by compile-time meta-objects reflecting
 *  constructs like class' member functions and indicates that
 *  the function is declared as const.
 *
 *  @ingroup specifier_tags
 */
struct spec_const_tag
{BOOST_MIRROR_IMPLEMENT_SPECIFIER_TAG_KEYWORD_FUNCTIONS("const")};

/// Tag indicating that the base level construct is not const
/** This tag is used by compile-time meta-objects reflecting
 *  constructs like class' member functions and indicates that
 *  the function is declared as non-const.
 *
 *  @ingroup specifier_tags
 */
struct spec_non_const_tag : spec__tag { };

/// Tag indicating that the base level construct has private access
/** This tag is used by compile-time meta-objects reflecting
 *  constructs like class' members or base classes and indicates that
 *  the member or base class has private access specifier.
 *
 *  @ingroup specifier_tags
 */
struct spec_private_tag
{BOOST_MIRROR_IMPLEMENT_SPECIFIER_TAG_KEYWORD_FUNCTIONS("private")};

/// Tag indicating that the base level construct has protected access
/** This tag is used by compile-time meta-objects reflecting
 *  constructs like class' members or base classes and indicates that
 *  the member or base class has protected access specifier.
 *
 *  @ingroup specifier_tags
 */
struct spec_protected_tag
{BOOST_MIRROR_IMPLEMENT_SPECIFIER_TAG_KEYWORD_FUNCTIONS("protected")};

/// Tag indicating that the base level construct has public access
/** This tag is used by compile-time meta-objects reflecting
 *  constructs like class' members or base classes and indicates that
 *  the member or base class has public access specifier.
 *
 *  @ingroup specifier_tags
 */
struct spec_public_tag
{BOOST_MIRROR_IMPLEMENT_SPECIFIER_TAG_KEYWORD_FUNCTIONS("public")};

/// Tag indicating that the reflected elaborated type is declared as 'struct'
/** This tag is used by meta_classes to indicate the reflected class
 *  has been defined (and registered) as 'struct'
 *
 *  @ingroup specifier_tags
 */
struct spec_struct_tag
{BOOST_MIRROR_IMPLEMENT_SPECIFIER_TAG_KEYWORD_FUNCTIONS("struct")};

/// Tag indicating that the reflected elaborated type is declared as 'class'
/** This tag is used by meta_classes to indicate the reflected type
 *  has been defined (and registered) as 'class' (as opposed to 'struct'
 *  or 'union').
 *
 *  @ingroup specifier_tags
 */
struct spec_class_tag
{BOOST_MIRROR_IMPLEMENT_SPECIFIER_TAG_KEYWORD_FUNCTIONS("class")};

/// Tag indicating that the reflected elaborated type is declared as 'union'
/** This tag is used by meta_classes to indicate the reflected type
 *  has been defined (and registered) as 'union'
 *
 *  @ingroup specifier_tags
 */
struct spec_union_tag
{BOOST_MIRROR_IMPLEMENT_SPECIFIER_TAG_KEYWORD_FUNCTIONS("union")};

/// Tag indicating that the reflected elaborated type is declared as 'enum'
/** This tag is used by meta_classes to indicate the reflected type
 *  has been defined (and registered) as 'enum'
 *
 *  @ingroup specifier_tags
 */
struct spec_enum_tag
{BOOST_MIRROR_IMPLEMENT_SPECIFIER_TAG_KEYWORD_FUNCTIONS("enum")};

/// Tag indicating that the reflected type is a non-elaborated type
/** This tag is used by meta_classes to indicate the reflected type
 *  has been defined (and registered) as non-elaborated type.
 *  This specifier is reserved for the intrinsic C++ types and should
 *  NOT be used in client code.
 *
 *  @ingroup specifier_tags
 */
struct spec_type_tag : spec__tag { };

/// Special specifier tag for selecting the default specifier in a context
/** This specifier tag is used as a convenience for selecting the default
 *  specifier for the particular context in which it is used.
 *  For example if this specifier is used to specify the inheritance type
 *  then the non-virtual inheritance is selected, if it is used to specify
 *  the default 'staticity' or 'constness' of a class member function
 *  then in the first case non-static tag and in the second cast the
 *  non-const tag is selected.
 *
 *  Do not use this tag directly, it is used by some of the registering
 *  macros in an appropriate way.
 *
 *  @ingroup specifier_tags
 */
struct spec___tag { };

// undefine the helper macros
#undef BOOST_MIRROR_IMPLEMENT_SPECIFIER_TAG_KEYWORD_FUNCTIONS

#define BOOST_MIRROR_FOR_EACH_SPECIFIER(MACRO, DATA) \
        MACRO(virtual, DATA) \
        MACRO(static, DATA) \
        MACRO(mutable, DATA) \
        MACRO(extern, DATA) \
        MACRO(register, DATA) \
        MACRO(thread_local, DATA) \
        MACRO(const, DATA) \
        MACRO(private, DATA) \
        MACRO(protected, DATA) \
        MACRO(public, DATA) \
        MACRO(struct, DATA) \
        MACRO(class, DATA) \
        MACRO(union, DATA) \
        MACRO(enum, DATA)

#ifdef BOOST_MIRROR_DOCUMENTATION_ONLY
/// Meta-function template returning the ElaboratedTypeTag for a type
/** This template can be used to determine how the type passed as
 *  template argument has been registered (as plain type, as enum,
 *  as class, etc.)
 */
template <typename T>
struct type_category
{
        typedef ElaboratedTypeTag type;
};

/// Function returning the ElaboratedTypeTag for the type of its argument
template <typename T>
ElaboratedTypeTag categorize_type(const T&);
#endif

/// Returns a range of all inheritance type specifier tags
/**
 *  @see InheritanceTypeTag
 *
 *  @ingroup specifier_tags
 */
struct inheritance_type_tags
{
#ifdef BOOST_MIRROR_DOCUMENTATION_ONLY
        typedef Range<InheritanceTypeTag> type;
#else
        typedef mp::range<
                spec__tag,
                spec_virtual_tag
        > type;
#endif
};

/// Returns a range of all storage class specifier tags
/**
 *  @see StorageClassTag
 *
 *  @ingroup specifier_tags
 */
struct storage_class_tags
{
#ifdef BOOST_MIRROR_DOCUMENTATION_ONLY
        typedef Range<StorageClassTag> type;
#else
        typedef mp::range<
                spec_auto_tag,
                spec_extern_tag,
                spec_static_tag,
                spec_mutable_tag,
                spec_register_tag,
                spec_thread_local_tag
        > type;
#endif
};

/// Returns a range of all constness specifier tags
/**
 *  @see ConstnessTag
 *
 *  @ingroup specifier_tags
 */
struct constness_tags
{
#ifdef BOOST_MIRROR_DOCUMENTATION_ONLY
        typedef Range<ConstnessTag> type;
#else
        typedef mp::range<
                spec_non_const_tag,
                spec_const_tag
        > type;
#endif
};

/// Returns a range of all access type specifier tags
/**
 *  @see AccessTypeTag
 *
 *  @ingroup specifier_tags
 */
struct access_type_tags
{
#ifdef BOOST_MIRROR_DOCUMENTATION_ONLY
        typedef Range<AccessTypeTag> type;
#else
        typedef mp::range<
                spec_private_tag,
                spec_protected_tag,
                spec_public_tag
        > type;
#endif
};


/// Returns a range of all elaborated type specifier tags
/**
 *  @see ElaboratedTypeTag
 *
 *  @ingroup specifier_tags
 */
struct elaborated_type_tags
{
#ifdef BOOST_MIRROR_DOCUMENTATION_ONLY
        typedef Range<ElaboratedTypeTag> type;
#else
        typedef mp::range<
                spec_type_tag,
                spec_class_tag,
                spec_struct_tag,
                spec_union_tag,
                spec_enum_tag
        > type;
#endif
};

BOOST_MIRROR_NAMESPACE_END

#endif //include guard

