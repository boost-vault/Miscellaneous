/**
 * @file boost/mirror/tag_dispatch.hpp
 * @brief Declaration of trait/tag types for tag dispatching for
 * Mirror's meta-objects.
 *
 *  Copyright 2008-2010 Matus Chochlik. Distributed under the Boost
 *  Software License, Version 1.0. (See accompanying file
 *  LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
 */

#ifndef BOOST_MIRROR_TAG_DISPATCH_1011291729_HPP
#define BOOST_MIRROR_TAG_DISPATCH_1011291729_HPP

#include <boost/mirror/config.hpp>
#include <type_traits>

BOOST_MIRROR_NAMESPACE_BEGIN

/** @defgroup meta_object_categories Mirror - Categorization and Tag dispatching
 *
 *  Tag types and categorization template meta-functions for tag dispatching.
 *  These tags,  the categorization functions and template meta-functions
 *  can be used for creating different function overloads and template
 *  specializations for different meta-object categories and for the
 *  dispatching of the proper overload and/or template specialization for
 *  a particular meta-object type, based on its capabilities.
 */


/// Tag used for recognizing types which are not Mirror meta-objects
/** This tag or tag derived from this tag is returned by the
 *  meta_object_category meta-function for types which are not
 *  Mirror's meta-object classes.
 *
 *  @see meta_object_category
 *  @see categorize_meta_object
 *  @ingroup meta_object_categories
 */
struct non_meta_object_tag
{ };

/// Tag for types which conform to the Mirror's MetaObject concept
/**
 *  @see meta_object_category
 *  @see categorize_meta_object
 *  @see MetaObject
 *  @ingroup meta_object_categories
 */
struct meta_object_tag
{ };

/// Tag for types conforming to the Mirror's MetaNamedObject concept
/**
 *  @see meta_object_category
 *  @see categorize_meta_object
 *  @see MetaNamedObject
 *  @ingroup meta_object_categories
 */
struct meta_named_object_tag
 : virtual public meta_object_tag
{ };

/// Tag for types conforming to the Mirror's MetaMetaObject concept
/**
 *  @see meta_object_category
 *  @see categorize_meta_object
 *  @see MetaMetaObject
 *  @ingroup meta_object_categories
 */
struct meta_meta_object_tag
 : virtual public meta_named_object_tag
{ };

/// Tag for types conforming to the Mirror's MetaScopedObject concept
/**
 *  @see meta_object_category
 *  @see categorize_meta_object
 *  @see MetaScopedObject
 *  @ingroup meta_object_categories
 */
struct meta_scoped_object_tag
 : virtual public meta_object_tag
{ };

/// Tag for types conforming to the Mirror's MetaNamedScopedObject concept
/**
 *  @see meta_object_category
 *  @see categorize_meta_object
 *  @see MetaNamedScopedObject
 *  @ingroup meta_object_categories
 */
struct meta_named_scoped_object_tag
 : virtual public meta_named_object_tag
 , virtual public meta_scoped_object_tag
{ };

/// Tag for types conforming to the Mirror's MetaScope concept
/**
 *  @see meta_object_category
 *  @see categorize_meta_object
 *  @see MetaScope
 *  @ingroup meta_object_categories
 */
struct meta_scope_tag
 : virtual public meta_named_scoped_object_tag
{ };

/// Tag for types conforming to the MetaScope concept for an unspecified scope
/**
 *  @see meta_object_category
 *  @see categorize_meta_object
 *  @see MetaScope
 *  @ingroup meta_object_categories
 */
struct meta_unspecified_scope_tag
 : virtual public meta_scope_tag
{ };

/// Tag for types conforming to the Mirror's MetaNamespace concept
/**
 *  @see meta_object_category
 *  @see categorize_meta_object
 *  @see MetaNamespace
 *  @ingroup meta_object_categories
 */
struct meta_namespace_tag
 : virtual public meta_scope_tag
{ };

/// Tag for types conforming to the MetaNamespace concept for the global scope
/**
 *  @see meta_object_category
 *  @see categorize_meta_object
 *  @see MetaNamespace
 *  @ingroup meta_object_categories
 */
struct meta_global_scope_tag
 : virtual public meta_namespace_tag
{ };

/// Tag for types conforming to the Mirror's MetaType concept
/**
 *  @see meta_object_category
 *  @see categorize_meta_object
 *  @see MetaType
 *  @ingroup meta_object_categories
 */
struct meta_type_tag
 : virtual public meta_named_scoped_object_tag
{ };

/// Tag for types conforming to the Mirror's MetaTemplatedType concept
/**
 *  @see meta_object_category
 *  @see categorize_meta_object
 *  @see MetaTemplatedType
 *  @ingroup meta_object_categories
 */
struct meta_templated_type_tag
 : virtual public meta_type_tag
{ };

/// Tag for types conforming to the Mirror's MetaTypeTemplate concept
/**
 *  @see meta_object_category
 *  @see categorize_meta_object
 *  @see MetaTypeTemplate
 *  @ingroup meta_object_categories
 */
struct meta_type_template_tag
 : virtual public meta_named_scoped_object_tag
{ };

/// Tag for types conforming to the Mirror's MetaTypedef concept
/**
 *  @see meta_object_category
 *  @see categorize_meta_object
 *  @see MetaTypedef
 *  @ingroup meta_object_categories
 */
struct meta_typedef_tag
 : virtual public meta_type_tag
{ };

/// Tag for types conforming to the Mirror's MetaClass concept
/**
 *  @see meta_object_category
 *  @see categorize_meta_object
 *  @see MetaClass
 *  @ingroup meta_object_categories
 */
struct meta_class_tag
 : virtual public meta_type_tag
 , virtual public meta_scope_tag
{ };

/// Tag for types conforming to the Mirror's MetaClassOrEnumMember concept
/**
 *  @see meta_object_category
 *  @see categorize_meta_object
 *  @see MetaClassOrEnumMember
 *  @ingroup meta_object_categories
 */
struct meta_class_or_enum_member_tag
 : virtual public meta_named_scoped_object_tag
{ };

/// Tag for types conforming to the Mirror's MetaClassMember concept
/**
 *  @see meta_object_category
 *  @see categorize_meta_object
 *  @see MetaClassMember
 *  @ingroup meta_object_categories
 */
struct meta_class_member_tag
 : virtual public meta_class_or_enum_member_tag
{ };

/// Tag for types conforming to the Mirror's MetaTemplatedClass concept
/**
 *  @see meta_object_category
 *  @see categorize_meta_object
 *  @see MetaTemplatedClass
 *  @ingroup meta_object_categories
 */
struct meta_templated_class_tag
 : virtual public meta_templated_type_tag
 , virtual public meta_class_tag
{ };

/// Tag for types conforming to the Mirror's MetaEnum concept
/**
 *  @see meta_object_category
 *  @see categorize_meta_object
 *  @see MetaEnum,
 *  @ingroup meta_object_categories
 */
struct meta_enum_tag
 : virtual public meta_type_tag
 , virtual public meta_scope_tag
{ };

/// Tag for types conforming to the Mirror's MetaEnumValue concept
/**
 *  @see meta_object_category
 *  @see categorize_meta_object
 *  @see MetaEnumValue,
 *  @ingroup meta_object_categories
 */
struct meta_enum_value_tag
 : virtual public meta_named_scoped_object_tag
{ };

/// Tag for types conforming to the Mirror's MetaInheritance concept
/**
 *  @see meta_object_category
 *  @see categorize_meta_object
 *  @see MetaInheritance
 *  @ingroup meta_object_categories
 */
struct meta_inheritance_tag
 : virtual public meta_object_tag
{ };

/// Tag for types conforming to the Mirror's MetaVariable concept
/**
 *  @see meta_object_category
 *  @see categorize_meta_object
 *  @see MetaVariable
 *  @ingroup meta_object_categories
 */
struct meta_variable_tag
 : virtual public meta_named_scoped_object_tag
{ };

/// Tag for types conforming to the Mirror's MetaFreeVariable concept
/**
 *  @see meta_object_category
 *  @see categorize_meta_object
 *  @see MetaFreeVariable
 *  @ingroup meta_object_categories
 */
struct meta_free_variable_tag
 : virtual public meta_variable_tag
{ };

/// Tag for types conforming to the Mirror's MetaPlainFreeVariable concept
/**
 *  @see meta_object_category
 *  @see categorize_meta_object
 *  @see MetaPlainFreeVariable
 *  @ingroup meta_object_categories
 */
struct meta_plain_free_variable_tag
 : virtual public meta_free_variable_tag
{ };

/// Tag for types conforming to the Mirror's MetaMemberVariable concept
/**
 *  @see meta_object_category
 *  @see categorize_meta_object
 *  @see MetaMemberVariable
 *  @ingroup meta_object_categories
 */
struct meta_member_variable_tag
 : virtual public meta_variable_tag
 , virtual public meta_class_member_tag
{ };

/// Tag for types conforming to the Mirror's MetaPlainMemberVariable concept
/**
 *  @see meta_object_category
 *  @see categorize_meta_object
 *  @see MetaPlainMemberVariable
 *  @ingroup meta_object_categories
 */
struct meta_plain_member_variable_tag
 : virtual public meta_member_variable_tag
{ };

/// Tag for types conforming to the Mirror's MetaParameter concept
/**
 *  @see meta_object_category
 *  @see categorize_meta_object
 *  @see MetaParameter
 *  @ingroup meta_object_categories
 */
struct meta_parameter_tag
 : virtual public meta_variable_tag
{ };

/// Tag for types conforming to the Mirror's MetaFunction concept
/**
 *  @see meta_object_category
 *  @see categorize_meta_object
 *  @see MetaFunction
 *  @ingroup meta_object_categories
 */
struct meta_function_tag
 : virtual public meta_scope_tag
{ };

/// Tag for types conforming to the Mirror's MetaMemberFunction concept
/**
 *  @see meta_object_category
 *  @see categorize_meta_object
 *  @see MetaMemberFunction
 *  @ingroup meta_object_categories
 */
struct meta_member_function_tag
 : virtual public meta_function_tag
 , virtual public meta_class_member_tag
{ };

/// Tag for types conforming to the Mirror's MetaConstructor concept
/**
 *  @see meta_object_category
 *  @see categorize_meta_object
 *  @see MetaConstructor
 *  @ingroup meta_object_categories
 */
struct meta_constructor_tag
 : virtual public meta_function_tag
 , virtual public meta_class_member_tag
{ };

/// Tag for types conforming to the Mirror's MetaConversionOperator concept
/**
 *  @see meta_object_category
 *  @see categorize_meta_object
 *  @see MetaConversionOperator
 *  @ingroup meta_object_categories
 */
struct meta_conversion_operator_tag
 : virtual public meta_member_function_tag
{ };

/// Tag for types conforming to the Mirror's MetaLocator concept
/**
 *  @see meta_object_category
 *  @see categorize_meta_object
 *  @see MetaLocator
 *  @ingroup meta_object_categories
 */
struct meta_locator_tag
 : virtual public meta_named_object_tag
{ };

/// Tag for types conforming to the Mirror's MetaTraversal concept
/**
 *  @see meta_object_category
 *  @see categorize_meta_object
 *  @see MetaTraversal
 *  @ingroup meta_object_categories
 */
struct meta_traversal_tag
 : virtual public meta_named_object_tag
{ };

/// Tag for types conforming to the Mirror's MetaInserter concept
/**
 *  @see meta_object_category
 *  @see categorize_meta_object
 *  @see MetaInserter
 *  @ingroup meta_object_categories
 */
struct meta_inserter_tag
 : virtual public meta_named_object_tag
{ };

/// Tag for types conforming to the Mirror's MetaEraser concept
/**
 *  @see meta_object_category
 *  @see categorize_meta_object
 *  @see MetaEraser
 *  @ingroup meta_object_categories
 */
struct meta_eraser_tag
 : virtual public meta_named_object_tag
{ };

/// Tag for types conforming to the Mirror's MetaContainer concept
/**
 *  @see meta_object_category
 *  @see categorize_meta_object
 *  @see MetaContainer
 *  @ingroup meta_object_categories
 */
struct meta_container_tag
 : virtual public meta_scoped_object_tag
{ };


namespace aux {

template <class T, class Bool>
struct meta_obj_cat;

template <class T>
struct meta_obj_cat<T, std::true_type>
{
        typedef typename T::category type;
};

template <class T>
struct meta_obj_cat<T, std::false_type>
{
        typedef non_meta_object_tag type;
};

template <typename T>
std::true_type meta_obj_has_cat(T*, typename T::category* = nullptr);

std::false_type meta_obj_has_cat(...);

} // namespace aux

/// Template meta-function for getting the category tag of a type
/** This template meta-function can be used to get the exact
 *  category tag for a (meta-object) type.
 *
 *  @tparam T the type to be examined for Mirror category tag
 *  @see categorize_meta_object
 *  @see meta_object_kind
 *  @see non_meta_object_tag
 *  @see meta_object_tag
 *  @see meta_named_object_tag
 *  @see meta_scoped_object_tag
 *  @see meta_named_scoped_object_tag
 *  @see meta_scope_tag
 *  @see meta_namespace_tag
 *  @see meta_global_scope_tag
 *  @see meta_type_tag
 *  @see meta_class_tag
 *  @ingroup meta_object_categories
 */
template <class T>
struct meta_object_category
#ifndef BOOST_MIRROR_DOCUMENTATION_ONLY
 : aux::meta_obj_cat<
        T,
        decltype(aux::meta_obj_has_cat((T*)nullptr))
>
#endif
{
#ifdef BOOST_MIRROR_DOCUMENTATION_ONLY
        /// The category tag for the type passed as template argument
        typedef CategoryTag type;
#endif
};

namespace aux {

template <typename ... Categories>
struct meta_obj_kind_hlpr;

template <>
struct meta_obj_kind_hlpr <>
{
        template <typename Category>
        static Category _get(Category);
};

template <typename Category, typename ... Categories>
struct meta_obj_kind_hlpr<Category, Categories...>
 : meta_obj_kind_hlpr<Categories...>
{
        static Category _get(Category);
};

} // namespace aux

/// Template meta-function for getting a category tag of a type
/** This template meta-function can be used to get the possibly up-cast
 *  category tag for a (meta-object) type. The difference between this template
 *  and meta_object_category is, that meta_object_category returns the exact
 *  meta-object-tag type for a particular meta-object. Sometimes it is however
 *  desirable to upcast the tag to a more general meta-object-tag.
 *
 *  This template allows to specify a set of meta-object-tags to one of which
 *  the real meta-object tag is up-cast if possible. This is useful for example
 *  if there is a template overload for MetaType but we also want it to handle
 *  MetaClass, MetaTemplatedType, or other derived meta-objects.
 *
 *  @tparam T the type to be examined for Mirror category tag
 *  @tparam CategoryTags the pack of category tags to up-cast to if the real
 *   category tag is derived from one of those listed in this pack.
 *
 *  @see categorize_meta_object
 *  @see meta_object_category
 *  @ingroup meta_object_categories
 */
template <class T, class ... CategoryTags>
struct meta_object_kind
#ifndef BOOST_MIRROR_DOCUMENTATION_ONLY
 : virtual aux::meta_obj_kind_hlpr<CategoryTags...>
#endif
{
        static meta_object_kind* that(void);
#ifdef BOOST_MIRROR_DOCUMENTATION_ONLY
        typedef CategoryTag type;
#else
        typedef decltype(_get(
                typename boost::mirror::meta_object_category<
                        T
                >::type()
        )) type;
#endif
};

/// This function returns the meta-object category tag for an instance
/**
 *  @tparam T the type to be categorized
 *  @param inst the instance type of which is to be categorized
 *  @see meta_object_category
 *  @ingroup meta_object_categories
 */
template <class T>
typename meta_object_category<T>::type
categorize_meta_object(const T& inst)
{
        return typename meta_object_category<T>::type();
}

#define BOOST_MIRROR_FOR_EACH_META_OBJECT(MACRO, DATA) \
        MACRO(object, DATA) \
        MACRO(named_object, DATA) \
        MACRO(scoped_object, DATA) \
        MACRO(named_scoped_object, DATA) \
        MACRO(scope, DATA) \
        MACRO(unspecified_scope, DATA) \
        MACRO(namespace, DATA) \
        MACRO(global_scope, DATA) \
        MACRO(type, DATA) \
        MACRO(templated_type, DATA) \
        MACRO(type_template, DATA) \
        MACRO(typedef, DATA) \
        MACRO(class, DATA) \
        MACRO(class_or_enum_member, DATA) \
        MACRO(class_member, DATA) \
        MACRO(templated_class, DATA) \
        MACRO(enum, DATA) \
        MACRO(enum_value, DATA) \
        MACRO(inheritance, DATA) \
        MACRO(variable, DATA) \
        MACRO(free_variable, DATA) \
        MACRO(plain_free_variable, DATA) \
        MACRO(member_variable, DATA) \
        MACRO(plain_member_variable, DATA) \
        MACRO(parameter, DATA) \
        MACRO(function, DATA) \
        MACRO(member_function, DATA) \
        MACRO(constructor, DATA) \
        MACRO(conversion_operator, DATA) \
        MACRO(traversal, DATA) \
        MACRO(locator, DATA) \
        MACRO(inserter, DATA) \
        MACRO(eraser, DATA) \
        MACRO(container, DATA)


BOOST_MIRROR_NAMESPACE_END

#endif //include guard

