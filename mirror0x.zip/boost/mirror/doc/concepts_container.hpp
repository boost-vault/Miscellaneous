/**
 * @file boost/mirror/doc/concepts.hpp
 * @brief Classes modelling the container-related concepts defined by Mirror
 *
 *  Copyright 2008-2011 Matus Chochlik. Distributed under the Boost
 *  Software License, Version 1.0. (See accompanying file
 *  LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
 */

#ifndef BOOST_MIRROR_DOC_CONCEPTS_1011291729_HPP
#define BOOST_MIRROR_DOC_CONCEPTS_1011291729_HPP

#include <boost/mirror/config.hpp>
#include <boost/mirror/doc/concepts.hpp>

// This section is here for documentation purposes only
#ifdef BOOST_MIRROR_DOCUMENTATION_ONLY

/** @defgroup meta_container_concepts Mirror - Meta-container concepts
 *
 *  Mirror defines the following concepts for meta-objects providing meta-data
 *  about containers, container element traversals, inserters and erasers.
 */

BOOST_MIRROR_NAMESPACE_BEGIN

/// Locator allows to get and possibly set the value of a container's element
/** Locator is not a meta-object, it is an abstraction for types which allow
 *  to access elements in a range or container, like pointers, iterators, etc.
 *  but are restricted to point to a particular element and cannot be made
 *  to point to another element.
 *  Locators also indicate positions inside containers for modifying operations
 *  like element insertion and removal. A particular Locator can only be used
 *  with the same instance of a container type which was used to instantiate
 *  the Locator in the first place.
 *
 *  Some Locators may also refer to special parts of the container (like end())
 *  and do not point to an element. For such locators it is necessary to check
 *  the value of @c dereferencable() before trying to get or set the value
 *  pointed to.
 *  Other locators, for example those returned by Traversal's front() member
 *  function, always point to an element and it is not necessary to check
 *  their dereferencability.
 *
 *  @see SafeLocator
 *  @see MetaLocator
 */
struct Locator
{
        /// Indicating whether this is a safe locator type
        typedef BooleanConstantType safe;

        /// The type of the element pointed to by this Locator
        typedef unspecified value_type;

        /// Returns true if the locator is dereferencable
        bool dereferencable(void) const;

        /// Shorthand for dereferencable()
        operator bool (void) const;

        /// Shorthand for !dereferencable()
        bool operator !(void) const;

        /// Allows to get the value of the element pointed to by the Locator
        value_type get(void) const;

        /// Sets the value of the element pointed to by the Locator
        void set(value_type value) const;
};

/// SafeLocator is a Locator that is always dereferencable
/** When handling SafeLocators it is not necessary to check if they
 *  are dereferencable before calling get and set.
 *
 *  @see Locator
 *  @see Traversal
 */
struct SafeLocator
 : public Locator
{
};

/// Traversal allows to traverse elements of containers in an uniform way
/** Traversal is not a meta-object, it is rather an abstraction for types
 *  wrapping various methods of container element traversal. Instances of these
 *  types are created by the MetaTraversal meta-object and allow the users
 *  to iterate through the elements of an arbitrary container in a generic
 *  way.
 *
 *  @see MetaTraversal
 *  @ingroup meta_container_concepts
 */
struct Traversal
{
        /// Indicates that the element traversal is finished
        /** When this member function returns true, then the step_front
         *  and the front member functions must not be called.
         *
         *  @see empty
         */
        bool done(void) const;

        /// Synonym for done
        bool empty(void) const;

        /// Returns a locator for the current element in the traversal
        /** This function should not be called if done() returns true.
         *
         *  @see done
         */
        SafeLocator front(void) const;

        /// Moves the front of the range one step ahead, to the next element
        /** This function should not be called if done() returns true.
         *
         *  @see done
         */
        void step_front(void);
};

/// Tag type specifying the kind of container
/**
 *  @see non_container_tag
 *  @see container_tag
 *  @see simple_container_tag
 *  @see single_value_container_tag
 *  @see optional_container_tag
 *  @see variant_container_tag
 *  @see complex_container_tag
 *
 *  @ingroup meta_container_concepts
 */
struct ContainerKindTag;

/// MetaLocator provides meta-data about a location in a container
/**
 *  @see meta_locator_tag
 *  @see meta_object_category
 *  @see categorize_meta_object
 *  @ingroup meta_container_concepts
 */
struct MetaLocator
 : virtual public MetaNamedObject
{
        /// The container that this traversal belongs to
        typedef MetaContainer container;

        /// Signature specifying the kinds of additional parameters for go_to
        /**
         *  @see container_op_count_param
         *  @see container_op_value_param
         *  @see go_to
         */
        typedef Range<unspecified> signature;

        /// The type of the Locator returned by go_to
        /**
         *  @see signature
         */
        typedef Locator locator_type;

        /// Gets a locator for the location reflected by this MetaLocator
        static locator_type go_to(Container container, ...);

        /** @see meta_object_category
         *  @see categorize_meta_object(const T&)
         */
        friend meta_locator_tag
        categorize_meta_object(MetaLocator);
};

/// MetaTraversal provides meta-data about a container traversal
/**
 *  @see meta_traversal_tag
 *  @see meta_object_category
 *  @see categorize_meta_object
 *  @ingroup meta_container_concepts
 */
struct MetaTraversal
 : virtual public MetaNamedObject
{
        /// The container that this traversal belongs to
        typedef MetaContainer container;

        /// Signature specifying the kinds of additional parameters for start
        /**
         *  @see container_op_location_param
         *  @see container_op_end_location_param
         *  @see container_op_count_param
         *  @see container_op_value_param
         *  @see start
         */
        typedef Range<unspecified> signature;

        /// The type of the Traversal returned by start
        typedef Traversal traversal_type;

        /// Starts a traversal of the container passed as argument
        /**
         *  @see signature
         */
        static traversal_type start(Container container, ...);

        /** @see meta_object_category
         *  @see categorize_meta_object(const T&)
         */
        friend meta_traversal_tag
        categorize_meta_object(MetaTraversal);
};

/// MetaInserter provides meta-data about a container element insertion method
/**
 *  @see meta_inserter_tag
 *  @see meta_object_category
 *  @see categorize_meta_object
 *  @ingroup meta_container_concepts
 */
struct MetaInserter
 : virtual public MetaNamedObject
{
        /// The container that this inserter operates on
        typedef MetaContainer container;

        /// Signature specifying the kinds of additional parameters for insert
        /**
         *  @see container_op_location_param
         *  @see container_op_count_param
         *  @see container_op_value_param
         *  @see insert
         */
        typedef Range<unspecified> signature;

        /// Inserts one or several values into a container
        /**
         *  @see signature
         */
        static void insert(Container& container, ...);

        /** @see meta_object_category
         *  @see categorize_meta_object(const T&)
         */
        friend meta_inserter_tag
        categorize_meta_object(MetaInserter);
};

/// MetaEraser provides meta-data about a container element removal method
/**
 *  @see meta_eraser_tag
 *  @see meta_object_category
 *  @see categorize_meta_object
 *  @ingroup meta_container_concepts
 */
struct MetaEraser
 : virtual public MetaNamedObject
{
        /// The container that this eraser operates on
        typedef MetaContainer container;

        /// Signature specifying the kinds of additional parameters for insert
        /**
         *  @see container_op_location_param
         *  @see container_op_end_location_param
         *  @see container_op_count_param
         *  @see container_op_value_param
         *  @see erase
         */
        typedef Range<unspecified> signature;


        /// Removes one or several values from a container
        /**
         *  @see signature
         */
        static void erase(Container& container, ...);

        /** @see meta_object_category
         *  @see categorize_meta_object(const T&)
         */
        friend meta_eraser_tag
        categorize_meta_object(MetaEraser);
};

/// MetaContainer provides meta-data about a container
/**
 *  @see meta_container_tag
 *  @see meta_object_category
 *  @see categorize_meta_object
 *  @ingroup meta_container_concepts
 */
struct MetaContainer
 : virtual public MetaScopedObject
{
        /// MetaClass reflecting the class that this container belongs to
        typedef MetaClass scope;

        /// Checks if the container is empty
        static bool empty(Container& container);

        /// Returns the number of elements in the container if possible
        /** This member function returns the number of elements in the container
         *  if this information is available for this Container type.
         *  If the info is not available this function returns zero.
         */
        static size_t size_hint(Container& container);

        /// MetaType reflecting the type of the elements stored in the container
        typedef MetaType element_type;

        /// The default element traversal method for the reflected container
        typedef MetaTraversal default_traversal;

        /// The default element traversal method for the reflected container
        /** Meta-function returning a MetaTraversal
         *  which is providing meta-data about the default element traversal
         *  method for the container reflected by this MetaContainer
         *
         *  @see traversals
         *  @returns MetaTraversal
         */
        friend struct default_traversal<MetaContainer>;

        /// The element traversal methods available for the reflected container
        /** Meta-function returning a range of MetaTraversals
         *  which are providing meta-data about all element traversal
         *  methods for the container reflected by this MetaContainer
         *
         *  @see default_traversal
         *  @see mp::range
         *  @returns Range<MetaTraversal>
         */
        friend struct traversals<MetaContainer>;

        /// The element location methods available for the reflected container
        /** Meta-function returning a range of MetaLocators
         *  which are providing meta-data about all element location
         *  methods for the container reflected by this MetaContainer
         *
         *  @see mp::range
         *  @returns Range<MetaLocator>
         */
        friend struct locators<MetaContainer>;

        /// The element insertion methods available for the reflected container
        /** Meta-function returning a range of MetaInserters
         *  which are providing meta-data about all element insertion
         *  methods for the container reflected by this MetaContainer
         *
         *  @see default_inserter
         *  @see mp::range
         *  @returns Range<MetaInserter>
         */
        friend struct inserters<MetaContainer>;

        /// The element removal methods available for the reflected container
        /** Meta-function returning a range of MetaErasers
         *  which are providing meta-data about all element removal
         *  methods for the container reflected by this MetaContainer
         *
         *  @see default_inserter
         *  @see mp::range
         *  @returns Range<MetaEraser>
         */
        friend struct erasers<MetaContainer>;

        /** @see meta_object_category
         *  @see categorize_meta_object(const T&)
         */
        friend meta_container_tag
        categorize_meta_object(MetaContainer);
};

BOOST_MIRROR_NAMESPACE_END

#endif // BOOST_MIRROR_DOCUMENTATION_ONLY

#endif //include guard

