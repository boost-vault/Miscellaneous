/**
 *  @file boost/mirror/doc/concepts_meta_prog.hpp
 *  @brief Documentation of meta-programming concepts
 *
 *  Copyright 2008-2011 Matus Chochlik. Distributed under the Boost
 *  Software License, Version 1.0. (See accompanying file
 *  LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
 */

#ifndef BOOST_MIRROR_DOC_CONCEPTS_META_PROG_1104131331_HPP
#define BOOST_MIRROR_DOC_CONCEPTS_META_PROG_1104131331_HPP

#include <boost/mirror/config.hpp>

#ifdef BOOST_MIRROR_DOCUMENTATION_ONLY

BOOST_MIRROR_NAMESPACE_BEGIN
// This section is here for documentation purposes only

/** @defgroup meta_prog_concepts Mirror - Meta-programming concepts
 *
 *  These are models for classes which reflect various base-level
 *
 *  These concept classes are defined here only for documentation purposes
 *  and cannot be used in any end-user code.
 */

/// Integral constant type
/**
 *  @ingroup meta_prog_concepts
 */
struct IntegralConstantType
{
        static const int value;
        typedef IntegralConstantType type;
};

/// Boolean constant type
/**
 *  @ingroup meta_prog_concepts
 */
struct BooleanConstantType
{
        static const bool value;
        typedef BooleanConstantType type;
};

/// Element of Range or Optional
/**
 *  @ingroup meta_prog_concepts
 */
struct Element { };

/// Range is a typelist class containing a sequence of types
/** Ranges are usually returned by various intrinsic meta-functions which
 *  have a sequence of meta-objects as result.
 *
 *  @see boost::mirror::mp::range
 *  @see boost::mirror::mp::empty
 *  @see boost::mirror::mp::size
 *  @see boost::mirror::mp::front
 *  @see boost::mirror::mp::step_front
 *  @see boost::mirror::mp::at
 *  @see boost::mirror::mp::at_c
 *  @ingroup meta_prog_concepts
 */
template <typename ... Elements>
struct Range
{
        /// Meta-function checking if a Range is empty;
        /**
         *  @see boost::mirror::mp::empty
         *  @returns BooleanConstantType
         */
        friend struct empty<Range>;

        /// Meta-function returning the number of elements in a Range
        /**
         *  @see boost::mirror::mp::size
         *  @returns IntegralConstantType
         */
        friend struct size<Range>;

        /// Meta-function returning the front element of a Range
        /**
         *  @see boost::mirror::mp::front
         *  @returns Element
         */
        friend struct front<Range>;

        /// Meta-function returning a Range without the front element
        /**
         *  @see boost::mirror::mp::step_front
         *  @returns Range
         */
        friend struct step_front<Range>;

        /// Meta-function returning an element at the specified Position
        /**
         *  @see boost::mirror::mp::at
         *  @returns Element
         */
        friend struct at<Range, Position>;

        /// Meta-function returning an element at the specified Position
        /**
         *  @see boost::mirror::mp::at_c
         *  @returns Element
         */
        friend struct at_c<Range, Position>;
};

/// Optional is a class that can optionally contain a single type element
/**
 *  @see boost::mirror::mp::optional
 *  @see boost::mirror::mp::nil
 *  @see boost::mirror::mp::get
 *  @ingroup meta_prog_concepts
 */
template <typename Element>
struct Optional
{
        /// Meta-function checking if a Optional is nil;
        /**
         *  @see boost::mirror::mp::nil
         *  @returns BooleanConstantType
         */
        friend struct nil<Optional>;

        /// Meta-function returning the number of elements in a Optional
        /**
         *  @see boost::mirror::mp::get
         *  @returns Element
         */
        friend struct get<Optional>;
};


BOOST_MIRROR_NAMESPACE_END

#endif // BOOST_MIRROR_DOCUMENTATION_ONLY

#endif //include guard

