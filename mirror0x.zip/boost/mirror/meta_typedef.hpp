/**
 * @file boost/mirror/meta_typedef.hpp
 * @brief Implementation of typedefined type registering and reflection
 *
 *
 *  Copyright 2008-2011 Matus Chochlik. Distributed under the Boost
 *  Software License, Version 1.0. (See accompanying file
 *  LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
 */

#ifndef BOOST_MIRROR_META_TYPEDEF_1011291729_HPP
#define BOOST_MIRROR_META_TYPEDEF_1011291729_HPP

#include <boost/mirror/meta_type.hpp>

BOOST_MIRROR_NAMESPACE_BEGIN
namespace _typedef {

// This type is used for distinguishing typedefined types from other T<x>
// template types
template <typename BaseTypedef>
struct _selector { };

} // namespace _typedef

namespace _type {

template <typename BaseTypedef>
struct _< boost::mirror::_typedef::_selector<BaseTypedef> >
 : BaseTypedef
{ };

} // namespace _type

template <typename BaseTypedef>
struct meta_type< boost::mirror::_typedef::_selector<BaseTypedef> >
 : aux::scoped_named_impl< BaseTypedef >
{
        typedef meta_typedef_tag _type_category;
        typedef meta_typedef_tag _class_category;

        typedef typename aux::full_meta_object<
                typename BaseTypedef::scope
        >::type scope;

        typedef typename BaseTypedef::source_type original_type;

        typedef meta_class<original_type> type;
};

#ifdef BOOST_MIRROR_DOCUMENTATION_ONLY
/// This macro registers a typedef from the global scope with Mirror
/**
 *  @param TYPEDEF the typefined type name
 *
 *  @see BOOST_MIRROR_REG_TYPEDEF
 *  @see BOOST_MIRRORED_TYPEDEF
 *  @ingroup registering_macros
 */
#define BOOST_MIRROR_REG_GLOBAL_SCOPE_TYPEDEF(TYPEDEF)
#else
#define BOOST_MIRROR_REG_GLOBAL_SCOPE_TYPEDEF(TYPEDEF) \
namespace _typedef { \
template <typename Namespace> struct _ ## TYPEDEF ; \
template <> struct _ ## TYPEDEF< boost::mirror::_namespace::_ >\
{  \
        typedef TYPEDEF source_type; \
        typedef meta_type_tag category; \
        typedef boost::mirror::_namespace::_ scope; \
        BOOST_MIRROR_IMPLEMENT_META_OBJECT_NAME_FUNCTIONS(#TYPEDEF) \
}; \
} BOOST_MIRROR_ADD_TO_GLOBAL_LIST( \
        boost::mirror::_namespace::_, \
        boost::mirror::meta_type< \
        boost::mirror::_typedef::_selector< \
        boost::mirror::_typedef::_ ## TYPEDEF< \
        boost::mirror::_namespace::_ \
        > > > \
)
#endif

#ifdef BOOST_MIRROR_DOCUMENTATION_ONLY
/// This macro registers a typedef nested in a named namespace with Mirror
/**
 *  @param NAMESPACE the full namespace name NOT containing the
 *  leading double colon
 *  @param TYPEDEF the base type name
 *
 *  @see BOOST_MIRROR_REG_GLOBAL_SCOPE_TYPEDEF
 *  @see BOOST_MIRRORED_TYPEDEF
 *  @ingroup registering_macros
 */
#define BOOST_MIRROR_REG_TYPEDEF(NAMESPACE, TYPEDEF)
#else
#define BOOST_MIRROR_REG_TYPEDEF(NAMESPACE, TYPEDEF) \
namespace _typedef { \
template <typename Namespace> struct _ ## TYPEDEF; \
template <> \
struct _ ## TYPEDEF< boost::mirror::_namespace:: NAMESPACE :: _ > \
{  \
        typedef :: NAMESPACE :: TYPEDEF source_type; \
        typedef meta_type_tag category; \
        typedef boost::mirror::_namespace:: NAMESPACE ::_ scope; \
        BOOST_MIRROR_IMPLEMENT_META_OBJECT_NAME_FUNCTIONS(#TYPEDEF) \
}; \
} BOOST_MIRROR_ADD_TO_GLOBAL_LIST( \
        boost::mirror::_namespace :: NAMESPACE :: _, \
        boost::mirror::meta_type< \
        boost::mirror::_typedef::_selector< \
        boost::mirror::_typedef::_ ## TYPEDEF< \
        boost::mirror::_namespace:: NAMESPACE ::_ \
        > > > \
)
#endif

#ifdef BOOST_MIRROR_DOCUMENTATION_ONLY
/// Returns a special type representing a nested typedef to Mirror
/** This macro expands into a special type that represents
 *  a typedef registered with Mirror. This special type can be
 *  used for example in registering class member variables
 *  having typedefined types.
 *
 *  @param NAMESPACE the full namespace name NOT containing the
 *  leading double colon
 *  @param TYPEDEF the base typedef-ined name
 *
 *  @see BOOST_MIRROR_GLOBAL_SCOPE_TYPEDEF
 *  @see BOOST_MIRROR_REG_TYPEDEF
 *  @see BOOST_MIRRORED_TYPEDEF
 *  @see BOOST_MIRROR_REG_CLASS_MEM_VAR
 *
 *  @ingroup utility_macros
 *  @include boost/mirror/example/typedefd_members.cpp
 */
#define BOOST_MIRROR_TYPEDEF(NAMESPACE, TYPEDEF)
#else
#define BOOST_MIRROR_TYPEDEF(NAMESPACE, TYPEDEF) \
        boost::mirror::_typedef::_selector < \
        boost::mirror::_typedef::_ ## TYPEDEF < \
        boost::mirror::_namespace:: NAMESPACE :: _ \
        > >
#endif

#ifdef BOOST_MIRROR_DOCUMENTATION_ONLY
/// Returns a special type representing a typedef from the global scope
/** This macro expands into a special type that represents
 *  a typedef registered with Mirror. This special type can be
 *  used for example in registering class member variables
 *  having typedefined types.
 *
 *  @param TYPEDEF the base typedef-ined name
 *
 *  @see BOOST_MIRROR_TYPEDEF
 *  @see BOOST_MIRROR_REG_GLOBAL_SCOPE_TYPEDEF
 *  @see BOOST_MIRRORED_TYPEDEF_GLOBAL_SCOPE
 *  @see BOOST_MIRROR_REG_CLASS_MEM_VAR
 *
 *  @ingroup utility_macros
 */
#define BOOST_MIRROR_GLOBAL_SCOPE_TYPEDEF(TYPEDEF)
#else
#define BOOST_MIRROR_GLOBAL_SCOPE_TYPEDEF(TYPEDEF) \
        boost::mirror::_typedef::_selector < \
        boost::mirror::_typedef::_ ## TYPEDEF < \
        boost::mirror::_namespace::  _ \
        > >
#endif

#ifdef BOOST_MIRROR_DOCUMENTATION_ONLY
/// Reflects the typedef @a TYPEDEF defined in the @a NAMESPACE namespace
/**
 *  This macro expands into a type conforming to the MetaTypedef
 *  concept, which provides meta-data about the given typedef.
 *
 *  @see BOOST_MIRRORED_TYPEDEF_GLOBAL_SCOPE
 *  @see BOOST_MIRROR_REG_TYPE
 *  @see BOOST_MIRROR_REG_TYPEDEF
 *  @see boost::mirror::MetaTypedef
 *
 *  @ingroup reflection_macros
 */
#define BOOST_MIRRORED_TYPEDEF(NAMESPACE, TYPEDEF) boost::mirror::MetaTypedef
#else
#define BOOST_MIRRORED_TYPEDEF(NAMESPACE, TYPEDEF) \
        boost::mirror::meta_type< \
        boost::mirror::_typedef::_selector< \
        boost::mirror::_typedef::_ ## TYPEDEF< \
        boost::mirror::_namespace::NAMESPACE::_ \
        > > >
#endif

#ifdef BOOST_MIRROR_DOCUMENTATION_ONLY
/// Reflects the typedef @a TYPEDEF defined in the global scope
/**
 *  This macro expands into a type conforming to the MetaTypedef
 *  concept, which provides meta-data about the given typedef.
 *
 *  @see BOOST_MIRRORED_TYPEDEF
 *  @see BOOST_MIRROR_REG_TYPE
 *  @see BOOST_MIRROR_REG_TYPEDEF
 *  @see boost::mirror::MetaTypedef
 *
 *  @ingroup reflection_macros
 */
#define BOOST_MIRRORED_GLOBAL_SCOPE_TYPEDEF(TYPEDEF) boost::mirror::MetaTypedef
#else
#define BOOST_MIRRORED_GLOBAL_SCOPE_TYPEDEF(TYPEDEF) \
        boost::mirror::meta_type< \
        boost::mirror::_typedef::_selector< \
        boost::mirror::_typedef::_ ## TYPEDEF< \
        boost::mirror::_namespace::_ \
        > > >
#endif

BOOST_MIRROR_NAMESPACE_END

#endif //include guard

