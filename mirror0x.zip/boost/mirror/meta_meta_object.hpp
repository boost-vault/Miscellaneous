/**
 * @file boost/mirror/meta_meta_object.hpp
 * @brief Reflection of meta-objects
 *
 *
 *  Copyright 2008-2010 Matus Chochlik. Distributed under the Boost
 *  Software License, Version 1.0. (See accompanying file
 *  LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
 */

#ifndef BOOST_MIRROR_META_META_OBJECT_1011291729_HPP
#define BOOST_MIRROR_META_META_OBJECT_1011291729_HPP

#include <boost/mirror/mirror_fwd.hpp>
#include <boost/mirror/tag_dispatch.hpp>
#include <boost/mirror/auxiliary/scoped_named.hpp>

BOOST_MIRROR_NAMESPACE_BEGIN
namespace aux {

template <typename Tag>
struct meta_meta_object_name;

template <>
struct meta_meta_object_name<meta_namespace_tag>
{
protected:
        BOOST_MIRROR_IMPLEMENT_META_OBJECT_NAME_FUNCTIONS("namespace")
};

template <>
struct meta_meta_object_name<meta_global_scope_tag>
{
protected:
        BOOST_MIRROR_IMPLEMENT_META_OBJECT_NAME_FUNCTIONS("global scope")
};

template <>
struct meta_meta_object_name<meta_type_tag>
{
protected:
        BOOST_MIRROR_IMPLEMENT_META_OBJECT_NAME_FUNCTIONS("type")
};

template <>
struct meta_meta_object_name<meta_typedef_tag>
{
protected:
        BOOST_MIRROR_IMPLEMENT_META_OBJECT_NAME_FUNCTIONS("typedef")
};

template <>
struct meta_meta_object_name<meta_templated_type_tag>
{
protected:
        BOOST_MIRROR_IMPLEMENT_META_OBJECT_NAME_FUNCTIONS("template type")
};

template <>
struct meta_meta_object_name<meta_type_template_tag>
{
protected:
        BOOST_MIRROR_IMPLEMENT_META_OBJECT_NAME_FUNCTIONS("template")
};

template <>
struct meta_meta_object_name<meta_class_tag>
{
protected:
        BOOST_MIRROR_IMPLEMENT_META_OBJECT_NAME_FUNCTIONS("class")
};

template <>
struct meta_meta_object_name<meta_templated_class_tag>
{
protected:
        BOOST_MIRROR_IMPLEMENT_META_OBJECT_NAME_FUNCTIONS("template class")
};

template <>
struct meta_meta_object_name<meta_enum_tag>
{
protected:
        BOOST_MIRROR_IMPLEMENT_META_OBJECT_NAME_FUNCTIONS("enum")
};

template <>
struct meta_meta_object_name<meta_enum_value_tag>
{
protected:
        BOOST_MIRROR_IMPLEMENT_META_OBJECT_NAME_FUNCTIONS("enum value")
};

template <>
struct meta_meta_object_name<meta_inheritance_tag>
{
protected:
        BOOST_MIRROR_IMPLEMENT_META_OBJECT_NAME_FUNCTIONS("base class")
};

template <>
struct meta_meta_object_name<meta_variable_tag>
{
protected:
        BOOST_MIRROR_IMPLEMENT_META_OBJECT_NAME_FUNCTIONS("variable")
};

template <>
struct meta_meta_object_name<meta_member_variable_tag>
{
protected:
        BOOST_MIRROR_IMPLEMENT_META_OBJECT_NAME_FUNCTIONS("member variable")
};

template <>
struct meta_meta_object_name<meta_plain_member_variable_tag>
{
protected:
        BOOST_MIRROR_IMPLEMENT_META_OBJECT_NAME_FUNCTIONS("member variable")
};

template <>
struct meta_meta_object_name<meta_parameter_tag>
{
protected:
        BOOST_MIRROR_IMPLEMENT_META_OBJECT_NAME_FUNCTIONS("parameter")
};

template <>
struct meta_meta_object_name<meta_constructor_tag>
{
protected:
        BOOST_MIRROR_IMPLEMENT_META_OBJECT_NAME_FUNCTIONS("constructor")
};

template <>
struct meta_meta_object_name<meta_member_function_tag>
{
protected:
        BOOST_MIRROR_IMPLEMENT_META_OBJECT_NAME_FUNCTIONS("member function")
};

template <>
struct meta_meta_object_name<meta_conversion_operator_tag>
{
protected:
        BOOST_MIRROR_IMPLEMENT_META_OBJECT_NAME_FUNCTIONS("conversion operator")
};

template <>
struct meta_meta_object_name<meta_container_tag>
{
protected:
        BOOST_MIRROR_IMPLEMENT_META_OBJECT_NAME_FUNCTIONS("container")
};

template <>
struct meta_meta_object_name<meta_traversal_tag>
{
protected:
        BOOST_MIRROR_IMPLEMENT_META_OBJECT_NAME_FUNCTIONS("traversal")
};

template <>
struct meta_meta_object_name<meta_inserter_tag>
{
protected:
        BOOST_MIRROR_IMPLEMENT_META_OBJECT_NAME_FUNCTIONS("inserter")
};

template <>
struct meta_meta_object_name<meta_eraser_tag>
{
protected:
        BOOST_MIRROR_IMPLEMENT_META_OBJECT_NAME_FUNCTIONS("eraser")
};

} // namespace aux

template <typename MetaObjectCategory>
struct meta_meta_object : aux::meta_meta_object_name<
        MetaObjectCategory
>
{
public:
        // The category of the reflected meta-object
        typedef MetaObjectCategory category;
private:
        typedef aux::meta_meta_object_name< category > base_class;
public:
        // Returns the base name of the meta-object
        static std::string base_name(void)
        {
                // get the name from the base class and cache it
                return std::string(
                        base_class::name(),
                        base_class::name_length()
                );
        }
};

#ifdef BOOST_MIRROR_DOCUMENTATION_ONLY
/// Reflects the meta_object passed as the @a META_OBJECT argument
/**
 *  This macro expands into a type conforming to the MetaMetaObject
 *  concept, which provides meta-data about the given Mirror's MetaObject.
 *  The type name passed as the @a META_TYPE argument
 *  must by a valid Mirror's meta-object.
 *
 *  @see boost::mirror::MetaObject
 *  @see boost::mirror::MetaMetaObject
 *  @see boost::lagoon::meta_meta_object
 *  @see boost::lagoon::meta_object::self
 *
 *  @ingroup reflection_macros
 */
#define BOOST_MIRRORED_META_OBJECT(META_OBJECT) boost::mirror::MetaMetaObject
#else
#define BOOST_MIRRORED_META_OBJECT(META_OBJECT) \
        boost::mirror::meta_meta_object< \
                typename boost::mirror::meta_object_category< META_OBJECT >::type \
        >
#endif


BOOST_MIRROR_NAMESPACE_END

#endif //include guard

