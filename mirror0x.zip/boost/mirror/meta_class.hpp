/**
 * @file boost/mirror/meta_class.hpp
 * @brief Implementation of class registering and reflection
 *
 *  Copyright 2008-2011 Matus Chochlik. Distributed under the Boost
 *  Software License, Version 1.0. (See accompanying file
 *  LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
 */

#ifndef BOOST_MIRROR_META_CLASS_1011291729_HPP
#define BOOST_MIRROR_META_CLASS_1011291729_HPP

#include <boost/mirror/meta_namespace.hpp>
#include <boost/mirror/meta_type.hpp>
#include <boost/mirror/specifier_tags.hpp>
#include <boost/mirror/constructor_tags.hpp>
#include <boost/mirror/auxiliary/default_spec_tags.hpp>
#include <boost/mirror/auxiliary/class_layout.hpp>
#include <boost/mirror/auxiliary/base_classes.hpp>
#include <boost/mirror/auxiliary/member_variables.hpp>
#include <boost/mirror/auxiliary/constructors.hpp>
#include <boost/mirror/auxiliary/member_functions.hpp>
#include <boost/mirror/meta_prog/identity.hpp>
#include <boost/mirror/meta_prog/lambda.hpp>
#include <boost/mirror/meta_prog/range.hpp>
#include <boost/mirror/meta_prog/concat.hpp>
#include <boost/mirror/meta_prog/unique.hpp>
#include <boost/mirror/meta_prog/fold.hpp>
#include <boost/mirror/meta_prog/apply_on_seq_pack.hpp>
#include <initializer_list>
#include <type_traits>

BOOST_MIRROR_NAMESPACE_BEGIN
namespace _class {

// Helper structure for storing information about class inheritance
template <
        typename InheritanceType,
        typename AccessSpecifier,
        typename BaseClass
>
struct inheritance
{
        typedef InheritanceType inherit;
        typedef AccessSpecifier access;
        typedef BaseClass base;
};

// helper structure for storing information about member variable
template <
        typename AccessType,
        typename StorageClass,
        typename TypeSelector
>
struct member
{
        typedef AccessType access_type;
        typedef StorageClass storage_class;
        typedef TypeSelector type_sel;
        typedef TypeSelector real_type;
};

// specialization of member for members with typedefined typs
template <
        typename AccessType,
        typename StorageClass,
        typename BaseTypedef
>
struct member<
        AccessType,
        StorageClass,
        boost::mirror::_typedef::_selector<BaseTypedef>
>
{
        typedef AccessType access_type;
        typedef StorageClass storage_class;
        typedef boost::mirror::_typedef::_selector<BaseTypedef>
                type_sel;
        typedef typename BaseTypedef::source_type real_type;
};

struct _defs_base
{
        typedef boost::mirror::mp::range<> base_classes;
        typedef std::integral_constant<int, 0> attr_count;

        typedef std::integral_constant<int, 0> ctr_count;

        typedef std::integral_constant<int, 0> memfn_count;

        template <int Idx>
        static boost::mirror::custom_constructor_tag
        ctr_kind(std::integral_constant<int, Idx>);

        typedef mp::range<> conv_ops;
};

template <typename Class, typename TypeKind>
struct _defaults
 : _defs_base
 , boost::mirror::_type::_<Class>
{
        typedef Class _this;
        typedef TypeKind kind;
        typedef meta_class_tag category;
        //
        typedef typename ::std::has_trivial_default_constructor<
                Class
        >::type        has_default_ctr;

        typedef typename ::std::has_trivial_copy_constructor<
                Class
        >::type        has_copy_ctr;
};

template <typename Class, typename TypeKind>
struct _defaults_native : _defs_base
{
        typedef Class _this;
        typedef TypeKind kind;

        typedef std::true_type has_default_ctr;
        typedef std::true_type has_copy_ctr;

        // default constructor
        struct ctr_params_default
        {
                typedef std::integral_constant<int, 0> size;
        };
        static ctr_params_default ctr_params(std::integral_constant<int, 0>);
        static spec_public_tag ctr_access(std::integral_constant<int, 0>);

        // copy-constructor / initializer
        struct ctr_params_copy
        {
                typedef std::integral_constant<int, 0> param_idx_source;
                static mp::identity<_this> type(param_idx_source);
                static const char* name( param_idx_source )
                {
                        return "source";
                }
                static size_t name_length( param_idx_source )
                {
                        return sizeof("source") - 1;
                }
                typedef std::integral_constant<int, 1> size;
        };
        static ctr_params_copy ctr_params(std::integral_constant<int, 1>);
        static spec_public_tag ctr_access(std::integral_constant<int, 1>);

        typedef std::integral_constant<int, 2> ctr_count;
};

template <typename Class>
struct _defaults<Class, boost::mirror::spec_enum_tag>
 : public _defaults_native<Class, boost::mirror::spec_enum_tag>
{
        // TODO: conversion of enum values to ints
        typedef mp::range<> conv_ops;
};

// Default implementation of the _ template providing base info
template <typename Class>
struct _ : _defaults<Class, typename boost::mirror::_type::_<Class>::kind>
{ };

} // namespace _class

#ifdef BOOST_MIRROR_DOCUMENTATION_ONLY
/// Begins the registering of an elaborate type from the global scope
/**
 *  @param ELABORATED_TYPE the type of the class this parameter can have
 *  the following values (class, struct, union, enum and _ for default (class))
 *  @param CLASS the base class name.
 *
 *  @see BOOST_MIRROR_REG_CLASS_BEGIN
 *  @see BOOST_MIRROR_REG_CLASS_END
 *  @see BOOST_MIRROR_REG_BASE_CLASS
 *  @ingroup registering_macros
 */
#define BOOST_MIRROR_REG_GLOBAL_SCOPE_CLASS_BEGIN(ELABORATED_TYPE, CLASS)
#else
#define BOOST_MIRROR_REG_GLOBAL_SCOPE_CLASS_BEGIN(ELABORATED_TYPE, CLASS) \
BOOST_MIRROR_REG_GLOBAL_SCOPE_TYPE_BASICS(ELABORATED_TYPE, CLASS) \
BOOST_MIRROR_ADD_TO_GLOBAL_LIST( \
        boost::mirror::_namespace :: _, \
        boost::mirror::meta_class< CLASS > \
) \
namespace _class { \
template <> \
struct _< CLASS > \
 : _defaults< CLASS, spec_ ## ELABORATED_TYPE ## _tag >\
{
#endif

#ifdef BOOST_MIRROR_DOCUMENTATION_ONLY
/// Macro that begins the registering of an elaborate type
/**
 *  @param ELABORATED_TYPE the type of the class this parameter can have
 *  the following values (class, struct, union, enum and _ for default (class))
 *  @param NAMESPACE the full namespace name inside of which the class is
 *  nested.
 *  @param CLASS the base class name.
 *
 *  @see BOOST_MIRROR_REG_CLASS_END
 *  @see BOOST_MIRROR_REG_BASE_CLASS
 *  @ingroup registering_macros
 */
#define BOOST_MIRROR_REG_CLASS_BEGIN(ELABORATED_TYPE, NAMESPACE, CLASS)
#else
#define BOOST_MIRROR_REG_CLASS_BEGIN(ELABORATED_TYPE, NAMESPACE, CLASS) \
BOOST_MIRROR_REG_TYPE_BASICS(class, NAMESPACE, CLASS) \
BOOST_MIRROR_ADD_TO_GLOBAL_LIST( \
        boost::mirror::_namespace :: NAMESPACE :: _, \
        boost::mirror::meta_class< :: NAMESPACE :: CLASS> \
) \
namespace _class { \
template <> \
struct _< :: NAMESPACE :: CLASS > \
 : _defaults< :: NAMESPACE :: CLASS, spec_ ## ELABORATED_TYPE ## _tag >\
{
#endif

#ifdef BOOST_MIRROR_DOCUMENTATION_ONLY
/// Macro that begins the registering of an elaborate type nested in a class
/**
 *  @param ELABORATED_TYPE the type of the class this parameter can have
 *  the following values (class, struct, union, enum and _ for default (class))
 *  @param PARENT_CLASS the full class name inside of which the class is
 *  nested.
 *  @param CLASS the base class name.
 *
 *  @see BOOST_MIRROR_REG_CLASS_BEGIN
 *  @see BOOST_MIRROR_REG_CLASS_END
 *  @see BOOST_MIRROR_REG_BASE_CLASS
 *  @ingroup registering_macros
 */
#define BOOST_MIRROR_REG_NESTED_CLASS_BEGIN(ELABORATED_TYPE, PARENT_CLASS, CLASS)
#else
#define BOOST_MIRROR_REG_NESTED_CLASS_BEGIN(ELABORATED_TYPE, PARENT_CLASS, CLASS) \
BOOST_MIRROR_REG_NESTED_TYPE_BASICS(class, PARENT_CLASS, CLASS) \
namespace _class { \
template <> \
struct _< :: PARENT_CLASS :: CLASS > \
 : _defaults< :: PARENT_CLASS :: CLASS, spec_ ## ELABORATED_TYPE ## _tag >\
{ \
        typedef spec_ ## ELABORATED_TYPE ## _tag kind;
#endif

#ifdef BOOST_MIRROR_DOCUMENTATION_ONLY
/// Macro that ends the registering of an elaborate type
/**
 *
 *  @see BOOST_MIRROR_REG_CLASS_BEGIN
 *  @see BOOST_MIRROR_REG_BASE_CLASS
 *  @ingroup registering_macros
 */
#define BOOST_MIRROR_REG_CLASS_END
#else
#define BOOST_MIRROR_REG_CLASS_END \
}; /* struct _class::_< :: NAMESPACE :: CLASS > */ \
} /* namespace _class */
#endif

#ifdef BOOST_MIRROR_DOCUMENTATION_ONLY
/// Macro that creates an alias for a type
/** This macro can be used to create an alias for a type inside
 *  of the class registering expression, basically to do a @c typedef.
 *
 *  Doing this is necessary with templated types whose name contains
 *  a comma. TODO
 *
 *  @see BOOST_MIRROR_REG_CLASS_BEGIN
 *  @see BOOST_MIRROR_REG_CLASS_END
 *  @ingroup registering_macros
 */
#define BOOST_MIRROR_REG_TYPE_ALIAS(TYPENAME, ALIAS)
#else
#define BOOST_MIRROR_REG_TYPE_ALIAS(TYPENAME, ALIAS) \
        typedef BOOST_MIRROR_PP_EXPAND_ARGS TYPENAME ALIAS;
#endif

#ifdef BOOST_MIRROR_DOCUMENTATION_ONLY
/// Macro that begins the registering of the base classes of a class
/**
 *  This macro must be used between the BOOST_MIRROR_REG_CLASS_BEGIN
 *  and the BOOST_MIRROR_REG_CLASS_END macros.
 *
 *  @see BOOST_MIRROR_REG_CLASS_BEGIN
 *  @see BOOST_MIRROR_REG_CLASS_END
 *  @see BOOST_MIRROR_REG_BASE_CLASS
 *  @ingroup registering_macros
 */
#define BOOST_MIRROR_REG_BASE_CLASSES_BEGIN
#else
#define BOOST_MIRROR_REG_BASE_CLASSES_BEGIN \
        typedef boost::mirror::mp::range<
#endif

#ifdef BOOST_MIRROR_DOCUMENTATION_ONLY
/// Macro that ends the registering of the base classes of a class
/**
 *  This macro must be used between the BOOST_MIRROR_REG_CLASS_BEGIN
 *  and the BOOST_MIRROR_REG_CLASS_END macros and after the
 *  BOOST_MIRROR_REG_BASE_CLASSES_BEGIN macro.
 *
 *  @see BOOST_MIRROR_REG_CLASS_BEGIN
 *  @see BOOST_MIRROR_REG_CLASS_END
 *  @see BOOST_MIRROR_REG_BASE_CLASS
 *  @ingroup registering_macros
 */
#define BOOST_MIRROR_REG_BASE_CLASSES_END
#else
#define BOOST_MIRROR_REG_BASE_CLASSES_END \
        > base_classes;
#endif


#ifdef BOOST_MIRROR_DOCUMENTATION_ONLY
/// Macro that registers one base class inheritance
/**
 *  This macro must be used between the BOOST_MIRROR_REG_BASE_CLASSES_BEGIN
 *  and the BOOST_MIRROR_REG_BASE_CLASSES_END macros and must be comma
 *  separated from the other invocations of this macro between the
 *  BOOST_MIRROR_REG_BASE_CLASSES_BEGIN and BOOST_MIRROR_REG_BASE_CLASSES_END
 *  macros.
 *
 *  @param INHERITANCE_TYPE the inheritance type specifier. This argument must
 *  have one of these values (virtual, non_virtual or _ for default
 *  (non-virtual)).
 *
 *  @param ACCESS_TYPE the member access type specifier. This argument must
 *  have one of these values (private, protected, public or _ for default
 *  (public for struct(s) and private for class(es))).
 *
 *  @param BASE_CLASS the full base class type name.
 *
 *  @see BOOST_MIRROR_REG_CLASS_BEGIN
 *  @see BOOST_MIRROR_REG_CLASS_END
 *  @see BOOST_MIRROR_REG_BASE_CLASSES_BEGIN
 *  @see BOOST_MIRROR_REG_BASE_CLASSES_END
 *  @ingroup registering_macros
 */
#define BOOST_MIRROR_REG_BASE_CLASS(INHERITANCE_TYPE, ACCESS_TYPE, BASE_CLASS)
#else
#define BOOST_MIRROR_REG_BASE_CLASS(INHERITANCE_TYPE, ACCESS_TYPE, BASE_CLASS)\
        boost::mirror::_class::inheritance< \
                spec_ ## INHERITANCE_TYPE ## _tag, \
                spec_ ## ACCESS_TYPE ## _tag, \
                BASE_CLASS \
        >
#endif

#ifdef BOOST_MIRROR_DOCUMENTATION_ONLY
/// Macro that begins the registering of the class' member variables
/**
 *  This macro must be used between the BOOST_MIRROR_REG_CLASS_BEGIN
 *  and the BOOST_MIRROR_REG_CLASS_END macros.
 *
 *  @see BOOST_MIRROR_REG_CLASS_BEGIN
 *  @see BOOST_MIRROR_REG_CLASS_END
 *  @see BOOST_MIRROR_REG_CLASS_ATTR_END
 *  @see BOOST_MIRROR_REG_CLASS_ATTR
 *  @ingroup registering_macros
 */
#define BOOST_MIRROR_REG_CLASS_MEM_VARS_BEGIN
#else
#define BOOST_MIRROR_REG_CLASS_MEM_VARS_BEGIN \
        template <typename T, typename P> static T attr_type(T*, P); \
        template <typename T> static T attr_type(_*, T _this::*); \
        template <typename T> static T attr_type(_*, T*); \
        static spec___tag member_access(std::integral_constant<int, -1>); \
        typedef std::integral_constant<int, 0>
#endif

#ifdef BOOST_MIRROR_DOCUMENTATION_ONLY
/// Macro that ends the registering of the class' member variables
/**
 *  This macro must be used between the BOOST_MIRROR_REG_CLASS_BEGIN
 *  and the BOOST_MIRROR_REG_CLASS_END macros.
 *
 *  @see BOOST_MIRROR_REG_CLASS_BEGIN
 *  @see BOOST_MIRROR_REG_CLASS_END
 *  @see BOOST_MIRROR_REG_CLASS_MEM_VARS_BEGIN
 *  @see BOOST_MIRROR_REG_CLASS_MEM_VAR
 *  @ingroup registering_macros
 */
#define BOOST_MIRROR_REG_CLASS_MEM_VARS_END
#else
#define BOOST_MIRROR_REG_CLASS_MEM_VARS_END \
        attr_count;
#endif

#define BOOST_MIRROR_REG_CLASS_MEM_VAR_BEGIN( \
        ACCESS_TYPE, \
        STORAGE_CLASS, \
        TYPE, \
        NAME, \
        MEM_PTR  \
) \
        attr_idx_ ## NAME; \
        typedef decltype(attr_type((TYPE*)nullptr, MEM_PTR)) \
                attr_type_ ## NAME; \
        static typename boost::mirror::aux::resof_member_access< \
                _, \
                spec_ ## ACCESS_TYPE ## _tag, \
                attr_idx_ ## NAME ::value \
        >::type member_access(attr_idx_ ## NAME); \
        typedef  member< \
                decltype(member_access(attr_idx_ ## NAME())), \
                spec_ ## STORAGE_CLASS ## _tag, \
                attr_type_ ## NAME \
        > mem_var_ ## NAME; \
        static mem_var_ ## NAME attr_traits(attr_idx_ ## NAME); \
        static const char* attr_name( attr_idx_ ## NAME ) \
        { \
                return #NAME; \
        } \
        static size_t attr_name_length( attr_idx_ ## NAME ) \
        { \
                return sizeof(#NAME) - 1; \
        } \
        template <typename X> \
        struct by_name_typ_ ## NAME \
        { \
                typedef X NAME; \
        }; \
        template <typename X> \
        static by_name_typ_ ## NAME <X> by_name_typ(attr_idx_ ## NAME, X*); \
        template <typename X> \
        struct by_name_val_ ## NAME \
        { \
                X NAME; \
                by_name_val_ ## NAME(void) = default; \
                template <class Parent, typename Param> \
                by_name_val_ ## NAME(Parent& parent, Param param) \
                 : NAME(parent, param) \
                { } \
        }; \
        template <typename X> \
        static by_name_val_ ## NAME <X> by_name_val(attr_idx_ ## NAME, X*); \
        typedef typename mem_var_ ## NAME :: real_type real_type_ ## NAME; \
        typedef const real_type_ ## NAME & r_value_ ## NAME;

#define BOOST_MIRROR_REG_CLASS_MEM_VAR_END( \
        NAME \
) typedef std::integral_constant<int, attr_idx_ ## NAME::value + 1>


#define BOOST_MIRROR_REG_CLASS_MEM_VAR_GET_SET_HLPR( \
        NAME, \
        GET_EXPRESSION, \
        SET_EXPRESSION  \
) \
        static auto get( \
                attr_idx_ ## NAME, \
                const _this& _ \
        ) -> decltype(GET_EXPRESSION) { return GET_EXPRESSION ;} \
        static void set( \
                attr_idx_ ## NAME, \
                _this& _, \
                r_value_ ## NAME _ ## NAME \
        ) { SET_EXPRESSION ; }

#ifdef BOOST_MIRROR_DOCUMENTATION_ONLY
/// Macro for registering a single class member variable
/** This registering macro registers a single member variable of
 *  a class and allows to specify custom expressions for getting
 *  and setting the value of the member variable in case it is necessary.
 *  This macro must be used between the BOOST_MIRROR_REG_CLASS_MEM_VARS_BEGIN
 *  and the BOOST_MIRROR_REG_CLASS_MEM_VARS_END macros.
 *  In case the member variable is a regular non-const and publically
 *  accessible member variable, the BOOST_MIRROR_REG_CLASS_MEM_VAR macro
 *  can be used.
 *
 *  @param ACCESS_TYPE the access type specifier (private|protected|publici|_)
 *  In case the special '_' specifier is used, then the access type is either
 *  determined from the elaborated type specifier of the parent class or from
 *  the explicitly specified access of a previous member (if any).
 *
 *  @param STORAGE_CLASS the storage class specifier for the member variable
 *  (static|mutable|auto|...|_) if the special '_' specifier is used,then auto
 *  is assumed.
 *
 *  @param TYPE the type of the member variable. If the special '_' specifier
 *  is used, then the type if automatically detected, if it is possible.
 *
 *  @param NAME the name (i.e. identifier not a string) of the member variable.
 *
 *  @param GET_EXPRESSION the expression which returns the value of the member
 *  variable from a const reference to an instance of the parent class of the
 *  member var. The reference to the parent class instance can be accessed by
 *  the pre-defined _ variable.
 *
 *  @param SET_EXPRESSION the expression which sets the value of the member
 *  variable to a reference to an instance of the parent class of the member
 *  variable.
 *  The reference to the parent class instance can be accessed by
 *  the pre-defined _ variable, the value to be set is stored in a variable
 *  having the same name as the registered member variable prefixed with
 *  a single underscore.
 *
 *  @see BOOST_MIRROR_REG_CLASS_MEM_VARS_BEGIN
 *  @see BOOST_MIRROR_REG_CLASS_MEM_VARS_END
 *  @see BOOST_MIRROR_REG_CLASS_MEM_VAR
 *  @see BOOST_MIRROR_FRIENDLY_CLASS
 *
 *  @ingroup registering_macros
 */
#define BOOST_MIRROR_REG_CLASS_MEM_VAR_GET_SET( \
        ACCESS_TYPE, \
        STORAGE_CLASS, \
        TYPE, \
        NAME, \
        GET_EXPRESSION, \
        SET_EXPRESSION  \
)
#else
#define BOOST_MIRROR_REG_CLASS_MEM_VAR_GET_SET( \
        ACCESS_TYPE, \
        STORAGE_CLASS, \
        TYPE, \
        NAME, \
        GET_EXPRESSION, \
        SET_EXPRESSION  \
) \
        BOOST_MIRROR_REG_CLASS_MEM_VAR_BEGIN( \
                ACCESS_TYPE, \
                STORAGE_CLASS, \
                TYPE, \
                NAME, \
                (TYPE*)nullptr \
        ) \
        BOOST_MIRROR_REG_CLASS_MEM_VAR_GET_SET_HLPR( \
                NAME, \
                GET_EXPRESSION, \
                SET_EXPRESSION  \
        ) \
        static std::false_type has_address(attr_idx_ ## NAME); \
        static void* address( attr_idx_ ## NAME, const _this& _ ); \
        static void* mem_ptr(attr_idx_ ## NAME); \
        BOOST_MIRROR_REG_CLASS_MEM_VAR_END(NAME)
#endif

#ifdef BOOST_MIRROR_DOCUMENTATION_ONLY
/// Macro for registering a single class member variable
/** This registering macro registers a single member variable of
 *  a class, in case the member variable is a regular non-const and publically
 *  accessible member variable or its parent class definition contains the
 *  BOOST_MIRROR_FRIENDLY_CLASS macro.
 *
 *  This macro must be used between the BOOST_MIRROR_REG_CLASS_MEM_VARS_BEGIN
 *  and the BOOST_MIRROR_REG_CLASS_MEM_VARS_END macros.
 *
 *  @param ACCESS_TYPE the access type specifier (private|protected|publici|_)
 *  In case the special '_' specifier is used, then the access type is either
 *  determined from the elaborated type specifier of the parent class or from
 *  the explicitly specified access of a previous member (if any).
 *
 *  @param STORAGE_CLASS the storage class specifier for the member variable
 *  (static|mutable|auto|...|_) if the special '_' specifier is used,then auto
 *  is assumed.
 *
 *  @param TYPE the type of the member variable. If the special '_' specifier
 *  is used, then the type if automatically detected, if it is possible.
 *
 *  @param NAME the name (i.e. identifier not a string) of the member variable.
 *
 *  @see BOOST_MIRROR_REG_CLASS_MEM_VARS_BEGIN
 *  @see BOOST_MIRROR_REG_CLASS_MEM_VARS_END
 *  @see BOOST_MIRROR_REG_CLASS_MEM_VAR_GET_SET
 *  @see BOOST_MIRROR_FRIENDLY_CLASS
 *
 *  @ingroup registering_macros
 */
#define BOOST_MIRROR_REG_CLASS_MEM_VAR( \
        ACCESS_TYPE, \
        STORAGE_CLASS, \
        TYPE, \
        NAME \
)
#else
#define BOOST_MIRROR_REG_CLASS_MEM_VAR( \
        ACCESS_TYPE, \
        STORAGE_CLASS, \
        TYPE, \
        NAME \
) BOOST_MIRROR_REG_CLASS_MEM_VAR_BEGIN( \
                ACCESS_TYPE, \
                STORAGE_CLASS, \
                TYPE, \
                NAME, \
                &_this::NAME \
        ) \
        BOOST_MIRROR_REG_CLASS_MEM_VAR_GET_SET_HLPR( \
                NAME, \
                _.NAME, \
                _.NAME = _ ## NAME \
        ) \
        static std::true_type has_address(attr_idx_ ## NAME); \
        static auto address( attr_idx_ ## NAME, _this& _ ) \
         -> decltype(&_.NAME) { return &_.NAME; } \
        static auto address( attr_idx_ ## NAME, const _this& _ ) \
         -> decltype(&_.NAME) { return &_.NAME; } \
        static auto mem_ptr(attr_idx_ ## NAME) \
         -> decltype(&_this::NAME) { return &_this::NAME; } \
        BOOST_MIRROR_REG_CLASS_MEM_VAR_END(NAME)
#endif

#ifdef BOOST_MIRROR_DOCUMENTATION_ONLY
/// Macro that begins the registering of the class' constructors
/**
 *  This macro must be used between the BOOST_MIRROR_REG_CLASS_BEGIN
 *  and the BOOST_MIRROR_REG_CLASS_END macros.
 *
 *  @see BOOST_MIRROR_REG_CLASS_BEGIN
 *  @see BOOST_MIRROR_REG_CLASS_END
 *  @see BOOST_MIRROR_REG_CONSTRUCTORS_END
 *  @see BOOST_MIRROR_REG_STRUCT_INITIALIZER
 *  @see BOOST_MIRROR_REG_DEFAULT_CONSTRUCTOR
 *  @see BOOST_MIRROR_REG_COPY_CONSTRUCTOR
 *  @see BOOST_MIRROR_REG_INITLIST_CONSTRUCTOR
 *  @ingroup registering_macros
 */
#define BOOST_MIRROR_REG_CONSTRUCTORS_BEGIN
#else
#define BOOST_MIRROR_REG_CONSTRUCTORS_BEGIN \
        typedef std::integral_constant<int, 0>
#endif

#ifdef BOOST_MIRROR_DOCUMENTATION_ONLY
/// Macro that ends the registering of the class' constructors
/**
 *  This macro must be used between the BOOST_MIRROR_REG_CLASS_BEGIN
 *  and the BOOST_MIRROR_REG_CLASS_END macros.
 *
 *  @see BOOST_MIRROR_REG_CLASS_BEGIN
 *  @see BOOST_MIRROR_REG_CLASS_END
 *  @see BOOST_MIRROR_REG_CONSTRUCTORS_BEGIN
 *  @see BOOST_MIRROR_REG_STRUCT_INITIALIZER
 *  @see BOOST_MIRROR_REG_DEFAULT_CONSTRUCTOR
 *  @see BOOST_MIRROR_REG_COPY_CONSTRUCTOR
 *  @see BOOST_MIRROR_REG_INITLIST_CONSTRUCTOR
 *  @ingroup registering_macros
 */
#define BOOST_MIRROR_REG_CONSTRUCTORS_END
#else
#define BOOST_MIRROR_REG_CONSTRUCTORS_END \
        ctr_count;
#endif

#ifdef BOOST_MIRROR_DOCUMENTATION_ONLY
/// Macro that registers the class' default constructor
/**
 *  This macro must be used between the BOOST_MIRROR_REG_CONSTRUCTORS_BEGIN
 *  and the BOOST_MIRROR_REG_CONSTRUCTORS_END macros.
 *
 *  @param ACCESS_TYPE the access type specifier (private|protected|publici|_)
 *  In case the special '_' specifier is used, then the access type is
 *  determined from the elaborated type specifier of the parent class
 *
 *  @see BOOST_MIRROR_REG_CONSTRUCTORS_BEGIN
 *  @see BOOST_MIRROR_REG_CONSTRUCTORS_END
 *  @see BOOST_MIRROR_REG_COPY_CONSTRUCTOR
 *  @see BOOST_MIRROR_REG_STRUCT_INITIALIZER
 *  @see BOOST_MIRROR_REG_INITLIST_CONSTRUCTOR
 *  @ingroup registering_macros
 */
#define BOOST_MIRROR_REG_DEFAULT_CONSTRUCTOR(ACCESS_TYPE)
#else
#define BOOST_MIRROR_REG_DEFAULT_CONSTRUCTOR(ACCESS_TYPE) \
        ctr_index_default; \
        typedef std::true_type has_default_ctr; \
        struct ctr_params_default \
        { \
                typedef std::integral_constant<int, 0> size; \
        };\
        static ctr_params_default ctr_params(ctr_index_default); \
        static spec_ ## ACCESS_TYPE ## _tag ctr_access(ctr_index_default); \
        static default_constructor_tag ctr_kind(ctr_index_default); \
        typedef std::integral_constant<int, ctr_index_default::value + 1>
#endif

#ifdef BOOST_MIRROR_DOCUMENTATION_ONLY
/// Macro that registers the class' copy constructor
/**
 *  This macro must be used between the BOOST_MIRROR_REG_CONSTRUCTORS_BEGIN
 *  and the BOOST_MIRROR_REG_CONSTRUCTORS_END macros.
 *
 *  @param ACCESS_TYPE the access type specifier (private|protected|publici|_)
 *  In case the special '_' specifier is used, then the access type is
 *  determined from the elaborated type specifier of the parent class
 *
 *  @see BOOST_MIRROR_REG_CONSTRUCTORS_BEGIN
 *  @see BOOST_MIRROR_REG_CONSTRUCTORS_END
 *  @see BOOST_MIRROR_REG_DEFAULT_CONSTRUCTOR
 *  @see BOOST_MIRROR_REG_STRUCT_INITIALIZER
 *  @see BOOST_MIRROR_REG_INITLIST_CONSTRUCTOR
 *  @ingroup registering_macros
 */
#define BOOST_MIRROR_REG_COPY_CONSTRUCTOR(ACCESS_TYPE)
#else
#define BOOST_MIRROR_REG_COPY_CONSTRUCTOR(ACCESS_TYPE) \
        ctr_index_copy; \
        typedef std::true_type has_copy_ctr; \
        struct ctr_params_copy \
        { \
                typedef std::integral_constant<int, 0> param_idx_source; \
                static mp::identity<_this> type(param_idx_source); \
                static const char* name( param_idx_source ) \
                { \
                        return "source"; \
                } \
                static size_t name_length( param_idx_source ) \
                { \
                        return sizeof("source") - 1; \
                } \
                typedef std::integral_constant<int, 1> size; \
        }; \
        static ctr_params_copy ctr_params(ctr_index_copy); \
        static spec_ ## ACCESS_TYPE ## _tag ctr_access(ctr_index_copy); \
        static copy_constructor_tag ctr_kind(ctr_index_copy); \
        typedef std::integral_constant<int, ctr_index_copy::value + 1>
#endif

#ifdef BOOST_MIRROR_DOCUMENTATION_ONLY
/// Macro that registers the class' initializer_list constructor
/**
 *  This macro must be used between the BOOST_MIRROR_REG_CONSTRUCTORS_BEGIN
 *  and the BOOST_MIRROR_REG_CONSTRUCTORS_END macros.
 *
 *  @param ACCESS_TYPE the access type specifier (private|protected|publici|_)
 *  In case the special '_' specifier is used, then the access type is
 *  determined from the elaborated type specifier of the parent class
 *
 *  @param ELEMENT_TYPE the type of the elements in the initializer list
 *
 *  @param NAME the name of the initializer-list parameter
 *
 *  @see BOOST_MIRROR_REG_CONSTRUCTORS_BEGIN
 *  @see BOOST_MIRROR_REG_CONSTRUCTORS_END
 *  @see BOOST_MIRROR_REG_DEFAULT_CONSTRUCTOR
 *  @see BOOST_MIRROR_REG_STRUCT_INITIALIZER
 *  @see BOOST_MIRROR_REG_COPY_CONSTRUCTOR
 *  @ingroup registering_macros
 */
#define BOOST_MIRROR_REG_INITLIST_CONSTRUCTOR(ACCESS_TYPE, ELEMENT_TYPE, NAME)
#else
#define BOOST_MIRROR_REG_INITLIST_CONSTRUCTOR(ACCESS_TYPE, ELEMENT_TYPE, NAME) \
        ctr_index_initlist; \
        typedef std::true_type has_initlist_ctr; \
        struct ctr_params_initlist \
        { \
                typedef std::integral_constant<int, 0> param_idx_source; \
                static mp::identity<std::initializer_list< ELEMENT_TYPE > > \
                type(param_idx_source); \
                static const char* name( param_idx_source ) \
                { \
                        return #NAME; \
                } \
                static size_t name_length( param_idx_source ) \
                { \
                        return sizeof(#NAME) - 1; \
                } \
                typedef std::integral_constant<int, 1> size; \
        }; \
        static ctr_params_initlist ctr_params(ctr_index_initlist); \
        static spec_ ## ACCESS_TYPE ## _tag ctr_access(ctr_index_initlist); \
        static initializer_list_constructor_tag ctr_kind(ctr_index_initlist);\
        typedef std::integral_constant<int, ctr_index_initlist::value + 1>
#endif

#ifdef BOOST_MIRROR_DOCUMENTATION_ONLY
/// Macro that registers the POD class' initializer as constructor
/**
 *  This macro must be used between the BOOST_MIRROR_REG_CONSTRUCTORS_BEGIN
 *  and the BOOST_MIRROR_REG_CONSTRUCTORS_END macros.
 *
 *  @see BOOST_MIRROR_REG_CONSTRUCTORS_BEGIN
 *  @see BOOST_MIRROR_REG_CONSTRUCTORS_END
 *  @see BOOST_MIRROR_REG_DEFAULT_CONSTRUCTOR
 *  @see BOOST_MIRROR_REG_COPY_CONSTRUCTOR
 *  @see BOOST_MIRROR_REG_INITLIST_CONSTRUCTOR
 *  @ingroup registering_macros
 */
#define BOOST_MIRROR_REG_STRUCT_INITIALIZER()
#else
#define BOOST_MIRROR_REG_STRUCT_INITIALIZER() \
        ctr_index_structinit; \
        struct ctr_params_structinit \
        { \
                typedef attr_count size; \
                template <typename AttrTraits> \
                static auto type_hlpr(AttrTraits)-> \
                typename AttrTraits::real_type; \
                template <int Idx> \
                static auto type(std::integral_constant<int, Idx> idx) -> \
                mp::identity<decltype(type_hlpr(attr_traits(idx)))>; \
                template <int Idx> \
                static const char* name(std::integral_constant<int, Idx> idx) \
                { \
                        return attr_name(idx); \
                } \
                template <int Idx> \
                static size_t name_length(std::integral_constant<int, Idx> idx)\
                { \
                        return attr_name_length(idx); \
                } \
        }; \
        static ctr_params_structinit ctr_params(ctr_index_structinit); \
        static spec_public_tag ctr_access(ctr_index_structinit); \
        static std::true_type is_strinit(ctr_index_structinit); \
        static struct_initializer_tag ctr_kind(ctr_index_structinit); \
        typedef std::integral_constant<int, ctr_index_structinit::value + 1>
#endif

#ifdef BOOST_MIRROR_DOCUMENTATION_ONLY
/// Macro that ends the registering of a single class' constructor
/**
 *  This macro must be used between the BOOST_MIRROR_REG_CONSTRUCTORS_BEGIN
 *  and the BOOST_MIRROR_REG_CONSTRUCTORS_END macros.
 *
 *  @param ACCESS_TYPE the access type specifier (private|protected|public|_)
 *  In case the special '_' specifier is used, then the access type is
 *  determined from the elaborated type specifier of the parent class
 *
 *  @param ID a unique identifier of the constructor within the class.
 *  Same rules as for C++ identifiers apply except it is possible
 *  for the identifier to start with a digit. i.e. 1 is a valid constructor
 *  identifier.
 *
 *  @see BOOST_MIRROR_REG_CONSTRUCTOR_END
 *  @see BOOST_MIRROR_REG_CLASS_BEGIN
 *  @see BOOST_MIRROR_REG_CLASS_END
 *  @see BOOST_MIRROR_REG_CONSTRUCTORS_BEGIN
 *  @see BOOST_MIRROR_REG_CONSTRUCTORS_END
 *  @see BOOST_MIRROR_REG_STRUCT_INITIALIZER
 *  @see BOOST_MIRROR_REG_DEFAULT_CONSTRUCTOR
 *  @see BOOST_MIRROR_REG_COPY_CONSTRUCTOR
 *  @see BOOST_MIRROR_REG_INITLIST_CONSTRUCTOR
 *  @ingroup registering_macros
 */
#define BOOST_MIRROR_REG_CONSTRUCTOR_BEGIN(ACCESS_TYPE, ID)
#else
#define BOOST_MIRROR_REG_CONSTRUCTOR_BEGIN(ACCESS_TYPE, ID) \
        ctr_index_ ## ID; \
        static spec_ ## ACCESS_TYPE ## _tag ctr_access(ctr_index_ ## ID); \
        struct ctr_params_ ## ID \
        { \
                typedef std::integral_constant<int, 0>
#endif

#ifdef BOOST_MIRROR_DOCUMENTATION_ONLY
/// Macro that ends the registering of a single class' constructor
/**
 *  This macro must be used between the BOOST_MIRROR_REG_CONSTRUCTORS_BEGIN
 *  and the BOOST_MIRROR_REG_CONSTRUCTORS_END macros.
 *
 *  @param ID a unique identifier of the constructor within the class.
 *  Same rules as for C++ identifiers apply except it is possible
 *  for the identifier to start with a digit. i.e. 1 is a valid constructor
 *  identifier.
 *
 *  @see BOOST_MIRROR_REG_CONSTRUCTOR_BEGIN
 *  @see BOOST_MIRROR_REG_CLASS_BEGIN
 *  @see BOOST_MIRROR_REG_CLASS_END
 *  @see BOOST_MIRROR_REG_CONSTRUCTORS_BEGIN
 *  @see BOOST_MIRROR_REG_CONSTRUCTORS_END
 *  @ingroup registering_macros
 */
#define BOOST_MIRROR_REG_CONSTRUCTOR_END(ID)
#else
#define BOOST_MIRROR_REG_CONSTRUCTOR_END(ID) \
                size; \
        }; \
        static ctr_params_ ## ID ctr_params(ctr_index_ ## ID); \
        static custom_constructor_tag ctr_kind(ctr_index_ ## ID); \
        typedef std::integral_constant<int, ctr_index_ ## ID ::value + 1>
#endif

#ifdef BOOST_MIRROR_DOCUMENTATION_ONLY
/// Macro that ends the registering of a single class' constructor
/// Macro that registers a single parameter of a member function
/**
 *  This macro must be used between the BOOST_MIRROR_REG_MEM_FUNCTION_BEGIN
 *  and the BOOST_MIRROR_REG_MEM_FUNCTION_END macros. The parameters
 *  must be registered in the same order as they appear in the function.
 *
 *  @param TYPE the type of the parameter. If the class that this member
 *  function belongs to has a member variable with the same name as @a NAME
 *  you can use the special value '_'. If @c _ is used then the type of this
 *  function parameter is deduced from the type of the member variable @a NAME.
 *
 *  @param NAME the name of the parameter (an identifier not a string).
 *
 *  @see BOOST_MIRROR_REG_MEM_FUNCTION_BEGIN
 *  @see BOOST_MIRROR_REG_MEM_FUNCTION_END
 *  @see BOOST_MIRROR_REG_MEM_FUNCTIONS_BEGIN
 *  @see BOOST_MIRROR_REG_MEM_FUNCTIONS_END
 *  @ingroup registering_macros
 */
#define BOOST_MIRROR_REG_MEM_FUNCTION_PARAM(TYPE, NAME)
#else
#define BOOST_MIRROR_REG_MEM_FUNCTION_PARAM(TYPE, NAME) \
                param_idx_ ## NAME; \
                template <typename _That> \
                struct atr_typ_hlp_ ## NAME \
                { \
                        typedef decltype(attr_type((TYPE*)nullptr, &_That::NAME))\
                                type; \
                }; \
                template <typename _Type> \
                static boost::mirror::mp::identity<_Type> \
                get_type(_Type*, param_idx_ ## NAME); \
                static atr_typ_hlp_ ## NAME <_this> \
                get_type(_*, param_idx_ ## NAME);\
                static auto type(param_idx_ ## NAME pi) -> \
                        decltype(get_type((TYPE*)nullptr, pi)); \
                static const char* name( param_idx_ ## NAME) \
                { \
                        return #NAME; \
                } \
                static size_t name_length( param_idx_ ## NAME) \
                { \
                        return sizeof(#NAME) - 1; \
                } \
                typedef std::integral_constant<int, param_idx_ ## NAME ::value + 1>
#endif

#ifdef BOOST_MIRROR_DOCUMENTATION_ONLY
/// Macro that registers a single parameter of a constructor
/**
 *  This macro must be used between the BOOST_MIRROR_REG_CONSTRUCTOR_BEGIN
 *  and the BOOST_MIRROR_REG_CONSTRUCTOR_END macros. The parameters
 *  must be registered in the same order as they appear in the constructor.
 *
 *  @param TYPE the type of the parameter. If the class that this constructor
 *  belongs to has a member variable with the same name as @a NAME
 *  you can use the special value '_'. If @c _ is used then the type of this
 *  constructor parameter is deduced from the type of the member variable
 *  @a NAME.
 *
 *  @param NAME the name of the parameter (an identifier not a string).
 *
 *  @see BOOST_MIRROR_REG_CONSTRUCTOR_BEGIN
 *  @see BOOST_MIRROR_REG_CONSTRUCTOR_END
 *  @see BOOST_MIRROR_REG_CONSTRUCTORS_BEGIN
 *  @see BOOST_MIRROR_REG_CONSTRUCTORS_END
 *  @ingroup registering_macros
 */
#define BOOST_MIRROR_REG_CONSTRUCTOR_PARAM(TYPE, NAME)
#else
#define BOOST_MIRROR_REG_CONSTRUCTOR_PARAM(TYPE, NAME) \
        BOOST_MIRROR_REG_MEM_FUNCTION_PARAM(TYPE, NAME)
#endif

#ifdef BOOST_MIRROR_DOCUMENTATION_ONLY
/// Macro that begins the registering of the class' member functions
/**
 *  This macro must be used between the BOOST_MIRROR_REG_CLASS_BEGIN
 *  and the BOOST_MIRROR_REG_CLASS_END macros.
 *
 *  @see BOOST_MIRROR_REG_CLASS_BEGIN
 *  @see BOOST_MIRROR_REG_CLASS_END
 *  @see BOOST_MIRROR_REG_MEM_FUNCTIONS_END
 *  @ingroup registering_macros
 */
#define BOOST_MIRROR_REG_MEM_FUNCTIONS_BEGIN
#else
#define BOOST_MIRROR_REG_MEM_FUNCTIONS_BEGIN \
        typedef std::integral_constant<int, 0>
#endif

#ifdef BOOST_MIRROR_DOCUMENTATION_ONLY
/// Macro that ends the registering of the class' member functions
/**
 *  This macro must be used between the BOOST_MIRROR_REG_CLASS_BEGIN
 *  and the BOOST_MIRROR_REG_CLASS_END macros.
 *
 *  @see BOOST_MIRROR_REG_CLASS_BEGIN
 *  @see BOOST_MIRROR_REG_CLASS_END
 *  @see BOOST_MIRROR_REG_MEM_FUNCTIONS_BEGIN
 *  @ingroup registering_macros
 */
#define BOOST_MIRROR_REG_MEM_FUNCTIONS_END
#else
#define BOOST_MIRROR_REG_MEM_FUNCTIONS_END \
        memfn_count;
#endif

#ifdef BOOST_MIRROR_DOCUMENTATION_ONLY
/// Macro that ends the registering of a single class' member function
/**
 *  This macro must be used between the BOOST_MIRROR_REG_MEM_FUNCTIONS_BEGIN
 *  and the BOOST_MIRROR_REG_MEM_FUNCTIONS_END macros.
 *
 *  @param ACCESS_TYPE the access type specifier (private|protected|public|_)
 *  In case the special '_' specifier is used, then the access type is
 *  determined from the elaborated type specifier of the parent class
 *
 *  @param LINKAGE_TYPE the linkage type or storage class specifier
 *  for the member function (static|_).
 *
 *  @param RESULT_TYPE the type of the result of the member function.
 *
 *  @param NAME the name of the member function.
 *
 *  @param ID a unique identifier of the member function within
 *  the overloads with the same name.
 *  Same rules as for C++ identifiers apply except it is possible
 *  for the identifier to start with a digit. i.e. 1 is a valid member
 *  function identifier.
 *
 *  @see BOOST_MIRROR_REG_MEM_FUNCTION_END
 *  @see BOOST_MIRROR_REG_CLASS_BEGIN
 *  @see BOOST_MIRROR_REG_CLASS_END
 *  @see BOOST_MIRROR_REG_MEM_FUNCTIONS_BEGIN
 *  @see BOOST_MIRROR_REG_MEM_FUNCTIONS_END
 *  @ingroup registering_macros
 */
#define BOOST_MIRROR_REG_MEM_FUNCTION_BEGIN( \
        ACCESS_TYPE, \
        LINKAGE_TYPE, \
        RESULT_TYPE, \
        NAME, \
        ID \
)
#else
#define BOOST_MIRROR_REG_MEM_FUNCTION_BEGIN( \
        ACCESS_TYPE, \
        LINKAGE_TYPE, \
        RESULT_TYPE, \
        NAME, \
        ID \
) \
        memfn_idx_ ## NAME ## ID; \
        typedef  member< \
                spec_ ## ACCESS_TYPE ## _tag, \
                spec_ ## LINKAGE_TYPE ## _tag, \
                RESULT_TYPE \
        > memfn_ ## NAME ## ID; \
        static memfn_ ## NAME ## ID memfn_traits(memfn_idx_ ## NAME ## ID); \
        static const char* memfn_name( memfn_idx_ ## NAME ## ID) \
        { \
                return #NAME; \
        } \
        static size_t memfn_name_length( memfn_idx_ ## NAME ## ID) \
        { \
                return sizeof(#NAME) - 1; \
        } \
        template <typename _That> \
        struct memfn_wrapper_ ## NAME ## ID \
        { \
                _That& instance; \
                memfn_wrapper_ ## NAME ## ID(_That& inst) \
                 : instance(inst) \
                { } \
                \
                template <typename ... _Params > \
                RESULT_TYPE operator()(_Params ... params) const \
                { \
                        return instance.NAME(params ... ); \
                } \
        };\
        struct memfn_params_ ## NAME ## ID \
        { \
                typedef std::integral_constant<int, 0>
#endif

#ifdef BOOST_MIRROR_DOCUMENTATION_ONLY
/// Macro that ends the registering of a single class' member function
/**
 *  This macro must be used between the BOOST_MIRROR_REG_MEM_FUNCTIONS_BEGIN
 *  and the BOOST_MIRROR_REG_MEM_FUNCTIONS_END macros.
 *
 *  @param NAME the name of the parameter (an identifier not a string).
 *
 *  @param ID a unique identifier of the member function within
 *  the overloads with the same name.
 *  Same rules as for C++ identifiers apply except it is possible
 *  for the identifier to start with a digit. i.e. 1 is a valid member
 *  function identifier.
 *
 *  @param CONST the constness specifier. Can be either @c non_const or @c _
 *  for non-const member functions or @c const for const member functions.
 *
 *  @see BOOST_MIRROR_REG_MEM_FUNCTION_BEGIN
 *  @see BOOST_MIRROR_REG_CLASS_BEGIN
 *  @see BOOST_MIRROR_REG_CLASS_END
 *  @see BOOST_MIRROR_REG_MEM_FUNCTIONS_BEGIN
 *  @see BOOST_MIRROR_REG_MEM_FUNCTIONS_END
 *  @ingroup registering_macros
 */
#define BOOST_MIRROR_REG_MEM_FUNCTION_END(NAME, ID, CONST)
#else
#define BOOST_MIRROR_REG_MEM_FUNCTION_END(NAME, ID, CONST) \
                size; \
        }; \
        static memfn_params_ ## NAME ## ID memfn_params( \
                memfn_idx_ ## NAME ## ID \
        ); \
        static spec_ ## CONST ## _tag memfn_constness(memfn_idx_ ## NAME ## ID);\
        static memfn_wrapper_ ## NAME ## ID < \
                aux::memfn_inst_type<spec_ ## CONST ## _tag, _this>::type  \
        > memfn_wrapper( \
                memfn_idx_ ## NAME ## ID, \
                aux::memfn_inst_type<spec_ ## CONST ## _tag, _this>::type& inst\
        ) \
        { \
                return memfn_wrapper_ ## NAME ## ID < \
                        aux::memfn_inst_type<spec_ ## CONST ## _tag, _this>::type\
                >(inst); \
        } \
        typedef std::integral_constant<int, memfn_idx_ ## NAME ## ID ::value + 1>
#endif

#ifdef BOOST_MIRROR_DOCUMENTATION_ONLY
/// Macro for the registering of types the class is convertible to
/** This macro allows to register the other types that the currently
 *  registered class is convertible into, i.e. has the apropriate
 *  conversion operators.
 *
 *  This macro must be used between the BOOST_MIRROR_REG_CLASS_BEGIN
 *  and the BOOST_MIRROR_REG_CLASS_END macros.
 *
 *  @param TYPELIST the comma separated list of fully qualified types
 *  enclosed in parentheses.
 *
 *  @code
 *  BOOST_MIRROR_REG_CLASS_BEGIN(class, myproject, X)
 *    BOOST_MIRROR_REG_CLASS_CONVERSIONS((::myproject::Y, ::myproject::Z))
 *  BOOST_MIRROR_REG_CLASS_END
 *  @endcode
 *
 *  @see BOOST_MIRROR_REG_CLASS_BEGIN
 *  @see BOOST_MIRROR_REG_CLASS_END
 *  @ingroup registering_macros
 */
#define BOOST_MIRROR_REG_CLASS_CONVERSIONS(TYPELIST)
#else
#define BOOST_MIRROR_REG_CLASS_CONVERSIONS(TYPELIST) \
        typedef mp::range< \
                BOOST_MIRROR_PP_EXPAND_ARGS TYPELIST \
        > conv_ops;
#endif

#ifdef BOOST_MIRROR_DOCUMENTATION_ONLY
/// Grants access to private members of a class to Mirror
/** This macro is used to grant access to private and protected
 *  members of the class @a CLASS to Mirror's meta-objects.
 *  It should be used inside of class declaration and basically
 *  translates into one or several 'friend' declarations.
 *
 *  This macro is necessary if you want to reflect non-public
 *  member variables of a class directly i.e. without using
 *  public getter / setter member functions.
 *
 *  @see BOOST_MIRROR_REG_CLASS_MEM_VARS_BEGIN
 *  @see BOOST_MIRROR_REG_CLASS_MEM_VARS_END
 *  @see BOOST_MIRROR_REG_CLASS_MEM_VAR_GET_SET
 *  @see BOOST_MIRROR_REG_CLASS_MEM_VAR
 *
 *  @ingroup registering_macros
 */
#define BOOST_MIRROR_FRIENDLY_CLASS(CLASS)
#else
#define BOOST_MIRROR_FRIENDLY_CLASS(CLASS) \
        friend class boost::mirror::_class::_< CLASS >
#endif

template <class Class, class BaseMetaInheritance>
struct meta_inheritance
{
        typedef meta_class<Class> derived_class;

        typedef typename aux::inheritance_type_tag<
                typename BaseMetaInheritance::inherit
        >::type inheritance_type;

        typedef typename aux::access_type_tag<
                typename _class::_<Class>::kind,
                typename BaseMetaInheritance::access
        >::type access_type;

        typedef meta_class<typename BaseMetaInheritance::base> base_class;
};


template <class Class, int Index>
struct meta_member_variable
{
public:
        typedef std::integral_constant<int, Index> position;
private:
        // Get the base traits of the type from the registered function
        typedef decltype(boost::mirror::_class::_<Class>::attr_traits(
                position()
        )) base_traits;
public:

        typedef meta_class< Class > scope;

        typedef typename aux::access_type_tag<
                typename boost::mirror::_class::_<Class>::kind,
                typename base_traits::access_type
        >::type access_type;

        typedef typename aux::storage_class_tag_mv<
                typename base_traits::storage_class
        >::type storage_class;

        typedef typename aux::reflect_type<
                typename base_traits::type_sel
        >::type type;

private:
        template <typename Local>
        static std::string make_name(Local local)
        {
                // get the full or local name of the scope
                std::string result(
                        Local::value ?
                        scope::local_name() :
                        scope::full_name()
                );
                // append the separating double colon
                result.append("::");
                // and append the base name of this member variable
                result.append(base_name());
                // return the result
                return result;
        }
public:
        // returns the base name of the member variable
        static std::string base_name(void)
        {
                return std::string(
                        boost::mirror::_class::_<Class>::attr_name(position()),
                        boost::mirror::_class::_<Class>::attr_name_length(position())
                );
        }

        // returns the full name (including the full nested name qualifier)
        static std::string full_name(void)
        {
                return make_name(std::false_type());
        }

        // returns the local name (including partial nested name qualifier)
        static std::string local_name(void)
        {
                return make_name(std::true_type());
        }

        // returns the value of the member when given a reference to Class
        static auto get(const Class& inst) ->
        decltype(boost::mirror::_class::_<Class>::get(position(), inst))
        {
                return boost::mirror::_class::_<Class>::get(
                        position(),
                        inst
                );
        }

        // sets the value of the member when given a reference to Class
        template <typename ValueType>
        static void set(Class& inst, const ValueType& value)
        {
                boost::mirror::_class::_<Class>::set(
                        position(),
                        inst,
                        value
                );
        }

private:
        typedef decltype(boost::mirror::_class::_<Class>::has_address(position()))
                has_address;

        friend struct meta_object_category<meta_member_variable>;
public:
        // gets the address of the member variable if possible
        // users should always check if the meta-variable conforms
        // to MetaPlainMemberVariable before trying to call address()
        static auto address(Class& inst) ->
        decltype(boost::mirror::_class::_<Class>::address(position(), inst))
        {
                return boost::mirror::_class::_<Class>::address(
                        position(),
                        inst
                );
        }

        // gets the address of the member variable if possible
        static auto address(const Class& inst) ->
        decltype(boost::mirror::_class::_<Class>::address(position(), inst))
        {
                return boost::mirror::_class::_<Class>::address(
                        position(),
                        inst
                );
        }

        // gets the address of the member variable if possible
        static auto member_pointer(void) ->
        decltype(boost::mirror::_class::_<Class>::mem_ptr(position()))
        {
                return boost::mirror::_class::_<Class>::mem_ptr(position());
        }

        // NOTE: internal implementation detail do not use
        template <typename X>
        struct _by_name_typ
        {
                typedef decltype(
                        boost::mirror::_class::_<Class>::by_name_typ(
                                position(),
                                (X*)nullptr
                        )
                ) type;
        };

        // NOTE: internal implementation detail do not use
        template <typename X>
        struct _by_name_val
        {
                typedef decltype(
                        boost::mirror::_class::_<Class>::by_name_val(
                                position(),
                                (X*)nullptr
                        )
                ) type;
        };
};

template <class Class, int Index>
struct meta_object_category< meta_member_variable<Class, Index> >
{
private:
        typedef meta_member_variable<Class, Index> mmv;

        static meta_member_variable_tag _get_type(std::false_type);

        static meta_plain_member_variable_tag _get_type(std::true_type);
public:
        typedef decltype(_get_type(typename mmv::has_address())) type;
};

template <class Class>
struct meta_class
 : public meta_type<Class>
{
        typedef typename aux::elaborated_type_tag<
                typename _class::_<Class>::kind
        >::type elaborated_type;
};

#ifdef BOOST_MIRROR_DOCUMENTATION_ONLY
/// Reflects the class passed as the @a FULL_CLASS_NAME argument
/**
 *  This macro expands into a type conforming to the MetaClass
 *  concept, which provides meta-data about the given class.
 *  The class name passed as the @a FULL_CLASS_NAME argument
 *  should be a fully qualified class name.
 *
 *  @see BOOST_MIRROR_REG_CLASS_BEGIN
 *  @see BOOST_MIRROR_REG_CLASS_END
 *  @see boost::mirror::MetaClass
 *  @see boost::mirror::reflected
 *  @see boost::lagoon::reflected_type
 *  @see boost::lagoon::reflected_class
 *
 *  @ingroup reflection_macros
 */
#define BOOST_MIRRORED_CLASS(FULL_CLASS_NAME) boost::mirror::MetaClass
#else
#define BOOST_MIRRORED_CLASS(FULL_CLASS_NAME) \
        boost::mirror::meta_class< FULL_CLASS_NAME >
#endif

#ifdef BOOST_MIRROR_DOCUMENTATION_ONLY
/// Reflects the specified member function of a class
/**
 *  This macro expands into a type conforming to the MetaMemberFunction
 *  concept, which provides meta-data about the specified
 *  class member function.
 *  The class name passed as the @a FULL_CLASS_NAME argument
 *  should be a fully qualified class name.
 *
 *  @see BOOST_MIRROR_REG_MEM_FUNCTION_BEGIN
 *  @see BOOST_MIRROR_REG_MEM_FUNCTION_END
 *  @see boost::mirror::MetaMemberFunction
 *
 *  @ingroup reflection_macros
 */
#define BOOST_MIRRORED_MEMBER_FUNCTION(FULL_CLASS_NAME, FUNCTION, SELECTOR) \
        boost::mirror::MetaMemberFunction
#else
#define BOOST_MIRRORED_MEMBER_FUNCTION(FULL_CLASS_NAME, FUNCTION, SELECTOR) \
        boost::mirror::mp::at< \
                boost::mirror::member_functions< \
                        BOOST_MIRRORED_CLASS(FULL_CLASS_NAME) \
                >::type, \
                boost::mirror::_class::_< FULL_CLASS_NAME >:: \
                memfn_idx_ ## FUNCTION ## SELECTOR \
        >::type
#endif

// The implementation of base_classes for instantiation of meta_class
template <class Class>
struct base_classes<meta_class<Class> >
{
        // A range of MetaInheritances reflecting the base-classes
        typedef typename aux::base_classes_helper<
                Class,
                typename _class::_<Class>::base_classes
        >::type type;
};

// The implementation of member_variables for instantiation of meta_class
template <class Class>
struct member_variables<meta_class<Class> >
{
        // A range of MetaMemberVariables reflecting the member variables
        typedef typename mp::apply_on_seq_pack<
                aux::mem_var_helper<Class>,
                typename boost::mirror::_class::_<Class>::attr_count
        >::type type;
};

// The implementation of the class_layout meta-function for meta-classes
template <class Class>
struct class_layout<meta_class<Class> >
{
private:
        typedef aux::class_layout_helper<
                typename base_classes<
                        meta_class<Class>
                >::type,
                meta_class<Class>,
                spec_non_virtual_tag
        > helper;
public:

        // the resulting range contains MetaClass(es)
        // in an order reflecting the layout of the class
        typedef typename mp::concat<
                typename mp::unique<typename helper::virt>::type,
                typename helper::reg
        >::type type;
};

// Implementation of the all_member_variables meta-function for meta-classes
template <class Class>
struct all_member_variables<meta_class<Class> >
{
        // the returned range contains MetaMemberVariables
        // reflecting the individual member variables of the Class
        typedef typename mp::fold<
                class_layout<meta_class<Class> >,
                mp::range<>,
                mp::concat<
                        mp::arg<1>,
                        member_variables<mp::arg<2> >
                >
        >::type type;
};


// implementation of the meta_constructor template
template <typename Type, int Index>
class meta_constructor
 : public aux::scoped_named_impl<
        aux::meta_constructor_base<Type, Index>
>
{
public:
        typedef std::integral_constant<int, Index> position;
        // the scope of the constructor
        typedef meta_class< Type > scope;

        typedef typename aux::access_type_tag<
                typename _class::_<Type>::kind,
                decltype(_class::_<Type>::ctr_access(position()))
        >::type access_type;

        // the result of the constructor
        typedef typename aux::reflect_type<Type>::type result_type;
        typedef spec_static_tag storage_class;
        typedef spec_static_tag linkage;

        typedef decltype(_class::_<Type>::ctr_kind(position())) kind;
};

// The implementation of constructors for instantiations of meta_class
template <class Type>
struct constructors<meta_type<Type> >
{
        // A range of MetaMemberVariables reflecting the member variables
        typedef typename mp::apply_on_seq_pack<
                aux::constructor_helper<Type>,
                typename boost::mirror::_class::_<Type>::ctr_count
        >::type type;
};

// The implementation of constructors for instantiations of meta_class
template <class Class>
struct constructors<meta_class<Class> >
 : constructors<meta_type<Class> >
{ };

// Implementation of meta_constructor_param template
template <typename Type, int ConstrIndex, int ParamIndex>
struct meta_constructor_param
 : public aux::scoped_named_impl<
        aux::meta_ctr_param_base<
                Type,
                ConstrIndex,
                ParamIndex
        >
>
{
private:
        typedef boost::mirror::_class::_<Type> base_meta_type;
        typedef decltype(
                base_meta_type::ctr_params(
                        std::integral_constant<int, ConstrIndex>()
                ).type(
                        std::integral_constant<int, ParamIndex>()
                )
        ) type_helper;
public:
        typedef spec_auto_tag storage_class;

        typedef meta_constructor<Type, ConstrIndex> scope;

        typedef typename aux::reflect_type<
                typename type_helper::type
        >::type type;

        // the type of the constructor parameter
        typedef std::integral_constant<int, ParamIndex> position;
};

// Implementation of the parameters meta-function template class
template <typename Type, int ConstrIndex>
struct parameters<meta_constructor<Type, ConstrIndex> >
{
private:
        typedef decltype(
                boost::mirror::_class::_<Type>
                ::ctr_params(
                        std::integral_constant<int, ConstrIndex >()
                )
        ) size_helper;
public:
        // A range of MetaVariables reflecting
        // the parameters of a meta-constructor
        typedef typename mp::apply_on_seq_pack<
                aux::ctr_param_helper<Type, ConstrIndex>,
                typename size_helper::size
        >::type type;
};

// implementation of the meta_initializer template
template <typename Type>
class meta_initializer
 : public aux::scoped_named_impl<
        aux::meta_ctr_base_base<Type>
>
{
public:
        typedef std::integral_constant<int, -1> position;
        // the scope of the constructor
        typedef meta_class< Type > scope;

        typedef spec_public_tag access_type;

        typedef typename aux::reflect_type<Type>::type result_type;
        typedef spec_static_tag storage_class;
        typedef spec_static_tag linkage;

        typedef struct_initializer_tag kind;
};

// Implementation of meta_constructor_param template
template <typename Type>
struct meta_initializer_param
 : public aux::scoped_named_impl<aux::meta_initlzr_param_base<Type> >
{
        typedef spec_auto_tag storage_class;

        typedef meta_initializer<Type> scope;

        typedef typename aux::reflect_type<Type>::type type;

        typedef std::integral_constant<int, 0> position;
};

// Implementation of the parameters meta-function template class
template <typename Type>
struct parameters<meta_initializer<Type> >
{
        typedef mp::range<meta_initializer_param<Type> > type;
};


// implementation of the meta_member_function template
template <typename Class, int Index>
class meta_member_function
 : public aux::scoped_named_impl<
        aux::meta_mem_function_base<Class, Index>
>
{
public:
        typedef std::integral_constant<int, Index> position;
private:
        typedef decltype(_class::_<Class>::memfn_traits(
                position()
        )) base_traits;
public:
        typedef boost::mirror::meta_class<Class> scope;

        typedef typename aux::access_type_tag<
                typename _class::_<Class>::kind,
                typename base_traits::access_type
        >::type access_type;

        typedef typename aux::storage_class_tag_mf<
                typename base_traits::storage_class
        >::type storage_class;
        typedef storage_class linkage;

        // the result of the constructor
        typedef typename aux::reflect_type<
                typename base_traits::type_sel
        >::type result_type;

        typedef typename aux::constness_tag<
                decltype(_class::_<Class>::memfn_constness(position()))
        >::type constness;

        // makes an instance of the wrapper which allows
        // to call the member function reflected by this
        // MetaMemberFunction
        static inline auto wrap(Class& instance) ->
        decltype(_class::_<Class>::memfn_wrapper(
                position(),
                instance
        ))
        {
                return _class::_<Class>::memfn_wrapper(
                        position(),
                        instance
                );
        }
};

// The implementation of member_functions for instantiations of meta_class
template <class Class>
struct member_functions<meta_class<Class> >
{
        // A range of MetaMemberFunctions reflecting the member functions
        typedef typename mp::apply_on_seq_pack<
                aux::mem_function_helper<Class>,
                typename boost::mirror::_class::_<Class>::memfn_count
        >::type type;
};

template <typename Class, int MemFnIndex, int ParamIndex>
struct meta_mem_function_param
 : public aux::scoped_named_impl<
        aux::meta_memfn_param_base<
                Class,
                MemFnIndex,
                ParamIndex
        >
>
{
private:
        typedef boost::mirror::_class::_<Class> base_meta_type;
        typedef decltype(
                base_meta_type::memfn_params(
                        std::integral_constant<int, MemFnIndex>()
                ).type(
                        std::integral_constant<int, ParamIndex>()
                )
        ) type_helper;
public:
        typedef spec_auto_tag storage_class;

        typedef meta_member_function<Class, MemFnIndex> scope;

        // the type of the function parameter
        typedef meta_class< typename type_helper::type > type;

        // the position of the function parameter
        typedef std::integral_constant<int, ParamIndex> position;

};


// Implementation of the parameters meta-function template class
template <typename Class, int MemFnIndex>
struct parameters<meta_member_function<Class, MemFnIndex> >
{
private:
        typedef decltype(
                boost::mirror::_class::_<Class>
                ::memfn_params(
                        std::integral_constant<int, MemFnIndex >()
                )
        ) size_helper;
public:
        // A range of MetaVariables reflecting
        // the parameters of a meta-constructor
        typedef typename mp::apply_on_seq_pack<
                aux::memfn_param_helper<Class, MemFnIndex>,
                typename size_helper::size
        >::type type;
};


// implementation of the meta_conversion_operator template
template <typename Class, typename Result>
class meta_conversion_operator
 : public aux::scoped_named_impl<
        aux::meta_conv_op_base<Class, Result>
>
{
public:
        typedef boost::mirror::meta_class<Class> scope;

        typedef spec_public_tag access_type;

        typedef spec_auto_tag storage_class;
        typedef spec_auto_tag linkage;

        typedef boost::mirror::meta_class<Result> result_type;
};

// The implementation of conversions for instantiations of meta_class
template <class Class>
struct conversions<meta_class<Class> >
{
private:
        typedef boost::mirror::_class::_<Class> base_meta_class;
public:
        // A range of MetaConversionOperators reflecting the conversions
        typedef typename aux::conv_op_helper<
                Class,
                typename base_meta_class::conv_ops
        >::type type;
};


// Implementation of the parameters meta-function template class
template <typename Class, typename Result>
struct parameters<meta_conversion_operator<Class, Result> >
{
public:
        // An empty range reflecting
        // the parameters of a conversion operator
        typedef typename mp::range<> type;
};


// Implementation of the members meta-function for constructors
template <typename Type, int ConstrIndex>
struct members<meta_constructor<Type, ConstrIndex> >
{
        typedef typename parameters<
                meta_constructor<Type, ConstrIndex>
        >::type type;
};

template <typename Type>
struct members<meta_initializer<Type> >
{
        typedef typename parameters<meta_initializer<Type> >::type type;
};

// Implementation of the members meta-function for functions
template <typename Type, int MemFnIndex>
struct members<meta_member_function<Type, MemFnIndex> >
{
        typedef typename parameters<
                meta_member_function<Type, MemFnIndex>
        >::type type;
};

// Implementation of the members meta-function for conversion operators
template <typename Class, typename Result>
struct members<meta_conversion_operator<Class, Result> >
{
        typedef typename parameters<
                meta_conversion_operator<Class, Result>
        >::type type;
};

// Implementation of the members meta-function for classes
template <class Class>
struct members<meta_class<Class> >
{
        //TODO: this should be finished when other class members
        // are supported
        typedef typename all_member_variables<
                meta_class<Class>
        >::type type;
};

BOOST_MIRROR_NAMESPACE_END

#endif //include guard

