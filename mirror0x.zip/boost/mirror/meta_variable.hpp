/**
 * @file boost/mirror/meta_variable.hpp
 * @brief Reflection of meta-variables
 *
 *  Copyright 2008-2011 Matus Chochlik. Distributed under the Boost
 *  Software License, Version 1.0. (See accompanying file
 *  LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
 */

#ifndef BOOST_MIRROR_META_VARIABLE_1103251718_HPP
#define BOOST_MIRROR_META_VARIABLE_1103251718_HPP

#include <boost/mirror/mirror_fwd.hpp>
#include <boost/mirror/tag_dispatch.hpp>
#include <boost/mirror/meta_namespace.hpp>
#include <boost/mirror/auxiliary/default_spec_tags.hpp>
#include <boost/mirror/meta_prog/only_if.hpp>
#include <type_traits>

BOOST_MIRROR_NAMESPACE_BEGIN

template <typename VariableSelector>
struct meta_free_variable
 : aux::scoped_named_impl< VariableSelector >
{
        typedef typename boost::mirror::aux::storage_class_tag_fv<
                typename VariableSelector::storage_class
        >::type storage_class;

        typedef typename boost::mirror::aux::full_meta_object<
                typename VariableSelector::scope
        >::type scope;

        typedef typename boost::mirror::reflected<
                typename VariableSelector::type
        >::type type;

        static auto get(void) -> decltype(VariableSelector::get())
        {
                return VariableSelector::get();
        }

        static void set(typename VariableSelector::type val)
        {
                VariableSelector::set(val);
        }
private:
        typedef decltype(VariableSelector::has_address()) has_address;

        friend struct meta_object_category<meta_free_variable>;
public:

        static auto address(void) -> decltype(VariableSelector::address())
        {
                return VariableSelector::address();
        }

        // NOTE: internal implementation detail do not use
        template <typename X>
        struct _by_name_typ
        {
                typedef typename VariableSelector::template by_name_typ<X> type;
        };

        // NOTE: internal implementation detail do not use
        template <typename X>
        struct _by_name_val
        {
                typedef typename VariableSelector::template by_name_val<X> type;
        };
};

//  Specialization of meta_object_category for meta_member_variables(s)
template <typename Selector>
struct meta_object_category<meta_free_variable<Selector> >
{
private:
        typedef meta_free_variable<Selector> mfv;

        static meta_free_variable_tag _get_type(std::false_type);

        static meta_plain_free_variable_tag _get_type(std::true_type);
public:
        typedef decltype(_get_type(typename mfv::has_address())) type;
};

// The implementation of free_variables for instantiation of meta_namespace
template <class X>
struct free_variables<meta_namespace<X> >
{
        typedef typename mp::only_if<
                typename members<meta_namespace<X> >::type,
                mp::is_a<mp::arg<1>, meta_free_variable_tag>
        >::type type;
};

#define BOOST_MIRROR_REG_FREE_VARIABLE_COMMON_HLPR(STORAGE_CLASS, VARIABLE) \
        typedef boost::mirror::spec_ ## STORAGE_CLASS ## _tag storage_class; \
        BOOST_MIRROR_IMPLEMENT_META_OBJECT_NAME_FUNCTIONS(#VARIABLE) \
        template <typename X> \
        struct by_name_typ \
        { \
                typedef X VARIABLE; \
        }; \
        template <typename X> \
        struct by_name_val \
        { \
                X VARIABLE; \
                by_name_val(void) = default; \
                template <class Parent, typename Param> \
                by_name_val(Parent& parent, Param param) \
                 : VARIABLE(parent, param) \
                { } \
        };

#ifdef BOOST_MIRROR_DOCUMENTATION_ONLY
/// This macro registers a variable from the global scope with Mirror
/**
 *  @param STORAGE_CLASS the storage class of the variable. _ is the default.
 *  @param VARIABLE the variable name
 *
 *  @see BOOST_MIRROR_REG_FREE_VARIABLE
 *  @ingroup registering_macros
 */
#define BOOST_MIRROR_REG_GLOBAL_SCOPE_VARIABLE(STORAGE_CLASS, VARIABLE)
#else
#define BOOST_MIRROR_REG_GLOBAL_SCOPE_VARIABLE(STORAGE_CLASS, VARIABLE) \
namespace _variable { \
template <typename Namespace> struct _ ## VARIABLE ; \
template <> struct _ ## VARIABLE< boost::mirror::_namespace::_ >\
{  \
        BOOST_MIRROR_REG_FREE_VARIABLE_COMMON_HLPR(STORAGE_CLASS, VARIABLE) \
        typedef decltype(VARIABLE) type; \
        typedef boost::mirror::_namespace::_ scope; \
        static inline type get(void) { return :: VARIABLE; } \
        static inline void set(type val) { :: VARIABLE = val; } \
        static inline type* address(void) { return & :: VARIABLE; } \
        static std::true_type has_address(void); \
}; \
} BOOST_MIRROR_ADD_TO_GLOBAL_LIST( \
        boost::mirror::_namespace::_, \
        boost::mirror::meta_free_variable< \
        boost::mirror::_variable::_ ## VARIABLE< \
        boost::mirror::_namespace::_ \
        > > \
)
#endif

#ifdef BOOST_MIRROR_DOCUMENTATION_ONLY
/// This macro registers a variable from the a namespace with Mirror
/**
 *  @param STORAGE_CLASS the storage class of the variable. _ is the default.
 *  @param NAMESPACE full name of the namespace where the variable is defined
 *  @param VARIABLE the variable name
 *
 *  @see BOOST_MIRROR_REG_FREE_VARIABLE
 *  @ingroup registering_macros
 */
#define BOOST_MIRROR_REG_FREE_VARIABLE(STORAGE_CLASS, NAMESPACE, VARIABLE)
#else
#define BOOST_MIRROR_REG_FREE_VARIABLE(STORAGE_CLASS, NAMESPACE, VARIABLE) \
namespace _variable { \
template <typename Namespace> struct _ ## VARIABLE ; \
template <> struct _ ## VARIABLE< boost::mirror::_namespace:: NAMESPACE ::_ >\
{  \
        BOOST_MIRROR_REG_FREE_VARIABLE_COMMON_HLPR(STORAGE_CLASS, VARIABLE) \
        typedef decltype(NAMESPACE :: VARIABLE) type; \
        typedef boost::mirror::_namespace:: NAMESPACE ::_ scope; \
        static inline type get(void) { return :: NAMESPACE :: VARIABLE; } \
        static inline void set(type val) { :: NAMESPACE :: VARIABLE = val; } \
        static inline type* address(void) { return & :: NAMESPACE :: VARIABLE;}\
        static std::true_type has_address(void); \
}; \
} BOOST_MIRROR_ADD_TO_GLOBAL_LIST( \
        boost::mirror::_namespace:: NAMESPACE ::_, \
        boost::mirror::meta_free_variable< \
        boost::mirror::_variable::_ ## VARIABLE< \
        boost::mirror::_namespace:: NAMESPACE ::_ \
        > > \
)
#endif


#ifdef BOOST_MIRROR_DOCUMENTATION_ONLY
/// Reflects the variable @a VARIABLE defined in the @a NAMESPACE namespace
/**
 *  This macro expands into a type conforming to the MetaFreeVariable
 *  concept, which provides meta-data about the given variable.
 *
 *  @see BOOST_MIRRORED_GLOBAL_SCOPE_VARIABLE
 *  @see BOOST_MIRROR_REG_FREE_VARIABLE
 *  @see boost::mirror::MetaFreeVariable
 *
 *  @ingroup reflection_macros
 */
#define BOOST_MIRRORED_FREE_VARIABLE(NAMESPACE, VARIABLE) boost::mirror::MetaFreeVariable
#else
#define BOOST_MIRRORED_FREE_VARIABLE(NAMESPACE, VARIABLE) \
        boost::mirror::meta_free_variable< \
        boost::mirror::_variable::_ ## VARIABLE< \
        boost::mirror::_namespace::NAMESPACE::_ \
        > >
#endif

#ifdef BOOST_MIRROR_DOCUMENTATION_ONLY
/// Reflects the variable @a VARIABLE defined in the global scope
/**
 *  This macro expands into a type conforming to the MetaFreeVariable
 *  concept, which provides meta-data about the given variable.
 *
 *  @see BOOST_MIRRORED_FREE_VARIABLE
 *  @see BOOST_MIRROR_REG_FREE_VARIABLE
 *  @see boost::mirror::MetaFreeVariable
 *
 *  @ingroup reflection_macros
 */
#define BOOST_MIRRORED_GLOBAL_SCOPE_VARIABLE(VARIABLE) boost::mirror::MetaFreeVariable
#else
#define BOOST_MIRRORED_GLOBAL_SCOPE_VARIABLE(VARIABLE) \
        boost::mirror::meta_free_variable< \
        boost::mirror::_variable::_ ## VARIABLE< \
        boost::mirror::_namespace::_ \
        > >
#endif

namespace aux {

template <typename StorageClassTag>
struct meta_simple_var
{
        typedef boost::mirror::meta_variable_tag category;
        typedef typename boost::mirror::aux::storage_class_tag_fv<
                StorageClassTag
        >::type storage_class;
        typedef BOOST_MIRRORED_UNSPECIFIED_SCOPE() scope;
};

} // namespace aux

#ifdef BOOST_MIRROR_DOCUMENTATION_ONLY
/// Reflects the meta_object passed as the @a META_OBJECT argument
/**
 *  This macro expands into a type conforming to the MetaMetaObject
 *  concept, which provides meta-data about the given Mirror's MetaObject.
 *  The type name passed as the @a META_TYPE argument
 *  must by a valid Mirror's meta-object.
 *
 *  @see boost::mirror::Meta Variable
 *
 *  @ingroup reflection_macros
 */
#define BOOST_MIRRORED_SIMPLE_VARIABLE(STORAGE_CLASS, VARIABLE) boost::mirror::MetaVariable
#else
#define BOOST_MIRRORED_SIMPLE_VARIABLE(STORAGE_CLASS, VARIABLE) \
struct _mirror_meta_simple_var_ ## VARIABLE \
 : boost::mirror::aux::meta_simple_var< \
        boost::mirror::spec_ ## STORAGE_CLASS ## _tag \
> \
{ \
        typedef boost::mirror::reflected<decltype(VARIABLE)>::type type; \
        static std::string base_name(void) \
        { \
                return std::string(#VARIABLE, sizeof(#VARIABLE) - 1); \
        } \
        static inline std::string full_name(void) { return base_name(); } \
        static inline std::string local_name(void) { return base_name(); } \
}
#endif


BOOST_MIRROR_NAMESPACE_END

#endif //include guard

