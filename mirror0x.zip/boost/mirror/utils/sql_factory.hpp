/**
 * @file boost/mirror/utils/sql_factory.hpp
 * @brief Framework for creating SQL-dataset-based factory generator plugins
 *
 *  Copyright 2008-2011 Matus Chochlik. Distributed under the Boost
 *  Software License, Version 1.0. (See accompanying file
 *  LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
 */

#ifndef BOOST_MIRROR_UTILS_SQL_FACTORY_1011291729_HPP
#define BOOST_MIRROR_UTILS_SQL_FACTORY_1011291729_HPP

#include <boost/mirror/config.hpp>

// sql factory-related
#include <boost/mirror/utils/sql_factory/helper.hpp>
#include <boost/mirror/utils/sql_factory/pool.hpp>
#include <boost/mirror/utils/sql_factory/manager.hpp>
#include <boost/mirror/utils/sql_factory/native_source.hpp>
#include <boost/mirror/utils/sql_factory/default_source.hpp>
#include <boost/mirror/utils/sql_factory/enumerator.hpp>
#include <boost/mirror/utils/sql_factory/default_traits.hpp>

BOOST_MIRROR_NAMESPACE_BEGIN

BOOST_MIRROR_NAMESPACE_END

#endif //include guard

