/**
 * @file boost/mirror/utils/sdn_factory.hpp
 * @brief Framework for creating structured data notation factory plugins
 *
 *  Copyright 2008-2010 Matus Chochlik. Distributed under the Boost
 *  Software License, Version 1.0. (See accompanying file
 *  LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
 */

#ifndef BOOST_MIRROR_UTILS_SDN_FACTORY_1011291729_HPP
#define BOOST_MIRROR_UTILS_SDN_FACTORY_1011291729_HPP

#include <boost/mirror/config.hpp>
#include <boost/mirror/factory.hpp>

#include <boost/mirror/using_directive.hpp>
// script factory-related
#include <boost/mirror/utils/native_types.hpp>
#include <boost/mirror/utils/sdn_factory/fwd_decl.hpp>
#include <boost/mirror/utils/sdn_factory/error.hpp>
#include <boost/mirror/utils/sdn_factory/default_traits.hpp>
#include <boost/mirror/utils/sdn_factory/handlers.hpp>
#include <boost/mirror/utils/sdn_factory/suppliers.hpp>
#include <boost/mirror/utils/sdn_factory/default_source.hpp>
#include <boost/mirror/utils/sdn_factory/native_source.hpp>
#include <boost/mirror/utils/sdn_factory/initlist_source.hpp>
#include <boost/mirror/utils/sdn_factory/enumerator.hpp>
#include <boost/mirror/utils/sdn_factory/manager.hpp>
#include <boost/mirror/utils/sdn_factory/data.hpp>

BOOST_MIRROR_NAMESPACE_BEGIN

template <class Product, class Traits>
class sdn_fact_manuf
 : public aux::sdn_fact_source<
        Product,
        Traits,
        typename is_util_native_type<Product>::type
>
{
private:
        typedef aux::sdn_fact_source<
                Product,
                Traits,
                typename is_util_native_type<Product>::type
        > base_class;
        typedef aux::sdn_fact_param<Traits> param_type;
public:
        //TODO: this can be replaced with inherited constructors
        template <class ConstructionInfo>
        inline sdn_fact_manuf(
                const param_type& parent_data,
                ConstructionInfo construction_info
        ): base_class(parent_data, construction_info)
        { }
};

template <class Element, class Traits>
class sdn_fact_manuf<
        std::initializer_list<Element>,
        Traits
> : public aux::sdn_fact_seq_source<Element, Traits>
{
private:
        typedef aux::sdn_fact_seq_source<
                Element,
                Traits
        > base_class;
        typedef aux::sdn_fact_param<Traits> param_type;
public:
        //TODO: this can be replaced with inherited constructors
        template <class ConstructionInfo>
        inline sdn_fact_manuf(
                const param_type& parent_data,
                ConstructionInfo construction_info
        ): base_class(parent_data, construction_info)
        { }
};

BOOST_MIRROR_NAMESPACE_END

#endif //include guard

