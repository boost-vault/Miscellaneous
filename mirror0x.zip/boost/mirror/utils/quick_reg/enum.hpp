/**
 * .file boost/mirror/utils/quick_reg/pod_class.hpp
 * .brief Boost.Preprocessor-based quicke registering macros
 *
 *  Do not include directly, include boost/mirror/utils/quick_reg.hpp
 *
 *  Copyright 2008-2011 Matus Chochlik. Distributed under the Boost
 *  Software License, Version 1.0. (See accompanying file
 *  LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
 */

#ifndef BOOST_MIRROR_UTILS_QUICK_REG_ENUM_1011291729_HPP
#define BOOST_MIRROR_UTILS_QUICK_REG_ENUM_1011291729_HPP

BOOST_MIRROR_NAMESPACE_BEGIN

// helper macro for BOOST_MIRROR_QREG_ENUM
#define BOOST_MIRROR_HLP_QREG_ENUM_VAL(R, X, ELEM) \
BOOST_MIRROR_REG_ENUM_VALUE(ELEM)

#ifdef BOOST_MIRROR_DOCUMENTATION_ONLY
/// Macro for quick registering of global scope enumerations
/**
 *  @param ENUM the base enum name.
 *  @param VALUES a sequence of enumeration value names enclosed in parenthesises
 *  for example (x)(y)(z)
 *
 *  @see BOOST_MIRROR_QREG_ENUM
 *  @see BOOST_MIRROR_REG_GLOBAL_SCOPE_ENUM_BEGIN
 *  @see BOOST_MIRROR_REG_ENUM_END
 *  @ingroup quick_registering_macros
 */
#define BOOST_MIRROR_QREG_GLOBAL_SCOPE_ENUM(ENUM, VALUES)
#else
#define BOOST_MIRROR_QREG_GLOBAL_SCOPE_ENUM(ENUM, VALUES) \
BOOST_MIRROR_REG_GLOBAL_SCOPE_ENUM_BEGIN(ENUM) \
BOOST_PP_SEQ_FOR_EACH(BOOST_MIRROR_HLP_QREG_ENUM_VAL, _, VALUES) \
BOOST_MIRROR_REG_ENUM_END
#endif

#ifdef BOOST_MIRROR_DOCUMENTATION_ONLY
/// Macro for quick registering of enumerations
/**
 *  @param NAMESPACE the full namespace name inside of which the enum is nested.
 *  @param ENUM the base enum name.
 *  @param VALUES a sequence of enumeration value names enclosed in parenthesises
 *  for example (x)(y)(z)
 *
 *  @see BOOST_MIRROR_REG_ENUM_BEGIN
 *  @see BOOST_MIRROR_REG_ENUM_END
 *  @ingroup quick_registering_macros
 */
#define BOOST_MIRROR_QREG_ENUM(NAMESPACE, ENUM, VALUES)
#else
#define BOOST_MIRROR_QREG_ENUM(NAMESPACE, ENUM, VALUES) \
BOOST_MIRROR_REG_ENUM_BEGIN(NAMESPACE, ENUM) \
BOOST_PP_SEQ_FOR_EACH(BOOST_MIRROR_HLP_QREG_ENUM_VAL, _, VALUES) \
BOOST_MIRROR_REG_ENUM_END
#endif

#ifdef BOOST_MIRROR_DOCUMENTATION_ONLY
/// Macro for quick registering of enumerations nested in a class
/**
 *  @param PARENT_CLASS the full class name inside of which the enum is nested.
 *  @param ENUM the base enum name.
 *  @param VALUES a sequence of member variable names enclosed in parenthesises
 *  for example (x)(y)(z)
 *
 *  @see BOOST_MIRROR_REG_NESTED_ENUM_BEGIN
 *  @see BOOST_MIRROR_REG_ENUM_END
 *  @ingroup quick_registering_macros
 */
#define BOOST_MIRROR_QREG_NESTED_ENUM(PARENT_CLASS, ENUM, VALUES)
#else
#define BOOST_MIRROR_QREG_NESTED_ENUM(PARENT_CLASS, ENUM, VALUES) \
BOOST_MIRROR_REG_NESTED_ENUM_BEGIN(PARENT_CLASS, ENUM) \
BOOST_PP_SEQ_FOR_EACH(BOOST_MIRROR_HLP_QREG_ENUM_VAL, _, VALUES) \
BOOST_MIRROR_REG_ENUM_END
#endif

BOOST_MIRROR_NAMESPACE_END

#endif //include guard

