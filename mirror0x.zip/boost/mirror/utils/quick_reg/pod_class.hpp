/**
 * .file boost/mirror/utils/quick_reg/pod_class.hpp
 * .brief Boost.Preprocessor-based quick registering macros
 *
 *  Do not include directly, include boost/mirror/utils/quick_reg.hpp
 *
 *  Copyright 2008-2011 Matus Chochlik. Distributed under the Boost
 *  Software License, Version 1.0. (See accompanying file
 *  LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
 */

#ifndef BOOST_MIRROR_UTILS_QUICK_REG_POD_CLASS_1011291729_HPP
#define BOOST_MIRROR_UTILS_QUICK_REG_POD_CLASS_1011291729_HPP

BOOST_MIRROR_NAMESPACE_BEGIN

// helper macro for BOOST_MIRROR_QREG_POD_CLASS
#define BOOST_MIRROR_HLP_QREG_PLAIN_MEM_VAR(R, X, ELEM) \
BOOST_MIRROR_REG_CLASS_MEM_VAR(_, _, _, ELEM)

#ifdef BOOST_MIRROR_DOCUMENTATION_ONLY
/// Macro for quick registering of POD classes defined at the global scope
/**
 *  @param ELABORATED_TYPE the type of the class this parameter can have
 *  the following values (class, struct, union, enum and _ for default (class))
 *  @param CLASS the base class name.
 *  @param MEMBERS a sequence of member variable names enclosed in parenthesises
 *  for example (x)(y)(z)
 *
 *  @see BOOST_MIRROR_QREG_POD_CLASS
 *  @see BOOST_MIRROR_REG_GLOBAL_SCOPE_CLASS_BEGIN
 *  @see BOOST_MIRROR_REG_CLASS_END
 *  @ingroup registering_macros
 */
#define BOOST_MIRROR_QREG_GLOBAL_SCOPE_POD_CLASS(ELABORATED_TYPE, CLASS, MEMBERS)
#else
#define BOOST_MIRROR_QREG_GLOBAL_SCOPE_POD_CLASS(ELABORATED_TYPE, CLASS, MEMBERS) \
BOOST_MIRROR_REG_GLOBAL_SCOPE_CLASS_BEGIN(ELABORATED_TYPE, CLASS) \
BOOST_MIRROR_REG_CLASS_MEM_VARS_BEGIN \
BOOST_PP_SEQ_FOR_EACH(BOOST_MIRROR_HLP_QREG_PLAIN_MEM_VAR, _, MEMBERS) \
BOOST_MIRROR_REG_CLASS_MEM_VARS_END \
BOOST_MIRROR_REG_CONSTRUCTORS_BEGIN \
BOOST_MIRROR_REG_DEFAULT_CONSTRUCTOR(public) \
BOOST_MIRROR_REG_COPY_CONSTRUCTOR(public) \
BOOST_MIRROR_REG_STRUCT_INITIALIZER() \
BOOST_MIRROR_REG_CONSTRUCTORS_END \
BOOST_MIRROR_REG_CLASS_END
#endif

#ifdef BOOST_MIRROR_DOCUMENTATION_ONLY
/// Macro for quick registering of POD class without base classes, etc.
/**
 *  @param ELABORATED_TYPE the type of the class this parameter can have
 *  the following values (class, struct, union, enum and _ for default (class))
 *  @param NAMESPACE the full namespace name inside of which the class is
 *  nested.
 *  @param CLASS the base class name.
 *  @param MEMBERS a sequence of member variable names enclosed in parenthesises
 *  for example (x)(y)(z)
 *
 *  @see BOOST_MIRROR_REG_CLASS_BEGIN
 *  @see BOOST_MIRROR_REG_CLASS_END
 *  @see BOOST_MIRROR_REG_BASE_CLASS
 *  @ingroup registering_macros
 */
#define BOOST_MIRROR_QREG_POD_CLASS(ELABORATED_TYPE, NAMESPACE, CLASS, MEMBERS)
#else
#define BOOST_MIRROR_QREG_POD_CLASS(ELABORATED_TYPE, NAMESPACE, CLASS, MEMBERS) \
BOOST_MIRROR_REG_CLASS_BEGIN(ELABORATED_TYPE, NAMESPACE, CLASS) \
BOOST_MIRROR_REG_CLASS_MEM_VARS_BEGIN \
BOOST_PP_SEQ_FOR_EACH(BOOST_MIRROR_HLP_QREG_PLAIN_MEM_VAR, _, MEMBERS) \
BOOST_MIRROR_REG_CLASS_MEM_VARS_END \
BOOST_MIRROR_REG_CONSTRUCTORS_BEGIN \
BOOST_MIRROR_REG_DEFAULT_CONSTRUCTOR(public) \
BOOST_MIRROR_REG_COPY_CONSTRUCTOR(public) \
BOOST_MIRROR_REG_STRUCT_INITIALIZER() \
BOOST_MIRROR_REG_CONSTRUCTORS_END \
BOOST_MIRROR_REG_CLASS_END
#endif

#ifdef BOOST_MIRROR_DOCUMENTATION_ONLY
/// Macro for quick registering of POD classes nested in other classes
/**
 *  @param ELABORATED_TYPE the type of the class this parameter can have
 *  the following values (class, struct, union, enum and _ for default (class))
 *  @param PARENT_CLASS the full class name inside of which the registerd class
 *  is nested.
 *  @param CLASS the base class name.
 *  @param MEMBERS a sequence of member variable names enclosed in parenthesises
 *  for example (x)(y)(z)
 *
 *  @see BOOST_MIRROR_QREG_POD_CLASS
 *  @see BOOST_MIRROR_REG_NESTED_CLASS_BEGIN
 *  @see BOOST_MIRROR_REG_CLASS_END
 *  @ingroup registering_macros
 */
#define BOOST_MIRROR_QREG_NESTED_POD_CLASS(ELABORATED_TYPE, PARENT_CLASS, CLASS, MEMBERS)
#else
#define BOOST_MIRROR_QREG_NESTED_POD_CLASS(ELABORATED_TYPE, PARENT_CLASS, CLASS, MEMBERS)\
BOOST_MIRROR_REG_NESTED_CLASS_BEGIN(ELABORATED_TYPE, PARENT_CLASS, CLASS) \
BOOST_MIRROR_REG_CLASS_MEM_VARS_BEGIN \
BOOST_PP_SEQ_FOR_EACH(BOOST_MIRROR_HLP_QREG_PLAIN_MEM_VAR, _, MEMBERS) \
BOOST_MIRROR_REG_CLASS_MEM_VARS_END \
BOOST_MIRROR_REG_CONSTRUCTORS_BEGIN \
BOOST_MIRROR_REG_DEFAULT_CONSTRUCTOR(public) \
BOOST_MIRROR_REG_COPY_CONSTRUCTOR(public) \
BOOST_MIRROR_REG_STRUCT_INITIALIZER() \
BOOST_MIRROR_REG_CONSTRUCTORS_END \
BOOST_MIRROR_REG_CLASS_END
#endif

BOOST_MIRROR_NAMESPACE_END

#endif //include guard

