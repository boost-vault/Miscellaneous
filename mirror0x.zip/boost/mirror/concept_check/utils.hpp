/**
 * @file boost/mirror/concept_check/utils.hpp
 * @brief Concept checking utilities
 *
 *  Copyright 2008-2010 Matus Chochlik. Distributed under the Boost
 *  Software License, Version 1.0. (See accompanying file
 *  LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
 */

#ifndef BOOST_MIRROR_CONCEPT_CHECK_UTILS_1011291729_HPP
#define BOOST_MIRROR_CONCEPT_CHECK_UTILS_1011291729_HPP

#include <boost/mirror/config.hpp>
#include <boost/mirror/mirror_fwd.hpp>
#include <boost/mirror/tag_dispatch.hpp>
#include <boost/mirror/meta_prog/is_a.hpp>
#include <boost/mirror/meta_prog/and.hpp>
#include <boost/mirror/preprocessor.hpp>


BOOST_MIRROR_NAMESPACE_BEGIN

// helper template use in implementation of conforms_to
// Specializations of this template check the conformance
// of the Tested type with various concepts
//
// Don't use or specialize this template directly use
// the BOOST_MIRROR_CONCEPT_TESTER_* macros
template <typename Tested, typename ConceptTag>
class conforms_to_helper;


#define BOOST_MIRROR_CONCEPT_TESTER_BEGIN(CONCEPT_TAG) \
template <typename Tested> \
class conforms_to_helper<Tested, CONCEPT_TAG> \
{ \
private: \
        template <typename X> \
        static typename boost::mirror::mp::is_a< \
                X, \
                CONCEPT_TAG \
        >::type category_test(X*); \
        static std::false_type category_test(...); \
        static std::false_type test(...); \
        template <class X> \
        static std::true_type test

#define BOOST_MIRROR_CONCEPT_TESTER_END \
public: \
        typedef typename boost::mirror::mp::and_< \
                other_constraints, \
                decltype(category_test((Tested*)nullptr)), \
                decltype(test((Tested*)nullptr)) \
        >::type type; \
};

#define BOOST_MIRROR_CONCEPT_TESTER_CONSTRAINTS(PARAM) \
        typedef typename BOOST_MIRROR_PP_EXPAND_ARGS PARAM :: type \
                other_constraints;

/// Checks if the @c Tested type conforms to a concept
/** This type inherits from @c std::true_type if the @c Tested type
 *  conforms to the concept specified by the @c ConceptTag,
 *  inherits from @c std::false_type otherwise.
 *
 *  @see BOOST_MIRROR_ASSERT_CONCEPT
 *  @ingroup concept_checking
 */
template <typename Tested, typename ConceptTag>
struct conforms_to
 : public conforms_to_helper<Tested, ConceptTag>::type
{ };

/// Compile-time concept conformance assertion
/** This macro triggers a compile-time error with a readable message
 *  if the @a TESTED type does not conform to a concept specified
 *  by the @a CONCEPT_TAG
 *
 *  @see conforms_to
 *  @ingroup concept_checking
 */
#define BOOST_MIRROR_ASSERT_CONCEPT(TESTED, CONCEPT_TAG) \
static_assert( \
        boost::mirror::conforms_to< \
                TESTED, \
                boost::mirror::CONCEPT_TAG \
        >::value, \
        #TESTED " does not conform to " #CONCEPT_TAG \
)

BOOST_MIRROR_NAMESPACE_END

#endif //include guard

