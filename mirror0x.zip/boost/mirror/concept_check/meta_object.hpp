/**
 * @file boost/mirror/concept_check/meta_object.hpp
 * @brief MetaObject concept conformance test
 *
 *  Copyright 2008-2010 Matus Chochlik. Distributed under the Boost
 *  Software License, Version 1.0. (See accompanying file
 *  LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
 */

#ifndef BOOST_MIRROR_CONCEPT_CHECK_META_OBJECT_1011291729_HPP
#define BOOST_MIRROR_CONCEPT_CHECK_META_OBJECT_1011291729_HPP

#include <boost/mirror/concept_check/utils.hpp>

BOOST_MIRROR_NAMESPACE_BEGIN

// MetaObject
BOOST_MIRROR_CONCEPT_TESTER_BEGIN(meta_object_tag)
(X*); // no special requirements from the interface
BOOST_MIRROR_CONCEPT_TESTER_CONSTRAINTS((std::true_type))
BOOST_MIRROR_CONCEPT_TESTER_END

BOOST_MIRROR_NAMESPACE_END

#endif //include guard

