/**
 * @file boost/mirror/concept_check/meta_typedef.hpp
 * @brief MetaTypedef concept conformance test
 *
 *  Copyright 2008-2010 Matus Chochlik. Distributed under the Boost
 *  Software License, Version 1.0. (See accompanying file
 *  LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
 */

#ifndef BOOST_MIRROR_CONCEPT_CHECK_META_TYPEDEF_1011291729_HPP
#define BOOST_MIRROR_CONCEPT_CHECK_META_TYPEDEF_1011291729_HPP

#include <boost/mirror/concept_check/utils.hpp>
#include <boost/mirror/concept_check/meta_type.hpp>

BOOST_MIRROR_NAMESPACE_BEGIN

// MetaType
BOOST_MIRROR_CONCEPT_TESTER_BEGIN(meta_typedef_tag)
(X*,
        const typename X::type* t = nullptr
);
BOOST_MIRROR_CONCEPT_TESTER_CONSTRAINTS((
        conforms_to<Tested, meta_type_tag>
))
BOOST_MIRROR_CONCEPT_TESTER_END

BOOST_MIRROR_NAMESPACE_END

#endif //include guard

