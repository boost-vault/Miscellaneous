/**
 * @file boost/mirror/intrinsic.hpp
 * @brief Implementation of several intrinsic meta-functions
 * for various meta-object concepts
 *
 *  Copyright 2008-2011 Matus Chochlik. Distributed under the Boost
 *  Software License, Version 1.0. (See accompanying file
 *  LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
 */

#ifndef BOOST_MIRROR_INTRINSIC_1011291729_HPP
#define BOOST_MIRROR_INTRINSIC_1011291729_HPP

#include <boost/mirror/meta_prog/as_a.hpp>
#include <boost/mirror/tag_dispatch.hpp>

BOOST_MIRROR_NAMESPACE_BEGIN

#ifndef BOOST_MIRROR_DOCUMENTATION_ONLY

template <class MetaTypeExpr>
struct original_type
{
        // try to evaluate the expression as a MetaType
        // and get its original_type
        typedef typename mp::as_a<
                MetaTypeExpr,
                meta_type_tag
        >::type::original_type type;
};

template <class MetaScopedObjectExpr>
struct scope
{
        typedef typename mp::as_a<
                MetaScopedObjectExpr,
                meta_scoped_object_tag
        >::type::scope type;
};

template <class MetaTypeExpr>
struct container_kind
{
        typedef typename mp::as_a<
                MetaTypeExpr,
                meta_type_tag
        >::type::container_kind type;
};

template <class MetaClassExpr>
struct elaborated_type
{
        typedef typename mp::as_a<
                MetaClassExpr,
                meta_class_tag
        >::type::elaborated_type type;
};

template <class MetaVariableExpr>
struct storage_class
{
        typedef typename mp::as_a<
                MetaVariableExpr,
                meta_variable_tag
        >::type::storage_class type;
};

template <class MetaFunctionExpr>
struct linkage
{
        typedef typename mp::as_a<
                MetaFunctionExpr,
                meta_function_tag
        >::type::linkage type;
};

template <class MetaMemberFunctionExpr>
struct constness
{
        typedef typename mp::as_a<
                MetaMemberFunctionExpr,
                meta_member_function_tag
        >::type::constness type;
};

template <class MetaInheritanceExpr>
struct inheritance_type
{
        typedef typename mp::as_a<
                MetaInheritanceExpr,
                meta_inheritance_tag
        >::type::inheritance_type type;
};

template <class MetaInheritanceExpr>
struct derived_class
{
        typedef typename mp::as_a<
                MetaInheritanceExpr,
                meta_inheritance_tag
        >::type::derived_class type;
};

template <class MetaInheritanceExpr>
struct base_class
{
        typedef typename mp::as_a<
                MetaInheritanceExpr,
                meta_inheritance_tag
        >::type::base_class type;
};

template <class MetaInheritanceExpr>
struct base_class_access_type
{
        typedef typename mp::as_a<
                MetaInheritanceExpr,
                meta_inheritance_tag
        >::type::access_type type;
};

template <class MetaClassMemberExpr>
struct class_member_access_type
{
        typedef typename mp::as_a<
                MetaClassMemberExpr,
                meta_class_member_tag
        >::type::access_type type;
};

template <class MetaClassOrEnumMemberExpr>
struct member_position
{
        typedef typename mp::as_a<
                MetaClassOrEnumMemberExpr,
                meta_class_or_enum_member_tag
        >::type::position type;
};

template <class MetaParameterExpr>
struct parameter_position
{
        typedef typename mp::as_a<
                MetaParameterExpr,
                meta_parameter_tag
        >::type::position type;
};

template <class MetaTemplatedTypeExpr>
struct type_template
{
        typedef typename mp::as_a<
                MetaTemplatedTypeExpr,
                meta_templated_type_tag
        >::type::type_template type;
};

template <class MetaVariableExpr>
struct type_of
{
        typedef typename mp::as_a<
                MetaVariableExpr,
                meta_variable_tag
        >::type::type type;
};

template <class MetaEnumExpr>
struct enum_size
{
        typedef typename mp::as_a<
                MetaEnumExpr,
                meta_enum_tag
        >::type::size type;
};

template <class X>
struct members
{
        static_assert(
                mp::is_a<
                        typename X::type,
                        meta_scope_tag
                >::value,
                "The X type is not a MetaScope expression."
        );
        typedef typename members<typename X::type>::type type;
};

template <class X>
struct template_parameters
{
        static_assert(
                mp::is_a<
                        typename X::type,
                        meta_templated_type_tag
                >::value,
                "The X type is not a MetaTemplatedType expression."
        );
        typedef typename template_parameters<typename X::type>::type type;
};

template <class X>
struct base_classes
{
        static_assert(
                mp::is_a<
                        typename X::type,
                        meta_class_tag
                >::value,
                "The X type is not a MetaClass expression."
        );
        typedef typename base_classes<typename X::type>::type type;
};

template <class X>
struct member_variables
{
        static_assert(
                mp::is_a<
                        typename X::type,
                        meta_class_tag
                >::value,
                "The X type is not a MetaClass expression."
        );
        typedef typename member_variables<typename X::type>::type type;
};

template <class X>
struct all_member_variables
{
        static_assert(
                mp::is_a<
                        typename X::type,
                        meta_class_tag
                >::value,
                "The X type is not a MetaClass expression."
        );
        typedef typename all_member_variables<typename X::type>::type type;
};

template <class X>
struct class_layout
{
        static_assert(
                mp::is_a<
                        typename X::type,
                        meta_class_tag
                >::value,
                "The X type is not a MetaClass expression."
        );
        typedef typename class_layout<typename X::type>::type type;
};

template <class X>
struct constructors
{
        static_assert(
                mp::is_a<
                        typename X::type,
                        meta_type_tag
                >::value,
                "The X type is not a MetaType expression."
        );
        typedef typename constructors<typename X::type>::type type;
};

template <class X>
struct member_functions
{
        static_assert(
                mp::is_a<
                        typename X::type,
                        meta_class_tag
                >::value,
                "The X type is not a MetaClass expression."
        );
        typedef typename member_functions<typename X::type>::type type;
};

template <class X>
struct conversions
{
        static_assert(
                mp::is_a<
                        typename X::type,
                        meta_class_tag
                >::value,
                "The X type is not a MetaClass expression."
        );
        typedef typename conversions<typename X::type>::type type;
};

template <class X>
struct parameters
{
        static_assert(
                mp::is_a<
                        typename X::type,
                        meta_function_tag
                >::value,
                "The X type is not a MetaFunction expression."
        );
        typedef typename parameters<typename X::type>::type type;
};

template <class X>
struct enum_values
{
        static_assert(
                mp::is_a<
                        typename X::type,
                        meta_enum_tag
                >::value,
                "The X type is not a MetaEnum expression."
        );
        typedef typename enum_values<typename X::type>::type type;
};

template <class X>
struct free_variables
{
        static_assert(
                mp::is_a<
                        typename X::type,
                        meta_namespace_tag
                >::value,
                "The X type is not a MetaNamespace expression."
        );
        typedef typename free_variables<typename X::type>::type type;
};

template <class X>
struct containers
{
        static_assert(
                mp::is_a<
                        typename X::type,
                        meta_class_tag
                >::value,
                "The X type is not a MetaClass expression."
        );
        typedef typename containers<typename X::type>::type type;
};

template <class X>
struct all_containers
{
        static_assert(
                mp::is_a<
                        typename X::type,
                        meta_class_tag
                >::value,
                "The X type is not a MetaClass expression."
        );
        typedef typename all_containers<typename X::type>::type type;
};

template <class X>
struct default_traversal
{
        static_assert(
                mp::is_a<
                        typename X::type,
                        meta_container_tag
                >::value,
                "The X type is not a MetaContainer expression."
        );
        typedef typename default_traversal<typename X::type>::type type;
};

template <class X>
struct traversals
{
        static_assert(
                mp::is_a<
                        typename X::type,
                        meta_container_tag
                >::value,
                "The X type is not a MetaContainer expression."
        );
        typedef typename traversals<typename X::type>::type type;
};

template <class X>
struct locators
{
        static_assert(
                mp::is_a<
                        typename X::type,
                        meta_container_tag
                >::value,
                "The X type is not a MetaContainer expression."
        );
        typedef typename locators<typename X::type>::type type;
};

template <class X>
struct inserters
{
        static_assert(
                mp::is_a<
                        typename X::type,
                        meta_container_tag
                >::value,
                "The X type is not a MetaContainer expression."
        );
        typedef typename inserters<typename X::type>::type type;
};

template <class X>
struct erasers
{
        static_assert(
                mp::is_a<
                        typename X::type,
                        meta_container_tag
                >::value,
                "The X type is not a MetaContainer expression."
        );
        typedef typename erasers<typename X::type>::type type;
};

#endif // BOOST_MIRROR_DOCUMENTATION_ONLY

BOOST_MIRROR_NAMESPACE_END

#endif //include guard

