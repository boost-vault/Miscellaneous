/**
 *  @file boost/mirror/mirror_base.hpp
 *  @brief All-in-one inclusion of everything in Mirror without
 *  pre-registered namespaces, types, etc.
 *
 *  Copyright 2008-2011 Matus Chochlik. Distributed under the Boost
 *  Software License, Version 1.0. (See accompanying file
 *  LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
 */

#ifndef BOOST_MIRROR_MIRROR_NO_PREREG_1011291729_HPP
#define BOOST_MIRROR_MIRROR_NO_PREREG_1011291729_HPP

// basic meta-object implementation
#include <boost/mirror/meta_namespace.hpp>
#include <boost/mirror/meta_type.hpp>
#include <boost/mirror/meta_typedef.hpp>
#include <boost/mirror/meta_class.hpp>
#include <boost/mirror/meta_enum.hpp>
#include <boost/mirror/meta_type_template.hpp>
#include <boost/mirror/meta_variable.hpp>
#include <boost/mirror/meta_container.hpp>
#include <boost/mirror/meta_std_container.hpp>
// meta-meta-objects
#include <boost/mirror/meta_meta_object.hpp>
//
// intrinsic meta-functions
#include <boost/mirror/intrinsic.hpp>
//
// meta-programming utilitis
#include <boost/mirror/meta_prog.hpp>
//
// specifier tags
#include <boost/mirror/specifier_tags.hpp>
//
// type traits
#include <boost/mirror/type_traits.hpp>
//
// the using directive utility
#include <boost/mirror/using_directive.hpp>
//
// object tagging
#include <boost/mirror/object_tagging.hpp>
//
// factory generators
#include <boost/mirror/factory.hpp>

#endif //include guard

