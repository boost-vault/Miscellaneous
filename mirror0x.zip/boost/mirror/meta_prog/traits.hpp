/**
 *  @file boost/mirror/meta_prog/traits.hpp
 *  @brief Meta-function template classes for getting various traits
 *  of types defined in the mp scope.
 *
 *  Copyright 2008-2011 Matus Chochlik. Distributed under the Boost
 *  Software License, Version 1.0. (See accompanying file
 *  LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
 */

#ifndef BOOST_MIRROR_META_PROG_TRAITS_1011291729_HPP
#define BOOST_MIRROR_META_PROG_TRAITS_1011291729_HPP

#include <boost/mirror/meta_prog/forward_decl.hpp>

BOOST_MIRROR_NAMESPACE_BEGIN
namespace mp {

#ifdef BOOST_MIRROR_DOCUMENTATION_ONLY
/// This trait meta-function can be used to check if the passed type is a range
template <typename T>
struct is_range : BooleanConstant
{ };
#else
template <typename T>
struct is_range : std::false_type
{ };

template <typename ... P>
struct is_range<range<P...> > : std::true_type
{ };
#endif

#ifdef BOOST_MIRROR_DOCUMENTATION_ONLY
/// This trait meta-function can be used to check if the passed type is optional
template <typename T>
struct is_optional : BooleanConstant
{ };
#else
template <typename T>
struct is_optional : std::false_type
{ };

template <typename T>
struct is_optional<optional<T> > : std::true_type
{ };
#endif

} // namespace mp
BOOST_MIRROR_NAMESPACE_END

#endif //include guard

