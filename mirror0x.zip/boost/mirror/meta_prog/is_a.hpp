/**
 * @file boost/mirror/meta_prog/is_a.hpp
 * @brief Boolean meta-function checking if a MetaObject is a model
 * of a specified concept
 *
 *  Copyright 2008-2011 Matus Chochlik. Distributed under the Boost
 *  Software License, Version 1.0. (See accompanying file
 *  LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
 */

#ifndef BOOST_MIRROR_META_PROG_IS_A_1011291729_HPP
#define BOOST_MIRROR_META_PROG_IS_A_1011291729_HPP

#include <boost/mirror/meta_prog/forward_decl.hpp>
#include <boost/mirror/meta_prog/not.hpp>
#include <type_traits>

BOOST_MIRROR_NAMESPACE_BEGIN
namespace mp {
namespace aux {

template <class X, class RealConcept, class QueriedConcept>
struct is_a_helper : public ::std::is_base_of<
        QueriedConcept,
        RealConcept
>{ };

template <class X, class Concept>
struct is_a_helper<X, Concept, Concept>
 : public std::true_type
{ };

template <class X, class QueriedConcept>
struct is_a_helper<X, non_meta_object_tag, QueriedConcept>
 : public is_a_helper<
        typename X::type,
        typename meta_object_category<typename X::type>::type,
        QueriedConcept
>
{ };


} // namespace aux

#ifdef BOOST_MIRROR_DOCUMENTATION_ONLY
/// Returns a boolean constant based on whether the MetaObject is the Concept
/**
 *  @tparam MetaObject
 *  @tparam Concept
 *
 *  @ingroup meta_programming
 */
template <class MetaObject, class Concept>
struct is_a
{
        /// The @c std::true_type or the @c std::false_type
        typedef BooleanConstant type;
};

/// Returns a boolean constant based on whether the MetaObject isn't the Concept
/**
 *  @tparam MetaObject
 *  @tparam Concept
 *
 *  @ingroup meta_programming
 */
template <class MetaObject, class Concept>
struct is_not_a
{
        /// The @c std::true_type or the @c std::false_type
        typedef BooleanConstant type;
};
#else

// X is a concept
template <class X, class Concept>
struct is_a : aux::is_a_helper<
        X,
        typename meta_object_category<X>::type,
        Concept
>
{ };

// X isn't a concept
template <class X, class Concept>
struct is_not_a : not_<aux::is_a_helper<
        X,
        typename meta_object_category<X>::type,
        Concept
> >
{ };
#endif


} // namespace mp
BOOST_MIRROR_NAMESPACE_END

#endif //include guard

