/**
 * @file boost/mirror/meta_prog/optional.hpp
 * @brief Compile-time optional type
 *
 *  Copyright 2008-2011 Matus Chochlik. Distributed under the Boost
 *  Software License, Version 1.0. (See accompanying file
 *  LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
 */

#ifndef BOOST_MIRROR_META_PROG_OPTIONAL_1104130956_HPP
#define BOOST_MIRROR_META_PROG_OPTIONAL_1104130956_HPP

#include <boost/mirror/meta_prog/forward_decl.hpp>
#include <boost/mirror/meta_prog/traits.hpp>

BOOST_MIRROR_NAMESPACE_BEGIN
namespace mp {
namespace aux {

struct nil_opt { };

} // namespace aux

/// A single value container
/**
 *  @tparam T the element of the optional
 *  @see nil
 *  @see get
 *  @ingroup meta_programming
 */
template <typename T>
struct optional
{
        typedef optional type;
};

/// Convenience typedef for NIL optional
typedef optional<aux::nil_opt> nil_optional;

#ifdef BOOST_MIRROR_DOCUMENTATION_ONLY
/// Nil intrinsic meta-function for optionals
/**
 *  @tparam Optional the optional to be examined
 *  @see optional
 *  @see get
 *  @ingroup meta_programming
 */
template <typename Optional>
struct nil { };
#else
// The default implementation of the empty meta-function
template <typename X>
struct nil : nil<typename X::type>::type
{
        static_assert(
                is_optional<typename X::type>::value,
                "The X type is not an Optional expression."
        );
};
#endif

template <>
struct nil<nil_optional>
 : std::true_type
{ };

template <typename T>
struct nil<optional<T> >
 : std::false_type
{ };

#ifdef BOOST_MIRROR_DOCUMENTATION_ONLY
/// Returns the element of the optional passed as argument
/**
 *  This operation may be invoked only on non-nil optionals.
 *
 *  @tparam Optional the optional the item of which is to be returned
 *  @see optional
 *  @see nil
 *  @ingroup meta_programming
 */
template <typename Optional>
struct get
{
        /// The type in the optional passed as argument
        typedef unspecified_type type;
};
#else
template <typename X>
struct get
{
        static_assert(
                is_optional<typename X::type>::value,
                "The X type is not an Optional expression."
        );
        typedef typename get<typename X::type>::type type;
};
#endif

template <typename T>
struct get<optional<T> >
{
        typedef T type;
};

template <>
struct get<nil_optional> { };

namespace aux {

template <typename Expr, typename IsOptional>
struct as_optional;

template <typename Optional>
struct as_optional<Optional, std::true_type>
{
        typedef Optional type;
};

template <typename Expr>
struct as_optional<Expr, std::false_type>
{
        static_assert(
                is_optional<typename Expr::type>::value,
                "The Expr type is not an Optional expression."
        );
        typedef typename Expr::type type;
};

} // namespace aux

template <typename Expr>
struct as_optional : public aux::as_optional<
        Expr,
        typename is_optional<Expr>::type
>{ };


} // namespace mp
BOOST_MIRROR_NAMESPACE_END

#endif //include guard

