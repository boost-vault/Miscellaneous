/**
 * @file boost/mirror/meta_type.hpp
 * @brief Implementation of type registering and reflection
 *
 *
 *  Copyright 2008-2011 Matus Chochlik. Distributed under the Boost
 *  Software License, Version 1.0. (See accompanying file
 *  LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
 */

#ifndef BOOST_MIRROR_META_TYPE_1011291729_HPP
#define BOOST_MIRROR_META_TYPE_1011291729_HPP

#include <boost/mirror/meta_namespace.hpp>
#include <boost/mirror/preprocessor.hpp>
#include <boost/mirror/auxiliary/template_type_name.hpp>
#include <boost/mirror/auxiliary/meta_type.hpp>

BOOST_MIRROR_NAMESPACE_BEGIN

namespace _type {

// Specialization of this structure provide basic meta-data about types
template <typename Type>
struct _
{
        typedef spec_type_tag kind;
};

} // namespace _type

// Implementation of the type_category meta-function
template <typename T>
struct type_category
{
        typedef typename boost::mirror::_type::_<T>::kind type;
};

template <typename T>
typename type_category<T>::type
categorize_type(const T&)
{
    return typename type_category<T>::type();
}


template <class Type>
struct meta_type
 : aux::meta_type_name_impl<
        Type,
        typename boost::mirror::_type::_<Type>::category
>
{
        typedef typename aux::full_meta_object<
                typename boost::mirror::_type::_<Type>::scope
        >::type scope;

        typedef Type original_type;
};

template <class Type>
struct reflected
{
        typedef typename aux::reflect_type<Type>::type type;
};

template <class Type>
struct reflected_type : public aux::reflect_type<Type>::type
{
        typedef typename aux::reflect_type<Type>::type type;
};

// Implementation of the parameters meta-function for templated types
template <template <typename...> class Template, typename ... Params>
struct template_parameters<meta_type<Template<Params...> > >
{
        typedef mp::range<meta_type<Params>...> type;
};

// Implementation of the parameters meta-function for templated classes
template <template <typename...> class Template, typename ... Params>
struct template_parameters<meta_class<Template<Params...> > >
{
        typedef mp::range<meta_class<Params>...> type;
};

#define BOOST_MIRROR_REG_GLOBAL_SCOPE_TYPE_BASICS(KIND, NAME) \
namespace _type { \
template <> \
struct _< NAME > \
{  \
        typedef meta_type_tag category; \
        typedef boost::mirror::spec_ ## KIND ## _tag kind; \
        typedef boost::mirror::_namespace::_ scope; \
        BOOST_MIRROR_IMPLEMENT_META_OBJECT_NAME_FUNCTIONS(#NAME) \
}; \
}

#ifdef BOOST_MIRROR_DOCUMENTATION_ONLY
/// This macro registers a type defined in the global scope with Mirror
/**
 *  @param NAME the base type name
 *
 *  @see BOOST_MIRROR_REG_TYPE
 *  @see BOOST_MIRRORED_TYPE
 *  @see boost::mirror::reflected
 *
 *  @ingroup registering_macros
 */
#define BOOST_MIRROR_REG_GLOBAL_SCOPE_TYPE(NAME)
#else
#define BOOST_MIRROR_REG_GLOBAL_SCOPE_TYPE(NAME) \
BOOST_MIRROR_REG_GLOBAL_SCOPE_TYPE_BASICS(type, NAME) \
BOOST_MIRROR_ADD_TO_GLOBAL_LIST( \
        boost::mirror::_namespace::_, \
        boost::mirror::meta_type< NAME > \
)
#endif

// Helper macro used in implementation of BOOST_MIRROR_REG_TYPE
#define BOOST_MIRROR_REG_TYPE_BASICS(KIND, NAMESPACE, NAME) \
namespace _type { \
template <> \
struct _< :: NAMESPACE :: NAME > \
{  \
        typedef meta_type_tag category; \
        typedef boost::mirror::spec_ ## KIND ## _tag kind; \
        typedef boost::mirror::_namespace:: NAMESPACE ::_ scope; \
        BOOST_MIRROR_IMPLEMENT_META_OBJECT_NAME_FUNCTIONS(#NAME) \
}; \
} /* namespace _type */

#ifdef BOOST_MIRROR_DOCUMENTATION_ONLY
/// This macro registers a type nested in a named namespace with Mirror
/**
 *  @param NAMESPACE the full namespace name NOT containing the
 *  leading double colon
 *  @param NAME the base type name
 *
 *  @see BOOST_MIRROR_REG_GLOBAL_SCOPE_TYPE
 *  @see BOOST_MIRRORED_TYPE
 *  @see boost::mirror::reflected
 *
 *  @ingroup registering_macros
 */
#define BOOST_MIRROR_REG_TYPE(NAMESPACE, NAME)
#else
#define BOOST_MIRROR_REG_TYPE(NAMESPACE, NAME) \
BOOST_MIRROR_REG_TYPE_BASICS(type, NAMESPACE, NAME) \
BOOST_MIRROR_ADD_TO_GLOBAL_LIST( \
        boost::mirror::_namespace :: NAMESPACE :: _, \
        boost::mirror::meta_type< :: NAMESPACE :: NAME > \
)
#endif

// Helper macro used in implementation of BOOST_MIRROR_REG_*_NESTED
#define BOOST_MIRROR_REG_NESTED_TYPE_BASICS(KIND, PARENT_CLASS, NAME) \
namespace _type { \
template <> \
struct _< :: PARENT_CLASS :: NAME > \
{  \
        typedef meta_type_tag category; \
        typedef boost::mirror::spec_ ## KIND ## _tag kind; \
        typedef boost::mirror::_class::_< :: PARENT_CLASS > scope; \
        BOOST_MIRROR_IMPLEMENT_META_OBJECT_NAME_FUNCTIONS(#NAME) \
}; \
} /* namespace _type */

#ifdef BOOST_MIRROR_DOCUMENTATION_ONLY
/// Reflects the type passed as the @a FULL_TYPE_NAME argument
/** @def BOOST_MIRRORED_TYPE(FULL_TYPE_NAME)
 *  This macro expands into a type conforming to the MetaType
 *  concept, which provides meta-data about the given type.
 *  The type name passed as the @a FULL_TYPE_NAME argument
 *  should be a fully qualified type name.
 *
 *  @see BOOST_MIRROR_REG_TYPE
 *  @see boost::mirror::MetaType
 *  @see boost::mirror::reflected
 *  @see boost::lagoon::reflected_type
 *
 *  @ingroup reflection_macros
 */
#define BOOST_MIRRORED_TYPE(FULL_TYPE_NAME) boost::mirror::MetaType
#else
#define BOOST_MIRRORED_TYPE(FULL_TYPE_NAME) \
        boost::mirror::meta_type< FULL_TYPE_NAME >
#endif

BOOST_MIRROR_NAMESPACE_END

#endif //include guard

