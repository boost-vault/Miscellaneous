/**
 * @file boost/mirror/auxiliary/member_functions.hpp
 * @brief Internal implementation of member functions
 *
 *  Copyright 2008-2011 Matus Chochlik. Distributed under the Boost
 *  Software License, Version 1.0. (See accompanying file
 *  LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
 */

#ifndef BOOST_MIRROR_AUX_MEMBER_FUNCTIONS_1011291729_HPP
#define BOOST_MIRROR_AUX_MEMBER_FUNCTIONS_1011291729_HPP

#include <boost/mirror/mirror_fwd.hpp>
#include <boost/mirror/meta_prog/range.hpp>
#include <boost/mirror/specifier_tags.hpp>
#include <string>
#include <type_traits>

BOOST_MIRROR_NAMESPACE_BEGIN
namespace aux {

template <typename Type, int Index>
class meta_mem_function_base
{
private:
        typedef boost::mirror::_type::_<Type> base_meta_type;
        typedef boost::mirror::_class::_<Type> base_meta_class;
public:
        // type scope of the member function
        typedef base_meta_type scope;

        static inline const char* name(void)
        {
                std::integral_constant<int, Index> idx;
                return base_meta_class::memfn_name(idx);
        }

        static inline size_t name_length(void)
        {
                std::integral_constant<int, Index> idx;
                return base_meta_class::memfn_name_length(idx);
        }
};

// Declaration of the mem_var_helper template (see below)
template <class Class>
struct mem_function_helper
{
        template <int ... Indices>
        struct apply
        {
                typedef boost::mirror::mp::range<
                        boost::mirror::meta_member_function<
                                Class,
                                Indices
                        >...
                > type;
        };
};

// Helper template returning the possibly const qualified taget type
// based on the constness of the tag passed as argument
template <typename ConstnessTag, typename T>
struct memfn_inst_type;

template <typename T>
struct memfn_inst_type<spec_non_const_tag, T>
{
        typedef T type;
};

template <typename T>
struct memfn_inst_type<spec___tag, T>
{
        typedef T type;
};

template <typename T>
struct memfn_inst_type<spec_const_tag, T>
{
        typedef const T type;
};

template <typename Type, int MemFnIndex, int ParamIndex>
struct meta_memfn_param_base
{
private:
        typedef boost::mirror::_class::_<Type> base_meta_type;
public:
        typedef meta_mem_function_base<Type, MemFnIndex> scope;

        static inline const char* name(void)
        {
                typedef std::integral_constant<int, MemFnIndex>
                        mem_fn_index;
                typedef std::integral_constant<int, ParamIndex>
                        param_index;
                typedef decltype(base_meta_type::memfn_params(
                        mem_fn_index()
                )) memfn_params;
                return memfn_params::name(param_index());
        }

        static inline size_t name_length(void)
        {
                typedef std::integral_constant<int, MemFnIndex>
                        mem_fn_index;
                typedef std::integral_constant<int, ParamIndex>
                        param_index;
                typedef decltype(base_meta_type::memfn_params(
                        mem_fn_index()
                )) memfn_params;
                return memfn_params::name_length(param_index());
        }
};

// Declaration of the mem_var_helper template (see below)
template <class Class, int MemFnIndex>
struct memfn_param_helper
{
        template <int ... Indices>
        struct apply
        {
                typedef boost::mirror::mp::range<
                        boost::mirror::meta_mem_function_param<
                                Class,
                                MemFnIndex,
                                Indices
                        >...
                > type;
        };
};


template <typename Type, typename Result>
class meta_conv_op_base
{
private:
        typedef boost::mirror::_type::_<Type> base_meta_type;
        typedef boost::mirror::_class::_<Type> base_meta_class;
        typedef boost::mirror::_type::_<Result> base_res_meta_type;

        static std::string operator_kw(void)
        {
                return
                        std::string("operator ") +
                        std::string(
                                base_meta_type::name(),
                                base_meta_type::name_length()
                        );
        }
public:
        // type scope of the member function
        typedef base_meta_type scope;

        static inline const char* name(void)
        {
                return operator_kw().c_str();
        }

        static inline size_t name_length(void)
        {
                return operator_kw().size();
        }
};

template <typename Type, class Range>
struct conv_op_helper;

// helper template used in the implementation of the conversions meta-function
template <typename Type, typename ... Results>
struct conv_op_helper<Type, mp::range<Results...> >
{
        typedef mp::range<
                boost::mirror::meta_conversion_operator<
                        Type,
                        Results
                > ...
        > type;
};


} // namespace aux
BOOST_MIRROR_NAMESPACE_END

#endif //include guard

