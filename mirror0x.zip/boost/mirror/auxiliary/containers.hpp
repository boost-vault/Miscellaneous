/**
 * @file boost/mirror/auxiliary/containers.hpp
 * @brief Internal implementation of container reflection helpers
 *
 *  Copyright 2008-2011 Matus Chochlik. Distributed under the Boost
 *  Software License, Version 1.0. (See accompanying file
 *  LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
 */

#ifndef BOOST_MIRROR_AUX_CONTAINERS_1104181546_HPP
#define BOOST_MIRROR_AUX_CONTAINERS_1104181546_HPP

#include <boost/mirror/mirror_fwd.hpp>
#include <boost/mirror/meta_prog/range.hpp>


BOOST_MIRROR_NAMESPACE_BEGIN
namespace aux {

template <class Container>
struct cntnr_helper
{
        template <int ... Indices>
        struct apply
        {
                typedef boost::mirror::mp::range<
                        boost::mirror::meta_container<
                                Container,
                                Indices
                        >...
                > type;
        };
};

template <typename Iterator>
class it_locator
{
private:
        static it_locator& that(void);
        Iterator pos;
public:
        it_locator(Iterator _pos)
         : pos(_pos)
        { }

        typedef std::true_type safe;

        // TODO: constexpr
        static inline bool dereferencable(void)
        {
                return true;
        }

        operator bool (void) const
        {
                return true;
        }

        bool operator !(void) const
        {
                return false;
        }

        auto get(void) const ->
        decltype(*that().pos)
        {
                return *pos;
        }

        template <typename T>
        void set(T value) const
        {
                *pos = value;
        }

        Iterator position(void) const
        {
                return pos;
        }
};


template <typename Iterator>
class it_pair_trvrsl
{
private:
        Iterator cur;
        Iterator end;
public:
        it_pair_trvrsl(Iterator _bgn, Iterator _end)
         : cur(_bgn)
         , end(_end)
        { }

        bool done(void) const
        {
                return cur == end;
        }

        bool empty(void) const
        {
                return done();
        }

        void step_front(void)
        {
                assert(!empty());
                ++cur;
        }

        it_locator<Iterator> front(void) const
        {
                assert(!empty());
                return it_locator<Iterator>(cur);
        }
};


template <typename ElementType, size_t Size>
struct meta_array_trav_fwd
{
        typedef meta_traversal_tag category;
        typedef boost::mirror::mp::empty_range signature;

        static inline std::string base_name(void)
        {
                return std::string();
        }

        typedef it_pair_trvrsl<ElementType*> traversal_type;

        static traversal_type start(ElementType* array)
        {
                return traversal_type(array, array + Size);
        }

        typedef it_pair_trvrsl<ElementType const*> const_traversal_type;

        static const_traversal_type start(const ElementType* array)
        {
                return const_traversal_type(array, array + Size);
        }
};

} // namespace aux
BOOST_MIRROR_NAMESPACE_END

#endif //include guard

