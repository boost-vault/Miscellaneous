/**
 * @file boost/puddle/config.hpp
 * @brief Configuration options
 *
 *  Copyright 2008-2011 Matus Chochlik. Distributed under the Boost
 *  Software License, Version 1.0. (See accompanying file
 *  LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
 */

#ifndef BOOST_PUDDLE_CONFIG_1103151301_HPP
#define BOOST_PUDDLE_CONFIG_1103151301_HPP

// Macro that begins the Mirror library namespace
#define BOOST_PUDDLE_NAMESPACE_BEGIN \
namespace boost { namespace puddle {

// Macro which ends the Mirror library namespace
#define BOOST_PUDDLE_NAMESPACE_END \
} /* namespace puddle */ } /* namespace boost */

#endif //include guard

