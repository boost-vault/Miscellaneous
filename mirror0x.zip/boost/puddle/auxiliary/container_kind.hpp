/**
 * .file boost/puddle/auxiliary/container_kind.hpp
 * .brief The container_kind wrapper
 *
 *  Copyright 2008-2011 Matus Chochlik. Distributed under the Boost
 *  Software License, Version 1.0. (See accompanying file
 *  LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
 */

#ifndef BOOST_PUDDLE_AUXILIARY_CONTAINER_KIND_1103160725_HPP
#define BOOST_PUDDLE_AUXILIARY_CONTAINER_KIND_1103160725_HPP

#include <boost/puddle/auxiliary/fwd.hpp>
#include <boost/puddle/auxiliary/base_wrap.hpp>
#include <type_traits>

BOOST_PUDDLE_NAMESPACE_BEGIN
namespace aux {

template <typename ContainerKind>
struct container_kind_tag : base_wrapper<ContainerKind>
{
public:
        template <typename OtherContainerKind>
        static bool is_a(OtherContainerKind)
        {
                return std::is_same<
                        OtherContainerKind,
                        ContainerKind
                >::value || std::is_base_of<
                        OtherContainerKind,
                        ContainerKind
                >::value;
        }

        static bool is_none(void)
        {
                return is_a(boost::mirror::non_container_tag());
        }
private:
        template <typename OtherContainerKind>
        static bool equal(
                container_kind_tag,
                container_kind_tag<OtherContainerKind>
        )
        {
                return is_a(OtherContainerKind());
        }

        static bool less(container_kind_tag, container_kind_tag)
        {
                return false;
        }

        template <typename OtherContainerKind>
        static bool less(
                container_kind_tag,
                container_kind_tag<OtherContainerKind>
        )
        {
                return ContainerKind::_uid() < OtherContainerKind::_uid();
        }
public:
        template <typename X>
        friend bool operator == (container_kind_tag a, X b)
        {
                return equal(a, b);
        }

        template <typename X>
        friend bool operator != (container_kind_tag a, X b)
        {
                return !equal(a, b);
        }

        template <typename X>
        friend bool operator <= (container_kind_tag a, X b)
        {
                return equal(a, b) || less(a, b);
        }

        template <typename X>
        friend bool operator >= (container_kind_tag a, X b)
        {
                return !less(a, b);
        }

        template <typename X>
        friend bool operator <  (container_kind_tag a, X b)
        {
                return less(a, b);
        }

        template <typename X>
        friend bool operator >  (container_kind_tag a, X b)
        {
                return !equal(a, b) && !less(a, b);
        }

        operator bool (void) const
        {
                return !is_none();
        }

        bool operator ! (void) const
        {
                return is_none();
        }
};

} // namespace aux
BOOST_PUDDLE_NAMESPACE_END

#endif //include guard

