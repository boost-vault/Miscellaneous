/**
 * .file boost/puddle/auxiliary/integer.hpp
 * .brief The integral constant wrapper
 *
 *  Copyright 2008-2011 Matus Chochlik. Distributed under the Boost
 *  Software License, Version 1.0. (See accompanying file
 *  LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
 */

#ifndef BOOST_PUDDLE_AUXILIARY_INTEGER_1103151313_HPP
#define BOOST_PUDDLE_AUXILIARY_INTEGER_1103151313_HPP

#include <boost/puddle/auxiliary/fwd.hpp>
#include <boost/puddle/auxiliary/base_wrap.hpp>
#include <type_traits>

BOOST_PUDDLE_NAMESPACE_BEGIN
namespace aux {

template <typename T, T Value>
struct integer<std::integral_constant<T, Value> >
 : base_wrapper<std::integral_constant<T, Value> >
{
        static std::integral_constant<T, Value> static_value(void)
        {
                return std::integral_constant<T, Value>();
        }

        static T value(void)
        {
                return Value;
        }

        operator T (void) const
        {
                return Value;
        }

        integer<std::integral_constant<T, !Value> >
        operator ! (void) const
        {
                return integer<std::integral_constant<T, !Value> >();
        }

        template <T OtherValue>
        friend bool operator ==
        (integer, integer<std::integral_constant<T, OtherValue> >)
        {
                return Value == OtherValue;
        }

        template <T OtherValue>
        friend bool operator !=
        (integer, integer<std::integral_constant<T, OtherValue> >)
        {
                return Value != OtherValue;
        }

        template <T OtherValue>
        friend bool operator <=
        (integer, integer<std::integral_constant<T, OtherValue> >)
        {
                return Value <= OtherValue;
        }

        template <T OtherValue>
        friend bool operator >=
        (integer, integer<std::integral_constant<T, OtherValue> >)
        {
                return Value >= OtherValue;
        }

        template <T OtherValue>
        friend bool operator <
        (integer, integer<std::integral_constant<T, OtherValue> >)
        {
                return Value <  OtherValue;
        }

        template <T OtherValue>
        friend bool operator >
        (integer, integer<std::integral_constant<T, OtherValue> >)
        {
                return Value >  OtherValue;
        }

        template <T OtherValue>
        friend auto operator +
        (integer, integer<std::integral_constant<T, OtherValue> >) ->
        integer<std::integral_constant<T, Value+OtherValue> >
        {
                return integer<std::integral_constant<T, Value+OtherValue> >();
        }

        template <T OtherValue>
        friend auto operator -
        (integer, integer<std::integral_constant<T, OtherValue> >) ->
        integer<std::integral_constant<T, Value-OtherValue> >
        {
                return integer<std::integral_constant<T, Value-OtherValue> >();
        }

        template <T OtherValue>
        friend auto operator *
        (integer, integer<std::integral_constant<T, OtherValue> >) ->
        integer<std::integral_constant<T, Value*OtherValue> >
        {
                return integer<std::integral_constant<T, Value*OtherValue> >();
        }

        template <T OtherValue>
        friend auto operator /
        (integer, integer<std::integral_constant<T, OtherValue> >) ->
        integer<std::integral_constant<T, Value/OtherValue> >
        {
                return integer<std::integral_constant<T, Value/OtherValue> >();
        }

        template <T OtherValue>
        friend auto operator %
        (integer, integer<std::integral_constant<T, OtherValue> >) ->
        integer<std::integral_constant<T, Value%OtherValue> >
        {
                return integer<std::integral_constant<T, Value%OtherValue> >();
        }

        template <T OtherValue>
        friend auto operator &
        (integer, integer<std::integral_constant<T, OtherValue> >) ->
        integer<std::integral_constant<T, Value&OtherValue> >
        {
                return integer<std::integral_constant<T, Value&OtherValue> >();
        }

        template <T OtherValue>
        friend auto operator |
        (integer, integer<std::integral_constant<T, OtherValue> >) ->
        integer<std::integral_constant<T, Value|OtherValue> >
        {
                return integer<std::integral_constant<T, Value|OtherValue> >();
        }

        template <T OtherValue>
        friend auto operator &&
        (integer, integer<std::integral_constant<T, OtherValue> >) ->
        integer<std::integral_constant<T, Value&&OtherValue> >
        {
                return integer<std::integral_constant<T, Value&&OtherValue> >();
        }

        template <T OtherValue>
        friend auto operator ||
        (integer, integer<std::integral_constant<T, OtherValue> >) ->
        integer<std::integral_constant<T, Value||OtherValue> >
        {
                return integer<std::integral_constant<T, Value||OtherValue> >();
        }
};

} // namespace aux
BOOST_PUDDLE_NAMESPACE_END

#endif //include guard

