/**
 * .file boost/puddle/auxiliary/specifier.hpp
 * .brief The specifier wrapper
 *
 *  Copyright 2008-2011 Matus Chochlik. Distributed under the Boost
 *  Software License, Version 1.0. (See accompanying file
 *  LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
 */

#ifndef BOOST_PUDDLE_AUXILIARY_SPECIFIER_1103160725_HPP
#define BOOST_PUDDLE_AUXILIARY_SPECIFIER_1103160725_HPP

#include <boost/puddle/auxiliary/fwd.hpp>
#include <boost/puddle/auxiliary/base_wrap.hpp>
#include <type_traits>

BOOST_PUDDLE_NAMESPACE_BEGIN
namespace aux {

template <typename Specifier>
struct specifier : base_wrapper<Specifier>
{
public:
        template <typename OtherSpecifier>
        static bool is_a(OtherSpecifier)
        {
                return std::is_same<
                        OtherSpecifier,
                        Specifier
                >::value || std::is_base_of<
                        OtherSpecifier,
                        Specifier
                >::value;
        }

        static bool is_none(void)
        {
                return is_a(boost::mirror::spec_none_tag());
        }

#define BOOST_PUDDLE_HELPER_MAKE_SPECIFIER_IS_X_FUNC(SPEC, X) \
        static bool is_ ## SPEC (void) \
        { \
                return is_a(boost::mirror::spec_ ## SPEC ## _tag()); \
        }

BOOST_MIRROR_FOR_EACH_SPECIFIER(BOOST_PUDDLE_HELPER_MAKE_SPECIFIER_IS_X_FUNC, _)

#undef BOOST_PUDDLE_HELPER_MAKE_SPECIFIER_IS_X_FUNC

private:
        template <typename OtherSpecifier>
        static bool equal(specifier, specifier<OtherSpecifier>)
        {
                return is_a(OtherSpecifier());
        }

        static bool less(specifier, specifier)
        {
                return false;
        }

        template <typename OtherSpecifier>
        static bool less(specifier, specifier<OtherSpecifier>)
        {
                return Specifier::keyword() < OtherSpecifier::keyword();
        }
public:
        template <typename X>
        friend bool operator == (specifier a, X b)
        {
                return equal(a, b);
        }

        template <typename X>
        friend bool operator != (specifier a, X b)
        {
                return !equal(a, b);
        }

        template <typename X>
        friend bool operator <= (specifier a, X b)
        {
                return equal(a, b) || less(a, b);
        }

        template <typename X>
        friend bool operator >= (specifier a, X b)
        {
                return !less(a, b);
        }

        template <typename X>
        friend bool operator <  (specifier a, X b)
        {
                return less(a, b);
        }

        template <typename X>
        friend bool operator >  (specifier a, X b)
        {
                return !equal(a, b) && !less(a, b);
        }

        operator bool (void) const
        {
                return !is_none();
        }

        bool operator ! (void) const
        {
                return is_none();
        }

        static std::string keyword(void)
        {
                return Specifier::keyword();
        }
};

} // namespace aux
BOOST_PUDDLE_NAMESPACE_END

#endif //include guard

