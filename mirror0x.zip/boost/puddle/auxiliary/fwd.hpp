/**
 * .file boost/puddle/auxiliary/fwd.hpp
 * .brief Forward declarations
 *
 *  Copyright 2008-2011 Matus Chochlik. Distributed under the Boost
 *  Software License, Version 1.0. (See accompanying file
 *  LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
 */

#ifndef BOOST_PUDDLE_AUXILIARY_FWD_1103151301_HPP
#define BOOST_PUDDLE_AUXILIARY_FWD_1103151301_HPP

#include <boost/puddle/config.hpp>

BOOST_PUDDLE_NAMESPACE_BEGIN
namespace aux {

template <typename IntegralConstant>
struct integer;

template <typename Range>
struct range;

template <typename SpecifierTag>
struct specifier;

template <typename ContainerKindTag>
struct container_kind;

template <typename MetaMetaObject>
struct meta_meta_object;

template <typename MetaObject>
struct meta_object;

template <typename MetaNamedObject>
struct meta_named_object;

template <typename MetaScopedObject>
struct meta_scoped_object;

template <typename MetaNamedScopedObject>
struct meta_named_scoped_object;

template <typename MetaScope>
struct meta_scope;

template <typename MetaGlobalScope>
struct meta_unspecified_scope;

template <typename MetaNamespace>
struct meta_namespace;

template <typename MetaGlobalScope>
struct meta_global_scope;

template <typename MetaType>
struct meta_type;

template <typename MetaTypedef>
struct meta_typedef;

template <typename MetaTemplatedType>
struct meta_templated_type;

template <typename MetaTypeTemplate>
struct meta_type_template;

template <typename MetaClass>
struct meta_class;

template <typename MetaClassOrEnumMember>
struct meta_class_or_enum_member;

template <typename MetaClassMember>
struct meta_class_member;

template <typename MetaTemplatedClass>
struct meta_templated_class;

template <typename MetaEnum>
struct meta_enum;

template <typename MetaEnumValue>
struct meta_enum_value;

template <typename MetaInheritance>
struct meta_inheritance;

template <typename MetaVariable>
struct meta_variable;

template <typename MetaFreeVariable>
struct meta_free_variable;

template <typename MetaFreeVariable>
struct meta_plain_free_variable;

template <typename MetaMemberVariable>
struct meta_member_variable;

template <typename MetaPlainMemberVariable>
struct meta_plain_member_variable;

template <typename MetaParameter>
struct meta_parameter;

template <typename MetaFunction>
struct meta_function;

template <typename MetaMemberFunction>
struct meta_member_function;

template <typename MetaConstructor>
struct meta_constructor;

template <typename MetaConversionOperator>
struct meta_conversion_operator;

template <typename MetaTraversal>
struct meta_traversal;

template <typename MetaLocator>
struct meta_locator;

template <typename MetaInserter>
struct meta_inserter;

template <typename MetaEraser>
struct meta_eraser;

template <typename MetaContainer>
struct meta_container;

} // namespace aux
BOOST_PUDDLE_NAMESPACE_END

#endif //include guard

