/**
 * .file boost/puddle/auxiliary/by_name.hpp
 * .brief Implementation of the by_name functions
 *
 *  Copyright 2008-2011 Matus Chochlik. Distributed under the Boost
 *  Software License, Version 1.0. (See accompanying file
 *  LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
 */

#ifndef BOOST_PUDDLE_AUXILIARY_BY_NAME_1103230901_HPP
#define BOOST_PUDDLE_AUXILIARY_BY_NAME_1103230901_HPP

#include <boost/puddle/auxiliary/fwd.hpp>
#include <boost/puddle/auxiliary/wrap.hpp>

BOOST_PUDDLE_NAMESPACE_BEGIN
namespace aux {

template <class MetaClass>
struct by_name_scope_transf
{
        struct type
        {
                template <typename T>
                type(const T&){ }
        };
};

template <class MetaVariable>
struct by_name_memvar_transf
{
        struct type
        {
                template <class TransfClass>
                type(TransfClass&, int)
                { }

                typename wrap<MetaVariable>::type
                operator()(void) const
                {
                        return typename wrap<MetaVariable>::type();
                }
        };
};

} // namespace aux
BOOST_PUDDLE_NAMESPACE_END

#endif //include guard

