/**
 * .file boost/puddle/auxiliary/wrap.hpp
 * .brief Implementation of the wrap helper function
 *
 *  Copyright 2008-2011 Matus Chochlik. Distributed under the Boost
 *  Software License, Version 1.0. (See accompanying file
 *  LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
 */

#ifndef BOOST_PUDDLE_AUXILIARY_WRAP_1103151308_HPP
#define BOOST_PUDDLE_AUXILIARY_WRAP_1103151308_HPP

#include <boost/puddle/config.hpp>
#include <boost/puddle/auxiliary/fwd.hpp>
#include <boost/mirror/tag_dispatch.hpp>

BOOST_PUDDLE_NAMESPACE_BEGIN
namespace aux {

template <typename MetaObject, typename Tag>
struct do_wrap;

template <typename MetaMetaObject>
struct do_wrap<MetaMetaObject, boost::mirror::meta_meta_object_tag>
{
        typedef meta_meta_object<MetaMetaObject> type;
};

#define BOOST_PUDDLE_HELPER_SPEC_DO_WRAP(OBJECT, X) \
template <typename Meta ## OBJECT> \
struct do_wrap<Meta ## OBJECT, boost::mirror::meta_## OBJECT ##_tag> \
{ \
        typedef meta_## OBJECT<Meta ## OBJECT> type; \
};

BOOST_MIRROR_FOR_EACH_META_OBJECT(BOOST_PUDDLE_HELPER_SPEC_DO_WRAP, _)
#undef BOOST_PUDDLE_HELPER_SPEC_DO_WRAP

template <typename MetaObject>
struct wrap
{
        wrap(void) = delete;
        wrap(const wrap&) = delete;

        typedef typename do_wrap<
                MetaObject,
                typename boost::mirror::meta_object_category<MetaObject>::type
        >::type type;
};

} // namespace aux
BOOST_PUDDLE_NAMESPACE_END

#endif //include guard

