/**
 * @file boost/lagoon/config.hpp
 * @brief Compilation configuration options
 *
 *
 *  Copyright 2008-2010 Matus Chochlik. Distributed under the Boost
 *  Software License, Version 1.0. (See accompanying file
 *  LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
 */

#ifndef BOOST_LAGOON_CONFIG_1011291729_HPP
#define BOOST_LAGOON_CONFIG_1011291729_HPP

// Macro that begins the Lagoon library namespace
#define BOOST_LAGOON_NAMESPACE_BEGIN \
namespace boost { namespace lagoon {

// Macro that ends the Lagoon library namespace
#define BOOST_LAGOON_NAMESPACE_END \
} /* namespace lagoon */ } /* namespace boost */

/** @defgroup lagoon_config_options Lagoon - Configuration options
 *
 *  The polymorphic nature of the interfaces and their implementations
 *  makes Lagoon-using applications prone to have long compilation times
 *  and large resulting executables.
 *  Lagoon is however highly configurable via preprocessor options,
 *  and lets the user preciselly specify which features should
 *  be included in the interfaces and what should be ommited. This
 *  way the application does not pay for things it does not use
 *  in terms of resources necessary for the compilation and the resulting
 *  code size.
 */

#ifdef BOOST_MIRROR_DOCUMENTATION_ONLY
/** @def BOOST_LAGOON_DYNAMIC_LINKING
 *  @brief Enables the dynamic linking of Lagoon's meta-objects
 *
 *  Setting this symbol to a zero vs. nonzero integer value switches
 *  between the header-only statically linked and the dynamically linked
 *  meta-objects respectivelly.
 *
 *  TODO: elaborate on what's the difference
 *
 *  @ingroup lagoon_config_options
 */
#define BOOST_LAGOON_DYNAMIC_LINKING 0 // or 1
#endif
#ifndef BOOST_LAGOON_DYNAMIC_LINKING
#define BOOST_LAGOON_DYNAMIC_LINKING 0
#endif

#ifdef BOOST_MIRROR_DOCUMENTATION_ONLY
/** @def BOOST_LAGOON_MNSO_WITH_LOCAL_NAME
 *  @brief Enables the meta_named_scoped_objects's local_name member function
 *
 *  Setting this to a nonzero integer value enables the
 *  @link boost::lagoon::meta_named_scoped_object::local_name local_name@endlink
 *  member function in the meta_named_scoped_object interface.
 *
 *  @ingroup lagoon_config_options
 */
#define BOOST_LAGOON_MNSO_WITH_LOCAL_NAME 0 // or 1
#else
#ifndef BOOST_LAGOON_MNSO_WITH_LOCAL_NAME
#define BOOST_LAGOON_MNSO_WITH_LOCAL_NAME 0
#endif
#endif

#ifdef BOOST_MIRROR_DOCUMENTATION_ONLY
/** @def BOOST_LAGOON_ALL_TYPE_TRAITS
 *  @brief Enables the type trait-related member function in the meta_type
 *
 *  Setting this to a non-zero value enables all supported
 *  type traits member functions in the meta_type interface.
 *  Otherwise the individual traits can be enabled separatelly
 *  by setting the appropriate preprocessor switches (listed below).
 *
 *  Set to zero (disabled) by default.
 *
 *  @see BOOST_LAGOON_MT_WITH_DEFAULT
 *  @see BOOST_LAGOON_MT_WITH_IS_DEFAULT_CONSTRUCTIBLE
 *  @see BOOST_LAGOON_MT_WITH_IS_COPY_CONSTRUCTIBLE
 *  @see BOOST_LAGOON_MT_WITH_ALIGNMENT_OF
 *  @see BOOST_LAGOON_MT_WITH_IS_ARRAY
 *  @see BOOST_LAGOON_MT_WITH_IS_CONST
 *  @see BOOST_LAGOON_MT_WITH_IS_VOLATILE
 *  @see BOOST_LAGOON_MT_WITH_IS_POINTER
 *  @see BOOST_LAGOON_MT_WITH_IS_REFERENCE
 *  @see BOOST_LAGOON_MT_WITH_ADD_CONST
 *  @see BOOST_LAGOON_MT_WITH_ADD_CV
 *  @see BOOST_LAGOON_MT_WITH_ADD_VOLATILE
 *  @see BOOST_LAGOON_MT_WITH_REMOVE_CONST
 *  @see BOOST_LAGOON_MT_WITH_REMOVE_CV
 *  @see BOOST_LAGOON_MT_WITH_REMOVE_VOLATILE
 *  @see BOOST_LAGOON_MT_WITH_REMOVE_POINTER
 *  @see BOOST_LAGOON_MT_WITH_REMOVE_REFERENCE
 *  @see BOOST_LAGOON_MT_WITH_REMOVE_EXTENT
 *
 *  @ingroup lagoon_config_options
 */
#define BOOST_LAGOON_ALL_TYPE_TRAITS 0 // or 1
#endif
#ifndef BOOST_LAGOON_ALL_TYPE_TRAITS
#define BOOST_LAGOON_ALL_TYPE_TRAITS 0
#endif

#ifdef BOOST_MIRROR_DOCUMENTATION_ONLY
/** @def BOOST_LAGOON_MT_WITH_DEFAULT
 *  @brief Enables the meta_type's default_ member function
 *
 *  Setting this to a nonzero integer value enables the
 *  @link boost::lagoon::meta_type::default_ default_@endlink
 *  member function in the meta_type interface.
 *
 *  @ingroup lagoon_config_options
 */
#define BOOST_LAGOON_MT_WITH_DEFAULT 0 // or 1
#endif
#ifndef BOOST_LAGOON_MT_WITH_DEFAULT
#define BOOST_LAGOON_MT_WITH_DEFAULT 0
#endif

#ifdef BOOST_MIRROR_DOCUMENTATION_ONLY
/** @def BOOST_LAGOON_MT_WITH_IS_DEFAULT_CONSTRUCTIBLE
 *  @brief Enables the meta_type's is_default_constructible member function
 *
 *  Setting this to a nonzero integer value enables the
 *  @link boost::lagoon::meta_type::is_default_constructible
 *  is_default_constructible@endlink
 *  member function in the meta_type interface.
 *
 *  @see BOOST_LAGOON_ALL_TYPE_TRAITS
 *  @ingroup lagoon_config_options
 */
#define BOOST_LAGOON_MT_WITH_IS_DEFAULT_CONSTRUCTIBLE 0 // or 1
#endif
#ifndef BOOST_LAGOON_MT_WITH_IS_DEFAULT_CONSTRUCTIBLE
#define BOOST_LAGOON_MT_WITH_IS_DEFAULT_CONSTRUCTIBLE 0
#endif

#ifdef BOOST_MIRROR_DOCUMENTATION_ONLY
/** @def BOOST_LAGOON_MT_WITH_IS_COPY_CONSTRUCTIBLE
 *  @brief Enables the meta_type's is_copy_constructible member function
 *
 *  Setting this to a nonzero integer value enables the
 *  @link boost::lagoon::meta_type::is_copy_constructible
 *  is_copy_constructible@endlink
 *  member function in the meta_type interface.
 *
 *  @see BOOST_LAGOON_ALL_TYPE_TRAITS
 *  @ingroup lagoon_config_options
 */
#define BOOST_LAGOON_MT_WITH_IS_COPY_CONSTRUCTIBLE 0 // or 1
#endif
#ifndef BOOST_LAGOON_MT_WITH_IS_COPY_CONSTRUCTIBLE
#define BOOST_LAGOON_MT_WITH_IS_COPY_CONSTRUCTIBLE 0
#endif

#ifdef BOOST_MIRROR_DOCUMENTATION_ONLY
/** @def BOOST_LAGOON_MT_WITH_ALIGNMENT_OF
 *  @brief Enables the meta_type's alignment_of member function
 *
 *  Setting this to a nonzero integer value enables the
 *  @link boost::lagoon::meta_type::alignment_of alignment_of@endlink
 *  member function in the meta_type interface.
 *
 *  @see BOOST_LAGOON_ALL_TYPE_TRAITS
 *  @ingroup lagoon_config_options
 */
#define BOOST_LAGOON_MT_WITH_ALIGNMENT_OF 0 // or 1
#endif
#ifndef BOOST_LAGOON_MT_WITH_ALIGNMENT_OF
#define BOOST_LAGOON_MT_WITH_ALIGNMENT_OF 0
#endif

#ifdef BOOST_MIRROR_DOCUMENTATION_ONLY
/** @def BOOST_LAGOON_MT_WITH_IS_ARRAY
 *  @brief Enables the meta_type's is_array member function
 *
 *  Setting this to a nonzero integer value enables the
 *  @link boost::lagoon::meta_type::is_array is_array@endlink
 *  member function in the meta_type interface.
 *
 *  @see BOOST_LAGOON_ALL_TYPE_TRAITS
 *  @ingroup lagoon_config_options
 */
#define BOOST_LAGOON_MT_WITH_IS_ARRAY 0 // or 1
#endif
#ifndef BOOST_LAGOON_MT_WITH_IS_ARRAY
#define BOOST_LAGOON_MT_WITH_IS_ARRAY 0
#endif

#ifdef BOOST_MIRROR_DOCUMENTATION_ONLY
/** @def BOOST_LAGOON_MT_WITH_IS_CONST
 *  @brief Enables the meta_type's is_const member function
 *
 *  Setting this to a nonzero integer value enables the
 *  @link boost::lagoon::meta_type::is_const is_const@endlink
 *  member function in the meta_type interface.
 *
 *  @see BOOST_LAGOON_ALL_TYPE_TRAITS
 *  @ingroup lagoon_config_options
 */
#define BOOST_LAGOON_MT_WITH_IS_CONST 0 // or 1
#endif
#ifndef BOOST_LAGOON_MT_WITH_IS_CONST
#define BOOST_LAGOON_MT_WITH_IS_CONST 0
#endif

#ifdef BOOST_MIRROR_DOCUMENTATION_ONLY
/** @def BOOST_LAGOON_MT_WITH_IS_POINTER
 *  @brief Enables the meta_type's is_pointer member function
 *
 *  Setting this to a nonzero integer value enables the
 *  @link boost::lagoon::meta_type::is_pointer is_pointer@endlink
 *  member function in the meta_type interface.
 *
 *  @see BOOST_LAGOON_ALL_TYPE_TRAITS
 *  @ingroup lagoon_config_options
 */
#define BOOST_LAGOON_MT_WITH_IS_POINTER 0 // or 1
#endif
#ifndef BOOST_LAGOON_MT_WITH_IS_POINTER
#define BOOST_LAGOON_MT_WITH_IS_POINTER 0
#endif

#ifdef BOOST_MIRROR_DOCUMENTATION_ONLY
/** @def BOOST_LAGOON_MT_WITH_IS_REFERENCE
 *  @brief Enables the meta_type's is_reference member function
 *
 *  Setting this to a nonzero integer value enables the
 *  @link boost::lagoon::meta_type::is_reference is_reference@endlink
 *  member function in the meta_type interface.
 *
 *  @see BOOST_LAGOON_ALL_TYPE_TRAITS
 *  @ingroup lagoon_config_options
 */
#define BOOST_LAGOON_MT_WITH_IS_REFERENCE 0 // or 1
#endif
#ifndef BOOST_LAGOON_MT_WITH_IS_REFERENCE
#define BOOST_LAGOON_MT_WITH_IS_REFERENCE 0
#endif

#ifdef BOOST_MIRROR_DOCUMENTATION_ONLY
/** @def BOOST_LAGOON_MT_WITH_IS_VOLATILE
 *  @brief Enables the meta_type's is_volatile member function
 *
 *  Setting this to a nonzero integer value enables the
 *  @link boost::lagoon::meta_type::is_volatile is_volatile@endlink
 *  member function in the meta_type interface.
 *
 *  @see BOOST_LAGOON_ALL_TYPE_TRAITS
 *  @ingroup lagoon_config_options
 */
#define BOOST_LAGOON_MT_WITH_IS_VOLATILE 0 // or 1
#endif
#ifndef BOOST_LAGOON_MT_WITH_IS_VOLATILE
#define BOOST_LAGOON_MT_WITH_IS_VOLATILE 0
#endif

#ifdef BOOST_MIRROR_DOCUMENTATION_ONLY
/** @def BOOST_LAGOON_MT_WITH_ADD_CONST
 *  @brief Enables the meta_type's add_const member function
 *
 *  Setting this to a nonzero integer value enables the
 *  @link boost::lagoon::meta_type::add_const add_const@endlink
 *  member function in the meta_type interface.
 *
 *  @see BOOST_LAGOON_ALL_TYPE_TRAITS
 *  @ingroup lagoon_config_options
 */
#define BOOST_LAGOON_MT_WITH_ADD_CONST 0 // or 1
#endif
#ifndef BOOST_LAGOON_MT_WITH_ADD_CONST
#define BOOST_LAGOON_MT_WITH_ADD_CONST 0
#endif

#ifdef BOOST_MIRROR_DOCUMENTATION_ONLY
/** @def BOOST_LAGOON_MT_WITH_ADD_CV
 *  @brief Enables the meta_type's add_cv member function
 *
 *  Setting this to a nonzero integer value enables the
 *  @link boost::lagoon::meta_type::add_cv add_cv@endlink
 *  member function in the meta_type interface.
 *
 *  @see BOOST_LAGOON_ALL_TYPE_TRAITS
 *  @ingroup lagoon_config_options
 */
#define BOOST_LAGOON_MT_WITH_ADD_CV 0 // or 1
#endif
#ifndef BOOST_LAGOON_MT_WITH_ADD_CV
#define BOOST_LAGOON_MT_WITH_ADD_CV 0
#endif

#ifdef BOOST_MIRROR_DOCUMENTATION_ONLY
/** @def BOOST_LAGOON_MT_WITH_ADD_VOLATILE
 *  @brief Enables the meta_type's add_volatile member function
 *
 *  Setting this to a nonzero integer value enables the
 *  @link boost::lagoon::meta_type::add_volatile add_volatile@endlink
 *  member function in the meta_type interface.
 *
 *  @see BOOST_LAGOON_ALL_TYPE_TRAITS
 *  @ingroup lagoon_config_options
 */
#define BOOST_LAGOON_MT_WITH_ADD_VOLATILE 0 // or 1
#endif
#ifndef BOOST_LAGOON_MT_WITH_ADD_VOLATILE
#define BOOST_LAGOON_MT_WITH_ADD_VOLATILE 0
#endif

#ifdef BOOST_MIRROR_DOCUMENTATION_ONLY
/** @def BOOST_LAGOON_MT_WITH_REMOVE_CONST
 *  @brief Enables the meta_type's remove_const member function
 *
 *  Setting this to a nonzero integer value enables the
 *  @link boost::lagoon::meta_type::remove_const remove_const@endlink
 *  member function in the meta_type interface.
 *
 *  @see BOOST_LAGOON_ALL_TYPE_TRAITS
 *  @ingroup lagoon_config_options
 */
#define BOOST_LAGOON_MT_WITH_REMOVE_CONST 0 // or 1
#endif
#ifndef BOOST_LAGOON_MT_WITH_REMOVE_CONST
#define BOOST_LAGOON_MT_WITH_REMOVE_CONST 0
#endif

#ifdef BOOST_MIRROR_DOCUMENTATION_ONLY
/** @def BOOST_LAGOON_MT_WITH_REMOVE_CV
 *  @brief Enables the meta_type's remove_cv member function
 *
 *  Setting this to a nonzero integer value enables the
 *  @link boost::lagoon::meta_type::remove_cv remove_cv@endlink
 *  member function in the meta_type interface.
 *
 *  @see BOOST_LAGOON_ALL_TYPE_TRAITS
 *  @ingroup lagoon_config_options
 */
#define BOOST_LAGOON_MT_WITH_REMOVE_CV 0 // or 1
#endif
#ifndef BOOST_LAGOON_MT_WITH_REMOVE_CV
#define BOOST_LAGOON_MT_WITH_REMOVE_CV 0
#endif

#ifdef BOOST_MIRROR_DOCUMENTATION_ONLY
/** @def BOOST_LAGOON_MT_WITH_REMOVE_VOLATILE
 *  @brief Enables the meta_type's remove_volatile member function
 *
 *  Setting this to a nonzero integer value enables the
 *  @link boost::lagoon::meta_type::remove_volatile remove_volatile@endlink
 *  member function in the meta_type interface.
 *
 *  @see BOOST_LAGOON_ALL_TYPE_TRAITS
 *  @ingroup lagoon_config_options
 */
#define BOOST_LAGOON_MT_WITH_REMOVE_VOLATILE 0 // or 1
#endif
#ifndef BOOST_LAGOON_MT_WITH_REMOVE_VOLATILE
#define BOOST_LAGOON_MT_WITH_REMOVE_VOLATILE 0
#endif

#ifdef BOOST_MIRROR_DOCUMENTATION_ONLY
/** @def BOOST_LAGOON_MT_WITH_REMOVE_POINTER
 *  @brief Enables the meta_type's remove_pointer member function
 *
 *  Setting this to a nonzero integer value enables the
 *  @link boost::lagoon::meta_type::remove_pointer remove_pointer@endlink
 *  member function in the meta_type interface.
 *
 *  @see BOOST_LAGOON_ALL_TYPE_TRAITS
 *  @ingroup lagoon_config_options
 */
#define BOOST_LAGOON_MT_WITH_REMOVE_POINTER 0 // or 1
#endif
#ifndef BOOST_LAGOON_MT_WITH_REMOVE_POINTER
#define BOOST_LAGOON_MT_WITH_REMOVE_POINTER 0
#endif

#ifdef BOOST_MIRROR_DOCUMENTATION_ONLY
/** @def BOOST_LAGOON_MT_WITH_REMOVE_REFERENCE
 *  @brief Enables the meta_type's remove_reference member function
 *
 *  Setting this to a nonzero integer value enables the
 *  @link boost::lagoon::meta_type::remove_reference remove_reference@endlink
 *  member function in the meta_type interface.
 *
 *  @see BOOST_LAGOON_ALL_TYPE_TRAITS
 *  @ingroup lagoon_config_options
 */
#define BOOST_LAGOON_MT_WITH_REMOVE_REFERENCE 0 // or 1
#endif
#ifndef BOOST_LAGOON_MT_WITH_REMOVE_REFERENCE
#define BOOST_LAGOON_MT_WITH_REMOVE_REFERENCE 0
#endif

#ifdef BOOST_MIRROR_DOCUMENTATION_ONLY
/** @def BOOST_LAGOON_MT_WITH_REMOVE_EXTENT
 *  @brief Enables the meta_type's remove_extent member function
 *
 *  Setting this to a nonzero integer value enables the
 *  @link boost::lagoon::meta_type::remove_extent remove_extent@endlink
 *  member function in the meta_type interface.
 *
 *  @see BOOST_LAGOON_ALL_TYPE_TRAITS
 *  @ingroup lagoon_config_options
 */
#define BOOST_LAGOON_MT_WITH_REMOVE_EXTENT 0 // or 1
#endif
#ifndef BOOST_LAGOON_MT_WITH_REMOVE_EXTENT
#define BOOST_LAGOON_MT_WITH_REMOVE_EXTENT 0
#endif

#ifdef BOOST_MIRROR_DOCUMENTATION_ONLY
/** @def BOOST_LAGOON_MT_WITH_MAKE_FACTORY
 *  @brief Enables the meta_type's make_factory member function.
 *
 *  Setting this switch to a non-zero value enables the meta_type's
 *  @link boost::lagoon::meta_type::make_factory make_factory@endlink
 *  member function, which can be used to build
 *  factories creating instances of the type reflected by meta-type.
 *
 *  @ingroup lagoon_config_options
 */
#define BOOST_LAGOON_MT_WITH_MAKE_FACTORY 0 // or 1
#endif
#ifndef BOOST_LAGOON_MT_WITH_MAKE_FACTORY
#define BOOST_LAGOON_MT_WITH_MAKE_FACTORY 0
#endif

#ifdef BOOST_MIRROR_DOCUMENTATION_ONLY
/** @def BOOST_LAGOON_MT_WITH_NEW
 *  @brief Enables the meta_type's new_ member function.
 *
 *  Setting this to non-zero integral value enables the
 *  @link boost::lagoon::meta_type::new_ new_@endlink member
 *  function in the meta_type interface.
 *
 *  @see BOOST_LAGOON_MT_WITH_NEW_COPY
 *  @see BOOST_LAGOON_MT_WITH_DELETE
 *  @see BOOST_LAGOON_MT_WITH_MAKE_SHARED
 *  @see BOOST_LAGOON_MT_WITH_MAKE_UNIQUE
 *
 *  @ingroup lagoon_config_options
 */
#define BOOST_LAGOON_MT_WITH_NEW 1 // or 0
#endif
#ifndef BOOST_LAGOON_MT_WITH_NEW
#define BOOST_LAGOON_MT_WITH_NEW 1
#endif

#ifdef BOOST_MIRROR_DOCUMENTATION_ONLY
/** @def BOOST_LAGOON_MT_WITH_NEW_COPY
 *  @brief Enables the meta_type's new_copy member function.
 *
 *  Setting this to non-zero integral value enables the
 *  @link boost::lagoon::meta_type::new_copy new_copy@endlink member
 *  function in the meta_type interface.
 *
 *  @see BOOST_LAGOON_MT_WITH_NEW
 *  @see BOOST_LAGOON_MT_WITH_DELETE
 *  @see BOOST_LAGOON_MT_WITH_MAKE_SHARED
 *  @see BOOST_LAGOON_MT_WITH_MAKE_UNIQUE
 *
 *  @ingroup lagoon_config_options
 */
#define BOOST_LAGOON_MT_WITH_NEW_COPY 0 // or 1
#endif
#ifndef BOOST_LAGOON_MT_WITH_NEW_COPY
#define BOOST_LAGOON_MT_WITH_NEW_COPY 0
#endif

#ifdef BOOST_MIRROR_DOCUMENTATION_ONLY
/** @def BOOST_LAGOON_MT_WITH_DELETE
 *  @brief Enables the meta_type's delete_ member function.
 *
 *  Setting this to non-zero integral value enables the
 *  @link boost::lagoon::meta_type::delete_ delete_@endlink member
 *  function in the meta_type interface.
 *
 *  @see BOOST_LAGOON_MT_WITH_NEW
 *  @see BOOST_LAGOON_MT_WITH_NEW_COPY
 *  @see BOOST_LAGOON_MT_WITH_MAKE_SHARED
 *  @see BOOST_LAGOON_MT_WITH_MAKE_UNIQUE
 *
 *  @ingroup lagoon_config_options
 */
#define BOOST_LAGOON_MT_WITH_DELETE 1 // or 0
#endif
#ifndef BOOST_LAGOON_MT_WITH_DELETE
#define BOOST_LAGOON_MT_WITH_DELETE 1
#endif

#ifdef BOOST_MIRROR_DOCUMENTATION_ONLY
/** @def BOOST_LAGOON_MT_WITH_MAKE_SHARED
 *  @brief Enables the meta_type's make_shared member function
 *
 *  Setting this to a nonzero integer value enables the
 *  @link boost::lagoon::meta_type::make_shared make_shared@endlink
 *  member function in the meta_type interface.
 *
 *  @see BOOST_LAGOON_MT_WITH_MAKE_SHARED
 *  @see BOOST_LAGOON_MT_WITH_DELETE
 *
 *  @ingroup lagoon_config_options
 */
#define BOOST_LAGOON_MT_WITH_MAKE_SHARED 0 // or 1
#endif
#ifndef BOOST_LAGOON_MT_WITH_MAKE_SHARED
#define BOOST_LAGOON_MT_WITH_MAKE_SHARED 0
#endif

#ifdef BOOST_MIRROR_DOCUMENTATION_ONLY
/** @def BOOST_LAGOON_MT_WITH_MAKE_UNIQUE
 *  @brief Enables the meta_type's make_unique member function
 *
 *  Setting this to a nonzero integer value enables the
 *  @link boost::lagoon::meta_type::make_unique make_unique@endlink
 *  member function in the meta_type interface.
 *
 *  @see BOOST_LAGOON_MT_WITH_MAKE_SHARED
 *  @see BOOST_LAGOON_MT_WITH_DELETE
 *
 *  @ingroup lagoon_config_options
 */
#define BOOST_LAGOON_MT_WITH_MAKE_UNIQUE 0 // or 1
#endif
#ifndef BOOST_LAGOON_MT_WITH_MAKE_UNIQUE
#define BOOST_LAGOON_MT_WITH_MAKE_UNIQUE 0
#endif

#ifdef BOOST_MIRROR_DOCUMENTATION_ONLY
/** @def BOOST_LAGOON_MC_WITH_ALL_MEMBER_VARIABLES
 *  @brief Enables the meta_class' all_member_variables member function
 *
 *  Setting this to a nonzero integer value enables the
 *  @link boost::lagoon::meta_class::all_member_variables
 *  all_member_variables@endlink
 *  member function in the meta_class interface.
 *
 *  @ingroup lagoon_config_options
 */
#define BOOST_LAGOON_MC_WITH_ALL_MEMBER_VARIABLES 0 // or 1
#endif
#ifndef BOOST_LAGOON_MC_WITH_ALL_MEMBER_VARIABLES
#define BOOST_LAGOON_MC_WITH_ALL_MEMBER_VARIABLES 0
#endif

#ifdef BOOST_MIRROR_DOCUMENTATION_ONLY
/** @def BOOST_LAGOON_FACT_WITH_CREATE
 *  @brief Enables the polymorph_factory's create member function
 *
 *  Setting this to a nonzero integer value enables the
 *  @link boost::lagoon::polymorph_factory::create create@endlink
 *  member function in the polymorphic_factory interface.
 *
 *  @ingroup lagoon_config_options
 */
#define BOOST_LAGOON_FACT_WITH_CREATE 0 // or 1
#endif
#ifndef BOOST_LAGOON_FACT_WITH_CREATE
#define BOOST_LAGOON_FACT_WITH_CREATE 0
#endif

#ifdef BOOST_MIRROR_DOCUMENTATION_ONLY
/** @def BOOST_LAGOON_NO_NAMESPACE_MEMBERS
 *  @brief Disables the traversal of namespace members
 *
 *  If this is defined as zero then namespace members can be iterated
 *  otherwise the members() function for meta-namespace
 *  returns an empty range.
 *
 *  Setting this to a non-zero value can greatly improve compilation
 *  times if namespace member traversal is not needed.
 *
 *  @ingroup lagoon_config_options
 */
#define BOOST_LAGOON_NO_NAMESPACE_MEMBERS 0 // or 1
#endif
#ifndef BOOST_LAGOON_NO_NAMESPACE_MEMBERS
#define BOOST_LAGOON_NO_NAMESPACE_MEMBERS 0
#endif

#endif //include guard

