/**
 * @file boost/lagoon/ranges.hpp
 * @brief Range utilities
 *
 *  Copyright 2008-2011 Matus Chochlik. Distributed under the Boost
 *  Software License, Version 1.0. (See accompanying file
 *  LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
 */

#ifndef BOOST_LAGOON_RANGES_1011291729_HPP
#define BOOST_LAGOON_RANGES_1011291729_HPP


BOOST_LAGOON_NAMESPACE_BEGIN

/** @defgroup lagoon_ranges Lagoon - Range utilities
 *
 *  Lagoon provides an extensive set of utilities for tasks like
 *  range transformation, filtering, sorting, searching, etc. which
 *  make writing complex range manipulating algorithms easier and
 *  more straightforward.
 */

BOOST_LAGOON_NAMESPACE_END

#include <boost/lagoon/range/for_each.hpp>
#include <boost/lagoon/range/fold.hpp>
#include <boost/lagoon/range/transform.hpp>
#include <boost/lagoon/range/contains.hpp>
#include <boost/lagoon/range/find_if.hpp>
#include <boost/lagoon/range/only_if.hpp>
#include <boost/lagoon/range/limit.hpp>
#include <boost/lagoon/range/offset.hpp>
#include <boost/lagoon/range/sort.hpp>
#include <boost/lagoon/range/until.hpp>
#include <boost/lagoon/range/chain.hpp>
#include <boost/lagoon/range/link.hpp>
#include <boost/lagoon/range/extract.hpp>
#include <boost/lagoon/range/flatten.hpp>
//
#include <boost/lagoon/range/std_range.hpp>
#endif //include guard

