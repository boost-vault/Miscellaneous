/**
 *  .file boost/lagoon/auxiliary/range_maker.hpp
 *  .brief Implementation of an internal helper class for initializing
 *   run-time meta-object ranges.
 *
 *  Copyright 2008-2011 Matus Chochlik. Distributed under the Boost
 *  Software License, Version 1.0. (See accompanying file
 *  LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
 */

#ifndef BOOST_LAGOON_AUX_RANGE_MAKER_1011291729_HPP
#define BOOST_LAGOON_AUX_RANGE_MAKER_1011291729_HPP

#include <boost/lagoon/utils.hpp>
#include <boost/lagoon/auxiliary/object_getter.hpp>
#include <boost/mirror/tag_dispatch.hpp>
#include <vector>

BOOST_LAGOON_NAMESPACE_BEGIN
namespace aux {

// Helper functor used for constructing ranges of meta-objects
template <typename Interface>
struct range_maker
{
        // The type of the object container to be initialized
        typedef std::vector<shared<Interface> > item_list;
        item_list& items_ref;

        // constructor taking a reference to the container
        range_maker(item_list& ref)
         : items_ref(ref)
        { }

        // fallback do-nothing implementation for other meta-objects
        template <typename MetaObject>
        void append_item(MetaObject, boost::mirror::meta_object_tag) const { }

        // implementation of append_item for common objects
        template <typename MetaObject>
        void do_append_item(MetaObject) const
        {
                // use the make function to get an instance
                // of the run-time meta-type with the selected
                // Interface
                items_ref.push_back(
                        get_meta_object<
                                MetaObject,
                                Interface
                        >()
                );
        }

        // implementation of append for meta-namespaces
        template <typename MetaNamespace>
        void append_item(
                MetaNamespace mo,
                boost::mirror::meta_namespace_tag
        ) const
        {
                do_append_item(mo);
        }

        // implementation of append for meta-types
        template <typename MetaType>
        void append_item(
                MetaType mo,
                boost::mirror::meta_type_tag
        ) const
        {
                do_append_item(mo);
        }

        // implementation of append for meta-class
        template <typename MetaClass>
        void append_item(
                MetaClass mo,
                boost::mirror::meta_class_tag
        ) const
        {
                do_append_item(mo);
        }

        // implementation of append for meta-type-templates
        template <typename MetaTemplate>
        void append_item(
                MetaTemplate mo,
                boost::mirror::meta_type_template_tag
        ) const
        {
                do_append_item(mo);
        }

        // implementation of append for meta-templated-type
        template <typename MetaTemplatedType>
        void append_item(
                MetaTemplatedType mo,
                boost::mirror::meta_templated_type_tag
        ) const
        {
                do_append_item(mo);
        }


        // implementation of append for meta-templated-class
        template <typename MetaTemplatedClass>
        void append_item(
                MetaTemplatedClass mo,
                boost::mirror::meta_templated_class_tag
        ) const
        {
                do_append_item(mo);
        }

        // implementation of append for meta-inheritance
        template <typename MetaInheritance>
        void append_item(
                MetaInheritance mo,
                boost::mirror::meta_inheritance_tag
        ) const
        {
                do_append_item(mo);
        }

        // implementation of append for meta-member variable
        template <typename MetaVariable>
        void append_item(
                MetaVariable mo,
                boost::mirror::meta_variable_tag
        ) const
        {
                do_append_item(mo);
        }

        // implementation of append for meta-member variable
        template <typename MetaMemberVariable>
        void append_item(
                MetaMemberVariable mo,
                boost::mirror::meta_member_variable_tag
        ) const
        {
                do_append_item(mo);
        }

        // implementation of append for meta-constructor
        template <typename MetaConstructor>
        void append_item(
                MetaConstructor mo,
                boost::mirror::meta_constructor_tag
        ) const
        {
                do_append_item(mo);
        }

        // implementation of append for meta-member function
        template <typename MetaMemberFunction>
        void append_item(
                MetaMemberFunction mo,
                boost::mirror::meta_member_function_tag
        ) const
        {
                do_append_item(mo);
        }

        // operator called for each element of compile-time meta-object range
        template <typename MetaObject>
        void operator()(MetaObject mo) const
        {
                // call the appropriate overload of append item based
                // on the category of the meta-object
                append_item(mo, boost::mirror::categorize_meta_object(mo));
        }
};

} // namespace aux
BOOST_LAGOON_NAMESPACE_END

#endif //include guard

