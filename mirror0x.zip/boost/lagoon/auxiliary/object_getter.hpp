/**
 *  .file boost/lagoon/auxiliary/object_getter.hpp
 *  .brief Switch of the implementations of object_getter
 *
 *
 *  Copyright 2008-2011 Matus Chochlik. Distributed under the Boost
 *  Software License, Version 1.0. (See accompanying file
 *  LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
 */

#ifndef BOOST_LAGOON_AUX_OBJECT_GETTER_1011291729_HPP
#define BOOST_LAGOON_AUX_OBJECT_GETTER_1011291729_HPP

BOOST_LAGOON_NAMESPACE_BEGIN
namespace aux {

template <
        typename MetaObject,
        template <class> class Implementation
>
inline Implementation<MetaObject>* inst_tpl_meta_object(void)
{
        static Implementation<MetaObject> mo;
        return &mo;
}

template <
        typename MetaObject,
        class Implementation
>
inline Implementation* inst_meta_object(void)
{
        MetaObject smo;
        static Implementation mo(smo);
        return &mo;
}

template <
        typename MetaObject,
        typename Interface,
        template <class> class Implementation
>
inline shared<Interface> do_get_tpl_meta_object(void)
{
        return shared<Interface>(
                inst_tpl_meta_object<
                        MetaObject,
                        Implementation
                >()
        );
}

template <
        typename MetaObject,
        typename Interface,
        class Implementation
>
inline shared<Interface> do_get_meta_object(void)
{
        return shared<Interface>(
                inst_meta_object<
                        MetaObject,
                        Implementation
                >()
        );
}

template <typename MetaNamespace, typename Interface>
inline shared<Interface> get_meta_object(boost::mirror::meta_namespace_tag)
{
        return do_get_meta_object<
                MetaNamespace,
                Interface,
                meta_namespace_
        >();
}

template <typename MetaType, typename Interface>
inline shared<Interface> get_meta_object(boost::mirror::meta_type_tag)
{
        return do_get_tpl_meta_object<
                MetaType,
                Interface,
                meta_type_
        >();
}

template <typename MetaTypeTemplate, typename Interface>
inline shared<Interface>
get_meta_object(boost::mirror::meta_type_template_tag)
{
        return do_get_meta_object<
                MetaTypeTemplate,
                Interface,
                meta_type_template_
        >();
}

template <typename MetaTypedef, typename Interface>
inline shared<Interface>
get_meta_object(boost::mirror::meta_typedef_tag)
{
        return do_get_tpl_meta_object<
                MetaTypedef,
                Interface,
                meta_typedef_
        >();
}

template <typename MetaTemplatedType, typename Interface>
inline shared<Interface>
get_meta_object(boost::mirror::meta_templated_type_tag)
{
        return do_get_tpl_meta_object<
                MetaTemplatedType,
                Interface,
                meta_templated_type_
        >();
}

template <typename MetaClass, typename Interface>
inline shared<Interface> get_meta_object(boost::mirror::meta_class_tag)
{
        return do_get_tpl_meta_object<
                MetaClass,
                Interface,
                meta_class_
        >();
}

template <typename MetaTemplatedClass, typename Interface>
inline shared<Interface> get_meta_object(
        boost::mirror::meta_templated_class_tag
)
{
        return do_get_tpl_meta_object<
                MetaTemplatedClass,
                Interface,
                meta_templated_class_
        >();
}

template <typename MetaEnum, typename Interface>
inline shared<Interface> get_meta_object(boost::mirror::meta_enum_tag)
{
        return do_get_tpl_meta_object<
                MetaEnum,
                Interface,
                meta_enum_
        >();
}

template <typename MetaInheritance, typename Interface>
inline shared<Interface>
get_meta_object(boost::mirror::meta_inheritance_tag)
{
        return do_get_meta_object<
                MetaInheritance,
                Interface,
                meta_inheritance_
        >();
}

template <typename MetaVariable, typename Interface>
inline shared<Interface>
get_meta_object(boost::mirror::meta_variable_tag)
{
        return do_get_tpl_meta_object<
                MetaVariable,
                Interface,
                meta_variable_
        >();
}

template <typename MetaMemberVariable, typename Interface>
inline shared<Interface>
get_meta_object(boost::mirror::meta_member_variable_tag)
{
        return do_get_meta_object<
                MetaMemberVariable,
                Interface,
                meta_member_variable_
        >();
}

template <typename MetaFreeVariable, typename Interface>
inline shared<Interface>
get_meta_object(boost::mirror::meta_free_variable_tag)
{
        return do_get_meta_object<
                MetaFreeVariable,
                Interface,
                meta_free_variable_
        >();
}

template <typename MetaPlainFreeVariable, typename Interface>
inline shared<Interface>
get_meta_object(boost::mirror::meta_plain_free_variable_tag)
{
        return do_get_meta_object<
                MetaPlainFreeVariable,
                Interface,
                meta_plain_free_variable_
        >();
}

template <typename MetaParameter, typename Interface>
inline shared<Interface>
get_meta_object(boost::mirror::meta_parameter_tag)
{
        return do_get_meta_object<
                MetaParameter,
                Interface,
                meta_parameter_
        >();
}

template <typename MetaConstructor, typename Interface>
inline shared<Interface>
get_meta_object(boost::mirror::meta_constructor_tag)
{
        return do_get_meta_object<
                MetaConstructor,
                Interface,
                meta_constructor_
        >();
}

template <typename MetaMemberFunction, typename Interface>
inline shared<Interface>
get_meta_object(boost::mirror::meta_member_function_tag)
{
        return do_get_meta_object<
                MetaMemberFunction,
                Interface,
                meta_member_function_
        >();
}

template <typename MetaConversionOperator, typename Interface>
inline shared<Interface>
get_meta_object(boost::mirror::meta_conversion_operator_tag)
{
        return do_get_meta_object<
                MetaConversionOperator,
                Interface,
                meta_conversion_operator_
        >();
}

template <typename MetaMetaObject, typename Interface>
inline shared<Interface> get_meta_object(boost::mirror::meta_meta_object_tag)
{
        MetaMetaObject _smmo;
        static meta_meta_object mmo(_smmo);
        return shared<Interface>(&mmo);
}

// This version of the get function calls the proper overload for MetaObject
template <typename MetaObject, typename Interface>
inline shared<Interface> get_meta_object(void)
{
        // use Mirror to categorize the compile-time meta-object
        // and call the proper overload of the get function
        // to create and wrap an instance of the proper
        // run-time meta-object
        return get_meta_object<
                MetaObject,
                Interface
        >(boost::mirror::categorize_meta_object(MetaObject()));
}

} // namespace aux
BOOST_LAGOON_NAMESPACE_END

#endif //include guard

