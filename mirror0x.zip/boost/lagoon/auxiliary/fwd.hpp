/**
 *  .file boost/lagoon/auxiliary/fwd.hpp
 *  .brief Forward declaration of auxiliary classes and functions
 *
 *  Copyright 2008-2011 Matus Chochlik. Distributed under the Boost
 *  Software License, Version 1.0. (See accompanying file
 *  LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
 */

#ifndef BOOST_LAGOON_AUXILIARY_FWD_1104091004_HPP
#define BOOST_LAGOON_AUXILIARY_FWD_1104091004_HPP

#include <boost/mirror/tag_dispatch.hpp>
#include <boost/lagoon/config.hpp>
#include <boost/lagoon/utils.hpp>

BOOST_LAGOON_NAMESPACE_BEGIN
namespace aux {

template <typename Specifier, typename Interface>
shared<Interface> get_inheritance_type_spec(void);

template <typename Specifier, typename Interface>
shared<Interface> get_access_type_spec(void);

template <typename Specifier, typename Interface>
shared<Interface> get_elaborated_type_spec(void);

template <typename Specifier, typename Interface>
shared<Interface> get_storage_class_spec(void);

template <typename Specifier, typename Interface>
shared<Interface> get_constness_spec(void);

template <typename MetaMetaObject, typename Interface>
shared<Interface> get_meta_object(boost::mirror::meta_meta_object_tag);

} // namespace aux
BOOST_LAGOON_NAMESPACE_END

#endif //include guard

