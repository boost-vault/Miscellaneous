/**
 * @file boost/lagoon/lagoon_fwd.hpp
 * @brief Forward declaration of the meta-level classes reflecting
 * base-level program constructs.
 *
 *  Copyright 2008-2010 Matus Chochlik. Distributed under the Boost
 *  Software License, Version 1.0. (See accompanying file
 *  LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
 */

#ifndef BOOST_LAGOON_LAGOON_FWD_1011291729_HPP
#define BOOST_LAGOON_LAGOON_FWD_1011291729_HPP

#include <boost/mirror/raw_ptr/raw_ptr.hpp>
#include <boost/lagoon/config.hpp>
#include <string>

BOOST_LAGOON_NAMESPACE_BEGIN

typedef boost::mirror::raw_ptr raw_ptr;
typedef boost::mirror::unique_raw_ptr unique_raw_ptr;
typedef boost::mirror::shared_raw_ptr shared_raw_ptr;
using boost::mirror::raw_cast;

// Forward declarations of the run-time meta-lavel interfaces

// MetaMetaObject
struct meta_meta_object;

// MetaObject
struct meta_object;

// MetaNamedObject
struct meta_named_object;

// MetaScopedObject
struct meta_scoped_object;

// MetaNamedScopedObject
struct meta_named_scoped_object;

// MetaScope
struct meta_scope;

// MetaNamespace
struct meta_namespace;

// MetaType
struct meta_type;

// MetaTypeTemplate
struct meta_type_template;

// MetaTemplatedType
struct meta_templated_type;

// MetaTypedef
struct meta_typedef;

// MetaClass
struct meta_class;

// MetaTemplatedClass
struct meta_templated_class;

// MetaEnum
struct meta_enum;

// MetaInheritance
struct meta_inheritance;

// MetaVariable
struct meta_variable;

// MetaFreeVariable
struct meta_free_variable;

// MetaPlainFreeVariable
struct meta_plain_free_variable;

// MetaMemberVariable
struct meta_member_variable;

// MetaParameter
struct meta_parameter;

// MetaFunction
struct meta_function;

// MetaMemberFunction
struct meta_member_function;

// MetaConversionOperator
struct meta_conversion_operator;

// MetaConstructor
struct meta_constructor;

class meta_namespace_;

template <typename MetaType>
class meta_type_;

template <typename MetaType>
class meta_typedef_;

class meta_type_template_;

template <typename MetaTemplatedType>
class meta_templated_type_;

template <typename MetaClass>
class meta_class_;

template <typename MetaTemplatedClass>
class meta_templated_class_;

template <typename MetaEnum>
class meta_enum_;

class meta_inheritance_;

class meta_variable_;

class meta_free_variable_;

class meta_plain_free_variable_;

class meta_member_variable_;

class meta_parameter_;

class meta_function_;

class meta_member_function_;

class meta_conversion_operator_;

class meta_constructor_;


BOOST_LAGOON_NAMESPACE_END

#endif //include guard

