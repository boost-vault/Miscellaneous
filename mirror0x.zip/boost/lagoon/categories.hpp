/**
 * @file boost/lagoon/categories.hpp
 * @brief Definitions of the meta-object categories
 *
 *
 *  Copyright 2008-2010 Matus Chochlik. Distributed under the Boost
 *  Software License, Version 1.0. (See accompanying file
 *  LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
 */

#ifndef BOOST_LAGOON_CATEGORIES_1011291729_HPP
#define BOOST_LAGOON_CATEGORIES_1011291729_HPP

#include <boost/lagoon/config.hpp>

BOOST_LAGOON_NAMESPACE_BEGIN
/** @defgroup lagoon_categories Lagoon - Meta-object categories
 *
 *  Lagoon defines an enumeration of tag values which can
 *  be used for the categorization of run-time meta-objects
 *  in a similar manner the tag types in Mirror are used for
 *  compile-time tag-dispatching.
 */

/// Enumeration of meta-object categorization tags
/** The meta_object and meta_meta_object interfaces
 *  define member functions for querying the category
 *  of the reflected construct or meta-object.
 *
 *  @see meta_meta_object
 *  @see meta_meta_object::category
 *  @see meta_meta_object::is_a
 *  @see meta_object
 *
 *  @ingroup lagoon_categories
 */
#ifdef BOOST_MIRROR_DOCUMENTATION_ONLY
enum meta_object_category
#else
enum class meta_object_category : unsigned long long
#endif
{
        /// Indicates that the meta-object is a meta_object
        meta_object_tag = 0x1ULL,

        /// Indicates that the meta-object is a meta_named_object
        meta_named_object_tag =
                meta_object_tag |
                0x2ULL,

        /// Indicates that the meta-object is a meta_scoped_object
        meta_scoped_object_tag =
                meta_object_tag |
                0x4ULL,

        /// Indicates that the meta-object is a meta_named_scoped_object
        meta_named_scoped_object_tag =
                meta_named_object_tag |
                meta_scoped_object_tag |
                0x8ULL,

        /// Indicates that the meta-object is a meta_scope
        meta_scope_tag =
                meta_named_scoped_object_tag |
                0x10ULL,

        /// Indicates that the meta-object is an meta_scope for the unspecified scope
        meta_unspecified_scope_tag =
                meta_scope_tag |
                0x20ULL,

        /// Indicates that the meta-object is a meta_namespace
        meta_namespace_tag =
                meta_scope_tag |
                0x40ULL,

        /// Indicates that the meta-object is a meta_namespace for global scope
        meta_global_scope_tag =
                meta_namespace_tag |
                0x80ULL,

        /// Indicates that the meta-object is a meta_type
        meta_type_tag =
                meta_named_scoped_object_tag |
                0x100ULL,

        /// Indicates that the meta-object is a meta_type_template
        meta_type_template_tag =
                meta_named_scoped_object_tag |
                0x200ULL,

        /// Indicates that the meta-object is a meta_typedef
        meta_typedef_tag =
                meta_type_tag |
                0x400ULL,

        /// Indicates that the meta-object is a meta_templated_type
        meta_templated_type_tag =
                meta_type_tag |
                0x800ULL,

        /// Indicates that the meta-object is a meta_class
        meta_class_tag =
                meta_type_tag |
                meta_scope_tag |
                0x1000ULL,

        /// Indicates that the meta-object is a meta_templated_class
        meta_templated_class_tag =
                meta_templated_type_tag |
                meta_class_tag |
                0x2000ULL,

        /// Indicates that the meta-object is a meta_enum
        meta_enum_tag =
                meta_type_tag |
                0x4000ULL,

        /// Indicates that the meta-object is a meta_enum_value
        meta_enum_value_tag =
                meta_named_scoped_object_tag |
                0x8000ULL,

        /// Indicates that the meta-object is a meta_member
        meta_class_or_enum_member_tag =
                meta_named_scoped_object_tag |
                0x10000ULL,

        /// Indicates that the meta-object is a meta_class_member
        meta_class_member_tag =
                meta_class_or_enum_member_tag |
                0x20000ULL,

        /// Indicates that the meta-object is a meta_inheritance
        meta_inheritance_tag =
                meta_object_tag |
                0x40000ULL,

        /// Indicates that the meta-object is a meta_variable
        meta_variable_tag =
                meta_named_scoped_object_tag |
                0x80000ULL,

        /// Indicates that the meta-object is a plain meta_variable
        meta_plain_variable_tag =
                meta_variable_tag |
                0x100000ULL,

        /// Indicates that the meta-object is a meta_free_variable
        meta_free_variable_tag =
                meta_variable_tag |
                0x200000ULL,

        /// Indicates that the meta-object is a meta_plain_free_variable
        meta_plain_free_variable_tag =
                meta_free_variable_tag |
                meta_plain_variable_tag,

        /// Indicates that the meta-object is a meta_member_variable
        meta_member_variable_tag =
                meta_variable_tag |
                meta_class_member_tag |
                0x400000ULL,

        /// Indicates that the meta-object is a meta_plain_member_variable
        meta_plain_member_variable_tag =
                meta_member_variable_tag |
                meta_plain_variable_tag,

        /// Indicates that the meta-object is a meta_parameter
        meta_parameter_tag =
                meta_variable_tag |
                0x800000ULL,

        /// Indicates that the meta-object is a meta_function
        meta_function_tag =
                meta_named_scoped_object_tag |
                0x1000000ULL,

        /// Indicates that the meta-object is a meta_member_function
        meta_member_function_tag =
                meta_function_tag |
                meta_class_member_tag |
                0x2000000ULL,

        /// Indicates that the meta-object is a meta_member_function
        meta_constructor_tag =
                meta_function_tag |
                meta_class_member_tag |
                0x4000000ULL,

        /// Indicates that the meta-object is a meta_conversion_operator
        meta_conversion_operator_tag =
                meta_member_function_tag |
                0x8000000ULL,

        /// Indicates that the meta-object is a meta_traversal
        meta_traversal_tag =
                meta_named_object_tag |
                0x10000000ULL,

        /// Indicates that the meta-object is a meta_locator
        meta_locator_tag =
                meta_named_object_tag |
                0x20000000ULL,

        /// Indicates that the meta-object is a meta_inserter
        meta_inserter_tag =
                meta_named_object_tag |
                0x40000000ULL,

        /// Indicates that the meta-object is a meta_eraser
        meta_eraser_tag =
                meta_named_object_tag |
                0x80000000ULL,

        /// Indicates that the meta-object is a meta_container
        meta_container_tag =
                meta_scoped_object_tag |
                0x100000000ULL
};

BOOST_LAGOON_NAMESPACE_END

#endif //include guard

