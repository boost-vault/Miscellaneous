/**
 * @file boost/lagoon/interfaces.hpp
 * @brief Definitions of the run-time interfaces of meta-objects
 *
 *
 *  Copyright 2008-2011 Matus Chochlik. Distributed under the Boost
 *  Software License, Version 1.0. (See accompanying file
 *  LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
 */

#ifndef BOOST_LAGOON_INTERFACES_1011291729_HPP
#define BOOST_LAGOON_INTERFACES_1011291729_HPP

#include <boost/lagoon/lagoon_fwd.hpp>
#include <boost/lagoon/categories.hpp>
#include <boost/lagoon/specifiers.hpp>
#include <boost/lagoon/utils.hpp>
#include <boost/mirror/type_traits.hpp>
#include <boost/mirror/tag_dispatch.hpp>
#include <string>
#include <memory>

#if BOOST_LAGOON_MT_WITH_MAKE_FACTORY
#include <boost/lagoon/polymorph_factory.hpp>
#endif

BOOST_LAGOON_NAMESPACE_BEGIN

/** @defgroup lagoon_interfaces Lagoon - Interfaces
 *
 *  Lagoon defines several polymorphic abstract interfaces,
 *  through which the meta-data are accessed. There interfaces
 *  are run-time equivalents of Mirror's concepts.
 */


/// The interface for reflecting Lagoon's meta-objects
/** This interface can be used to get meta-data about
 *  a Lagoon's meta-object.
 *
 *  @see meta_object_category
 *  @see boost::mirror::MetaMetaObject
 *
 *  @ingroup lagoon_interfaces
 */
struct meta_meta_object
{
private:
        const std::string _base_name;
        meta_object_category _category;

        static inline bool category_matches(unsigned a, unsigned b)
        {
                return (a & b) == b;
        }
protected:
#define BOOST_LAGOON_HELPER_MAKE_MMO_GET_CATEGORY_FN(OBJECT, X) \
        static meta_object_category get_category(boost::mirror::meta_ ## OBJECT ## _tag) \
        { \
                return meta_object_category::meta_ ## OBJECT ## _tag; \
        }

BOOST_MIRROR_FOR_EACH_META_OBJECT(BOOST_LAGOON_HELPER_MAKE_MMO_GET_CATEGORY_FN, _)
#undef BOOST_LAGOON_HELPER_MAKE_MMO_GET_CATEGORY_FN

        template <typename MetaMetaObject, typename Interface>
        friend shared<Interface> aux::get_meta_object(boost::mirror::meta_meta_object_tag);

        template <typename MetaMetaObject>
        inline meta_meta_object(MetaMetaObject)
         : _base_name(MetaMetaObject::base_name())
         , _category(get_category(typename MetaMetaObject::category()))
        { }
public:

        /// Returns the base name of the reflected meta_object
        /** This member function returns the base name
         *  i.e. the name without the nested name specifier
         *  of the construct reflected by this meta-object.
         */
        std::string base_name(void) const
        {
                return _base_name;
        }

        /** @name Reflected meta-object categorization functions
         *  These functions allow to determine the category of the meta_object
         *  reflected by this meta_meta_object.
         */
        //@{

        /// Returns the category of the reflected meta_object
        meta_object_category category(void) const
        {
                return _category;
        }

        /// Returns true if the reflected meta-object is of the cat category
        inline bool is_a(meta_object_category cat) const
        {
                return category_matches(
                        unsigned(category()),
                        unsigned(cat)
                );
        }

#define BOOST_LAGOON_HELPER_MAKE_MMO_IS_META_OBJECT(OBJECT, X) \
        inline bool is_meta_## OBJECT(void) const \
        { \
                return is_a(meta_object_category::meta_ ## OBJECT ## _tag); \
        }
BOOST_MIRROR_FOR_EACH_META_OBJECT(BOOST_LAGOON_HELPER_MAKE_MMO_IS_META_OBJECT, _)
#undef BOOST_LAGOON_HELPER_MAKE_MMO_IS_META_OBJECT
        //@}
};


/// The base interface for all Lagoon's meta-objects
/** This interface serves as a common ancestor for all
 *  other run-time meta-object interfaces.
 *
 *  @see meta_meta_object
 *  @see meta_object_category
 *  @see boost::mirror::MetaObject
 *
 *  @ingroup lagoon_interfaces
 */
struct meta_object
{
        // virtual destructor assuring proper cleanup
        virtual ~meta_object(void) { }

        /// returns meta-data about this meta-object
        virtual shared<meta_meta_object> self(void) const = 0;

#if BOOST_MIRROR_NO_RTTI
        virtual void* cast_to(meta_object_category cat)
        {
                if(cat == meta_object_category::meta_object_tag)
                        return (meta_object*) this;
                return nullptr;
        }
#endif

        /** @name Reflected construct categorization functions
         *  These functions allow to determine the category of the
         *  base level construct reflected by the meta_object
         */
        //@{

        /// Always returns true
#define BOOST_LAGOON_HELPER_MO_IS_OBJECT(OBJECT, X) \
        inline bool is_## OBJECT(void) const \
        { \
                return self()->is_meta_ ## OBJECT(); \
        }
BOOST_MIRROR_FOR_EACH_META_OBJECT(BOOST_LAGOON_HELPER_MO_IS_OBJECT, _)
#undef BOOST_LAGOON_HELPER_MO_IS_OBJECT

        //@}
};

inline meta_object_category categorize_interface(meta_object*)
{
        return meta_object_category::meta_object_tag;
}

/// Interface for reflecting named constructs
/** This interface provides meta-data about base-level
 *  constructs having a name.
 *
 *  @see boost::mirror::MetaNamedObject
 *
 *  @ingroup lagoon_interfaces
 */
struct meta_named_object
 : virtual meta_object
{
#if BOOST_MIRROR_NO_RTTI
        virtual void* cast_to(meta_object_category cat)
        {
                if(cat == meta_object_category::meta_named_object_tag)
                        return (meta_named_object*) this;
                return meta_object::cast_to(cat);
        }
#endif

        /// Returns the base name of the reflected construct
        /** This member function returns the base name
         *  i.e. the name without the nested name specifier
         *  of the construct reflected by this meta-object.
         */
        virtual std::string base_name(void) = 0;
};

inline meta_object_category categorize_interface(meta_named_object*)
{
        return meta_object_category::meta_named_object_tag;
}

/// Interface for reflecting objects defined inside of a scope
/** This interface provides meta-data about base-level constructs
 *  which are defined inside of a scope like namespace or class.
 *
 *  @see boost::mirror::MetaScopedObject
 *
 *  @ingroup lagoon_interfaces
 */
struct meta_scoped_object
 : virtual meta_object
{
#if BOOST_MIRROR_NO_RTTI
        virtual void* cast_to(meta_object_category cat)
        {
                if(cat == meta_object_category::meta_scoped_object_tag)
                        return (meta_scoped_object*) this;
                return meta_object::cast_to(cat);
        }
#endif

        /// Returns a meta-object reflecting a scope of this object
        virtual shared<meta_scope> scope(void) = 0;
};

inline meta_object_category categorize_interface(meta_scoped_object*)
{
        return meta_object_category::meta_scoped_object_tag;
}

/// Interface for reflecting named objects defined inside of a scope
/** This interface provides meta-data about named base-level constructs
 *  which are defined inside of a scope like a namespace or a class.
 *
 *  @see boost::mirror::MetaNamedScopedObject
 *
 *  @ingroup lagoon_interfaces
 */
struct meta_named_scoped_object
 : virtual meta_named_object
 , virtual meta_scoped_object
{
#if BOOST_MIRROR_NO_RTTI
        virtual void* cast_to(meta_object_category cat)
        {
                if(cat == meta_object_category::meta_named_scoped_object_tag)
                        return (meta_named_scoped_object*) this;
                void* result = meta_named_object::cast_to(cat);
                if(result != nullptr) return result;
                return meta_scoped_object::cast_to(cat);
        }
#endif

        /// Returns the full name of the reflected construct
        virtual std::string full_name(void) = 0;


#if BOOST_LAGOON_MNSO_WITH_LOCAL_NAME || \
    BOOST_MIRROR_DOCUMENTATION_ONLY
        /// Returns the local name of the reflected construct
        /**
         *  Available only if the #BOOST_LAGOON_MNSO_WITH_LOCAL_NAME preprocessor
         *  symbol is set to a nonzero integer value.
         *
         *  @see base_name
         *  @see full_name
         */
        virtual std::string local_name(void) = 0;
#endif
};

inline meta_object_category categorize_interface(meta_named_scoped_object*)
{
        return meta_object_category::meta_named_scoped_object_tag;
}

/// Interface for reflecting objects which can enclose other constructs
/** This interface provides meta-data about named constructs like
 *  namespaces, classes, etc. which can contain other constructs.
 *
 *  @see boost::mirror::MetaScope
 *
 *  @ingroup lagoon_interfaces
 */
struct meta_scope
 : virtual meta_named_scoped_object
{
#if BOOST_MIRROR_NO_RTTI
        virtual void* cast_to(meta_object_category cat)
        {
                if(cat == meta_object_category::meta_scope_tag)
                        return (meta_scope*) this;
                return meta_named_scoped_object::cast_to(cat);
        }
#endif

        /// This member function returns the members of the scope
        virtual range<meta_named_scoped_object> members(void) = 0;

        /// Convenience member function for finding a member by base_name
        /**
         *  @tparam Interface the required interface of the member
         *  @param name the base name to search the member by
         */
        template <typename Interface>
        shared<Interface> find_member(const std::string& name)
        {
                auto r(this->members());
                while(!r.empty())
                {
                        if(r.front()->base_name() == name)
                                return r.front().as<Interface>();
                        r.step_front();
                }
                return shared<Interface>();
        }
};

inline meta_object_category categorize_interface(meta_scope*)
{
        return meta_object_category::meta_scope_tag;
}

/// Interface for reflecting namespaces
/** This interface provides meta-data about a namespace
 *
 *  @see boost::mirror::MetaNamespace
 *
 *  @ingroup lagoon_interfaces
 */
struct meta_namespace
 : virtual meta_scope
{
#if BOOST_MIRROR_NO_RTTI
        virtual void* cast_to(meta_object_category cat)
        {
                if(cat == meta_object_category::meta_namespace_tag)
                        return (meta_namespace*) this;
                return meta_scope::cast_to(cat);
        }
#endif
        /// Returns the free variables of this namespace
        virtual range<meta_free_variable> free_variables(void) = 0;

        /// Convenience function returning a meta_variable by name
        inline shared<meta_free_variable> variable_(const std::string& name)
        {
                return find_member<meta_free_variable>(name);
        }

        /// Convenience function returning a meta_namespace by name
        inline shared<meta_namespace> namespace_(const std::string& name)
        {
                return find_member<meta_namespace>(name);
        }

        /// Convenience function returning a meta_type by name
        inline shared<meta_type> type_(const std::string& name)
        {
                return find_member<meta_type>(name);
        }

        /// Convenience function returning a meta_class by name
        inline shared<meta_class> class_(const std::string& name)
        {
                return type_(name).as<meta_class>();
        }

        /// Convenience function returning a meta_typedef by name
        inline shared<meta_typedef> typedef_(const std::string& name)
        {
                return find_member<meta_typedef>(name);
        }

        /// Convenience function returning a meta_type_template by name
        inline shared<meta_type_template> template_(const std::string& name)
        {
                return find_member<meta_type_template>(name);
        }
};

inline meta_object_category categorize_interface(meta_namespace*)
{
        return meta_object_category::meta_namespace_tag;
}

/// Interface for reflecting types
/** This interface provides meta-data about a type
 *
 *  @see boost::mirror::MetaType
 *
 *  @ingroup lagoon_interfaces
 */
struct meta_type
 : virtual meta_named_scoped_object
{
#if BOOST_MIRROR_NO_RTTI
        virtual void* cast_to(meta_object_category cat)
        {
                if(cat == meta_object_category::meta_type_tag)
                        return (meta_type*) this;
                return meta_named_scoped_object::cast_to(cat);
        }
#endif

        /// Returns meta-constructors reflecting type's constructors
        virtual range<meta_constructor> constructors(void) = 0;

#if BOOST_LAGOON_ALL_TYPE_TRAITS || \
    BOOST_LAGOON_MT_WITH_IS_DEFAULT_CONSTRUCTIBLE || \
    BOOST_MIRROR_DOCUMENTATION_ONLY
        /// Returns true if the type is default constructible
        /**
         *  Available only if either the
         *  #BOOST_LAGOON_MT_WITH_IS_DEFAULT_CONSTRUCTIBLE
         *  or the #BOOST_LAGOON_ALL_TYPE_TRAITS
         *  preprocessor symbol is set to a nonzero integer value.
         */
        virtual bool is_default_constructible(void) = 0;
#endif

#if BOOST_LAGOON_ALL_TYPE_TRAITS || \
    BOOST_LAGOON_MT_WITH_IS_COPY_CONSTRUCTIBLE || \
    BOOST_MIRROR_DOCUMENTATION_ONLY
        /// Returns true if the type is copy constructible
        /**
         *  Available only if either the
         *  #BOOST_LAGOON_MT_WITH_IS_COPY_CONSTRUCTIBLE
         *  or the #BOOST_LAGOON_ALL_TYPE_TRAITS
         *  preprocessor symbol is set to a nonzero integer value.
         */
        virtual bool is_copy_constructible(void) = 0;
#endif

#if BOOST_LAGOON_MT_WITH_NEW || \
    BOOST_MIRROR_DOCUMENTATION_ONLY
        /// Allocates and constructs a new instance of the reflected type
        /** This member function returns a pointer to a newly allocated
         *  and default-constructed instance of the type reflected by
         *  this meta-type if the base-level type has a default constructor.
         *  If the reflected type does not have a default constructor, this
         *  function returns a null pointer.
         *
         *  Available only if the #BOOST_LAGOON_MT_WITH_NEW preprocessor
         *  symbol is set to a nonzero integer value.
         *
         *  @see boost::mirror::is_default_constructible
         *  @see new_copy
         *  @see delete_
         *  @see make_factory
         */
        virtual raw_ptr new_(void) = 0;
#endif

#if BOOST_LAGOON_MT_WITH_NEW_COPY || \
    BOOST_MIRROR_DOCUMENTATION_ONLY
        /// Allocates and copy-constructs a new instance of the reflected type
        /** This member function returns a pointer to a newly allocated
         *  and copy-constructed instance of the type reflected by
         *  this meta-type if the base-level type has a copy constructor and
         *  a valid pointer to an instance to copy from is provided.
         *  If the reflected type does not have a default constructor, this
         *  function returns a null pointer.
         *
         *  Available only if the #BOOST_LAGOON_MT_WITH_NEW_COPY preprocessor
         *  symbol is set to a nonzero integer value.
         *
         *  @param source a valid pointer to an instance to copy from. If
         *  a null pointer is provided or the type does not match
         *  the constructed type the result is undefined. Most probably
         *  this will cause the application to be aborted in debug builds.
         *
         *  @see boost::mirror::is_copy_constructible
         *  @see new_copy
         *  @see delete_
         *  @see make_factory
         */
        virtual raw_ptr new_copy(raw_ptr source) = 0;
#endif

#if BOOST_LAGOON_MT_WITH_DEFAULT || \
    BOOST_MIRROR_DOCUMENTATION_ONLY
        /// Creates a default instance of the type reflected by this meta type
        /** This member function returns a default-constructed instance
         *  of the type reflected by this meta-type if the base-level type
         *  has a default constructor.
         *  If the reflected type does not have a default constructor, this
         *  function returns an empty boost::any.
         *
         *  Available only if the #BOOST_LAGOON_MT_WITH_DEFAULT
         *  preprocessor symbol is set to a nonzero integer value.
         */
        virtual boost::any default_(void) = 0;
#endif

#if BOOST_LAGOON_MT_WITH_DELETE || \
    BOOST_MIRROR_DOCUMENTATION_ONLY
        /// Deletes an object constructed by new_, new_copy or by a factory
        /**
         *  Available only if the #BOOST_LAGOON_MT_WITH_DELETE preprocessor
         *  symbol is set to a nonzero integer value.
         *
         *  @see new_
         *  @see new_copy
         *  @see make_factory
         *  @see make_shared
         *  @see make_unique
         */
        virtual void delete_(raw_ptr ptr) = 0;
#endif

#if BOOST_LAGOON_MT_WITH_MAKE_SHARED || \
    BOOST_MIRROR_DOCUMENTATION_ONLY
        /// Make a shared raw pointer from an unmanaged raw pointer
        /**
         *  Available only if the #BOOST_LAGOON_MT_WITH_MAKE_SHARED
         *  preprocessor symbol is set to a nonzero integer value.
         *
         *  @see new_
         *  @see new_copy
         *  @see make_factory
         *  @see make_unique
         */
        virtual shared_raw_ptr make_shared(raw_ptr source) = 0;
#endif

#if BOOST_LAGOON_MT_WITH_MAKE_UNIQUE || \
    BOOST_MIRROR_DOCUMENTATION_ONLY
        /// Make a shared raw pointer from an unmanaged raw pointer
        /**
         *  Available only if the #BOOST_LAGOON_MT_WITH_MAKE_UNIQUE
         *  preprocessor symbol is set to a nonzero integer value.
         *
         *  @see new_
         *  @see new_copy
         *  @see make_factory
         *  @see make_shared
         */
        virtual unique_raw_ptr make_unique(raw_ptr source) = 0;
#endif

#if BOOST_LAGOON_MT_WITH_MAKE_FACTORY || \
    BOOST_MIRROR_DOCUMENTATION_ONLY
        /// Make a polymorphic factory, built by the passed factory builder
        /**
         *  Available only if the #BOOST_LAGOON_MT_WITH_MAKE_FACTORY
         *  preprocessor symbol is set to a nonzero integer value.
         *  @see new_
         *  @see new_copy
         *  @see make_shared
         *  @see make_unique
         */
        virtual std::unique_ptr<polymorph_factory> make_factory(
                polymorph_factory_builder& builder,
                raw_ptr build_data
        ) = 0;
#endif

        /** @name Reflected type-trait functions
         *  These functions allow to inspect individual type traits
         *  of the type reflected by this meta_type.
         */
        //@{

        /// Returns the size of this type
        virtual std::size_t size_of(void) = 0;

#if BOOST_LAGOON_ALL_TYPE_TRAITS || \
    BOOST_LAGOON_MT_WITH_ALIGNMENT_OF || \
    BOOST_MIRROR_DOCUMENTATION_ONLY
        /// Returns the alignment of this type
        /**
         *  Available only if either the #BOOST_LAGOON_MT_WITH_ALIGNMENT_OF
         *  or the #BOOST_LAGOON_ALL_TYPE_TRAITS
         *  preprocessor symbol is set to a nonzero integer value.
         */
        virtual std::size_t alignment_of(void) = 0;
#endif

#if BOOST_LAGOON_ALL_TYPE_TRAITS || \
    BOOST_LAGOON_MT_WITH_IS_ARRAY || \
    BOOST_MIRROR_DOCUMENTATION_ONLY
        /// Returns true if the reflected type is an array type
        /**
         *  Available only if either the #BOOST_LAGOON_MT_WITH_IS_ARRAY
         *  or the #BOOST_LAGOON_ALL_TYPE_TRAITS
         *  preprocessor symbol is set to a nonzero integer value.
         */
        virtual bool is_array(void) = 0;
#endif

#if BOOST_LAGOON_ALL_TYPE_TRAITS || \
    BOOST_LAGOON_MT_WITH_IS_CONST || \
    BOOST_MIRROR_DOCUMENTATION_ONLY
        /// Returns true if the reflected type is const
        /**
         *  Available only if either the #BOOST_LAGOON_MT_WITH_IS_CONST
         *  or the #BOOST_LAGOON_ALL_TYPE_TRAITS
         *  preprocessor symbol is set to a nonzero integer value.
         */
        virtual bool is_const(void) = 0;
#endif

#if BOOST_LAGOON_ALL_TYPE_TRAITS || \
    BOOST_LAGOON_MT_WITH_IS_POINTER || \
    BOOST_MIRROR_DOCUMENTATION_ONLY
        /// Returns true if the reflected type is a pointer
        /**
         *  Available only if either the #BOOST_LAGOON_MT_WITH_IS_POINTER
         *  or the #BOOST_LAGOON_ALL_TYPE_TRAITS
         *  preprocessor symbol is set to a nonzero integer value.
         */
        virtual bool is_pointer(void) = 0;
#endif

#if BOOST_LAGOON_ALL_TYPE_TRAITS || \
    BOOST_LAGOON_MT_WITH_IS_REFERENCE || \
    BOOST_MIRROR_DOCUMENTATION_ONLY
        /// Returns true if the reflected type is a reference
        /**
         *  Available only if either the #BOOST_LAGOON_MT_WITH_IS_REFERENCE
         *  or the #BOOST_LAGOON_ALL_TYPE_TRAITS
         *  preprocessor symbol is set to a nonzero integer value.
         */
        virtual bool is_reference(void) = 0;
#endif

#if BOOST_LAGOON_ALL_TYPE_TRAITS || \
    BOOST_LAGOON_MT_WITH_IS_VOLATILE || \
    BOOST_MIRROR_DOCUMENTATION_ONLY
        /// Returns true if the reflected type is volatile
        /**
         *  Available only if either the #BOOST_LAGOON_MT_WITH_IS_VOLATILE
         *  or the #BOOST_LAGOON_ALL_TYPE_TRAITS
         *  preprocessor symbol is set to a nonzero integer value.
         */
        virtual bool is_volatile(void) = 0;
#endif

#if BOOST_LAGOON_ALL_TYPE_TRAITS || \
    BOOST_LAGOON_MT_WITH_ADD_CONST || \
    BOOST_MIRROR_DOCUMENTATION_ONLY
        /// Returns a meta_type with added const qualifier
        /**
         *  Available only if either the #BOOST_LAGOON_MT_WITH_ADD_CONST
         *  or the #BOOST_LAGOON_ALL_TYPE_TRAITS
         *  preprocessor symbol is set to a nonzero integer value.
         */
        virtual shared<meta_type> add_const(void) = 0;
#endif

#if BOOST_LAGOON_ALL_TYPE_TRAITS || \
    BOOST_LAGOON_MT_WITH_ADD_CV || \
    BOOST_MIRROR_DOCUMENTATION_ONLY
        /// Returns a meta_type with added const and volatile qualifiers
        /**
         *  Available only if either the #BOOST_LAGOON_MT_WITH_ADD_CV
         *  or the #BOOST_LAGOON_ALL_TYPE_TRAITS
         *  preprocessor symbol is set to a nonzero integer value.
         */
        virtual shared<meta_type> add_cv(void) = 0;
#endif

#if BOOST_LAGOON_ALL_TYPE_TRAITS || \
    BOOST_LAGOON_MT_WITH_ADD_VOLATILE || \
    BOOST_MIRROR_DOCUMENTATION_ONLY
        /// Returns a meta_type with added volatile qualifier
        /**
         *  Available only if either the #BOOST_LAGOON_MT_WITH_ADD_VOLATILE
         *  or the #BOOST_LAGOON_ALL_TYPE_TRAITS
         *  preprocessor symbol is set to a nonzero integer value.
         */
        virtual shared<meta_type> add_volatile(void) = 0;
#endif

#if BOOST_LAGOON_ALL_TYPE_TRAITS || \
    BOOST_LAGOON_MT_WITH_REMOVE_CONST || \
    BOOST_MIRROR_DOCUMENTATION_ONLY
        /// Returns a meta_type without the const qualifier
        /**
         *  Available only if either the #BOOST_LAGOON_MT_WITH_REMOVE_CONST
         *  or the #BOOST_LAGOON_ALL_TYPE_TRAITS
         *  preprocessor symbol is set to a nonzero integer value.
         */
        virtual shared<meta_type> remove_const(void) = 0;
#endif

#if BOOST_LAGOON_ALL_TYPE_TRAITS || \
    BOOST_LAGOON_MT_WITH_REMOVE_CV || \
    BOOST_MIRROR_DOCUMENTATION_ONLY
        /// Returns a meta_type without the const and volatile qualifiers
        /**
         *  Available only if either the #BOOST_LAGOON_MT_WITH_REMOVE_CV
         *  or the #BOOST_LAGOON_ALL_TYPE_TRAITS
         *  preprocessor symbol is set to a nonzero integer value.
         */
        virtual shared<meta_type> remove_cv(void) = 0;
#endif

#if BOOST_LAGOON_ALL_TYPE_TRAITS || \
    BOOST_LAGOON_MT_WITH_REMOVE_POINTER || \
    BOOST_MIRROR_DOCUMENTATION_ONLY
        /// Returns a meta_type with one level of pointer indirection removed
        /**
         *  Available only if either the #BOOST_LAGOON_MT_WITH_REMOVE_POINTER
         *  or the #BOOST_LAGOON_ALL_TYPE_TRAITS
         *  preprocessor symbol is set to a nonzero integer value.
         */
        virtual shared<meta_type> remove_pointer(void) = 0;
#endif

#if BOOST_LAGOON_ALL_TYPE_TRAITS || \
    BOOST_LAGOON_MT_WITH_REMOVE_REFERENCE || \
    BOOST_MIRROR_DOCUMENTATION_ONLY
        /// Returns a meta_type with one level of reference indirection removed
        /**
         *  Available only if either the #BOOST_LAGOON_MT_WITH_REMOVE_REFERENCE
         *  or the #BOOST_LAGOON_ALL_TYPE_TRAITS
         *  preprocessor symbol is set to a nonzero integer value.
         */
        virtual shared<meta_type> remove_reference(void) = 0;
#endif

#if BOOST_LAGOON_ALL_TYPE_TRAITS || \
    BOOST_LAGOON_MT_WITH_REMOVE_VOLATILE || \
    BOOST_MIRROR_DOCUMENTATION_ONLY
        /// Returns a meta_type without the volatile qualifier
        /**
         *  Available only if either the #BOOST_LAGOON_MT_WITH_REMOVE_VOLATILE
         *  or the #BOOST_LAGOON_ALL_TYPE_TRAITS
         *  preprocessor symbol is set to a nonzero integer value.
         */
        virtual shared<meta_type> remove_volatile(void) = 0;
#endif

#if BOOST_LAGOON_ALL_TYPE_TRAITS || \
    BOOST_LAGOON_MT_WITH_REMOVE_EXTENT || \
    BOOST_MIRROR_DOCUMENTATION_ONLY
        /// Returns a meta_type with an array extent removed
        /**
         *  Available only if either the #BOOST_LAGOON_MT_WITH_REMOVE_EXTENT
         *  or the #BOOST_LAGOON_ALL_TYPE_TRAITS
         *  preprocessor symbol is set to a nonzero integer value.
         */
        virtual shared<meta_type> remove_extent(void) = 0;
#endif
        //@}
};

inline meta_object_category categorize_interface(meta_type*)
{
        return meta_object_category::meta_type_tag;
}

/// Interface for reflecting type templates
/** This interface provides meta-data about a type template
 *
 *  @see boost::mirror::MetaTypeTemplate
 *
 *  @ingroup lagoon_interfaces
 */
struct meta_type_template
 : virtual meta_named_scoped_object
{
#if BOOST_MIRROR_NO_RTTI
        virtual void* cast_to(meta_object_category cat)
        {
                if(cat == meta_object_category::meta_type_template_tag)
                        return (meta_type_template*) this;
                return meta_named_scoped_object::cast_to(cat);
        }
#endif

};

inline meta_object_category categorize_interface(meta_type_template*)
{
        return meta_object_category::meta_type_template_tag;
}


/// Interface for reflecting typedefined type
/** This interface provides meta-data about a typedef
 *
 *  @see boost::mirror::MetaTypedef
 *
 *  @ingroup lagoon_interfaces
 */
struct meta_typedef
 : virtual meta_type
{
#if BOOST_MIRROR_NO_RTTI
        virtual void* cast_to(meta_object_category cat)
        {
                if(cat == meta_object_category::meta_typedef_tag)
                        return (meta_typedef*) this;
                return meta_type::cast_to(cat);
        }
#endif

        /// Returns a meta_type reflecting this typedef's base type
        virtual shared<meta_type> type(void) = 0;
};

inline meta_object_category categorize_interface(meta_typedef*)
{
        return meta_object_category::meta_typedef_tag;
}

/// Interface for reflecting template instantiation
/** This interface provides meta-data about a templated type
 *
 *  @see boost::mirror::MetaTemplatedType
 *
 *  @ingroup lagoon_interfaces
 */
struct meta_templated_type
 : virtual meta_type
{
#if BOOST_MIRROR_NO_RTTI
        virtual void* cast_to(meta_object_category cat)
        {
                if(cat == meta_object_category::meta_templated_type_tag)
                        return (meta_templated_type*) this;
                return meta_type::cast_to(cat);
        }
#endif

        /// Returns a meta_type_template reflecting this type's template
        virtual shared<meta_type_template> type_template(void) = 0;

        /// Returns a range of meta_type(s) reflecting template parameters
        virtual range<meta_type> template_parameters(void) = 0;
};

inline meta_object_category categorize_interface(meta_templated_type*)
{
        return meta_object_category::meta_templated_type_tag;
}

/// Interface for reflecting base class inheritances
/** This interface provides meta-data about the inheritance of a base-class
 *  of another class.
 *
 *  @see boost::mirror::MetaInheritance
 *
 *  @ingroup lagoon_interfaces
 */
struct meta_inheritance
 : virtual meta_object
{
#if BOOST_MIRROR_NO_RTTI
        virtual void* cast_to(meta_object_category cat)
        {
                if(cat == meta_object_category::meta_inheritance_tag)
                        return (meta_inheritance*) this;
                return meta_object::cast_to(cat);
        }
#endif

        /// returns the inheritance type specifier
        virtual shared<inheritance_type_specifier> inheritance_type(void) = 0;

        /// returns the member access type specifier
        virtual shared<access_type_specifier> access_type(void) = 0;

        /// Returns a meta_class reflecting the base class in the inhertiance
        virtual shared<meta_class> base_class(void) = 0;

        /// Returns a meta_class reflecting the derived class in the inhertiance
        virtual shared<meta_class> derived_class(void) = 0;
};

inline meta_object_category categorize_interface(meta_inheritance*)
{
        return meta_object_category::meta_inheritance_tag;
}

/// Interface for reflecting class members
/** This interface provides meta-data about a class member
 *
 *  @see boost::mirror::MetaClassMember
 *
 *  @ingroup lagoon_interfaces
 */
struct meta_class_member
 : virtual meta_named_scoped_object
{
#if BOOST_MIRROR_NO_RTTI
        virtual void* cast_to(meta_object_category cat)
        {
                if(cat == meta_object_category::meta_class_member_tag)
                        return (meta_class_member*) this;
                return meta_named_scoped_object::cast_to(cat);
        }
#endif

        /// Returns the position of the parameter
        virtual int position(void) = 0;

        /// Returns the access type specifier of the class member
        virtual shared<access_type_specifier> access_type(void) = 0;
};

inline meta_object_category categorize_interface(meta_class_member*)
{
        return meta_object_category::meta_class_member_tag;
}

/// Interface for reflecting variables
/** This interface provides meta-data about a variable
 *
 *  @see boost::mirror::MetaVariable
 *
 *  @ingroup lagoon_interfaces
 */
struct meta_variable
 : virtual meta_named_scoped_object
{
#if BOOST_MIRROR_NO_RTTI
        virtual void* cast_to(meta_object_category cat)
        {
                if(cat == meta_object_category::meta_variable_tag)
                        return (meta_variable*) this;
                return meta_named_scoped_object::cast_to(cat);
        }
#endif

        /// returns the storage class specifier
        virtual shared<storage_class_specifier> storage_class(void) = 0;

        /// Returns a meta_type reflecting the type of the variable
        virtual shared<meta_type> type(void) = 0;
};

inline meta_object_category categorize_interface(meta_variable*)
{
        return meta_object_category::meta_variable_tag;
}

/// Interface for reflecting namespace's free variables
/** This interface provides meta-data about a free variable
 *
 *  @see boost::mirror::MetaFreeVariable
 *
 *  @ingroup lagoon_interfaces
 */
struct meta_free_variable
 : virtual meta_variable
{
#if BOOST_MIRROR_NO_RTTI
        virtual void* cast_to(meta_object_category cat)
        {
                if(cat == meta_object_category::meta_free_variable_tag)
                        return (meta_free_variable*) this;
                return  meta_variable::cast_to(cat);
        }
#endif
        // TODO: get/set
};

inline meta_object_category categorize_interface(meta_free_variable*)
{
        return meta_object_category::meta_free_variable_tag;
}

/// Interface for reflecting namespace's plain free variables
/** This interface provides meta-data about a free variable
 *
 *  @see boost::mirror::MetaPlainFreeVariable
 *
 *  @ingroup lagoon_interfaces
 */
struct meta_plain_free_variable
 : virtual meta_free_variable
{
#if BOOST_MIRROR_NO_RTTI
        virtual void* cast_to(meta_object_category cat)
        {
                if(cat == meta_object_category::meta_plain_free_variable_tag)
                        return (meta_plain_free_variable*) this;
                return  meta_free_variable::cast_to(cat);
        }
#endif
        // TODO: ref/address
};

inline meta_object_category categorize_interface(meta_plain_free_variable*)
{
        return meta_object_category::meta_plain_free_variable_tag;
}

/// Interface for reflecting class member variables
/** This interface provides meta-data about a class member variable (attribute)
 *
 *  @see boost::mirror::MetaMemberVariable
 *
 *  @ingroup lagoon_interfaces
 */
struct meta_member_variable
 : virtual meta_variable
 , virtual meta_class_member
{
#if BOOST_MIRROR_NO_RTTI
        virtual void* cast_to(meta_object_category cat)
        {
                if(cat == meta_object_category::meta_member_variable_tag)
                        return (meta_member_variable*) this;
                void* result = meta_variable::cast_to(cat);
                if(result != nullptr) return result;
                return meta_class_member::cast_to(cat);
        }
#endif
};

inline meta_object_category categorize_interface(meta_member_variable*)
{
        return meta_object_category::meta_member_variable_tag;
}

/// Interface for reflecting function parameters
/** This interface provides meta-data about a function or constructor parameter
 *
 *  @see boost::mirror::MetaParameter
 *
 *  @ingroup lagoon_interfaces
 */
struct meta_parameter
 : virtual meta_variable
{
#if BOOST_MIRROR_NO_RTTI
        virtual void* cast_to(meta_object_category cat)
        {
                if(cat == meta_object_category::meta_parameter_tag)
                        return (meta_parameter*) this;
                return meta_variable::cast_to(cat);
        }
#endif

        /// Returns the position of the parameter
        virtual int position(void) = 0;
};

inline meta_object_category categorize_interface(meta_parameter*)
{
        return meta_object_category::meta_parameter_tag;
}

/// Interface for reflecting classes
/** This interface provides meta-data about a class
 *
 *  @see boost::mirror::MetaClass
 *
 *  @ingroup lagoon_interfaces
 */
struct meta_class
 : virtual meta_type
 , virtual meta_scope
{
#if BOOST_MIRROR_NO_RTTI
        virtual void* cast_to(meta_object_category cat)
        {
                if(cat == meta_object_category::meta_class_tag)
                        return (meta_class*) this;
                void* result = meta_type::cast_to(cat);
                if(result != nullptr) return result;
                return meta_scope::cast_to(cat);
        }
#endif

        /// returns the elaborated type specifier
        virtual shared<elaborated_type_specifier> elaborated_type(void) = 0;

        /// This member function returns the base clases of this class
        virtual range<meta_inheritance> base_classes(void) = 0;

        /// This member function returns the layout of this class
        virtual range<meta_class> class_layout(void) = 0;

        /// This function returns the member variables of this class
        virtual range<meta_member_variable> member_variables(void) = 0;


#if BOOST_LAGOON_MC_WITH_ALL_MEMBER_VARIABLES || \
    BOOST_MIRROR_DOCUMENTATION_ONLY
        /// This function returns all member variables of this class
        /**
         *  Available only if the #BOOST_LAGOON_MC_WITH_ALL_MEMBER_VARIABLES
         *  preprocessor symbol is set to a nonzero integer value.
         *
         *  @see member_variables
         */
        virtual range<meta_member_variable> all_member_variables(void) = 0;
#endif

        /// This function returns the member functions of this class
        virtual range<meta_member_function> member_functions(void) = 0;

        /// This function returns the conversion operators of this class
        virtual range<meta_conversion_operator> conversions(void) = 0;

};

inline meta_object_category categorize_interface(meta_class*)
{
        return meta_object_category::meta_class_tag;
}

/// Interface for reflecting templated classes
/** This interface provides meta-data about a class
 *
 *  @see boost::mirror::MetaTemplatedClass
 *
 *  @ingroup lagoon_interfaces
 */
struct meta_templated_class
 : virtual meta_templated_type
 , virtual meta_class
{
#if BOOST_MIRROR_NO_RTTI
        virtual void* cast_to(meta_object_category cat)
        {
                if(cat == meta_object_category::meta_templated_class_tag)
                        return (meta_templated_class*) this;
                void* result = meta_templated_type::cast_to(cat);
                if(result != nullptr) return result;
                return meta_class::cast_to(cat);
        }
#endif
};

inline meta_object_category categorize_interface(meta_templated_class*)
{
        return meta_object_category::meta_templated_class_tag;
}

/// Interface for reflecting enumerations
/** This interface provides meta-data about an enum class
 *
 *  @see boost::mirror::MetaEnum
 *
 *  @ingroup lagoon_interfaces
 */
struct meta_enum
 : virtual meta_type
{
#if BOOST_MIRROR_NO_RTTI
        virtual void* cast_to(meta_object_category cat)
        {
                if(cat == meta_object_category::meta_enum_tag)
                        return (meta_enum*) this;
                return meta_type::cast_to(cat);
        }
#endif

        /// The number of elements in the enumeration
        virtual int size(void) = 0;

        /// Return the value at the given index
        virtual int value(int index) = 0;

        /// Returns the name of the i-th value
        virtual std::string value_name(int index) = 0;

        /// Return the value with the provided name
        virtual int value_by_name(const std::string& name) = 0;

        /// Return the name with the provided value
        virtual std::string name_by_value(int value) = 0;

        /// Returns true if the enum has a value with the provided name
        virtual bool has_value_name(const std::string& name) = 0;
};

inline meta_object_category categorize_interface(meta_enum*)
{
        return meta_object_category::meta_enum_tag;
}

/// Interface for reflecting functions
/** This interface provides meta-data about a function
 *
 *  @see boost::mirror::MetaFunction
 *
 *  @ingroup lagoon_interfaces
 */
struct meta_function
 : virtual meta_scope
{
#if BOOST_MIRROR_NO_RTTI
        virtual void* cast_to(meta_object_category cat)
        {
                if(cat == meta_object_category::meta_function_tag)
                        return (meta_function*) this;
                return meta_scope::cast_to(cat);
        }
#endif

        /// returns the meta-type reflecting the type of the result value
        virtual shared<meta_type> result_type(void) = 0;

        /// returns the meta-variables reflecting function's parameters
        virtual range<meta_variable> parameters(void) = 0;
};

inline meta_object_category categorize_interface(meta_function*)
{
        return meta_object_category::meta_function_tag;
}

/// Interface for reflecting constructors
/** This interface provides meta-data about a constructor
 *
 *  @see boost::mirror::MetaConstructor
 *
 *  @ingroup lagoon_interfaces
 */
struct meta_constructor
 : virtual meta_function
{
#if BOOST_MIRROR_NO_RTTI
        virtual void* cast_to(meta_object_category cat)
        {
                if(cat == meta_object_category::meta_constructor_tag)
                        return (meta_constructor*) this;
                return meta_function::cast_to(cat);
        }
#endif

        //virtual raw_ptr new_(...) = 0;

        /// returns the constructor access type specifier
        virtual shared<access_type_specifier> access_type(void) = 0;
};

inline meta_object_category categorize_interface(meta_constructor*)
{
        return meta_object_category::meta_constructor_tag;
}

/// Interface for reflecting member functions
/** This interface provides meta-data about a member function
 *
 *  @see boost::mirror::MetaMemberFunction
 *
 *  @ingroup lagoon_interfaces
 */
struct meta_member_function
 : virtual meta_function
 , virtual meta_class_member
{
#if BOOST_MIRROR_NO_RTTI
        virtual void* cast_to(meta_object_category cat)
        {
                if(cat == meta_object_category::meta_member_function_tag)
                        return (meta_member_function*) this;
                void* result = meta_function::cast_to(cat);
                if(result != nullptr) return result;
                return meta_class_member::cast_to(cat);
        }
#endif

        /// returns the storage class specifier
        virtual shared<storage_class_specifier> storage_class(void) = 0;

        /// alternate name for the storage_class member function
        inline shared<storage_class_specifier> linkage(void)
        {
                return this->storage_class();
        }

        /// returns the constness specifier
        virtual shared<constness_specifier> constness(void) = 0;
};

inline meta_object_category categorize_interface(meta_member_function*)
{
        return meta_object_category::meta_member_function_tag;
}

/// Interface for reflecting conversion operator
/** This interface provides meta-data about a conversion operator
 *
 *  @see boost::mirror::MetaConversionOperator
 *
 *  @ingroup lagoon_interfaces
 */
struct meta_conversion_operator
 : virtual meta_member_function
{
#if BOOST_MIRROR_NO_RTTI
        virtual void* cast_to(meta_object_category cat)
        {
                if(cat == meta_object_category::meta_conversion_operator_tag)
                        return (meta_conversion_operator*) this;
                return meta_member_function::cast_to(cat);
        }
#endif
};

inline meta_object_category categorize_interface(meta_conversion_operator*)
{
        return meta_object_category::meta_conversion_operator_tag;
}

BOOST_LAGOON_NAMESPACE_END

#endif //include guard

