/**
 * @file boost/lagoon/utils/wxxml_factory.hpp
 * @brief RapidXML-based polymorphic factory implementation
 *
 *  Copyright 2008-2010 Matus Chochlik. Distributed under the Boost
 *  Software License, Version 1.0. (See accompanying file
 *  LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
 */

#ifndef BOOST_LAGOON_UTILS_WXXML_FACTORY_1011291729_HPP
#define BOOST_LAGOON_UTILS_WXXML_FACTORY_1011291729_HPP

#include <boost/lagoon/config.hpp>
#include <boost/lagoon/lagoon_fwd.hpp>
#include <boost/lagoon/utils.hpp>
#include <boost/lagoon/interfaces.hpp>

#include <boost/mirror/utils/wxxml_factory.hpp>
#include <boost/lagoon/utils/sdn_factory.hpp>

BOOST_LAGOON_NAMESPACE_BEGIN

using boost::mirror::wxxml_factory_input;

typedef sdn_fact_builder_templ<boost::mirror::sdn_fact_wxxml_traits>
        wxxml_factory_builder;

BOOST_LAGOON_NAMESPACE_END

#endif //include guard

