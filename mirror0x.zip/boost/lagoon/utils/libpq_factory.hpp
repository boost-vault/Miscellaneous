/**
 * @file boost/lagoon/utils/libpq_factory.hpp
 * @brief libpq-based polymorphic factory implementation
 *
 *  Copyright 2008-2010 Matus Chochlik. Distributed under the Boost
 *  Software License, Version 1.0. (See accompanying file
 *  LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
 */

#ifndef BOOST_LAGOON_UTILS_LIBPQ_FACTORY_1011291729_HPP
#define BOOST_LAGOON_UTILS_LIBPQ_FACTORY_1011291729_HPP

#include <boost/lagoon/utils/sql_factory.hpp>
#include <boost/mirror/utils/libpq_factory.hpp>

BOOST_LAGOON_NAMESPACE_BEGIN

using boost::mirror::libpq_fact_data;
using boost::mirror::libpq_fact_result;
using boost::mirror::libpq_fact_db;

typedef sql_fact_builder_templ<
        sql_fact_def_traits<libpq_fact_data>
> libpq_factory_builder;


BOOST_LAGOON_NAMESPACE_END

#endif //include guard

