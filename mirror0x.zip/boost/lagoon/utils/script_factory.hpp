/**
 * @file boost/lagoon/utils/script_factory.hpp
 * @brief Script-parsing framework polymorphic factory implementation
 *
 *  Copyright 2008-2011 Matus Chochlik. Distributed under the Boost
 *  Software License, Version 1.0. (See accompanying file
 *  LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
 */

#ifndef BOOST_LAGOON_UTILS_SCRIPT_FACTORY_1011291729_HPP
#define BOOST_LAGOON_UTILS_SCRIPT_FACTORY_1011291729_HPP

#include <boost/lagoon/config.hpp>
#include <boost/lagoon/lagoon_fwd.hpp>
#include <boost/lagoon/utils.hpp>
#include <boost/lagoon/interfaces.hpp>
#include <boost/lagoon/polymorph_factory.hpp>

#include <boost/mirror/utils/script_factory.hpp>
// Script-parsing factory-related
#include <boost/lagoon/utils/script_factory/utils.hpp>
#include <boost/lagoon/utils/script_factory/manager.hpp>
#include <boost/lagoon/utils/script_factory/composite.hpp>
#include <boost/lagoon/utils/script_factory/arrayer.hpp>
#include <boost/lagoon/utils/script_factory/manufacturer.hpp>
#include <boost/lagoon/utils/script_factory/suppliers.hpp>
#include <boost/lagoon/utils/script_factory/enumerator.hpp>
#include <boost/lagoon/utils/script_factory/builder.hpp>

#include <boost/mirror/utils/script_factory/default_traits.hpp>

BOOST_LAGOON_NAMESPACE_BEGIN

using boost::mirror::script_fact_def_traits;
using boost::mirror::script_factory_input;
using boost::mirror::c_str_script_factory_input;

typedef script_fact_builder_templ<
        script_fact_def_traits<std::string::const_iterator>
> script_factory_builder;

typedef script_fact_builder_templ<
        script_fact_def_traits<const char*>
> c_str_script_factory_builder;

BOOST_LAGOON_NAMESPACE_END

#endif //include guard

