/**
 * @file boost/lagoon/utils/wx_gui_factory.hpp
 * @brief wxWidgets-based GUI polymorphic factory implementation
 *
 *  Copyright 2008-2010 Matus Chochlik. Distributed under the Boost
 *  Software License, Version 1.0. (See accompanying file
 *  LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
 */

#ifndef BOOST_LAGOON_UTILS_WX_GUI_FACTORY_1011291729_HPP
#define BOOST_LAGOON_UTILS_WX_GUI_FACTORY_1011291729_HPP

#include <boost/lagoon/config.hpp>
#include <boost/lagoon/lagoon_fwd.hpp>
#include <boost/lagoon/utils.hpp>
#include <boost/lagoon/interfaces.hpp>
#include <boost/lagoon/polymorph_factory.hpp>

// wx gui factory-related
#include <boost/lagoon/utils/wx_gui_factory/data.hpp>
#include <boost/lagoon/utils/wx_gui_factory/utils.hpp>
#include <boost/lagoon/utils/wx_gui_factory/default_traits.hpp>
#include <boost/lagoon/utils/wx_gui_factory/manager.hpp>
#include <boost/lagoon/utils/wx_gui_factory/composite.hpp>
#include <boost/lagoon/utils/wx_gui_factory/arrayer.hpp>
#include <boost/lagoon/utils/wx_gui_factory/manufacturer.hpp>
#include <boost/lagoon/utils/wx_gui_factory/suppliers.hpp>
#include <boost/lagoon/utils/wx_gui_factory/enumerator.hpp>
#include <boost/lagoon/utils/wx_gui_factory/builder.hpp>

BOOST_LAGOON_NAMESPACE_BEGIN

BOOST_LAGOON_NAMESPACE_END

#endif //include guard

