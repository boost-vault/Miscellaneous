/**
 * @file boost/lagoon/specifiers.hpp
 * @brief Definitions of the specifiers and categorization tag values
 *
 *  Copyright 2008-2011 Matus Chochlik. Distributed under the Boost
 *  Software License, Version 1.0. (See accompanying file
 *  LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
 */

#ifndef BOOST_LAGOON_SPECIFIERS_1011291729_HPP
#define BOOST_LAGOON_SPECIFIERS_1011291729_HPP

#include <boost/lagoon/lagoon_fwd.hpp>
#include <boost/lagoon/auxiliary/fwd.hpp>
#include <boost/lagoon/utils.hpp>
#include <boost/mirror/specifier_tags.hpp>

BOOST_LAGOON_NAMESPACE_BEGIN

/** @defgroup lagoon_specifiers Lagoon - Specifiers
 *
 *  Lagoon provides access to specifier meta-data through specifier
 *  interfaces and allows to do run-time categorization with specifier
 *  tags.
 */


/// Enumeration of tags categorizing various specifiers
/**
 *  @ingroup lagoon_specifiers
 */
enum class specifier_category : unsigned int
{
        spec__tag = 0x1,

        /// Indicates that the specifier is a inheritance type specifier
        spec_inheritance_type_tag = 0x10,

        /// Represents non-virtual inheritance
        spec_non_virtual_tag =
                spec_inheritance_type_tag |
                spec__tag,

        /// Represents virtual inheritance
        spec_virtual_tag =
                spec_inheritance_type_tag |
                spec_inheritance_type_tag << 1,

        /// Indicates that the specifier is an access type specifier
        spec_access_type_tag = 0x100,

        /// Represents private member access
        spec_private_tag =
                spec_access_type_tag |
                spec_access_type_tag << 1,

        /// Represents protected member access
        spec_protected_tag =
                spec_access_type_tag |
                spec_access_type_tag << 2,

        /// Represents public member access
        spec_public_tag =
                spec_access_type_tag |
                spec_access_type_tag << 3,

        /// Indicates that the specifier is a elaborated type specifier
        spec_elaborated_type_tag = 0x1000,

        /// Represents non-elaborate type
        spec_type_tag =
                spec_elaborated_type_tag |
                spec__tag,

        /// Represents class elaborate type
        spec_class_tag =
                spec_elaborated_type_tag |
                spec_elaborated_type_tag << 1,

        /// Represents struct elaborate type
        spec_struct_tag =
                spec_elaborated_type_tag |
                spec_elaborated_type_tag << 2,

        /// Represents union elaborate type
        spec_union_tag =
                spec_elaborated_type_tag |
                spec_elaborated_type_tag << 3,

        /// Represents enum elaborate type
        spec_enum_tag =
                spec_elaborated_type_tag |
                spec_elaborated_type_tag << 4,

        /// Indicates that the specifier is a storage class specifier
        spec_storage_class_tag = 0x100000,

        /// Represents the automatic storage class
        spec_auto_tag =
                spec_storage_class_tag |
                spec__tag,

        /// Represents the extern storage class
        spec_extern_tag =
                spec_storage_class_tag |
                spec_storage_class_tag << 1,

        /// Represents the mutable storage class
        spec_mutable_tag =
                spec_storage_class_tag |
                spec_storage_class_tag << 2,

        /// Represents the register storage class
        spec_register_tag =
                spec_storage_class_tag |
                spec_storage_class_tag << 3,

        /// Represents the static storage class
        spec_static_tag =
                spec_storage_class_tag |
                spec_storage_class_tag << 4,

        spec_thread_local_tag =
                spec_storage_class_tag |
                spec_storage_class_tag << 5,

        /// Indicates that the specifier is a constness specifier
        spec_constness_tag = 0x10000000,

        /// Represents the (empty default) non-const constness
        spec_non_const_tag =
                spec_constness_tag |
                spec__tag,

        /// Represents the const constness
        spec_const_tag =
                spec_constness_tag |
                spec_constness_tag << 1
};

/// Common base interface for various specifiers
/** Serves as the base interface for classes representing various
 *  specifiers.
 *
 *  @ingroup lagoon_specifiers
 */
struct specifier
{
private:
        const std::string _keyword;
        specifier_category _category;

        static inline bool category_matches(unsigned a, unsigned b)
        {
                return (a & b) == b;
        }
protected:
        // categorize the 'virtual' specifier
        static specifier_category cat(boost::mirror::spec_virtual_tag)
        {
                return specifier_category::spec_virtual_tag;
        }

        // categorize the non-virtual (empty default) specifier
        static specifier_category cat(boost::mirror::spec_non_virtual_tag)
        {
                return specifier_category::spec_non_virtual_tag;
        }

        // categorize the 'private' specifier
        static specifier_category cat(boost::mirror::spec_private_tag)
        {
                return specifier_category::spec_private_tag;
        }

        // categorize the 'protected' specifier
        static specifier_category cat(boost::mirror::spec_protected_tag)
        {
                return specifier_category::spec_protected_tag;
        }

        // categorize the 'public' specifier
        static specifier_category cat(boost::mirror::spec_public_tag)
        {
                return specifier_category::spec_public_tag;
        }

        // categorize the 'class' specifier
        static specifier_category cat(boost::mirror::spec_class_tag)
        {
                return specifier_category::spec_class_tag;
        }

        // categorize the 'struct' specifier
        static specifier_category cat(boost::mirror::spec_struct_tag)
        {
                return specifier_category::spec_struct_tag;
        }

        // categorize the 'union' specifier
        static specifier_category cat(boost::mirror::spec_union_tag)
        {
                return specifier_category::spec_union_tag;
        }

        // categorize the 'enum' specifier
        static specifier_category cat(boost::mirror::spec_enum_tag)
        {
                return specifier_category::spec_enum_tag;
        }

        // categorize the 'type' specifier
        static specifier_category cat(boost::mirror::spec_type_tag)
        {
                return specifier_category::spec_type_tag;
        }

        // categorize the (former explicit,now implicit) default auto specifier
        static specifier_category cat(boost::mirror::spec_auto_tag)
        {
                return specifier_category::spec_auto_tag;
        }

        // categorize the 'extern' specifier
        static specifier_category cat(boost::mirror::spec_extern_tag)
        {
                return specifier_category::spec_extern_tag;
        }

        // categorize the 'mutable' specifier
        static specifier_category cat(boost::mirror::spec_mutable_tag)
        {
                return specifier_category::spec_mutable_tag;
        }

        // categorize the 'register' specifier
        static specifier_category cat(boost::mirror::spec_register_tag)
        {
                return specifier_category::spec_register_tag;
        }

        // categorize the 'static' specifier
        static specifier_category cat(boost::mirror::spec_static_tag)
        {
                return specifier_category::spec_static_tag;
        }

        // categorize the 'thread_local' specifier
        static specifier_category cat(boost::mirror::spec_thread_local_tag)
        {
                return specifier_category::spec_thread_local_tag;
        }

        // categorize the 'const' specifier
        static specifier_category cat(boost::mirror::spec_const_tag)
        {
                return specifier_category::spec_const_tag;
        }

        // categorize the non-const (empty default) specifier
        static specifier_category cat(boost::mirror::spec_non_const_tag)
        {
                return specifier_category::spec_non_const_tag;
        }

        template <class Specifier>
        specifier(Specifier)
         : _keyword(Specifier::keyword())
         , _category(cat(Specifier()))
        { }
public:
        /// Returns the specifier keyword
        std::string keyword(void)
        {
                return _keyword;
        }

        /// Returns the tag identifying the category of the specifier
        specifier_category category(void)
        {
                return _category;
        }

        /// Convenience function for checking if the specifier is of a category
        inline bool is_a(specifier_category cat)
        {
                return category_matches(
                        unsigned(category()),
                        unsigned(cat)
                );
        }

        /// Returns true if this is the non-specifier
        bool is_none(void)
        {
                return is_a(specifier_category::spec__tag);
        }

        /// Returns true if this is an inheritance type specifier
        bool is_inheritance_type_spec(void)
        {
                return is_a(specifier_category::spec_inheritance_type_tag);
        }

        /// Returns true if this is an member access type specifier
        bool is_access_type_spec(void)
        {
                return is_a(specifier_category::spec_access_type_tag);
        }

        /// Returns true if this is an elaborate type specifier
        bool is_elaborated_type_spec(void)
        {
                return is_a(specifier_category::spec_elaborated_type_tag);
        }

        /// Returns true if this is a storage class specifier
        bool is_storage_class_spec(void)
        {
                return is_a(specifier_category::spec_storage_class_tag);
        }

        /// Returns true if this is a member function constness specifier
        bool is_constness_spec(void)
        {
                return is_a(specifier_category::spec_constness_tag);
        }
};


/// Interface representing inheritance type specifiers
struct inheritance_type_specifier
 : public specifier
{
private:
        template <typename Specifier, typename Interface>
        friend shared<Interface> aux::get_inheritance_type_spec(void);

        template <class Specifier>
        inheritance_type_specifier(Specifier spec)
         : specifier(spec)
        { }
public:
        /// Returns true if this is the virtual specifier
        bool is_virtual(void)
        {
                return is_a(specifier_category::spec_virtual_tag);
        }

        /// Returns true if this is the non-virtual specifier
        bool is_non_virtual(void)
        {
                return is_a(specifier_category::spec_non_virtual_tag);
        }
};

/// Interface representing member access type specifiers
struct access_type_specifier
 : public specifier
{
private:
        template <typename Specifier, typename Interface>
        friend shared<Interface> aux::get_access_type_spec(void);

        template <class Specifier>
        access_type_specifier(Specifier spec)
         : specifier(spec)
        { }
public:
        /// Returns true if this is the private specifier
        bool is_private(void)
        {
                return is_a(specifier_category::spec_private_tag);
        }

        /// Returns true if this is the protected specifier
        bool is_protected(void)
        {
                return is_a(specifier_category::spec_protected_tag);
        }

        /// Returns true if this is the public specifier
        bool is_public(void)
        {
                return is_a(specifier_category::spec_public_tag);
        }
};

/// Interface representing elaborate type specifiers
struct elaborated_type_specifier
 : public specifier
{
private:
        template <typename Specifier, typename Interface>
        friend shared<Interface> aux::get_elaborated_type_spec(void);

        template <class Specifier>
        elaborated_type_specifier(Specifier spec)
         : specifier(spec)
        { }
public:
        /// Returns true if this is the class specifier
        bool is_class(void)
        {
                return is_a(specifier_category::spec_class_tag);
        }

        /// Returns true if this is the struct specifier
        bool is_struct(void)
        {
                return is_a(specifier_category::spec_struct_tag);
        }

        /// Returns true if this is the union specifier
        bool is_union(void)
        {
                return is_a(specifier_category::spec_union_tag);
        }

        /// Returns true if this is the enum specifier
        bool is_enum(void)
        {
                return is_a(specifier_category::spec_enum_tag);
        }

        /// Returns true if this is the non-elaborated type spec
        bool is_type(void)
        {
                return is_a(specifier_category::spec_type_tag);
        }
};

/// Interface representing storage class specifiers
struct storage_class_specifier
 : public specifier
{
private:
        template <typename Specifier, typename Interface>
        friend shared<Interface> aux::get_storage_class_spec(void);

        template <class Specifier>
        storage_class_specifier(Specifier spec)
         : specifier(spec)
        { }
public:
        /// Returns true if this is the auto (default) specifier
        bool is_auto(void)
        {
                return is_a(specifier_category::spec_auto_tag);
        }

        /// Returns true if this is the extern specifier
        bool is_extern(void)
        {
                return is_a(specifier_category::spec_extern_tag);
        }

        /// Returns true if this is the mutable specifier
        bool is_mutable(void)
        {
                return is_a(specifier_category::spec_mutable_tag);
        }

        /// Returns true if this is the register specifier
        bool is_register(void)
        {
                return is_a(specifier_category::spec_register_tag);
        }

        /// Returns true if this is the static specifier
        bool is_static(void)
        {
                return is_a(specifier_category::spec_static_tag);
        }

        /// Returns true if this is the thread_local specifier
        bool is_thread_local(void)
        {
                return is_a(specifier_category::spec_thread_local_tag);
        }
};

/// Interface representing class member function constness specifiers
struct constness_specifier
 : public specifier
{
private:
        template <typename Specifier, typename Interface>
        friend shared<Interface> aux::get_constness_spec(void);

        template <class Specifier>
        constness_specifier(Specifier spec)
         : specifier(spec)
        { }
public:
        /// Returns true if this is the non const (empty default) specifier
        bool is_non_const(void)
        {
                return is_a(specifier_category::spec_non_const_tag);
        }

        /// Returns true if this is the const specifier
        bool is_const(void)
        {
                return is_a(specifier_category::spec_const_tag);
        }
};

BOOST_LAGOON_NAMESPACE_END


#endif //include guard

