/*
The Paired Ptr Library
A library for bidirectional connectivity between objects.
Copyright 2010 by Dan Walters

Distributed under the Boost Software License, Version 1.0.
See accompanying file LICENSE_1_0.txt or copy at
http://www.boost.org/LICENSE_1_0.txt

See http://www.boost.org/libs/paired_ptr for library home page.
*/

/*! \file
\brief This is the main header for paired_ptr.
*/

#ifndef BOOST_INCLUDED_PAIRED_PTR_HPP
#define BOOST_INCLUDED_PAIRED_PTR_HPP

template <class T, class U>
class paired_ptr
{
	T* m_p_owner;
	paired_ptr<U,T>* p_other_ptr;
	void (T::*connect_callback)();
	void (T::*disconnect_callback)();

public:

	typedef T element_type;
	typedef T value_type;
	typedef T * pointer;

	paired_ptr()
		: m_p_owner(NULL), p_other_ptr(NULL), connect_callback(NULL), disconnect_callback(NULL) {}

	~paired_ptr()
	{
		if(p_other_ptr)
			p_other_ptr->disconnect_pair();
	}

	void set_owner(T* p_owner)
	{
		m_p_owner = p_owner;
	}

	void set_connect_callback(void (T::*callback)())
	{
		connect_callback = callback;
	}

	void set_disconnect_callback(void (T::*callback)())
	{
		disconnect_callback = callback;
	}

	T* owner()
	{
		return m_p_owner;
	}

	U* get()
	{
		return p_other_ptr->owner();
	}

	U* operator-> () const
	{
		BOOST_ASSERT(p_other_ptr != 0);
		BOOST_ASSERT(p_other_ptr->owner() != 0);
		return p_other_ptr->owner();
	}

	void connect_pair(paired_ptr<U,T>* p_ptr)
	{
		if(p_ptr != p_other_ptr)
		{
			disconnect_pair();
			p_other_ptr = p_ptr;
			if(connect_callback)
				(m_p_owner->*connect_callback)();
			p_other_ptr->notify_connect_pair(this);
		}
	}

	void disconnect_pair()
	{
		if(p_other_ptr)
		{
			p_other_ptr->notify_disconnect_pair();
			notify_disconnect_pair();
		}
	}

	void swap_ptr(paired_ptr<T,U>* p_ptr)
	{
		if(p_other_ptr != p_ptr->get_other_ptr())
		{
			callback_disconnect();
			p_ptr->disconnect_callback();

			paired_ptr<U,T>* p_temp = p_other_ptr;
			p_other_ptr = p_ptr->get_other_ptr();
			p_ptr->set_other_ptr(p_temp);

			callback_connect();
			p_ptr->callback_connect();
		}
	}

	friend class paired_ptr<U, T>;

protected:

	void notify_disconnect_pair()
	{
		callback_disconnect();
		p_other_ptr = NULL;
	}

	void notify_connect_pair(paired_ptr<U,T>* p_ptr)
	{
		disconnect_pair();
		p_other_ptr = p_ptr;
		callback_connect();
	}

	paired_ptr<U,T>* get_other_ptr()
	{
		return p_other_ptr;
	}

	void set_other_ptr(paired_ptr<U,T>* p_ptr)
	{
		p_other_ptr = p_ptr;
	}

	void callback_disconnect()
	{
		if(disconnect_callback)
			(m_p_owner->*disconnect_callback)();
	}

	void callback_connect()
	{
		if(connect_callback)
			(m_p_owner->*connect_callback)();
	}
};

#endif // BOOST_INCLUDED_PAIRED_PTR_HPP