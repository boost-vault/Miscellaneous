#include <boost/twinned_link/twinned_link.hpp>
#include <iostream>

class CBoy;
class CGirl;

class CBoy
{
public:
	CBoy()
	{
		m_girlfriend.set_owner(this);
	}
	void GiveGirlfriendFlowers();
	void RecvSlap()
	{
		std::cout << "boy: ouch!" << '\n';
		m_girlfriend.disconnect_pair();
	}
	paired_ptr<CBoy,CGirl> m_girlfriend;
};

class CGirl
{
public:
	CGirl()
	{
		m_boyfriend.set_owner(this);
		m_boyfriend.set_connect_callback(&CGirl::make_boyfriend);
		m_boyfriend.set_disconnect_callback(&CGirl::break_boyfriend);
	}
	void RecvFlowers()
	{
		std::cout << "girl: thank you for the flowers!" << '\n';
	}
	void SlapBoyfriend()
	{
		std::cout << "girl: take this!" << '\n';
		if(m_boyfriend.get())
			m_boyfriend.get()->RecvSlap();
	}
	void make_boyfriend()
	{
		std::cout << "girl: i have a boyfriend!" << '\n';
	}
	void break_boyfriend()
	{
		std::cout << "girl: we broke up." << '\n';
	}
	paired_ptr<CGirl,CBoy> m_boyfriend;
};

void CBoy::GiveGirlfriendFlowers()
{
	if(m_girlfriend.get())
		m_girlfriend.get()->RecvFlowers();
}


int main()
{
	CBoy Henry;
	CGirl Sally;

	Henry.m_girlfriend.connect_pair(&Sally.m_boyfriend);

	Henry.GiveGirlfriendFlowers();
	Sally.SlapBoyfriend();

	return 0;
}