// Copyright 2006 (C) Dean Michael Berris <dean@orangeandbronze.com>
// Distributed under the Boost Software License, Version 1.0. (See accompanying
// file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)

#define BOOST_AUTO_TEST_MAIN
#include <boost/test/auto_unit_test.hpp>
#include <boost/bind.hpp>
#include <string>

#include <boost/dispatch.hpp>

void void_function() {
};

void function(int i) {
};

int function_returns_int (int j) {
    return j+1;
};

BOOST_AUTO_TEST_CASE ( dispatch_register_test ) {
    boost::dispatch::dispatcher<void(), int> d;
    d[0] = boost::bind(function, 2);
    d[1] = boost::bind(function, 2);
    d[2] = void_function;
    BOOST_REQUIRE_NO_THROW (d[0]());
    BOOST_REQUIRE_NO_THROW (d[1]());
    BOOST_REQUIRE_NO_THROW (d[2]());
    BOOST_REQUIRE_THROW (d[3](), boost::dispatch::unregistered_handler);
};

BOOST_AUTO_TEST_CASE ( dispatch_primitive_return_test ) {
    boost::dispatch::dispatcher<int(), int> d;
    d[0] = boost::bind(function_returns_int, 1);
    d[1] = boost::bind(function_returns_int, 2);
    BOOST_CHECK_EQUAL (d[0](), 2);
    BOOST_CHECK_EQUAL (d[1](), 3);
    BOOST_REQUIRE_THROW (d[2](), boost::dispatch::unregistered_handler);
};

struct require_even_strategy {
    bool operator() (int number) const {
        return (number != 0) && ((number % 2) == 0);
    };
};

BOOST_AUTO_TEST_CASE ( strategized_dispatcher_test ) {
    boost::dispatch::dispatcher<int(), int, require_even_strategy> d;
    d[2] = boost::bind(function_returns_int, 3);
    d[4] = boost::bind(function_returns_int, 5);
};

BOOST_AUTO_TEST_CASE ( strategized_dispatcher_call_test ) {
    boost::dispatch::dispatcher<int(), int, require_even_strategy> d;
    BOOST_REQUIRE_THROW ((d[0] = boost::bind(function_returns_int, 1)), boost::dispatch::invalid_index<int>  );
    BOOST_REQUIRE_NO_THROW ((d[2] = boost::bind(function_returns_int, 2)));
};

BOOST_AUTO_TEST_CASE ( dispatcher_unregister_test ) {
    boost::dispatch::dispatcher <void(), int> d;
    d[0] = boost::bind(function, 1);
    BOOST_REQUIRE_NO_THROW (d[0]() );
    d.unset(0);
    BOOST_REQUIRE_THROW (d[0](), boost::dispatch::unregistered_handler);
};

#include <boost/tuple/tuple.hpp>

boost::tuple<int, int> function_returns_tuple (int k) {
    return boost::make_tuple<int, int> (k + 1, k + 2);
};

BOOST_AUTO_TEST_CASE ( dispatch_tuple_return_test ) {
    boost::dispatch::dispatcher< boost::tuple<int, int> () , int > d;
    d[0] = boost::bind(&function_returns_tuple, 1);
    d[1] = boost::bind(&function_returns_tuple, 2);
    int temp1, temp2;
    boost::tie<int, int>(temp1, temp2) = d[0]();
    BOOST_REQUIRE_EQUAL (temp1, 2);
    BOOST_REQUIRE_EQUAL (temp2, 3);
    boost::tie<int, int>(temp1, temp2) = d[1]();
    BOOST_REQUIRE_EQUAL (temp1, 3);
    BOOST_REQUIRE_EQUAL (temp2, 4);
    BOOST_REQUIRE_THROW (d[2](), boost::dispatch::unregistered_handler );
};

// parameterized dispatcher
BOOST_AUTO_TEST_CASE ( parameterized_dispatch_test ) {
    boost::dispatch::dispatcher< int (int), int > d;
    d[0] = function_returns_int;
    BOOST_REQUIRE_EQUAL (d[0](1), 2);
    BOOST_REQUIRE_EQUAL (d[0](2), 3);
    BOOST_REQUIRE_THROW (d[1](1), boost::dispatch::unregistered_handler);
};

int function_2args_returns_int (int a, int b) {
    return a + b;
};

// parameterized dispatcher (2 arguments)
BOOST_AUTO_TEST_CASE ( parameterized_dispatch_2args_test ) {
    boost::dispatch::dispatcher <int (int, int), int> d;
    d[0] = function_2args_returns_int;
    BOOST_REQUIRE_EQUAL (d[0](1, 2), 3);
    BOOST_REQUIRE_EQUAL (d[0](2, 3), 5);
    BOOST_REQUIRE_THROW ((d[1](1, 2)), boost::dispatch::unregistered_handler);
};

class sample_functor {
public:
    int operator() (int x) {
        return x * 2;
    };
};

BOOST_AUTO_TEST_CASE ( functor_dispatch_1arg_test ) {
    boost::dispatch::dispatcher <int (int), int> d;
    sample_functor sample;
    d[0] = sample;
    BOOST_REQUIRE_EQUAL (d[0](1), 2);
    BOOST_REQUIRE_EQUAL (d[0](2), 4);
    BOOST_REQUIRE_THROW ((d[1](1)), boost::dispatch::unregistered_handler);
};

int function_3_arg(int a, int b, std::string s) {
    return a+b;
};

BOOST_AUTO_TEST_CASE ( functor_dispatch_3arg_test ) {
    boost::dispatch::dispatcher <int (int, int, std::string), int> d;
    d[0] = function_3_arg;
    BOOST_REQUIRE_EQUAL (d[0](1, 2, "This is a string"), 3);
    BOOST_REQUIRE_EQUAL (d[0](1, 2, "This is another string"), 3);
    BOOST_REQUIRE_THROW ((d[1](1, 2, "This won't work")), boost::dispatch::unregistered_handler);
};

int function_4_arg(int a, std::string b, double d, double) {
    return a;
};

BOOST_AUTO_TEST_CASE ( function_dispatch_4arg_test ) {
    boost::dispatch::dispatcher < int (int, std::string, double, double), int > d;
    d[0] = function_4_arg;
    BOOST_REQUIRE_EQUAL ((d[0](1,"This is a string",1.9, 2.1)),1);
    BOOST_REQUIRE_EQUAL ((d[0](1,"This ia another string", 1.9, 2.1)), 1);
    BOOST_REQUIRE_THROW ((d[1](1,"This won't work", 1.2, 3.5)), boost::dispatch::unregistered_handler);
};

int function_5_arg(int a, std::string b, double d, float e, char f) {
    return a;
};

BOOST_AUTO_TEST_CASE ( function_dispatch_5arg_test ) {
    boost::dispatch::dispatcher < int (int, std::string, double, float, char), int > d;
    d[0] = function_5_arg;
    BOOST_REQUIRE_EQUAL ((d[0](1, "This is a string", 1.9, 2.1f, 'a')), 1);
    BOOST_REQUIRE_EQUAL ((d[0](2, "This is another string", 1.8, 8.9f, 'c')), 2);
    BOOST_REQUIRE_THROW ((d[1](1, "This won't work", 1.2, 3.5f, 'd')), boost::dispatch::unregistered_handler);
};

int function_6_arg(int a, int b, int c, int d, int e, int f) {
    return a + b + c + d + e + f;
};

BOOST_AUTO_TEST_CASE ( function_dispatch_6arg_test ) {
    boost::dispatch::dispatcher < int (int, int, int, int, int, int), int > d;
    d[0] = function_6_arg;
    BOOST_REQUIRE_EQUAL ((d[0](1, 1, 1, 1, 1, 1)), 6);
    BOOST_REQUIRE_EQUAL ((d[0](0, 0, 0, 0, 0, 0)), 0);
    BOOST_REQUIRE_THROW ((d[1](0, 0, 0, 0, 0, 0)), boost::dispatch::unregistered_handler);
};

struct my_type {
    int value;
    my_type () : value(0) { };
    explicit my_type(int val) : value(val) { };
    my_type(const my_type & other) : value (other.value) { };
};

template <>
struct std::less<my_type> {
    bool operator ()(const my_type &_Left, const my_type &_Right) const {
        return _Left.value < _Right.value;
    };
};

BOOST_AUTO_TEST_CASE ( function_user_defined_index_dispatch_test ) {
    boost::dispatch::dispatcher < void () , my_type > d;
    d[my_type()] = void_function;
    BOOST_REQUIRE_NO_THROW (d[my_type()]());
    BOOST_REQUIRE_THROW (d[my_type(1)](), boost::dispatch::unregistered_handler);
};

BOOST_AUTO_TEST_CASE ( dispatch_macro_test ) {
    boost::dispatch::dispatcher < void () > d;
    d[0] = void_function;
    BOOST_DISPATCH ( d[1](), void_function(); );
};

struct rotisserie {
    unsigned int index;
    
    rotisserie() : index (0) { };
    
    unsigned int operator() (unsigned int) {
        return index++ % 3;
    };
};

unsigned int function1() {
    return 1;
};

unsigned int function2() {
    return 2;
};

unsigned int function3() {
    return 3;
};

BOOST_AUTO_TEST_CASE ( dispatch_routing_strategy_test ) {
    boost::dispatch::dispatcher <int(), unsigned int,
        boost::dispatch::detail::always_true<unsigned int>,
        rotisserie > d;
    d[0] = function1;
    d[0] = function2;
    d[0] = function3;
    BOOST_REQUIRE_EQUAL (d[0](), 1);
    BOOST_REQUIRE_EQUAL (d[0](), 2);
    BOOST_REQUIRE_EQUAL (d[0](), 3);
    BOOST_REQUIRE_EQUAL (d[0](), 1);
};

typedef boost::dispatch::dispatcher < void () > void_dispatcher;
BOOST_AUTO_TEST_CASE ( dispatch_invoker ) {
    void_dispatcher d;
    d[0] = void_function;
    d[1] = void_function;
    void_dispatcher::invoke_(d) << 0 << 1;
};

typedef boost::dispatch::dispatcher < void (int) > void_int_dispatcher;
BOOST_AUTO_TEST_CASE ( dispatch_arg1_invoker ) {
    void_int_dispatcher d;
    d[0] = function ;
    d[1] = function ;
    void_int_dispatcher::invoke_(d)(0) << 0 << 1;
};

struct int_aggregator {
    std::vector<int> & _v;
    int_aggregator (std::vector<int> & v) : _v(v) { };
    void operator() (int i) {
        _v.push_back(i);
    };
};

typedef boost::dispatch::dispatcher < int (int) > int_int_dispatcher;
BOOST_AUTO_TEST_CASE ( dispatch_arg1_accumulator_invoker ) {
    int_int_dispatcher d;
    d[0] = function_returns_int;
    d[1] = function_returns_int;
    std::vector<int> v;
    int_aggregator a(v);
    int_int_dispatcher::invoke_(d, a)(1) << 0 << 1;
    BOOST_REQUIRE_EQUAL (v[0], 2);
    BOOST_REQUIRE_EQUAL (v[1], 2);
};

typedef boost::dispatch::dispatcher < int (int, int) > int_int_int_dispatcher;
BOOST_AUTO_TEST_CASE ( dispatch_arg2_accumulator_invoker ) {
    int_int_int_dispatcher d;
    d[0] = function_2args_returns_int;
    d[1] = function_2args_returns_int;
    std::vector<int> v;
    int_aggregator a(v);
    int_int_int_dispatcher::invoke_(d, a)(1, 2) << 0 << 1;
    BOOST_REQUIRE_EQUAL (v[0], 3);
    BOOST_REQUIRE_EQUAL (v[1], 3);
};

typedef boost::dispatch::dispatcher < int (int, int, int) > int_int_int_int_dispatcher;
int int_function_3args(int i, int j, int k) {
    return i + j + k;
};

BOOST_AUTO_TEST_CASE ( dispatch_arg3_accumulator_invoker ) {
    int_int_int_int_dispatcher d;
    d[0] = int_function_3args;
    d[1] = int_function_3args;
    std::vector<int> v;
    int_aggregator a(v);
    int_int_int_int_dispatcher::invoke_(d, a)(1, 2, 3) << 0 << 1;
    BOOST_REQUIRE_EQUAL (v[0], 6);
    BOOST_REQUIRE_EQUAL (v[1], 6);
};

typedef boost::dispatch::dispatcher < int (int, int, int, int) > int_int_int_int_int_dispatcher;
int int_function_4args(int i, int j, int k, int l) {
    return i + j + k + l;
};

BOOST_AUTO_TEST_CASE ( dispatch_arg4_accumulator_invoker ) {
    int_int_int_int_int_dispatcher d;
    d[0] = int_function_4args;
    d[1] = int_function_4args;
    std::vector<int> v;
    int_aggregator a(v);
    int_int_int_int_int_dispatcher::invoke_(d, a)(1, 2, 3, 4) << 0 << 1;
    BOOST_REQUIRE_EQUAL (v[0], 10);
    BOOST_REQUIRE_EQUAL (v[1], 10);
};

typedef boost::dispatch::dispatcher < int (int, int, int, int, int) > int_int_int_int_int_int_dispatcher;
int int_function_5args(int i, int j, int k, int l, int m) {
    return i + j + k + l + m;
};

BOOST_AUTO_TEST_CASE ( dispatch_arg5_accumulator_invoker ) {
    int_int_int_int_int_int_dispatcher d;
    d[0] = int_function_5args;
    d[1] = int_function_5args;
    std::vector<int> v;
    int_aggregator a(v);
    int_int_int_int_int_int_dispatcher::invoke_(d, a)(1, 2, 3, 4, 5) << 0 << 1;
    BOOST_REQUIRE_EQUAL (v[0], 15);
    BOOST_REQUIRE_EQUAL (v[1], 15);
};

typedef boost::dispatch::dispatcher < int (int, int, int, int, int, int) > int_int_int_int_int_int_int_dispatcher;
int int_function_6args(int i, int j, int k, int l, int m, int n) {
    return i + j + k + l + m + n;
};

BOOST_AUTO_TEST_CASE ( dispatch_arg6_accumulator_invoker ) {
    int_int_int_int_int_int_int_dispatcher d;
    d[0] = int_function_6args;
    d[1] = int_function_6args;
    std::vector<int> v;
    int_aggregator a(v);
    int_int_int_int_int_int_int_dispatcher::invoke_(d, a)
        (1, 2, 3, 4, 5, 6) 
        << 0 
        << 1;
    BOOST_REQUIRE_EQUAL (v[0], 21);
    BOOST_REQUIRE_EQUAL (v[1], 21);
};
