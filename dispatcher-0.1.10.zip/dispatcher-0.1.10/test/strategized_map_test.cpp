// Copyright 2006 (C) Dean Michael Berris <dean@orangeandbronze.com>
// Distributed under the Boost Software License, Version 1.0. (See accompanying
// file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)

#define BOOST_AUTO_TEST_MAIN
#include <boost/test/auto_unit_test.hpp>
#include <algorithm>

#include "boost/strategized_map.hpp"

struct hash_function {
    int operator () (int value) const {
        return value % 17;
    };
};

struct hash_function_1 {
    explicit hash_function_1(int mod)
        : _mod(mod) { };

    int _mod;

    int operator () (int value) const {
        return value & _mod;
    };
};

struct hash_function_2 {
    hash_function_2 (int mod1, short mod2)
        : _mod1(mod1), _mod2(mod2) { };

    int _mod1, _mod2;

    int operator () (int value) const {
        return (_mod2 + value) % _mod1;
    };
};

BOOST_AUTO_TEST_CASE ( strat_map_instantiation ) {
    boost::strategized_map<int, int> instance;
    boost::strategized_map<int, int, hash_function> instance1;
    boost::strategized_map<int, int, hash_function_1> instance2(97);
    boost::strategized_map<int, int, hash_function_2> instance3(29, 4);
};

BOOST_AUTO_TEST_CASE ( strat_map_indexing ) {
    boost::strategized_map<int, int, hash_function> instance;
    instance[1] = 1;
    instance[18] = 2;
    BOOST_REQUIRE_EQUAL ( 2, instance[1] );
};

BOOST_AUTO_TEST_CASE ( strat_map_clearing ) {
    boost::strategized_map<int, int, hash_function> instance;
    // when not set to 0, causes a bug on Win32 MSVC8
    // 1243188 != 0
    // TODO: ask Boost about standard regarding
    // initializing ints in a map.
    int uninitialized = 0;
    instance[1] = 1;
    instance[18] = 2;
    instance.clear();
    BOOST_REQUIRE_EQUAL ( uninitialized, instance[1] );
};

BOOST_AUTO_TEST_CASE ( strat_map_insert ) {
    boost::strategized_map<int, int> instance;
    std::pair<int, int> test1(1, 1);
    instance.insert(test1);
    BOOST_REQUIRE_EQUAL ( 1, instance[1] );
};

BOOST_AUTO_TEST_CASE ( strat_map_insert_strategized ) {
    boost::strategized_map<int, int, hash_function> instance;
    std::pair<int, int> test1(18, 1);
    instance.insert(test1);
    BOOST_REQUIRE_EQUAL ( 1, instance[1] );
};

BOOST_AUTO_TEST_CASE ( strat_map_remove_strategized ) {
    boost::strategized_map<int, int, hash_function> instance;
    std::pair<int, int> test1(18, 1);
    instance.insert(test1);
    BOOST_REQUIRE_EQUAL ( 1, instance[1] );
    instance.erase(18);
    BOOST_REQUIRE_EQUAL ( 0, instance[1] );
};

BOOST_AUTO_TEST_CASE ( strat_map_iterator ) {
    typedef boost::strategized_map<int, int, hash_function> strat_map;
    strat_map instance;
    std::pair<int, int> test1(18, 1);
    instance.insert(test1);
    BOOST_REQUIRE_EQUAL ( 1, instance[1] );
    strat_map::iterator start = instance.begin();
    strat_map::iterator end = instance.end();
    BOOST_REQUIRE_EQUAL ( 1, start->first );
    BOOST_REQUIRE_EQUAL ( 1, start->second );
};

BOOST_AUTO_TEST_CASE ( strat_map_iterator_range ) {
    typedef boost::strategized_map<int, int, hash_function> strat_map;
    strat_map instance;
    instance [0] = 1;
    strat_map::iterator iterator = instance.find(0);
    BOOST_REQUIRE_EQUAL ( 0, iterator->first );
    BOOST_REQUIRE_EQUAL ( 1, iterator->second );
};

struct strat_with_instance {
    explicit strat_with_instance (int number)
        : internal_instance(number)
    {
    };

    int internal_instance;

    int operator() (int) const {
        return 0;
    };
};

BOOST_AUTO_TEST_CASE ( strat_map_internal_instance ) {
    boost::strategized_map<int, int, strat_with_instance> instance(1);
    BOOST_REQUIRE_EQUAL ( 1, instance.strategy().internal_instance );
};