// Copyright 2006 (C) Dean Michael Berris <dean@orangeandbronze.com>
// Distributed under the Boost Software License, Version 1.0. (See accompanying
// file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)

#ifndef __STRATEGIZED_MAP_HPP__
#define __STRATEGIZED_MAP_HPP__

#include <map>

namespace boost {

    namespace detail {
        template <typename InputType>
        struct default_route {
            InputType operator () (InputType const& input) const {
                return input;
            };
        };
    };

    ///////////////////////////////////////////////////////////////////////////
    // Strategized Map Implementation
    ///////////////////////////////////////////////////////////////////////////
    template <typename KeyType, 
        typename ValueType, 
        typename RoutingStrategy = detail::default_route<KeyType>
    >
    struct strategized_map {
    private :
        // Internal instance of a normal sorted map
        mutable std::map<KeyType, ValueType> _map;

        // Internal instance of the RoutingStrategy
        RoutingStrategy _strategy;

    public:
        // Typedef to the iterator types
        typedef typename std::map<KeyType, ValueType>::iterator iterator;
        typedef typename std::map<KeyType, ValueType>::const_iterator const_iterator;

        // Default Constructor
        strategized_map () {
        };

        // Constructor which takes arguments for the internal
        // routing strategy. Does type deduction and forwarding
        template <typename Arg1Type>
        explicit strategized_map (Arg1Type const & arg1)
            : _strategy(arg1) { };

        // Constructor Overloads.
        template <typename Arg1Type,
            typename Arg2Type
        >
        strategized_map (Arg1Type const & arg1,
            Arg2Type const & arg2)
            : _strategy(arg1, arg2) { };

        // TODO: add more constructor overloads
        // Use Boost.PP ?

        // Forwarding Index Operator which invokes
        // the Routing Strategy on the key.
        ValueType & operator[] (KeyType const & key) {
            return _map[_strategy(key)];
        };

        // Forwarding `insert' which invokes
        // the Routing Strategy on the key.
        // FIXME: how to get away from "copy" ?
        void insert (std::pair<KeyType, ValueType> element) const {
            element.first=_strategy(element.first);
            _map.insert(element);
        };

        // Forwarding `erase' which invokes
        // the Routing Strategy on the key.
        void erase (KeyType const & key) const {
            _map.erase(_strategy(key));
        };

        // Forwarding `begin' returns a copy
        // of the iterator.
        iterator begin() const {
            return _map.begin();
        };

        // Forwarding `end' returns a copy
        // of the iterator
        iterator end() const {
            return _map.end();
        };

        // Forwarding `find' returns a copy
        // of the iterator
        iterator find (KeyType const & key) const {
            return _map.find(_strategy(key));
        };

        // Forwarding `clear'
        void clear () const {
            _map.clear();
        };

        // Strategy instance reference
        RoutingStrategy & strategy () {
            return _strategy;
        };
        
    };

}; // namespace boost

#endif