// Copyright 2006 (C) Dean Michael Berris <dean@orangeandbronze.com>
// Distributed under the Boost Software License, Version 1.0. (See accompanying
// file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)

#ifndef __INVOKE_IMPL0_HPP_
#define __INVOKE_IMPL0_HPP_

#include <boost/function.hpp>
#include <boost/dispatch/detail/default_aggregator.hpp>

namespace boost {
    namespace dispatch {
        namespace detail {

            template <typename ReturnType, typename DispatcherType>
            struct invoke_impl_0 {
                typedef typename DispatcherType::index_type index_type;
                typedef boost::function<void ( typename DispatcherType::result_type )> aggregator_t;
                invoke_impl_0 (
                    DispatcherType & dispatcher, 
                    aggregator_t aggregator
                    ) 
                    : _dispatcher(dispatcher), _aggregator(aggregator)
                { };

                DispatcherType & _dispatcher;
                aggregator_t _aggregator;
            };

            template <typename DispatcherType>
            struct invoke_impl_0 <void, DispatcherType> {
                typedef typename DispatcherType::index_type index_type;
                typedef boost::function<void ( int )> aggregator_t;
                invoke_impl_0 (
                    DispatcherType & dispatcher, 
                    aggregator_t aggregator
                    ) 
                    : _dispatcher(dispatcher), _aggregator(aggregator)
                { };

                DispatcherType & _dispatcher;
                aggregator_t _aggregator;
            };

            template <typename ReturnType, typename DispatcherType>
            invoke_impl_0<ReturnType, DispatcherType> & operator << 
                (
                invoke_impl_0<ReturnType, DispatcherType> & invoker, 
                const typename DispatcherType::index_type & index
                ) 
            {
                invoker._aggregator(
                    (invoker._dispatcher[index]())
                    );
                return invoker;
            };

            template <typename DispatcherType>
            invoke_impl_0<void, DispatcherType> & operator <<
                (
                invoke_impl_0<void, DispatcherType> & invoker,
                const typename DispatcherType::index_type & index
                )
            {
                invoker._dispatcher[index]();
                return invoker;
            };

        };
    };
};

#endif
