// Copyright 2006 (C) Dean Michael Berris <dean@orangeandbronze.com>
// Distributed under the Boost Software License, Version 1.0. (See accompanying
// file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)

#ifndef __DETAIL_DISPATCH_DEFAULT_ROUTING__
#define __DETAIL_DISPATCH_DEFAULT_ROUTING__

namespace boost {
    namespace dispatch {
        namespace detail {

            template < typename IndexType >
            struct default_routing {
                IndexType operator() (const IndexType & index) const {
                    return index;
                };
            };

        };
    };
};

#endif
