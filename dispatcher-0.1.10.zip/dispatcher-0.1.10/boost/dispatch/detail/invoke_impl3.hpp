// Copyright 2006 (C) Dean Michael Berris <dean@orangeandbronze.com>
// Distributed under the Boost Software License, Version 1.0. (See accompanying
// file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)

#ifndef __INVOKE_IMPL3_HPP_
#define __INVOKE_IMPL3_HPP_

#include <boost/function.hpp>

namespace boost {
    namespace dispatch {
        namespace detail {

            template <typename ReturnType, typename DispatcherType,
                typename arg1_type,
                typename arg2_type,
                typename arg3_type
            >
            struct invoke_impl_3_callable {
                typedef boost::function< void (typename DispatcherType::result_type) > aggregator_t;

                DispatcherType & _dispatcher;
                const aggregator_t _aggregator;
                const arg1_type & _arg1;
                const arg2_type & _arg2;
                const arg3_type & _arg3;

                invoke_impl_3_callable (
                    DispatcherType & dispatcher,
                    const aggregator_t & aggregator,
                    const arg1_type & arg1,
                    const arg2_type & arg2,
                    const arg3_type & arg3)
                    : _dispatcher(dispatcher),
                    _aggregator(aggregator),
                    _arg1(arg1),
                    _arg2(arg2),
                    _arg3(arg3)
                { /*...*/ };

            };

            template <typename DispatcherType,
                typename arg1_type,
                typename arg2_type,
                typename arg3_type
            >
            struct invoke_impl_3_callable <
                void,
                DispatcherType,
                arg1_type,
                arg2_type,
                arg3_type
            >
            {
                typedef boost::function< void ( int ) > aggregator_t;

                DispatcherType & _dispatcher;
                const aggregator_t _aggregator;
                const arg1_type & _arg1;
                const arg2_type & _arg2;
                const arg3_type & _arg3;

                invoke_impl_3_callable (
                    DispatcherType & dispatcher,
                    const aggregator_t & aggregator,
                    const arg1_type & arg1,
                    const arg2_type & arg2,
                    const arg3_type & arg3)
                    : _dispatcher(dispatcher),
                    _aggregator(aggregator),
                    _arg1(arg1),
                    _arg2(arg2),
                    _arg3(arg3)
                { /*...*/ };

            };

            template <typename ReturnType, typename DispatcherType,
                typename arg1_type,
                typename arg2_type,
                typename arg3_type
            >
            struct invoke_impl_3 {
                typedef typename DispatcherType::index_type index_type;
                typedef boost::function< void (typename DispatcherType::result_type) > aggregator_t;

                aggregator_t _aggregator;
                DispatcherType & _dispatcher;
                const arg1_type * _arg1;
                const arg2_type * _arg2;
                const arg3_type * _arg3;

                invoke_impl_3 (
                    DispatcherType & dispatcher,
                    aggregator_t aggregator
                    ) : _dispatcher(dispatcher), _aggregator(aggregator)
                { } ;

                invoke_impl_3_callable<ReturnType, DispatcherType, 
                    arg1_type, 
                    arg2_type,
                    arg3_type
                > operator()
                    (const arg1_type & arg1, 
                    const arg2_type & arg2,
                    const arg3_type & arg3) {
                        return 
                            invoke_impl_3_callable<ReturnType, DispatcherType, 
                            arg1_type, 
                            arg2_type,
                            arg3_type
                            > (_dispatcher, _aggregator,
                            arg1,
                            arg2,
                            arg3
                            )
                            ;
                };
            };

            template <typename DispatcherType,
                typename arg1_type,
                typename arg2_type,
                typename arg3_type
            >
            struct invoke_impl_3<void, DispatcherType, 
                arg1_type, 
                arg2_type,
                arg3_type
            > {
                typedef typename DispatcherType::index_type index_type;
                typedef boost::function<void (int)> aggregator_t;

                aggregator_t _aggregator;
                DispatcherType & _dispatcher;
                const arg1_type * _arg1;
                const arg2_type * _arg2;
                const arg3_type * _arg3;

                invoke_impl_3 (
                    DispatcherType & dispatcher,
                    aggregator_t aggregator
                    ) : _dispatcher(dispatcher), _aggregator(default_aggregator<void>())
                { } ;

                invoke_impl_3_callable<void, DispatcherType, 
                    arg1_type, 
                    arg2_type,
                    arg3_type
                > operator()
                    (const arg1_type & arg1, 
                    const arg2_type & arg2,
                    const arg3_type & arg3) {
                        return 
                            invoke_impl_3_callable<void, DispatcherType, 
                            arg1_type, 
                            arg2_type,
                            arg3_type
                            > (_dispatcher, _aggregator,
                            arg1,
                            arg2,
                            arg3
                            )
                            ;
                };
            };

            template <typename ReturnType, typename DispatcherType, 
                typename arg1_type,
                typename arg2_type,
                typename arg3_type
            >
            inline invoke_impl_3_callable <ReturnType, DispatcherType, 
                arg1_type, 
                arg2_type,
                arg3_type
            > const & operator<<
                ( const invoke_impl_3_callable<ReturnType, DispatcherType, 
                    arg1_type,
                    arg2_type,
                    arg3_type
                  > & invoker,
                  const typename DispatcherType::index_type & index 
                ) {
                    invoker._aggregator(
                        invoker._dispatcher[index](
                            invoker._arg1,
                            invoker._arg2,
                            invoker._arg3
                         )
                    );
                    return invoker;
            };

            template <typename DispatcherType,
                typename arg1_type,
                typename arg2_type,
                typename arg3_type
            >
            inline invoke_impl_3_callable <void, DispatcherType, 
                arg1_type,
                arg2_type,
                arg3_type
            > const & operator<< 
                ( const invoke_impl_3_callable <void, DispatcherType, 
                    arg1_type,
                    arg2_type,
                    arg3_type
                  > & invoker,
                  const typename DispatcherType::index_type & index ) {
                    invoker._dispatcher[index](
                        invoker._arg1,
                        invoker._arg2,
                        invoker._arg3
                    );
                    return invoker;
            };

        }; // namespace detail
    }; // namespace dispatch
}; // namespace boost

#endif
