#include <vector>
#include <deque>
#include <list>
#include <iterator>
#include <algorithm>
#include <iostream>
#include <boost/iterator/counting_iterator.hpp>
#include "abstract_iterator.hpp"


int main(int, char*[])
{
    typedef boost::abstract_iterator< const int, std::bidirectional_iterator_tag > iterator_t;

    std::vector< int > v;
    std::copy(
        boost::counting_iterator< int >(1),
        boost::counting_iterator< int >(11),
        std::back_inserter(v));

    iterator_t b = v.begin(), e = v.end();
    std::copy(b, e, std::ostream_iterator< int >(std::cout, ", "));
    std::cout << std::endl;

    std::deque< int > d;
    std::copy(
        boost::counting_iterator< int >(11),
        boost::counting_iterator< int >(21),
        std::back_inserter(d));

    b = d.begin();
    e = d.end();
    std::copy(b, e, std::ostream_iterator< int >(std::cout, ", "));
    std::cout << std::endl;

    std::list< int > l;
    std::copy(
        boost::counting_iterator< int >(21),
        boost::counting_iterator< int >(31),
        std::back_inserter(l));

    b = l.begin();
    e = l.end();
    std::copy(b, e, std::ostream_iterator< int >(std::cout, ", "));
    std::cout << std::endl;

    typedef boost::abstract_iterator< const int, std::forward_iterator_tag > fwd_iterator_t;
    fwd_iterator_t b1 = b, e1 = e;
    std::copy(b, e, std::ostream_iterator< int >(std::cout, ", "));
    std::cout << std::endl;

    return 0;
}
