/*!
 * (C) 2010 Andrey Semashev
 *
 * Use, modification and distribution is subject to the Boost Software License, Version 1.0.
 * (See accompanying file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
 *
 * \file   abstract_iterator.hpp
 * \author Andrey Semashev
 * \date   08.02.2010
 *
 * \brief  This header implements an abstract iterator
 */

#if (defined(_MSC_VER) && _MSC_VER > 1000)
#pragma once
#endif // _MSC_VER > 1000

#ifndef BOOST_ABSTRACT_ITERATOR_HPP_INCLUDED_
#define BOOST_ABSTRACT_ITERATOR_HPP_INCLUDED_

#include <cstddef>
#include <new>
#include <string>
#include <iterator>
#include <stdexcept>
#include <boost/throw_exception.hpp>
#include <boost/aligned_storage.hpp>
#include <boost/iterator/iterator_facade.hpp>
#include <boost/iterator/iterator_categories.hpp>
#include <boost/type_traits/is_base_of.hpp>
#include <boost/utility/enable_if.hpp>

#ifndef BOOST_ABSTRACT_ITERATOR_STATIC_BUFFER_SIZE
#define BOOST_ABSTRACT_ITERATOR_STATIC_BUFFER_SIZE sizeof(void*)
#endif // BOOST_ABSTRACT_ITERATOR_STATIC_BUFFER_SIZE

namespace boost {

//! An exception that is being thrown in case of access to an empty iterator
class bad_iterator :
    public std::runtime_error
{
public:
    bad_iterator() : std::runtime_error("invalid access to an empty abstract iterator") {}
    bad_iterator(std::string const& op) :
        std::runtime_error("invalid access to an empty abstract iterator: " + op) {}
};

namespace aux {

    //! Root interface for the abstract iterator implementation
    struct impl_base
    {
        virtual ~impl_base() {}
        virtual void copy_to(void* where) const = 0;
        virtual bool is_empty() const { return false; }
        virtual bool is_equal(impl_base const* that) const = 0;
    };

    /*!
     * \brief The trait defines the implementation interface for the abstract iterator
     *
     * This specialization defines interface for iterators with forward traversal
     */
    template<
        typename ValueT,
        typename TraversalT,
        typename ReferenceT,
        typename DifferenceT
    >
    struct traversal_category_types
    {
        //! Base interface for the implementation
        struct impl_base : aux::impl_base
        {
            virtual ReferenceT dereference() const = 0;
            virtual void increment() = 0;
        };
    };

    //! This specialization defines interface for iterators with bidirectional traversal
    template<
        typename ValueT,
        typename ReferenceT,
        typename DifferenceT
    >
    struct traversal_category_types< ValueT, bidirectional_traversal_tag, ReferenceT, DifferenceT > :
        public traversal_category_types<
            ValueT,
            forward_traversal_tag,
            ReferenceT,
            DifferenceT
        >
    {
        typedef traversal_category_types<
            ValueT,
            forward_traversal_tag,
            ReferenceT,
            DifferenceT
        > base_type;

        //! Base interface for the implementation
        struct impl_base : base_type::impl_base
        {
            virtual void decrement() = 0;
        };
    };

    //! This specialization defines interface for iterators with random access capability
    template<
        typename ValueT,
        typename ReferenceT,
        typename DifferenceT
    >
    struct traversal_category_types< ValueT, random_access_traversal_tag, ReferenceT, DifferenceT > :
        public traversal_category_types<
            ValueT,
            bidirectional_traversal_tag,
            ReferenceT,
            DifferenceT
        >
    {
        typedef traversal_category_types<
            ValueT,
            bidirectional_traversal_tag,
            ReferenceT,
            DifferenceT
        > base_type;

        //! Base interface for the implementation
        struct impl_base : base_type::impl_base
        {
            virtual DifferenceT distance_to(aux::impl_base* that) const = 0;
            virtual void advance(DifferenceT offset) = 0;
        };
    };

    //! A helper trait that defines implementation types for various categories of iterators
    template<
        typename ValueT,
        typename TraversalT,
        typename ReferenceT,
        typename DifferenceT
    >
    struct abstract_iterator_types :
        public traversal_category_types< ValueT, TraversalT, ReferenceT, DifferenceT >
    {
        typedef traversal_category_types< ValueT, TraversalT, ReferenceT, DifferenceT > base_type;

        //! Implementation of an empty iterator
        class empty_impl :
            public base_type::impl_base
        {
        public:
            void copy_to(void* where) const
            {
                new (where) empty_impl(*this);
            }
            bool is_empty() const { return true; }
            bool is_equal(aux::impl_base const* that) const
            {
                return (dynamic_cast< empty_impl const* >(that) != 0);
            }
            DifferenceT distance_to(aux::impl_base* that) const
            {
                BOOST_THROW_EXCEPTION(bad_iterator("attempt to calculate distance"));
            }
            void increment()
            {
                BOOST_THROW_EXCEPTION(bad_iterator("increment attempt"));
            }
            void decrement()
            {
                BOOST_THROW_EXCEPTION(bad_iterator("decrement attempt"));
            }
            void advance(DifferenceT offset)
            {
                BOOST_THROW_EXCEPTION(bad_iterator("advance attempt"));
            }
            ReferenceT dereference() const
            {
                BOOST_THROW_EXCEPTION(bad_iterator("dereference attempt"));
            }
        };

        //! Implementation that fits into the static buffer
        template< typename IteratorT >
        class in_place_impl :
            public base_type::impl_base
        {
            IteratorT m_Iterator;

        public:
            explicit in_place_impl(IteratorT const& it) : m_Iterator(it) {}
            void copy_to(void* where) const
            {
                new (where) in_place_impl< IteratorT >(*this);
            }
            bool is_equal(aux::impl_base const* that) const
            {
                in_place_impl const* p = dynamic_cast< in_place_impl const* >(that);
                if (p)
                    return (m_Iterator == p->m_Iterator);
                else
                    return false;
            }
            DifferenceT distance_to(aux::impl_base* that) const
            {
                in_place_impl* p = dynamic_cast< in_place_impl* >(that);
                if (p)
                {
                    return std::distance(m_Iterator, p->m_Iterator);
                }
                else
                {
                    BOOST_THROW_EXCEPTION(bad_iterator("attempt to calculate distance between unrelated iterators"));
                }
            }
            void increment()
            {
                ++m_Iterator;
            }
            void decrement()
            {
                --m_Iterator;
            }
            void advance(DifferenceT offset)
            {
                m_Iterator += offset;
            }
            ReferenceT dereference() const
            {
                return *m_Iterator;
            }

        private:
            in_place_impl(in_place_impl const& that) : m_Iterator(that.m_Iterator) {}
        };

        //! Implementation that does not fit into the static buffer
        template< typename IteratorT >
        class dynamic_impl :
            public base_type::impl_base
        {
            IteratorT* m_pIterator;

        public:
            explicit dynamic_impl(IteratorT const& it) : m_pIterator(new IteratorT(it)) {}
            ~dynamic_impl()
            {
                delete m_pIterator;
            }
            void copy_to(void* where) const
            {
                new (where) dynamic_impl< IteratorT >(*this);
            }
            bool is_equal(aux::impl_base const* that) const
            {
                dynamic_impl const* p = dynamic_cast< dynamic_impl const* >(that);
                if (p)
                    return (*m_pIterator == *(p->m_pIterator));
                else
                    return false;
            }
            DifferenceT distance_to(aux::impl_base* that) const
            {
                dynamic_impl* p = dynamic_cast< dynamic_impl* >(that);
                if (p)
                {
                    return std::distance(*m_pIterator, *(p->m_pIterator));
                }
                else
                {
                    BOOST_THROW_EXCEPTION(bad_iterator("attempt to calculate distance between unrelated iterators"));
                }
            }
            void increment()
            {
                ++(*m_pIterator);
            }
            void decrement()
            {
                --(*m_pIterator);
            }
            void advance(DifferenceT offset)
            {
                *m_pIterator += offset;
            }
            ReferenceT dereference() const
            {
                return **m_pIterator;
            }

        private:
            dynamic_impl(dynamic_impl const& that) : m_pIterator(new IteratorT(*that.m_pIterator)) {}
        };
    };

} // namespace aux

//! An iterator that is capable to adopt any other iterator of the compatible type
template<
    typename ValueT,
    typename CategoryT,
    typename ReferenceT = ValueT&,
    typename DifferenceT = std::ptrdiff_t
>
class abstract_iterator :
    public iterator_facade<
        abstract_iterator< ValueT, CategoryT, ReferenceT, DifferenceT >,
        ValueT,
        CategoryT,
        ReferenceT,
        DifferenceT
    >
{
    template<
        typename ValueT,
        typename CategoryT,
        typename ReferenceT,
        typename DifferenceT
    >
    friend class abstract_iterator;
    friend class iterator_core_access;
    typedef typename abstract_iterator::iterator_facade_ iterator_facade_;
    typedef aux::abstract_iterator_types<
        ValueT,
        typename iterator_category_to_traversal< CategoryT >::type,
        ReferenceT,
        DifferenceT
    > types;

    //! The base interface for the iterator
    typedef typename types::impl_base impl_base;
    //! The empty implementation for the iterator
    typedef typename types::empty_impl empty_impl;

    //! The internal storage type
    typedef typename aligned_storage<
        sizeof(impl_base) + BOOST_ABSTRACT_ITERATOR_STATIC_BUFFER_SIZE
    >::type storage_type;

private:
    //! The storage for the contained iterator or a pointer to it
    storage_type m_Storage;

public:
    /*!
     * \brief Default constructor
     * \post <tt>empty() == true</tt>
     */
    abstract_iterator()
    {
        new (m_Storage.address()) empty_impl();
    }
    //! Copy constructor
    abstract_iterator(abstract_iterator const& that)
    {
        that.get_impl()->copy_to(m_Storage.address());
    }
    /*!
     * \brief Self-adoption constructor
     *
     * Allows to adopt abstract iterators with different categories, as long as
     * the adopting iterators is of a more restricting category.
     */
    template< typename ThatCategoryT >
    abstract_iterator(
        abstract_iterator< ValueT, ThatCategoryT, ReferenceT, DifferenceT > const& that,
        typename enable_if<
            is_base_of<
                impl_base,
                typename abstract_iterator< ValueT, ThatCategoryT, ReferenceT, DifferenceT >::impl_base
            >,
            int
        >::type = 0)
    {
        that.get_impl()->copy_to(m_Storage.address());
    }
    //! Adoption constructor
    template< typename IteratorT >
    abstract_iterator(IteratorT const& it)
    {
        typedef typename types::template in_place_impl< IteratorT > in_place_impl;
        if (sizeof(in_place_impl) <= sizeof(m_Storage))
        {
            new (m_Storage.address()) in_place_impl(it);
        }
        else
        {
            typedef typename types::template dynamic_impl< IteratorT > dynamic_impl;
            new (m_Storage.address()) dynamic_impl(it);
        }
    }
    //! Destructor
    ~abstract_iterator()
    {
        get_impl()->~impl_base();
    }

    /*!
     * \brief Assignment
     * \note Provides basic guarantee. If assignment fails, the iterator is in the empty state.
     */
    abstract_iterator& operator= (abstract_iterator that)
    {
        get_impl()->~impl_base();
        try
        {
            that.get_impl()->copy_to(m_Storage.address());
        }
        catch (...)
        {
            new (m_Storage.address()) empty_impl();
            throw;
        }

        return *this;
    }

    //! Checks if the iterator is in the empty state
    bool empty() const
    {
        return get_impl()->is_empty();
    }

private:
    //! Returns the pointer to the iterator implementation
    impl_base* get_impl() { return static_cast< impl_base* >(m_Storage.address()); }
    //! Returns the pointer to the iterator implementation
    impl_base const* get_impl() const { return static_cast< impl_base const* >(m_Storage.address()); }

    //! Checks if the iterator is equal to another iterator
    bool equal(abstract_iterator const& that) const
    {
        return get_impl()->is_equal(that.get_impl());
    }
    //! Increments the iterator
    void increment()
    {
        get_impl()->increment();
    }
    //! Decrements the iterator
    void decrement()
    {
        get_impl()->decrement();
    }
    //! Advances the iterator to the specified distance
    void advance(DifferenceT offset)
    {
        get_impl()->advance(offset);
    }
    //! Calculates distance to the other iterator
    DifferenceT distance_to(abstract_iterator const& that) const
    {
        return get_impl()->distance_to(that.get_impl());
    }
    //! Dereferences the iterator
    ReferenceT dereference() const
    {
        return get_impl()->dereference();
    }
};

} // namespace boost

#endif // BOOST_ABSTRACT_ITERATOR_HPP_INCLUDED_
