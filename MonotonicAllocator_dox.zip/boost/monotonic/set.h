// (C) 2009 Christian Schladetsch

#pragma once

#include <set>
#include <boost/monotonic/allocator.h>

namespace boost
{
	namespace monotonic
	{
		/// A std::set<T,P> that uses a monotonic allocator
		template <class T, class P = std::less<T> >
		struct set : std::set<T,P, allocator<T> >
		{
			typedef allocator<T> Allocator;
			typedef P Predicate;
			typedef std::set<T,P,allocator<T> > Set;

			set() 
			{ 
			}
			set(storage_base &S) 
				: Set(Predicate(), Allocator(S)) 
			{ 
			}
			set(Allocator const &A) 
				: Set(Predicate(), A) 
			{ 
			}	
			set(Predicate P, Allocator const &A) 
				: Set(P, A) 
			{
			}
		};
	}
}

//EOF
