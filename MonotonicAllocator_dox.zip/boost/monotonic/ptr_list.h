// (C) 2009 Christian Schladetsch

#pragma once

#include <boost/ptr_container/ptr_list.hpp>
#include <boost/monotonic/allocator.h>
#include <boost/monotonic/inline_clone_allocator.h>

namespace boost
{
	namespace monotonic
	{
		/// A boost::ptr_list<T> that uses a monotonic allocator, and a custom clone allocator
		template <class T>
		struct ptr_list : boost::ptr_list<T, inline_clone_allocator, allocator<T> >
		{
			typedef allocator<T> Allocator;
			typedef boost::ptr_list<T, inline_clone_allocator, Allocator> List;

			ptr_list() 
			{ 
			}
			ptr_list(storage_base &storage) 
				: List(Allocator(storage)) 
			{ 
			}
			ptr_list(Allocator const &A) 
				: List(A) 
			{ 
			}	
		};

	}
}

//EOF
