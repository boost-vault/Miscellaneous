#pragma once

#include <map>
#include <boost/monotonic/allocator.h>

namespace boost
{
	namespace monotonic
	{
		/// A std::map<K,T,P> that uses a monotonic allocator
		template <class K, class T, class P = std::less<K> >
		struct map : std::map<K,T,P, allocator<K> >
		{
			typedef allocator<K> Allocator;
			typedef std::map<K,T,P,Allocator > Map;
			typedef P Predicate;

			map() 
			{ 
			}
			map(storage_base &S) 
				: Map(Predicate(), Allocator(S)) 
			{ 
			}
			map(Allocator const &A) 
				: Map(Predicate(), A) 
			{ 
			}	
			map(Predicate P, Allocator const &A) 
				: Map(P, A) 
			{
			}
		};
	}
}

//EOF
