// (C) 2009 Christian Schladetsch

#pragma once

#include <cassert>
#include <boost/array.hpp>

namespace boost
{
	namespace monotonic
	{
		/// storage for an allocator that is on the stack or heap
		template <size_t N>
		struct inline_storage : storage_base
		{
		private:
			boost::array<char, N> buffer;	///< the storage
			size_t cursor;					///< pointer to current index within storage for next allocation

		public:
			inline_storage() : cursor(0)
			{
			}

			void reset()
			{
				cursor = 0;
			}

			size_t get_cursor() const
			{
				return cursor;
			}

			void set_cursor(size_t c)
			{
				cursor = c;
			}

			/// allocate storage. ignore hint.
			void *allocate(size_t num_bytes, void const * = 0)
			{
				assert(cursor + num_bytes <= N);
				if (cursor + num_bytes > N)
				{
					return 0;
				}
				void *ptr = &buffer[cursor];
				cursor += num_bytes;
				return ptr;
			}

			/// no work is done to deallocate storage
			void deallocate(void * /*p*/, size_t /*n*/)
			{
			}

			/// the maximum size is determined at compile-time
			size_t max_size() const
			{
				return N;
			}

			size_t remaining() const
			{
				return N - cursor;
			}
		};
	}
}

//EOF
