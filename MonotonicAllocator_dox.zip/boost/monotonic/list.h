#pragma once

#include <list>
#include <boost/monotonic/allocator.h>

namespace boost
{
	namespace monotonic
	{
		/// A std::list<T> that uses a monotonic allocator
		template <class T>
		struct list : std::list<T, allocator<T> >
		{
			typedef allocator<T> Allocator;
			typedef std::list<T, Allocator> List;

			list() { }
			list(storage_base &storage) 
				: List(Allocator(storage)) { }
			list(Allocator const &A) 
				: List(A) { }	
		};
	}
}

//EOF
