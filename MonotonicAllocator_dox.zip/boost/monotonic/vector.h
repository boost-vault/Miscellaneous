// (C) 2009 Christian Schladetsch

#pragma once

#include <vector>
#include <boost/monotonic/allocator.h>
#include <boost/monotonic/storage_base.h>

namespace boost
{
	namespace monotonic
	{
		/// a std::vector<T> that uses a monotonic allocator
		template <class T>
		struct vector : std::vector<T, allocator<T> >
		{
			typedef allocator<T> Allocator;
			typedef std::vector<T,Allocator> Vector;

			vector() 
			{ 
			}
			vector(storage_base &storage) 
				: Vector(Allocator(storage)) 
			{ 
			}
			vector(Allocator const &A) 
				: Vector(A) 
			{ 
			}	
		};
	}
}

//EOF
