// (C) 2009 Christian Schladetsch

#include <assert.h>
#include <stdlib.h>
#include <string.h>

#include <boost/monotonic/vector.h>
#include <boost/monotonic/list.h>
#include <boost/monotonic/map.h>
#include <boost/monotonic/set.h>

int main()
{
	// create the storage that will be used for the various monotonic containers.
	// while it is on the stack here, it could be on the heap as well.
	boost::monotonic::inline_storage<1000> storage;

	// create a list that uses inline, monotonically-increasing storage
	boost::monotonic::list<int> list(storage);
	list.push_back(100);
	list.push_back(400);
	list.erase(list.begin());

	// a map from the same storage
	boost::monotonic::map<int, float> map(storage);
	map[42] = 3.14f;

	// a set...
	boost::monotonic::set<float> set(storage);
	set.insert(3.14f);
	set.insert(-123.f);

}

//EOF
