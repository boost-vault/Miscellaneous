/*********************************************************************************
 * Copyright 2005-2007 Adobe Systems Incorporated                                *
 * Copyright 2008 Daniel Pfeifer                                                 *
 *                                                                               *
 * Use, modification and distribution are subject to the Boost Software License, *
 * Version 1.0. (See accompanying file LICENSE_1_0.txt or copy at                *
 * http://www.boost.org/LICENSE_1_0.txt).                                        *
 *********************************************************************************/

#ifndef GIL_IO_ERROR_HPP
#define GIL_IO_ERROR_HPP

/// \file
/// \brief  Handle input-output errors
/// \author Lubomir Bourdev and Hailin Jin \n
///         Adobe Systems Incorporated
/// \author Daniel Pfeifer
/// \since  August 10, 2008 \n
///         read from/write to std streams

#include <ios>

namespace boost
{
namespace gil
{

inline void io_error(const char* descr)
{
   throw std::ios_base::failure(descr);
}

inline void io_error_if(bool expr, const char* descr = "")
{
   if (expr)
      io_error(descr);
}

inline void io_error_if_fail(std::ios& ios)
{
   if (ios.fail())
      io_error("failed to open file");
}

} // namespace gil
} // namespace boost

#endif
