/*********************************************************************************
 * Copyright 2005-2007 Adobe Systems Incorporated                                *
 * Copyright 2008 Daniel Pfeifer                                                 *
 *                                                                               *
 * Use, modification and distribution are subject to the Boost Software License, *
 * Version 1.0. (See accompanying file LICENSE_1_0.txt or copy at                *
 * http://www.boost.org/LICENSE_1_0.txt).                                        *
 *********************************************************************************/

#ifndef GIL_JPEG_IO_PRIVATE_HPP
#define GIL_JPEG_IO_PRIVATE_HPP

/// \file
/// \brief  Internal support for reading and writing JPEG files
/// \author Hailin Jin and Lubomir Bourdev \n
///         Adobe Systems Incorporated
/// \author Daniel Pfeifer
/// \since  August 10, 2008 \n
///         read from/write to std streams

#include <stdio.h>
#include <boost/static_assert.hpp>
#include <vector>
#include <boost/gil/gil_all.hpp>
#include "io_error.hpp"

namespace boost
{
namespace gil
{

namespace detail
{

// lbourdev: What is the advantage of having channel and colorspace together? Are there cases where they are interrelated?

template<typename Channel, typename ColorSpace>
struct jpeg_read_support_private
{
   BOOST_STATIC_CONSTANT(bool,is_supported=false);
   BOOST_STATIC_CONSTANT(J_COLOR_SPACE,color_type=JCS_UNKNOWN);
};
template<>
struct jpeg_read_support_private<bits8, gray_t>
{
   BOOST_STATIC_ASSERT(BITS_IN_JSAMPLE==8);
   BOOST_STATIC_CONSTANT(bool,is_supported=true);
   BOOST_STATIC_CONSTANT(J_COLOR_SPACE,color_type=JCS_GRAYSCALE);
};
template<>
struct jpeg_read_support_private<bits8, rgb_t>
{
   BOOST_STATIC_ASSERT(BITS_IN_JSAMPLE==8);
   BOOST_STATIC_CONSTANT(bool,is_supported=true);
   BOOST_STATIC_CONSTANT(J_COLOR_SPACE,color_type=JCS_RGB);
};
template<>
struct jpeg_read_support_private<bits8, cmyk_t>
{
   BOOST_STATIC_ASSERT(BITS_IN_JSAMPLE==8);
   BOOST_STATIC_CONSTANT(bool,is_supported=true);
   BOOST_STATIC_CONSTANT(J_COLOR_SPACE,color_type=JCS_CMYK);
};
template<typename Channel, typename ColorSpace>
struct jpeg_write_support_private
{
   BOOST_STATIC_CONSTANT(bool,is_supported=false);
   BOOST_STATIC_CONSTANT(J_COLOR_SPACE,color_type=JCS_UNKNOWN);
};
template<>
struct jpeg_write_support_private<bits8, gray_t>
{
   BOOST_STATIC_ASSERT(BITS_IN_JSAMPLE==8);
   BOOST_STATIC_CONSTANT(bool,is_supported=true);
   BOOST_STATIC_CONSTANT(J_COLOR_SPACE,color_type=JCS_GRAYSCALE);
};
template<>
struct jpeg_write_support_private<bits8, rgb_t>
{
   BOOST_STATIC_ASSERT(BITS_IN_JSAMPLE==8);
   BOOST_STATIC_CONSTANT(bool,is_supported=true);
   BOOST_STATIC_CONSTANT(J_COLOR_SPACE,color_type=JCS_RGB);
};
template<>
struct jpeg_write_support_private<bits8, cmyk_t>
{
   BOOST_STATIC_ASSERT(BITS_IN_JSAMPLE==8);
   BOOST_STATIC_CONSTANT(bool,is_supported=true);
   BOOST_STATIC_CONSTANT(J_COLOR_SPACE,color_type=JCS_CMYK);
};

class jpeg_reader: protected jpeg_source_mgr
{
protected:
   std::istream& _istream;
   jpeg_decompress_struct _cinfo;
   jpeg_error_mgr _jerr;
   char _buffer[1024];

   static void init_source_fn(j_decompress_ptr cinfo)
   {
      jpeg_reader* this_ = static_cast<jpeg_reader*> (cinfo->src);
      this_->next_input_byte = (JOCTET*) this_->_buffer;
      this_->bytes_in_buffer = 0;
   }

   static boolean fill_input_buffer_fn(j_decompress_ptr cinfo)
   {
      jpeg_reader* this_ = static_cast<jpeg_reader*> (cinfo->src);
      this_->next_input_byte = (JOCTET*) this_->_buffer;
      this_->bytes_in_buffer = this_->_istream.readsome(this_->_buffer, 1024);
      return (this_->bytes_in_buffer > 0);
   }

   static void skip_input_data_fn(j_decompress_ptr cinfo, long num_bytes)
   {
      jpeg_reader* this_ = static_cast<jpeg_reader*> (cinfo->src);
      if (num_bytes > 0)
      {
         if ((size_t) num_bytes > this_->bytes_in_buffer)
         {
            num_bytes -= this_->bytes_in_buffer;
            this_->bytes_in_buffer = 0;
            this_->_istream.ignore(num_bytes);
         }
         else
         {
            this_->bytes_in_buffer -= num_bytes;
         }
      }
   }

   static void term_source_fn(j_decompress_ptr)
   {
   }

   //    void init() {
   //        _cinfo.err=jpeg_std_error(&_jerr);
   //        jpeg_create_decompress(&_cinfo);
   //    	init_source = init_source_fn;
   //    	fill_input_buffer = fill_input_buffer_fn;
   //    	skip_input_data = skip_input_data_fn;
   //    	resync_to_restart = jpeg_resync_to_restart; /* use default function */
   //    	term_source = term_source_fn;
   //        _cinfo.src = this;
   //        jpeg_read_header(&_cinfo, TRUE);
   //    }

public:
   jpeg_reader(std::istream& istream) :
      _istream(istream)
   {
      _cinfo.err = jpeg_std_error(&_jerr);
      jpeg_create_decompress(&_cinfo);
      init_source = init_source_fn;
      fill_input_buffer = fill_input_buffer_fn;
      skip_input_data = skip_input_data_fn;
      resync_to_restart = jpeg_resync_to_restart; /* use default function */
      term_source = term_source_fn;
      _cinfo.src = this;
      jpeg_read_header(&_cinfo, TRUE);
   }

   ~jpeg_reader()
   {
      jpeg_destroy_decompress(&_cinfo);
   }

   template<typename View>
   void apply(const View& view)
   {
      jpeg_start_decompress(&_cinfo); // lbourdev: Can this return an error? You need to check and throw. Check all other library methods that can return an error state...
      io_error_if(_cinfo.data_precision != 8,
            "jpeg_reader::apply(): this image file is not supported");
      io_error_if(_cinfo.out_color_space != jpeg_read_support_private<
            typename channel_type<View>::type,
            typename color_space_type<View>::type>::color_type,
            "jpeg_reader::apply(): input view type does not match the image file");
      io_error_if(view.dimensions() != get_dimensions(),
            "jpeg_reader::apply(): input view dimensions do not match the image file");
      std::vector<pixel<bits8,layout<typename color_space_type<View>::type> > >
            row(view.width());
      JSAMPLE* row_address = (JSAMPLE*) &row.front();
      for (int y = 0; y < view.height(); ++y)
      {
         io_error_if(
               jpeg_read_scanlines(&_cinfo, (JSAMPARRAY) & row_address, 1) != 1,
               "jpeg_reader::apply(): fail to read JPEG file");
         std::copy(row.begin(), row.end(), view.row_begin(y));
      }
      jpeg_finish_decompress(&_cinfo);
   }

   template<typename Image>
   void read_image(Image& im)
   {
      im.recreate(get_dimensions());
      apply( view(im));
   }

   point2<std::ptrdiff_t> get_dimensions() const
   {
      return point2<std::ptrdiff_t> (_cinfo.image_width, _cinfo.image_height);
   }
};

// This code will be simplified...
template<typename CC>
class jpeg_reader_color_convert: public jpeg_reader
{
private:
   CC _cc;
public:
   jpeg_reader_color_convert(std::istream& istream) :
      jpeg_reader(istream)
   {
   }
   jpeg_reader_color_convert(std::istream& istream, CC cc_in) :
      jpeg_reader(istream), _cc(cc_in)
   {
   }

   template<typename View>
   void apply(const View& view)
   {
      jpeg_start_decompress(&_cinfo); // lbourdev: Can this return an error? You need to check and throw. Check all other library methods that can return an error state...
      io_error_if(_cinfo.data_precision != 8,
            "jpeg_reader_color_covert::apply(): this image file is not supported");
      io_error_if(view.dimensions() != get_dimensions(),
            "jpeg_reader_color_covert::apply(): "
               "input view dimensions don't match the image file");
      switch (_cinfo.out_color_space)
      {
      case JCS_GRAYSCALE:
      {
         std::vector<gray8_pixel_t> row(view.width());
         JSAMPLE* row_address = (JSAMPLE*) &row.front();
         for (int y = 0; y < view.height(); ++y)
         {
            io_error_if(jpeg_read_scanlines(&_cinfo,
                  (JSAMPARRAY) & row_address, 1) != 1,
                  "jpeg_reader_color_covert::apply(): fail to read JPEG file");
            std::transform(row.begin(), row.end(), view.row_begin(y),
                  color_convert_deref_fn<gray8_ref_t,
                        typename View::value_type, CC> (_cc));
         }
         break;
      }
      case JCS_RGB:
      {
         std::vector<rgb8_pixel_t> row(view.width());
         JSAMPLE* row_address = (JSAMPLE*) &row.front();
         for (int y = 0; y < view.height(); ++y)
         {
            io_error_if(jpeg_read_scanlines(&_cinfo,
                  (JSAMPARRAY) & row_address, 1) != 1,
                  "jpeg_reader_color_covert::apply(): fail to read JPEG file");
            std::transform(row.begin(), row.end(), view.row_begin(y),
                  color_convert_deref_fn<rgb8_ref_t, typename View::value_type,
                        CC> (_cc));
         }
         break;
      }
      case JCS_CMYK:
      {
         std::vector<cmyk8_pixel_t> row(view.width());
         JSAMPLE* row_address = (JSAMPLE*) &row.front();
         for (int y = 0; y < view.height(); ++y)
         {
            io_error_if(jpeg_read_scanlines(&_cinfo,
                  (JSAMPARRAY) & row_address, 1) != 1,
                  "jpeg_reader_color_covert::apply(): fail to read JPEG file");
            std::transform(row.begin(), row.end(), view.row_begin(y),
                  color_convert_deref_fn<cmyk8_ref_t,
                        typename View::value_type, CC> (_cc));
         }
         break;
      }
      default:
         io_error("jpeg_reader_color_covert::apply(): unknown color type");
      }
      jpeg_finish_decompress(&_cinfo);
   }
   template<typename Image>
   void read_image(Image& im)
   {
      im.recreate(get_dimensions());
      apply( view(im));
   }
};

class jpeg_writer: protected jpeg_destination_mgr
{
   std::ostream& _ostream;
   jpeg_compress_struct _cinfo;
   jpeg_error_mgr _jerr;
   char _buffer[1024];

   static void init_destination_fn(j_compress_ptr cinfo)
   {
      jpeg_writer* this_ = static_cast<jpeg_writer*> (cinfo->dest);
      this_->next_output_byte = (JOCTET*) this_->_buffer;
      this_->free_in_buffer = 1024;
   }

   static boolean empty_output_buffer_fn(j_compress_ptr cinfo)
   {
      jpeg_writer* this_ = static_cast<jpeg_writer*> (cinfo->dest);
      this_->_ostream.write(this_->_buffer, 1024);
      this_->next_output_byte = (JOCTET*) this_->_buffer;
      this_->free_in_buffer = 1024;
      return this_->_ostream.good();
   }

   static void term_destination_fn(j_compress_ptr cinfo)
   {
      jpeg_writer* this_ = static_cast<jpeg_writer*> (cinfo->dest);
      this_->_ostream.write(this_->_buffer, 1024 - this_->free_in_buffer);
   }

   //    void init() {
   //        _cinfo.err=jpeg_std_error(&_jerr);
   //        jpeg_create_compress(&_cinfo);
   //        init_destination = init_destination_fn;
   //        empty_output_buffer = empty_output_buffer_fn;
   //        term_destination = term_destination_fn;
   //        _cinfo.dest = this;
   //    }
public:
   jpeg_writer(std::ostream& ostream) :
      _ostream(ostream)
   {
      _cinfo.err = jpeg_std_error(&_jerr);
      jpeg_create_compress(&_cinfo);
      init_destination = init_destination_fn;
      empty_output_buffer = empty_output_buffer_fn;
      term_destination = term_destination_fn;
      _cinfo.dest = this;
   }

   ~jpeg_writer()
   {
      jpeg_destroy_compress(&_cinfo);
   }

   template<typename View>
   void apply(const View& view, int quality = 100)
   {
      _cinfo.image_width = (JDIMENSION) view.width();
      _cinfo.image_height = (JDIMENSION) view.height();
      _cinfo.input_components = num_channels<View>::value;
      _cinfo.in_color_space = jpeg_write_support_private<typename channel_type<
            View>::type, typename color_space_type<View>::type>::color_type;
      jpeg_set_defaults(&_cinfo);
      jpeg_set_quality(&_cinfo, quality, TRUE);
      jpeg_start_compress(&_cinfo, TRUE);
      std::vector<pixel<bits8,layout<typename color_space_type<View>::type> > >
            row(view.width());
      JSAMPLE* row_address = (JSAMPLE*) &row.front();
      for (int y = 0; y < view.height(); ++y)
      {
         std::copy(view.row_begin(y), view.row_end(y), row.begin());
         io_error_if(jpeg_write_scanlines(&_cinfo, (JSAMPARRAY) & row_address,
               1) != 1, "jpeg_writer::apply(): fail to write file");
      }
      jpeg_finish_compress(&_cinfo);
   }
};

} // namespace detail

} // namespace gil
} // namespace boost

#endif
