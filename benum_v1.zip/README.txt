BENUM - auto-generated streaming and metadata capture for enumerations

Authors: Tony Delroy, Andrew Marlow

- LICENSE AND COPYRIGHT -------------------------------------------------------

Copyright Tony Delroy 2008
Distributed under the Boost Software License, Version 1.0.
(See accompanying file LICENSE_1_0.txt or copy at
 http://www.boost.org/LICENSE_1_0.txt)

- SUMMARY ---------------------------------------------------------------------

BENUM is a support facility that automates support for streaming enumerations
(and a few similar value-adds).

- COMPILATION -----------------------------------------------------------------

You can compile the benum.test program using "make benum.test", or using
Visual C++'s default compilation logic.

- INTENDED AUDIENCE -----------------------------------------------------------

This release is intended for would-be reviewers to assess functionality,
correctness and usability.

- USAGE -----------------------------------------------------------------------

BENUM enumerations may be defined like this:

    EXPLICIT_BENUM__CUSTOM(Enumeration_Type_Name,
        Benum::Info_Container__Reference /* or a custom container */ ,
        /* space-separated options from benum_features.h */ ,
        identifier1 = value1 [ , ... ] );

...then used as per builtin enums...

   Enumeration_Type_Name x = identifier1;

...except istream& >> x and ostream& << x support (pipe-separated if necessary)
identifiers in preference to integers.

Various mark-up macros may be used to guide streaming and other benum features.

- TODO ------------------------------------------------------------------------

Later releases will provide some simpler macros with names implying the
Info_Container and features required, once it is better understood what's
most commonly appropriate.

Optimised Info_Container implementations can also be written once the
functional requirements are confirmed.
