#ifndef INCLUDED_BENUM_CONTAINERS_REFERENCE_H
#define INCLUDED_BENUM_CONTAINERS_REFERENCE_H

#include "benum_core.h"      // for Enum_Info
#include "benum_features.h"
#include "benum_containers_core.h"
#include <stdexcept>

// Reference Info_Container ===================================================

// The reference containers provides simple, easy-to-understand but unoptimised
// implementations of BENUM library behaviour, to:
//
//   - help users planning to roll their own Info_Containers understand the
//     expected functionality
//   - help library designers explore alternative functionalality
//   - provide a trusted implementation against which optimised containers can
//     be tested
//
// (see benum_containers_general.h and benum_containers_adaptive.h)

namespace Benum
{

    // int OR idn to info maps ------------------------------------------------

    // Int_To_Info__Map<> uses an arbitrary ordered associative container
    // (which must support duplicate keys ala multimap) to map from
    // enumeration value (cast to int) to Enum_Info.

    template <class Container>
    class Int_To_Info__Reference
    {
      public:
        virtual ~Int_To_Info__Reference() { }

        void register_enumeration(const Enum_Info& info)
        {
            container_.insert(std::make_pair(info.value_, info));
        }

        void post_registration__pre_usage(int)
        {
            // out() could be optimised if we created lists of exact values,
            // maps from mask values to identifiers etc here...
        }

        // streaming ----------------------------------------------------------

        std::ostream& out(std::ostream& os, int value) const
        {
            // first, seek an exact match with mode EQ
            for (typename Container::const_iterator i =
                     container_.lower_bound(value);
                 i != container_.end() && i->second.value_ == value; ++i)
            {
                if (i->second.mode_ == EQ)
                    return os << i->second.idn_;
                 
            }

            // failing that, brute-force reverse iteration (reverse so
            // value A|B is found before either A or B, providing
            // single concise identifier)
            
            // try to find exact matches on part of the value...
            
            int unaccounted_for = value;
            int idns = 0;
            
            for (typename Container::const_reverse_iterator i =
                     container_.rbegin(); i != container_.rend(); ++i)
            {
                Mode i_mode  = i->second.mode_;
                
                if (i_mode & Implicit)
                    continue;
                    
                int i_value = i->second.value_;
                int i_mask  = i->second.mask_;
                int masked  = unaccounted_for & i_mask;
                
                // BENUM_DBG("unaccounted for " << unaccounted_for
                //           << ", candidate " << i->second); 
                
                if (i_mode == Masked && masked == i_value ||
                    i_mode == And_EQ && masked == i_value)
                {
                    if (idns++ >= 1) os << '|';
                    os << i->second.idn_;
                    unaccounted_for -= i_value;
                    if (i_mask & 1 && unaccounted_for == 0)
                        break; // avoid streaming 0 value too...
                }
            }
            
            // if there haven't been any matches at all yet, then see
            // if the value might be composed of one or more masks...
            
            if (unaccounted_for && idns == 0)
            {
                for (typename Container::const_reverse_iterator i =
                     container_.rbegin(); i != container_.rend(); ++i)
                {
                    Mode i_mode  = i->second.mode_;
                
                    if (i_mode & Implicit ||
                        i_mode == Masked || i_mode == EQ)
                        continue;

                    int i_value = i->second.value_;
                    int i_mask  = i->second.mask_;
                    int masked  = unaccounted_for & i_mask;
                    
                    BENUM_DBG("unaccounted for " << unaccounted_for
                              << ", candidate { "
                              << i_mode << ", mask " << i_mask
                              << ", value " << i_value << " }"
                                 ", masked " << masked); 
                   
                    if ((unaccounted_for & i_mask) == i_mask)
                    {
                        if (idns++ >= 1) os << '|';
                        os << i->second.idn_;
                        
                        unaccounted_for -= i->second.value_;
                        
                        if (unaccounted_for == 0)
                            break;
                    }
                }
            }
            
            if (unaccounted_for)
            {                
                if (idns >= 1) os << '|';
                os << unaccounted_for;
            }
            
            return os;
        }

        // iteration ----------------------------------------------------------

        // providing our own iterator for operator* and -> customisation...
        class const_iterator
        {
          public:
            const_iterator(const typename Container::const_iterator& i)
              : iterator_(i)
            { }

            const Enum_Info& operator*() const { return iterator_->second; }
            const Enum_Info& operator->() const { return iterator_->second; }

            const_iterator& operator++() {
                ++iterator_;
                return *this;
            }

            bool operator==(const const_iterator& rhs) const
            {
                return iterator_ == rhs.iterator_;
            }

            bool operator!=(const const_iterator& rhs) const
            {
                return !operator==(rhs);
            }

          private:
            typename Container::const_iterator iterator_;
        };

        const_iterator begin() const
        {
            return const_iterator(container_.begin());
        }

        const_iterator end() const
        {
            return const_iterator(container_.end());
        }

        // miscellaneous ----------------------------------------------------
        
        const Enum_Info* max_value() const
        {
            return container_.empty() ? NULL : &container_.rbegin()->second;
        }

      private:
        Container container_;
    };

    // Idn_To_Info__Map<> uses an arbitrary associative container to map from
    // enumeration identifier to Enum_Info.  It was originally
    // hardcoding std::map<const std::string, const Enum_Info>, then templated
    // to allow substitution of faster hash maps.

    template <class Container>
    class Idn_To_Info__Map
    {
      public:
        virtual ~Idn_To_Info__Map() { }

        void register_enumeration(const Enum_Info& info)
        {
            container_.insert(std::make_pair(info.idn_, info));
        }

        void post_registration__pre_usage(int) { }

        std::istream& in(std::istream& is, int& value) const
        {
            return Benum::in(*this, is, value);
        }

        const Enum_Info* find(const std::string& idn) const
        {
            typename Container::const_iterator i = container_.find(idn);
            BENUM_DBG("find('" << idn << "') " << i->second
                      << " @" << (void*)&(i->second));

            return i != container_.end() ? &(i->second) : NULL;
        }

        bool in__one_identifier(const std::string& s, int& value) const
        {
            typename Container::const_iterator i = container_.find(s);

            if (i == container_.end())
                return false;

            value |= i->second.value_;
            return true;
        }

      private:
        Container container_;
    };

    // int AND idn to info maps -----------------------------------------------

    // some supporting typedefs to simplify composition of new Info_Containers

    typedef std::map<const std::string, const Enum_Info> Std_Map_From_Idn;
    typedef std::multimap<int, const Enum_Info>          Std_Multimap_From_Int;

    typedef Idn_To_Info__Map<Std_Map_From_Idn> Idn_To_Info__Std_Map;
    typedef Int_To_Info__Reference<Std_Multimap_From_Int>
                                               Int_To_Info__Reference__Multimap;

    // new Info_Containers...

    typedef Compose<Int_To_Info__Reference__Multimap, Idn_To_Info__Std_Map>
        Info_Container__Reference;
        
} // namespace Benum

#endif
