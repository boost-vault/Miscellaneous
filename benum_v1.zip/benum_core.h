#ifndef INCLUDED_BENUM_CORE_H
#define INCLUDED_BENUM_CORE_H

// This file defines the Enum_Info class capturing one enumeration value/
// identifier pair.  Significant extra complexity comes from a scheme for
// capturing additional optional (but necessary for correct streaming
// behaviour in some circumstances) user-supplied metadata.  The logic behind
// this is outlined below.
//
// Consider:
//
//   enum Type { Int = 0, Double = 1, String = 2, Boolean = 3, Video = 4,
//               Const = 8, ConstInt = Const|Int, Numeric = Int|Double,
//               FileScope = 0, NamespaceScope = 16,
//               ClassScope = 32, FunctionScope = 48, Scope = 16|32 };
// 
// - intuitively, we can work out from an understanding of the
//   real-world meaning of the words and subtle hints in the way the
//   values are expressed that logical intent resembles:
//
//   struct Type {
//      enum Base_Type { Int, Double, String, Boolean } base_type_;
//      bool const_;
//      enum Scope { File, Namespace, Class, Function } scope_;
//   };
// 
// - streaming enums can be quite tricky:
//   - value '9' might be best streamed as either FileScope|Const|Double
//     or simply Const|Double (iff FileScope is considered implied given
//     the choice to represent it as 0)
//   - '5' should NOT render as Video|Double
//   - '8' should probably (?) render as [FileScope|]ConstInt not ...Const
//   - '48' could be Scope 'mask', or FunctionScope[|Int]
//
// The BENUM library:
// - extracts user-specified information on the effectively embedded
//   "integers", "booleans", bit-masks, bit-sets etc. AND
// - supports related user operations at run-time.
//
// The user may specify this information by embedding additional macros
// inside the list of enumerations.  Those macros are defined at the bottom of
// this file.  There are four main types:
//
// - BENUM_MASK groups mutally-exclusive values and a final mask
//   value which.  The former values are considered related to an enumeration
//   value when resulting from application of the mask in a bitwise AND.
//   - hint: final mask value is often a bitwise OR of values in the set.
// 
// - idn = BENUM_IMPLICIT [ = [BENUM_XXX] [value] }
//   inhibits printing of this identifier when streaming out an enum
//
// - idn = BENUM_BIT value
//   indicates a boolean flag, value should be a power of 2
//
// - idn = BENUM_AND_OP(mask) [value]
//   idn is relevant iff a candidate & MASK OP [value]"
//   where OP may be EQ, NE, LT, LE, GE, GT, Z(ero) or N(ot)Z(ero), the last
//   two don't require or accept a value...
//
// Please consult benum.test.c++ for examples.

#include <algorithm>        // for std::pair<>
#include <string>
#include <iostream>

#define BENUM_DBG(X) \
    do { \
        if (true) \
            std::cerr << '@' << __LINE__ << ' ' << X << '\n'; \
    } while (false)

namespace Benum
{
    // Optional user-supplied metadata per enumeration ------------------------

    enum Mode { EQ, Masked, Mask, And_Z, And_NZ, And_EQ, And_NE,
                And_LT, And_LE, And_GE, And_GT, Implicit = 128 };

    inline std::ostream& operator<<(std::ostream& os, Mode mode)
    {
        if (mode & Implicit)
        {
            os << "Implicit|";
            mode = Mode(mode ^ Implicit);
        }

        switch (mode)
        {
          case EQ:       return os << "EQ";
          case Masked:   return os << "Masked";
          case Mask:     return os << "Mask";
          case And_Z:    return os << "And_Z";
          case And_NZ:   return os << "And_NZ";
          case And_EQ:   return os << "And_EQ";
          case And_NE:   return os << "And_NE";
          case And_LT:   return os << "And_LT";
          case And_LE:   return os << "And_LE";
          case And_GE:   return os << "And_GE";
          case And_GT:   return os << "And_GT";
          case Implicit: ; // prevent compiler warning for unhandled case...
        }
        return os << "<unknown mode>";
    }

    // Enum_Info associates an enumeration identifier and value ---------------
    //   e.g. enum E { X = 2, Z } => Enum_Info("X", 2), Enum_Info("Z", 3)

    struct Enum_Info
    {
        Enum_Info()
        { }

        Enum_Info(const std::string& idn, int value, Mode mode, int mask)
          : idn_(idn), value_(value), mode_(mode), mask_(mask)
        { }

        std::string idn_;
        int value_;
        Mode mode_;
        int mask_;

        // is x a logical match for this object?
        bool test(int x) const
        {
            BENUM_DBG(*this << ".test(" << x << ")...\n");
            
            switch (mode_ & ~Implicit)
            {
              case EQ:     return x == value_;
              case Masked: return (x & mask_) == value_;
              case Mask:   return x == value_;
              case And_Z:  return (x & mask_) == 0;
              case And_NZ: return (x & mask_) != 0;
              case And_EQ: return (x & mask_) == value_;
              case And_NE: return (x & mask_) != value_;
              case And_LT: return (x & mask_) <  value_;
              case And_LE: return (x & mask_) <= value_;
              case And_GE: return (x & mask_) >= value_;
              case And_GT: return (x & mask_) >  value_;
            }
            return false;
        }

        friend std::ostream& operator<<(std::ostream& os, const Enum_Info& ei)
        {
            os << "{ " << ei.idn_ << " = " << ei.value_;
            if (ei.mode_ != EQ)
              os << " / mode " << ei.mode_;
            if (ei.mode_ == Masked || ei.mode_ == And_EQ)
              os << ", mask " << ei.mask_;
            return os << " }";
        }
    };

    // info() helps map dereferenced container iterators to Enum_Info&s -------

    inline const Enum_Info& info(const std::pair<int, const Enum_Info>& pair)
    {
        return pair.second;
    }

    inline const Enum_Info& info(const Enum_Info& info) { return info; }

    // Registrar callback allows support code to request insertion of ---------
    // Enum_Info, entries identified at run time, in a derived container.

    struct Registrar
    {
        virtual ~Registrar() { }
        virtual void register_enumeration(const Enum_Info&) = 0;
    };

} // namespace Benum

#define BENUM_IMPLICIT
#define BENUM_EQ
#define BENUM_MASK(...) __VA_ARGS__
#define BENUM_AND_Z
#define BENUM_AND_NZ
#define BENUM_AND_EQ(X)
#define BENUM_AND_NE(X)
#define BENUM_AND_LT(X)
#define BENUM_AND_LE(X)
#define BENUM_AND_GE(X)
#define BENUM_AND_GT(X)
#define BENUM_BIT

#endif
