// Test cases for BENUM library

#include "benum.h"
#include "benum_containers_reference.h"

#include <iostream>
#include <sstream>

int num_tests = 0;
int failures = 0;

#define ASSERT_EQ(X, Y) \
    do { \
        ++num_tests; \
        bool pass = (X) == (Y); \
        if (!pass) ++failures; \
        std::cerr << (pass ? "PASS" : "FAIL") \
            << " @" << __LINE__ << "  " \
            << #X << " == '" << (X) << "' == " << #Y << '\n'; \
    } while (false)

#define ASSERT(X) ASSERT_EQ(X, true)

#define ASSERT_STREAM(X, Y) \
    do { \
        std::ostringstream oss; \
        oss << X; \
        ASSERT_EQ(oss.str(), Y); \
    } while (false)

EXPLICIT_BENUM__CUSTOM(Convoluted, // typename of class to wrap enum...
                       Benum::Info_Container__Reference, // meta-data storage
                       // optional features and behaviours...
                       BENUM_BITOPS
                       BENUM_ITERATOR
                       BENUM_EXPLICIT_CONSTRUCTOR_FROM_INT(Convoluted)
                       BENUM_INFO,
    // enumerations...
    BENUM_MASK(Int = 0, Double = 1, String = 2,
               Boolean = 3, Video = 4,
              Base_Type = 1|2|4),
    Const = BENUM_BIT 8,
    ConstInt = BENUM_AND_EQ(Const|Base_Type) Const|Int,
    FileConstInt = BENUM_EQ Const|Int,
    Numeric = BENUM_AND_Z Base_Type & ~(Int|Double),
    NonNumeric = BENUM_IMPLICIT BENUM_AND_NZ Base_Type & ~(Int|Double),
      // Note: different purpose, but same value as Numeric
      // alternative: NonNumeric = BENUM_AND_LE(Base_Type) Double,
    
    BENUM_MASK(FileScope = BENUM_IMPLICIT 0,
               NamespaceScope = 16,
               ClassScope = 32,
               FunctionScope = 48,
               Scope = NamespaceScope|ClassScope|FunctionScope));

void tests()
{
    typedef Convoluted T;
    Convoluted x = Convoluted::Int;
    ASSERT_EQ(Convoluted::type_idn(), "Convoluted");
    
    // streaming out --------------------------------------------------------    
    
    ASSERT_STREAM(x, "Int");

    x = Convoluted::Double;
    ASSERT_STREAM(x, "Double");

    x = Convoluted::ConstInt;
    ASSERT_STREAM(x, "FileConstInt");

    x = Convoluted::Const | Convoluted::Boolean;
    ASSERT_STREAM(x, "Const|Boolean");

    x = Convoluted::ClassScope | Convoluted::Boolean;
    ASSERT_STREAM(x, "ClassScope|Boolean");
    
    x = Convoluted::FunctionScope | Convoluted::ConstInt;
    ASSERT_STREAM(x, "FunctionScope|ConstInt");

    x = Convoluted(-1);
    ASSERT_STREAM(x, "FunctionScope|Const|-57"); // oh well, why not? 

    // masks ----------------------------------------------------------------
    
    x = Convoluted::Base_Type;
    ASSERT_STREAM(x, "Base_Type");

    x = Convoluted::Scope;
    ASSERT_STREAM(x, "FunctionScope|Int");
    // TODO: to_scope_string() reversing idn selection priorities...

    x = Convoluted::Numeric;
    ASSERT_STREAM(x, "Numeric");
    
    x = Convoluted::NonNumeric;
    ASSERT_STREAM(x, "Numeric"); // implicit, so should stream as
                                 // matching-valued Numeric...

    // logical tests --------------------------------------------------------

    // Note: this usage is error prone, as user could easily end up
    // dereferencing a NULL pointer.  Could provide a macro that
    // uses the identifier to refer to the enumeration as well as
    // stringifying it (the identifier is need to disambiguate situations
    // where two enumerations have the same value).

    // const Benum::Enum_Info* p = Convoluted::info("Numeric");
    ASSERT(Convoluted::info("Numeric")->test(Convoluted::Int));
    ASSERT(Convoluted::info("Numeric")->test(Convoluted::Double));
    ASSERT(!Convoluted::info("Numeric")->test(Convoluted::Boolean));
    ASSERT(!Convoluted::info("Numeric")->test(Convoluted::String));

    ASSERT(!Convoluted::info("NonNumeric")->test(Convoluted::Int));
    ASSERT(!Convoluted::info("NonNumeric")->test(Convoluted::Double));
    ASSERT(Convoluted::info("NonNumeric")->test(Convoluted::Boolean));
    ASSERT(Convoluted::info("NonNumeric")->test(Convoluted::String));

    ASSERT(!Convoluted::info("Const")->test(Convoluted::Boolean));
    ASSERT(Convoluted::info("Const")->
               test(Convoluted::String|Convoluted::Const));

    ASSERT(!Convoluted::info("ClassScope")->test(Convoluted::Boolean));
    ASSERT(Convoluted::info("ClassScope")->
               test(Convoluted::String|Convoluted::ClassScope));

    // iterators ------------------------------------------------------------    

    {
        std::ostringstream oss;
        for (T::const_iterator i = T::begin(); i != T::end(); ++i)
            oss << *i << ' ';
        // std::cerr << "streamed '" << oss << "'\n";
        ASSERT_EQ(oss.str(),
            "{ Int = 0 / mode Masked, mask 7 } "
            "{ FileScope = 0 / mode Implicit|Masked } "
            "{ Double = 1 / mode Masked, mask 7 } "
            "{ String = 2 / mode Masked, mask 7 } "
            "{ Boolean = 3 / mode Masked, mask 7 } "
            "{ Video = 4 / mode Masked, mask 7 } "
            "{ Numeric = 6 / mode And_Z } "
            "{ NonNumeric = 6 / mode Implicit|And_NZ } "
            "{ Base_Type = 7 / mode Mask } "
            "{ Const = 8 / mode Masked, mask 8 } "
            "{ ConstInt = 8 / mode And_EQ, mask 15 } "
            "{ FileConstInt = 8 } "
            "{ NamespaceScope = 16 / mode Masked, mask 48 } "
            "{ ClassScope = 32 / mode Masked, mask 48 } "
            "{ FunctionScope = 48 / mode Masked, mask 48 } "
            "{ Scope = 48 / mode Mask } ");
    }

    // streaming in ---------------------------------------------------------
    
    {
        std::istringstream iss1("Double|Const other stuff");
        bool stream_in_worked = iss1 >> x;
        ASSERT_EQ(stream_in_worked, true);
        ASSERT_STREAM(x, "Const|Double");

        char buf[128];
        iss1.get(buf, sizeof buf);
        ASSERT_EQ(std::string(buf), " other stuff");
    }
}

int main()
try
{
    tests();

    std::cerr << failures << " failures after " << num_tests << " tests\n";
    
    std::cerr << "Press return to exit...\n";
    getchar(); // what is it with these Windows GUIs - yikes!
    
    return failures ? EXIT_FAILURE : EXIT_SUCCESS;
}
catch (const std::exception& e)
{
    std::cerr << __FILE__ << ':' << __LINE__ << " caught exception "
        << e.what() << '\n';
}
