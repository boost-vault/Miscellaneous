#ifndef INCLUDED_BENUM_H
#define INCLUDED_BENUM_H

// BENUM - support for enums
// 
// Authors: Tony Delroy and Andrew Marlow
// Copyright 2008 All Rights Reserved
// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt or copy at
//  http://www.boost.org/LICENSE_1_0.txt)
//
// preprocessor generation of a class encapsulating an enum, w/ auto-generated
// streaming operators, iterators, cardinality etc.

#include "benum_core.h"     // Enum_Info, Registrar
#include "benum_support.h"  // parse(...)

#include <iostream>
#include <string>
#include <map>
#include <vector>
#include <sstream>

// BENUM Core/Abstract Infrastructure =========================================

namespace Benum
{
    // Info_Container abstraction ---------------------------------------------

    // Contains and indexes the Enum_Info structures for a specific enum.

    // While it is not necessary to use Info_Container__Abstract, the class:
    // - roughly documents an appropriate interface for instantiating
    //   Enum_Meta (via the EXPLICIT_BENUM__* macros) (see below).
    // - implies the minimum facilities a user can expect from an
    //   Info_Container, encouraging interoperability

    class Info_Container__Abstract : public Registrar
    {
      public:
        virtual ~Info_Container__Abstract() { }

        // the initialisation of the static container object will generate
        // callbacks into these functions with the enumeration values...
        virtual void register_enumeration(const Enum_Info&) = 0;
        virtual void post_registration__pre_usage(int num_values) = 0;

        // streaming operations...
        virtual std::ostream& out(std::ostream&, int value) = 0;
        virtual std::istream& in(std::istream&, int& value) = 0;

        // seek Enum_Info record using enumeration value as key...
        virtual const Enum_Info* find(int value) const = 0;

        // iteration over enumerations ----------------------------------------

        // - OPTIONAL but necessary support for BENUM_ITERATOR feature
        // - no ordering is guaranteed

        class const_iterator
        {
          public:
            const const_iterator& operator++() const;
            const const_iterator& operator++(int) const;

            bool operator==(const const_iterator& rhs) const;
            bool operator!=(const const_iterator& rhs) const;

          private:
            void* p_impl_;
        };

        virtual const_iterator begin() const = 0;
        virtual const_iterator end() const = 0;
    };

    // Enum_Meta objects associate a specific enumeration type with an
    // Info_Container (which need not be derived from Info_Container__Abstract
    // above, but should support equivalent usage).

    template <typename Enum, class Info_Container>
    class Enum_Meta : public Info_Container
    {
      public:
        Enum_Meta(const char type_idn[], const char source[],
                  const int values[], int num_values)
          : type_idn_(type_idn), num_values_(num_values)
        {

            parse(source, values, num_values, this);

            Info_Container::post_registration__pre_usage(num_values);
        }

        virtual ~Enum_Meta() { }

        const char* type_idn_;
        const int num_values_;
    };

    template <typename T>
    struct Incrementing
    {
        Incrementing() : value_(s_next_value_++) { }
        Incrementing(int value) : value_(value) { s_next_value_ = value + 1; }

        operator int() const { return value_; }

        int value_;
        static int s_next_value_;
    };

} // namespace B

template<typename T>
int Benum::Incrementing<T>::s_next_value_;

// BENUM usage macros =======================================================

// the final argument takes a list of zero or more enumerations...

#define EXPLICIT_BENUM__CUSTOM(TYPE, INFO_CONTAINER, FEATURES, ...) \
    class TYPE \
    { \
      public: \
        typedef TYPE Class_Type; \
        typedef Benum::Enum_Meta<TYPE, INFO_CONTAINER> Meta; \
        \
        enum Enum { __VA_ARGS__ }; \
        \
        TYPE(Enum e) : e_(e) { } \
        \
        TYPE& operator=(Enum e) { e_ = e; return *this; } \
        operator Enum() const { return e_; } \
        \
        FEATURES \
        \
        static const char* type_idn() { return #TYPE; } \
        static int num_values() { return TYPE::instance().num_values_; } \
        \
        friend std::ostream& operator<<(std::ostream& os, TYPE x) { \
            return TYPE::instance().out(os, (int)x); \
        } \
        \
        friend std::istream& operator>>(std::istream& is, TYPE& x) { \
            int value; \
            TYPE::instance().in(is, value); \
            x = Enum(value); \
            return is; \
        } \
        \
      private: \
        static Meta& instance() { \
            static Benum::Incrementing<TYPE> __VA_ARGS__; \
            static const int values[] = { __VA_ARGS__ }; \
            static Meta meta(#TYPE, #__VA_ARGS__, values, \
                             sizeof values / sizeof(int)); \
            return meta; \
        } \
        \
        Enum e_; \
    } /* Note: terminating semicolon to be provided by user... */

#define BENUM_IS(ENUM_EXPR, ENUM_VALUE) \
    (ENUM_EXPR).is(ENUM_VALUE, #ENUM_VALUE)

#endif
