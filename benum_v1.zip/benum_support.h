#ifndef INCLUDED_BENUM_SUPPORT_H
#define INCLUDED_BENUM_SUPPORT_H

#include "benum_core.h"

namespace Benum
{
    // parse(...) executes callbacks to a registrar object for each
    // enumeration found in the source code, with values picked up from the
    // values[] array.

    void parse(const char source[], const int values[], int num_values,
               Benum::Registrar*);
               
} // namespace Benum

# ifndef OUT_OF_LINE_BENUM_SUPPORT
#  include "benum_support.c++"
# endif

#endif
