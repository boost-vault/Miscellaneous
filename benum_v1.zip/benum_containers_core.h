#ifndef INCLUDED_BENUM_CONTAINERS_CORE_H
#define INCLUDED_BENUM_CONTAINERS_CORE_H

#include <cctype>

namespace Benum
{
    // support classes ------------------------------------------------------

    // helper class supporting creation of Info_Container from independent
    // Int_To_Info && Idn_To_Info classes...

    template <class A, class B>
    struct Compose : public A, public B, public Registrar
    {
        virtual ~Compose() { }

        void register_enumeration(const Enum_Info& info)
        {
            A::register_enumeration(info);
            B::register_enumeration(info);
        }

        void post_registration__pre_usage(int num_values)
        {
            A::post_registration__pre_usage(num_values);
            B::post_registration__pre_usage(num_values);
        }
    };

    // support functions ----------------------------------------------------

    template <class Container>
    std::istream& in(const Container& container, std::istream& is, int& value)
    {
        value = 0;
        char c;
        std::string s;
        bool performed_conversion = false;

        while (true)
        {
            if (!is.get(c))
            {
                BENUM_DBG("not is >> c, s '" << s << '\'');
                if (is.eof())
                    if (s.empty() ? !performed_conversion
                                  : !container.in__one_identifier(s, value))
                        break;

                return is;
            }

            if (std::isalnum(c) || c == '_')
                s += c;
            else
            {
                BENUM_DBG("in s '" << s << "', c '" << c << "'");
                if (s.empty())
                {
                    if (performed_conversion && c != '|')
                    {
                        is.putback(c);
                        return is;
                    }
                    else
                    {
                        is.setstate(std::ios::failbit);
                        return is;
                    }
                }
                else if (container.in__one_identifier(s, value))
                {
                    if (c != '|')
                    {
                        is.putback(c);
                        return is;
                    }
                    s.clear();
                    performed_conversion = true;
                    BENUM_DBG("continuing conversion, value " << value);
                }
                else
                    break;
            }
        }

        BENUM_DBG("unable to convert '" << s << "')");
        is.setstate(std::ios::failbit);
        return is;
    }

} // namespace Benum

#endif
