#ifndef INCLUDED_BENUM_FEATURES_H
#define INCLUDED_BENUM_FEATURES_H

#include "benum_core.h"      // for info(...)

// BENUM optional features ====================================================

// One or more of these macros may be placed in the FEATURES argument of
// EXPLICIT_BENUM__CUSTOM to incorporate additional members and functionality
// in the encapsulating class.

// Placeholder ----------------------------------------------------------------

#define BENUM_NO_FEATURES

// Bit Operations -------------------------------------------------------------
//
// - makes it legal to use |=, &=, ^=, |, &, ^ and ~ on enumeration values...

#define BENUM_BITOPS \
    Class_Type& operator|=(Enum rhs) { \
        e_ = Enum((int)e_ | (int)rhs); return *this; \
    } \
    Class_Type& operator&=(Enum rhs) { \
        e_ = Enum((int)e_ & (int)rhs); return *this; \
    } \
    Class_Type& operator^=(Enum rhs) { \
        e_ = Enum((int)e_ ^ (int)rhs); return *this; \
    } \
    Enum operator~() { \
        return Enum(~e_); \
    } \
    friend Enum operator|(Enum lhs, Enum rhs) { \
        return Enum((int)lhs | (int)rhs); \
    } \
    friend Enum operator&(Enum lhs, Enum rhs) { \
        return Enum((int)lhs & (int)rhs); \
    } \
    friend Enum operator^(Enum lhs, Enum rhs) { \
        return Enum((int)lhs ^ (int)rhs); \
    }

#define BENUM_BITSHIFT \
    Enum& operator>>=(int n) { \
        e_ = Enum((int)e_ >> n); return *this; \
    } \
    Enum& operator<<=(int n) { \
        e_ = Enum((int)e_ << n); return *this; \
    } \
    friend Enum operator>>(Enum lhs, int n) { \
        return Enum((int)lhs >> n); \
    } \
    friend Enum operator<<(Enum lhs, int n) { \
        return Enum((int)lhs << n); \
    }

// Increment ------------------------------------------------------------------

// - allows ++x or x++ to be used to increment an enum's value...

#define BENUM_INCREMENT \
    Class_Type& operator++() { \
        e_ = Enum((int)e_ + 1); \
        return *this; \
    } \
    Enum operator++(int) { \
        Enum result = e_; \
        operator++(); \
        return result; \
    }

// Comparison operators -------------------------------------------------------

#define BENUM_COMPARISON \
    friend bool operator< (Enum l, Enum r) { return (int)l <  (int)r; } \
    friend bool operator<=(Enum l, Enum r) { return (int)l <= (int)r; } \
    friend bool operator>=(Enum l, Enum r) { return (int)l >= (int)r; } \
    friend bool operator> (Enum l, Enum r) { return (int)l >  (int)r; }

// Iteration over enumerations ------------------------------------------------

// - provides const_iterator type, begin(), end()

#define BENUM_ITERATOR \
    typedef Meta::const_iterator const_iterator; \
    static const_iterator begin() { return instance().begin(); } \
    static const_iterator end()   { return instance().end();   }

// Default Constructor --------------------------------------------------------

#define BENUM_DEFAULT_CONSTRUCTOR(TYPE, VALUE) \
    TYPE() : e_(Enum(VALUE)) { }

// Explicit Constructor from int ----------------------------------------------

#define BENUM_EXPLICIT_CONSTRUCTOR_FROM_INT(TYPE) \
    TYPE(int value) : e_(Enum(value)) { }

// BENUM_IS(expr, enum_value) -------------------------------------------------

#define BENUM_INFO \
    static const Benum::Enum_Info* info(const std::string& idn) { \
        return instance().find(idn); \
    }

#endif
