/* -*- C++ -*-
 * $Id: probabilities.hpp,v 1.24 2007/10/18 05:04:29 brook Exp $
 */

/*
 * Copyright (c) 2007 Brook Milligan.
 * Distributed under the Boost Software License, Version 1.0. (See
 * accompanying file LICENSE_1_0.txt or copy at
 * http://www.boost.org/LICENSE_1_0.txt)
 */

/**
 * @file probabilities.hpp
 * @brief Definition of the probability class.
 */

#ifndef BOOST_PROBABILITIES_HPP
#define BOOST_PROBABILITIES_HPP

#include <cmath>
#include <limits>
#include <stdexcept>
#include <boost/concept_archetype.hpp>
#include <boost/concept_check.hpp>
#include <boost/operators.hpp>

#if defined __MSC_VER
#include <boost/math/special_functions/log1p.hpp>
using boost::math::log1p;
#endif

namespace boost
{

  namespace probabilities
  {

    /// Exception to indicate a runtime value failure
    template <typename Value>
    class out_of_range : public std::out_of_range
    {
    public:
      typedef Value value_type;
    public:
      out_of_range()
	: std::out_of_range("value out of range: "
			    "value cannot be interpreted as a "
			    "probability/likelihood"), v_() { }
      out_of_range(const value_type& v)
	: std::out_of_range("value out of range: "
			    "value cannot be interpreted as a "
			    "probability/likelihood"), v_(v) { }
      virtual ~out_of_range() throw() { }
      value_type value () const { return v_; }
    private:
      value_type v_;
    };

    /**
     * @brief Linear domain of operations.
     *
     * Perform operations on likelihoods and probabilities within the
     * linear domain, i.e., on native probability quantities.  Within
     * this domain, a likelihood or probability is represented
     * internally by its value and all operations correspond to
     * identical mathematical operations delegated to the @c
     * value_type..  The linear_domain type is used to signal the
     * domain of operation when transforming either the domain or
     * value of a probability object.  In addition, it is used to
     * signal the domain for certain constructors.
     */
    typedef struct { } linear_domain;

    /**
     * @brief Log domain of operations.
     *
     * Perform operations on likelihoods and probabilities within the
     * log domain.  Within this domain, a likelihood or probability is
     * represented internally by the logarithm of its value and, where
     * appropriate, operations are performed directly on the
     * logarithms.  For example, the multiplication operator (@c
     * operator*() is implemented in terms of addition of the internal
     * (log) values.  The log_domain type is used to signal the domain
     * of operation when transforming either the domain or value of a
     * probability object.  In addition, it is used to signal the
     * domain for certain constructors.
     *
     * Not all operations can be provided within the log domain
     * without incurring substantial costs associated with
     * transforming to the linear domain.  For example, the addition
     * of probabilities cannot be formed directly within the log
     * domain.  As a design decision, these operations are not
     * provided under the assumption that such expensive operations
     * should be requested explicitly by the client code.
     */
    typedef struct {} log_domain;

    /**
     * @brief Validator Concept checking class
     *
     * The Validator Concept applies to classes that can validate the
     * internal representation of likelihoods and probabilities.  The
     * likelihood and probabilty classes enforce this concept on the
     * @c Validator template argument.
     *
     * @li @b Required @b types.  Types modeling the Validator Concept
     * must provide a nested @c value_type.  This corresponds to the
     * type used to represent the quantities to be validated.
     * Normally, this is the same as the @c value_type of the
     * likelihood or probability class; however, it is sufficient that
     * those types are convertible to this @c value_type.
     *
     * @li @b Required @b functions.  Types modeling the Validator
     * Concept must provide the following functions:
     * @code
     * static void is_valid(value_type,linear_domain);
     * static void is_valid(value_type,log_domain);
     * @endcode

     * These function must decide whether or not the @c value_type
     * argument is valid within the corresponding domain.  If not,
     * they must signal that case by throwing an exception, typically
     * out_of_range.  The following types model the Validator Concept.
     *
     * @li validator_archetype.  This class is the archtypical model
     * for the Validator Concept.  Its primary use is to verify that
     * the ValidatorConcept class fully covers the concept.
     *
     * @li null_validator.  This validator generates no code and
     * accepts any value as valid.  Its primary use is to avoid the
     * run-time costs of validation.
     *
     * @li range_validator.  This validator verifies that values lie
     * strictly within the intervals appropriate for likelihoods and
     * probabilities, @f$[0,\infty)@f$ and @f$[0,1]@f$, respectively.
     * An out_of_range exception is thrown if the value lies outside
     * the interval.
     *
     * @li truncating_validator.  This validator verifies that values
     * lie within the appropriate intervals.  Value that are outside
     * the strct intervals defined above but within @c epsilon of a
     * boundary are truncated to the appropriate boundary.  This
     * handles floating point round-off errors that generate values
     * slightly outside the strict interval appropriate for the
     * domain.  An out_of_range exception is thrown if the value lies
     * outside the enlarged interval.
     */
    template <typename T>
    struct ValidatorConcept
    {
      /// Constraint checking function.
      void constraints()
      {
	T::is_valid(v,linear_domain());
	T::is_valid(v,log_domain());
      }
      /// Type of value to validate.
      typename T::value_type v;
    };

    /**
     * @brief Validator Concept archetype
     *
     * This class is the archetypical model of the ValidatorConcept.
     * Its primary purpose is to verify that the ValidatorConcept
     * class fully covers the requirements of the Validator Concept.
     *
     * The following example, which is available in
     * <A HREF="example5.cpp">example5.cpp</A>,
     * illustrates a test of the validator_archetype class with
     * respect to coverage of the Validator Concept.
     *
     * First, create a class that imposes the concept requirement.
     * @dontinclude example5.cpp
     * @skipline namespace
     * @until // namespace
     * Second, create a validator type to simplify the test
     * expression.
     * @skipline typedef
     * Finally, instantiate the class that imposes the concept
     * requirement.
     * @skipline <validator>
     * Similar code may be used to verify that another class,
     * range_validator in this case, covers the Validator Concept.
     * @skipline typedef
     * @until <validator>
     */
    template <typename Value, typename Base = null_archetype<> >
    class validator_archetype : public Base
    {
    public:
      /// Type of value to validate.
      typedef Value value_type;
      /**
       * @brief Is the @c value_type valid for this @c Domain?
       *
       * @param v Value to validate
       * @param d Domain within which @p v must be valid
       *
       * These static functions must ascertain, by some criterion,
       * whether or not the value of @p v is valid for domain @p d.
       * Upon return, these function must guarrantee that @p v is
       * valid for domain @p d.  Note that the value of @p v may be
       * modified to ensure that this is the case.  If this guarrentee
       * cannot be made, an exception must be thrown.
       */
      template <typename Domain>
      static void is_valid (value_type v, Domain d) { }
    };

    typedef struct {} likelihood_tag;
    typedef struct {} probability_tag;
    
    /**
     * @brief Domain-specific traits for likelihoods and probabilities.
     *
     * This class provides domain-specific operations for likelihoods
     * and probabilities.  All of the differences between the two
     * domains, linear_domain and log_domain, are factored into the
     * specializations of this class.  This is purely an
     * implementation detail of the main classes, which allows general
     * templating for both the domain type and the value type.  Client
     * code should have no need to refer to this class.  It may be
     * useful, however, for implementing certain classes that model
     * the ValidatorConcept.
     */

    template <typename Type, typename Domain, typename Value>
    struct domain_traits
    {
      static const Value default_value ();
      template <typename V>
      static void assign_add (V&, V);
      template <typename V>
      static void assign_sub (V&, V);
      template <typename V>
      static void assign_mpy (V&, V);
      template <typename V>
      static void assign_div (V&, V);
      template <typename SourceDomain, typename V>
      static Value transform_domain (SourceDomain, V);
      template <typename T>
      static const Value min (T);
      template <typename T>
      static const Value max (T);
      template <typename V>
      static bool in_range (V v);
      template <typename V>
      static void truncate (V& v, V epsilon);
      template <typename V>
      static bool equal (Value p, V v);
      template <typename V>
      static bool less_than (Value p, V v);
      template <typename V>
      static bool greater_than (Value p, V v);
      template <typename V>
      static Value pow (Value, V);
    };

    template <typename Type, typename Value>
    struct domain_traits<Type,linear_domain,Value>
    {
      static const Value default_value () { return Value(1); }
      template <typename V>
      static void assign_add (V& lhs, V rhs) { lhs+=rhs; }
      template <typename V>
      static void assign_sub (V& lhs, V rhs) { lhs-=rhs; }
      template <typename V>
      static void assign_mpy (V& lhs, V rhs) { lhs*=rhs; }
      template <typename V>
      static void assign_div (V& lhs, V rhs) { lhs/=rhs; }
      template <typename V>
      static Value transform_domain (linear_domain, V v) { return Value(v); }
      template <typename V>
      static Value transform_domain (log_domain, V v)
      { return exp(static_cast<Value>(v)); }
      static const Value min (likelihood_tag) { return Value(0); }
      static const Value max (likelihood_tag)
      { return std::numeric_limits<Value>::max(); }
      static const Value min (probability_tag) { return Value(0); }
      static const Value max (probability_tag) { return Value(1); }
      template <typename V>
      static bool in_range (V v) { return min(Type())<=v && v<=max(Type()); }
      template <typename V>
      static void truncate (V& v, V epsilon)
      {
	if (-epsilon <= v && v < min(Type())) v = min(Type());
	if (max(Type()) < v && v <= max(Type()) + epsilon) v = max(Type());
      }
      template <typename V>
      static bool equal (Value p, V v) { return p == v; }
      template <typename V>
      static bool less_than (Value p, V v) { return p < v; }
      template <typename V>
      static bool greater_than (Value p, V v) { return p > v; }
      template <typename V>
      static Value pow (Value x, V y) { return ::pow(x, y); }
    };

    template <typename Type, typename Value>
    struct domain_traits<Type,log_domain,Value>
    {
      static const Value default_value () { return Value(0); }
      // XXX - both arguments must be in the log domain
      template <typename V>
      static void assign_add (V& lhs, V rhs)
      {
 	static const V log2 (log(V(2)));
	if (lhs == rhs)
	  lhs += log2;
	else if (lhs > rhs)
	  lhs += log1p(exp(static_cast<V>(rhs-lhs)));
	else if (lhs < rhs)
	  lhs = rhs + log1p(exp(static_cast<V>(lhs-rhs)));
      }
      // XXX - both arguments must be in the log domain
      template <typename V>
      static void assign_sub (V& lhs, V rhs)
      {
	if (lhs == rhs)
	  lhs = -std::numeric_limits<V>::infinity();
	else if (lhs > rhs)
	  lhs += log1p(-exp(static_cast<V>(rhs-lhs)));
	else if (lhs < rhs)
	  throw out_of_range<V>(exp(static_cast<V>(lhs))
				- exp(static_cast<V>(rhs)));
      }
      template <typename V>
      static void assign_mpy (V& lhs, V rhs) { lhs+=rhs; }
      template <typename V>
      static void assign_div (V& lhs, V rhs) { lhs-=rhs; }
      template <typename V>
      static Value transform_domain (linear_domain, V v)
      { return log(static_cast<Value>(v)); }
      template <typename V>
      static Value transform_domain (log_domain, V v) { return Value(v); }
      static const Value min (likelihood_tag)
      { return -std::numeric_limits<Value>::max(); }
      static const Value max (likelihood_tag)
      { return std::numeric_limits<Value>::max(); }
      static const Value min (probability_tag)
      { return -std::numeric_limits<Value>::max(); }
      static const Value max (probability_tag) { return Value(0); }
      template <typename V>
      static bool in_range (V v) { return v <= max(Type());  }
      template <typename V>
      static void truncate (V& v, V epsilon)
      { if (max(Type()) < v && v <= epsilon) v = max(Type()); }
      template <typename V>
      static bool equal (Value p, V v)
      {
 	function_requires< ConvertibleConcept<V,Value> >();
	return p == log(static_cast<Value>(v));
      }
      template <typename V>
      static bool less_than (Value p, V v)
      {
	function_requires< ConvertibleConcept<V,Value> >();
	return p < log(static_cast<Value>(v));
      }
      template <typename V>
      static bool greater_than (Value p, V v)
      {
	function_requires< ConvertibleConcept<V,Value> >();
	return p > log(static_cast<Value>(v));
      }
      template <typename V>
      static Value pow (Value x, V y) { return x * y; }
    };

    /**
     * @brief Null validator.
     *
     * This class models the ValidatorConcept but does nothing to
     * check the validity of a value.  Use this validator if the
     * values will normally be within range and the performance gain
     * obtained by not checking is critical.
     */
    template <typename Value=double>
    struct null_validator
    {
      typedef Value value_type;
      static void is_valid (value_type, linear_domain) { }
      static void is_valid (value_type, log_domain) { }
    };
    /**
     * @brief Range-enforcing validator.
     *
     * This class models the ValidatorConcept and ensures that values
     * are within the range, which is @f$ [0,\infty) @f$ and @f$ [0,1]
     * @f$ for likelihoods and probabilities respectively.  Because
     * the range_validator introduces additional checks and incurs a
     * performance penalty, it is not the default validator.  However,
     * it is provided for situations in which performance is less
     * critical than a guarrantee that values lie strictly within the
     * appropriate range.
     */
    template <typename Type, typename Value=double>
    struct range_validator
    {
      typedef Value value_type;
      template <typename Domain>
      static void is_valid (value_type v, Domain)
      {
	if (!domain_traits<Type,Domain,Value>::in_range(v))
	  throw out_of_range<Value> (v);
      }
    };
    /**
     * @brief Truncating validator.
     *
     * This class models the ValidatorConcept and ensures that values
     * are within range.  Additionally, values outside of the range
     * but within @c epsilon of the boundaries are truncated to the
     * appropriate boundary.  This is to handle the corner cases that
     * might occur due to floating point round-off errors, even when
     * operating on well-defined values of likelihood or probability.
     */
    template <typename Type, typename Value=double>
    class truncating_validator
    {
    public:
      typedef Value value_type;
      template <typename Domain>
      static void is_valid (value_type& v, Domain)
      {
	domain_traits<Type,Domain,Value>::truncate(v, epsilon_);
	if (!domain_traits<Type,Domain,Value>::in_range(v))
	  throw out_of_range<Value> (v);
      }
      /**
       * @brief Inspect the tolerance imposed on the boundaries.
       *
       * Due to round-off errors, floating point values outside this
       * range may result, even when operating on well-defined values
       * of likelihood or probability.  Small deviations (e.g.,
       * determined by @p epsilon) are tolerated and truncated to the
       * appropriate extreme.
       */
      static value_type epsilon () { return epsilon_; }
      /**
       * @brief Set the tolerance imposed on the boundaries.
       *
       * Set the tolerance imposed on the boundaries and return the
       * previous tolerance.  Due to round-off errors, floating point
       * values outside this range may result, even when operating on
       * well-defined value of likelihood or probability.  Small
       * deviations (e.g., determined by @p epsilon) are tolerated and
       * truncated to the appropriate extreme.
       */
      static value_type epsilon (value_type epsilon)
      { std::swap(epsilon_, epsilon); return epsilon; }
      
    private:
      static value_type epsilon_;
    };

    /// Default value of epsilon.
    template <typename Type, typename Value>
    Value truncating_validator<Type,Value>::epsilon_ = 0;

    /**
     * @brief Probability quantity.
     *
     * This class encapsulates a probability quantity, represented as
     * the @c value_type template argument.  Probabilities and their
     * logarithms are encapsulated by types differing in their domains
     * (i.e., the linear_domain versus the log_domain).  In both
     * cases, however, the same semantics apply to the same operators.
     * For example, the multiplication operator operator*() denotes
     * multiplication of probabilities or addition of logarithms of
     * probabilities.  This helps make the fundamental operations
     * clearer in the code while providing an explicit means of
     * selecting the mode of operation, for example to avoid underflow
     * of the @c value_type.  The consistency of semantics also makes
     * generic algorithms possible.
     *
     * In addition to providing all the natural arithmetic operators,
     * the probability class models the following concepts.
     *
     * @li Default constructible.
     * @li Copy constructible.
     * @li Assignable.
     * @li Swapable.
     * @li Equality comparable
     * @li Less than comparable
     * @li Comparable (i.e., all comparison operators)
     *
     * In order to model these concepts, however, the underlying @c
     * value_type must also model most of these.  In addition, the @c
     * value_type must provide the exponential functions @c exp(), @c
     * log(), and @c log1p().  Finally, the class provides strong
     * exception guarrantees.  For example, although an assignment may
     * throw an exception, it will do so only if the copy constructor
     * does.  If this occurs, the original lvalue object is
     * guarranteed to be unchanged.
     */
    template < typename Domain = linear_domain, typename Value = double,
	       typename Validator = null_validator<Value> >
    class probability
      :   boost::multiplicative<probability<Domain,Value,Validator>
        , boost::multiplicative2<probability<Domain,Value,Validator>,Value
	, boost::totally_ordered<probability<Domain,Value,Validator>
	, boost::totally_ordered2<probability<Domain,Value,Validator>,Value
	> > > >
    {
    public:
      /**
       * @brief Type of domain of operations.
       *
       * The domain of operations is assumed to be one of
       * linear_domain or log_domain.
       */
      typedef Domain domain_type;
      /**
       * @brief Type representing probability values.
       *
       * The value type should be a model of the real numbers within
       * the closed interval [0,1].
       */
      typedef Value value_type;
      /// Type modeling ValidatorConcept for probability values.
      typedef Validator validator_type;

    private:
      BOOST_CLASS_REQUIRE(value_type, boost, AssignableConcept);
      BOOST_CLASS_REQUIRE(value_type, boost, CopyConstructibleConcept);
      BOOST_CLASS_REQUIRE(value_type, boost, EqualityComparableConcept);
      BOOST_CLASS_REQUIRE(value_type, boost, ComparableConcept);
      BOOST_CLASS_REQUIRE(validator_type, probabilities, ValidatorConcept);

    public:
      /**
       * @brief Construct a probability of unity.
       *
       * In many contexts, the most common operation on probabilities
       * is multiplication.  To simplify the accumulation of a product
       * of probabilities, the default constructed value is the
       * multiplicative identity.
       */
      probability ()
	: p_(domain_traits<probability_tag,domain_type,value_type>::
	     default_value())
      { validator_type::is_valid(p_,domain_type()); }
      /**
       * @brief Explicitly construct a probability.
       *
       * @param t Value of probability represented as the type T.
       *
       * Note that type T must be convertible to the internal
       * representation of a probability (i.e., to the @c value_type).
       */
      template <typename T>
      explicit probability (const T& t)
	: p_(t)
      {
	function_requires< ConvertibleConcept<T,value_type> >();
	validator_type::is_valid(p_,domain_type());
      }
      /**
       * @brief Explicitly construct a probability from another domain.
       *
       * @param t Value of probability represented as the type T.
       *
       * Note that type T must be convertible to the internal
       * representation of a probability (i.e., to the @c value_type).
       */
      template <typename T, typename D>
      probability (const T& t, D)
	: p_(domain_traits<probability_tag,domain_type,value_type>::
	     transform_domain(D(),t))
      {
	function_requires< ConvertibleConcept<T,value_type> >();
	validator_type::is_valid(p_,domain_type());
      }
      /// Transform a probability from another domain.
      template <typename D, typename V, typename VV>
      probability (const probability<D,V,VV>& p)
	: p_(p.value_cast(domain_type()))
      {
	function_requires< ConvertibleConcept<V,value_type> >();
	validator_type::is_valid(p_,domain_type());
      }
      probability (const probability& p) : p_(p.p_) { }
      ~probability () { }
      probability& operator = (const probability& p)
      { probability p_(p); swap(p_); return *this; }
      void swap (probability& p) { std::swap (p_, p.p_); }
      
      /**
       * @name Mathematical assignment operators
       *
       * The probability class is derived from the
       * boost::operators classes.  As a result, these mathematical
       * assignment operators are the foundation for a complete set of
       * natural mathematical operations.  The probability class
       * supports the full range of arithmetic operators.
       */
      //@{
      /// Addition assignment operator.
      template <typename D, typename V, typename VV>
      probability& operator += (const probability<D,V,VV>& p)
      {
	function_requires< ConvertibleConcept<V,value_type> >();
	domain_traits<probability_tag,domain_type,value_type>::assign_add
	  (p_,value_type(p.value_cast(domain_type())));
	validator_type::is_valid(p_,domain_type());
	return *this;
      }
      /**
       * @brief Addition assignment operator.
       *
       * Add a value of type T to a probability.  Note that the type T
       * must be convertible to the @c value_type.  Furthermore, @c t
       * is assumed to be in the linear domain; it will be converted
       * to the appropriate domain as required.
       */
      template <typename T>
      probability& operator += (const T& t)
      {
	function_requires< ConvertibleConcept<T,value_type> >();
	value_type domain_t
	  (domain_traits<probability_tag,domain_type,value_type>::
	   transform_domain(linear_domain(),t));
	domain_traits<probability_tag,domain_type,value_type>::
	  assign_add(p_,domain_t);
	validator_type::is_valid(p_,domain_type());
	return *this;
      }

      /// Subtraction assignment operator.
      template <typename D, typename V, typename VV>
      probability& operator -= (const probability<D,V,VV>& p)
      {
	function_requires< ConvertibleConcept<V,value_type> >();
	domain_traits<probability_tag,domain_type,value_type>::assign_sub
	  (p_,value_type(p.value_cast(domain_type())));
	validator_type::is_valid(p_,domain_type());
	return *this;
      }
      /**
       * @brief Subtraction assignment operator.
       *
       * Subtract a value of type T from a probability.  Note that the
       * type T must be convertible to the @c value_type.
       * Furthermore, @c t is assumed to be in the linear domain; it
       * will be converted to the appropriate domain as required.
       */
      template <typename T>
      probability& operator -= (const T& t)
      {
	function_requires< ConvertibleConcept<T,value_type> >();
	value_type domain_t
	  (domain_traits<probability_tag,domain_type,value_type>::
	   transform_domain(linear_domain(),t));
	domain_traits<probability_tag,domain_type,value_type>::
	  assign_sub(p_,domain_t);
	validator_type::is_valid(p_,domain_type());
	return *this;
      }

      /// Multiplication assignment operator.
      template <typename D, typename V, typename VV>
      probability& operator *= (const probability<D,V,VV>& p)
      {
	function_requires< ConvertibleConcept<V,value_type> >();
	domain_traits<probability_tag,domain_type,value_type>::assign_mpy
	  (p_,value_type(p.value_cast(domain_type())));
	validator_type::is_valid(p_,domain_type());
	return *this;
      }
      /**
       * @brief Multiplication assignment operator.
       *
       * Multiply a probability by a value of type T.  Note that the
       * type T must be convertible to the @c value_type.
       * Furthermore, @c t is assumed to be in the linear domain; it
       * will be converted to the appropriate domain as required.
       */
      template <typename T>
      probability& operator *= (const T& t)
      {
	function_requires< ConvertibleConcept<T,value_type> >();
	value_type domain_t
	  (domain_traits<probability_tag,domain_type,value_type>::
	   transform_domain(linear_domain(),t));
	domain_traits<probability_tag,domain_type,value_type>::
	  assign_mpy(p_,domain_t);
	validator_type::is_valid(p_,domain_type());
	return *this;
      }

      /// Division assignment operator.
      template <typename D, typename V, typename VV>
      probability& operator /= (const probability<D,V,VV>& p)
      {
	function_requires< ConvertibleConcept<V,value_type> >();
	domain_traits<probability_tag,domain_type,value_type>::assign_div
	  (p_,value_type(p.value_cast(domain_type())));
	validator_type::is_valid(p_,domain_type());
	return *this;
      }
      /**
       * @brief Division assignment operator.
       *
       * Divide a probability by a value of type T.  Note that the
       * type T must be convertible to the @c value_type.
       * Furthermore, @c t is assumed to be in the linear domain; it
       * will be converted to the appropriate domain as required.
       */
      template <typename T>
      probability& operator /= (const T& t)
      {
	function_requires< ConvertibleConcept<T,value_type> >();
	value_type domain_t
	  (domain_traits<probability_tag,domain_type,value_type>::
	   transform_domain(linear_domain(),t));
	domain_traits<probability_tag,domain_type,value_type>::
	  assign_div(p_,domain_t);
	validator_type::is_valid(p_,domain_type());
	return *this;
      }
      //@}

      /// Unary plus operator.
      probability operator + () const { return *this; }

      /// Cast to another domain.
      template <typename D>
      probability<D,value_type,validator_type> domain_cast (D) const
      { return probability<D,value_type,validator_type>(value_cast(D())); }

      /// Cast the internal value to another domain.
      template <typename D>
      value_type value_cast (D) const
      {
	return domain_traits<probability_tag,D,value_type>::
	  transform_domain(domain_type(),p_);
      }
      //@}

    private:
      value_type p_;
    };

    /// @ingroup casts
    //@{
    /**
     * @brief Cast domain of operations.
     *
     * @param p probability
     *
     * This function creates a new probability object as a copy of @p
     * p but cast into the domain specified by the template argument
     * @c TargetDomain.  Appropriate domain types are linear_domain
     * and log_domain.
     */
    template <typename TargetDomain, typename SourceDomain,
	      typename Value, typename Validator>
    probability<TargetDomain,Value,Validator>
    domain_cast (const probability<SourceDomain,Value,Validator>& p)
    { return p.domain_cast (TargetDomain()); }
    
    /**
     * @brief Cast the value of a probability.
     *
     * @param p probability
     *
     * This function creates an object representing only the value of
     * the probability @p p, but cast into the domain specified by the
     * template argument @c TargetDomain.  This is useful, for
     * example, to inspect the value of a probability object and
     * ensure that the value is represented within a particular
     * domain.  It may also be useful if further calculations must be
     * performed on the value that do not, for example, result in a
     * probability.  Appropriate domain types are linear_domain and
     * log_domain.
     */
    template <typename TargetDomain, typename SourceDomain,
	      typename Value, typename Validator>
    typename probability<TargetDomain,Value,Validator>::value_type
    value_cast (const probability<SourceDomain,Value,Validator>& p)
    { return p.value_cast(TargetDomain()); }
    //@}

    /// @ingroup arithmetic
    //@{
    /// Addition of probabilities.
    template <typename Ldomain, typename Lvalue, typename Lvalidator,
	      typename Rdomain, typename Rvalue, typename Rvalidator>
    probability<Ldomain, Lvalue, Lvalidator>
    operator + (const probability<Ldomain,Lvalue,Lvalidator>& lhs,
		const probability<Rdomain,Rvalue,Rvalidator>& rhs)
    {
      probability<Ldomain,Lvalue,Lvalidator> p(lhs);
      p += rhs;
      return p;
    }

    /// Subtraction of probabilities.
    template <typename Ldomain, typename Lvalue, typename Lvalidator,
	      typename Rdomain, typename Rvalue, typename Rvalidator>
    probability<Ldomain, Lvalue, Lvalidator>
    operator - (const probability<Ldomain,Lvalue,Lvalidator>& lhs,
		const probability<Rdomain,Rvalue,Rvalidator>& rhs)
    {
      probability<Ldomain,Lvalue,Lvalidator> p(lhs);
      p -= rhs;
      return p;
    }

    /// Multiplication of probabilities.
    template <typename Ldomain, typename Lvalue, typename Lvalidator,
	      typename Rdomain, typename Rvalue, typename Rvalidator>
    probability<log_domain, Lvalue, Lvalidator>
    operator * (const probability<Ldomain,Lvalue,Lvalidator>& lhs,
		const probability<Rdomain,Rvalue,Rvalidator>& rhs)
    {
      probability<log_domain, Lvalue, Lvalidator> p(lhs);
      p *= rhs;
      return p;
    }

    /// Division of probabilities.
    template <typename Ldomain, typename Lvalue, typename Lvalidator,
	      typename Rdomain, typename Rvalue, typename Rvalidator>
    probability<log_domain, Lvalue, Lvalidator>
    operator / (const probability<Ldomain,Lvalue,Lvalidator>& lhs,
		const probability<Rdomain,Rvalue,Rvalidator>& rhs)
    {
      probability<log_domain, Lvalue, Lvalidator> p(lhs);
      p /= rhs;
      return p;
    }
    //@}

    /// @ingroup compare
    //@{
    /**
     * @brief Create logical comparison operator functions.
     *
     * This macro simplifies the creation of the necessary logical
     * comparisons between two probability quantities as they are all
     * essentially the same, differing only in the probability types
     * being compared.
     *
     * Operators include the full range of logical comparisons (@c ==,
     * @c !=, @c <, @c <=, @c >=, @c >).
     */
#define COMPARE(OP)                                                           \
    template <typename Ldomain, typename Lvalue, typename Lvalidator,         \
	      typename Rdomain, typename Rvalue, typename Rvalidator>         \
    bool                                                                      \
    operator OP (const probability<Ldomain,Lvalue,Lvalidator>& lhs,           \
		 const probability<Rdomain,Rvalue,Rvalidator>& rhs)           \
    { return lhs.value_cast(log_domain()) OP rhs.value_cast(log_domain()); }

    COMPARE(==)
    COMPARE(!=)
    COMPARE(<)
    COMPARE(<=)
    COMPARE(>=)
    COMPARE(>)

#undef COMPARE

    /**
     * @brief Create logical comparison operator functions.
     *
     * This macro simplifies the creation of the necessary logical
     * comparisons between a probability quantity and another type as
     * they are all essentially the same, differing only in the types
     * being compared.
     *
     * Operators include the full range of logical comparisons (@c ==,
     * @c !=, @c <, @c <=, @c >=, @c >).
     */
#define COMPARE_T(OP)                                                         \
    template <typename Domain,typename Value,typename Validator,typename T>   \
    bool                                                                      \
    operator OP (const probability<Domain,Value,Validator>& lhs, const T& rhs)\
    {                                                                         \
      function_requires< ConvertibleConcept<T,Value> >();                     \
      return lhs.value_cast(linear_domain()) OP rhs;                          \
    }                                                                         \
    template <typename Domain,typename Value,typename Validator,typename T>   \
    bool                                                                      \
    operator OP (const T& lhs, const probability<Domain,Value,Validator>& rhs)\
    {                                                                         \
      function_requires< ConvertibleConcept<T,Value> >();                     \
      return lhs OP rhs.value_cast(linear_domain());                          \
    }

    COMPARE_T(==)
    COMPARE_T(!=)
    COMPARE_T(<)
    COMPARE_T(<=)
    COMPARE_T(>=)
    COMPARE_T(>)

#undef COMPARE_T
    //@}

    /// @ingroup functions
    //@{
      /**
       * @brief Power function of probabilities.
       *
       * Note that probabilities raised to powers that are not natural
       * numbers make little sense in the context of this library, as
       * the result is no longer a probability.  Consequently, this
       * power function is only valid for integral exponents.
       */
    template <typename Domain, typename Value, typename Validator,
	      typename Integer>
    probability<Domain, Value, Validator>
    pow (const probability<Domain,Value,Validator>& base, Integer n)
    {
      function_requires< boost::IntegerConcept<Integer> >();
      return probability<Domain,Value,Validator>
	(domain_traits<probability_tag,Domain,Value>::
	 pow(base.value_cast(Domain()), n));
    }
    //@}

  } // namespace probabilities

} // namespace boost

namespace std
{

  /**
   * @brief Specialization of @c std::numeric_limits for probabilities.
   *
   * In almost all instances, the functions and values encapsulated
   * for @c std::numeric_limits<boost::probabilities::probability> are
   * simply delegated to the corresponding functions and values for
   * the underlying @c value_type.  The following, however, are
   * notable exceptions.
   *
   * @li @c is_signed is false regardless of the @c value_type as
   * probabilities cannot be negative.
   *
   * @li @c min() and @c max() return the extreme values for the
   * internal value of a probability in the relevant domain.  The
   * range corresponds to @f$ [0,1] @f$ and @f$ [-\infty, 0] @f$ for
   * the boost::probabilities::linear_domain and
   * boost::probabilities::log_domain, respectively.
   *
   * @li @c min() returns the value of @c
   * std::numeric_limits<Value>::min() for any domain.  For types
   * without denormalization, this corresponds to the minimum finite
   * value representable by the internal type; for types with
   * denormalization this corresponds to the minimum positive
   * normalized value representable by the internal type.  This seems
   * to be the most appropriate interpretation of the intent of @c
   * std:numeric_limits<>::min().
   *
   * @li @c max() returns a value of unity (1) for eny domain.  This
   * corresponds to the maximum value in the linear domain, which
   * seems to be the most appropriate interpretation of the intent of
   * @c std:numeric_limits<>::max().
   */
  template <typename Domain, typename Value, typename Validator>
  struct numeric_limits< boost::probabilities::
    probability<Domain,Value,Validator> >
  {
    static const bool is_specialized = true;

    static Value min() throw() { return numeric_limits<Value>::min(); }
    static Value max() throw() { return Value(1); }

    static const int digits = numeric_limits<Value>::digits;
    static const int digits10 = numeric_limits<Value>::digits10;
    static const bool is_signed = false;
    static const bool is_integer = numeric_limits<Value>::is_integer;
    static const bool is_exact = numeric_limits<Value>::is_exact;
    static const int radix = numeric_limits<Value>::radix;
    static Value epsilon() throw() { return numeric_limits<Value>::epsilon(); }
    static Value round_error() throw()
    { return numeric_limits<Value>::round_error(); }

    static const int min_exponent = numeric_limits<Value>::min_exponent;
    static const int min_exponent10 = numeric_limits<Value>::min_exponent10;
    static const int max_exponent = numeric_limits<Value>::max_exponent;
    static const int max_exponent10 = numeric_limits<Value>::max_exponent10;

    static const bool has_infinity = numeric_limits<Value>::has_infinity;
    static const bool has_quiet_NaN = numeric_limits<Value>::has_quiet_NaN;
    static const bool has_signaling_NaN
    = numeric_limits<Value>::has_signaling_NaN;
    static const float_denorm_style has_denorm
    = numeric_limits<Value>::has_denorm;
    static const bool has_denorm_loss = numeric_limits<Value>::has_denorm_loss;

    static Value infinity() throw()
    { return numeric_limits<Value>::infinity(); }
    static Value quiet_NaN() throw()
    { return numeric_limits<Value>::quiet_NaN(); }
    static Value signaling_NaN() throw()
    { return numeric_limits<Value>::signaling_NaN(); }
    static Value denorm_min() throw()
    { return numeric_limits<Value>::denorm_min(); }

    static const bool is_iec559 = numeric_limits<Value>::is_iec559;
    static const bool is_bounded = numeric_limits<Value>::is_bounded;
    static const bool is_modulo = numeric_limits<Value>::is_modulo;

    static const bool traps = numeric_limits<Value>::traps;
    static const bool tinyness_before = numeric_limits<Value>::tinyness_before;
    static const float_round_style round_style
    = numeric_limits<Value>::round_style;
  };

} // namespace std

#endif
