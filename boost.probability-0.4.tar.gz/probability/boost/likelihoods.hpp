/* -*- C++ -*-
 * $Id: likelihoods.hpp,v 1.15 2007/10/18 05:04:29 brook Exp $
 */

/*
 * Copyright (c) 2007 Brook Milligan.
 * Distributed under the Boost Software License, Version 1.0. (See
 * accompanying file LICENSE_1_0.txt or copy at
 * http://www.boost.org/LICENSE_1_0.txt)
 */

/**
 * @file likelihoods.hpp
 * @brief Definition of the likelihood class.
 */

#ifndef BOOST_LIKELIHOODS_HPP
#define BOOST_LIKELIHOODS_HPP

#include <cmath>
#include <limits>
#include <boost/concept_check.hpp>
#include <boost/operators.hpp>
#include <boost/probabilities.hpp>

namespace boost
{

  namespace probabilities
  {

    /**
     * @brief Likelihood quantity.
     *
     * This class encapsulates a likelihood quantity, represented as
     * the @c value_type template argument.  Likelihoods and their
     * logarithms are encapsulated by types differing in their domains
     * (i.e., the linear_domain versus the log_domain).  In both
     * cases, however, the same semantics apply to the same operators.
     * For example, the multiplication operator operator*() denotes
     * multiplication of likelihoods or addition of logarithms of
     * likelihoods.  This helps make the fundamental operations
     * clearer in the code while providing an explicit means of
     * selecting the mode of operation, for example to avoid underflow
     * of the @c value_type.  The consistency of semantics also makes
     * generic algorithms possible.
     *
     * In addition to providing all the natural arithmetic operators,
     * the likelihood class models the following concepts.
     *
     * @li Default constructible.
     * @li Copy constructible.
     * @li Assignable.
     * @li Swapable.
     * @li Equality comparable
     * @li Less than comparable
     * @li Comparable (i.e., all comparison operators)
     *
     * In order to model these concepts, however, the underlying @c
     * value_type must also model most of these.  In addition, the @c
     * value_type must provide the exponential functions @c exp(), @c
     * log(), and @c log1p().  Finally, the class provides strong
     * exception guarrantees.  For example, although an assignment may
     * throw an exception, it will do so only if the copy constructor
     * does.  If this occurs, the original lvalue object is
     * guarranteed to be unchanged.
     */
    template < typename Domain = linear_domain, typename Value = double,
	       typename Validator = null_validator<Value> >
    class likelihood
      :   boost::multiplicative<likelihood<Domain,Value,Validator>
	, boost::multiplicative2<likelihood<Domain,Value,Validator>,Value
	, boost::multiplicative2<likelihood<Domain,Value,Validator>,
				 probability<Domain,Value,Validator>
	, boost::totally_ordered<likelihood<Domain,Value,Validator>
	, boost::totally_ordered2<likelihood<Domain,Value,Validator>,Value
	, boost::totally_ordered2<likelihood<Domain,Value,Validator>,
				  probability<Domain,Value,Validator>
	> > > > > >
    {
    public:
      /**
       * @brief Type of domain of operations.
       *
       * The domain of operations is assumed to be one of
       * linear_domain or log_domain.
       */
      typedef Domain domain_type;
      /**
       * @brief Type representing likelihood values.
       *
       * The value type should be a model of the real numbers within
       * the semi-open interval @f$[0,\infty)@f$.
       */
      typedef Value value_type;
      /// Type modeling ValidatorConcept for likelihood values.
      typedef Validator validator_type;

    private:
      BOOST_CLASS_REQUIRE(value_type, boost, AssignableConcept);
      BOOST_CLASS_REQUIRE(value_type, boost, CopyConstructibleConcept);
      BOOST_CLASS_REQUIRE(value_type, boost, EqualityComparableConcept);
      BOOST_CLASS_REQUIRE(value_type, boost, ComparableConcept);
      BOOST_CLASS_REQUIRE(validator_type, probabilities, ValidatorConcept);

    public:
      /**
       * @brief Construct a likelihood of unity.
       *
       * In many contexts, the most common operation on likelihoods is
       * multiplication.  To simplify the accumulation of a product of
       * likelihoods, the default constructed value is the
       * multiplicative identity.
       */
      likelihood ()
	: l_(domain_traits<likelihood_tag,domain_type,value_type>::
	     default_value()) 
	{ validator_type::is_valid(l_,domain_type()); }
      /**
       * @brief Explicitly construct a likelihood.
       *
       * @param t Value of likelihood represented as the type T.
       *
       * Note that type T must be convertible to the internal
       * representation of a probability (i.e., to the @c value_type).
       */
      template <typename T>
      explicit likelihood (const T& t)
	: l_(t)
      {
	function_requires< ConvertibleConcept<T,value_type> >();
	validator_type::is_valid(l_,domain_type());
      }
      /**
       * @brief Explicitly construct a likelihood from another domain.
       *
       * @param t Value of likelihood represented as the type T.
       *
       * Note that type T must be convertible to the internal
       * representation of a probability (i.e., to the @c value_type).
       */
      template <typename T, typename D>
      likelihood (const T& t, D)
	: l_(domain_traits<likelihood_tag,domain_type,value_type>::
	     transform_domain(D(),t))
      {
	function_requires< ConvertibleConcept<T,value_type> >();
	validator_type::is_valid(l_,domain_type());
      }
      /// Transform a likelihood from another domain.
      template <typename D, typename V, typename VV>
      likelihood (const likelihood<D,V,VV>& l)
	: l_(l.value_cast(domain_type()))
      {
	function_requires< ConvertibleConcept<V,value_type> >();
	validator_type::is_valid(l_,domain_type());
      }
      /**
       * @brief Construct a likelihood from a probability.
       */
      template <typename D, typename V, typename VV>
      likelihood (const probability<D,V,VV>& l)
	: l_(l.value_cast(domain_type()))
      {
	function_requires< ConvertibleConcept<V,value_type> >();
	validator_type::is_valid(l_,domain_type());
      }
      likelihood (const likelihood& l) : l_(l.l_) { }
      ~likelihood () { }
      likelihood& operator = (const likelihood& l)
      { likelihood l_(l); swap(l_); return *this; }
      void swap (likelihood& l) { std::swap (l_, l.l_); }
      
      /**
       * @name Mathematical assignment operators
       *
       * The likelihood class is derived from the
       * boost::operators classes.  As a result, these mathematical
       * assignment operators are the foundation for a complete set of
       * natural mathematical operations.  The likelihood class
       * supports the full range of arithmetic operators.
       */
      //@{
      /// Addition assignment operator.
      template <typename D,typename V, typename VV>
      likelihood& operator += (const likelihood<D,V,VV>& l)
      {
	function_requires< ConvertibleConcept<V,value_type> >();
	domain_traits<likelihood_tag,domain_type,value_type>::assign_add
	  (l_,value_type(l.value_cast(domain_type())));
	validator_type::is_valid(l_,domain_type());
	return *this;
      }
      /**
       * @brief Addition assignment operator.
       *
       * Add a value of type T to a likelihood.  Note that type T must
       * be convertible to the @c value_type.  Furthermore, @c t is
       * assumed to be in the linear domain; it will be converted to
       * the appropriate domain as required.
       */
      template <typename T>
      likelihood& operator += (const T& t)
      {
	function_requires< ConvertibleConcept<T,value_type> >();
	value_type domain_t
	  (domain_traits<likelihood_tag,domain_type,value_type>::
	   transform_domain(linear_domain(),t));
	domain_traits<likelihood_tag,domain_type,value_type>::
	  assign_add(l_,domain_t);
	validator_type::is_valid(l_,domain_type());
	return *this;
      }
      /// Addition assignment operator.
      template <typename D, typename V, typename VV>
      likelihood& operator += (const probability<D,V,VV>& p)
      {
	function_requires< ConvertibleConcept<V,value_type> >();
	domain_traits<likelihood_tag,domain_type,value_type>::assign_add
	  (l_,value_type(p.value_cast(domain_type())));
	validator_type::is_valid(l_,domain_type());
	return *this;
      }
      
      /// Subtraction assignment operator.
      template <typename D, typename V, typename VV>
      likelihood& operator -= (const likelihood<D,V,VV>& l)
      {
	function_requires< ConvertibleConcept<V,value_type> >();
	domain_traits<likelihood_tag,domain_type,value_type>::assign_sub
	  (l_,value_type(l.value_cast(domain_type())));
	validator_type::is_valid(l_,domain_type());
	return *this;
      }
      /**
       * @brief Subtraction assignment operator.
       *
       * Subtract a value of type T from a likelihood.  Note that type
       * T must be convertible to the @c value_type.  Furthermore, @c
       * t is assumed to be in the linear domain; it will be converted
       * to the appropriate domain as required.
       */
      template <typename T>
      likelihood& operator -= (const T& t)
      {
	function_requires< ConvertibleConcept<T,value_type> >();
	value_type domain_t
	  (domain_traits<likelihood_tag,domain_type,value_type>::
	   transform_domain(linear_domain(),t));
	domain_traits<likelihood_tag,domain_type,value_type>::
	  assign_sub(l_,domain_t);
	validator_type::is_valid(l_,domain_type());
	return *this;
      }
      /// Subtraction assignment operator.
      template <typename D, typename V, typename VV>
      likelihood& operator -= (const probability<D,V,VV>& p)
      {
	function_requires< ConvertibleConcept<V,value_type> >();
	domain_traits<likelihood_tag,domain_type,value_type>::assign_sub
	  (l_,value_type(p.value_cast(domain_type())));
	validator_type::is_valid(l_,domain_type());
	return *this;
      }
      
      /// Multiplication assignment operator.
      template <typename D, typename V, typename VV>
      likelihood& operator *= (const likelihood<D,V,VV>& l)
      {
	function_requires< ConvertibleConcept<V,value_type> >();
	domain_traits<likelihood_tag,domain_type,value_type>::assign_mpy
	  (l_,value_type(l.value_cast(domain_type())));
	validator_type::is_valid(l_,domain_type());
	return *this;
      }
      /**
       * @brief Multiplication assignment operator.
       *
       * Multiply a likelihood by a value of type T.  Note that type T
       * must be convertible to the @c value_type.  Furthermore, @c t
       * is assumed to be in the linear domain; it will be converted
       * to the appropriate domain as required.
       */
      template <typename T>
      likelihood& operator *= (const T& t)
      {
	function_requires< ConvertibleConcept<T,value_type> >();
	value_type domain_t
	  (domain_traits<likelihood_tag,domain_type,value_type>::
	   transform_domain(linear_domain(),t));
	domain_traits<likelihood_tag,domain_type,value_type>::
	  assign_mpy(l_,domain_t);
	validator_type::is_valid(l_,domain_type());
	return *this;
      }
      /// Multiplication assignment operator.
      template <typename D, typename V, typename VV>
      likelihood& operator *= (const probability<D,V,VV>& p)
      {
	function_requires< ConvertibleConcept<V,value_type> >();
	domain_traits<likelihood_tag,domain_type,value_type>::assign_mpy
	  (l_,value_type(p.value_cast(domain_type())));
	validator_type::is_valid(l_,domain_type());
	return *this;
      }
      
      /// Division assignment operator.
      template <typename D, typename V, typename VV>
      likelihood& operator /= (const likelihood<D,V,VV>& l)
      {
	function_requires< ConvertibleConcept<V,value_type> >();
	domain_traits<likelihood_tag,domain_type,value_type>::assign_div
	  (l_,value_type(l.value_cast(domain_type())));
	validator_type::is_valid(l_,domain_type());
	return *this;
      }
      /**
       * @brief Division assignment operator.
       *
       * Divide a likelihood by a value of type T.  Note that type T
       * must be convertible to the @c value_type.  Furthermore, @c t
       * is assumed to be in the linear domain; it will be converted
       * to the appropriate domain as required.
       */
      template <typename T>
      likelihood& operator /= (const T& t)
      {
	function_requires< ConvertibleConcept<T,value_type> >();
	value_type domain_t
	  (domain_traits<likelihood_tag,domain_type,value_type>::
	   transform_domain(linear_domain(),t));
	domain_traits<likelihood_tag,domain_type,value_type>::
	  assign_div(l_,domain_t);
	validator_type::is_valid(l_,domain_type());
	return *this;
      }
      /// Division assignment operator.
      template <typename D, typename V, typename VV>
      likelihood& operator /= (const probability<D,V,VV>& p)
      {
	function_requires< ConvertibleConcept<V,value_type> >();
	domain_traits<likelihood_tag,domain_type,value_type>::assign_div
	  (l_,value_type(p.value_cast(domain_type())));
	validator_type::is_valid(l_,domain_type());
	return *this;
      }
      //@}

      /// Unary plus operator.
      likelihood operator + () const { return *this; }

      /// Cast to another domain.
      template <typename D>
      likelihood<D,value_type,validator_type> domain_cast (D) const
      { return likelihood<D,value_type,validator_type>(value_cast(D())); }

      /// Cast the internal value to another domain.
      template <typename D>
      value_type value_cast (D) const
      {
	return domain_traits<likelihood_tag,D,value_type>::
	  transform_domain(domain_type(),l_);
      }

    private:
      value_type l_;
    };

    /// @ingroup casts
    //@{
    /**
     * @brief Cast domain of operations.
     *
     * @param l likelihood
     *
     * This function creates a new probability object as a copy of @p
     * l but cast into the domain specified by the template argument
     * @c TargetDomain.  Appropriate domain types are linear_domain
     * and log_domain.
     */
    template <typename TargetDomain, typename SourceDomain,
	      typename Value, typename Validator>
    likelihood<TargetDomain,Value,Validator>
    domain_cast (const likelihood<SourceDomain,Value,Validator>& l)
    { return l.domain_cast (TargetDomain()); }
    
    /**
     * @brief Cast the value of a likelihood.
     *
     * @param l likelihood
     *
     * This function creates an object representing only the value of
     * the likelihood @p l, but cast into the domain specified by the
     * template argument @c TargetDomain.  This is useful, for
     * example, to inspect the value of a likelihood object and ensure
     * that the value is represented within a particular domain.  It
     * may also be useful if further calculations must be performed on
     * the value that do not, for example, result in a likelihood.
     * Appropriate domain types are linear_domain and log_domain.
     */
    template <typename TargetDomain, typename SourceDomain,
	      typename Value, typename Validator>
    typename likelihood<TargetDomain,Value,Validator>::value_type
    value_cast (const likelihood<SourceDomain,Value,Validator>& l)
    { return l.value_cast(TargetDomain()); }
    //@}

    /// @ingroup arithmetic
    //@{
    /// Addition of likelihoods.
    template <typename Ldomain, typename Lvalue, typename Lvalidator,
	      typename Rdomain, typename Rvalue, typename Rvalidator>
    likelihood<Ldomain, Lvalue, Lvalidator>
    operator + (const likelihood<Ldomain,Lvalue,Lvalidator>& lhs,
		const likelihood<Rdomain,Rvalue,Rvalidator>& rhs)
    {
      likelihood<Ldomain,Lvalue,Lvalidator> l(lhs);
      l += rhs;
      return l;
    }
    /// Mixed addition of a likelihood and a probability.
    template <typename Ldomain, typename Lvalue, typename Lvalidator,
	      typename Rdomain, typename Rvalue, typename Rvalidator>
    likelihood<Ldomain, Lvalue, Lvalidator>
    operator + (const likelihood<Ldomain,Lvalue,Lvalidator>& lhs,
		const probability<Rdomain,Rvalue,Rvalidator>& rhs)
    {
      likelihood<Ldomain,Lvalue,Lvalidator> l(lhs);
      l += rhs;
      return l;
    }
    /// Mixed addition of a probability and a likelihood.
    template <typename Ldomain, typename Lvalue, typename Lvalidator,
	      typename Rdomain, typename Rvalue, typename Rvalidator>
    likelihood<Ldomain, Lvalue, Lvalidator>
    operator + (const probability<Ldomain,Lvalue,Lvalidator>& lhs,
		const likelihood<Rdomain,Rvalue,Rvalidator>& rhs)
    {
      likelihood<Ldomain,Lvalue,Lvalidator> l(lhs);
      l += rhs;
      return l;
    }

    /// Subtraction of likelihoods.
    template <typename Ldomain, typename Lvalue, typename Lvalidator,
	      typename Rdomain, typename Rvalue, typename Rvalidator>
    likelihood<Ldomain, Lvalue, Lvalidator>
    operator - (const likelihood<Ldomain,Lvalue,Lvalidator>& lhs,
		const likelihood<Rdomain,Rvalue,Rvalidator>& rhs)
    {
      likelihood<Ldomain,Lvalue,Lvalidator> l(lhs);
      l -= rhs;
      return l;
    }

    /// Multiplication of likelihoods.
    template <typename Ldomain, typename Lvalue, typename Lvalidator,
	      typename Rdomain, typename Rvalue, typename Rvalidator>
    likelihood<log_domain, Lvalue, Lvalidator>
    operator * (const likelihood<Ldomain,Lvalue,Lvalidator>& lhs,
		const likelihood<Rdomain,Rvalue,Rvalidator>& rhs)
    {
      likelihood<log_domain, Lvalue, Lvalidator> p(lhs);
      p *= rhs;
      return p;
    }
    /// Mixed multiplication of a likelihood and a probability.
    template <typename Ldomain, typename Lvalue, typename Lvalidator,
	      typename Rdomain, typename Rvalue, typename Rvalidator>
    likelihood<log_domain, Lvalue, Lvalidator>
    operator * (const likelihood<Ldomain,Lvalue,Lvalidator>& lhs,
		const probability<Rdomain,Rvalue,Rvalidator>& rhs)
    {
      likelihood<log_domain, Lvalue, Lvalidator> p(lhs);
      p *= rhs;
      return p;
    }
    /// Mixed multiplication of a probability and a likelihood.
    template <typename Ldomain, typename Lvalue, typename Lvalidator,
	      typename Rdomain, typename Rvalue, typename Rvalidator>
    likelihood<log_domain, Lvalue, Lvalidator>
    operator * (const probability<Ldomain,Lvalue,Lvalidator>& lhs,
		const likelihood<Rdomain,Rvalue,Rvalidator>& rhs)
    {
      likelihood<log_domain, Lvalue, Lvalidator> p(lhs);
      p *= rhs;
      return p;
    }

    /// Division of likelihoods.
    template <typename Ldomain, typename Lvalue, typename Lvalidator,
	      typename Rdomain, typename Rvalue, typename Rvalidator>
    likelihood<log_domain, Lvalue, Lvalidator>
    operator / (const likelihood<Ldomain,Lvalue,Lvalidator>& lhs,
		const likelihood<Rdomain,Rvalue,Rvalidator>& rhs)
    {
      likelihood<log_domain, Lvalue, Lvalidator> p(lhs);
      p /= rhs;
      return p;
    }
    //@}

    /// @ingroup compare
    //@{
    /**
     * @brief Create logical comparison operator functions.
     *
     * This macro simplifies the creation of the necessary logical
     * comparisons between two likelihood quantities as they are all
     * essentially the same, differing only in the likelihood types
     * being compared.
     *
     * Operators include the full range of logical comparisons (@c ==,
     * @c !=, @c <, @c <=, @c >=, @c >).
     */
#define COMPARE(OP)                                                           \
    template <typename Ldomain, typename Lvalue, typename Lvalidator,         \
	      typename Rdomain, typename Rvalue, typename Rvalidator>         \
    bool                                                                      \
    operator OP (const likelihood<Ldomain,Lvalue,Lvalidator>& lhs,            \
		 const likelihood<Rdomain,Rvalue,Rvalidator>& rhs)            \
    { return lhs.value_cast(log_domain()) OP rhs.value_cast(log_domain()); }  \
    template <typename Ldomain, typename Lvalue, typename Lvalidator,         \
	      typename Rdomain, typename Rvalue, typename Rvalidator>         \
    bool                                                                      \
    operator OP (const likelihood<Ldomain,Lvalue,Lvalidator>& lhs,            \
		 const probability<Rdomain,Rvalue,Rvalidator>& rhs)           \
    { return lhs.value_cast(log_domain()) OP rhs.value_cast(log_domain()); }  \
    template <typename Ldomain, typename Lvalue, typename Lvalidator,         \
	      typename Rdomain, typename Rvalue, typename Rvalidator>         \
    bool                                                                      \
    operator OP (const probability<Ldomain,Lvalue,Lvalidator>& lhs,           \
		 const likelihood<Rdomain,Rvalue,Rvalidator>& rhs)            \
    { return lhs.value_cast(log_domain()) OP rhs.value_cast(log_domain()); }

    COMPARE(==)
    COMPARE(!=)
    COMPARE(<)
    COMPARE(<=)
    COMPARE(>=)
    COMPARE(>)

#undef COMPARE

    /**
     * @brief Create logical comparison operator functions.
     *
     * This macro simplifies the creation of the necessary logical
     * comparisons between a likelihood quantity and another type as
     * they are all essentially the same, differing only in the types
     * being compared.
     *
     * Operators include the full range of logical comparisons (@c ==,
     * @c !=, @c <, @c <=, @c >=, @c >).
     */
#define COMPARE_T(OP)                                                         \
    template <typename Domain,typename Value,typename Validator,typename T>   \
    bool                                                                      \
    operator OP (const likelihood<Domain,Value,Validator>& lhs, const T& rhs) \
    {                                                                         \
      function_requires< ConvertibleConcept<T,Value> >();                     \
      return lhs.value_cast(linear_domain()) OP rhs;                          \
    }                                                                         \
    template <typename Domain,typename Value,typename Validator,typename T>   \
    bool                                                                      \
    operator OP (const T& lhs, const likelihood<Domain,Value,Validator>& rhs) \
    {                                                                         \
      function_requires< ConvertibleConcept<T,Value> >();                     \
      return lhs OP rhs.value_cast(linear_domain());                          \
    }

    COMPARE_T(==)
    COMPARE_T(!=)
    COMPARE_T(<)
    COMPARE_T(<=)
    COMPARE_T(>=)
    COMPARE_T(>)

#undef COMPARE_T
    //@}

    /// @ingroup functions
    //@{
      /**
       * @brief Power function of likelihoods.
       *
       * Note that likelihoods raised to powers that are not natural
       * numbers make little sense in the context of this library, as
       * the result is no longer a likelihood.  Consequently, this
       * power function is only valid for integral exponents.
       */
    template <typename Domain, typename Value, typename Validator,
	      typename Integer>
    likelihood<Domain, Value, Validator>
    pow (const likelihood<Domain,Value,Validator>& base, Integer n)
    {
      function_requires< boost::IntegerConcept<Integer> >();
      return likelihood<Domain,Value,Validator>
	(domain_traits<likelihood_tag,Domain,Value>::
	 pow(base.value_cast(Domain()), n));
    }
    //@}

  } // namespace probabilities

} // namespace boost

namespace std
{

  /**
   * @brief Specialization of @c std::numeric_limits for likelihoods.
   *
   * In almost all instances, the functions and values encapsulated
   * for @c std::numeric_limits<boost::probabilities::likelihood> are
   * simply delegated to the corresponding functions and values for
   * the underlying @c value_type.  The following points are worthy of
   * note.
   *
   * @li @c is_signed is false regardless of the @c value_type as
   * likelihoods are considered to be proportional to probabilities
   * with a positive constant of proportionality.
   *
   * @li @c min() returns the value of @c
   * std::numeric_limits<Value>::min() for any domain.  For types
   * without denormalization, this corresponds to the minimum finite
   * value representable by the internal type; for types with
   * denormalization this corresponds to the minimum positive
   * normalized value representable by the internal type.  This seems
   * to be the most appropriate interpretation of the intent of @c
   * std:numeric_limits<>::min().
   *
   * @li @c max() returns the value of @c
   * std::numeric_limits<Value>::max() for any domain.  For types
   * without denormalization, this corresponds to the maximum finite
   * value representable by the internal type; for types with
   * denormalization this corresponds to the maximum positive
   * normalized value representable by the internal type.  This seems
   * to be the most appropriate interpretation of the intent of @c
   * std:numeric_limits<>::max().  Note that this behavior is unlike
   * the specialization for the boost::probabilities::probability
   * class, which instead returns unity (1) as a consequence of the
   * closed interval for probabilities.
   */
  template <typename Domain, typename Value>
  struct numeric_limits< boost::probabilities::likelihood<Domain,Value> >
  {
    static const bool is_specialized = true;

    static Value min() throw() { return numeric_limits<Value>::min(); }
    static Value max() throw() { return numeric_limits<Value>::max(); }

    static const int digits = numeric_limits<Value>::digits;
    static const int digits10 = numeric_limits<Value>::digits10;
    static const bool is_signed = false;
    static const bool is_integer = numeric_limits<Value>::is_integer;
    static const bool is_exact = numeric_limits<Value>::is_exact;
    static const int radix = numeric_limits<Value>::radix;
    static Value epsilon() throw() { return numeric_limits<Value>::epsilon(); }
    static Value round_error() throw()
    { return numeric_limits<Value>::round_error(); }

    static const int min_exponent = numeric_limits<Value>::min_exponent;
    static const int min_exponent10 = numeric_limits<Value>::min_exponent10;
    static const int max_exponent = numeric_limits<Value>::max_exponent;
    static const int max_exponent10 = numeric_limits<Value>::max_exponent10;

    static const bool has_infinity = numeric_limits<Value>::has_infinity;
    static const bool has_quiet_NaN = numeric_limits<Value>::has_quiet_NaN;
    static const bool has_signaling_NaN
    = numeric_limits<Value>::has_signaling_NaN;
    static const float_denorm_style has_denorm
    = numeric_limits<Value>::has_denorm;
    static const bool has_denorm_loss = numeric_limits<Value>::has_denorm_loss;

    static Value infinity() throw()
    { return numeric_limits<Value>::infinity(); }
    static Value quiet_NaN() throw()
    { return numeric_limits<Value>::quiet_NaN(); }
    static Value signaling_NaN() throw()
    { return numeric_limits<Value>::signaling_NaN(); }
    static Value denorm_min() throw()
    { return numeric_limits<Value>::denorm_min(); }

    static const bool is_iec559 = numeric_limits<Value>::is_iec559;
    static const bool is_bounded = numeric_limits<Value>::is_bounded;
    static const bool is_modulo = numeric_limits<Value>::is_modulo;

    static const bool traps = numeric_limits<Value>::traps;
    static const bool tinyness_before = numeric_limits<Value>::tinyness_before;
    static const float_round_style round_style
    = numeric_limits<Value>::round_style;
  };

} // namespace std

#endif
