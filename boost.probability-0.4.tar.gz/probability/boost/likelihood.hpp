/* -*- C++ -*-
 * $Id: likelihood.hpp,v 1.1 2007/03/26 23:50:43 brook Exp $
 */

/*
 * Copyright (c) 2007 Brook Milligan.
 * Distributed under the Boost Software License, Version 1.0. (See
 * accompanying file LICENSE_1_0.txt or copy at
 * http://www.boost.org/LICENSE_1_0.txt)
 */

/**
 * @file likelihood.hpp
 * @brief Definition of the default likelihood classes.
 */

#ifndef BOOST_LIKELIHOOD_HPP
#define BOOST_LIKELIHOOD_HPP

#include "boost/likelihoods.hpp"

namespace boost
{

  /**
   * @brief Default likelihood class.
   *
   * Many applications do not require the full capability of
   * specifying the underlying value type for likelihoods.  Instead,
   * the convenience of a simple definition based on a double value
   * type directly within the boost namespace is paramount.  This
   * typedef provides that capability.
   */
  typedef probabilities::likelihood<probabilities::linear_domain> likelihood;

  /**
   * @brief Default ln(likelihood) class.
   *
   * Many applications do not require the full capability of
   * specifying the underlying value type for likelihoods.  Instead,
   * the convenience of a simple definition based on a double value
   * type directly within the boost namespace is paramount.  This
   * typedef provides that capability.
   */
  typedef probabilities::likelihood<probabilities::log_domain> log_likelihood;

} // namespace boost

#endif
