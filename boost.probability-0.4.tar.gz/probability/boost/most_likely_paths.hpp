/*
 * $Id: most_likely_paths.hpp,v 1.3 2007/10/18 02:24:24 brook Exp $
 */

/*
 * Copyright (c) 2007 Brook Milligan.
 * Distributed under the Boost Software License, Version 1.0. (See
 * accompanying file LICENSE_1_0.txt or copy at
 * http://www.boost.org/LICENSE_1_0.txt)
 */

/**
 * @file most_likely_paths.hpp
 * @brief Most likely paths graph algorithm.
 */

#ifndef BOOST_MOST_LIKELY_PATHS_HPP
#define BOOST_MOST_LIKELY_PATHS_HPP

#include <boost/probability.hpp>
#include <boost/graph/dag_shortest_paths.hpp>

namespace boost
{

  namespace probabilities
  {

    namespace detail
    {

      template <typename T, typename U>
      struct mpy
      {
	T operator () (const T& a, const U& b) const { return a * b; }
      };

    } // namespace detail

    /// Most likely paths algorithm.
    template <typename VertexListGraph, typename WeightMap,
	      typename DistanceMap, typename PredecessorMap, typename ColorMap,
	      typename IndexMap>
    inline void
    most_likely_paths
    (const VertexListGraph& g,
     typename graph_traits<VertexListGraph>::vertex_descriptor s,
     WeightMap weight, DistanceMap distance, PredecessorMap pred,
     ColorMap color, IndexMap id)
    {
      // XXX - assert that the graph is directed...

      typedef typename boost::property_traits<DistanceMap>::value_type
	distance_type;
      typedef typename boost::property_traits<WeightMap>::value_type
	weight_type;

      typedef std::greater<distance_type> compare_type;
      typedef detail::mpy<distance_type,weight_type> combine_type;

      distance_type identity
	(probability<linear_domain,typename distance_type::value_type>(1));
      distance_type infinity
	(probability<linear_domain,typename distance_type::value_type>(0));

      boost::dag_shortest_paths
	(g, s, weight_map(weight).distance_map(distance)
	 .predecessor_map(pred).color_map(color)
	 .distance_compare(compare_type()).distance_combine(combine_type())
	 .distance_zero(identity).distance_inf(infinity).vertex_index_map(id)
	 );
    }

    namespace detail
    {

      template <typename VertexListGraph,
		typename WeightMap, typename DistanceMap, typename IndexMap,
		typename Param, typename Tag, typename Rest>
      inline void
      dispatch
      (const VertexListGraph& g,
       typename graph_traits<VertexListGraph>::vertex_descriptor s,
       WeightMap weight, DistanceMap distance, IndexMap id,
       const bgl_named_params<Param,Tag,Rest>& params)
      {
	typedef typename property_traits<WeightMap>::value_type T;
	typename std::vector<T>::size_type n;
	n = is_default_param(distance) ? num_vertices(g) : 1;
	std::vector<T> distance_map(n);

	most_likely_paths
	  (g, s,
	   choose_const_pmap(get_param(params, edge_weight), g, edge_weight),
	   choose_param(distance, make_iterator_property_map
			(distance_map.begin(), id, distance_map[0])),
	   get_param(params, vertex_predecessor),
	   get_param(params, vertex_color),
	   id
	   );
      }

    } // namespace detail

    /**
     * @brief Most likely paths graph algorithm.
     *
     * @param g Directed acyclic vertex list graph.
     * @param s Source vertex.
     * @param params Named parameters.
     *
     * This algorithm identifies the most likely paths originating
     * from a specific vertex and traversing through a directed
     * acyclic graph.
     *
     * The set of named parameters may include any of the following.
     *
     * @li @b IN: @c weight_map(WeightMap @c w_map)
     *
     * The weight or ``length'' of each edge in the graph. The type @c
     * WeightMap must be a model of Readable Property Map.  The edge
     * descriptor type of the graph needs to be usable as the key type
     * for the weight map.  The value type for the map must be
     * Multiplyable with the value type of the distance map.  Because
     * quantities are combined multiplicatively along each path, edge
     * weights must represent conditional probabilities or conditional
     * likelihoods.
     *
     * Default: @c get(edge_weight,g)
     *
     * @li @b UTIL/OUT: @c distance_map(DistanceMap @c d_map)
     *
     * The most likely path weight from the source vertex s to each
     * vertex in the graph g is recorded in this property map.  The
     * most likely path weight is the product of the edge weights
     * along the most likely path.  The type @c DistanceMap must be a
     * model of Read/Write Property Map.  The vertex descriptor type
     * of the graph needs to be usable as the key type of the distance
     * map.  The value type of the distance map must be constructible
     * from a boost::probabilities::probability.
     *
     * Default: @c iterator_property_map created from a @c std::vector
     * of the @c WeightMap's value type of size @c num_vertices(g) and
     * using the @c i_map for the index map.
     *
     * @li @b OUT: @c predecessor_map(PredecessorMap @c p_map)
     *
     * The predecessor map records the edges in the minimum spanning
     * tree representing the most likely paths emanating from the
     * source vertex @c s.  Upon completion of the algorithm, the
     * edges @c (p[u],u) for all @c u in @c V are in the minimum
     * spanning tree.  If @c p[u] @c = @c u then @c u is either the
     * source vertex or a vertex that is not reachable from the
     * source.  The @c PredecessorMap type must be a Read/Write
     * Property Map with key and vertex types the same as the vertex
     * descriptor type of the graph.
     *
     * Default: as implemented by @c dag_shortest_paths().
     *
     * @li @b UTIL/OUT: @c color_map(ColorMap @c c_map)
     *
     * This is used during the execution of the algorithm to mark the
     * vertices.  The vertices start out white and become gray when
     * they are inserted in the queue.  They then turn black when they
     * are removed from the queue.  At the end of the algorithm,
     * vertices reachable from the source vertex will have been
     * colored black.  All other vertices will still be white.  The
     * type @c ColorMap must be a model of Read/Write Property Map.  A
     * vertex descriptor must be usable as the key type of the map,
     * and the value type of the map must be a model of Color Value.
     *
     * Default: as implemented by @c dag_shortest_paths().
     *
     * @li @b IN: @c vertex_index_map(VertexIndexMap @c i_map)
     *
     * This maps each vertex to an integer in the range @c [0, @c
     * num_vertices(g)). This is necessary for efficient updates of
     * the heap data structure when an edge is relaxed. The type @c
     * VertexIndexMap must be a model of Readable Property Map. The
     * value type of the map must be an integer type. The vertex
     * descriptor type of the graph needs to be usable as the key type
     * of the map.
     *
     * Default: @c get(vertex_index,g).  Note: if you use this
     * default, make sure your graph has an internal @c vertex_index
     * property. For example, @c adjacenty_list with @c
     * VertexList=listS does not have an internal @c vertex_index
     * property.
     *
     * The most likely paths algorithm is implemented in terms of the
     * DAG shortest paths algorithm, @c dag_shortest_paths(), provided
     * by the Boost Graph Library.
     */
    template <typename VertexListGraph,
	      typename Param, typename Tag, typename Rest>
    inline void
    most_likely_paths
    (const VertexListGraph& g,
     typename graph_traits<VertexListGraph>::vertex_descriptor s,
     const bgl_named_params<Param,Tag,Rest>& params)
    {
      detail::dispatch
	(g, s,
	 choose_const_pmap(get_param(params, edge_weight), g, edge_weight),
	 get_param(params, vertex_distance),
	 choose_const_pmap(get_param(params, vertex_index), g, vertex_index),
	 params);
    }

  } // namespace probabilities

} // namespace boost

#endif
