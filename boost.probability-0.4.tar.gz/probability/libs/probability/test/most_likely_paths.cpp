/*
 * $Id: test.cpp,v 1.2 2007/09/18 13:31:23 brook Exp $
 */

/*
 * Copyright (c) 2007 Brook Milligan.
 * Distributed under the Boost Software License, Version 1.0. (See
 * accompanying file LICENSE_1_0.txt or copy at
 * http://www.boost.org/LICENSE_1_0.txt)
 */

// Boost Probability
#include <boost/most_likely_paths.hpp>
#include <boost/probability.hpp>
#include <boost/likelihood.hpp>

// Boost Graph
#include <boost/graph/adjacency_list.hpp>

// Boost.MPL
#include <boost/mpl/list.hpp>
#include <boost/mpl/insert_range.hpp>

#if defined STANDALONE
#define BOOST_TEST_DYN_LINK
#endif
#if BOOST_1_33
#define BOOST_AUTO_TEST_MAIN
#include <boost/test/auto_unit_test.hpp>
#else
#define BOOST_TEST_MODULE most_likely_paths tests
#include <boost/test/unit_test.hpp>
#endif

// Boost.Test
#include <boost/test/test_tools.hpp>
#include <boost/test/test_case_template.hpp>

BOOST_TEST_DONT_PRINT_LOG_VALUE (likelihood);
BOOST_TEST_DONT_PRINT_LOG_VALUE (probability);

typedef boost::probabilities::linear_domain linear_domain;
typedef boost::probabilities::log_domain log_domain;

typedef boost::mpl::list
<
  boost::probabilities::probability<linear_domain,double>,
  boost::probabilities::probability<linear_domain,float>,
  boost::probabilities::probability<log_domain,double>,
  boost::probabilities::probability<log_domain,float>
> probability_types;
typedef boost::mpl::end<probability_types>::type probability_types_end;

typedef boost::mpl::list
<
  boost::probabilities::likelihood<linear_domain,double>,
  boost::probabilities::likelihood<linear_domain,float>,
  boost::probabilities::likelihood<log_domain,double>,
  boost::probabilities::likelihood<log_domain,float>
> likelihood_types;
typedef boost::mpl::end<likelihood_types>::type likelihood_types_end;

typedef boost::mpl::insert_range<probability_types,
				 probability_types_end,
				 likelihood_types>::type all_types;

typedef enum { external_distance_map, internal_distance_map }
distance_map_type;

template <typename Distance, typename Weight>
void
test_most_likely_paths (Distance d, Weight w,
			distance_map_type distance_map_tag
			= external_distance_map)
{
  typedef Distance distance_type;
  typedef typename distance_type::domain_type distance_domain_type;
  typedef typename distance_type::value_type distance_value_type;

  typedef Weight weight_type;
  typedef typename weight_type::domain_type weight_domain_type;
  typedef typename weight_type::value_type weight_value_type;

  typedef boost::probabilities::probability<linear_domain,distance_value_type>
    linear_distance_type;
  typedef boost::probabilities::probability<linear_domain,weight_value_type>
    linear_weight_type;

  // XXX - simplify the calculation of expected distances

#define DISTANCE(w)                                                           \
    (distance_type(linear_distance_type(1))                                   \
     * weight_type(linear_weight_type(w)))
#define DISTANCE2(w1,w2)                                                      \
    (distance_type(linear_distance_type(1))                                   \
     * weight_type(linear_weight_type(w1))                                    \
     * weight_type(linear_weight_type(w2)))

  distance_type expected_distances[] =
    {
      DISTANCE(0),
      DISTANCE(1),
      DISTANCE(0.2),
      DISTANCE(0.6),
      DISTANCE2(0.2, 0.4),
      DISTANCE(0.6)
    };

#undef DISTANCE2
#undef DISTANCE

  typedef boost::adjacency_list<boost::vecS, boost::vecS, boost::directedS, 
    boost::property<boost::vertex_distance_t, distance_type>,
    boost::property<boost::edge_weight_t, weight_type> > graph_type;

  graph_type g(6);
  enum verts { r, s, t, u, v, x };
  add_edge(r, s, weight_type(linear_weight_type(0.5)), g);
  add_edge(r, t, weight_type(linear_weight_type(0.3)), g);
  add_edge(s, t, weight_type(linear_weight_type(0.2)), g);
  add_edge(s, u, weight_type(linear_weight_type(0.6)), g);
  add_edge(t, u, weight_type(linear_weight_type(0.7)), g);
  add_edge(t, v, weight_type(linear_weight_type(0.4)), g);
  add_edge(t, x, weight_type(linear_weight_type(1)), g);
  add_edge(u, v, weight_type(linear_weight_type(0.1)), g);
  add_edge(u, x, weight_type(linear_weight_type(1)), g);
  add_edge(v, x, weight_type(linear_weight_type(0.1)), g);

  typename boost::property_map<graph_type, boost::vertex_distance_t>::type
    d_map = get(boost::vertex_distance, g);

  switch (distance_map_tag)
    {
      /*
       * XXX - Use the external distance map for storing the distances
       * calculated by the algorithm.
       */
    case external_distance_map:
      most_likely_paths(g, s, distance_map(d_map));
      break;
      /*
       * XXX - Use an internally constructed distance map for storing
       * the distances calculated by the algorithm.  This tests that
       * the dispatch function correctly constructs its own internal
       * read/writable distance map.
       */
    case internal_distance_map:
      typename boost::property_map<graph_type, boost::edge_weight_t>::type
	w_map = get(boost::edge_weight, g);
      most_likely_paths(g, s, weight_map(w_map));
      break;
    }

  int i (0);
  typename boost::graph_traits<graph_type>::vertex_iterator vi , vi_end;
  for (tie(vi, vi_end) = vertices(g); vi != vi_end; ++vi, ++i)
    {
      switch (distance_map_tag)
	{
	  /*
	   * XXX - Since the algorithm used the external distance map
	   * the calculated distances may be compared with those
	   * expected.
	   */
	case external_distance_map:
	  BOOST_CHECK_EQUAL (d_map[*vi], expected_distances[i]);
	  break;
	  /*
	   * XXX - Since the algorithm used an internal distance map,
	   * the external one remains full of default-constructed
	   * values.
	   */
	case internal_distance_map:
	  BOOST_CHECK_EQUAL (d_map[*vi], distance_type());
	  break;
	}
    }
}

BOOST_AUTO_TEST_CASE_TEMPLATE (test_likelihood, T, all_types)
{
  boost::likelihood distance;
  T t;
  test_most_likely_paths(distance, t);
}

BOOST_AUTO_TEST_CASE_TEMPLATE (test_probability, T, probability_types)
{
  boost::probability distance;
  T t;
  test_most_likely_paths(distance, t);
}

BOOST_AUTO_TEST_CASE (test_internal_distance_map)
{
  boost::likelihood distance;
  boost::probability weight;
  test_most_likely_paths(distance, weight, internal_distance_map);
}
