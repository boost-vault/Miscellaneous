/*
 * $Id: test.cpp,v 1.1 2007/06/27 18:15:22 brook Exp $
 */

/*
 * Copyright (c) 2007 Brook Milligan.
 * Distributed under the Boost Software License, Version 1.0. (See
 * accompanying file LICENSE_1_0.txt or copy at
 * http://www.boost.org/LICENSE_1_0.txt)
 */

#if defined _MSC_VER
#  pragma warning(disable: 4100) // 'b' : unreferenced formal parameter
#endif

#include <cmath>
#include <iomanip>
#include <iostream>
#include <string>
#include <vector>
#include <boost/date_time/posix_time/posix_time_types.hpp>
#include <boost/program_options.hpp>
#include <boost/likelihoods.hpp>
#include <boost/probabilities.hpp>

namespace po = boost::program_options;

typedef double value_type;

typedef boost::probabilities::linear_domain linear_domain;
typedef boost::probabilities::log_domain log_domain;

typedef boost::probabilities::probability_tag probability_tag;
typedef boost::probabilities::likelihood_tag likelihood_tag;

typedef boost::probabilities::null_validator<value_type> null_validator;
typedef boost::probabilities::range_validator<likelihood_tag,value_type>
likelihood_range_validator;
typedef boost::probabilities::range_validator<probability_tag,value_type>
probability_range_validator;

typedef boost::probabilities::likelihood
<linear_domain,value_type,null_validator> likelihood_unvalidated;
typedef boost::probabilities::probability
<linear_domain,value_type,null_validator> probability_unvalidated;

typedef boost::probabilities::likelihood
<linear_domain,value_type,likelihood_range_validator> likelihood_validated;
typedef boost::probabilities::probability
<linear_domain,value_type,probability_range_validator> probability_validated;

typedef std::vector<int> observations;

// report data type
const char* type_name (double) { return "double"; }
const char* type_name (likelihood_unvalidated) { return "likelihood"; }
template <typename Domain, typename Value, typename Validator>
const char* type_name (boost::probabilities::
		       likelihood<Domain,Value,Validator>)
{ return "likelihood"; }
template <typename Domain, typename Value, typename Validator>
const char* type_name (boost::probabilities::
		       probability<Domain,Value,Validator>)
{ return "probability"; }

// report validator type
const char* validator_name (double) { return "null"; }
const char* validator_name (likelihood_unvalidated) { return "null"; }
const char* validator_name (likelihood_validated) { return "range"; }
const char* validator_name (probability_unvalidated) { return "null"; }
const char* validator_name (probability_validated) { return "range"; }

// create a series of numbers of replicates
std::vector<int>
create_n ()
{
  std::vector<int> n_;
  n_.push_back (10);
  n_.push_back (20);
  n_.push_back (50);
  n_.push_back (90);
  n_.push_back (100);
  n_.push_back (10);
  n_.push_back (20);
  n_.push_back (50);
  n_.push_back (90);
  n_.push_back (100);
  n_.push_back (10);
  n_.push_back (20);
  n_.push_back (50);
  n_.push_back (90);
  n_.push_back (100);
  return n_;
}

// create a series of observations
observations
create_observations (int m)
{
  observations obs;
  for (int i = 0; i <= m; ++i)
    obs.push_back(i % 10);   // limit observations to the range [0, 9]
  return obs;
}

// generic, but simple, factorial
template <typename IntegralType>
IntegralType
factorial (IntegralType i)
{
  if (i)
    return i * factorial(i-1);
  return IntegralType(1);
}

// generic, but simple, Poisson distribution
template <typename Value, typename IntegralType>
Value
poisson (IntegralType i)
{
  const value_type lambda (2);
  return Value(exp(-lambda) * pow(lambda, i) / factorial(i));
}

template <typename Accumulator, typename Value>
class benchmark
{
public:
  boost::posix_time::time_duration operator () (int m) const
  {
    observations obs(create_observations(m));

    boost::posix_time::ptime start
      (boost::date_time::microsec_clock<boost::posix_time::ptime>::
       universal_time());
    Accumulator l;
    for (observations::const_iterator i = obs.begin(); i != obs.end(); ++i)
      l *= poisson<Value>(*i);
    boost::posix_time::ptime stop
      (boost::date_time::microsec_clock<boost::posix_time::ptime>::
       universal_time());

    return stop - start;
  }
};

template <typename Accumulator, typename Value>
class benchmarks
{
public:
  boost::posix_time::time_duration operator () (int n, int m) const
  {
    boost::posix_time::time_duration sum;
    for (int i = 0; i < n; ++i)
      {
	benchmark<Accumulator,Value> b;
	boost::posix_time::time_duration t (b(m));
	sum = sum + t;
      }
    return sum / n;
  }
};

template <typename Accumulator, typename Value>
class benchmark_comparison
{
public:
  benchmark_comparison (int n, int m, int width)
  {
    std::cout << std::fixed << std::setprecision(3);

    benchmarks<Accumulator,Value> b;
    boost::posix_time::time_duration mean (b(n,m));
    std::cout << std::setw(width) << n << "  "
	      << std::setw(width) << m << "  "
	      << std::setw(width) << type_name(Accumulator()) << "  "
	      << std::setw(width) << type_name(Value()) << "  "
	      << std::setw(width) << validator_name(Accumulator()) << "  "
	      << std::setw(width) << mean.total_microseconds()
	      << std::endl;
  }
};

template <typename Accumulator, typename Value>
class benchmark_test
{
public:
  benchmark_test (std::vector<int> n, int m, int width)
  {
    for (std::vector<int>::const_iterator i = n.begin(); i != n.end(); ++i)
      benchmark_comparison<Accumulator,Value>
	(*i, m, width);
  }
};

int
main (int argc, char* argv[])
{
  // default values
  int m (10);

				// declare the supported options.
  po::options_description desc("Allowed options");
  desc.add_options()
    ("help", "produce help message")
    ("slow", "run a complete (and slow) test")
    ;

  bool unrecognized_options(false);
  po::variables_map vm;
  try { po::store(po::parse_command_line(argc, argv, desc), vm); }
  catch (...) { unrecognized_options = true; }
  po::notify(vm);    

				// handle command line options
  if (vm.count("help") || unrecognized_options)
    {
      std::cout << desc << std::endl;
      return 1;
    }
  if (vm.count("slow"))
    m = 100000;

  const int width (11);

  std::vector<int> n (create_n());
  
  std::cout << std::setw(width) << "reps" << "  "
	    << std::setw(width) << "iterations" << "  "
	    << std::setw(width) << "lhs" << "  "
	    << std::setw(width) << "rhs" << "  "
	    << std::setw(width) << "validator" << "  "
	    << std::setw(width) << "time"
	    << std::endl;

  benchmark_test<double,double>(n, m, width);

  benchmark_test<probability_unvalidated,double>(n, m, width);
  benchmark_test<probability_unvalidated,probability_unvalidated>(n, m, width);

  benchmark_test<likelihood_unvalidated,double>(n, m, width);
  benchmark_test<likelihood_unvalidated,probability_unvalidated>(n, m, width);

  benchmark_test<probability_validated,double>(n, m, width);
  benchmark_test<probability_validated,probability_validated>(n, m, width);

  benchmark_test<likelihood_validated,double>(n, m, width);
  benchmark_test<likelihood_validated,probability_validated>(n, m, width);

  return 0;
}
