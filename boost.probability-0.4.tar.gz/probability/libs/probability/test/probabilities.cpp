/*
 * $Id: test.cpp,v 1.12 2007/10/18 05:04:29 brook Exp $
 */

/*
 * Copyright (c) 2007 Brook Milligan.
 * Distributed under the Boost Software License, Version 1.0. (See
 * accompanying file LICENSE_1_0.txt or copy at
 * http://www.boost.org/LICENSE_1_0.txt)
 */

#if defined _MSC_VER
#  pragma warning(disable: 4100) // 'b' : unreferenced formal parameter
#endif

#include "boost/probability.hpp"

#include <iostream>

typedef boost::probability probability;
typedef boost::log_probability log_probability;

typedef boost::probabilities::linear_domain linear_domain;
typedef boost::probabilities::log_domain log_domain;

typedef boost::probabilities::probability_tag type_tag;
typedef boost::probabilities::range_validator <type_tag,double>
range_validator;

typedef boost::probabilities::probability<linear_domain,double,range_validator>
      probability_validated;
typedef boost::probabilities::probability<log_domain,double,range_validator>
      log_probability_validated;

typedef boost::probabilities::out_of_range<probability::value_type>
out_of_range;

template <typename Domain, typename Value, typename Validator>
std::ostream& operator << (std::ostream&, const boost::probabilities::
			   probability<Domain,Value,Validator>&);

#if defined STANDALONE
#define BOOST_TEST_DYN_LINK
#endif
#if BOOST_1_33
#define BOOST_AUTO_TEST_MAIN
#include <boost/test/auto_unit_test.hpp>
#else
#define BOOST_TEST_MODULE probability tests
#include <boost/test/unit_test.hpp>
#endif
#include <boost/test/output_test_stream.hpp>

/*
 * XXX - theoretically, the operator<<(std::ostream&, ...) functions
 * declared above shoule allow the BOOST_CHECK macros to log error
 * messages appropriately.  This is apparently not the case here,
 * however.  Consequently, the following prevents the log output from
 * being generated and eliminates the errors, which all have to do
 * with the compiler not finding a match for operator<<().
 */

#define XXX_PREVENT_LOG_OUTPUT 1

#if XXX_PREVENT_LOG_OUTPUT
BOOST_TEST_DONT_PRINT_LOG_VALUE (probability);
BOOST_TEST_DONT_PRINT_LOG_VALUE (log_probability);
BOOST_TEST_DONT_PRINT_LOG_VALUE (probability_validated);
BOOST_TEST_DONT_PRINT_LOG_VALUE (log_probability_validated);
#endif

namespace boost
{

  template <typename T>
  class ValidatorCheck
  {
    BOOST_CLASS_REQUIRE(T, probabilities, ValidatorConcept);
  };

  // XXX - unused variable errors
  BOOST_AUTO_TEST_CASE (test_validator_concept)
  {
    typedef probability::value_type value_type;
    typedef linear_domain domain;
    ValidatorCheck< probabilities::validator_archetype<value_type> > c;
    ValidatorCheck< probabilities::null_validator<value_type> > null;
    ValidatorCheck< probabilities::range_validator
      <probabilities::probability_tag,value_type> > range;
    ValidatorCheck< probabilities::truncating_validator
      <probabilities::probability_tag,value_type> > truncate;
  }

} // namespace boost

BOOST_AUTO_TEST_CASE (test_sizeof)
{
  typedef struct { probability first; probability second; } probability_pair;
  typedef struct { probability::value_type first;
    probability::value_type second; } value_pair;
  const int n (10);

  BOOST_CHECK_EQUAL(sizeof(probability), sizeof(probability::value_type));
  BOOST_CHECK_EQUAL(sizeof(log_probability), sizeof(probability::value_type));
  BOOST_CHECK_EQUAL(sizeof(probability), sizeof(log_probability));
  BOOST_CHECK_EQUAL(sizeof(probability_pair), sizeof(value_pair));
  BOOST_CHECK_EQUAL(sizeof(probability[n]),
		    sizeof(probability::value_type[n]));
  BOOST_CHECK_EQUAL(sizeof(probability[n][n]),
		    sizeof(probability::value_type[n][n]));
}

BOOST_AUTO_TEST_CASE (test_default_constructors)
{
  probability p;
  log_probability log_p;
}

BOOST_AUTO_TEST_CASE (test_explicit_constructors)
{
  probability p_int (1);
  log_probability log_p_int (0);

  probability p_double (1.0);
  log_probability log_p_double (0.0);

  probability p_linear (1, linear_domain());
  log_probability log_p_linear (1, linear_domain());

  probability p_log (0, log_domain());
  log_probability log_p_log (0, log_domain());
}

BOOST_AUTO_TEST_CASE (test_exceptions)
{
  typedef boost::probabilities::probability_tag type_tag;

  // default validator: no out_of_range exceptions
  probability(-1);
  log_probability(1);

  // range validator
  {
    typedef boost::probabilities::range_validator <type_tag,double> validator;
    typedef boost::probabilities::probability<linear_domain,double,validator>
      probability;

    BOOST_REQUIRE_THROW(probability(-1), out_of_range);
  }

  {
    typedef boost::probabilities::range_validator<type_tag,double> validator;
    typedef boost::probabilities::probability<log_domain,double,validator>
      probability;

    BOOST_REQUIRE_THROW(probability(1), out_of_range);
  }

  // truncating validator (default epsilon)
  {
    typedef boost::probabilities::truncating_validator<type_tag,double>
      validator;
    typedef boost::probabilities::probability<linear_domain,double,validator>
      probability;

    BOOST_REQUIRE_THROW(probability(-1), out_of_range);
  }

  {
    typedef boost::probabilities::truncating_validator<type_tag,double>
      validator;
    typedef boost::probabilities::probability<log_domain,double,validator>
      probability;

    BOOST_REQUIRE_THROW(probability(1), out_of_range);
  }
}

BOOST_AUTO_TEST_CASE (test_extreme_values)
{
  probability p0 (0);
  probability p1 (1);

  log_probability log_p0 (-std::numeric_limits<log_probability>::max());
  log_probability log_p1 (0);
}

BOOST_AUTO_TEST_CASE (test_domain_change_constructors)
{
  probability p;
  log_probability log_p;

  probability p_linear (log_p);
  log_probability p_log (p);
}

BOOST_AUTO_TEST_CASE (test_copy_constructor)
{
  probability p1 (0.1);
  probability p2 (p1);

  BOOST_CHECK_EQUAL(p1, p2);

  log_probability log_p1 (0.1, linear_domain());
  log_probability log_p2 (log_p1);

  BOOST_CHECK_EQUAL(log_p1, log_p2);
}

BOOST_AUTO_TEST_CASE (test_assignment)
{
  probability p1 (0.1);
  probability p2 (0.2);

  p1 = p2;
  BOOST_CHECK_EQUAL(p1, p2);

  log_probability log_p1 (0.1, linear_domain());
  log_probability log_p2 (0.2, linear_domain());

  log_p1 = log_p2;
  BOOST_CHECK_EQUAL(log_p1, log_p2);
}

BOOST_AUTO_TEST_CASE (test_value_casts)
{
  probability p;
  log_probability log_p;

  BOOST_CHECK_EQUAL(p.value_cast(linear_domain()), 1);
  BOOST_CHECK_EQUAL(p.value_cast(log_domain()), 0);

  BOOST_CHECK_EQUAL(log_p.value_cast(linear_domain()), 1);
  BOOST_CHECK_EQUAL(log_p.value_cast(log_domain()), 0);

  BOOST_CHECK_EQUAL(boost::probabilities::value_cast<linear_domain>(p), 1);
  BOOST_CHECK_EQUAL(boost::probabilities::value_cast<log_domain>(p), 0);

  BOOST_CHECK_EQUAL(boost::probabilities::value_cast<linear_domain>(log_p), 1);
  BOOST_CHECK_EQUAL(boost::probabilities::value_cast<log_domain>(log_p), 0);
}

BOOST_AUTO_TEST_CASE (test_domain_casts)
{
  probability p;
  log_probability log_p;

  probability p1 (1);
  log_probability log_p1 (0);

  BOOST_CHECK_EQUAL(p.domain_cast(linear_domain()), p1);
  BOOST_CHECK_EQUAL(p.domain_cast(log_domain()), log_p1);

  BOOST_CHECK_EQUAL(log_p.domain_cast(linear_domain()), p1);
  BOOST_CHECK_EQUAL(log_p.domain_cast(log_domain()), log_p1);

  BOOST_CHECK_EQUAL(boost::probabilities::domain_cast<linear_domain>(p), p1);
  BOOST_CHECK_EQUAL(boost::probabilities::domain_cast<log_domain>(p), log_p1);

  BOOST_CHECK_EQUAL
    (boost::probabilities::domain_cast<linear_domain>(log_p), p1);
  BOOST_CHECK_EQUAL(boost::probabilities::domain_cast<log_domain>(log_p),
		    log_p1);
}

BOOST_AUTO_TEST_CASE (test_logical_comparison)
{
  probability p;
  log_probability log_p;

  p == p;
  p == log_p;
  p == 1;
  p == 1.0;
  1 == p;
  1.0 == p;

  p != p;
  p != log_p;
  p != 1;
  p != 1.0;
  1 != p;
  1.0 != p;

  log_p == log_p;
  log_p == p;
  log_p == 1;
  log_p == 1.0;
  1 == log_p;
  1.0 == log_p;

  log_p != log_p;
  log_p != p;
  log_p != 1;
  log_p != 1.0;
  1 != log_p;
  1.0 != log_p;

  p < p;
  p < log_p;
  p < 1;
  p < 1.0;
  1 < p;
  1.0 < p;

  p <= p;
  p <= log_p;
  p <= 1;
  p <= 1.0;
  1 <= p;
  1.0 <= p;

  p >= p;
  p >= log_p;
  p >= 1;
  p >= 1.0;
  1 >= p;
  1.0 >= p;

  p > p;
  p > log_p;
  p > 1;
  p > 1.0;
  1 > p;
  1.0 > p;

  log_p < log_p;
  log_p < p;
  log_p < 1;
  log_p < 1.0;
  1 < log_p;
  1.0 < log_p;

  log_p <= log_p;
  log_p <= p;
  log_p <= 1;
  log_p <= 1.0;
  1 <= log_p;
  1.0 <= log_p;

  log_p >= log_p;
  log_p >= p;
  log_p >= 1;
  log_p >= 1.0;
  1 >= log_p;
  1.0 >= log_p;

  log_p > log_p;
  log_p > p;
  log_p > 1;
  log_p > 1.0;
  1 > log_p;
  1.0 > log_p;
}

BOOST_AUTO_TEST_CASE (test_logical_comparisons_1)
{
  probability p1 (0.25);
  probability p2 (0.25);
  probability p3 (0.5);

  log_probability p1_log (0.25, linear_domain());
  log_probability p2_log (0.25, linear_domain());
  log_probability p3_log (0.5, linear_domain());

  BOOST_CHECK_EQUAL(p1, p2);
  BOOST_CHECK(p1 == p2);
  BOOST_CHECK(p1 != p3);
  BOOST_CHECK(p1 <  p3);
  BOOST_CHECK(p1 <= p2);
  BOOST_CHECK(p1 <= p3);
  BOOST_CHECK(p3 >= p1);
  BOOST_CHECK(p2 >= p1);
  BOOST_CHECK(p3 >  p1);

  BOOST_CHECK_EQUAL(p1_log, p2_log);
  BOOST_CHECK(p1_log == p2_log);
  BOOST_CHECK(p1_log != p3_log);
  BOOST_CHECK(p1_log <  p3_log);
  BOOST_CHECK(p1_log <= p2_log);
  BOOST_CHECK(p1_log <= p3_log);
  BOOST_CHECK(p3_log >= p1_log);
  BOOST_CHECK(p2_log >= p1_log);
  BOOST_CHECK(p3_log >  p1_log);

  BOOST_CHECK_EQUAL(p1, p2_log);
  BOOST_CHECK(p1 == p2_log);
  BOOST_CHECK(p1 != p3_log);
  BOOST_CHECK(p1 <  p3_log);
  BOOST_CHECK(p1 <= p2_log);
  BOOST_CHECK(p1 <= p3_log);
  BOOST_CHECK(p3 >= p1_log);
  BOOST_CHECK(p2 >= p1_log);
  BOOST_CHECK(p3 >  p1_log);
}

BOOST_AUTO_TEST_CASE (test_unary_operators)
{
  probability p;
  log_probability log_p;

  BOOST_CHECK_EQUAL(+p, p);
  BOOST_CHECK_EQUAL(+log_p, log_p);
}

BOOST_AUTO_TEST_CASE (test_arithmetic_assignment)
{
  probability::value_type x1 (0.25);
  probability::value_type x2 (0.50);
  probability::value_type x3 (0.75);

  probability::value_type ln_x1 (log(x1));
  probability::value_type ln_x2 (log(x2));
  probability::value_type ln_x3 (log(x3));

  probability p1 (x1);
  probability p2 (x2);
  probability p3 (x3);
  probability sum (x1 + x2);
  probability difference (x2 - x1);
  probability product (x1 * x2);
  probability quotient (x1 / x2);

  BOOST_CHECK_EQUAL (probability(p1) += p2, sum);
  probability(p3) += p3;	// XXX - no exception, unvalidated

  BOOST_CHECK_EQUAL (probability(p2) -= p1, difference);
  probability(p1) -= p2;	// XXX - no exception, unvalidated

  BOOST_CHECK_EQUAL (probability(p1) *= p2, product);

  BOOST_CHECK_EQUAL (probability(p1) /= p2, quotient);
  probability(p2) /= p1;	// XXX - no exception, unvalidated

  log_probability log_p1 (x1, linear_domain());
  log_probability log_p2 (x2, linear_domain());
  log_probability log_sum (x1 + x2, linear_domain());
  log_probability log_difference (x2 - x1, linear_domain());
  log_probability log_product (log(x1) + log(x2));
  log_probability log_quotient (log(x1) - log(x2));

  BOOST_CHECK_EQUAL (log_probability(p1) += log_p2, log_sum);
  BOOST_CHECK_EQUAL (log_probability(p2) -= log_p1, log_difference);
  BOOST_CHECK_EQUAL (log_probability(p1) *= log_p2, log_product);
  BOOST_CHECK_EQUAL (log_probability(p1) /= log_p2, log_quotient);

  BOOST_CHECK_EQUAL(boost::probabilities::
		    value_cast<linear_domain>(probability(x1) += p1), x1 + x1);
  BOOST_CHECK_EQUAL(boost::probabilities::
		    value_cast<linear_domain>(probability(x1) += p2), x1 + x2);
  BOOST_CHECK_EQUAL(boost::probabilities::
		    value_cast<linear_domain>(probability(x2) += p1), x2 + x1);
  BOOST_CHECK_EQUAL(boost::probabilities::
		    value_cast<log_domain>(log_probability(ln_x1) += log_p1),
		    ln_x1 + log(2));
  BOOST_CHECK_EQUAL(boost::probabilities::
		    value_cast<log_domain>(log_probability(ln_x1) += log_p2),
		    ln_x2 + log1p(exp(ln_x1-ln_x2)));
  BOOST_CHECK_EQUAL(boost::probabilities::
		    value_cast<log_domain>(log_probability(ln_x2) += log_p1),
		    ln_x2 + log1p(exp(ln_x1-ln_x2)));

  BOOST_CHECK_EQUAL(boost::probabilities::
		    value_cast<linear_domain>(probability(x1) -= p1), x1 - x1);
  BOOST_CHECK_EQUAL(boost::probabilities::
		    value_cast<linear_domain>(probability(x2) -= p1), x2 - x1);
  BOOST_CHECK_EQUAL(boost::probabilities::
		    value_cast<log_domain>(log_probability(ln_x1) -= log_p1),
		    -std::numeric_limits<log_probability>::infinity());
  BOOST_CHECK_EQUAL(boost::probabilities::
		    value_cast<log_domain>(log_probability(ln_x2) -= log_p1),
		    ln_x2 + log1p(-exp(ln_x1-ln_x2)));

  BOOST_CHECK_EQUAL(boost::probabilities::
		    value_cast<linear_domain>(probability(x1) += x1), x1 + x1);
  BOOST_CHECK_EQUAL(boost::probabilities::
		    value_cast<linear_domain>(probability(x1) += x2), x1 + x2);
  BOOST_CHECK_EQUAL(boost::probabilities::
		    value_cast<linear_domain>(probability(x2) += x1), x2 + x1);
  BOOST_CHECK_EQUAL(boost::probabilities::
		    value_cast<log_domain>(log_probability(ln_x1) += x1),
		    ln_x1 + log(2));
  BOOST_CHECK_EQUAL(boost::probabilities::
		    value_cast<log_domain>(log_probability(ln_x1) += x2),
		    ln_x2 + log1p(exp(ln_x1-ln_x2)));
  BOOST_CHECK_EQUAL(boost::probabilities::
		    value_cast<log_domain>(log_probability(ln_x2) += x1),
		    ln_x2 + log1p(exp(ln_x1-ln_x2)));

  BOOST_CHECK_EQUAL(boost::probabilities::
		    value_cast<linear_domain>(probability(x1) -= x1), x1 - x1);
  BOOST_CHECK_EQUAL(boost::probabilities::
		    value_cast<linear_domain>(probability(x2) -= x1), x2 - x1);
  BOOST_CHECK_EQUAL(boost::probabilities::
		    value_cast<log_domain>(log_probability(ln_x1) -= x1),
		    -std::numeric_limits<log_probability>::infinity());
  BOOST_CHECK_EQUAL(boost::probabilities::
		    value_cast<log_domain>(log_probability(ln_x2) -= x1),
		    ln_x2 + log1p(-exp(ln_x1-ln_x2)));

  BOOST_CHECK_EQUAL(boost::probabilities::
		    value_cast<linear_domain>(probability(x1) *= x2), x1 * x2);
  BOOST_CHECK_EQUAL(boost::probabilities::
		    value_cast<log_domain>(log_probability(ln_x1) *= x2),
		    ln_x1 + log(x2));

  BOOST_CHECK_EQUAL(boost::probabilities::
		    value_cast<linear_domain>(probability(x1) /= x2), x1 / x2);
  BOOST_CHECK_EQUAL(boost::probabilities::
		    value_cast<log_domain>(log_probability(ln_x1) /= x2),
		    ln_x1 - log(x2));
}

BOOST_AUTO_TEST_CASE (test_arithmetic_assignment_validated)
{
  typedef boost::probabilities::probability_tag type_tag;

  typedef boost::probabilities::range_validator <type_tag,double> validator;
  typedef boost::probabilities::probability<linear_domain,double,validator>
    probability;
  typedef boost::probabilities::probability<log_domain,double,validator>
    log_probability;

  probability::value_type x1 (0.25);
  probability::value_type x2 (0.50);
  probability::value_type x3 (0.75);

  probability p1 (x1);
  probability p2 (x2);
  probability p3 (x3);
  probability sum (x1 + x2);
  probability difference (x2 - x1);
  probability product (x1 * x2);
  probability quotient (x1 / x2);

  BOOST_CHECK_EQUAL (probability(p1) += p2, sum);
  BOOST_REQUIRE_THROW (probability(p3) += p3, out_of_range);

  BOOST_CHECK_EQUAL (probability(p2) -= p1, difference);
  BOOST_REQUIRE_THROW (probability(p1) -= p2, out_of_range);

  BOOST_CHECK_EQUAL (probability(p1) *= p2, product);

  BOOST_CHECK_EQUAL (probability(p1) /= p2, quotient);
  BOOST_REQUIRE_THROW (probability(p2) /= p1, out_of_range);

  log_probability log_p1 (x1, linear_domain());
  log_probability log_p2 (x2, linear_domain());
  log_probability log_sum (x1 + x2, linear_domain());
  log_probability log_difference (x2 - x1, linear_domain());
  log_probability log_product (log(x1) + log(x2));
  log_probability log_quotient (log(x1) - log(x2));

  BOOST_CHECK_EQUAL (log_probability(p1) += log_p2, log_sum);
  BOOST_CHECK_EQUAL (log_probability(p2) -= log_p1, log_difference);
  BOOST_CHECK_EQUAL (log_probability(p1) *= log_p2, log_product);
  BOOST_CHECK_EQUAL (log_probability(p1) /= log_p2, log_quotient);
}

BOOST_AUTO_TEST_CASE (test_mixed_arithmetic_assignment)
{
  const int ten (10);

  probability::value_type x1 (0.25);
  probability::value_type x2 (0.50);

  probability p1 (x1);
  probability p2 (x2);

  log_probability log_sum (x1 + x2, linear_domain());
  log_probability log_difference (x2 - x1, linear_domain());
  log_probability log_product (log(x1) + log(x2));
  log_probability log_quotient (log(x1) - log(x2));

  probability() += +ten;	// XXX - no exception, unvalidated
  probability() += -ten;	// XXX - no exception, unvalidated

  probability() -= +ten;	// XXX - no exception, unvalidated
  probability() -= -ten;	// XXX - no exception, unvalidated

  probability() *= +ten;	// XXX - no exception, unvalidated
  probability() *= -ten;	// XXX - no exception, unvalidated

  probability() /= -ten;	// XXX - no exception, unvalidated

  BOOST_CHECK_EQUAL (log_probability(p1) += p2, log_sum);
  BOOST_CHECK_EQUAL (log_probability(p2) -= p1, log_difference);
  BOOST_CHECK_EQUAL (log_probability(p1) *= p2, log_product);
  BOOST_CHECK_EQUAL (log_probability(p1) /= p2, log_quotient);
}

BOOST_AUTO_TEST_CASE (test_mixed_arithmetic_assignment_validated)
{
  typedef boost::probabilities::probability_tag type_tag;

  typedef boost::probabilities::range_validator <type_tag,double> validator;
  typedef boost::probabilities::probability<linear_domain,double,validator>
    probability;
  typedef boost::probabilities::probability<log_domain,double,validator>
    log_probability;

  const int ten (10);

  probability::value_type x1 (0.25);
  probability::value_type x2 (0.50);

  probability p1 (x1);
  probability p2 (x2);

  log_probability log_sum (x1 + x2, linear_domain());
  log_probability log_difference (x2 - x1, linear_domain());
  log_probability log_product (log(x1) + log(x2));
  log_probability log_quotient (log(x1) - log(x2));

  BOOST_REQUIRE_THROW (probability() += +ten, out_of_range);
  BOOST_REQUIRE_THROW (probability() += -ten, out_of_range);

  BOOST_REQUIRE_THROW (probability() -= +ten, out_of_range);
  BOOST_REQUIRE_THROW (probability() -= -ten, out_of_range);

  BOOST_REQUIRE_THROW (probability() *= +ten, out_of_range);
  BOOST_REQUIRE_THROW (probability() *= -ten, out_of_range);

  BOOST_REQUIRE_THROW (probability() /= -ten, out_of_range);

  BOOST_CHECK_EQUAL (log_probability(p1) += p2, log_sum);
  BOOST_CHECK_EQUAL (log_probability(p2) -= p1, log_difference);
  BOOST_CHECK_EQUAL (log_probability(p1) *= p2, log_product);
  BOOST_CHECK_EQUAL (log_probability(p1) /= p2, log_quotient);
}

BOOST_AUTO_TEST_CASE (test_arithmetic)
{
  probability::value_type x1 (0.25);
  probability::value_type x2 (0.50);

  probability p1 (x1);
  probability p2 (x2);
  probability sum (x1 + x2);
  probability difference (x2 - x1);
  probability product (x1 * x2);
  probability quotient (x1 / x2);

  BOOST_CHECK_EQUAL (p1 + p2, sum);
  BOOST_CHECK_EQUAL (p2 - p1, difference);
  BOOST_CHECK_EQUAL (p1 * p2, product);
  BOOST_CHECK_EQUAL (p1 / p2, quotient);

  log_probability log_p1 (x1, linear_domain());
  log_probability log_p2 (x2, linear_domain());
  log_probability log_sum (exp(log(x1)) + exp(log(x2)), linear_domain());
  log_probability log_difference (x2 - x1, linear_domain());
  log_probability log_product (log(x1) + log(x2));
  log_probability log_quotient (log(x1) - log(x2));

  BOOST_CHECK_EQUAL (log_p1 + log_p2, log_sum);
  BOOST_CHECK_EQUAL (log_p2 - log_p1, difference);
  BOOST_CHECK_EQUAL (log_p1 * log_p2, log_product);
  BOOST_CHECK_EQUAL (log_p1 / log_p2, log_quotient);
}

BOOST_AUTO_TEST_CASE (test_mixed_arithmetic)
{
  probability::value_type x1 (0.25);
  probability::value_type x2 (0.50);

  probability p1 (x1);
  probability p2 (x2);
  probability sum (x1 + x2);
  probability difference (x2 - x1);
  probability product (x1 * x2);
  probability quotient (x1 / x2);

  log_probability log_p1 (x1, linear_domain());
  log_probability log_p2 (x2, linear_domain());
  log_probability log_sum (x1 + x2, linear_domain());
  log_probability log_difference (x2 - x1, linear_domain());
  log_probability log_product (log(x1) + log(x2));
  log_probability log_quotient (log(x1) - log(x2));

  BOOST_CHECK_EQUAL (p1 + log_p2, sum);
  BOOST_CHECK_EQUAL (log_p1 + p2, sum);
  BOOST_CHECK_EQUAL (p2 - log_p1, difference);
  BOOST_CHECK_EQUAL (log_p2 - p1, difference);

  BOOST_CHECK_EQUAL (p1 * log_p2, log_product);
  BOOST_CHECK_EQUAL (log_p1 * p2, log_product);
  BOOST_CHECK_EQUAL (p1 / log_p2, log_quotient);
  BOOST_CHECK_EQUAL (log_p1 / p2, log_quotient);
}

BOOST_AUTO_TEST_CASE (test_functions)
{
  int n (3);

  probability::value_type x (0.5);
  probability::value_type ln_x (log(x));

  probability p (x);
  BOOST_CHECK_EQUAL
    (boost::probabilities::value_cast<linear_domain>(pow(p, n)), pow(x,n));

  log_probability ln_p (ln_x);
  BOOST_CHECK_EQUAL
    (boost::probabilities::value_cast<log_domain>(pow(ln_p, n)), n * ln_x);
}

BOOST_AUTO_TEST_CASE (test_epsilon)
{
  typedef boost::probabilities::probability_tag type_tag;
  typedef probability::value_type value_type;
  typedef boost::probabilities::truncating_validator<type_tag,value_type>
    validator;

  value_type epsilon (0.001);

  validator::epsilon (epsilon);
  BOOST_CHECK_EQUAL(validator::epsilon(), epsilon);
  BOOST_CHECK_EQUAL(validator::epsilon(0), epsilon);
  BOOST_CHECK_EQUAL(validator::epsilon(), 0);
}

BOOST_AUTO_TEST_CASE (test_boundary_tolerance)
{
  typedef boost::probabilities::probability_tag type_tag;

  // null validator
  {
    typedef boost::probabilities::null_validator<double> validator;
    typedef boost::probabilities::probability<linear_domain,double,validator>
      probability;

    probability(-1);		// invalid but unchecked
  }

  {
    typedef boost::probabilities::null_validator<double> validator;
    typedef boost::probabilities::probability<log_domain,double,validator>
      probability;

    probability(1);		// invalid but unchecked
  }

  // truncating validator (large epsilon)
  {
    typedef linear_domain domain;
    typedef probability::value_type value_type;

    typedef boost::probabilities::truncating_validator<type_tag,value_type>
      validator;
    typedef boost::probabilities::probability<domain,value_type,validator>
      probability;

    value_type epsilon (0.25);
    value_type delta (epsilon);
    value_type x0 (0 - delta);
    value_type x1 (1 + delta);

    probability p0 (0);
    probability p1 (1);

    validator::epsilon (epsilon); // extend tolerance to avoid exceptions
    BOOST_CHECK(probability(x0) == p0);	// XXX - why not BOOST_CHECK_EQUAL?
    BOOST_CHECK(probability(x1) == p1);	// XXX - why not BOOST_CHECK_EQUAL?
  }

  {
    typedef log_domain domain;
    typedef log_probability::value_type value_type;

    typedef boost::probabilities::truncating_validator<type_tag,value_type>
      validator;
    typedef boost::probabilities::probability<domain,value_type,validator>
      probability;

    value_type epsilon (0.25);
    value_type delta (epsilon);
    value_type x1 (1 + delta);

    probability p0 (0, linear_domain());
    probability p1 (1, linear_domain());

    validator::epsilon (epsilon); // extend tolerance to avoid exceptions
    BOOST_CHECK(probability(x1, linear_domain()) == p1); // XXX - why not BOOST_CHECK_EQUAL?
  }
}

BOOST_AUTO_TEST_CASE (test_numeric_limits)
{
  log_probability::value_type min
    (std::numeric_limits<log_probability::value_type>::min());

  BOOST_CHECK(std::numeric_limits<probability>::is_specialized);
  BOOST_CHECK(!std::numeric_limits<probability>::is_signed);
  BOOST_CHECK_EQUAL(std::numeric_limits<probability>::min(), min);
  BOOST_CHECK_EQUAL(std::numeric_limits<probability>::max(), 1);

  BOOST_CHECK(std::numeric_limits<log_probability>::is_specialized);
  BOOST_CHECK(!std::numeric_limits<log_probability>::is_signed);
  BOOST_CHECK_EQUAL(std::numeric_limits<log_probability>::min(), min);
  BOOST_CHECK_EQUAL(std::numeric_limits<log_probability>::max(), 1);
}

BOOST_AUTO_TEST_CASE (test_output)
{
  boost::test_tools::output_test_stream stream;
  stream << probability();
  BOOST_CHECK(stream.is_equal("1", true));
  stream << log_probability();
  BOOST_CHECK(stream.is_equal("1", true));
}

template <typename Domain, typename Value, typename Validator>
std::ostream&
operator << (std::ostream& s, const boost::probabilities::
	     probability<Domain,Value,Validator>& p)
{
  return s << boost::probabilities::value_cast<linear_domain>(p);
}
