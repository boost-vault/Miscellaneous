/*
 * $Id: test.cpp,v 1.2 2007/06/27 20:29:52 brook Exp $
 */

/*
 * Copyright (c) 2007 Brook Milligan.
 * Distributed under the Boost Software License, Version 1.0. (See
 * accompanying file LICENSE_1_0.txt or copy at
 * http://www.boost.org/LICENSE_1_0.txt)
 */

/*
 * The purpose of this test case is simply to exercise the concept
 * checks on the validator types.  To do so, instances of the
 * ValidatorCheck class (defined below) must be instantiated.
 * Likewise, a probabilities::probability object is instantiated with
 * the validator_archetype to verify that it satisfies the
 * requirements.  None of these instantiated objects need to be used
 * for the purposes of concept checking.  Consequently, some compilers
 * will generate 'unused variable' warnings for this code.
 */

#if defined _MSC_VER
#  pragma warning(disable: 4100) // 'b' : unreferenced formal parameter
#endif

#include <boost/probability.hpp>

#if defined STANDALONE
#define BOOST_TEST_DYN_LINK
#endif
#if BOOST_1_33
#define BOOST_AUTO_TEST_MAIN
#include <boost/test/auto_unit_test.hpp>
#else
#define BOOST_TEST_MODULE likelihood tests
#include <boost/test/unit_test.hpp>
#endif

namespace boost
{

  template <typename T>
  class ValidatorCheck
  {
    BOOST_CLASS_REQUIRE(T, probabilities, ValidatorConcept);
  };

} // namespace boost

BOOST_AUTO_TEST_CASE(test_archetype)
{
  typedef double value_type;
  typedef boost::probabilities::linear_domain linear_domain;
  typedef boost::probabilities::validator_archetype<value_type> validator;
  boost::ValidatorCheck<validator> c;

  // test whether the archetype satisfies the probability type requirements
  boost::probabilities::probability<linear_domain,value_type,validator> p;
}

BOOST_AUTO_TEST_CASE(test_range_validator)
{
  typedef boost::probabilities::probability_tag type_tag;
  typedef boost::probabilities::range_validator<type_tag> validator;
  boost::ValidatorCheck<validator> c;
}

BOOST_AUTO_TEST_CASE(test_null_validator)
{
  typedef boost::probabilities::null_validator<> validator;
  boost::ValidatorCheck<validator> c;
}

BOOST_AUTO_TEST_CASE(test_truncating_validator)
{
  typedef boost::probabilities::probability_tag type_tag;
  typedef boost::probabilities::truncating_validator<type_tag> validator;
  boost::ValidatorCheck<validator> c;
}
