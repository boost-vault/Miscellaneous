/*
 * $Id: test.cpp,v 1.10 2007/10/18 03:26:17 brook Exp $
 */

/*
 * Copyright (c) 2007 Brook Milligan.
 * Distributed under the Boost Software License, Version 1.0. (See
 * accompanying file LICENSE_1_0.txt or copy at
 * http://www.boost.org/LICENSE_1_0.txt)
 */

#if defined _MSC_VER
#  pragma warning(disable: 4100) // 'b' : unreferenced formal parameter
#endif

#include <boost/likelihood.hpp>

#include <iostream>
#include <boost/probability.hpp>

typedef boost::likelihood likelihood;
typedef boost::log_likelihood log_likelihood;

typedef boost::probability probability;
typedef boost::log_probability log_probability;

typedef boost::probabilities::linear_domain linear_domain;
typedef boost::probabilities::log_domain log_domain;

typedef boost::probabilities::likelihood_tag type_tag;
typedef boost::probabilities::range_validator <type_tag,double>
range_validator;

typedef boost::probabilities::likelihood<linear_domain,double,range_validator>
      likelihood_validated;
typedef boost::probabilities::likelihood<log_domain,double,range_validator>
      log_likelihood_validated;

typedef boost::probabilities::out_of_range<probability::value_type>
out_of_range;

template <typename Domain, typename Value, typename Validator>
static std::ostream& operator << (std::ostream&, const boost::probabilities::
				  likelihood<Domain,Value,Validator>&);
template <typename Domain, typename Value, typename Validator>
static std::ostream& operator << (std::ostream&, const boost::probabilities::
				  probability<Domain,Value,Validator>&);

#if defined STANDALONE
#define BOOST_TEST_DYN_LINK
#endif
#if BOOST_1_33
#define BOOST_AUTO_TEST_MAIN
#include <boost/test/auto_unit_test.hpp>
#else
#define BOOST_TEST_MODULE likelihood tests
#include <boost/test/unit_test.hpp>
#endif
#include <boost/test/output_test_stream.hpp>

/*
 * XXX - theoretically, the operator<<(std::ostream&, ...) functions
 * declared above shoule allow the BOOST_CHECK macros to log error
 * messages appropriately.  This is apparently not the case here,
 * however.  Consequently, the following prevents the log output from
 * being generated and eliminates the errors, which all have to do
 * with the compiler not finding a match for operator<<().
 */

#define XXX_PREVENT_LOG_OUTPUT 1

#if XXX_PREVENT_LOG_OUTPUT
BOOST_TEST_DONT_PRINT_LOG_VALUE (likelihood);
BOOST_TEST_DONT_PRINT_LOG_VALUE (log_likelihood);
BOOST_TEST_DONT_PRINT_LOG_VALUE (probability);
BOOST_TEST_DONT_PRINT_LOG_VALUE (log_probability);
BOOST_TEST_DONT_PRINT_LOG_VALUE (likelihood_validated);
BOOST_TEST_DONT_PRINT_LOG_VALUE (log_likelihood_validated);
#endif

BOOST_AUTO_TEST_CASE (test_sizeof)
{
  typedef struct { likelihood first; likelihood second; } likelihood_pair;
  typedef struct { likelihood::value_type first;
    likelihood::value_type second; } value_pair;
  const int n (10);

  BOOST_CHECK_EQUAL(sizeof(likelihood), sizeof(likelihood::value_type));
  BOOST_CHECK_EQUAL(sizeof(log_likelihood), sizeof(likelihood::value_type));
  BOOST_CHECK_EQUAL(sizeof(likelihood), sizeof(log_likelihood));
  BOOST_CHECK_EQUAL(sizeof(likelihood_pair), sizeof(value_pair));
  BOOST_CHECK_EQUAL(sizeof(likelihood[n]), sizeof(likelihood::value_type[n]));
  BOOST_CHECK_EQUAL(sizeof(likelihood[n][n]),
		    sizeof(likelihood::value_type[n][n]));
}

BOOST_AUTO_TEST_CASE (test_default_constructors)
{
  likelihood l;
  log_likelihood log_l;
}

BOOST_AUTO_TEST_CASE (test_explicit_constructors)
{
  likelihood l_int (1);
  log_likelihood log_l_int (0);

  likelihood l_double (1.0);
  log_likelihood log_l_double (0.0);

  likelihood p_linear (1, linear_domain());
  log_likelihood log_p_linear (1, linear_domain());

  likelihood p_log (0, log_domain());
  log_likelihood log_p_log (0, log_domain());
}

BOOST_AUTO_TEST_CASE (test_exceptions)
{
  typedef boost::probabilities::likelihood_tag type_tag;

  // default validator: no out_of_range exceptions
  likelihood(-1);
  log_likelihood(1);

  // range validator
  {
    typedef boost::probabilities::range_validator<type_tag,double> validator;
    typedef boost::probabilities::likelihood<linear_domain,double,validator>
      likelihood;

    BOOST_REQUIRE_THROW(likelihood(-1), out_of_range);
  }

  {
    typedef boost::probabilities::range_validator<type_tag,double> validator;
    typedef boost::probabilities::likelihood<log_domain,double,validator>
      likelihood;

    likelihood(1);
  }

  // truncating validator (default epsilon)
  {
    typedef boost::probabilities::truncating_validator<type_tag,double>
      validator;
    typedef boost::probabilities::likelihood<linear_domain,double,validator>
      likelihood;

    BOOST_REQUIRE_THROW(likelihood(-1), out_of_range);
  }

  {
    typedef boost::probabilities::truncating_validator<type_tag,double>
      validator;
    typedef boost::probabilities::likelihood<log_domain,double,validator>
      likelihood;

    likelihood(1);
  }
}

BOOST_AUTO_TEST_CASE (test_extreme_values)
{
  likelihood l0 (0);
  likelihood l1 (std::numeric_limits<likelihood::value_type>::max());

  log_likelihood log_p0 (-std::numeric_limits<log_likelihood>::max());
  log_likelihood log_p1 (std::numeric_limits<log_likelihood>::max());
}

BOOST_AUTO_TEST_CASE (test_domain_change_constructors)
{
  likelihood l;
  log_likelihood log_l;

  likelihood l_linear (log_l);
  log_likelihood l_log (l);
}

BOOST_AUTO_TEST_CASE (test_probability_constructors)
{
  probability p;
  log_probability log_p;

  likelihood l (p);
  log_likelihood log_l (log_p);
}

BOOST_AUTO_TEST_CASE (test_copy_constructor)
{
  likelihood l1 (0.1);
  likelihood l2 (l1);

  BOOST_CHECK_EQUAL(l1, l2);

  log_likelihood log_l1 (0.1, linear_domain());
  log_likelihood log_l2 (log_l1);

  BOOST_CHECK_EQUAL(log_l1, log_l2);
}

BOOST_AUTO_TEST_CASE (test_assignment)
{
  likelihood l1 (0.1);
  likelihood l2 (0.2);

  l1 = l2;
  BOOST_CHECK_EQUAL(l1, l2);

  log_likelihood log_l1 (0.1, linear_domain());
  log_likelihood log_l2 (0.2, linear_domain());

  log_l1 = log_l2;
  BOOST_CHECK_EQUAL(log_l1, log_l2);
}

BOOST_AUTO_TEST_CASE (test_value_casts)
{
  likelihood l;
  log_likelihood log_l;

  boost::probabilities::value_cast<linear_domain>(l);
  boost::probabilities::value_cast<log_domain>(l);

  boost::probabilities::value_cast<linear_domain>(log_l);
  boost::probabilities::value_cast<log_domain>(log_l);

  BOOST_CHECK_EQUAL(boost::probabilities::value_cast<linear_domain>(l), 1);
  BOOST_CHECK_EQUAL(boost::probabilities::value_cast<log_domain>(l), 0);

  BOOST_CHECK_EQUAL(boost::probabilities::value_cast<linear_domain>(log_l), 1);
  BOOST_CHECK_EQUAL(boost::probabilities::value_cast<log_domain>(log_l), 0);
}

BOOST_AUTO_TEST_CASE (test_domain_casts)
{
  likelihood l;
  log_likelihood log_l;

  likelihood l1 (1);
  log_likelihood log_l1 (0);

  BOOST_CHECK_EQUAL(l.domain_cast(linear_domain()), l1);
  BOOST_CHECK_EQUAL(l.domain_cast(log_domain()), log_l1);

  BOOST_CHECK_EQUAL(log_l.domain_cast(linear_domain()), l1);
  BOOST_CHECK_EQUAL(log_l.domain_cast(log_domain()), log_l1);

  BOOST_CHECK_EQUAL(boost::probabilities::domain_cast<linear_domain>(l), l1);
  BOOST_CHECK_EQUAL(boost::probabilities::domain_cast<log_domain>(l), log_l1);

  BOOST_CHECK_EQUAL(boost::probabilities::domain_cast<linear_domain>(log_l), l1);
  BOOST_CHECK_EQUAL(boost::probabilities::domain_cast<log_domain>(log_l), log_l1);
}

BOOST_AUTO_TEST_CASE (test_logical_comparison)
{
  likelihood l;
  log_likelihood log_l;

  l == l;
  l == log_l;
  l == 1;
  l == 1.0;
  1 == l;
  1.0 == l;

  l != l;
  l != log_l;
  l != 1;
  l != 1.0;
  1 != l;
  1.0 != l;

  log_l == log_l;
  log_l == l;
  log_l == 1;
  log_l == 1.0;
  1 == log_l;
  1.0 == log_l;

  log_l != log_l;
  log_l != l;
  log_l != 1;
  log_l != 1.0;
  1 != log_l;
  1.0 != log_l;

  l < l;
  l < log_l;
  l < 1;
  l < 1.0;
  1 < l;
  1.0 < l;

  l <= l;
  l <= log_l;
  l <= 1;
  l <= 1.0;
  1 <= l;
  1.0 <= l;

  l >= l;
  l >= log_l;
  l >= 1;
  l >= 1.0;
  1 >= l;
  1.0 >= l;

  l > l;
  l > log_l;
  l > 1;
  l > 1.0;
  1 > l;
  1.0 > l;

  log_l < log_l;
  log_l < l;
  log_l < 1;
  log_l < 1.0;
  1 < log_l;
  1.0 < log_l;

  log_l <= log_l;
  log_l <= l;
  log_l <= 1;
  log_l <= 1.0;
  1 <= log_l;
  1.0 <= log_l;

  log_l >= log_l;
  log_l >= l;
  log_l >= 1;
  log_l >= 1.0;
  1 >= log_l;
  1.0 >= log_l;

  log_l > log_l;
  log_l > l;
  log_l > 1;
  log_l > 1.0;
  1 > log_l;
  1.0 > log_l;
}

BOOST_AUTO_TEST_CASE (test_logical_comparisons_1)
{
  likelihood l1 (0.25, linear_domain());
  likelihood l2 (0.25, linear_domain());
  likelihood l3 (0.5, linear_domain());

  log_likelihood l1_log (0.25, linear_domain());
  log_likelihood l2_log (0.25, linear_domain());
  log_likelihood l3_log (0.5, linear_domain());

  BOOST_CHECK_EQUAL(l1, l2);
  BOOST_CHECK(l1 == l2);
  BOOST_CHECK(l1 != l3);
  BOOST_CHECK(l1 <  l3);
  BOOST_CHECK(l1 <= l2);
  BOOST_CHECK(l1 <= l3);
  BOOST_CHECK(l3 >= l1);
  BOOST_CHECK(l2 >= l1);
  BOOST_CHECK(l3 >  l1);

  BOOST_CHECK_EQUAL(l1_log, l2_log);
  BOOST_CHECK(l1_log == l2_log);
  BOOST_CHECK(l1_log != l3_log);
  BOOST_CHECK(l1_log <  l3_log);
  BOOST_CHECK(l1_log <= l2_log);
  BOOST_CHECK(l1_log <= l3_log);
  BOOST_CHECK(l3_log >= l1_log);
  BOOST_CHECK(l2_log >= l1_log);
  BOOST_CHECK(l3_log >  l1_log);

  BOOST_CHECK_EQUAL(l1, l2_log);
  BOOST_CHECK(l1 == l2_log);
  BOOST_CHECK(l1 != l3_log);
  BOOST_CHECK(l1 <  l3_log);
  BOOST_CHECK(l1 <= l2_log);
  BOOST_CHECK(l1 <= l3_log);
  BOOST_CHECK(l3 >= l1_log);
  BOOST_CHECK(l2 >= l1_log);
  BOOST_CHECK(l3 >  l1_log);
}

BOOST_AUTO_TEST_CASE (test_logical_comparisons_probability)
{
  likelihood l1 (0.25);
  likelihood l2 (0.25);
  likelihood l3 (0.5);

  probability p1 (0.25);
  probability p2 (0.25);
  probability p3 (0.5);

  BOOST_CHECK_EQUAL(l1, p2);
  BOOST_CHECK(l1 == p2);
  BOOST_CHECK(l1 != p3);
  BOOST_CHECK(l1 <  p3);
  BOOST_CHECK(l1 <= p2);
  BOOST_CHECK(l1 <= p3);
  BOOST_CHECK(l3 >= p1);
  BOOST_CHECK(l2 >= p1);
  BOOST_CHECK(l3 >  p1);

  BOOST_CHECK_EQUAL(p1, p2);
  BOOST_CHECK(p1 == l2);
  BOOST_CHECK(p1 != l3);
  BOOST_CHECK(p1 <  l3);
  BOOST_CHECK(p1 <= l2);
  BOOST_CHECK(p1 <= l3);
}

BOOST_AUTO_TEST_CASE (test_logical_comparisons_log_probability)
{
  log_likelihood l1 (0.25, linear_domain());
  log_likelihood l2 (0.25, linear_domain());
  log_likelihood l3 (0.5, linear_domain());

  log_probability p1 (0.25, linear_domain());
  log_probability p2 (0.25, linear_domain());
  log_probability p3 (0.5, linear_domain());

  BOOST_CHECK_EQUAL(l1, p2);
  BOOST_CHECK(l1 == p2);
  BOOST_CHECK(l1 != p3);
  BOOST_CHECK(l1 <  p3);
  BOOST_CHECK(l1 <= p2);
  BOOST_CHECK(l1 <= p3);
  BOOST_CHECK(l3 >= p1);
  BOOST_CHECK(l2 >= p1);
  BOOST_CHECK(l3 >  p1);

  BOOST_CHECK_EQUAL(p1, p2);
  BOOST_CHECK(p1 == l2);
  BOOST_CHECK(p1 != l3);
  BOOST_CHECK(p1 <  l3);
  BOOST_CHECK(p1 <= l2);
  BOOST_CHECK(p1 <= l3);
}

BOOST_AUTO_TEST_CASE (test_unary_operators)
{
  likelihood l;
  log_likelihood log_l;

  BOOST_CHECK_EQUAL((+l).value_cast(linear_domain()),
		    l.value_cast(linear_domain()));
  BOOST_CHECK_EQUAL((+log_l).value_cast(log_domain()),
		    log_l.value_cast(log_domain()));
}

BOOST_AUTO_TEST_CASE (test_arithmetic_assignment)
{
  likelihood::value_type x1 (0.25);
  likelihood::value_type x2 (0.50);

  likelihood l1 (x1);
  likelihood l2 (x2);
  likelihood sum (x1 + x2);
  likelihood difference (x2 - x1);
  likelihood product (x1 * x2);
  likelihood quotient (x1 / x2);

  BOOST_CHECK_EQUAL (likelihood(l1) += l2, sum);
  BOOST_CHECK_EQUAL (likelihood(l2) -= l1, difference);
  likelihood(l1) -= l2;		// XXX - no exception, unvalidated
  BOOST_CHECK_EQUAL (likelihood(l1) *= l2, product);
  BOOST_CHECK_EQUAL (likelihood(l1) /= l2, quotient);

  log_likelihood log_l1 (x1, linear_domain());
  log_likelihood log_l2 (x2, linear_domain());
  log_likelihood log_sum (x1 + x2, linear_domain());
  log_likelihood log_difference (x2 - x1, linear_domain());
  log_likelihood log_product (log(x1) + log(x2));
  log_likelihood log_quotient (log(x1) - log(x2));

  BOOST_CHECK_EQUAL (log_likelihood(l1) += log_l2, log_sum);
  BOOST_CHECK_EQUAL (log_likelihood(l2) -= log_l1, log_difference);
  BOOST_CHECK_EQUAL (log_likelihood(l1) *= log_l2, log_product);
  BOOST_CHECK_EQUAL (log_likelihood(l1) /= log_l2, log_quotient);
}

BOOST_AUTO_TEST_CASE (test_arithmetic_assignment_validated)
{
  typedef boost::probabilities::likelihood_tag type_tag;

  typedef boost::probabilities::range_validator <type_tag,double> validator;
  typedef boost::probabilities::likelihood<linear_domain,double,validator>
    likelihood;
  typedef boost::probabilities::likelihood<log_domain,double,validator>
    log_likelihood;

  likelihood::value_type x1 (0.25);
  likelihood::value_type x2 (0.50);

  likelihood l1 (x1);
  likelihood l2 (x2);
  likelihood sum (x1 + x2);
  likelihood difference (x2 - x1);
  likelihood product (x1 * x2);
  likelihood quotient (x1 / x2);

  BOOST_CHECK_EQUAL (likelihood(l1) += l2, sum);
  BOOST_CHECK_EQUAL (likelihood(l2) -= l1, difference);
  BOOST_REQUIRE_THROW (likelihood(l1) -= l2, out_of_range);
  BOOST_CHECK_EQUAL (likelihood(l1) *= l2, product);
  BOOST_CHECK_EQUAL (likelihood(l1) /= l2, quotient);

  log_likelihood log_l1 (x1, linear_domain());
  log_likelihood log_l2 (x2, linear_domain());
  log_likelihood log_sum (x1 + x2, linear_domain());
  log_likelihood log_difference (x2 - x1, linear_domain());
  log_likelihood log_product (log(x1) + log(x2));
  log_likelihood log_quotient (log(x1) - log(x2));

  BOOST_CHECK_EQUAL (log_likelihood(l1) += log_l2, log_sum);
  BOOST_CHECK_EQUAL (log_likelihood(l2) -= log_l1, log_difference);
  BOOST_CHECK_EQUAL (log_likelihood(l1) *= log_l2, log_product);
  BOOST_CHECK_EQUAL (log_likelihood(l1) /= log_l2, log_quotient);
}

BOOST_AUTO_TEST_CASE (test_arithmetic_assignment_probability)
{
  likelihood::value_type x1 (0.25);
  likelihood::value_type x2 (0.50);

  likelihood l1 (x1);
  likelihood l2 (x2);
  likelihood sum (x1 + x2);
  likelihood difference (x2 - x1);
  likelihood product (x1 * x2);
  likelihood quotient (x1 / x2);

  probability p1 (x1);
  probability p2 (x2);

  log_probability log_p1 (x1, linear_domain());
  log_probability log_p2 (x2, linear_domain());

  BOOST_CHECK_EQUAL (likelihood(l1) += p2, sum);
  BOOST_CHECK_EQUAL (likelihood(l2) -= p1, difference);
  BOOST_CHECK_EQUAL (likelihood(l1) *= p2, product);
  BOOST_CHECK_EQUAL (likelihood(l1) /= p2, quotient);

  BOOST_CHECK_EQUAL (likelihood(l1) += log_p2, sum);
  BOOST_CHECK_EQUAL (likelihood(l2) -= log_p1, difference);
  BOOST_CHECK_EQUAL (likelihood(l1) *= log_p2, product);
  BOOST_CHECK_EQUAL (likelihood(l1) /= log_p2, quotient);

  log_likelihood log_l1 (x1, linear_domain());
  log_likelihood log_l2 (x2, linear_domain());
  log_likelihood log_sum (x1 + x2, linear_domain());
  log_likelihood log_difference (x2 - x1, linear_domain());
  log_likelihood log_product (log(x1) + log(x2));
  log_likelihood log_quotient (log(x1) - log(x2));

  BOOST_CHECK_EQUAL (log_likelihood(l1) += p2, log_sum);
  BOOST_CHECK_EQUAL (log_likelihood(l2) -= p1, log_difference);
  BOOST_CHECK_EQUAL (log_likelihood(l1) *= p2, log_product);
  BOOST_CHECK_EQUAL (log_likelihood(l1) /= p2, log_quotient);

  BOOST_CHECK_EQUAL (log_likelihood(l1) += log_p2, log_sum);
  BOOST_CHECK_EQUAL (log_likelihood(l2) -= log_p1, log_difference);
  BOOST_CHECK_EQUAL (log_likelihood(l1) *= log_p2, log_product);
  BOOST_CHECK_EQUAL (log_likelihood(l1) /= log_p2, log_quotient);
}

BOOST_AUTO_TEST_CASE (test_mixed_arithmetic_assignment)
{
  const int one (1);

  likelihood::value_type x1 (0.25);
  likelihood::value_type x2 (0.50);

  likelihood l1 (x1);
  likelihood l2 (x2);

  log_likelihood log_l1 (x1, linear_domain());
  log_likelihood log_l2 (x2, linear_domain());
  log_likelihood log_sum (x1 + x2, linear_domain());
  log_likelihood log_difference (x2 - x1, linear_domain());
  log_likelihood log_product (log(x1) + log(x2));
  log_likelihood log_quotient (log(x1) - log(x2));

  likelihood(l1) += -one;	// XXX - no exception, unvalidated
  likelihood(l1) -= +one;	// XXX - no exception, unvalidated
  likelihood(l1) *= -one;	// XXX - no exception, unvalidated
  likelihood(l1) /= -one;	// XXX - no exception, unvalidated

  BOOST_CHECK_EQUAL (log_likelihood(l1) += l2, log_sum);
  BOOST_CHECK_EQUAL (log_likelihood(l2) -= l1, log_difference);
  BOOST_CHECK_EQUAL (log_likelihood(l1) *= l2, log_product);
  BOOST_CHECK_EQUAL (log_likelihood(l1) /= l2, log_quotient);
}

BOOST_AUTO_TEST_CASE (test_mixed_arithmetic_assignment_validated)
{
  typedef boost::probabilities::likelihood_tag type_tag;

  typedef boost::probabilities::range_validator <type_tag,double> validator;
  typedef boost::probabilities::likelihood<linear_domain,double,validator>
    likelihood;
  typedef boost::probabilities::likelihood<log_domain,double,validator>
    log_likelihood;

  const int one (1);

  likelihood::value_type x1 (0.25);
  likelihood::value_type x2 (0.50);

  likelihood l1 (x1);
  likelihood l2 (x2);

  log_likelihood log_l1 (x1, linear_domain());
  log_likelihood log_l2 (x2, linear_domain());
  log_likelihood log_sum (x1 + x2, linear_domain());
  log_likelihood log_difference (x2 - x1, linear_domain());
  log_likelihood log_product (log(x1) + log(x2));
  log_likelihood log_quotient (log(x1) - log(x2));

  BOOST_REQUIRE_THROW (likelihood(l1) += -one, out_of_range);
  BOOST_REQUIRE_THROW (likelihood(l1) -= +one, out_of_range);
  BOOST_REQUIRE_THROW (likelihood(l1) *= -one, out_of_range);
  BOOST_REQUIRE_THROW (likelihood(l1) /= -one, out_of_range);

  BOOST_CHECK_EQUAL (log_likelihood(l1) += l2, log_sum);
  BOOST_CHECK_EQUAL (log_likelihood(l2) -= l1, log_difference);
  BOOST_CHECK_EQUAL (log_likelihood(l1) *= l2, log_product);
  BOOST_CHECK_EQUAL (log_likelihood(l1) /= l2, log_quotient);
}

BOOST_AUTO_TEST_CASE (test_arithmetic)
{
  likelihood::value_type x1 (0.25);
  likelihood::value_type x2 (0.50);

  likelihood l1 (x1);
  likelihood l2 (x2);
  likelihood sum (x1 + x2);
  likelihood difference (x2 - x1);
  likelihood product (x1 * x2);
  likelihood quotient (x1 / x2);

  BOOST_CHECK_EQUAL (l1 + l2, sum);
  BOOST_CHECK_EQUAL (l2 - l1, difference);
  BOOST_CHECK_EQUAL (l1 * l2, product);
  BOOST_CHECK_EQUAL (l1 / l2, quotient);

  log_likelihood log_l1 (x1, linear_domain());
  log_likelihood log_l2 (x2, linear_domain());
  log_likelihood log_product (log(x1) + log(x2));
  log_likelihood log_quotient (log(x1) - log(x2));

  BOOST_CHECK_EQUAL (log_l1 + log_l2, sum);
  BOOST_CHECK_EQUAL (log_l2 - log_l1, difference);
  BOOST_CHECK_EQUAL (log_l1 * log_l2, log_product);
  BOOST_CHECK_EQUAL (log_l1 / log_l2, log_quotient);
}

BOOST_AUTO_TEST_CASE (test_mixed_arithmetic)
{
  likelihood::value_type x1 (0.25);
  likelihood::value_type x2 (0.50);

  likelihood l1 (x1);
  likelihood l2 (x2);
  likelihood sum (x1 + x2);
  likelihood difference (x2 - x1);
  likelihood product (x1 * x2);
  likelihood quotient (x1 / x2);

  log_likelihood log_l1 (x1, linear_domain());
  log_likelihood log_l2 (x2, linear_domain());
  log_likelihood log_product (log(x1) + log(x2));
  log_likelihood log_quotient (log(x1) - log(x2));

  BOOST_CHECK_EQUAL (l1 + log_l2, sum);
  BOOST_CHECK_EQUAL (log_l1 + l2, sum);
  BOOST_CHECK_EQUAL (l2 - log_l1, difference);
  BOOST_CHECK_EQUAL (log_l2 - l1, difference);

  BOOST_CHECK_EQUAL (l1 * log_l2, log_product);
  BOOST_CHECK_EQUAL (log_l1 * l2, log_product);
  BOOST_CHECK_EQUAL (l1 / log_l2, log_quotient);
  BOOST_CHECK_EQUAL (log_l1 / l2, log_quotient);
}

BOOST_AUTO_TEST_CASE (test_functions)
{
  int n (3);

  likelihood::value_type x (0.5);
  likelihood::value_type ln_x (log(x));

  likelihood l (x);
  BOOST_CHECK_EQUAL
    (boost::probabilities::value_cast<linear_domain>(pow(l, n)), pow(x,n));

  log_likelihood ln_l (ln_x);
  BOOST_CHECK_EQUAL
    (boost::probabilities::value_cast<log_domain>(pow(ln_l, n)), n * ln_x);
}

BOOST_AUTO_TEST_CASE (test_numeric_limits)
{
  BOOST_CHECK(std::numeric_limits<likelihood>::is_specialized);
  BOOST_CHECK(!std::numeric_limits<likelihood>::is_signed);
  BOOST_CHECK_EQUAL(std::numeric_limits<likelihood>::min(),
		    std::numeric_limits<likelihood::value_type>::min());
  BOOST_CHECK_EQUAL(std::numeric_limits<likelihood>::max(),
		    std::numeric_limits<likelihood::value_type>::max());

  BOOST_CHECK(std::numeric_limits<log_likelihood>::is_specialized);
  BOOST_CHECK(!std::numeric_limits<log_likelihood>::is_signed);
  BOOST_CHECK_EQUAL(std::numeric_limits<log_likelihood>::min(),
		    std::numeric_limits<likelihood::value_type>::min());
  BOOST_CHECK_EQUAL(std::numeric_limits<log_likelihood>::max(),
		    std::numeric_limits<likelihood::value_type>::max());
}

BOOST_AUTO_TEST_CASE (test_output)
{
  boost::test_tools::output_test_stream stream;
  stream << likelihood();
  BOOST_CHECK(stream.is_equal("1", true));
  stream << log_likelihood();
  BOOST_CHECK(stream.is_equal("1", true));
}

template <typename Domain, typename Value, typename Validator>
std::ostream&
operator << (std::ostream& s, const boost::probabilities::
	     likelihood<Domain,Value,Validator>& l)
{
  return s << boost::probabilities::value_cast<linear_domain>(l);
}

template <typename Domain, typename Value, typename Validator>
std::ostream&
operator << (std::ostream& s, const boost::probabilities::
	     probability<Domain,Value,Validator>& p)
{
  return s << boost::probabilities::value_cast<linear_domain>(p);
}
