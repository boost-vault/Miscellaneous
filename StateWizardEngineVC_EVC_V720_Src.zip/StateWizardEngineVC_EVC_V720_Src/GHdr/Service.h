/* =============================================================================
 * Filename:    Service.h
 * 
 * Copyright Intelliwizard Inc
 * All rights reserved.
 * -----------------------------------------------------------------------------
 * General description of this file:
 *
 * -----------------------------------------------------------------------------
 *                               Revision History
 * -----------------------------------------------------------------------------
 * Version   Date      Author          Revision Detail
 * 1.0.0    2004/11/26                 Initial
 * ===========================================================================*/

#ifndef SERVICE_H
#define SERVICE_H

#include "sme.h"
#include "EventId.h"
//#include "stdafx.h"

#ifdef __cplusplus   
extern "C" {
#endif

SME_DEC_EXT_APP_VAR(PowerUpDown);
SME_DEC_EXT_APP_VAR(MenuCtrl);
SME_DEC_EXT_APP_VAR(ImageList);
SME_DEC_EXT_APP_VAR(EditCtrl);
SME_DEC_EXT_APP_VAR(DialogCtrl);


// Message data definitions for specific message type.
typedef struct MSG_KEY_PRESS_T
{
	unsigned short nKeyCode;
}MSG_KEY_PRESS_T;

typedef struct MSG_TIMER_T
{
	unsigned int nSeqNum;	
}MSG_TIMER_T;

enum
{
	KEY_CODE_0,
	KEY_CODE_1,
	KEY_CODE_2,
	KEY_CODE_3,
	KEY_CODE_4,
	KEY_CODE_5,
	KEY_CODE_6,
	KEY_CODE_7,
	KEY_CODE_8,
	KEY_CODE_9,
	KEY_CODE_RIGHTSOFT,
	KEY_CODE_LEFTSOFT,
	KEY_CODE_POWER,
	KEY_CODE_UP,
	KEY_CODE_DOWN,

	KEY_DLG_OK,
	KEY_DLG_CANCEL,
	KEY_DLG_SKL,
	KEY_DLG_SKR
};

////////////////////////////////////////////////////////////////
// Service definitions which will map to service call.
enum
{
	SRV_ID_POWER_CONTROL,
	SRV_ID_DISPLAY_DIALOG,
	SRV_ID_CLEAR_DISPLAY,
	SRV_ID_UPDATE_DISPLAY,
	SRV_ID_TURN_OFF_DISPLAY,
	SRV_ID_MEMORY_STATISTIC,
	SRV_ID_SET_TIMER,
	SRV_ID_KILL_TIMER,
	SRV_ID_GET_TIME
};


////////////////////////////////////////////////////////////////
// Service function parameter definitions.
typedef struct SRV_CALL_UPDATE_DISPLAY_T
{
	int nLeft;
	int nTop;
	int nWidth;
	int nHeight;
	unsigned char *pData;
}SRV_CALL_UPDATE_DISPLAY_T;

typedef struct SRV_CALL_DISPLAY_DIALOG_T
{
	char* pStr;
}SRV_CALL_DISPLAY_DIALOG_T;

typedef struct SRV_SET_TIMER_T
{
	unsigned int nElapse;
	void* pDestPort;
	int* pTimerID;
}SRV_SET_TIMER_T;

typedef struct SRV_KILL_TIMER_T
{
	unsigned int nTimerID;
}SRV_KILL_TIMER_T;

typedef struct SRV_GET_TIME_T
{
	int *pHour;
	int *pMinute;
	int *pSecond;
}SRV_GET_TIME_T;

void SrvPowerControl();
void SrvClearDisplay();
void SrvUpdateDisplay(int nLeft, int nTop, int nWidth, int nHeight, unsigned char *pData);
void SrvRefreshDisplay(int nLeft, int nTop, int nWidth, int nHeight, unsigned char *pData);
void SrvTurnOffDisplay();
void SrvUpdateMemoryStatistic(unsigned int size);
unsigned int SrvSetTimer(unsigned int nElapse,void* pDestPort);
BOOL SrvKillTimer(unsigned int nTimerID);
void SrvGetTime(int *pHour, int *pMinute, int *pSecond);
void** SrvGetPortInfoPtr();

#ifdef __cplusplus
}
#endif 

#endif // #define SME_H
