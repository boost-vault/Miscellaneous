/**********************************************************************
UML StateWizard provides its software under the GPL License and zlib/libpng License for open source projects.

Email us at info@intelliwizard.com for any information, suggestions and feature requestions.

http://www.intelliwizard.com
*************************************************************************/



/* =============================================================================
 * Filename:    SrvAgent.h
 * 
 * Copyright  Intelliwizard Inc
 * All rights reserved.
 * -----------------------------------------------------------------------------
 * General description of this file:
 * This is the global interface definition for the service agent.
 * -----------------------------------------------------------------------------
 *                               Revision History
 * -----------------------------------------------------------------------------
 * Version   Date      Author          Revision Detail
 * 1.0.0    2004/11/26                 Initial
 * ===========================================================================*/

#ifndef SRV_AGENT_H
#define SRV_AGENT_H

#include "sme.h"
#include "windows.h"

#ifdef __cplusplus   
extern "C" {
#endif


/**********************************************************************************************
Thread and external event handle.
*/
typedef int (*AGT_CALL_BACK_PROC_T)(void* pParam );

BOOL AgtEndAppThread(SME_THREAD_CONTEXT_PT pThreadContext, AGT_CALL_BACK_PROC_T pfnCallback);

#ifdef _WIN32_WCE
BOOL AgtStartAppThread(HWND hSimWinHdl, LPCTSTR sLibFileName, LPCTSTR sProcName,SME_THREAD_CONTEXT_PT pThreadContext);
BOOL AgtStartAppChildThread(LPCTSTR sProcName,SME_THREAD_CONTEXT_PT pThreadContext);
#else
BOOL AgtStartAppThread(HWND hSimWinHdl, LPCTSTR sLibFileName, LPCSTR asProcName,SME_THREAD_CONTEXT_PT pThreadContext);
BOOL AgtStartAppChildThread(LPCSTR sProcName,SME_THREAD_CONTEXT_PT pThreadContext);
#endif

BOOL AgtPostExtEvent(long nEventId, void* pData, int nDataSize, void *pDestPort, SME_THREAD_CONTEXT_PT pThreadContext );

BOOL AgtFreeAppDll();

#define WM_SRV_CALL_ID (WM_APP + 1)

/* Create an additional header for service call. */
typedef struct SME_SRV_CALL_DATA_HDR_T
{
	long nSrvCallId;
	unsigned long nDataLen; /* service call data size*/
} SME_SRV_CALL_DATA_HDR_T;

/* The SME_AFTER_SRV_CALL_DATA_HDR structure is used to ensure proper alignment when
 * creating and accessing a message.  The offset of the BeginingOfData
 * field is calculated when skipping over the message header in order to return
 * a pointer to the usable data portion of a message.
 */
typedef struct SME_AFTER_SRV_CALL_DATA_HDR
{
   SME_SRV_CALL_DATA_HDR_T MsgHdr;
   union BeginingOfData
   {
      char int8;
      short int16;
      long int32;
   } BeginingOfData;
} SME_AFTER_SRV_CALL_DATA_HDR;

#define SME_SIZEOF_SRV_CALL_HDR      ((unsigned long)(offsetof(SME_AFTER_SRV_CALL_DATA_HDR, BeginingOfData)))

/* This macro returns a pointer to message header */
#define SME_CALLDATA2HDR(msg_ptr) \
   ((SME_SRV_CALL_DATA_HDR_T *)(((unsigned long) (msg_ptr)) - (SME_SIZEOF_SRV_CALL_HDR)))

/* This macro returns a pointer to message data */
#define SME_HDR2CALLDATA(msg_hdr_p) \
   ((void *)(((unsigned long) (msg_hdr_p)) + (SME_SIZEOF_SRV_CALL_HDR)))

/**********************************************************************************************
Service call agent
*/
BOOL AgtPostServiceCall(long nSrvCallId, void * pCallData, int nDataSize);
BOOL AgtSendServiceCall(long nSrvCallId, void * pCallData, int nDataSize);
BOOL AgtEndServiceCall(SME_SRV_CALL_DATA_HDR_T* pHdr);
BOOL AgtSetEngineOprProc(SME_THREAD_CONTEXT_PT pThreadContext);


/*********************************************************************************************
For Winodws only
*/
BOOL MfcHookWnd(HWND hWndHooked);

BOOL MfcPostExtPtrEventToWnd(long nEventId, void* pData, int nDataSize, void *pDestPort, HWND hWndHooked);
BOOL MfcPostExtIntEventToWnd(long nEventId, unsigned long nParam1, unsigned long nParam2, void *pDestPort, HWND hWndHooked);

BOOL MfcSendExtPtrEventToWnd(long nEventId, void* pData, int nDataSize, void *pDestPort, HWND hWndHooked);
BOOL MfcSendExtIntEventToWnd(long nEventId, unsigned long nParam1, unsigned long nParam2, void *pDestPort, HWND hWndHooked);

#ifdef __cplusplus
}
#endif 

#endif // #define SRVAGENT_H
