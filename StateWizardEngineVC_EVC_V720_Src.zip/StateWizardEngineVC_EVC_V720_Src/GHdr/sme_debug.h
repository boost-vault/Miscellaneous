/**********************************************************************
UML StateWizard provides its software under the GPL License and zlib/libpng License for open source projects.

Email us at info@intelliwizard.com for any information, suggestions and feature requestions.

http://www.intelliwizard.com
*************************************************************************/


/* =============================================================================
 * Filename:    sme_debug.h
 * 
 * Copyright  IntelliWizard Inc. www.intelliwizard.com
 * All rights reserved.
 * -----------------------------------------------------------------------------
 * General description of this file:
 *
 * State machine engine debug support global header file.
 * -----------------------------------------------------------------------------
 *                               Revision History
 * -----------------------------------------------------------------------------
 * Version   Date      Author          Revision Detail
 * 1.0.0    2004/11/26       Initial
 * ===========================================================================*/

#ifndef SME_DEBUG_H
#define SME_DEBUG_H

#include "sme.h"

#ifdef __cplusplus   
extern "C" {
#endif

/*****************************************************************************************
*  Diagnostic function prototypes.
******************************************************************************************/
typedef void (*SME_OUTPUT_DEBUG_ASCII_STR_PROC_T)(const char * sDebugStr); 
typedef void (*SME_OUTPUT_DEBUG_UNICODE_STR_PROC_T)(const unsigned short * sDebugStr); 
SME_OUTPUT_DEBUG_ASCII_STR_PROC_T	SmeSetOutputDebugAsciiStrProc(SME_OUTPUT_DEBUG_ASCII_STR_PROC_T fnProc);
SME_OUTPUT_DEBUG_UNICODE_STR_PROC_T	SmeSetOutputDebugUnicodeStrProc(SME_OUTPUT_DEBUG_UNICODE_STR_PROC_T fnProc);

void SmeUnicodeTrace(int nModuleID, const unsigned short * wsFormat, ...);
void SmeUnicodeTraceAscFmt(int nModuleID, const char * sFormat, ...);
void SmeAsciiTrace(int nModuleID, const char * sFormat, ...);
void SmeTurnOnModuleTracer(int nModuleID);
void SmeTurnOffModuleTracer(int nModuleID);
void SmeTurnOnAllModuleTracers();
void SmeTurnOffAllModuleTracers();
void SmeEnableStateTracking(BOOL bStateTree, BOOL bOutputWin);

BOOL StateTrack(struct SME_EVENT_T *pEvent, struct SME_APP_T *pDestApp, SME_STATE_T nNewState);

#if (defined(DEBUG) || defined(_DEBUG))
	#define SME_TURN_ON_MODULE_TRACER(nModuleID) SmeTurnOnModuleTracer(nModuleID)
	#define SME_TURN_OFF_MODULE_TRACER(nModuleID) SmeTurnOffModuleTracer(nModuleID)
	#define SME_TURN_ON_ALL_MODULE_TRACERS() SmeTurnOnAllModuleTracers()
	#define SME_TURN_OFF_ALL_MODULE_TRACERS() SmeTurnOffAllModuleTracers()

	#define SME_ASCII_TRACE  SmeAsciiTrace

	#ifdef _UNICODE
		#define SME_TRACE  SmeUnicodeTrace
		#define SME_TRACE_ASC_FMT SmeUnicodeTraceAscFmt
		#define SME_SET_TRACER(fnTracer)	SmeSetOutputDebugUnicodeStrProc(fnTracer)
		#define SME_ASSERT(BoolExpress)       do { \
			if (!(BoolExpress)) {\
			SME_TRACE_ASC_FMT(-1,"Assertion fails.\n"); while(1); \
			}\
		} while(0)
	#else
		#define SME_TRACE  SmeAsciiTrace
		#define SME_TRACE_ASC_FMT SmeAsciiTrace
		#define SME_SET_TRACER(fnTracer)	SmeSetOutputDebugAsciiStrProc(fnTracer)
		#define SME_ASSERT(BoolExpress)       do { \
			if (!(BoolExpress)) {\
			SME_TRACE(-1,"Assertion fails at %s (%d).\n", __FILE__, __LINE__); while(1); \
			}\
		} while(0)
	#endif 

	// 
#else /* not _DEBUG */

	#define SME_ASCII_TRACE		   1 ? (void)0 : SmeAsciiTrace

	#ifdef _UNICODE
		#define SME_TRACE              1 ? (void)0 : SmeUnicodeTrace
		#define SME_TRACE_ASC_FMT      1 ? (void)0 : SmeUnicodeTraceAscFmt
	#else
		#define SME_TRACE              1 ? (void)0 : SmeAsciiTrace
		#define SME_TRACE_ASC_FMT      1 ? (void)0 : SmeAsciiTrace
	#endif

	#define SME_ASSERT(BoolExpress)
	#define SME_SET_TRACER(fnTracer)
	#define SME_TURN_ON_MODULE_TRACER(nModuleID)
	#define SME_TURN_OFF_MODULE_TRACER(nModuleID)
	#define SME_TURN_ON_ALL_MODULE_TRACERS
	#define SME_TURN_OFF_ALL_MODULE_TRACERS
#endif  /* _DEBUG */

/******************************************************************************************
*  Dynamic memory operation function prototypes.
*******************************************************************************************/
typedef BOOL (*SME_ENUM_MEM_CALLBACK_T)(void *pUserData, unsigned int nSize, 
	const char *sFileName, int nLineNumber);

void * SmeMAllocDebug (unsigned int nSize, const char * sFile, int nLine);
int SmeMFreeDebug (void * pUserData, const char * sFile, int nLine);

enum {
	SME_HOOK_PRE_ALLOC,
	SME_HOOK_POST_ALLOC,
	SME_HOOK_PRE_FREE,
	SME_HOOK_POST_FREE
};
typedef unsigned char SME_MEM_OPR_HOOK_TYPE_T;

typedef int (*SME_MEM_OPR_HOOK_T)(SME_MEM_OPR_HOOK_TYPE_T nAllocType, void *pUserData, unsigned int nSize, 
	const char *sFileName, int nLineNumber);

SME_MEM_OPR_HOOK_T SmeSetMemOprHook(SME_MEM_OPR_HOOK_T pMemOprHook);
BOOL SmeEnumMem(SME_ENUM_MEM_CALLBACK_T fnEnumMemCallBack);
void SmeDumpMem();
void SmeAllocMemSize();
BOOL SmeDbgInit();

#if (defined(DEBUG) || defined(_DEBUG))
	#define SME_DBG_INIT SmeDbgInit
	#define SmeMAlloc(nSize)  	SmeMAllocDebug((nSize), __FILE__, __LINE__)
	#define SmeMFree(pUserData)  	SmeMFreeDebug((pUserData), __FILE__, __LINE__)

	#define SME_SET_MEM_OPR_HOOK(pMemOprHook)	SmeSetMemOprHook(pMemOprHook) 
	#define SME_ENUM_MEM(fnEnumMemCallBack) SmeEnumMem(fnEnumMemCallBack)
	#define SME_DUMP_MEM SmeDumpMem
	#define SME_ALLOC_MEM_SIZE SmeAllocMemSize
	#define SME_ENABLE_STATE_TRACK(bStateTree, bOutputWin) SmeEnableStateTracking(bStateTree, bOutputWin)

#else /* not DEBUG */
	#define SME_DBG_INIT()
	#define SmeMAlloc(nSize)	SmeMAllocRelease((nSize))
	#define SmeMFree(pUserData)		SmeMFreeRelease((pUserData))

	#define SME_SET_MEM_OPR_HOOK(pMemOprHook)
	#define SME_ENUM_MEM(fnEnumMemCallBack)
	#define SME_DUMP_MEM()
	#define SME_ALLOC_MEM_SIZE()
	#define SME_ENABLE_STATE_TRACK(bStateTree, bOutputWin) 
#endif  

#ifdef __cplusplus
}
#endif 


#endif /* SME_DEBUG_H */
