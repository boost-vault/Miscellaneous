/**********************************************************************
UML StateWizard provides its software under the GPL License and zlib/libpng License for open source projects.

Email us at info@intelliwizard.com for any information, suggestions and feature requestions.

http://www.intelliwizard.com
*************************************************************************/

/* =============================================================================
 * Filename:    sme.h
 * 
 * Copyright  IntelliWizard Inc. www.intelliwizard.com
 * All rights reserved.
 * -----------------------------------------------------------------------------
 * General description of this file:
 *
 * State machine engine global header file.
 * -----------------------------------------------------------------------------
 *                               Revision History
 * -----------------------------------------------------------------------------
 * Version   Date      Author          Revision Detail
 * 1.0.0    2004/11/26                 Initial
 *          2004/12/19					__cplusplus and extern
			2005/1/22					Add app macro definition
			2005/4/12					Add pPortInfo property in SME_EVENT_T.
 * ===========================================================================*/

#ifndef SME_H
#define SME_H

#ifndef BOOL
	typedef int  BOOL;
#endif
#ifndef FALSE
	#define FALSE	0
#endif
#ifndef TRUE
	#define TRUE	1
#endif
#ifndef NULL
	#define NULL    0
#endif

#ifdef __cplusplus   
extern "C" {
#endif

/*****************************************************************************************
*  State Machine Engine Type Definitions
******************************************************************************************/

/* State Definition */
typedef short SME_STATE_T;

#define SME_APP_STATE		0
#define SME_INVALID_STATE	-1

/* Event Definition
* Positive 32-bit integer values are user-defined event identifiers.
* Negative 32-bit integer values are state machine engine defined event identifiers.
*/
typedef long SME_EVENT_ID_T;
#define SME_INVALID_EVENT_ID	-1
#define SME_EVENT_KILL_FOCUS -2
#define SME_EVENT_SET_FOCUS  -3

typedef enum
{
	SME_EVENT_CAT_UI=0,
	SME_EVENT_CAT_OTHER,
};
typedef unsigned char SME_EVENT_CAT_T;

typedef enum 
{
	SME_EVENT_ORIGIN_INTERNAL=0,
	SME_EVENT_ORIGIN_EXTERNAL,
};
typedef unsigned char SME_EVENT_ORIGIN_T;

typedef enum 
{
	SME_EVENT_DATA_FORMAT_INT=0,
	SME_EVENT_DATA_FORMAT_PTR,
};
typedef unsigned char SME_EVENT_DATA_FORMAT_T;

typedef	struct SME_INT_DATA_T 
{
		unsigned long nParam1; 
		unsigned long nParam2;
} SME_INT_DATA_T;

typedef struct SME_PTR_DATA_T 
{
		void* pData;
		unsigned long nSize;
} SME_PTR_DATA_T;

union SME_EVENT_DATA_T
{
	SME_INT_DATA_T	Int;
	SME_PTR_DATA_T  Ptr;
};

typedef struct SME_EVENT_T
{
	SME_EVENT_ID_T nEventID;
	unsigned long nSequenceNum;
	struct SME_EVENT_T *pNext; 
	/* Provide 2 data formats: integer or pointer */
	union SME_EVENT_DATA_T Data;
	struct SME_APP_T *pDestApp; /* The destination application. */ 
	void* pPortInfo; /* Point to a destination port information data. */
	unsigned long nOrigin :8; /* */
	unsigned long nCategory :8; /* Category of this event. */
	unsigned long nDataFormat :8; /* Flag for this event. */
	unsigned long bIsConsumed :8; /* Is comsumed. */
}SME_EVENT_T,*SME_EVENT_PT;

typedef struct SME_APP_T
{
	const char * sAppName;
	struct SME_APP_T *pParent; /* Who starts me */
	struct SME_APP_T *pNext; /* Applications are linked together. */
	unsigned long nPortId; 
	void * pPortInfo;
	void * pData;
	const struct SME_STATE_TREE_TABLE_T *pStateTree;
	SME_STATE_T nAppState;
}SME_APP_T, *SME_APP_PT;

#define SME_APP_DATA(app) (app.pData)
#define SME_IS_ACTIVATED(app) (app->nAppState != SME_INVALID_STATE)

typedef int (* SME_EVENT_HANDLER_T)(SME_APP_T *, SME_EVENT_T *);  

#define SME_INTERNAL_TRAN	SME_INVALID_STATE

typedef struct SME_EVENT_TABLE_T {                                    
	SME_EVENT_ID_T nEventID;                                        
	SME_EVENT_HANDLER_T pHandler;
	SME_STATE_T nNewState;	
}SME_EVENT_TABLE_T, *SME_EVENT_TABLE_PT;                                                

typedef struct SME_STATE_TREE_TABLE_T{
	SME_EVENT_TABLE_T *pEventTable;
	SME_STATE_T nState;
	SME_STATE_T nParentState;
	SME_STATE_T nDefSubState;
}SME_STATE_TREE_TABLE_T, *SME_STATE_TREE_TABLE_PT;

/********************************************************************************************************
*  State Machine Engine hook function prototypes.
*********************************************************************************************************/
typedef struct SME_EVENT_T* (*SME_GET_EXT_EVENT_PROC_T)();
typedef BOOL (*SME_DEL_EXT_EVENT_PROC_T)(struct SME_EVENT_T *pEvent);
typedef BOOL (*SME_POST_EXT_THREAD_EVENT_PROC_T)(long nEventId, void* pData, int nDataSize, void *pDestPort,
												 struct SME_THREAD_CONTEXT_T *pThreadContext);
 
typedef void* (*SME_MEM_ALLOC_PROC_T)(unsigned int nSize);
typedef BOOL  (*SME_MEM_FREE_PROC_T)(void* pUserData);

typedef int (*SME_ON_EVENT_COME_HOOK_T)(SME_EVENT_ORIGIN_T nEventOrigin, struct SME_EVENT_T *pEvent);
typedef int (*SME_ON_EVENT_HANDLE_HOOK_T)(SME_EVENT_ORIGIN_T nEventOrigin, struct SME_EVENT_T *pEvent, 
										  struct SME_APP_T *pDestApp, SME_STATE_T nNewState);

/********************************************************************************************************
*  State Machine Engine multi-thread support.
*********************************************************************************************************/
#define SME_EVENT_POOL_SIZE			8

typedef struct SME_THREAD_CONTEXT_T{
	struct SME_APP_T	* pActAppHdr;
	struct SME_APP_T * pFocusedApp;
	struct SME_EVENT_T EventPool[SME_EVENT_POOL_SIZE];
	int nEventPoolIdx;
	struct SME_EVENT_T *pEventQueueFront; 
	struct SME_EVENT_T *pEventQueueRear;
	SME_GET_EXT_EVENT_PROC_T  fnGetExtEvent;
	SME_DEL_EXT_EVENT_PROC_T  fnDelExtEvent;
	SME_POST_EXT_THREAD_EVENT_PROC_T  fnPostExtThreadEvent;
	SME_ON_EVENT_COME_HOOK_T fnOnEventComeHook; 
	SME_ON_EVENT_HANDLE_HOOK_T fnOnEventHandleHook;
	unsigned long		nAppThreadID;
	void *pData;
}SME_THREAD_CONTEXT_T, *SME_THREAD_CONTEXT_PT;

typedef BOOL (*SME_SET_THREAD_CONTEXT_PROC)(SME_THREAD_CONTEXT_PT p);
typedef SME_THREAD_CONTEXT_PT (*SME_GET_THREAD_CONTEXT_PROC)();

/******************************************************************************************
*  ASCII and Unicode string supports
*******************************************************************************************/
#ifndef _UNICODE
#define SME_CHAR	char
#else
#define SME_CHAR	unsigned short
#endif


/******************************************************************************************
*  State Machine Data Mapping Definitions
*******************************************************************************************/
#define SME_BEGIN_STATE_DECLARE(_app) \
	enum _app##_state_enum_t \
	{

#define SME_STATE_DECLARE(_state) _state, 

#define SME_MAX_STATE(_app)	_app##_max_state	 

#define SME_END_STATE_DECLARE };

////////////////
#define SME_ENTRY_FUNC_IDX	0
#define SME_EXIT_FUNC_IDX	1
#define SME_EVENT_HANDLER_FUNC_IDX	2

#define SME_BEGIN_STATE_DEF(_app,_state) \
static const SME_EVENT_TABLE_T _app##_state##_event_hdl_tbl[] \
={

#define SME_STATE_ENTRY_FUNC( _EntryFunc) \
{  SME_INVALID_EVENT_ID, _EntryFunc, 0},

#define SME_STATE_EXIT_FUNC( _ExitFunc) \
{  SME_INVALID_EVENT_ID, _ExitFunc, 0},

#define SME_ON_EVENT(_EventID, _Handler, _NewState) \
{  _EventID, _Handler, _NewState},

#define SME_END_STATE_DEF { SME_INVALID_EVENT_ID, 0, SME_INVALID_STATE}};

/* Note: 
In C, constant values default to external linkage, so they can appear only in source files. 
In C++, constant values default to internal linkage, which allows them to appear in header files.

Attempting to reference functions or data that don't have external linkage causes LNK2001. 
In C++, inline functions and const data have internal linkage unless explicitly specified as extern. 
*/

#define SME_BEGIN_STATE_TREE_DEF(_app) \
extern const SME_STATE_TREE_TABLE_T _app##_state_tree[] = \
{

#define SME_STATE(_app,_state,_state_parent,_def_substate) \
	{(SME_EVENT_TABLE_T *)_app##_state##_event_hdl_tbl, _state,_state_parent,_def_substate},

#define SME_END_STATE_TREE_DEF };

#define SME_APPLICATION_DEF(_app,_app_name) \
	struct SME_APP_T _app##App = { \
	_app_name, NULL, NULL, 0, NULL,	NULL, _app##_state_tree, SME_INVALID_STATE};

/* Get application variable name. */
#define SME_GET_APP_VAR(_app) _app##App

/* Declare application variable that has external linkage. */
#define SME_DEC_EXT_APP_VAR(_app) extern SME_APP_T _app##App;

/******************************************************************************************
*  State Machine Engine APIs
******************************************************************************************/
void SmeInitEngine(SME_THREAD_CONTEXT_PT pThreadContext);
BOOL SmeActivateApp(struct SME_APP_T *pNewApp, struct SME_APP_T *pParentApp);
BOOL SmeDeactivateApp(struct SME_APP_T *pApp);
BOOL SmeSetFocus(struct SME_APP_T *pApp);

struct SME_EVENT_T *SmeCreateIntEvent(SME_EVENT_ID_T nEventId,
								   unsigned long nParam1,
								   unsigned long nParam2,
								   SME_EVENT_CAT_T nCategory,
								   struct SME_APP_T *pDestApp);
struct SME_EVENT_T *SmeCreatePtrEvent(SME_EVENT_ID_T nEventId,
								   void* pData,
								   unsigned long nSize,
								   SME_EVENT_CAT_T nCategory,
								   struct SME_APP_T *pDestApp);

BOOL SmeDeleteEvent(struct SME_EVENT_T *pEvent);
void SmeConsumeEvent(struct SME_EVENT_T *pEvent);
BOOL SmePostEvent(struct SME_EVENT_T *pEvent);
BOOL SmePostExtThreadEvent(long nEventId, void* pData, int nDataSize, void *pDestPort, SME_THREAD_CONTEXT_PT pDestThreadContext);

BOOL SmeDispatchEvent(struct SME_EVENT_T *pEvent, struct SME_APP_T *pApp);
void SmeRun();

void SmeSetExtEventOprProc(SME_GET_EXT_EVENT_PROC_T fnGetExtEvent, 
						   SME_DEL_EXT_EVENT_PROC_T fnDelExtEvent,
						   SME_POST_EXT_THREAD_EVENT_PROC_T fnPostEvtEvent);

SME_ON_EVENT_COME_HOOK_T SmeSetOnEventComeHook(SME_ON_EVENT_COME_HOOK_T pOnEventComeHook);
SME_ON_EVENT_HANDLE_HOOK_T SmeSetOnEventHandleHook(SME_ON_EVENT_HANDLE_HOOK_T pOnEventHandleHook);

void* SmeMAllocRelease(unsigned int nSize);
BOOL SmeMFreeRelease(void *pUserData);
void SmeSetMemOprProc(SME_MEM_ALLOC_PROC_T fnMAllocProc, SME_MEM_FREE_PROC_T fnMFreeProc);

void SmeSetTlsProc(SME_SET_THREAD_CONTEXT_PROC pfnSetThreadContext, SME_GET_THREAD_CONTEXT_PROC pfnGetThreadContext);

#ifdef __cplusplus
}
#endif 

#endif /* #define SME_H */
