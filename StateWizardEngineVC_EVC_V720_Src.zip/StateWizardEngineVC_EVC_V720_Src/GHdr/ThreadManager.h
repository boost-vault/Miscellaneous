/**********************************************************************
UML StateWizard provides its software under the GPL License and zlib/libpng License for open source projects.

Email us at info@intelliwizard.com for any information, suggestions and feature requestions.

http://www.intelliwizard.com
*************************************************************************/



/* =============================================================================
 * Filename:    ThreadManager.h
 * 
 * Copyright  Intelliwizard Inc
 * All rights reserved.
 * -----------------------------------------------------------------------------
 * General description of this file:
 *
 * Manager application thread and create external events.
 * -----------------------------------------------------------------------------
 *                               Revision History
 * -----------------------------------------------------------------------------
 * Version   Date      Author          Revision Detail
 * 1.0.0    2004/11/26                 Initial
 * ===========================================================================*/

#ifndef THREAD_MANAGER_H
#define THREAD_MANAGER_H

/* =============================================================================
 *                               INCLUDE FILES
 * ===========================================================================*/
#include "SrvAgent.h"
/* =============================================================================
 *                           LOCAL FUNCTION PROTOTYPES
 * ===========================================================================*/
/* The following message id is reserved for the state machine engine. 
Do NOT use this message id (0xBFFF) in your application which window is hooked for state machine engine message pump. */
#define WM_EXT_EVENT_ID		(0xBFFF)

void AppThreadExit();
void ExtEventTrigger();
struct SME_EVENT_T * GetExtEvent();
BOOL DelExtEvent(struct SME_EVENT_T *pEvent);
struct SME_EVENT_T* TranslateEvent(MSG *pWinMsg);

void* SrvMAlloc(unsigned int nSize);
BOOL SrvMFree(void* pUserData);

/* Create an additional header for external service provider events. */
typedef struct SME_SRV_MSG_HEADER_T
{
	long nEventId;
	unsigned long nDataLen; /* message size of data portion */
	void *pDestPort; /* Message destination port. */
} SME_SRV_MSG_HEADER_T;

/* The SME_AFTER_SRV_MSG_HDR structure is used to ensure proper alignment when
 * creating and accessing a message.  The offset of the BeginingOfData
 * field is calculated when skipping over the message header in order to return
 * a pointer to the usable data portion of a message.
 */
typedef struct SME_AFTER_SRV_MSG_HDR
{
   SME_SRV_MSG_HEADER_T MsgHdr;
   union BeginingOfData
   {
      char int8;
      short int16;
      long int32;
   } BeginingOfData;
} SME_AFTER_SRV_MSG_HDR;

#define SME_SIZEOF_MSG_HDR      ((unsigned long)(offsetof(SME_AFTER_SRV_MSG_HDR, BeginingOfData)))

/* This macro returns a pointer to message header */
#define SME_MSG2HDR(msg_ptr) \
   ((SME_SRV_MSG_HEADER_T *)(((unsigned long) (msg_ptr)) - (SME_SIZEOF_MSG_HDR)))

/* This macro returns a pointer to message data */
#define SME_HDR2MSG(msg_hdr_p) \
   ((void *)(((unsigned long) (msg_hdr_p)) + (SME_SIZEOF_MSG_HDR)))

#endif //THREAD_MANAGER_H