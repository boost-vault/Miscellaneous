/**********************************************************************
UML StateWizard provides its software under the GPL License and zlib/libpng License for open source projects.

Email us at info@intelliwizard.com for any information, suggestions and feature requestions.

http://www.intelliwizard.com

*************************************************************************/

/* =============================================================================
 * Filename:    EngineSrvAgent.cpp
 * 
 * Copyright  Inc
 * All rights reserved.
 * -----------------------------------------------------------------------------
 * General description of this file:
 *   EngineSrvAgent.cpp : Defines the initialization routines for the DLL.
 *   Retrieve the workspace window handle by debuging process environment variables.
 * -----------------------------------------------------------------------------
 *                               Revision History
 * -----------------------------------------------------------------------------
 * Version   Date      Author          Revision Detail
 * 1.0.0    2005/1/19                  Initial
			2005/12/23                 Thread Local Storage
 * ===========================================================================*/
// EngineSrvAgent.cpp : Defines the initialization routines for the DLL.
//

#include "stdafx.h"
#include <afxdllx.h>

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

HWND GetDSWorkspaceHandle();
///////////////////////////////////////////////////////////////////////////////////////////
HWND g_hWorkspaceWnd = NULL;
extern DWORD g_dwTlsIndex;

///////////////////////////////////////////////////////////////////////////////////////////
// DESCRIPTION: This function gets VC workspace window handle by environment variables. 
// INPUT:  
//  None. 
// OUTPUT: 
// RETURN: 
// NOTE: 
//	It will be used to detect memory leaks, if developer call it when application enter some status.
///////////////////////////////////////////////////////////////////////////////////////////
#define VCDEV_INFO_VAR	_T("smw_vcdev_info_var")
HWND GetDSWorkspaceHandle()
{
	TCHAR sEnvVar[128];
	TCHAR *pEnd;

	if (GetEnvironmentVariable(VCDEV_INFO_VAR, sEnvVar, 128)<=0)
		return NULL;

	return (HWND)(_tcstoul((const TCHAR *)sEnvVar, &pEnd, 16));
}

///////////////////////////////////////////////////////////////////////////////////////////
static AFX_EXTENSION_MODULE EngineSrvAgentDLL = { NULL, NULL };

extern "C" int APIENTRY
DllMain(HINSTANCE hInstance, DWORD dwReason, LPVOID lpReserved)
{
	// Remove this if you use lpReserved
	UNREFERENCED_PARAMETER(lpReserved);

	if (dwReason == DLL_PROCESS_ATTACH)
	{
		TRACE0("ENGINESRVAGENT.DLL Initializing!\n");
		
		// Extension DLL one-time initialization
		if (!AfxInitExtensionModule(EngineSrvAgentDLL, hInstance))
			return 0;

		// Insert this DLL into the resource chain
		// NOTE: If this Extension DLL is being implicitly linked to by
		//  an MFC Regular DLL (such as an ActiveX Control)
		//  instead of an MFC application, then you will want to
		//  remove this line from DllMain and put it in a separate
		//  function exported from this Extension DLL.  The Regular DLL
		//  that uses this Extension DLL should then explicitly call that
		//  function to initialize this Extension DLL.  Otherwise,
		//  the CDynLinkLibrary object will not be attached to the
		//  Regular DLL's resource chain, and serious problems will
		//  result.

		new CDynLinkLibrary(EngineSrvAgentDLL);

		g_hWorkspaceWnd = GetDSWorkspaceHandle();
		g_dwTlsIndex = TlsAlloc();

	}
	else if (dwReason == DLL_PROCESS_DETACH)
	{
		TRACE0("ENGINESRVAGENT.DLL Terminating!\n");

		if (0xFFFFFFFF != g_dwTlsIndex)
			TlsFree(g_dwTlsIndex);

		// Terminate the library before destructors are called
		AfxTermExtensionModule(EngineSrvAgentDLL);
	}
	return 1;   // ok
}



