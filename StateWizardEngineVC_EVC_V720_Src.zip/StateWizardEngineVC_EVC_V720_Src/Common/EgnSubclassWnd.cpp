/**********************************************************************
UML StateWizard provides its software under the GPL License and zlib/libpng License for open source projects.
Email us at info@intelliwizard.com for any information, suggestions and feature requestions.

http://www.intelliwizard.com
*************************************************************************/




// EgnSubclassWnd.cpp: implementation of the CEgnSubclassWnd class.
//
//////////////////////////////////////////////////////////////////////

#include "stdafx.h"
#include "EgnSubclassWnd.h"
#include "ThreadManager.h"

#ifdef _DEBUG
#undef THIS_FILE
static char THIS_FILE[]=__FILE__;
#define new DEBUG_NEW
#endif

///////////////////////////////////////////////////////////////////////
extern SME_GET_THREAD_CONTEXT_PROC g_pfnGetThreadContext;


//////////////////////////////////////////////////////////////////////
// Construction/Destruction
//////////////////////////////////////////////////////////////////////

CEgnSubclassWnd::CEgnSubclassWnd()
{

}

CEgnSubclassWnd::~CEgnSubclassWnd()
{

}


LRESULT CEgnSubclassWnd::WindowProc(HWND hwnd, UINT msg, WPARAM wp,LPARAM lp)
{
	struct SME_EVENT_T* pExtEvent=NULL;
	MSG WinMsg;
	WinMsg.hwnd = hwnd;
	WinMsg.message =msg;
	WinMsg.wParam = wp;
	WinMsg.lParam = lp;

	LRESULT ret = 0;
	switch (msg)
	{
	case WM_EXT_EVENT_ID:
		// External event is triggered. App go to running state.
		OnExtEvent(WinMsg);
		break;

	default:
		break;
	}

	ret = CSubclassWnd::WindowProc(hwnd,msg,wp,lp);
	return ret;
}

/*******************************************************************************************
* DESCRIPTION:  Just like SmeRun(), this function dispatches external event to applications. 
* INPUT:  
* OUTPUT: None.
* NOTE: 
Engine has to check internal event first, because SmeActivateApp() may trigger some internal events.

Case:
	SmeActivateApp(&SME_GET_APP_VAR(PowerUpDown),NULL);
	SmeRun();
   
*******************************************************************************************/
struct SME_EVENT_T * GetEventFromQueue();
BOOL DispatchInternalEvents(SME_THREAD_CONTEXT_PT pThreadContext);
BOOL DispatchEventToApps(SME_THREAD_CONTEXT_PT pThreadContext,SME_EVENT_T *pEvent);

LRESULT CEgnSubclassWnd::OnExtEvent(MSG& WinMsg)
{
	SME_APP_T *pApp;
	SME_THREAD_CONTEXT_PT pThreadContext=NULL;
	SME_EVENT_T *pEvent=TranslateEvent(&WinMsg);

	if (pEvent==NULL)
		return 0;

	if (g_pfnGetThreadContext)
		pThreadContext = (*g_pfnGetThreadContext)();
	if (!pThreadContext) return 0;

	pApp = pThreadContext->pActAppHdr;

	/* Call hook function on an external event coming. */
	if (pThreadContext->fnOnEventComeHook)
		(*pThreadContext->fnOnEventComeHook)(SME_EVENT_ORIGIN_EXTERNAL, pEvent);

	/* Dispatch it to active applications.*/
	DispatchEventToApps(pThreadContext, pEvent);

	DispatchInternalEvents(pThreadContext);

	/* Free external event if necessary. */
	if (pThreadContext->fnDelExtEvent && pEvent)
	{
		(*pThreadContext->fnDelExtEvent)(pEvent);
		// Engine should delete this event, because translation of external event will create an internal event. 
		SmeDeleteEvent(pEvent); 
	}
	
	return 0;
}

CEgnSubclassWnd EngSubclassWnd;

BOOL MfcHookWnd(HWND hWndHooked)
{
	if (hWndHooked==NULL || !IsWindow(hWndHooked)) return FALSE;

	CWnd *pWnd = CWnd::FromHandle(hWndHooked);
	return EngSubclassWnd.HookWindow(pWnd);	
}

BOOL MfcUnhookWnd(HWND hWndHooked)
{
	if (hWndHooked==NULL || !IsWindow(hWndHooked)) return FALSE;

	CWnd *pWnd = CWnd::FromHandle(hWndHooked);
	return EngSubclassWnd.HookWindow(pWnd);	
}
