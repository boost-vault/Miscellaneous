/**********************************************************************
UML StateWizard provides its software under the GPL License and zlib/libpng License for open source projects.

Email us at info@intelliwizard.com for any information, suggestions and feature requestions.

http://www.intelliwizard.com
*************************************************************************/



/* =============================================================================
 * Filename:    ThreadManager.cpp
 * 
 * Copyright  IntelliWizard Inc. www.intelliwizard.com
 * -----------------------------------------------------------------------------
 * General description of this file:
 *
 * Manager application thread in simulation mode.
 * -----------------------------------------------------------------------------
 *                               Revision History
 * -----------------------------------------------------------------------------
 * Version   Date           Revision Detail
 * 1.0.0    2004/11/26		Initial
			2005/8/28		Multi-thread engine support	
 * ===========================================================================*/

/* =============================================================================
 *                               INCLUDE FILES
 * ===========================================================================*/
#include "stdafx.h"
#include "ThreadManager.h"
#include "sme.h"
#include "sme_debug.h"
#include "SrvAgent.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/* =============================================================================
 *                            LOCAL     CONSTANTS
 * ===========================================================================*/
/* =============================================================================
 *                  LOCAL STRUCTURES AND OTHER TYPEDEFS
 * ===========================================================================*/

/*==============================================================================
 *                              LOCAL   MACROS
 * ===========================================================================*/
 
 /*==============================================================================
 *                              GLOBAL   Variables
 * ===========================================================================*/

// The following varables are some basic variables in Simulation.
HWND		g_hSimWndHdle = NULL;
HINSTANCE	g_hAppDll =NULL;

typedef void (*APP_MAIN_PROC)(SME_THREAD_CONTEXT_PT pThreadContext);


BOOL SetThreadContext(SME_THREAD_CONTEXT_PT p);
SME_THREAD_CONTEXT_PT GetThreadContext();
BOOL PostExtThreadEvent(long nEventId, void* pData, int nDataSize, void *pDestPort,
						struct SME_THREAD_CONTEXT_T* pDestThreadContext);

/******************************* FUNCTION HEADER BEGIN *************************
 * Function Name:     AgtSetEngineOprProc
 * Input Parameters:  None. 
 * Return Value:      0
 * Global Variables:  None
 * File Variables:    None
 * Description:  
   Install default RTOS delayer functions for engine.
 
   1) TLS
   2) Set event handler functions 
   3) memory operation functions for Windows platform editions.
 ******************************************************************************/
BOOL AgtSetEngineOprProc(SME_THREAD_CONTEXT_PT pThreadContext)
{
	// Install thread local storage data functions.
	SmeSetTlsProc(SetThreadContext, GetThreadContext);
	// Save the thread context pointer to the TLS.
	SetThreadContext(pThreadContext);

	// Install event handler functions.
	SmeSetExtEventOprProc(GetExtEvent, DelExtEvent,PostExtThreadEvent);
	// Install memory operation functions.
	SmeSetMemOprProc(SrvMAlloc, SrvMFree);
	return TRUE;
}


/******************************* FUNCTION HEADER BEGIN *************************
 * Function Name:     AgtStartAppThread
 * Input Parameters:  Install event handler functions. 
 * Return Value:      0
 * Global Variables:  None
 * File Variables:    None
 * Description:  Load application DLL and run application main thread.
 // This function is running at main app thread.
 ******************************************************************************/
#ifdef _WIN32_WCE
BOOL AgtStartAppThread(HWND hSimWinHdl, LPCTSTR sLibFileName, LPCTSTR sProcName,SME_THREAD_CONTEXT_PT pThreadContext)
#else
BOOL AgtStartAppThread(HWND hSimWinHdl, LPCTSTR sLibFileName, LPCSTR sProcName,SME_THREAD_CONTEXT_PT pThreadContext)
#endif

{
	// Launch App
	g_hSimWndHdle = hSimWinHdl;

	AgtSetEngineOprProc(pThreadContext);

	// Load App DLL
	g_hAppDll = LoadLibrary(sLibFileName);

	if (g_hAppDll != NULL)
	{
		APP_MAIN_PROC pfnAppMain = (APP_MAIN_PROC)::GetProcAddress(g_hAppDll, sProcName);
		if (pfnAppMain)
			(*pfnAppMain)(pThreadContext);
		return TRUE;
	} else return FALSE;
}

/******************************* FUNCTION HEADER BEGIN *************************
 * Function Name:     AgtStartAppChildThread
 * Input Parameters:  Install event handler functions. 
 * Return Value:      0
 * Global Variables:  None
 * File Variables:    None
 * Description:  Run application child thread. 
 Note that: All applications should locate in the application DLL. 
 The thread entry function is loaded by AgtStartAppThread().      
 ******************************************************************************/
#ifdef _WIN32_WCE
BOOL AgtStartAppChildThread(LPCTSTR sProcName,SME_THREAD_CONTEXT_PT pThreadContext)
#else
BOOL AgtStartAppChildThread(LPCSTR sProcName,SME_THREAD_CONTEXT_PT pThreadContext)
#endif
{
	if (sProcName==NULL) return FALSE;

	// Wait until application DLL is loaded.
	int nTime=0;

	while (g_hAppDll==NULL)
	{
		if (nTime < 100)
			Sleep(100);
		else return FALSE;
	}

	// Launch App

	AgtSetEngineOprProc(pThreadContext);

	APP_MAIN_PROC pfnAppChild = (APP_MAIN_PROC)::GetProcAddress(g_hAppDll, sProcName);
	if (pfnAppChild)
		(*pfnAppChild)(pThreadContext);

	return TRUE;

}
/******************************* FUNCTION HEADER BEGIN *************************
 * Function Name:     AgtFreeAppDll
 * Input Parameters:  
 * Return Value:      None
 * Global Variables:  None
 * File Variables:    None
 * Description:  
 This function reset simulation for App power down. 
 ******************************************************************************/
BOOL AgtFreeAppDll()
{

	if (g_hAppDll)
	{
		FreeLibrary(g_hAppDll);
		g_hAppDll = NULL;
		return TRUE;
	} return FALSE;

}

/******************************* FUNCTION HEADER BEGIN *************************
 * Function Name:     GetExtEvent
 * Input Parameters:  .
 * Return Value:      None
 * Global Variables:  None
 * File Variables:    None
 * Description:  This function wait for external event.
 Note: If return value is NULL, 
 ******************************************************************************/
struct SME_EVENT_T * GetExtEvent()
{
	MSG WinMsg;
	struct SME_EVENT_T* pExtEvent;

	// GetMessage()
	// If the function retrieves a message other than WM_QUIT, the return value is nonzero.
	// If the function retrieves the WM_QUIT message, the return value is zero. 
	while (GetMessage(&WinMsg, NULL, 0, 0))
	{
		if (WinMsg.message == WM_EXT_EVENT_ID)
		{
			// External event is triggered. App go to running state.
			pExtEvent = TranslateEvent(&WinMsg); 

			return pExtEvent;
		} 
		// Handle Windows messages in MMI thread, for example audio messages.
		else //if (handle_win_msg_in_mmi_thread(&WinMsg) == FALSE)
		{
			// MSDN: DispatchMessage API
			// The DispatchMessage function dispatches a message to a window procedure.

			// MSDN: DefWindowProc API
			// The DefWindowProc function calls the default window procedure to provide default 
			// processing for any window messages that an application does not process. This 
			// function ensures that every message is processed. 

			// MSDN: WM_TIMER
			// The WM_TIMER message is posted to the installing thread's message queue 
			// when a timer expires. You can process the message by providing a WM_TIMER case 
			// in the window procedure. Otherwise, the default window procedure (DefWindowProc) 
			// will call the TimerProc callback function specified in the call to the SetTimer 
			// function used to install the timer. 

			// Handle Windows messages by the default window procedure in MMI thread  
			// for example calling the TimerProc callback function for timer messages.
			DispatchMessage(&WinMsg);
		};
	}

	// Handle WM_QUIT message when MMI call PostQuitMessage() funcion.
	//g_pMMIThread->ExitInstance();
	// Reset simulation for MMI.
	// AppThreadExit(pThreadContext);
	// End MMI UI thread with exit code provided by PostQuitMessage().
	
	// Call this function to terminate the currently executing thread. 
	// Must be called from within the thread to be terminated.
	if (WinMsg.lParam)
	{
		AGT_CALL_BACK_PROC_T pfnCallBack = (AGT_CALL_BACK_PROC_T)(WinMsg.lParam);
		WPARAM wParam = WinMsg.wParam;
		(*pfnCallBack)(&wParam);
	}
	return NULL;
}

/******************************* FUNCTION HEADER BEGIN *************************
 * Function Name:     DelExtEvent
 * Input Parameters:  None
 * Return Value:      None
 * Description:       
 ******************************************************************************/
BOOL DelExtEvent(struct SME_EVENT_T *pEvent)
{
	if (SME_MSG2HDR(pEvent->Data.Ptr.pData))
		delete (SME_MSG2HDR(pEvent->Data.Ptr.pData));
	return TRUE;
}

/******************************* FUNCTION HEADER BEGIN *************************
 * Function Name:     PostExtThreadEvent
 * Input Parameters:  None
 * Return Value:      None
 * Description:  Post an event to another thread.     
 ******************************************************************************/
BOOL PostExtThreadEvent(long nEventId, void* pData, int nDataSize, void *pDestPort,
						struct SME_THREAD_CONTEXT_T* pDestThreadContext)
{
	return AgtPostExtEvent(nEventId, pData, nDataSize, pDestPort,
		pDestThreadContext);  
}

/******************************* FUNCTION HEADER BEGIN *************************
 * Function Name:     AgtEndAppThread
 * Input Parameters:  None.
 * Return Value:      None
 * Global Variables:  None
 * File Variables:    None
 * Description:  
 
   This function posts WM_QUIT message to App thread requested 
	end of App thread.      
 ******************************************************************************/
BOOL AgtEndAppThread(SME_THREAD_CONTEXT_PT pThreadContext, AGT_CALL_BACK_PROC_T pfnCallback)
{
	if (pThreadContext->nAppThreadID != 0)
	{
		// End application thread. Stop state tracking.
		StateTrack(NULL, NULL, -1);

		// Request to exit thread. WM_QUIT nExitCode = (int) wParam, lParam = Call back function pointer.
		VERIFY(PostThreadMessage(pThreadContext->nAppThreadID,WM_QUIT,(WPARAM)0,(LPARAM)pfnCallback)==TRUE);
		// Wait for thread to exit.
		//WaitForSingleObject(pThreadContext->hThread, INFINITE);
		return TRUE;
	}
	return FALSE;
}


struct SME_EVENT_T* TranslateEvent(MSG *pWinMsg)
{
	SME_SRV_MSG_HEADER_T *pUserMsg =(SME_SRV_MSG_HEADER_T *)(pWinMsg->wParam);
	void *pData = SME_HDR2MSG(pUserMsg);
	void *pPort = pUserMsg->pDestPort; 
	SME_APP_T *pDestApp=NULL;

	// If the destination port is not empty, look up the application in port and app mapping table.

	SME_EVENT_T* e = SmeCreatePtrEvent(pUserMsg->nEventId, 
		pData,
		pUserMsg->nDataLen,
		SME_EVENT_CAT_OTHER,
		pDestApp);
	
	if (e) 
	{
		e->pPortInfo = pPort;
		e->nOrigin = SME_EVENT_ORIGIN_EXTERNAL;
	}
	return e;
}

/******************************* FUNCTION HEADER BEGIN *************************
 * Function Name:     AgtPostExtEvent
 * Input Parameters:  None.
 * Return Value:      None
 * Global Variables:  None
 * File Variables:    None
 * Description:  
 
   This function create a service provider message to App thread. 
   The message contains message header and service provider message.
 ******************************************************************************/
BOOL AgtPostExtEvent(long nEventId, void* pData, int nDataSize, void *pDestPort,
					 SME_THREAD_CONTEXT_PT pThreadContext)
{
	void *pDataCopy, *pSrvMsg;
	unsigned long nMsgSize = sizeof(SME_SRV_MSG_HEADER_T) + nDataSize;

	if (pThreadContext->nAppThreadID==NULL) return FALSE;

	pSrvMsg = new char[nMsgSize];

	SME_SRV_MSG_HEADER_T *pHdr = (SME_SRV_MSG_HEADER_T *)pSrvMsg;
	pHdr->nEventId = nEventId;
	pHdr->nDataLen = nDataSize;
	pHdr->pDestPort = pDestPort;

	if (pData!=NULL && nDataSize>0)
	{
		pDataCopy = SME_HDR2MSG(pHdr);
		memcpy(pDataCopy, pData, nDataSize);
	}

	return PostThreadMessage(pThreadContext->nAppThreadID, 
		WM_EXT_EVENT_ID, 
		(WPARAM)pSrvMsg, 
		(LPARAM)nMsgSize);
}

BOOL MfcPostExtPtrEventToWnd(long nEventId, void* pData, int nDataSize, void *pDestPort, HWND hWndHooked)
{
	void *pDataCopy, *pSrvMsg;
	unsigned long nMsgSize = sizeof(SME_SRV_MSG_HEADER_T) + nDataSize;
	pSrvMsg = new char[nMsgSize];

	SME_SRV_MSG_HEADER_T *pHdr = (SME_SRV_MSG_HEADER_T *)pSrvMsg;
	pHdr->nEventId = nEventId;
	pHdr->nDataLen = nDataSize;
	pHdr->pDestPort = pDestPort;

	if (pData!=NULL && nDataSize>0)
	{
		pDataCopy = SME_HDR2MSG(pHdr);
		memcpy(pDataCopy, pData, nDataSize);
	}

	return PostMessage(hWndHooked, 
		WM_EXT_EVENT_ID, 
		(WPARAM)pSrvMsg, 
		(LPARAM)nMsgSize);
}

BOOL MfcSendExtPtrEventToWnd(long nEventId, void* pData, int nDataSize, void *pDestPort, HWND hWndHooked)
{
	void *pDataCopy, *pSrvMsg;
	unsigned long nMsgSize = sizeof(SME_SRV_MSG_HEADER_T) + nDataSize;
	pSrvMsg = new char[nMsgSize];

	SME_SRV_MSG_HEADER_T *pHdr = (SME_SRV_MSG_HEADER_T *)pSrvMsg;
	pHdr->nEventId = nEventId;
	pHdr->nDataLen = nDataSize;
	pHdr->pDestPort = pDestPort;

	if (pData!=NULL && nDataSize>0)
	{
		pDataCopy = SME_HDR2MSG(pHdr);
		memcpy(pDataCopy, pData, nDataSize);
	}

	return SendMessage(hWndHooked, 
		WM_EXT_EVENT_ID, 
		(WPARAM)pSrvMsg, 
		(LPARAM)nMsgSize);
}

BOOL MfcPostExtIntEventToWnd(long nEventId, unsigned long nParam1, unsigned long nParam2, void *pDestPort, HWND hWndHooked)
{
	struct INT_EVENT_DATA_T
	{
		unsigned long nParam1;
		unsigned long nParam2;
	} Data = {nParam1, nParam2 };

	return MfcPostExtPtrEventToWnd(nEventId, &Data, sizeof(Data), pDestPort, hWndHooked);
}

BOOL MfcSendExtIntEventToWnd(long nEventId, unsigned long nParam1, unsigned long nParam2, void *pDestPort, HWND hWndHooked)
{
	struct INT_EVENT_DATA_T
	{
		unsigned long nParam1;
		unsigned long nParam2;
	} Data = {nParam1, nParam2 };

	return MfcSendExtPtrEventToWnd(nEventId, &Data, sizeof(Data), pDestPort, hWndHooked);
}

void* SrvMAlloc(unsigned int nSize)
{
	return malloc(nSize);
}

BOOL SrvMFree(void* pUserData)
{
	free(pUserData);
	return TRUE;
}

////////////////////////////////////////////////////////////////////////////////////////
DWORD g_dwTlsIndex=0xFFFFFFFF;
/******************************* FUNCTION HEADER BEGIN *************************
 * Function Name:     SetThreadContext
 * Input Parameters:  
 * Return Value:      BOOL
 * Global Variables:  None
 * File Variables:    None
 * Description:  
 
   Set thread context into thread local storage.
 ******************************************************************************/
BOOL SetThreadContext(SME_THREAD_CONTEXT_PT p)
{
	if (0xFFFFFFFF != g_dwTlsIndex)
		return TlsSetValue(g_dwTlsIndex, p);
	else
		return FALSE;
}

/******************************* FUNCTION HEADER BEGIN *************************
 * Function Name:     GetThreadContext
 * Input Parameters:  
 * Return Value:      BOOL
 * Global Variables:  None
 * File Variables:    None
 * Description:  
 
   Get thread context into local storage data.
 ******************************************************************************/
SME_THREAD_CONTEXT_PT GetThreadContext()
{
	if (0xFFFFFFFF != g_dwTlsIndex)
		return (struct SME_THREAD_CONTEXT_T*)TlsGetValue(g_dwTlsIndex);
	else
		return NULL;
}

