/**********************************************************************
UML StateWizard provides its software under the GPL License and zlib/libpng License for open source projects.

Email us at info@intelliwizard.com for any information, suggestions and feature requestions.

http://www.intelliwizard.com
*************************************************************************/




// EgnSubclassWnd.h: interface for the CEgnSubclassWnd class.
//
//////////////////////////////////////////////////////////////////////

#if !defined(AFX_EGNSUBCLASSWND_H__0210765A_1DAF_4305_B45E_EE9AA267A7C8__INCLUDED_)
#define AFX_EGNSUBCLASSWND_H__0210765A_1DAF_4305_B45E_EE9AA267A7C8__INCLUDED_

#if _MSC_VER > 1000
#pragma once
#endif // _MSC_VER > 1000

#include "Subclass.h"
#include "sme.h"

class CEgnSubclassWnd: public CSubclassWnd  
{
public:
	CEgnSubclassWnd();
	virtual ~CEgnSubclassWnd();
	
	virtual LRESULT WindowProc(HWND hwnd, UINT msg, WPARAM wp,LPARAM lp);
	LRESULT OnExtEvent(MSG& WinMsg);

};

#endif // !defined(AFX_EGNSUBCLASSWND_H__0210765A_1DAF_4305_B45E_EE9AA267A7C8__INCLUDED_)
