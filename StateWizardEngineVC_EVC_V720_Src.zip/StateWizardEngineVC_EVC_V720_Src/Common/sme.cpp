/**********************************************************************
UML StateWizard provides its software under the GPL License and zlib/libpng License for open source projects.

Email us at info@intelliwizard.com for any information, suggestions and feature requestions.

http://www.intelliwizard.com
*************************************************************************/

/* =============================================================================
 * Filename:    sme.cpp 
 * Multi-thread Edition
 *
 * Copyright  IntelliWizard Inc. www.intelliwizard.com
 * All rights reserved.
 * -----------------------------------------------------------------------------
 * General description of this file:
 *
 * The state machine engine APIs implementaion.
 * -----------------------------------------------------------------------------
 *                               Revision History
 * -----------------------------------------------------------------------------
 * Version   Date			Revision Detail
 * 1.0.0    2004/11/26      Initial
			2005/3/3		SmeInitEngine initializes gloabl variables.
			2005/3/16		Create and delete event from event pool. 
			2005/3/28		Free external event by SmeRun.
			2005/4/7		Check the internal event pool and then check external event pool.
			2005/4/12		If an event has destination application. Dispatch it if the application is active.
			2005/8/27		MultiThread support. 
							a) Only one external event queue;
							b) Allocate one internal event queue for one thread.
			2005/8/31		Memory the pointer to the main thread context. 
			2005/9/13		Keep tack of the route of state transition
			2005/12/23		Manage thread context using Thread Local Storage.
							Merge Unicode & Ascii editions. Export all functions by DLL. Header file will map macros to different functions
							depending _UNICODE defined or not.
			2006/3/11		Add DispatchInteranlEvents();
 * ===========================================================================*/
#include "stdafx.h"
#include "SrvAgent.h"

#include "sme.h"
#include "sme_debug.h"

#define SME_MAX_STATE_NUM			65532
#define SME_MAX_STATE_TREE_DEPTH	16
/*******************************************************************************************
* State Machine Engine static variables.
*******************************************************************************************/
static SME_MEM_ALLOC_PROC_T g_fnMAllocProc = NULL;
static SME_MEM_FREE_PROC_T g_fnMFreeProc = NULL;

static SME_SET_THREAD_CONTEXT_PROC g_pfnSetThreadContext=NULL;
SME_GET_THREAD_CONTEXT_PROC g_pfnGetThreadContext=NULL;

BOOL DispatchInternalEvents(SME_THREAD_CONTEXT_PT pThreadContext);
BOOL DispatchEventToApps(SME_THREAD_CONTEXT_PT pThreadContext,SME_EVENT_T *pEvent);

/*******************************************************************************************
* DESCRIPTION:  Initialize state machine engine given the thread context.
* INPUT:  None.
* OUTPUT: None.
* NOTE: 
*******************************************************************************************/
void SmeInitEngine(SME_THREAD_CONTEXT_PT pThreadContext)
{
	int i;
	if (!pThreadContext) return;

#if defined(WIN32) || defined(_WIN32_WCE)
	//Set event handler functions and memory operation functions for Windows platform editions.
	AgtSetEngineOprProc(pThreadContext);
#else
	// For the platform indepent engine..
	// Save the thread context pointer to the TLS.
	if (g_pfnSetThreadContext) (*g_pfnSetThreadContext)(pThreadContext);
#endif

	/* Service agent will automatically set the following Virtual RTOS functions, when
	application thread launches.

	pThreadContext->fnGetExtEvent = NULL;
	pThreadContext->fnDelExtEvent = NULL;
	g_fnMAllocProc = NULL;
	g_fnMFreeProc = NULL;
	*/

	pThreadContext->pActAppHdr = NULL;
	pThreadContext->pFocusedApp = NULL;

	pThreadContext->pEventQueueFront=NULL; 
	pThreadContext->pEventQueueRear=NULL;


	pThreadContext->fnOnEventComeHook = NULL; 
	pThreadContext->fnOnEventHandleHook = NULL;

	SME_DBG_INIT(); 

	/* Set all event pool are empty. */
	for (i=0; i<SME_EVENT_POOL_SIZE; i++)
		pThreadContext->EventPool[i].nEventID = SME_INVALID_EVENT_ID;
	pThreadContext->nEventPoolIdx =0;
}

/*******************************************************************************************
* DESCRIPTION:  Get an event data buffer from event pool.
* INPUT:  None
* OUTPUT: New event pointer. If pool is used up, return NULL. 
* NOTE: 
*   
*******************************************************************************************/
static struct SME_EVENT_T *GetAEvent()
{
	struct SME_EVENT_T *e=NULL;
	int nOldEventPoolIdx;
	SME_THREAD_CONTEXT_PT pThreadContext=NULL;

	if (g_pfnGetThreadContext)
		pThreadContext = (*g_pfnGetThreadContext)();
	if (!pThreadContext) return NULL;

	nOldEventPoolIdx = pThreadContext->nEventPoolIdx;
	do {
		if (pThreadContext->EventPool[pThreadContext->nEventPoolIdx].nEventID == SME_INVALID_EVENT_ID)
		{
			/*This event data buffer is available.*/
			e = &(pThreadContext->EventPool[pThreadContext->nEventPoolIdx]);
			pThreadContext->nEventPoolIdx = (pThreadContext->nEventPoolIdx+1)%SME_EVENT_POOL_SIZE;
			return e;
		} else
		{
			pThreadContext->nEventPoolIdx = (pThreadContext->nEventPoolIdx+1)%SME_EVENT_POOL_SIZE;
			if (pThreadContext->nEventPoolIdx == nOldEventPoolIdx)
				return NULL;
		}
	} while(TRUE);

}
/*******************************************************************************************
* DESCRIPTION:  Create a state machine event.
* INPUT:  event id, parameter1, parameter2, event category, destination application pointer.
* OUTPUT: New event pointer.
* NOTE: 
*   
*******************************************************************************************/
struct SME_EVENT_T *SmeCreateIntEvent(SME_EVENT_ID_T nEventId,
								   unsigned long nParam1,
								   unsigned long nParam2,
								   SME_EVENT_CAT_T nCategory,
								   struct SME_APP_T *pDestApp)
{
	struct SME_EVENT_T *e=NULL;

	if (nEventId==SME_INVALID_EVENT_ID)
		return NULL;

	if(e=GetAEvent())
	{
		e->nEventID=nEventId;
		e->nSequenceNum =0;
		e->pNext = NULL;
		e->Data.Int.nParam1 = nParam1;
		e->Data.Int.nParam2 = nParam2;
		e->pDestApp=pDestApp;
		e->pPortInfo = NULL;
 		e->nOrigin = SME_EVENT_ORIGIN_INTERNAL;
		e->nCategory=nCategory;
		e->nDataFormat = SME_EVENT_DATA_FORMAT_INT;
		e->bIsConsumed = FALSE;
	}
	return e;
}

struct SME_EVENT_T *SmeCreatePtrEvent(SME_EVENT_ID_T nEventId,
								   void* pData,
								   unsigned long nSize,
								   SME_EVENT_CAT_T nCategory,
								   struct SME_APP_T *pDestApp)
{
	struct SME_EVENT_T *e=NULL;

	if(e=GetAEvent())
	{
		e->nEventID=nEventId;
		e->nSequenceNum =0;
		e->pNext = NULL;
		e->Data.Ptr.pData = pData;
		e->Data.Ptr.nSize = nSize;
		e->pDestApp=pDestApp;
		e->pPortInfo = NULL;
		e->nOrigin = SME_EVENT_ORIGIN_INTERNAL; //by default
		e->nCategory=nCategory;
		e->nDataFormat = SME_EVENT_DATA_FORMAT_PTR;
		e->bIsConsumed = FALSE;
	}
	return e;
}

/*******************************************************************************************
* DESCRIPTION:  
* INPUT:  
* OUTPUT: None.
* NOTE: 
*   
*******************************************************************************************/
BOOL SmeDeleteEvent(struct SME_EVENT_T *pEvent)
{
	if(!pEvent) return FALSE;
	pEvent->nEventID = SME_INVALID_EVENT_ID;
	return TRUE;
	/*return SmeMFree(pEvent);*/
}

/*******************************************************************************************
* DESCRIPTION: Activate the given application. 
* INPUT:  
*  1) pNewApp: The new activated application.
*  2) pParentApp: who starts this new activated application.
* OUTPUT: None.
*  TRUE: Start it successfully.
*  FALSE: Fail to start it.
* NOTE: 
*  The active applications are linked as a stack.
*  NULL <--- Node.pNext  <--- Node.pNext  <--- pThreadContext->pActAppHdr
*******************************************************************************************/
BOOL SmeActivateApp(struct SME_APP_T *pNewApp, struct SME_APP_T *pParentApp)
{
	SME_STATE_T nState;
	SME_THREAD_CONTEXT_PT pThreadContext=NULL;

	if (g_pfnGetThreadContext)
		pThreadContext = (*g_pfnGetThreadContext)();
	if (!pThreadContext) return NULL;

	if(!pNewApp || SME_IS_ACTIVATED(pNewApp)) return FALSE;

	pNewApp->pParent = pParentApp;
    /* Push the new application to active application stack. */
	pNewApp->pNext=pThreadContext->pActAppHdr;
	pThreadContext->pActAppHdr=pNewApp;
	
	/* Call default entry functions. */
	nState = SME_APP_STATE; /* The new application state. */
	pNewApp->nAppState = SME_APP_STATE; // Keep track of the route of state transitions including non-leaf node.
	do 
	{
		/* Call state's entry function.*/
		if(pNewApp->pStateTree[nState].pEventTable[SME_ENTRY_FUNC_IDX].pHandler)
			pNewApp->pStateTree[nState].pEventTable[SME_ENTRY_FUNC_IDX].pHandler(pNewApp,NULL);

		if (pNewApp->pStateTree[nState].nDefSubState == SME_INVALID_STATE)
		{
			pNewApp->nAppState = nState; /* New application state is the destination state's leaf. */
			break;
		} else
		{
			nState = pNewApp->pStateTree[nState].nDefSubState;
			pNewApp->nAppState = nState; // Keep track of the route of state transitions including non-leaf node.
		}
	} while(TRUE); /* It is not a leaf.*/

	/* Dispatch all internal events which may be triggered by entry functions.*/
	DispatchInternalEvents(pThreadContext);
	
	/* Focus on the new application. */
	SmeSetFocus(pNewApp);



#if defined(WIN32) || defined(_WIN32_WCE)
	StateTrack(NULL, pNewApp, pNewApp->nAppState);
#endif

	return TRUE;
}

/*******************************************************************************************
* DESCRIPTION:  De-activate the given application.
* INPUT:  
*  pApp: the application to be de-activated.
* OUTPUT: None.
*  TRUE: Deactivate it successfully.
*  FALSE: Fail to de-activate it.
* NOTE: 
*******************************************************************************************/
BOOL SmeDeactivateApp(struct SME_APP_T *pApp)
{
	struct SME_APP_T *p,*pPre;
	SME_STATE_T nState;
	SME_THREAD_CONTEXT_PT pThreadContext=NULL;

	if (g_pfnGetThreadContext)
		pThreadContext = (*g_pfnGetThreadContext)();
	if (!pThreadContext) return NULL;

	if (!pApp || !SME_IS_ACTIVATED(pApp)) return FALSE;

	/* Locate the application in the active application stack.*/
	p=pThreadContext->pActAppHdr;
	pPre=NULL;
	while (p!=NULL)
	{
		/* The application should be located in the leaf of the active application tree.*/
		if (p->pParent == pApp)
			return FALSE;
		/* 1) Get the previous node of pApp.*/
		if (p->pNext == pApp)
			pPre=p;
		/* 2) Move to next application and traverse all applications. Assert pApp is a leaf. */
		p=p->pNext;
	}

	/* Adjust active application stack. */
	if (pApp==pThreadContext->pActAppHdr)
		/* the application is the active applcation header.*/
		pThreadContext->pActAppHdr=pApp->pNext;
	else
		pPre->pNext=pApp->pNext;

	/* If de-activated application is a focused application,the de-activated application's
	parent will be new focused application*/
	if	(pApp==pThreadContext->pFocusedApp)
		if (pApp->pParent != NULL)
			SmeSetFocus(pApp->pParent); /* Focus on the parent application.*/
		else 
			pThreadContext->pFocusedApp = NULL; /* No any application focused.*/

	/* Call exit functions from leaf to the root.*/
	nState = pApp->nAppState; /* It should be leaf. */
	do {
		if(pApp->pStateTree[nState].pEventTable[SME_EXIT_FUNC_IDX].pHandler)
			pApp->pStateTree[nState].pEventTable[SME_EXIT_FUNC_IDX].pHandler(pApp,NULL);
		nState=pApp->pStateTree[nState].nParentState;
		pApp->nAppState = nState; // Keep track of the route of state transitions including non-leaf node.
	} while (nState != SME_INVALID_STATE); /* The root state's parent should be invalid.*/

	/* Reset the application data.*/
	pApp->nAppState=SME_INVALID_STATE; 
	pApp->pNext =NULL;
	pApp->pParent =NULL;

	/* Dispatch all internal events which may be triggered by exit functions.*/
	DispatchInternalEvents(pThreadContext);


#if defined(WIN32) || defined(_WIN32_WCE)
	StateTrack(NULL, pApp, pApp->nAppState);
#endif
	return TRUE;
}

/*******************************************************************************************
* DESCRIPTION: Set an application focused. 
* INPUT:  
* OUTPUT: None.
* NOTE: 
*   Send SME_EVENT_KILL_FOCUS event to old focused application. And send SME_EVENT_SET_FOCUS
*   to the new focused application.
*******************************************************************************************/
BOOL SmeSetFocus(struct SME_APP_T *pApp)
{
	struct SME_EVENT_T *pEvent1,*pEvent2;
	SME_THREAD_CONTEXT_PT pThreadContext=NULL;

	if (g_pfnGetThreadContext)
		pThreadContext = (*g_pfnGetThreadContext)();
	if (!pThreadContext) return NULL;

	if (!pApp) return FALSE;

	if (pThreadContext->pFocusedApp)
	{
		pEvent1=SmeCreateIntEvent(SME_EVENT_KILL_FOCUS,
			0, /*(unsigned long)pApp,*/
			0,
			SME_EVENT_CAT_UI,
			pThreadContext->pFocusedApp);
		if (pEvent1!=NULL)
		{
			SmeDispatchEvent(pEvent1,pThreadContext->pFocusedApp);
			SmeDeleteEvent(pEvent1);
		} else return FALSE;
	}

    pEvent2=SmeCreateIntEvent(SME_EVENT_SET_FOCUS,
		0, /*(unsigned long)pThreadContext->pFocusedApp,*/
		0,
		SME_EVENT_CAT_UI,
		pApp);
	if (pEvent2!=NULL)
	{
		SmeDispatchEvent(pEvent2,pApp);
		SmeDeleteEvent(pEvent2);
	}

    pThreadContext->pFocusedApp=pApp;

	return TRUE;
}

/*******************************************************************************************
* DESCRIPTION:  Post an event to queue.
* INPUT:  pEvent: An event.
* OUTPUT: None.
* NOTE: 
*   
*******************************************************************************************/
BOOL SmePostEvent(struct SME_EVENT_T *pEvent)
{
	SME_THREAD_CONTEXT_PT pThreadContext=NULL;

	if (g_pfnGetThreadContext)
		pThreadContext = (*g_pfnGetThreadContext)();
	if (!pThreadContext) return NULL;

	if (pEvent == NULL) return FALSE;

	if (pThreadContext->pEventQueueRear==NULL) 
	{ 
		/* The first event in queue. */
		pThreadContext->pEventQueueFront=pThreadContext->pEventQueueRear=pEvent;
	}
	else 
	{
		/* Append the event to queue.*/
		pThreadContext->pEventQueueRear->pNext=pEvent;
		pEvent->pNext=NULL;
		pThreadContext->pEventQueueRear=pEvent;
	}
	return TRUE;
}

/*******************************************************************************************
* DESCRIPTION:  Post an external event to another thread.
* INPUT:  pEvent: An event.
* OUTPUT: None.
* NOTE: 
*   This function does not need thread synchronization. It calls PostThreadMessage().
*******************************************************************************************/
BOOL SmePostExtThreadEvent(long nEventId, void* pData, int nDataSize, void *pDestPort,
						SME_THREAD_CONTEXT_PT pDestThreadContext)
{
	if (pDestThreadContext && pDestThreadContext->fnPostExtThreadEvent)
	{
		return (*pDestThreadContext->fnPostExtThreadEvent)(nEventId, pData, nDataSize, pDestPort,pDestThreadContext);
	}
	return FALSE;
}

/*******************************************************************************************
* DESCRIPTION:  Get an event from queue.
* INPUT:  pEvent: An event.
* RETURN: Event in the head of queue. return NULL if not available.
* NOTE: 
*   
*******************************************************************************************/
struct SME_EVENT_T * GetEventFromQueue()
{
	/* Get an event from event queue if available. */
	struct SME_EVENT_T *pEvent = NULL;
	SME_THREAD_CONTEXT_PT pThreadContext=NULL;

	if (g_pfnGetThreadContext)
		pThreadContext = (*g_pfnGetThreadContext)();
	if (!pThreadContext) return NULL;

	if (pThreadContext->pEventQueueFront != NULL)
	{
		pEvent = pThreadContext->pEventQueueFront;
		pThreadContext->pEventQueueFront = pThreadContext->pEventQueueFront->pNext;
		/* Set the end of queue to NULL if queue is empty.*/
		if (pThreadContext->pEventQueueFront == NULL)
			pThreadContext->pEventQueueRear = NULL;
	}
	return pEvent;
}
/*******************************************************************************************
* DESCRIPTION: Dispatch the incoming event to an application if it is specified, otherwise
*  dispatch to all active applications untile it is consumed.  
* INPUT:  
*  1) pEvent: Incoming event 
*  2) pApp: The destination application that event will be dispatched.
* OUTPUT: None.
* NOTE: 
*	1) Call exit functions in old state   
*	2) Call event handler functions   
*	3) Call entry functions in new state  
*  4) Transit from one state region to another state region. All states exit functions that jump out 
*  the old region will be called. And all states exit functions that jump in the new region will be called.
*  5) Although there is a property pEvent->pDestApp in SME_EVENT_T, this function will ignore this one,
*		because if pEvent->pDestApp is NULL, this event have to dispatch to all active applications.
*******************************************************************************************/
BOOL SmeDispatchEvent(struct SME_EVENT_T *pEvent, 
					  struct SME_APP_T *pApp)
{
	SME_STATE_T nOldState; /* Old state should be a leaf.*/
	SME_STATE_T nState;
    SME_STATE_T nNewState;
	int i;
	BOOL bFoundHandler=FALSE;
	SME_EVENT_HANDLER_T pHandler = NULL;

	SME_STATE_T OldStateStack[SME_MAX_STATE_TREE_DEPTH];
	SME_STATE_T NewStateStack[SME_MAX_STATE_TREE_DEPTH];
	SME_STATE_T nOldStateStackTop =0;
	SME_STATE_T nNewStateStackTop =0;

	/* Trace back from leaf to root, so as to retrieve all event handler tables.
	 Find what nNewState is */
	struct SME_EVENT_TABLE_T *pStateEventTable;

	SME_THREAD_CONTEXT_PT pThreadContext=NULL;

	if (g_pfnGetThreadContext)
		pThreadContext = (*g_pfnGetThreadContext)();
	if (!pThreadContext) return NULL;

	if (pEvent==NULL || pApp==NULL) return FALSE;

	nOldState = pApp->nAppState; /* Old state should be a leaf. */
	nState = nOldState;
	pStateEventTable = pApp->pStateTree[nOldState].pEventTable;

	/*******************************************************************************************
	 Check the state's event handler table from leaf to root.
	 If find it, stop searching, no matter there is another handler in parent sate's event table.
	*/
	while (TRUE)
	{
		/* Check the current state's event handler table.*/
		i=SME_EVENT_HANDLER_FUNC_IDX;
		while (pStateEventTable[i].nEventID != SME_INVALID_EVENT_ID)
		{
			if (pStateEventTable[i].nEventID == pEvent->nEventID)
			{
				nNewState=pStateEventTable[i].nNewState;
				bFoundHandler = TRUE;
				pHandler = pStateEventTable[i].pHandler;
				break;
			} else
				i++;
		}
		
		if (bFoundHandler || (nState == SME_APP_STATE)) break;
		/* Get the parent state's event handler table. */
		nState = pApp->pStateTree[nState].nParentState; 
		pStateEventTable = pApp->pStateTree[nState].pEventTable;
	}
	
	if (!bFoundHandler) return FALSE;
	/*******************************************************************************************/
	if (nNewState != SME_INTERNAL_TRAN)
	{
		/* It is a state transition.
		 Push all old state's ancestors.
		*/
		nState = nOldState;
		while (nState!=SME_APP_STATE)
		{
			OldStateStack[nOldStateStackTop++] = nState;
			nState=pApp->pStateTree[nState].nParentState;
			if (nOldStateStackTop >= SME_MAX_STATE_TREE_DEPTH)
				return FALSE;
		}

		/* Push all new state's ancestors. */
		nState = nNewState;
		while (nState!=SME_APP_STATE)
		{
			NewStateStack[nNewStateStackTop++] = nState;
			nState=pApp->pStateTree[nState].nParentState;
			if (nNewStateStackTop >= SME_MAX_STATE_TREE_DEPTH)
				return FALSE;
		}

		/* Pop all equal states except the last one.
		 Special case 1: self transition state1->state1, leave one item in each stack.
		 Special case 2: parent state transits to child state, leave one item in parent state stack.
		*/
		while ((nOldStateStackTop>1) && (nNewStateStackTop>1)
			&& (OldStateStack[nOldStateStackTop-1] == NewStateStack[nNewStateStackTop-1]))
		{
			nOldStateStackTop--;
			nNewStateStackTop--;
		}

		/* Get the leaf of the old state.
		 Note: Old state should be a leaf state.
		 Call exit functions from leaf nState to old state stacks top.
		 */
		for (i=0; i<nOldStateStackTop; i++)
		{
			nState = OldStateStack[i];
			pApp->nAppState = nState; // Keep track of the route of state transitions including non-leaf node.
			if(pApp->pStateTree[nState].pEventTable[SME_EXIT_FUNC_IDX].pHandler)
				pApp->pStateTree[nState].pEventTable[SME_EXIT_FUNC_IDX].pHandler(pApp,pEvent);
		};
	}; /* end of not internal transition.*/

	/*******************************************************************************************
	 Call event handler function if given enent handler is available and handler is not empty.
	 Maybe their is a transition, however handler is empty.
	*/
	if (bFoundHandler && pHandler)
	{
		(*pHandler)(pApp,pEvent);
	};

	/*******************************************************************************************
	 Call entry functions from new state stack's top to leaf state. */
	if (nNewState != SME_INTERNAL_TRAN)
	{
		/* It is a state transition.
		 Call entry functions from ancestor to new state.
		*/
		for (i=nNewStateStackTop-1; i>=0; i--)
		{
			nState = NewStateStack[i];
			pApp->nAppState = nState; // Keep track of the route of state transitions including non-leaf node.
			if(pApp->pStateTree[nState].pEventTable[SME_ENTRY_FUNC_IDX].pHandler)
				pApp->pStateTree[nState].pEventTable[SME_ENTRY_FUNC_IDX].pHandler(pApp,pEvent);
		};

		/* Call entry functions from new state's child to leaf. */
		nState=nNewState;
		while (pApp->pStateTree[nState].nDefSubState != SME_INVALID_STATE) /* It is not a leaf. */
		{
			nState=pApp->pStateTree[nState].nDefSubState;
			pApp->nAppState = nState; // Keep track of the route of state transitions including non-leaf node.
			/* Call default sub-state's entry function.*/
			if(pApp->pStateTree[nState].pEventTable[SME_ENTRY_FUNC_IDX].pHandler)
				pApp->pStateTree[nState].pEventTable[SME_ENTRY_FUNC_IDX].pHandler(pApp,pEvent);
		}

		pApp->nAppState = nState; /* New application state is the destination state's leaf. */
	};

	/*******************************************************************************************
	 Call event handle hook function if given enent handler is available and no matter whether handler is empty or not.
	 */
	if (bFoundHandler && pThreadContext->fnOnEventHandleHook)
		(*pThreadContext->fnOnEventHandleHook)((SME_EVENT_ORIGIN_T)(pEvent->nOrigin), 
			pEvent, 
			pApp, 
			pApp->nAppState);

#if defined(WIN32) || defined(_WIN32_WCE)
	// if (bFoundHandler)
	if (nOldState!=pApp->nAppState) /* State Updated? */
		StateTrack(pEvent, pApp, pApp->nAppState);
#endif
	return TRUE;
}
/*******************************************************************************************
* DESCRIPTION:  This API function installs geting and deleting external event functions. 
*  It will never exit. 
* INPUT:  
* OUTPUT: None.
* NOTE: 
*   
*******************************************************************************************/
void SmeSetExtEventOprProc(SME_GET_EXT_EVENT_PROC_T fnGetExtEvent, 
						   SME_DEL_EXT_EVENT_PROC_T fnDelExtEvent,
						   SME_POST_EXT_THREAD_EVENT_PROC_T fnPostExtThreadEvent)
{
	SME_THREAD_CONTEXT_PT pThreadContext=NULL;

	if (g_pfnGetThreadContext)
		pThreadContext = (*g_pfnGetThreadContext)();
	if (!pThreadContext) return;

	pThreadContext->fnGetExtEvent = fnGetExtEvent;
	pThreadContext->fnDelExtEvent = fnDelExtEvent;
	pThreadContext->fnPostExtThreadEvent = fnPostExtThreadEvent;

}

/*******************************************************************************************
* DESCRIPTION:  This API function is the state machine engine event handling loop function. 
*  It will never exit. 
* INPUT:  
* OUTPUT: None.
* NOTE: 

Engine has to check internal event first, because SmeActivateApp() may trigger some internal events.

Case:
	SmeActivateApp(&SME_GET_APP_VAR(PowerUpDown),NULL);
	SmeRun();
  
*******************************************************************************************/
void SmeRun()
{
	struct SME_EVENT_T *pExtEvent, *pEvent;
	struct SME_APP_T *pApp;
	
	SME_THREAD_CONTEXT_PT pThreadContext=NULL;
	if (g_pfnGetThreadContext)
		pThreadContext = (*g_pfnGetThreadContext)();
	if (!pThreadContext) return;

	if (!pThreadContext->fnGetExtEvent) return;

	pExtEvent = pEvent = NULL;
	pApp = pThreadContext->pActAppHdr;

	while (TRUE)
	{
		/* Check the internal event pool firstly. */
		pEvent = GetEventFromQueue();
		if (pEvent == NULL)
		{
			/* Wait for an external event. */
			pExtEvent = (*pThreadContext->fnGetExtEvent)();
			//if (pExtEvent == NULL) continue;
			if (pExtEvent == NULL) return; // Exit the thread.

			pEvent = pExtEvent;
			pEvent->nOrigin = SME_EVENT_ORIGIN_EXTERNAL;

			/* Call hook function on an external event coming. */
			if (pThreadContext->fnOnEventComeHook)
				(*pThreadContext->fnOnEventComeHook)(SME_EVENT_ORIGIN_EXTERNAL, pEvent);
		}else
		{
			/* Call hook function on an internal event coming. */
			if (pThreadContext->fnOnEventComeHook)
				(*pThreadContext->fnOnEventComeHook)(SME_EVENT_ORIGIN_INTERNAL, pEvent);
		}

		do { 
			DispatchEventToApps(pThreadContext, pEvent);

			/* Free internal event. Free external event later. */
			if (pEvent != pExtEvent)
				SmeDeleteEvent(pEvent);

			/* Get an event from event queue if available. */
			pEvent = GetEventFromQueue();
			if (pEvent != NULL)
			{
				/* Call hook function on an internal event coming. */
				if (pThreadContext->fnOnEventComeHook)
					(*pThreadContext->fnOnEventComeHook)(SME_EVENT_ORIGIN_INTERNAL, pEvent);
			}
			else 
			{
				/* The internal event queque is empty. */
				break;
			}
		} while (TRUE); /* Get all events from the internal event pool. */

		/* Free external event if necessary. */
		if (pThreadContext->fnDelExtEvent && pExtEvent)
		{
			(*pThreadContext->fnDelExtEvent)(pExtEvent);
			// Engine should delete this event, because translation of external event will create an internal event. 
			SmeDeleteEvent(pExtEvent); 
		}

	} /* Wait for an external event. */
}

/*******************************************************************************************
* DESCRIPTION:   
* INPUT:  
* OUTPUT: None.
* NOTE: SmeRun() and SmeActivateApp()/SmeDeactivateApp() calls this function.  
********************************************************************************************/
BOOL DispatchInternalEvents(SME_THREAD_CONTEXT_PT pThreadContext)
{
	struct SME_EVENT_T *pEvent=NULL;
	struct SME_APP_T *pApp;
	
	if (!pThreadContext) return FALSE;

	pApp = pThreadContext->pActAppHdr;

	pEvent = GetEventFromQueue();
	while (pEvent != NULL)
	{
		pEvent->nOrigin = SME_EVENT_ORIGIN_INTERNAL;
		/* Call hook function on an internal event coming. */
		if (pThreadContext->fnOnEventComeHook)
			(*pThreadContext->fnOnEventComeHook)(SME_EVENT_ORIGIN_INTERNAL, pEvent);
		
		DispatchEventToApps(pThreadContext, pEvent);

		/* Free internal event*/
		SmeDeleteEvent(pEvent);
		/* Next internal event? */
		pEvent = GetEventFromQueue();
	}
	return TRUE;
}

/*******************************************************************************************
* DESCRIPTION:   
* INPUT:  
* OUTPUT: None.
* NOTE: SmeRun() and SmeActivateApp()/SmeDeactivateApp() calls this function.  
********************************************************************************************/
BOOL DispatchEventToApps(SME_THREAD_CONTEXT_PT pThreadContext,SME_EVENT_T *pEvent)
{
	struct SME_APP_T *pApp;
	if (pThreadContext==NULL || pEvent==NULL) return FALSE;

	/*Dispatch it to active applications*/
	if (pEvent->pDestApp)
	{
		/* This event has destination application. Dispatch it if the application is active.*/
		if (pEvent->pDestApp->nAppState != SME_INVALID_STATE)
			/* Dispatch it to an destination application. */
			SmeDispatchEvent(pEvent, pEvent->pDestApp);
	}
	else if (pEvent->nCategory == SME_EVENT_CAT_UI)
		/* Dispatch UI event to the focused application. */
		SmeDispatchEvent(pEvent, pThreadContext->pFocusedApp);
	else 
	{
		/* Traverse all active applications. */
		pApp = pThreadContext->pActAppHdr;
		while (pApp != NULL) 
		{
			SmeDispatchEvent(pEvent, pApp);
			if (pEvent->bIsConsumed) 
				break;
			else pApp = pApp->pNext; 
		}
	}
	return TRUE;
}
/*******************************************************************************************
* DESCRIPTION:  This API function install a hook function. It will be called when event comes. 
* INPUT:  
* OUTPUT: None.
* NOTE: 
*   
*******************************************************************************************/
SME_ON_EVENT_COME_HOOK_T SmeSetOnEventComeHook(SME_ON_EVENT_COME_HOOK_T fnHook)
{
	SME_ON_EVENT_COME_HOOK_T fnOldHook;
	SME_THREAD_CONTEXT_PT pThreadContext=NULL;
	if (g_pfnGetThreadContext)
		pThreadContext = (*g_pfnGetThreadContext)();
	if (!pThreadContext) return NULL;

	fnOldHook = pThreadContext->fnOnEventComeHook;
	pThreadContext->fnOnEventComeHook = fnHook;
	return fnOldHook;
}

/*******************************************************************************************
* DESCRIPTION:  This API function install a hook function. It will be called when event is handled. 
* INPUT:  
* OUTPUT: None.
* NOTE: 
*   
*******************************************************************************************/
SME_ON_EVENT_HANDLE_HOOK_T SmeSetOnEventHandleHook(SME_ON_EVENT_HANDLE_HOOK_T fnHook)
{
	SME_ON_EVENT_HANDLE_HOOK_T fnOldHook;
	SME_THREAD_CONTEXT_PT pThreadContext=NULL;
	if (g_pfnGetThreadContext)
		pThreadContext = (*g_pfnGetThreadContext)();
	if (!pThreadContext) return NULL;

	fnOldHook = pThreadContext->fnOnEventHandleHook;
	pThreadContext->fnOnEventHandleHook = fnHook;
	return fnOldHook;
}
/*******************************************************************************************
* DESCRIPTION:  This API function set an event consumed. It will not dispatched to another application. 
* INPUT:  
* OUTPUT: None.
* NOTE: 
*   
*******************************************************************************************/
void SmeConsumeEvent(struct SME_EVENT_T *pEvent)
{
	if (!pEvent) return;
	pEvent->bIsConsumed = TRUE;
}

/*******************************************************************************************
* DESCRIPTION:  This API function sets memory allocation and free function pointers. 
* INPUT: fnMAllocProc: Memory allocation function pointer;
*	      fnMFreeProc: 	Memory free function pointer.	 
* OUTPUT: None.
* NOTE: 
*   
*******************************************************************************************/
void SmeSetMemOprProc(SME_MEM_ALLOC_PROC_T fnMAllocProc, SME_MEM_FREE_PROC_T fnMFreeProc)
{
	g_fnMAllocProc= fnMAllocProc;
	g_fnMFreeProc = fnMFreeProc;
}

/*******************************************************************************************
* DESCRIPTION:  State machine engine memory allocation function in release version. 
* INPUT: nSize: Memory size;
* OUTPUT: Allocated memory pointer.
* NOTE: It will just call user defined memory allocation function.
*   
*******************************************************************************************/
void* SmeMAllocRelease(unsigned int nSize)
{
	if (g_fnMAllocProc)
		return (*g_fnMAllocProc)(nSize);
	else return NULL;
}

/*******************************************************************************************
* DESCRIPTION:  State machine engine memory free function in release version. 
* INPUT: pUserData: Memory block pointer;
* OUTPUT: The result depends on user defined memory free function.
* NOTE: It will just call user defined memory free function.
*   
*******************************************************************************************/
BOOL SmeMFreeRelease(void * pUserData)
{
	if (g_fnMFreeProc)
		return (*g_fnMFreeProc)(pUserData);
	else return FALSE;
}

/*******************************************************************************************
* DESCRIPTION:  This API function sets thread local storage function pointers. 
* INPUT: pSetThreadContextProc: Thread context setting function pointer;
*	      pGetThreadContext: 	Thread context getting function pointer.	 
* OUTPUT: None.
* NOTE: 
*   
*******************************************************************************************/
void SmeSetTlsProc(SME_SET_THREAD_CONTEXT_PROC pfnSetThreadContext, SME_GET_THREAD_CONTEXT_PROC pfnGetThreadContext)
{
	g_pfnSetThreadContext = pfnSetThreadContext;
	g_pfnGetThreadContext = pfnGetThreadContext;
}

/*******************************************************************************************
Sample:

void AppMain(SME_THREAD_CONTEXT_PT pAppThreadContext)
{
	SmeInitEngine(pAppThreadContext); // Initialize engine
	
	AttachPortToApp(&SME_GET_APP_VAR(PowerUpDown),SrvGetPortInfoPtr());
	AttachPortToApp(&SME_GET_APP_VAR(ImageList),SrvGetPortInfoPtr());
	AttachPortToApp(&SME_GET_APP_VAR(MenuCtrl),SrvGetPortInfoPtr());
	AttachPortToApp(&SME_GET_APP_VAR(DialogCtrl),SrvGetPortInfoPtr());
	AttachPortToApp(&SME_GET_APP_VAR(EditCtrl),SrvGetPortInfoPtr());

	SmeSetOnEventComeHook(OnEventComeHook);
	SME_SET_MEM_OPR_HOOK(OnMemOprHook);

	SmeActivateApp(&SME_GET_APP_VAR(PowerUpDown),NULL);

	// By default, all module trancers are turned on. Turn off MODULE_SRV_CALL_DISP tracer.
	SME_TURN_OFF_MODULE_TRACER(MODULE_SRV_CALL_DISP);

	SmeRun();
}

*/
