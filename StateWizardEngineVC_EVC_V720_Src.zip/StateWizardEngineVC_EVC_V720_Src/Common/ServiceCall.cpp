/**********************************************************************
UML StateWizard provides its software under the GPL License and zlib/libpng License for open source projects.

Email us at info@intelliwizard.com for any information, suggestions and feature requestions.

http://www.intelliwizard.com
*************************************************************************/





/* =============================================================================
 * Filename:    ServiceCall.cpp
 * 
 * Copyright  Intelliwizard Inc
 * All rights reserved.
 * -----------------------------------------------------------------------------
 * General description of this file:
 *
 * Service call agent.
 * -----------------------------------------------------------------------------
 *                               Revision History
 * -----------------------------------------------------------------------------
 * Version   Date      Author          Revision Detail
 * 1.0.0    2004/11/26                 Initial
 * ===========================================================================*/

/* =============================================================================
 *                               INCLUDE FILES
 * ===========================================================================*/
#include "stdafx.h"
#include "sme.h"
#include "SrvAgent.h"
#include "ServiceCall.h"

#ifdef _DEBUG
#define new DEBUG_NEW
#undef THIS_FILE
static char THIS_FILE[] = __FILE__;
#endif

/* =============================================================================
 *                            LOCAL     CONSTANTS
 * ===========================================================================*/
/* =============================================================================
 *                  LOCAL STRUCTURES AND OTHER TYPEDEFS
 * ===========================================================================*/

/*==============================================================================
 *                              LOCAL   MACROS
 * ===========================================================================*/
 
 /*==============================================================================
 *                              GLOBAL   Variables
 * ===========================================================================*/
extern HWND	g_hSimWndHdle;

/******************************************************************************************
* DESCRIPTION:  Make a service call by posting a message. 
* INPUT:
		long nSrvCallId: Call ID
		void * pCallData: Function parameter data;
		int nDataSize: Function parameter size.
* OUTPUT: None.
* NOTE: 
*   This function will allocate a memory block for parameter data. Simulator should free this 
*	memory block after receives a service call request.
********************************************************************************************/
BOOL AgtPostServiceCall(long nSrvCallId, void * pCallData, int nDataSize)
{
	if (g_hSimWndHdle==NULL) return FALSE;

	unsigned long nMsgSize = sizeof(SME_SRV_CALL_DATA_HDR_T) + nDataSize;

	SME_SRV_CALL_DATA_HDR_T *pHdr = (SME_SRV_CALL_DATA_HDR_T *)(new char[nMsgSize]);
	pHdr->nSrvCallId = nSrvCallId;
	pHdr->nDataLen = nDataSize;

	if (pCallData!=NULL && nDataSize>0)
	{
		void *pDataCopy = SME_HDR2CALLDATA(pHdr);
		memcpy(pDataCopy, pCallData, nDataSize);
	};

	return PostMessage(g_hSimWndHdle, 
		WM_SRV_CALL_ID, 
		(WPARAM)pHdr, 
		(LPARAM)nMsgSize);

}

/******************************************************************************************
* DESCRIPTION:  Make a service call by sending a message. 
* INPUT:
		long nSrvCallId: Call ID
		void * pCallData: Function parameter data;
		int nDataSize: Function parameter size.
* OUTPUT: None.
* NOTE: 
*   This function will NOT allocate a memory block for parameter data. Simulator should NOT free this 
*	memory block after receives a service calln request.
********************************************************************************************/
BOOL AgtSendServiceCall(long nSrvCallId, void * pCallData, int nDataSize)
{
	if (g_hSimWndHdle==NULL) return FALSE;

	unsigned long nMsgSize = sizeof(SME_SRV_CALL_DATA_HDR_T) + nDataSize;

	SME_SRV_CALL_DATA_HDR_T *pHdr = (SME_SRV_CALL_DATA_HDR_T *)(new char[nMsgSize]);
	pHdr->nSrvCallId = nSrvCallId;
	pHdr->nDataLen = nDataSize;

	if (pCallData!=NULL && nDataSize>0)
	{
		void *pDataCopy = SME_HDR2CALLDATA(pHdr);
		memcpy(pDataCopy, pCallData, nDataSize);
	};

	// The SendMessage function sends the specified message to a window or windows. The function calls 
	// the window procedure for the specified window and does not return until the window procedure 
	// has processed the message. 
	// The PostMessage function, in contrast, posts a message to a thread's message queue and returns immediately. 	
	SendMessage(g_hSimWndHdle, 
		WM_SRV_CALL_ID, 
		(WPARAM)pHdr, 
		(LPARAM)nMsgSize);
	
	return TRUE;
}

/******************************************************************************************
* DESCRIPTION:  When a service call ends, delete the service call header. 
* INPUT:
		pHdr: Service call data header
* OUTPUT: None.
* NOTE: 
********************************************************************************************/
BOOL AgtEndServiceCall(SME_SRV_CALL_DATA_HDR_T* pHdr)
{
	if (pHdr!=NULL)
	{
		delete pHdr;
		return TRUE;
	} else return FALSE;
}

