/**********************************************************************
UML StateWizard provides its software under the GPL License and zlib/libpng License for open source projects.

Email us at info@intelliwizard.com for any information, suggestions and feature requestions.

http://www.intelliwizard.com

*************************************************************************/

// EngineEVC.cpp : Defines the entry point for the DLL application.
/* =============================================================================
 * Filename:    EngineEVC.cpp
 * 
 * Copyright  Inc
 * All rights reserved.
 * -----------------------------------------------------------------------------
 * General description of this file:
 * -----------------------------------------------------------------------------
 *                               Revision History
 * -----------------------------------------------------------------------------
 * Version   Date      Author          Revision Detail
			2005/12/23                 Thread Local Storage
 * ===========================================================================*/

#include "stdafx.h"

BOOL EST_DestroyStateTrackWnd();
extern DWORD g_dwTlsIndex;

/*
BOOL APIENTRY DllMain( HANDLE hModule, 
                       DWORD  ul_reason_for_call, 
                       LPVOID lpReserved
					 )
{

    switch (ul_reason_for_call)
	{
	case DLL_PROCESS_ATTACH:
		g_dwTlsIndex = TlsAlloc();
		break;
	case DLL_THREAD_ATTACH:
		break;
	case DLL_THREAD_DETACH:
		EST_DestroyStateTrackWnd();
		break;
	case DLL_PROCESS_DETACH:
		EST_DestroyStateTrackWnd();
		if (0xFFFFFFFF != g_dwTlsIndex)
			TlsFree(g_dwTlsIndex);
		break;

	}
	return TRUE;
}
*/
class CMFCEVCDllApp : public CWinApp
{
public:
	CMFCEVCDllApp();
	virtual ~CMFCEVCDllApp();

// Overrides
	// ClassWizard generated virtual function overrides
	//{{AFX_VIRTUAL(CMFCEVCDllApp)
	//}}AFX_VIRTUAL

	//{{AFX_MSG(CMFCEVCDllApp)
		// NOTE - the ClassWizard will add and remove member functions here.
		//    DO NOT EDIT what you see in these blocks of generated code !
	//}}AFX_MSG
	DECLARE_MESSAGE_MAP()
};

//
//	Note!
//
//		If this DLL is dynamically linked against the MFC
//		DLLs, any functions exported from this DLL which
//		call into MFC must have the AFX_MANAGE_STATE macro
//		added at the very beginning of the function.
//
//		For example:
//
//		extern "C" BOOL PASCAL EXPORT ExportedFunction()
//		{
//			AFX_MANAGE_STATE(AfxGetStaticModuleState());
//			// normal function body here
//		}
//
//		It is very important that this macro appear in each
//		function, prior to any calls into MFC.  This means that
//		it must appear as the first statement within the 
//		function, even before any object variable declarations
//		as their constructors may generate calls into the MFC
//		DLL.
//
//		Please see MFC Technical Notes 33 and 58 for additional
//		details.
//

/////////////////////////////////////////////////////////////////////////////
// CMFCEVCDllApp

BEGIN_MESSAGE_MAP(CMFCEVCDllApp, CWinApp)
	//{{AFX_MSG_MAP(CMFCEVCDllApp)
		// NOTE - the ClassWizard will add and remove mapping macros here.
		//    DO NOT EDIT what you see in these blocks of generated code!
	//}}AFX_MSG_MAP
END_MESSAGE_MAP()

/////////////////////////////////////////////////////////////////////////////
// CMFCEVCDllApp construction

CMFCEVCDllApp::CMFCEVCDllApp()
{
	// TODO: add construction code here,
	// Place all significant initialization in InitInstance

	g_dwTlsIndex = TlsAlloc();

}

CMFCEVCDllApp::~CMFCEVCDllApp()
{
		EST_DestroyStateTrackWnd();
		if (0xFFFFFFFF != g_dwTlsIndex)
			TlsFree(g_dwTlsIndex);

}
/////////////////////////////////////////////////////////////////////////////
// The one and only CMFCEVCDllApp object

CMFCEVCDllApp theApp;
