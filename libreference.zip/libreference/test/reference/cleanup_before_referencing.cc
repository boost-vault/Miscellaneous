#include <string>

#include <reference/reference.h>

#include <boost/test/unit_test.hpp>

#include "cleanup_before_referencing.h"

namespace cleanup_before_referencing
{
	int not_referenced_count = 0;

	class not_referenced : public reference::referenced
	{
		public:
			reference::reference<not_referenced> next;

			not_referenced() :
				next(*this)
			{
				++not_referenced_count;
				return;
			}

			not_referenced(const not_referenced& rhs) :
				next(*this)
			{
				++not_referenced_count;
				return;
			}

			~not_referenced() throw ()
			{
				--not_referenced_count;
				return;
			}
	};

	void test()
	{
		BOOST_CHECK_EQUAL(not_referenced_count, 0);

		not_referenced* creation = new not_referenced();
		BOOST_CHECK_EQUAL(not_referenced_count, 1);

		boost::intrusive_ptr<not_referenced> ptr = new not_referenced();
		BOOST_CHECK_EQUAL(not_referenced_count, 2);

		ptr = 0;
		BOOST_CHECK_EQUAL(not_referenced_count, 1);

		if (not_referenced_count == 1) // test will cause segv if the not_referenced object mentioned by creation was cleaned too soon
		{
			ptr = creation;
			BOOST_CHECK_EQUAL(not_referenced_count, 1);

			creation = new not_referenced(); // oh, bad programming: variable reuse :P
			BOOST_CHECK_EQUAL(not_referenced_count, 2);

			creation->next = ptr;
			BOOST_CHECK_EQUAL(not_referenced_count, 2); // creation has never been referenced and thus should not be considered for deletion

			if (not_referenced_count == 2)
			{
				ptr = creation; // make creation referenced, so it will be cleaned up; only if it was still there
			}
		}
		return;
	}
}
