#ifndef TEST_REFERENCE_not_referenced_H
#define TEST_REFERENCE_not_referenced_H

namespace not_referenced
{
	void test();
}

#endif // TEST_REFERENCE_not_referenced_H
