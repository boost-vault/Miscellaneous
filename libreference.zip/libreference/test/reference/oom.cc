#include <memory>

#include <reference/reference.h>
#include <reference/manager/manager.h>

#include <boost/test/unit_test.hpp>

#include "oom.h"

namespace oom
{
	volatile int test_class_count = 0;

	class test_class : public reference::referenced
	{
		public:
			static const int MEM = 8192 * 1024; // 8Mb memory usage
			static const int DUMMY_DATA_SIZE = MEM / sizeof(char); // 8Mb

		private:
			char dummy_data[DUMMY_DATA_SIZE];
			reference::reference<test_class> self;

		public:
			test_class() :
				self(*this, this)
			{
				++test_class_count;
				for (int i = 0; i != sizeof(dummy_data); ++i)
				{
					dummy_data[i] = i % 128;
				}
				return;
			}

			test_class(const test_class& rhs) :
				self(*this, this)
			{
				++test_class_count;
				for (int i = 0; i != sizeof(dummy_data); ++i)
				{
					dummy_data[i] = rhs.dummy_data[i];
				}
				return;
			}

			~test_class() throw ()
			{
				--test_class_count;
				return;
			}
	};

	class large_data
	{
		private:
			char dummy_data[test_class::DUMMY_DATA_SIZE / 8];

		public:
			std::auto_ptr<large_data> next;

			large_data(std::auto_ptr<large_data>& rhs) :
				next(rhs)
			{
				return;
			}
	};

	void test()
	{
		const int TEST_CLASS_MEM = 64 * 1024 * 1024; // 64Mb for test class
		const int TEST_CLASS_COUNT = TEST_CLASS_MEM / test_class::MEM;

		reference::manager::batch b;
		// allocate and intrusively reference ~800kb data
		for (int i = 0; i < TEST_CLASS_COUNT; ++i)
		{
			boost::intrusive_ptr<test_class> ptr = new test_class();
		}
		BOOST_CHECK_EQUAL(test_class_count, TEST_CLASS_COUNT);

		// exhaust the available memory, using a linked list made with std::auto_ptr
		std::auto_ptr<large_data> ptr;
		while (test_class_count > 0)
		{
			ptr = std::auto_ptr<large_data>(new large_data(ptr));
		}
		BOOST_CHECK_EQUAL(test_class_count, 0);

		// be gentle on the stack while cleaning up:
		while (ptr.get())
		{
			ptr = ptr->next;
		}

		return;
	}
}
