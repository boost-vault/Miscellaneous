#ifndef TEST_REFERENCE_small_loop_H
#define TEST_REFERENCE_small_loop_H

namespace small_loop
{
	void test();
}

#endif // TEST_REFERENCE_small_loop_H
