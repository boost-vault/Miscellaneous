#include <boost/test/unit_test.hpp>

#include "parent_child_proper_cleanup.h"
#include "loop_cleanup.h"
#include "stepping.h"
#include "not_referenced.h"
#include "small_loop.h"
#include "cleanup_before_referencing.h"
#include "batcher.h"
#include "oom.h"

#include <reference/manager/manager.h>

using boost::unit_test::test_suite;

test_suite* init_unit_test_suite(int argc, char* argv[])
{
	reference::manager::set_policy(reference::manager::manager_policy_immediate);
	test_suite* test = BOOST_TEST_SUITE("intrusive ptr create and destroy test");
	test->add(BOOST_TEST_CASE(&parent_child_proper_cleanup::test));
	test->add(BOOST_TEST_CASE(&loop_cleanup::test));
	test->add(BOOST_TEST_CASE(&stepping::test));
	test->add(BOOST_TEST_CASE(&not_referenced::test));
	test->add(BOOST_TEST_CASE(&small_loop::test));
	test->add(BOOST_TEST_CASE(&cleanup_before_referencing::test));
	test->add(BOOST_TEST_CASE(&batcher::test));
	test->add(BOOST_TEST_CASE(&oom::test));
	return test;
}
