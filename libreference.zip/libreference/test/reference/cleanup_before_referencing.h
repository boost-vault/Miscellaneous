#ifndef TEST_REFERENCE_cleanup_before_referencing_H
#define TEST_REFERENCE_cleanup_before_referencing_H

namespace cleanup_before_referencing
{
	void test();
}

#endif // TEST_REFERENCE_cleanup_before_referencing_H
