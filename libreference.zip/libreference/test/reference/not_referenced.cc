#include <string>

#include <reference/reference.h>

#include <boost/test/unit_test.hpp>

#include "not_referenced.h"

namespace not_referenced
{
	int not_referenced_count = 0;

	class not_referenced : public reference::referenced
	{
		public:
			not_referenced()
			{
				++not_referenced_count;
				return;
			}

			not_referenced(const not_referenced& rhs)
			{
				++not_referenced_count;
				return;
			}

			~not_referenced() throw ()
			{
				--not_referenced_count;
				return;
			}
	};

	class test_class : public reference::referenced
	{
		public:
			reference::reference<not_referenced> next;

			test_class() :
				next(*this)
			{
				return;
			}

			test_class(std::string id, const test_class& rhs) :
				next(*this)
			{
				next = rhs.next;
				return;
			}

			~test_class() throw ()
			{
				return;
			}
	};

	void test()
	{
		{
			boost::intrusive_ptr<test_class> test0 = new test_class();
			{
				boost::intrusive_ptr<not_referenced> nr = new not_referenced();
				test0->next = nr;
				BOOST_CHECK_EQUAL(not_referenced_count, 1);
			}
			BOOST_CHECK_EQUAL(not_referenced_count, 1);
		}
		BOOST_CHECK_EQUAL(not_referenced_count, 0);
		return;
	}
}
