#include <reference/reference.h>

#include <boost/test/unit_test.hpp>

#include "loop_cleanup.h"

namespace loop_cleanup
{
	int test_class_count = 0;

	class test_class : public reference::referenced
	{
		public:
			const std::string id;
			reference::reference<test_class> next;

			test_class(std::string id) :
				id(id),
				next(*this)
			{
				++test_class_count;
				return;
			}

			test_class(std::string id, const test_class& rhs) :
				id(id),
				next(*this)
			{
				++test_class_count;
				next = rhs.next;
				return;
			}

			~test_class() throw ()
			{
				--test_class_count;
				return;
			}
	};

	int test()
	{
		boost::intrusive_ptr<test_class> test0 = new test_class("#00");
		{
			boost::intrusive_ptr<test_class> test1 = new test_class("#01");
			boost::intrusive_ptr<test_class> test2 = new test_class("#02");

			BOOST_CHECK_EQUAL(test0->id, "#00");
			BOOST_CHECK_EQUAL(test1->id, "#01");
			BOOST_CHECK_EQUAL(test2->id, "#02");

			test0->next = test1;
			test1->next = test2;
			test2->next = test0;
			BOOST_CHECK_EQUAL(test0->next->id, "#01");
			BOOST_CHECK_EQUAL(test1->next->id, "#02");
			BOOST_CHECK_EQUAL(test2->next->id, "#00");
		}
		BOOST_CHECK_EQUAL(test_class_count, 3);
		test0 = 0;
		BOOST_CHECK_EQUAL(test_class_count, 0);
		return 0;
	}
}
