#ifndef TEST_REFERENCE_oom_H
#define TEST_REFERENCE_oom_H

#include <reference/reference.h>

namespace oom
{
	void test();
}

#endif // TEST_REFERENCE_oom_H
