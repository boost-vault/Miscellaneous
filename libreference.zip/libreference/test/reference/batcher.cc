#include <memory>

#include <reference/reference.h>
#include <reference/manager/manager.h>

#include <boost/test/unit_test.hpp>

#include "batcher.h"

namespace batcher
{
	int test_class_count = 0;

	class test_class : public reference::referenced
	{
		private:
			reference::reference<test_class> self;

		public:
			test_class() :
				self(*this, this)
			{
				++test_class_count;
				return;
			}

			test_class(const test_class& rhs) :
				self(*this, this)
			{
				++test_class_count;
				return;
			}

			~test_class() throw ()
			{
				--test_class_count;
				return;
			}
	};

	void test()
	{
		const int TEST_CLASS_COUNT = 5;

		{
			reference::manager::batch b;
			for (int i = 0; i < TEST_CLASS_COUNT; ++i)
			{
				boost::intrusive_ptr<test_class> ptr = new test_class();
			}
			BOOST_CHECK_EQUAL(test_class_count, TEST_CLASS_COUNT);
		}
		BOOST_CHECK_EQUAL(test_class_count, 0);

		return;
	}
}
