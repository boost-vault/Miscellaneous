#ifndef TEST_REFERENCE_stepping_H
#define TEST_REFERENCE_stepping_H

#include <string>

#include <reference/reference.h>

namespace stepping
{
	void test();
}

#endif // TEST_REFERENCE_stepping_H
