#ifndef TEST_REFERENCE_batcher_H
#define TEST_REFERENCE_batcher_H

#include <reference/reference.h>

namespace batcher
{
	void test();
}

#endif // TEST_REFERENCE_batcher_H
