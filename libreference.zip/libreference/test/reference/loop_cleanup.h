#ifndef TEST_REFERENCE_loop_cleanup_H
#define TEST_REFERENCE_loop_cleanup_H

#include <reference/reference.h>

namespace loop_cleanup
{
	int test();
}

#endif // TEST_REFERENCE_loop_cleanup_H
