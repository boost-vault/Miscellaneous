#ifndef TEST_REFERENCE_parent_child_proper_cleanup_H
#define TEST_REFERENCE_parent_child_proper_cleanup_H

namespace parent_child_proper_cleanup
{
	void test();
}

#endif // TEST_REFERENCE_parent_child_proper_cleanup_H
