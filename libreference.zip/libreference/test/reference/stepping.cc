#include <string>

#include <reference/reference.h>

#include <boost/test/unit_test.hpp>

#include "stepping.h"

namespace stepping
{
	int test_class_count = 0;

	class test_class : public reference::referenced
	{
		public:
			const std::string id;
			reference::reference<test_class> next;

			test_class(std::string id) :
				id(id),
				next(*this)
			{
				++test_class_count;
				return;
			}

			test_class(std::string id, const test_class& rhs) :
				id(id),
				next(*this)
			{
				++test_class_count;
				next = rhs.next;
				return;
			}

			~test_class() throw ()
			{
				--test_class_count;
				return;
			}
	};

	void test()
	{
		boost::intrusive_ptr<test_class> test0 = new test_class("#00");
		{
			boost::intrusive_ptr<test_class> test1 = new test_class("#01");
			boost::intrusive_ptr<test_class> test2 = new test_class("#02");
	
			test0->next = test1;
			test1->next = test2;
		}
		BOOST_CHECK_EQUAL(test_class_count, 3);
		int should_be = 3;
		while (test0)
		{
			test0 = test0->next;
			--should_be;
			BOOST_CHECK_EQUAL(test_class_count, should_be);
		}
		return;
	}
}
