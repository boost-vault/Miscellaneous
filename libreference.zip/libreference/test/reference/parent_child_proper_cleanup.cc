#include "parent_child_proper_cleanup.h"

#include <reference/reference.h>

#include <boost/test/unit_test.hpp>

#include <iostream>

namespace parent_child_proper_cleanup
{
	int parent_class_count = 0;
	int child_class_count = 0;

	class child_class;

	class parent_class : public reference::referenced
	{
		public:
			reference::reference<child_class> child;

			parent_class() :
				child(*this)
			{
				++parent_class_count;
				std::cerr << "creating parent_class: " << this << "; parent_class_count = " << parent_class_count << std::endl;
				return;
			}

			parent_class(const parent_class& rhs) :
				child(*this)
			{
				child = rhs.child;
				++parent_class_count;
				std::cerr << "creating parent_class: " << this << "; parent_class_count = " << parent_class_count << std::endl;
				return;
			}

			~parent_class() throw ()
			{
				--parent_class_count;
				std::cerr << "destroying parent_class: " << this << "; parent_class_count = " << parent_class_count << std::endl;
				return;
			}
	};

	class child_class : public reference::referenced
	{
		public:
			reference::reference<parent_class> parent;

			child_class() :
				parent(*this)
			{
				++child_class_count;
				std::cerr << "creating child_class: " << this << "; child_class_count = " << child_class_count << std::endl;
				return;
			}

			child_class(boost::intrusive_ptr<parent_class> parent) :
				parent(*this, parent)
			{
				++child_class_count;
				std::cerr << "creating child_class: " << this << "; child_class_count = " << child_class_count << std::endl;
				return;
			}

			child_class(const child_class& rhs) :
				parent(*this, rhs.parent)
			{
				++child_class_count;
				std::cerr << "creating child_class: " << this << "; child_class_count = " << child_class_count << std::endl;
				return;
			}

			~child_class() throw ()
			{
				--child_class_count;
				std::cerr << "destroying child_class: " << this << "; child_class_count = " << child_class_count << std::endl;
				return;
			}
	};

	void test()
	{
		{
			boost::intrusive_ptr<parent_class> parent = new parent_class();
			BOOST_CHECK_EQUAL(parent_class_count, 1);
			boost::intrusive_ptr<child_class> child = new child_class(parent);
			BOOST_CHECK_EQUAL(child_class_count, 1);
			parent->child = child;
		}
		BOOST_CHECK_EQUAL(parent_class_count, 0);
		BOOST_CHECK_EQUAL(child_class_count, 0);
		return;
	}
}
