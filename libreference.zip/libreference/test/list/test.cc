#include <boost/test/unit_test.hpp>

#include "create_destroy.h"
#include "iterator.h"
#include "listcopy.h"
#include "stl_algo.h"

using boost::unit_test::test_suite;

test_suite* init_unit_test_suite(int argc, char* argv[])
{
	reference::manager::set_policy(reference::manager::manager_policy_immediate);
	test_suite* test = BOOST_TEST_SUITE("reference list test");
	test->add(BOOST_TEST_CASE(&create_destroy::test));
	test->add(BOOST_TEST_CASE(&iterator::test));
	test->add(BOOST_TEST_CASE(&listcopy::test));
	test->add(BOOST_TEST_CASE(&stl_algo::copy_test));
	return test;
}
