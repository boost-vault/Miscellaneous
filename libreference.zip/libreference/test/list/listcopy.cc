#include <boost/test/unit_test.hpp>

#include <reference/reference.h>
#include <reference/list.h>

#include "filled_list.h"
#include "listcopy.h"

namespace listcopy
{
	void test()
	{
		BOOST_CHECK_EQUAL(list_elem_count, 0); // fails if previous tests left dangling list_elem classes.

		boost::intrusive_ptr<filled_list> lhs = new filled_list();
		boost::intrusive_ptr<filled_list> rhs;
		BOOST_CHECK_EQUAL(list_elem_count, 1 * filled_list::INIT_SIZE);

		rhs = new filled_list(*lhs);
		BOOST_CHECK_EQUAL(list_elem_count, 1 * filled_list::INIT_SIZE); // same number as before: no classes were copied

		lhs = 0;
		BOOST_CHECK_EQUAL(list_elem_count, 1 * filled_list::INIT_SIZE); // same number as before: classes are still reachable from rhs

		rhs = 0;
		BOOST_CHECK_EQUAL(list_elem_count, 0); // no longer referenced

		return;
	}
}
