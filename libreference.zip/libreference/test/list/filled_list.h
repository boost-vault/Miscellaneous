#ifndef TEST_REFERENCE_filled_list_H
#define TEST_REFERENCE_filled_list_H

#include <memory>

#include <reference/reference.h>
#include <reference/list.h>

#include <iostream>

extern int list_elem_count;

class list_elem : public reference::referenced
{
	public:
		const int index;

		list_elem();

		list_elem(const int index);

		list_elem(const list_elem& rhs);

		~list_elem() throw ();
};

class filled_list : public reference::referenced
{
	public:
		static const int INIT_SIZE;

		reference::list<list_elem> l;

		filled_list();

		filled_list(const filled_list& rhs);

		~filled_list() throw ();
};

#endif // TEST_REFERENCE_filled_list_H
