#ifndef TEST_REFERENCE_listcopy_H
#define TEST_REFERENCE_listcopy_H

namespace listcopy
{
	void test();
}

#endif // TEST_REFERENCE_listcopy_H
