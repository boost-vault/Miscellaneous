#include <cassert>

#include <iterator>

#include <reference/reference.h>
#include <reference/list.h>

#include "filled_list.h"

int list_elem_count = 0;

list_elem::list_elem() :
	index(-1)
{
	++list_elem_count;
	return;
}

list_elem::list_elem(const int index) :
	index(index)
{
	++list_elem_count;
	return;
}

list_elem::list_elem(const list_elem& rhs) :
	index(rhs.index)
{
	++list_elem_count;
	return;
}

list_elem::~list_elem() throw ()
{
	--list_elem_count;
	return;
}

const int filled_list::filled_list::INIT_SIZE = 10;

filled_list::filled_list() :
	l(*this)
{
	assert(l.empty());

	for (int i = 0; i != INIT_SIZE; ++i)
	{
		*(std::back_inserter(l)++) = new list_elem(i);
	}
	assert(l.size() == INIT_SIZE);
	return;
}

filled_list::filled_list(const filled_list& rhs) :
	l(*this, rhs.l)
{
	return;
}

filled_list::~filled_list() throw ()
{
	return;
}
