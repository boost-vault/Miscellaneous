#include <string>

#include <boost/test/unit_test.hpp>

#include <reference/reference.h>
#include <reference/list.h>

#include "filled_list.h"
#include "stl_algo.h"

namespace stl_algo
{
	void copy_test()
	{
		BOOST_CHECK_EQUAL(list_elem_count, 0); // fails if previous tests left dangling list_elem classes.

		boost::intrusive_ptr<filled_list> lhs = new filled_list();
		boost::intrusive_ptr<filled_list> rhs = new filled_list();
		BOOST_CHECK_EQUAL(list_elem_count, 2 * filled_list::INIT_SIZE);

		std::copy(lhs->l.begin(), lhs->l.end(), std::back_inserter(rhs->l));
		BOOST_CHECK_EQUAL(list_elem_count, 2 * filled_list::INIT_SIZE);

		lhs = 0;
		BOOST_CHECK_EQUAL(list_elem_count, 2 * filled_list::INIT_SIZE);

		return;
	}
}
