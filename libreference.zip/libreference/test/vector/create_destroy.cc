#include <string>

#include <boost/test/unit_test.hpp>

#include <reference/reference.h>
#include <reference/vector.h>

#include "create_destroy.h"

namespace create_destroy
{
	int test_class_count = 0;

	class test_class : public reference::referenced
	{
		public:
			reference::vector<test_class> l;
	
			test_class() :
				l(*this)
			{
				++test_class_count;
				return;
			}

			test_class(const test_class& rhs) :
				l(*this, rhs.l)
			{
				++test_class_count;
				return;
			}

			~test_class() throw ()
			{
				--test_class_count;
				return;
			}
	};

	void test()
	{
		const int MAX_INDEX = 10;

		boost::intrusive_ptr<test_class> test0 = new test_class();
		BOOST_CHECK_EQUAL(test_class_count, 1);
		for (int i = 0; i < MAX_INDEX; ++i)
		{
			test0->l.push_back(new test_class());
		}
		test0->l.push_back(test0);
		BOOST_CHECK_EQUAL(test_class_count, 1 + MAX_INDEX);
		test0 = 0;
		BOOST_CHECK_EQUAL(test_class_count, 0);
		return;
	}
}
