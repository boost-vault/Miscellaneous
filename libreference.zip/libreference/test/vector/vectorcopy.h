#ifndef TEST_REFERENCE_vectorcopy_H
#define TEST_REFERENCE_vectorcopy_H

namespace vectorcopy
{
	void test();
}

#endif // TEST_REFERENCE_vectorcopy_H
