#ifndef TEST_REFERENCE_iterator_H
#define TEST_REFERENCE_iterator_H

namespace iterator
{
	void test();
}

#endif // TEST_REFERENCE_iterator_H
