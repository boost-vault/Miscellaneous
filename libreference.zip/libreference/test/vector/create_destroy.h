#ifndef TEST_REFERENCE_create_destroy_H
#define TEST_REFERENCE_create_destroy_H

namespace create_destroy
{
	void test();
}

#endif // TEST_REFERENCE_create_destroy_H
