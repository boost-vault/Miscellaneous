#ifndef TEST_REFERENCE_stl_algo_H
#define TEST_REFERENCE_stl_algo_H

namespace stl_algo
{
	void copy_test();
}

#endif // TEST_REFERENCE_stl_algo_H
