#ifndef TEST_REFERENCE_filled_vector_H
#define TEST_REFERENCE_filled_vector_H

#include <reference/reference.h>
#include <reference/vector.h>

extern int vector_elem_count;

class vector_elem : public reference::referenced
{
	public:
		const int index;

		vector_elem();

		vector_elem(const int index);

		vector_elem(const vector_elem& rhs);

		~vector_elem() throw ();
};

extern template reference::vector<vector_elem>;

class filled_vector : public reference::referenced
{
	public:
		static const int INIT_SIZE;

		reference::vector<vector_elem> l;

		filled_vector();

		filled_vector(const filled_vector& rhs);

		~filled_vector() throw ();
};

#endif // TEST_REFERENCE_filled_vector_H
