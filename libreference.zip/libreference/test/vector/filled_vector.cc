#include <cassert>

#include <iterator>

#include <reference/reference.h>
#include <reference/vector.h>

#include "filled_vector.h"

int vector_elem_count = 0;

vector_elem::vector_elem() :
	index(-1)
{
	++vector_elem_count;
	return;
}

vector_elem::vector_elem(const int index) :
	index(index)
{
	++vector_elem_count;
	return;
}

vector_elem::vector_elem(const vector_elem& rhs) :
	index(rhs.index)
{
	++vector_elem_count;
	return;
}

vector_elem::~vector_elem() throw ()
{
	--vector_elem_count;
	return;
}

const int filled_vector::filled_vector::INIT_SIZE = 10;

filled_vector::filled_vector() :
	l(*this)
{
	assert(l.empty());

	for (int i = 0; i != INIT_SIZE; ++i)
	{
		boost::intrusive_ptr<vector_elem> ptr;
		*(std::back_inserter(l)++) = new vector_elem(i);
	}
	assert(l.size() == INIT_SIZE);
	return;
}

filled_vector::filled_vector(const filled_vector& rhs) :
	l(*this, rhs.l)
{
	return;
}

filled_vector::~filled_vector() throw ()
{
	return;
}

template reference::vector<vector_elem>;
