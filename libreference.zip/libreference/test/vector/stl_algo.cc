#include <string>

#include <boost/test/unit_test.hpp>

#include <reference/reference.h>
#include <reference/vector.h>

#include "filled_vector.h"
#include "stl_algo.h"

namespace stl_algo
{
	void copy_test()
	{
		BOOST_CHECK_EQUAL(vector_elem_count, 0); // fails if previous tests left dangling vector_elem classes.

		boost::intrusive_ptr<filled_vector> lhs = new filled_vector();
		boost::intrusive_ptr<filled_vector> rhs = new filled_vector();
		BOOST_CHECK_EQUAL(vector_elem_count, 2 * filled_vector::INIT_SIZE);

		std::copy(lhs->l.begin(), lhs->l.end(), std::back_inserter(rhs->l));
		BOOST_CHECK_EQUAL(vector_elem_count, 2 * filled_vector::INIT_SIZE);

		lhs = 0;
		BOOST_CHECK_EQUAL(vector_elem_count, 2 * filled_vector::INIT_SIZE);

		return;
	}
}
