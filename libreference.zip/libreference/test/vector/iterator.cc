#include <string>
#include <sstream>

#include <boost/test/unit_test.hpp>

#include <reference/reference.h>
#include <reference/vector.h>

#include "iterator.h"

namespace iterator
{
	template<class Arg>
	std::string to_string(Arg arg)
	{
		std::ostringstream oss;
		oss << arg;
		return oss.str();
	}

	class vector_item : public reference::referenced
	{
		public:
			std::string str;

			vector_item(const std::string str) :
				str(str)
			{
				return;
			}

			~vector_item() throw ()
			{
				return;
			}
	};

	class test_class : public reference::referenced
	{
		public:
			reference::vector<vector_item> l;
	
			test_class() :
				l(*this)
			{
				return;
			}

			test_class(const test_class& rhs) :
				l(*this, rhs.l)
			{
				return;
			}

			~test_class() throw ()
			{
				return;
			}
	};

	void test_iterator(reference::vector<vector_item>& l)
	{
		int i_counter = 0;
		for (reference::vector<vector_item>::iterator i = l.begin(); i != l.end(); ++i, ++i_counter)
		{
			const boost::intrusive_ptr<vector_item> item = *i;
			BOOST_CHECK_EQUAL(item->str, to_string(i_counter));
		}
		return;
	}

	void test_const_iterator(const reference::vector<vector_item>& l)
	{
		int i_counter = 0;
		for (reference::vector<vector_item>::const_iterator i = l.begin(); i != l.end(); ++i, ++i_counter)
		{
			const boost::intrusive_ptr<vector_item> item = *i;
			BOOST_CHECK_EQUAL(item->str, to_string(i_counter));
		}
		return;
	}

	void test_reverse_iterator(reference::vector<vector_item>& l)
	{
		int i_counter = l.size() - 1;
		for (reference::vector<vector_item>::reverse_iterator i = l.rbegin(); i != l.rend(); ++i, --i_counter)
		{
			const boost::intrusive_ptr<vector_item> item = *i;
			BOOST_CHECK_EQUAL(item->str, to_string(i_counter));
		}
		return;
	}

	void test_const_reverse_iterator(const reference::vector<vector_item>& l)
	{
		int i_counter = l.size() - 1;
		for (reference::vector<vector_item>::const_reverse_iterator i = l.rbegin(); i != l.rend(); ++i, --i_counter)
		{
			const boost::intrusive_ptr<vector_item> item = *i;
			BOOST_CHECK_EQUAL(item->str, to_string(i_counter));
		}
		return;
	}

	void test()
	{
		const int MAX_INDEX = 10;

		boost::intrusive_ptr<test_class> test0 = new test_class();
		for (int i = 0; i < MAX_INDEX; ++i)
		{
			test0->l.push_back(new vector_item(to_string(i)));
		}
		BOOST_CHECK_EQUAL(test0->l.size(), MAX_INDEX);

		test_iterator(test0->l);
		test_const_iterator(test0->l);
		test_reverse_iterator(test0->l);
		test_const_reverse_iterator(test0->l);

		return;
	}
}
