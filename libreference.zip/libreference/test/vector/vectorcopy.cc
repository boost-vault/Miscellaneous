#include <string>

#include <boost/test/unit_test.hpp>

#include <reference/reference.h>
#include <reference/vector.h>

#include "filled_vector.h"
#include "vectorcopy.h"

namespace vectorcopy
{
	void test()
	{
		BOOST_CHECK_EQUAL(vector_elem_count, 0); // fails if previous tests left dangling vector_elem classes.

		boost::intrusive_ptr<filled_vector> lhs = boost::intrusive_ptr<filled_vector>(new filled_vector());
		boost::intrusive_ptr<filled_vector> rhs;
		BOOST_CHECK_EQUAL(vector_elem_count, 1 * filled_vector::INIT_SIZE);

		rhs = boost::intrusive_ptr<filled_vector>(new filled_vector(*lhs));
		BOOST_CHECK_EQUAL(vector_elem_count, 1 * filled_vector::INIT_SIZE); // same number as before: no classes were copied

		lhs = 0;
		BOOST_CHECK_EQUAL(vector_elem_count, 1 * filled_vector::INIT_SIZE); // same number as before: classes are still reachable from rhs

		rhs = 0;
		BOOST_CHECK_EQUAL(vector_elem_count, 0); // no longer referenced

		return;
	}
}
