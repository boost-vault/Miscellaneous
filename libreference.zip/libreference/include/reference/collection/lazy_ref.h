/*
 * Copyright (c) 2007 A.P. van der Steldt
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */

#ifndef REFERENCE_PERSISTENCE_LAZY_REF__H
#define REFERENCE_PERSISTENCE_LAZY_REF__H

#include <cassert>

#include <reference/reference.h>

namespace reference
{
	namespace collection
	{
		/**
		 * Wrapper class which contains a reference, but delays initialization, thus not requiring a known parent at creation time.
		 * Cannot contain a reference until the parent is known.
		 *
		 * Supports resetting of parent.
		 */
		template<class Target>
		class lazy_ref
		{
			public:
				typedef reference<Target> reference_type;

			private:
				/**
				 * Union-ish, to make the reference not requiring additional new allocation and to support late initialization.
				 */
				char internal[(sizeof(reference_type) + sizeof(char) - 1) / sizeof(char)]; 

				reference_type* actual()
				{
					reference_type* const target_ptr = reinterpret_cast<reference_type*>(&internal[0]);
					assert(static_cast<void*>(target_ptr) == &internal);
					return target_ptr;
				}

				const reference_type* actual() const
				{
					const reference_type* const target_ptr = reinterpret_cast<const reference_type*>(&internal[0]);
					assert(static_cast<const void*>(target_ptr) == &internal);
					return target_ptr;
				}

				/**
				 * Monitors initialization state, true if actual has been constructed, false otherwise.
				 */
				bool initialized;

				// initializer and deinitializer
				void initialize(const referenced& parent)
				{
					deinitialize();

					assert(!initialized);
					new(actual()) reference_type(parent);
					initialized = true;
					return;
				}

				void deinitialize()
				{
					if (initialized)
					{
						actual()->~reference_type();
						initialized = false;
					}

					assert(!initialized);
					return;
				}

			public:
				lazy_ref() :
					initialized(false)
				{
					return;
				}

				lazy_ref(const referenced& parent) :
					initialized(false)
				{
					initialize(parent);
					return;
				}

				~lazy_ref() throw ()
				{
					deinitialize();
					return;
				}

				void set_parent(const referenced& parent)
				{
					boost::intrusive_ptr<typename reference_type::element_type> transfer_value;

					if (initialized)
					{
						if (actual()->get_parent() == &parent)
						{
							// Same parent, hence this would be a noop.
							return;
						}
						transfer_value = *actual();
						deinitialize();
					}

					assert(!initialized);
					initialize(parent);
					*actual() = transfer_value;
					return;
				}

				lazy_ref<Target>& operator=(typename reference_type::element_type* value)
				{
					assert(initialized); // if not initialized, programmer using this made an error.

					*actual() = value;
					return *this;
				}

				lazy_ref<Target>& operator=(const reference_type& value)
				{
					return *this = value.get();
				}

				lazy_ref<Target>& operator=(const boost::intrusive_ptr<typename reference_type::element_type>& value)
				{
					return *this = value.get();
				}

				bool operator==(const lazy_ref<Target>& rhs) const
				{
					if (!initialized || !rhs.initialized)
					{
						return false;
					}

					return *actual() == *rhs.actual();
				}

				typename reference_type::element_type* get() const
				{
					assert(initialized);

					return actual()->get();
				}

				reference_type& get_reference()
				{
					assert(initialized);

					return *actual();
				}

				const referenced& get_parent() const
				{
					assert(initialized);

					return *actual()->get_parent();
				}

				const reference_type& get_reference() const
				{
					assert(initialized);

					return *actual();
				}

				void reset()
				{
					assert(initialized);

					return actual->reset();
				}
		};
	}
}

#endif // REFERENCE_PERSISTENCE_LAZY_REF__H
