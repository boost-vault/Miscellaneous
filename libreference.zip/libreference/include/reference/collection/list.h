/*
 * Copyright (c) 2007 A.P. van der Steldt
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */

#ifndef REFERENCE_COLLECTION_LIST__H
#define REFERENCE_COLLECTION_LIST__H

#include <algorithm>
#include <list>
#include <iterator>
#include <memory>

#include <reference/reference.h>
#include <reference/manager/manager.h>
#include <reference/collection/element.h>
#include <reference/collection/predicate_wrapper.h>
#include <reference/collection/iterator.h>

namespace reference
{
	namespace collection
	{
		// Forward declaration, so the {front,back,insert}_iterator have a class to refer to.
		template<class Target, class Alloc>
		class list;
	}
}

namespace std
{
	template<class Target, class Alloc>
	class insert_iterator<reference::collection::list<Target, Alloc> > :
		public iterator<output_iterator_tag, void, void, void, void>
	{
		private:
			::reference::collection::list<Target, Alloc>* l;
			typename ::reference::collection::list<Target, Alloc>::iterator pos;

		public:
			class proxy
			{
				private:
					::reference::collection::list<Target, Alloc>& l;
					typename ::reference::collection::list<Target, Alloc>::iterator pos;

				public:
					proxy(::reference::collection::list<Target, Alloc>& l, typename ::reference::collection::list<Target, Alloc>::iterator pos) :
						l(l),
						pos(pos)
					{
						return;
					}

					proxy& operator=(Target* ptr)
					{
						l.insert(pos, ptr);
						return *this;
					}

					proxy& operator=(const ::reference::reference<Target>& ref)
					{
						return *this = ref.get();
					}

					proxy& operator=(const boost::intrusive_ptr<Target>& ref)
					{
						return *this = ref.get();
					}
			};

			insert_iterator(::reference::collection::list<Target, Alloc>& l, typename ::reference::collection::list<Target, Alloc>::iterator pos) :
				l(&l),
				pos(pos)
			{
				return;
			}

			insert_iterator< ::reference::collection::list<Target, Alloc> >& operator++()
			{
				return *this;
			}

			insert_iterator< ::reference::collection::list<Target, Alloc> >& operator++(int)
			{
				return *this;
			}

			proxy operator*()
			{
				return proxy(*l);
			}
	};

	template<class Target, class Alloc>
	class front_insert_iterator<reference::collection::list<Target, Alloc> > :
		public iterator<output_iterator_tag, void, void, void, void>
	{
		private:
			::reference::collection::list<Target, Alloc>* l;

		public:
			class proxy
			{
				private:
					::reference::collection::list<Target, Alloc>& l;

				public:
					proxy(::reference::collection::list<Target, Alloc>& l) :
						l(l)
					{
						return;
					}

					proxy& operator=(Target* ptr)
					{
						l.push_front(ptr);
						return *this;
					}

					proxy& operator=(const ::reference::reference<Target>& ref)
					{
						return *this = ref.get();
					}

					proxy& operator=(const boost::intrusive_ptr<Target>& ref)
					{
						return *this = ref.get();
					}
			};

			front_insert_iterator(::reference::collection::list<Target, Alloc>& l) :
				l(&l)
			{
				return;
			}

			front_insert_iterator< ::reference::collection::list<Target, Alloc> >& operator++()
			{
				return *this;
			}

			front_insert_iterator< ::reference::collection::list<Target, Alloc> >& operator++(int)
			{
				return *this;
			}

			proxy operator*()
			{
				return proxy(*l);
			}
	};

	template<class Target, class Alloc>
	class back_insert_iterator<reference::collection::list<Target, Alloc> > :
		public iterator<output_iterator_tag, void, void, void, void>
	{
		private:
			::reference::collection::list<Target, Alloc>* l;

		public:
			class proxy
			{
				private:
					::reference::collection::list<Target, Alloc>& l;

				public:
					proxy(::reference::collection::list<Target, Alloc>& l) :
						l(l)
					{
						return;
					}

					proxy& operator=(Target* ptr)
					{
						l.push_back(ptr);
						return *this;
					}

					proxy& operator=(const ::reference::reference<Target>& ref)
					{
						return *this = ref.get();
					}

					proxy& operator=(const boost::intrusive_ptr<Target>& ref)
					{
						return *this = ref.get();
					}
			};

			back_insert_iterator(::reference::collection::list<Target, Alloc>& l) :
				l(&l)
			{
				return;
			}

			back_insert_iterator< ::reference::collection::list<Target, Alloc> >& operator++()
			{
				return *this;
			}

			back_insert_iterator< ::reference::collection::list<Target, Alloc> >& operator++(int)
			{
				return *this;
			}

			proxy operator*()
			{
				return proxy(*l);
			}
	};
}

namespace reference
{
	namespace collection
	{
		template<class Target, class Alloc = std::allocator<Target> >
		class list
		{
			template<class List, class Predicate> friend class predicate_wrapper;
			template<class List, class Predicate> friend class binary_predicate_wrapper;
			template<class List, class Iterator> friend class iterator_wrapper_base;
			template<class List, class Iterator> friend class iterator_wrapper;
			template<class List, class Iterator> friend class const_iterator_wrapper;

			public:
				/** This list presents itself as a list containing references. */
				typedef reference<Target> element_type;
				typedef const element_type const_element_type;

			private:
				typedef std::list<element<typename element_type::element_type>, typename Alloc::rebind<element<typename element_type::element_type> >::other> internal_list_type;
				internal_list_type internal_list;

				/** Parent for all references in the list. */
				const referenced& parent;

			public:
				// --- list typedefs ---

				typedef element_type value_type;
				typedef element_type* pointer;
				typedef element_type& reference;
				typedef const element_type& const_reference;
				typedef typename internal_list_type::size_type size_type;
				typedef typename internal_list_type::difference_type difference_type;
				typedef typename internal_list_type::allocator_type allocator_type;

				// --- list iterator types ---

				typedef iterator_wrapper<list<Target, Alloc>, typename internal_list_type::iterator> iterator;
				typedef const_iterator_wrapper<list<Target, Alloc>, typename internal_list_type::const_iterator> const_iterator;
				typedef iterator_wrapper<list<Target, Alloc>, typename internal_list_type::reverse_iterator> reverse_iterator;
				typedef const_iterator_wrapper<list<Target, Alloc>, typename internal_list_type::const_reverse_iterator> const_reverse_iterator;

			protected:
				// --- element wrapping ---

				/** Wrap a pointer into an element object. */
				typename internal_list_type::value_type wrap(typename element_type::element_type* ptr) const
				{
					return typename internal_list_type::value_type(parent, ptr);
				}

				/** Wrap a pointer into an element object. */
				typename internal_list_type::value_type wrap(const boost::intrusive_ptr<typename element_type::element_type>& ptr) const
				{
					return wrap(ptr.get());
				}

				/** Wrap a pointer into an element object. */
				typename internal_list_type::value_type wrap(const ::reference::reference<typename element_type::element_type>& ptr) const
				{
					return wrap(ptr.get());
				}

				// --- element unwrapping ---

				element_type& unwrap(typename internal_list_type::value_type& internal_element) const
				{
					return internal_element.get_reference();
				}

				const element_type& unwrap(const typename internal_list_type::value_type& internal_element) const
				{
					return internal_element.get_reference();
				}

				// --- iterator wrapping ---

				/** Wrap an internal iterator into our iterator. */
				iterator wrap(const typename internal_list_type::iterator& internal_iter)
				{
					return iterator(*this, internal_iter);
				}

				/** Wrap an internal iterator into our iterator. */
				const_iterator wrap(const typename internal_list_type::const_iterator& internal_iter) const
				{
					return const_iterator(*this, internal_iter);
				}

				/** Wrap an internal iterator into our iterator. */
				reverse_iterator wrap(const typename internal_list_type::reverse_iterator& internal_iter)
				{
					return reverse_iterator(*this, internal_iter);
				}

				/** Wrap an internal iterator into our iterator. */
				const_reverse_iterator wrap(const typename internal_list_type::const_reverse_iterator& internal_iter) const
				{
					return const_reverse_iterator(*this, internal_iter);
				}

				// --- iterator unwrapping ---

				/** Unwrap our iterator into an internal iterator. */
				typename internal_list_type::iterator& unwrap(iterator& wrapped_iter) const
				{
					return wrapped_iter.unwrap();
				}

				/** Unwrap our iterator into an internal iterator. */
				typename internal_list_type::const_iterator& unwrap(const_iterator& wrapped_iter) const
				{
					return wrapped_iter.unwrap();
				}

				/** Unwrap our iterator into an internal iterator. */
				typename internal_list_type::reverse_iterator& unwrap(reverse_iterator& wrapped_iter) const
				{
					return wrapped_iter.unwrap();
				}

				/** Unwrap our iterator into an internal iterator. */
				typename internal_list_type::const_reverse_iterator& unwrap(const_reverse_iterator& wrapped_iter) const
				{
					return wrapped_iter.unwrap();
				}

				/** Unwrap our iterator into an internal iterator. */
				const typename internal_list_type::iterator& unwrap(const iterator& wrapped_iter) const
				{
					return wrapped_iter.unwrap();
				}

				/** Unwrap our iterator into an internal iterator. */
				const typename internal_list_type::const_iterator& unwrap(const const_iterator& wrapped_iter) const
				{
					return wrapped_iter.unwrap();
				}

				/** Unwrap our iterator into an internal iterator. */
				const typename internal_list_type::reverse_iterator& unwrap(const reverse_iterator& wrapped_iter) const
				{
					return wrapped_iter.unwrap();
				}

				/** Unwrap our iterator into an internal iterator. */
				const typename internal_list_type::const_reverse_iterator& unwrap(const const_reverse_iterator& wrapped_iter) const
				{
					return wrapped_iter.unwrap();
				}

			public:
				// --- constructors ---

				list(const referenced& parent) :
					parent(parent),
					internal_list()
				{
					return;
				}

				list(const referenced& parent, size_type n) :
					parent(parent),
					internal_list()
				{
					static const boost::intrusive_ptr<typename element_type::element_type> null_ptr;
					while (n > 0)
					{
						n--;
						push_back(null_ptr);
					}
					return;
				}

				template<class Iter>
				list(const referenced& parent, Iter iter_begin, Iter iter_end) :
					parent(parent),
					internal_list()
				{
					push_back(iter_begin, iter_end);
					return;
				}

				template<class SomeAlloc>
				list(const referenced& parent, const list<Target, SomeAlloc>& rhs) :
					parent(parent),
					internal_list()
				{
					push_back(rhs.begin(), rhs.end());
					return;
				}

				~list() throw ()
				{
					// perform a clear prior to destruction, but use a batch lock, to make the garbage collector only run once for all elements
					{
						manager::batch b;
						clear();
					}
					return;
				}

				// --- iterators ---

				iterator begin()
				{
					return wrap(internal_list.begin());
				}

				iterator end()
				{
					return wrap(internal_list.end());
				}

				const_iterator begin() const
				{
					return wrap(internal_list.begin());
				}

				const_iterator end() const
				{
					return wrap(internal_list.end());
				}

				reverse_iterator rbegin()
				{
					return wrap(internal_list.rbegin());
				}

				reverse_iterator rend()
				{
					return wrap(internal_list.rend());
				}

				const_reverse_iterator rbegin() const
				{
					return wrap(internal_list.rbegin());
				}

				const_reverse_iterator rend() const
				{
					return wrap(internal_list.rend());
				}

				// --- access to front and back ---

				element_type& front()
				{
					return unwrap(internal_list.front());
				}

				element_type& back()
				{
					return unwrap(internal_list.back());
				}

				const element_type& front() const
				{
					return unwrap(internal_list.front());
				}

				const element_type& back() const
				{
					return unwrap(internal_list.front());
				}

				// --- pop ---

				void pop_front()
				{
					internal_list.pop_front();
					return;
				}

				void pop_back()
				{
					internal_list.pop_back();
					return;
				}

				// --- insertion ---

				void push_front(element_type& elem)
				{
					internal_list.push_front(wrap(elem));
					return;
				}

				void push_front(typename element_type::element_type* elem)
				{
					internal_list.push_front(wrap(elem));
					return;
				}

				void push_front(boost::intrusive_ptr<typename element_type::element_type>& elem)
				{
					internal_list.push_front(wrap(elem));
					return;
				}

				void push_back(element_type& elem)
				{
					internal_list.push_back(wrap(elem));
					assert(back().get() == elem.get());
					return;
				}

				void push_back(typename element_type::element_type* elem)
				{
					internal_list.push_back(wrap(elem));
					assert(back().get() == elem);
					return;
				}

				void push_back(const boost::intrusive_ptr<typename element_type::element_type>& elem)
				{
					internal_list.push_back(wrap(elem));
					assert(back().get() == elem.get());
					return;
				}

				iterator insert(iterator pos, element_type& elem)
				{
					return wrap(internal_list.insert(unwrap(pos), wrap(elem)));
				}

				iterator insert(iterator pos, typename element_type::element_type* elem)
				{
					return wrap(internal_list.insert(unwrap(pos), wrap(elem)));
				}

				iterator insert(iterator pos, boost::intrusive_ptr<typename element_type::element_type>& elem)
				{
					return wrap(internal_list.insert(unwrap(pos), wrap(elem)));
				}

				void insert(iterator pos, size_type n, element_type& elem)
				{
					internal_list.insert(unwrap(pos), n, wrap(elem));
					return;
				}

				void insert(iterator pos, size_type n, typename element_type::element_type* elem)
				{
					internal_list.insert(unwrap(pos), n, wrap(elem));
					return;
				}

				void insert(iterator pos, size_type n, boost::intrusive_ptr<typename element_type::element_type>& elem)
				{
					internal_list.insert(unwrap(pos), n, wrap(elem));
					return;
				}

				template<class Iter>
				void push_back(Iter begin, Iter end)
				{
					while (begin != end)
					{
						internal_list.push_back(wrap(*begin++));
					}
					return;
				}

				template<class Iter>
				void push_front(Iter begin, Iter end)
				{
					while (begin != end)
					{
						internal_list.push_front(wrap(*begin++));
					}
					return;
				}

				template<class Iter>
				iterator insert(iterator pos, Iter begin, Iter end)
				{
					typename internal_list_type::iterator internal_pos = unwrap(pos);
					while (begin != end)
					{
						internal_pos = internal_list.insert(internal_pos, wrap(*begin++));
					}
					return wrap(internal_pos);
				}

				// --- misc functions ---

				bool empty() const
				{
					return internal_list.empty();
				}

				size_type size() const
				{
					return internal_list.size();
				}

				size_type max_size() const
				{
					return internal_list.max_size();
				}

				// --- erase ---

				iterator erase(const iterator& pos)
				{
					return wrap(internal_list.erase(unwrap(pos)));
				}

				iterator erase(const iterator& pos_begin, const iterator& pos_end)
				{
					manager::batch b; // make garbage collection run only once for all elements
					return wrap(internal_list.erase(unwrap(pos_begin), unwrap(pos_end)));
				}

				void clear()
				{
					manager::batch b; // make garbage collection run only once for all elements
					internal_list.clear();
					return;
				}

				void remove(const element_type& elem)
				{
					internal_list.remove(wrap(elem));
					return;
				}

				void remove(typename element_type::element_type* elem)
				{
					internal_list.remove(wrap(elem));
					return;
				}

				void remove(const boost::intrusive_ptr<typename element_type::element_type>& elem)
				{
					internal_list.remove(wrap(elem));
					return;
				}

				template<class Predicate>
				void remove_if(Predicate predicate)
				{
					internal_list.remove_if(mk_predicate_wrapper(*this, predicate));
					return;
				}

				// --- operators ---

				list<typename element_type::element_type>& operator=(const list<typename element_type::element_type>& rhs)
				{
					internal_list.clear();
					push_back(rhs.begin(), rhs.end());
					return *this;
				}

				void swap(list<typename element_type::element_type>& rhs)
				{
					manager::batch b; // make garbage collection run only once for all elements
					const list<typename element_type::element_type> rhs_copy = rhs;
					rhs = *this;
					*this = rhs_copy;
					return;
				}

				// --- collection management ---

				void unique()
				{
					manager::batch b; // make garbage collection run only once for all elements
					internal_list.unique();
					return;
				}

				template<class BinaryPredicate>
				void unique(BinaryPredicate binary_predicate)
				{
					manager::batch b; // make garbage collection run only once for all elements
					internal_list.unique(mk_binary_predicate_wrapper(*this, binary_predicate));
					return;
				}

				void sort()
				{
					internal_list.sort();
					return;
				}

				template<class BinaryPredicate>
				void sort(BinaryPredicate binary_predicate)
				{
					internal_list.sort(mk_binary_predicate_wrapper(*this, binary_predicate));
					return;
				}

				void merge(list<typename element_type::element_type>& rhs)
				{
					// TODO: make a (memory) efficient implementation
					list<typename element_type::element_type> rhs_copy(parent, rhs);
					internal_list.merge(rhs_copy.internal_list);
					rhs.clear();
					return;
				}

				template<class BinaryPredicate>
				void merge(list<typename element_type::element_type>& rhs, BinaryPredicate binary_predicate)
				{
					std::for_each(rhs.internal_list.begin(), rhs.internal_list.end(), std::bind2nd(std::mem_fun(&internal_list_type::element_type::set_parent), parent));
					internal_list.merge(rhs.internal_list);
					return;
				}

				void reverse()
				{
					internal_list.reverse();
					return;
				}

				// --- splice ---

				void splice(const iterator& position, list<typename element_type::element_type>& x, iterator i)
				{
					const typename internal_list_type::iterator unwrapped_i = unwrap(i);

					unwrapped_i->set_parent(parent);
					internal_list.splice(unwrap(position), x.internal_list, unwrapped_i);
					return;
				}

				void splice(const iterator& position, list<typename element_type::element_type>& x, iterator x_start, iterator x_end)
				{
					const typename internal_list_type::iterator unwrapped_x_start = unwrap(x_start);
					const typename internal_list_type::iterator unwrapped_x_end = unwrap(x_end);

					std::for_each(x_start, x_end, std::bind2nd(std::mem_fun(&internal_list_type::element_type::set_parent), parent));
					internal_list.splice(unwrap(position), x.internal_list, unwrapped_x_start, unwrapped_x_end);
					return;
				}

				void splice(const iterator& position, list<typename element_type::element_type>& x)
				{
					assert(&x != this);
					splice(position, x, x.begin(), x.end());
					return;
				}
		};
	}
}

template<class Target>
bool operator==(const reference::collection::list<Target>& lhs,
		reference::collection::list<Target>& rhs)
{
	if (&lhs == &rhs)
	{
		return true;
	}

	typename reference::collection::list<Target>::const_iterator lhs_begin = lhs.begin();
	typename reference::collection::list<Target>::const_iterator rhs_begin = rhs.begin();
	const typename reference::collection::list<Target>::const_iterator lhs_end = lhs.end();
	const typename reference::collection::list<Target>::const_iterator rhs_end = rhs.end();

	while ((lhs_begin != lhs_end) && (rhs_begin != rhs_end))
	{
		if (*lhs_begin++ != *rhs_begin++)
		{
			return false;
		}
	}
	return (lhs_begin != lhs_end) != (rhs_begin != rhs_end);
}

template<class Target>
bool operator<(const reference::collection::list<Target>& lhs,
		reference::collection::list<Target>& rhs)
{
	if (&lhs == &rhs)
	{
		return false;
	}

	typename reference::collection::list<Target>::const_iterator lhs_begin = lhs.begin();
	typename reference::collection::list<Target>::const_iterator rhs_begin = rhs.begin();
	const typename reference::collection::list<Target>::const_iterator lhs_end = lhs.end();
	const typename reference::collection::list<Target>::const_iterator rhs_end = rhs.end();

	while ((lhs_begin != lhs_end) && (rhs_begin != rhs_end))
	{
		if (*lhs_begin < *rhs_begin)
		{
			return true;
		}
		else if (*lhs_begin != rhs_begin)
		{
			return false;
		}

		lhs_begin++;
		rhs_begin++;
	}
	return (lhs_begin != lhs_end) > (rhs_begin != rhs_end); // true > false
}

#endif // REFERENCE_COLLECTION_LIST__H
