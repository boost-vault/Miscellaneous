/*
 * Copyright (c) 2007 A.P. van der Steldt
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */

#ifndef REFERENCE_COLLECTION_PREDICATE_WRAPPER__H
#define REFERENCE_COLLECTION_PREDICATE_WRAPPER__H

namespace reference
{
	namespace collection
	{
		template<class Collection, class Predicate>
		class predicate_wrapper
		{
			private:
				const Collection& collection;
				Predicate predicate;

			public:
				predicate_wrapper(const Collection& collection, Predicate predicate) :
					collection(collection),
					predicate(predicate)
				{
					return;
				}

				bool operator()(typename Collection::internal_list::const_reference arg) const
				{
					return predicate(unwrap(arg));
				}
		};

		template<class Collection, class Predicate>
		predicate_wrapper<Collection, Predicate> mk_predicate_wrapper(const Collection& collection, Predicate& predicate)
		{
			return predicate_wrapper<Collection, Predicate>(collection, predicate);
		}

		template<class Collection, class BinaryPredicate>
		class binary_predicate_wrapper
		{
			private:
				const Collection& collection;
				BinaryPredicate binary_predicate;

			public:
				binary_predicate_wrapper(const Collection& collection, BinaryPredicate binary_predicate) :
					collection(collection),
					binary_predicate(binary_predicate)
				{
					return;
				}

				bool operator()(typename Collection::internal_list::const_reference lhs, typename Collection::internal_list::const_reference rhs) const
				{
					return binary_predicate(unwrap(lhs), unwrap(rhs));
				}
		};

		template<class Collection, class BinaryPredicate>
		binary_predicate_wrapper<Collection, BinaryPredicate> mk_binary_predicate_wrapper(const Collection& collection, BinaryPredicate binary_predicate)
		{
			return binary_predicate_wrapper<Collection, BinaryPredicate>(collection, binary_predicate);
		}
	}
}

#endif // REFERENCE_COLLECTION_PREDICATE_WRAPPER__H
