/*
 * Copyright (c) 2007 A.P. van der Steldt
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */

#ifndef REFERENCE_COLLECTION_ITERATOR__H
#define REFERENCE_COLLECTION_ITERATOR__H

namespace reference
{
	namespace collection
	{
		template<class List, class Iterator>
		class iterator_wrapper_base
		{
			// template friend class iterator_wrapper_base;

			protected:
				List* list;
				Iterator internal;

			public:
				typedef typename Iterator::iterator_category iterator_category;
				typedef typename List::value_type value_type;
				typedef typename List::pointer pointer;
				typedef typename List::reference reference;
				typedef typename List::const_reference const_reference;
				typedef typename List::difference_type difference_type;

				iterator_wrapper_base() :
					list(),
					internal()
				{
					return;
				}

				iterator_wrapper_base(List& list, Iterator iterator) :
					list(&list),
					internal(iterator)
				{
					return;
				}

				iterator_wrapper_base(const iterator_wrapper_base<List, Iterator>& rhs) :
					list(rhs.list),
					internal(rhs.internal)
				{
					return;
				}

				template<class SomeIterator>
				difference_type operator-(const iterator_wrapper_base<List, SomeIterator>& rhs) const
				{
					return internal - rhs.internal;
				}

				template<class SomeIterator>
				bool operator==(const iterator_wrapper_base<List, SomeIterator>& rhs) const
				{
					return internal == rhs.internal;
				}

				template<class SomeIterator>
				bool operator!=(const iterator_wrapper_base<List, SomeIterator>& rhs) const
				{
					return internal != rhs.internal;
				}

				Iterator& unwrap()
				{
					return internal;
				}

				const Iterator& unwrap() const
				{
					return internal;
				}
		};

		template<class List, class Iterator>
		class iterator_wrapper : public iterator_wrapper_base<List, Iterator>
		{
			public:
				// copy over parent typedefs, to counter for gcc bug
				typedef typename iterator_wrapper_base<List, Iterator>::iterator_category iterator_category;
				typedef typename iterator_wrapper_base<List, Iterator>::value_type value_type;
				typedef typename iterator_wrapper_base<List, Iterator>::pointer pointer;
				typedef typename iterator_wrapper_base<List, Iterator>::reference reference;
				typedef typename iterator_wrapper_base<List, Iterator>::const_reference const_reference;
				typedef typename iterator_wrapper_base<List, Iterator>::difference_type difference_type;
				// end of copy over

				reference operator*() const
				{
					return list->unwrap(*internal);
				}

				value_type* operator->() const
				{
					return &list->unwrap(*internal);
				}

				iterator_wrapper() :
					iterator_wrapper_base<List, Iterator>()
				{
					return;
				}

				explicit iterator_wrapper(const iterator_wrapper<List, Iterator>& rhs) :
					iterator_wrapper_base<List, Iterator>(rhs)
				{
					return;
				}

				template<class SomeIterator>
				iterator_wrapper(const iterator_wrapper<List, SomeIterator>& rhs) :
					iterator_wrapper_base<List, Iterator>(rhs)
				{
					return;
				}

				iterator_wrapper(List& list, const Iterator& iter) :
					iterator_wrapper_base<List, Iterator>(list, iter)
				{
					return;
				}

				// --- increment/decrement ---

				iterator_wrapper<List, Iterator>& operator++()
				{
					++internal;
					return *this;
				}

				iterator_wrapper<List, Iterator>& operator--()
				{
					--internal;
					return *this;
				}

				iterator_wrapper<List, Iterator> operator++(int)
				{
					return iterator_wrapper<List, Iterator>(*list, internal++);
				}

				iterator_wrapper<List, Iterator> operator--(int)
				{
					return iterator_wrapper<List, Iterator>(*list, internal--);
				}
		};

		template<class List, class Iterator>
		class const_iterator_wrapper : public iterator_wrapper_base<const List, Iterator>
		{
			public:
				// copy over parent typedefs, to counter for gcc bug
				typedef typename iterator_wrapper_base<List, Iterator>::iterator_category iterator_category;
				typedef typename iterator_wrapper_base<List, Iterator>::value_type value_type;
				typedef typename iterator_wrapper_base<List, Iterator>::pointer pointer;
				typedef typename iterator_wrapper_base<List, Iterator>::reference reference;
				typedef typename iterator_wrapper_base<List, Iterator>::const_reference const_reference;
				typedef typename iterator_wrapper_base<List, Iterator>::difference_type difference_type;
				// end of copy over

				const_reference operator*() const
				{
					return list->unwrap(*internal);
				}

				const value_type* operator->() const
				{
					return &list->unwrap(*internal);
				}

				const_iterator_wrapper() :
					iterator_wrapper_base<const List, Iterator>()
				{
					return;
				}

				explicit const_iterator_wrapper(const iterator_wrapper<List, Iterator>& rhs) :
					iterator_wrapper_base<const List, Iterator>(rhs)
				{
					return;
				}

				template<class SomeIterator>
				const_iterator_wrapper(const iterator_wrapper<List, SomeIterator>& rhs) :
					iterator_wrapper_base<const List, Iterator>(rhs.list, rhs.internal)
				{
					return;
				}

				const_iterator_wrapper(const List& list, const Iterator& iter) :
					iterator_wrapper_base<const List, Iterator>(list, iter)
				{
					return;
				}

				// --- increment/decrement ---

				const_iterator_wrapper<List, Iterator>& operator++()
				{
					++internal;
					return *this;
				}

				const_iterator_wrapper<List, Iterator>& operator--()
				{
					--internal;
					return *this;
				}

				const_iterator_wrapper<List, Iterator> operator++(int)
				{
					return const_iterator_wrapper<List, Iterator>(*list, internal++);
				}

				const_iterator_wrapper<List, Iterator> operator--(int)
				{
					return const_iterator_wrapper<List, Iterator>(*list, internal--);
				}
		};
	}
}

#endif // REFERENCE_COLLECTION_ITERATOR__H
