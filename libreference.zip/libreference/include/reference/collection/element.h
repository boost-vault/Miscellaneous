/*
 * Copyright (c) 2007 A.P. van der Steldt
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */

#ifndef REFERENCE_COLLECTION_ELEMENT__H
#define REFERENCE_COLLECTION_ELEMENT__H

#include <reference/collection/lazy_ref.h>

namespace reference
{
	namespace collection
	{
		/**
		 * Holds the elements internal to the list.
		 */
		template<class Target>
		class element
		{
			public:
				typedef Target element_type;

			private:
				lazy_ref<element_type> ref;

			public:
				element()
				{
					return;
				}

				element(const referenced& parent) :
					ref(parent)
				{
					return;
				}

				element(const referenced& parent, element_type* target) :
					ref(parent)
				{
					ref = target;
					return;
				}

				element(const referenced& parent, const reference<element_type>& target) :
					ref(parent)
				{
					ref = target;
					return;
				}

				element(const referenced& parent, const boost::intrusive_ptr<element_type>& target) :
					ref(parent)
				{
					ref = target;
					return;
				}

				element(const element<element_type>& rhs) :
					ref(rhs.ref.get_parent())
				{
					*this = rhs;
					return;
				}

				void set_parent(const referenced& parent)
				{
					ref.set_parent(parent);
					return;
				}

				element_type* get() const
				{
					return ref.get();
				}

				reference<element_type>& get_reference()
				{
					return ref.get_reference();
				}

				const reference<element_type>& get_reference() const
				{
					return ref.get_reference();
				}

				element<element_type>& operator=(const element<element_type>& rhs)
				{
					ref.set_parent(rhs.ref.get_parent());
					ref = rhs.ref.get();

					return *this;
				}

				bool operator==(const element<element_type>& rhs) const
				{
					return get() == rhs.get();
				}

				bool operator<(const element<element_type>& rhs) const
				{
					return get() < rhs.get();
				}

				bool operator>(const element<element_type>& rhs) const
				{
					return get() > rhs.get();
				}

				bool operator<=(const element<element_type>& rhs) const
				{
					return get() <= rhs.get();
				}

				bool operator>=(const element<element_type>& rhs) const
				{
					return get() >= rhs.get();
				}

				bool operator!=(const element<element_type>& rhs) const
				{
					return get() != rhs.get();
				}

				void swap(element<element_type>& rhs)
				{
					get_reference().swap(rhs.get_reference());
					return;
				}
		};
	}
}

#endif // REFERENCE_COLLECTION_ELEMENT__H
