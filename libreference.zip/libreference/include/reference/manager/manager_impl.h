/*
 * Copyright (c) 2007 A.P. van der Steldt
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */

#ifndef REFERENCE_MANAGER_MANAGER_IMPL__H
#define REFERENCE_MANAGER_MANAGER_IMPL__H

#include <reference/manager/manager.h>
#include <reference/manager/black_white_grey.h>
#include <reference/manager/oom_handler.h>
#include <reference/manager/policy_intf.h>

#include <memory>

#include <boost/config.hpp> // for BOOST_HAS_THREADS define
#ifdef BOOST_HAS_THREADS
# include <boost/thread/mutex.hpp>
#endif // BOOST_HAS_THREADS

namespace reference
{
	namespace manager
	{
		/**
		 * This class maintains the manager data. The reason is that we want to break down the management in one go at the end of the application.
		 * If we use several static variables, we cannot guarantee in which order these will be destroyed and hence can get errors where functions
		 * try to operate on objects already destroyed.
		 *
		 * TODO: make all this wrapping stuff neater, perhaps actually design it instead of ad-hoc adding?
		 */
		template<class Parent>
		class manager_data : public Parent
		{
			public:
#ifdef BOOST_HAS_THREADS
				static const manager_policy default_policy = manager_policy_thread;
#else // BOOST_HAS_THREADS
				static const manager_policy default_policy = manager_policy_immediate;
#endif // BOOST_HAS_THREADS

				int max_skip_in_batch;
#ifdef BOOST_HAS_THREADS
				boost::mutex manager_mutex;
#endif // BOOST_HAS_THREADS
				int batch_counter;
				bool parallel_batches;
				int batch_skip_counter;

#ifdef BOOST_HAS_THREADS
				boost::mutex policy_mutex;
#endif // BOOST_HAS_THREADS
				std::auto_ptr<policy_intf> policy_impl;

				// --- constructors/destructors ---

				manager_data() :
					max_skip_in_batch(1000),
#ifdef BOOST_HAS_THREADS
					manager_mutex(),
#endif // BOOST_HAS_THREADS
					batch_counter(0),
					parallel_batches(false),
					batch_skip_counter(0),
#ifdef BOOST_HAS_THREADS
					policy_mutex(),
#endif // BOOST_HAS_THREADS
					policy_impl()
				{
					return;
				}

				~manager_data()
				{
#ifdef BOOST_HAS_THREADS
					boost::mutex::scoped_lock policy_lock(policy_mutex);
#endif // BOOST_HAS_THREADS
					policy_impl.reset();
					return;
				}
		};

		extern oom_handler<manager_data<black_white_grey<manager_allocator> > > impl;
	}
}

#endif // REFERENCE_MANAGER_MANAGER_IMPL__H
