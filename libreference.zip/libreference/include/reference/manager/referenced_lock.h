/*
 * Copyright (c) 2007 A.P. van der Steldt
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */

#ifndef REFERENCE_MANAGER_REFERENCED_LOCK_H
#define REFERENCE_MANAGER_REFERENCED_LOCK_H

namespace reference
{
	class referenced;

	namespace manager
	{
		/** Small class that prevents references from being deleted by anything else than the reference_mgr. */
		class referenced_lock
		{
			private:
				const referenced* ref;

				void detach();
				void attach(const referenced* ref_ptr);

			public:
				referenced_lock() :
					ref()
				{
					return;
				}

				referenced_lock(const referenced* ref) :
					ref()
				{
					attach(ref);
					return;
				}

				referenced_lock(const referenced_lock& rhs) :
					ref()
				{
					attach(rhs.ref);
					return;
				}

				~referenced_lock() throw ()
				{
					detach();
					return;
				}

				referenced_lock& operator=(const referenced_lock& rhs)
				{
					attach(rhs.ref);
					return *this;
				}

				referenced_lock& operator=(const referenced* ref)
				{
					attach(ref);
					return *this;
				}

				bool operator==(const referenced_lock& rhs) const
				{
					return ref == rhs.ref;
				}

				bool operator!=(const referenced_lock& rhs) const
				{
					return !(*this == rhs);
				}

				bool operator<(const referenced_lock& rhs) const
				{
					return ref < rhs.ref;
				}

				void reset()
				{
					detach();
					return;
				}
		};
	}
}

#endif // REFERENCE_MANAGER_REFERENCED_LOCK_H
