/*
 * Copyright (c) 2007 A.P. van der Steldt
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */

#ifndef REFERENCE_MANAGER_BLACK_WHITE_GREY_H
#define REFERENCE_MANAGER_BLACK_WHITE_GREY_H

#include <algorithm>
#include <cassert>
#include <functional>
#include <list>
#include <memory>
#include <iterator>

#include <boost/config.hpp> // For the BOOST_HAS_THREADS define.
#ifdef BOOST_HAS_THREADS
# include <boost/thread/mutex.hpp>
# include <boost/thread/thread.hpp>
#endif // BOOST_HAS_THREADS

#include <reference/reference.h>
#include <reference/manager/reference_lock.h>

namespace reference
{
	namespace manager
	{
		template<class Alloc>
		class black_white_grey
		{
			public:
				/** Registry of all references. */
				typedef std::list<reference_lock, typename Alloc::rebind<reference_lock>::other> reference_list;

			private:
				reference_list white_list; // white elements are not reachable or reachable via a grey element; white list is sorted while garbage collecting
				reference_list grey_list; // grey elements are directly reachable or reachable via a black element
				reference_list black_list; // like grey, but no elements in white are reachable via a black element

				bool busy;

#ifdef BOOST_HAS_THREADS
				typedef boost::mutex mutex;

				/** Mutex which controls the cleanup process. These locks are to be locked in this order, to avoid dead locks. */
				mutex busy_lock; // lock the busy flag
				mutex white_lock; // lock the white list
				mutex grey_lock; // lock the grey list
				mutex black_lock; // lock the black list
#endif // BOOST_HAS_THREADS

			public:
				void add_reference(reference_base& ref)
				{
#ifdef BOOST_HAS_THREADS
					mutex::scoped_lock busy_scoped_lock(busy_lock);
#endif // BOOST_HAS_THREADS

					if (busy)
					{
						// insert into grey, just using push_back
#ifdef BOOST_HAS_THREADS
						mutex::scoped_lock grey_scoped_lock(grey_lock);
#endif // BOOST_HAS_THREADS
						grey_list.push_back(reference_lock(&ref, true));
					}
					else
					{
						// insert into white, using ordering
#ifdef BOOST_HAS_THREADS
						mutex::scoped_lock white_scoped_lock(white_lock);
#endif // BOOST_HAS_THREADS
						white_list.push_back(reference_lock(&ref, false));
					}
					return;
				}

				void remove_reference(reference_base& ref)
				{
#ifndef NDEBUG
					{
# ifdef BOOST_HAS_THREADS
						mutex::scoped_lock busy_scoped_lock(busy_lock);
# endif // BOOST_HAS_THREADS
						assert(!busy); // should not be possible to be called while busy, since while busy, all objects are referenced by the gc.
					}
#endif // NDEBUG

#ifdef BOOST_HAS_THREADS
					// need all locks simultaniously, otherwise I could miss a move from grey to white, for instance
					mutex::scoped_lock white_scoped_lock(white_lock);
					mutex::scoped_lock grey_scoped_lock(grey_lock);
					mutex::scoped_lock black_scoped_lock(black_lock);
#endif // BOOST_HAS_THREADS

					const reference_lock reflock(&ref, false);
					white_list.remove(reflock);
					grey_list.remove(reflock);
					black_list.remove(reflock);
					return;
				}

			private:
				class parent_less_comp
				{
					public:
						bool operator()(const reference_lock& lhs, const reference_lock& rhs) const
						{
							return lhs.get_parent() < rhs.get_parent();
						}

						bool operator()(const reference_lock& lhs, const referenced* rhs) const
						{
							return lhs.get_parent() < rhs;
						}

						bool operator()(const referenced* lhs, const reference_lock& rhs) const
						{
							return lhs < rhs.get_parent();
						}
				};

			public:
				bool collect_garbage()
				{
					// preparation, requires busy_lock until black and grey are empty
					{
#ifdef BOOST_HAS_THREADS
						mutex::scoped_lock busy_scoped_lock(busy_lock);
#endif // BOOST_HAS_THREADS
						if (busy)
						{
							return false; // another thread or parent instance is running the garbage collector.
						}

						busy = true; // we are now the controlling garbage collecting thread.

#ifdef BOOST_HAS_THREADS
						mutex::scoped_lock white_scoped_lock(white_lock);
#endif // BOOST_HAS_THREADS
						{
							// move all grey elements to white.
#ifdef BOOST_HAS_THREADS
							mutex::scoped_lock grey_scoped_lock(grey_lock);
#endif // BOOST_HAS_THREADS
							white_list.splice(white_list.begin(), grey_list);
						}
						{
							// move all black elements to white.
#ifdef BOOST_HAS_THREADS
							mutex::scoped_lock black_scoped_lock(black_lock);
#endif // BOOST_HAS_THREADS
							white_list.splice(white_list.begin(), black_list);
						}

						// activate all reference_locks
						std::for_each(white_list.begin(), white_list.end(), std::mem_fun_ref(&reference_lock::activate));
					}

#ifdef BOOST_HAS_THREADS
					// no locks held, allow other threads to pop in between
					boost::thread::yield();
#endif // BOOST_HAS_THREADS

					// sorting of white, requires white lock only
					{
#ifdef BOOST_HAS_THREADS
						mutex::scoped_lock white_scoped_lock(white_lock);
#endif // BOOST_HAS_THREADS
						white_list.sort();
					}

#ifdef BOOST_HAS_THREADS
					// no locks held, allow other threads to pop in between
					boost::thread::yield();
#endif // BOOST_HAS_THREADS

					// moving directly reachable elements from white to grey, we want white to be sorted, for large chunks of splicing
					{
#ifdef BOOST_HAS_THREADS
						mutex::scoped_lock white_scoped_lock(white_lock);
#endif // BOOST_HAS_THREADS
						typename reference_list::iterator b = white_list.begin();
						while (b != white_list.end())
						{
							typename reference_list::iterator e = std::upper_bound(b, white_list.end(), *b, parent_less_comp());
							if (b->get_parent()->directly_reachable())
							{
								// [b..e) has a directly reachable parent
#ifdef BOOST_HAS_THREADS
								mutex::scoped_lock grey_scoped_lock(grey_lock);
#endif // BOOST_HAS_THREADS
								grey_list.splice(grey_list.end(), white_list, b, e);
							}

							b = e;
						}
					}

					// the next stage will fill this list with all white members which are unreachable
					reference_list white_dead_members;

					// for each element in grey, move it to black and move all children that are in white to grey
					while (true) // actually: while (!grey.empty())
					{
#ifdef BOOST_HAS_THREADS
						/* This is a lock intensive thread, which has been coded to release locks as soon as possible, but the most important locks to be
						 * released often are busy_lock and grey_lock, which are both required for the creation of new references.
						 * To make sure threads can still continue their important reference creation and deletion, we take a short break between each iteration,
						 * at the point where no locks are held (which is here). */
						boost::thread::yield();
#endif // BOOST_HAS_THREADS

#ifdef BOOST_HAS_THREADS
						mutex::scoped_lock busy_scoped_lock(busy_lock); // by re-aquiring the busy lock each iteration, we allow other threads to work their magic while cleaning
						mutex::scoped_lock white_scoped_lock(white_lock); // need white lock, and white needs to be locked before grey
						mutex::scoped_lock grey_scoped_lock(grey_lock);
#endif // BOOST_HAS_THREADS

						// actual guard, since our guard needs locks and we wish to keep interruptable locks for other threads
						if (grey_list.empty())
						{
#ifdef BOOST_HAS_THREADS
							grey_scoped_lock.unlock(); // grey lock no longer needed
#endif // BOOST_HAS_THREADS
							/* The grey list is empty, which means that all reachable elements are in black and all
							 * unreachable elements are in white.
							 * The black list can now be deactivated, since it's directly reachable anyway, while the
							 * white list will be resetted and cleared, to delete any unreachable referenced from memory.
							 */

							// move each white element to a local list, which will be cleaned at the end of this statement group
							white_dead_members.splice(white_dead_members.begin(), white_list);
							// dead members remain active, so the destructor of reference_lock will remove them
#ifdef BOOST_HAS_THREADS
							white_scoped_lock.unlock(); // finished with the white list
#endif // BOOST_HAS_THREADS

							// deactivation of black
#ifdef BOOST_HAS_THREADS
							mutex::scoped_lock black_scoped_lock(black_lock);
#endif // BOOST_HAS_THREADS
							std::for_each(black_list.begin(), black_list.end(), std::mem_fun_ref(&reference_lock::deactivate));
#ifdef BOOST_HAS_THREADS
							black_scoped_lock.unlock(); // no longer needed
#endif // BOOST_HAS_THREADS

							// deactivate magic
							busy = false;
#ifdef BOOST_HAS_THREADS
							busy_scoped_lock.unlock(); // busy lock no longer needed
#endif // BOOST_HAS_THREADS

							// end of this loop, white dead members will be subjected to a delete operation now
							break;
						}

#ifdef BOOST_HAS_THREADS
						busy_scoped_lock.unlock(); // busy lock no longer needed
#endif // BOOST_HAS_THREADS

						/** Grey element that is to be processed. */
						const typename reference_list::iterator item = grey_list.begin();

						// move all white elements that are directly referenced by item to the grey list
						const referenced*const grey_child = item->get_child();
						if (grey_child) // if no child, nothing in white can reference this
						{
							const std::pair<typename reference_list::iterator, typename reference_list::iterator> white_range =
								std::equal_range(white_list.begin(), white_list.end(), grey_child, parent_less_comp());
							grey_list.splice(grey_list.end(), white_list, white_range.first, white_range.second);
						}
#ifdef BOOST_HAS_THREADS
						white_scoped_lock.unlock(); // no more changes on white list for this iteration
#endif // BOOST_HAS_THREADS

						// move the grey item to the black list
#ifdef BOOST_HAS_THREADS
						mutex::scoped_lock black_scoped_lock(black_lock);
#endif // BOOST_HAS_THREADS
						black_list.splice(black_list.end(), grey_list, item);
					}

					// the garbage collector is now fully unlocked and clean, only thing that remains is resetting all dead references to kill loops
					std::for_each(white_dead_members.begin(), white_dead_members.end(), std::mem_fun_ref(&reference_lock::reset_reference));

					// cleanup done, return
					return !white_dead_members.empty();
				}

			private:
				typedef std::list<const referenced*> children_list;

				/** Helper function for activate_children. */
				static void activate_children_helper(const typename reference_list::value_type elem, std::back_insert_iterator<children_list> child_inserter)
				{
					const referenced* child = elem.get_child();
					if (child)
					{
#ifdef BOOST_HAS_THREADS
						referenced::mutex_type::scoped_lock lock(child->mutex);
#endif // BOOST_HAS_THREADS
						if (!child->has_been_intrusive_referenced)
						{
							child->has_been_intrusive_referenced = true;
							*child_inserter++ = child;
						}
					}
					return;
				}

				/**
				 * Activates (sets the has_been_intrusive_referenced flag) for a sorted list of referenced objects.
				 * The sort order is by std::less<const referenced*>.
				 * The iterators must be iterators over a collection of const referenced*.
				 * The white, grey and black list must have been locked.
				 * The busy flag does not have to be set or locked, since the children will not have their reachability altered.
				 */
				template<class Iter>
				void activate_children(const Iter& begin, const Iter& end)
				{
					const referenced* parent = 0;
					children_list children;

					const bool white_list_empty = white_list.empty();
					const bool grey_list_empty = grey_list.empty();
					const bool black_list_empty = black_list.empty();

					typename reference_list::iterator white_begin = white_list.begin();
					typename reference_list::iterator grey_begin = grey_list.begin();
					typename reference_list::iterator black_begin = black_list.begin();

					for (Iter iter = begin; iter != end; ++iter)
					{
						assert(*iter); // assert that we will not be asked to handle null
						assert(parent < *iter); // assert that the list is indeed sorted
						parent = *iter;

						if (!white_list_empty)
						{
							white_begin = std::lower_bound(white_begin, white_list.end(), parent, parent_less_comp());
							const typename reference_list::iterator white_end = std::upper_bound(white_begin, white_list.end(), parent, parent_less_comp());
							std::for_each(white_begin, white_end, std::bind2nd(std::ptr_fun(&activate_children_helper), std::back_inserter(children)));
							white_begin = white_end;
						}

						if (!grey_list_empty)
						{
							grey_begin = std::lower_bound(grey_begin, grey_list.end(), parent, parent_less_comp());
							const typename reference_list::iterator grey_end = std::upper_bound(grey_begin, grey_list.end(), parent, parent_less_comp());
							std::for_each(grey_begin, grey_end, std::bind2nd(std::ptr_fun(&activate_children_helper), std::back_inserter(children)));
							grey_begin = grey_end;
						}

						if (!black_list_empty)
						{
							black_begin = std::lower_bound(black_begin, black_list.end(), parent, parent_less_comp());
							const typename reference_list::iterator black_end = std::upper_bound(black_begin, black_list.end(), parent, parent_less_comp());
							std::for_each(black_begin, black_end, std::bind2nd(std::ptr_fun(&activate_children_helper), std::back_inserter(children)));
							black_begin = black_end;
						}
					}

					// cascade to children of activated objects
					if (!children.empty())
					{
						children.sort();
						activate_children(children.begin(), children.end());
					}
					return;
				}

			public:
				void activate_children(const referenced* parent)
				{
					assert(parent);
					children_list children;

#ifdef BOOST_HAS_THREADS
					/* all lists have to be locked, to prevent modifications while we cascade through the pointers.
					 * unlike the collector, we do not have the luxury of unlocking after sorting, since all our lists require to be and stay sorted,
					 * while the collector can guarantee that the white list will remain sorted, since during collection, elements are only inserted in grey. */
					mutex::scoped_lock white_scoped_lock(white_lock);
					mutex::scoped_lock grey_scoped_lock(grey_lock);
					mutex::scoped_lock black_scoped_lock(black_lock);
#endif // BOOST_HAS_THREADS

					// handle the white list
					if (!white_list.empty())
					{
						white_list.sort();
						const typename reference_list::iterator white_begin = std::lower_bound(white_list.begin(), white_list.end(), parent, parent_less_comp());
						const typename reference_list::iterator white_end = std::upper_bound(white_begin, white_list.end(), parent, parent_less_comp());
						std::for_each(white_begin, white_end, std::bind2nd(std::ptr_fun(&activate_children_helper), std::back_inserter(children)));
					}

					// handle the grey list
					if (!grey_list.empty())
					{
						grey_list.sort();
						const typename reference_list::iterator grey_begin = std::lower_bound(grey_list.begin(), grey_list.end(), parent, parent_less_comp());
						const typename reference_list::iterator grey_end = std::upper_bound(grey_begin, grey_list.end(), parent, parent_less_comp());
						std::for_each(grey_begin, grey_end, std::bind2nd(std::ptr_fun(&activate_children_helper), std::back_inserter(children)));
					}

					// handle the black list
					if (!black_list.empty())
					{
						black_list.sort();
						const typename reference_list::iterator black_begin = std::lower_bound(black_list.begin(), black_list.end(), parent, parent_less_comp());
						const typename reference_list::iterator black_end = std::upper_bound(black_begin, black_list.end(), parent, parent_less_comp());
						std::for_each(black_begin, black_end, std::bind2nd(std::ptr_fun(&activate_children_helper), std::back_inserter(children)));
					}

					// cascade to children of activated objects
					if (!children.empty())
					{
						children.sort();
						activate_children(children.begin(), children.end());
					}
					return;
				}
		};
	}
}

#endif // REFERENCE_MANAGER_BLACK_WHITE_GREY_H
