/*
 * Copyright (c) 2007 A.P. van der Steldt
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */

#ifndef REFERENCE_MANAGER_POLICY_IMPL__H
#define REFERENCE_MANAGER_POLICY_IMPL__H

#include <reference/manager/policy_intf.h>
#include <boost/config.hpp> // for BOOST_HAS_THREADS
#ifdef BOOST_HAS_THREADS
# include <boost/thread/condition.hpp>
# include <boost/thread/mutex.hpp>
# include <boost/thread/thread.hpp>
#endif // BOOST_HAS_THREADS

namespace reference
{
	namespace manager
	{
		class policy_immediate : public policy_intf
		{
			public:
				policy_immediate();
				~policy_immediate();

				bool operator()() const;
		};

		class policy_oom : public policy_intf
		{
			public:
				policy_oom();
				~policy_oom();

				bool operator()() const;
		};

#ifdef BOOST_HAS_THREADS
		class policy_thread : public policy_intf
		{
			private:
				mutable boost::condition worker_checking_notify;
				mutable boost::mutex worker_checking;
				volatile bool do_not_stop; // true while the worker is to continue doing its job
				std::auto_ptr<boost::thread> worker;

				static policy_thread* instance;

			public:
				policy_thread();
				~policy_thread();

				static void thread();

				bool operator()() const;
		};
#endif // BOOST_HAS_THREADS
	}
}

#endif // REFERENCE_MANAGER_POLICY_IMPL__H
