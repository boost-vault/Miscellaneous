/*
 * Copyright (c) 2007 A.P. van der Steldt
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */

#ifndef REFERENCE_MANAGER_REFERENCE_LOCK_H
#define REFERENCE_MANAGER_REFERENCE_LOCK_H

#include <reference/manager/referenced_lock.h>

namespace reference
{
	class reference_base;

	namespace manager
	{
		/**
		 * Reference lock, contains one reference.
		 * Reference locks are comparable and sortable.
		 *
		 * Reference locks can be activated and deactivated. Activated locks lock the parent against deletion, allowing the reference_mgr to perform a cleanup
		 * without halting the program.
		 */
		class reference_lock
		{
			private:
				reference_base* ref;
				referenced_lock parent_lock;

			public:
				void activate();
				void deactivate();

				const referenced* get_parent() const;
				const referenced* get_child() const;

			private:
				void attach(reference_base* ref_ptr);
				void detach();

			public:
				reference_lock() :
					ref(),
					parent_lock()
				{
					return;
				}

				reference_lock(reference_base* ref, bool active = false) :
					ref(),
					parent_lock()
				{
					attach(ref);
					if (active)
					{
						activate();
					}
					return;
				}

				reference_lock(const reference_lock& rhs) :
					ref(),
					parent_lock()
				{
					attach(rhs.ref);
					parent_lock = rhs.parent_lock;
					return;
				}

				~reference_lock()
				{
					detach();
					return;
				}

				reference_lock& operator=(const reference_lock& rhs)
				{
					attach(rhs.ref);
					parent_lock = rhs.parent_lock;
					return *this;
				}

				reference_lock& operator=(reference_base* ref)
				{
					attach(ref);
					return *this;
				}

				bool operator==(const reference_lock& rhs) const
				{
					return ref == rhs.ref;
				}

				bool operator!=(const reference_lock& rhs) const
				{
					return !(*this == rhs);
				}

				bool operator<(const reference_lock& rhs) const
				{
					if (!ref || !rhs.ref)
					{
						return ref < rhs.ref;
					}

					if (get_parent() == rhs.get_parent())
					{
						if (get_child() == rhs.get_child())
						{
							return ref < rhs.ref;
						}
						return get_child() < rhs.get_child();
					}
					return get_parent() < rhs.get_parent();
				}

				void reset()
				{
					detach();
					return;
				}

				/**
				 * This function detaches the child of this reference. Used if the reference_mgr decides something needs to be cleaned up.
				 * The reason for detaching the child prior to erasing the parent, is that the undetached children can create circular
				 * references which would not be cleaned up otherwise.
				 */
				void reset_reference() const;
		};
	}
}

#endif // REFERENCE_MANAGER_REFERENCE_LOCK_H
