/*
 * Copyright (c) 2007 A.P. van der Steldt
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */

#ifndef REFERENCE_MANAGER_MANAGER__H
#define REFERENCE_MANAGER_MANAGER__H

#include <reference/manager/policy.h>

#include <memory>

#include <boost/config.hpp> // for BOOST_HAS_THREADS
#ifdef BOOST_HAS_THREADS
# include <boost/thread/mutex.hpp>
#endif // BOOST_HAS_THREADS

namespace reference
{
	class reference_base;
	class referenced;

	namespace manager
	{
		class policy_intf;
		template<class Alloc> class black_white_grey;

		typedef std::allocator<void> manager_allocator;

		bool cleanup(bool force = false);
		void do_register(reference_base& ref);
		void do_deregister(reference_base& ref);
		void activate_children(const referenced* parent);
		void set_policy(manager_policy policy);
		manager_policy get_policy();

		class batch
		{
			private:
				static void start_batch() throw ();
				static void stop_batch() throw ();

				batch(const batch& rhs)
				{
					return;
				}

			public:
				batch()
				{
					start_batch();
					return;
				}

				~batch()
				{
					stop_batch();
					return;
				}
		};
	}
}

#endif // REFERENCE_MANAGER_MANAGER__H
