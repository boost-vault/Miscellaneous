/*
 * Copyright (c) 2007 A.P. van der Steldt
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */

#ifndef REFERENCE_MANAGER_OOM_HANDLER__H
#define REFERENCE_MANAGER_OOM_HANDLER__H

#include <new>

namespace reference
{
	namespace manager
	{
		extern std::new_handler parent_new_handler;

		void new_handler();

		template<class Parent>
		class oom_handler : public Parent
		{
			public:
				oom_handler() :
					Parent()
				{
					parent_new_handler = std::set_new_handler(&new_handler);
					return;
				}

				~oom_handler()
				{
					std::set_new_handler(0);
					return;
				}
		};
	}
}

#endif // REFERENCE_MANAGER_OOM_HANDLER__H
