/*
 * Copyright (c) 2007 A.P. van der Steldt
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */

#ifndef REFERENCE_REFERENCE_H
#define REFERENCE_REFERENCE_H

#include <new>
#include <memory>
#include <cassert>
#include <set>

#include <boost/intrusive_ptr.hpp>
#include <boost/config.hpp> // For the BOOST_HAS_THREADS define.
#ifdef BOOST_HAS_THREADS
# include <boost/thread/mutex.hpp>
#endif // BOOST_HAS_THREADS

namespace reference
{
	// Forward definition of reference base class.
	class reference_base;

	// Forward defintion of referenced class.
	class referenced;
}

namespace reference
{
	namespace manager
	{
		class referenced_lock;
		class reference_lock;
		template<class Alloc = std::allocator<void> > class black_white_grey;
	}
}

namespace boost
{
	void intrusive_ptr_add_ref(const reference::referenced*);
	void intrusive_ptr_release(const reference::referenced*);
}

namespace reference
{
	/**
	 * Everything that can be handled by the reference counted pointer needs to be of this type.
	 * This class performs the book keeping for the reference functionality in the referenced type.
	 */
	class referenced
	{
		private:
			/**
			 * Friend class reference_lock, which is used by the reference_mgr as an alternative to intrusive_ptrs, to bypass intrusive_ptr side effects.
			 */
			friend class manager::reference_lock;

#ifdef BOOST_HAS_THREADS
			/**
			 * Assure free store list single access.
			 */
			static boost::mutex in_free_store_list_mutex;
#endif // BOOST_HAS_THREADS

 			/**
 			 * Collection of all dynamic_cast<void*>(referenced&) that have been allocated
 			 * using operator new.
 			 */
 			static std::set<const void*> in_free_store_list;

 			/**
 			 * Allocator used to allocate memory for use by operator new.
 			 * We simply use the default allocator.
 			 */
 			typedef std::allocator<int> free_store_allocator_type;
 			static free_store_allocator_type free_store_allocator;

#ifdef BOOST_HAS_THREADS
			typedef boost::mutex mutex_type;
			mutable mutex_type mutex;
#endif // BOOST_HAS_THREADS

 			/**
 			 * True if this referenced was created in the free storage, using operator new.
 			 */
 			const bool in_free_store;

			/**
			 * Function used by the constructor to search for this_ptr in the in_free_store_list.
			 */
			static bool in_free_store_helper(const referenced* this_ptr) throw ();

 			/**
 			 * The number of intrusive pointers referencing this instance.
 			 */
 			mutable unsigned int intrusive_ptr_count;

 			/**
 			 * The number of references referencing this instance.
 			 */
 			mutable unsigned int reference_ptr_count;

 			/**
 			 * True if at least one intrusive pointer has ever referenced to this type.
 			 * This is used so the referenced class can be properly referenced even if
 			 * the instance has been allocated on the stack, as opposed to via a new
 			 * construction.
 			 */
 			mutable bool has_been_intrusive_referenced;

			/**
			 * True if the cleanup_handle function is already busy cleaning up this referenced object.
			 */
			mutable bool deleting;

 		protected:
 			/**
 			 * Default constructor, sets all values to reflect that there is no reference present
 			 * and that the object may have been allocated on the stack, rather than via a new
 			 * construction.
 			 */
 			referenced() throw ();

 			/**
 			 * Copy constructor. The reference counters are local, hence they are set to 0 rather than being copied over.
 			 * Performs the same function as the default constructor.
 			 */
 			referenced(const referenced& rhs) throw ();

 		public:
 			/**
 			 * Destruction routine.
 			 * Destructors need to be virtual.
 			 *
 			 * Throws a destruction_with_active_references if the destructor is called while still being referenced.
 			 */
 			virtual ~referenced() throw ();

 		private:
 			/**
 			 * Returns true if this is or has been pointed to by boost::intrusive_ptr.
 			 */
 			bool internal__directly_reachable() const throw ()
 			{
 				return !has_been_intrusive_referenced || (intrusive_ptr_count > 0) || !in_free_store;
 			}

 			/**
 			 * Returns true if this element should be deleted.
 			 * The condition is thus: there are no active references to this instance and
 			 * during the lifetime of this instance, there has been at least one moment
 			 * that a boost::intrusive_ptr has referenced this instance.
 			 *
 			 * If during the lifetime of this instance, no boost::intrusive_ptr has ever
 			 * referenced this instance, the instance assumes it was created on the stack
 			 * and thus cannot be deleted.
 			 */
 			bool should_call_delete() const throw ()
 			{
				if (deleting)
				{
					return false;
				}
 				return has_been_intrusive_referenced && (intrusive_ptr_count == 0) && (reference_ptr_count == 0) && in_free_store;
 			}

 			// --- boost intrusive pointer helper functions ---

 			/**
 			 * Increase the number of intrusive pointers pointing to this instance.
 			 */
 			void intrusive_add_ref() const throw ();

 			/**
 			 * Decrease the number of intrusive pointers pointing to this instance.
 			 * Returns true if a destructor should be called on this instance.
 			 */
 			bool intrusive_release() const throw ();

 			friend void boost::intrusive_ptr_add_ref(const referenced*);
 			friend void boost::intrusive_ptr_release(const referenced*);

 			void reference_mgr_add_ref() const throw ();
 			bool reference_mgr_release() const throw ();

			friend class manager::referenced_lock;
			template<class Alloc> friend class manager::black_white_grey;

 			// --- reference helper functions ---

 			/**
 			 * Increase the number of reference pointers pointing to this instance.
 			 */
 			void reference_add_ref(bool parent_has_been_intrusive_referenced) const throw ();

 			/**
 			 * Decrease the number of reference pointers pointing to this instance.
 			 * Returns true if a desctructor should be called on this instance.
 			 */
 			bool reference_release() const throw ();

 			friend class reference_base;

 			// --- release helper function ---

 			/**
 			 * Returns true if this element is directly reachable from the application.
 			 * This means that the object was created on the stack (!has_been_intrusive_referenced)
 			 * or that at least one intrusive_ptr points at this instance (intrusive_ptr_count > 0).
 			 */
 			bool directly_reachable() const throw ();

 			/**
 			 * Calls delete on the reference if nessecary.
 			 * r may not be a valid object after calling this function.
 			 */
 			static void cleanup_handle(const referenced& r);

 		public:
 			/**
 			 * Operator new.
 			 */
 			static void* operator new(size_t size);

 			/**
 			 * Operator delete.
 			 */
 			static void operator delete(void* ptr, size_t size);
 	};

 	class reference_base
 	{
 		private:
 			/**
 			 * Friend reference_mgr, which manages all references and needs access to protected functions in this instance.
 			 */
 			friend class manager::reference_lock;
 			template<class Alloc> friend class manager::black_white_grey;

#ifdef BOOST_HAS_THREADS
			typedef boost::mutex mutex_type;
			mutable mutex_type mutex;
#endif // BOOST_HAS_THREADS

			/**
			 * Parent, owner of this reference.
			 */
			const referenced& parent;
			referenced* child;

			void do_register();

			void do_deregister();

		public:
			/**
			 * Constructor, without child.
			 */
			reference_base(const referenced& owner) throw ();

		private:
			// the copy constructor is private, since it performs an illegal operation
			// (the setting of the parent to something that may not be its parent).
			reference_base(const reference_base& rhs) :
				parent(rhs.parent)
			{
				do_register();
				return;
			}

			/**
			 * Performs the actual detach operation, as specified by detach().
			 * Requires the mutex to be locked.
			 */
			const referenced* internal_detach();

		protected:
			/**
			 * Detaches the current child from this reference, decreasing the internal reference counters and
			 * performing the delete action as required.
			 */
			void detach();

			/**
			 * Attaches a child to this reference. Attaching will always trigger detaching first.
			 * Attaching a null is the same as detaching.
			 */
			void attach(referenced* new_ptr);

		public:
			void reset()
			{
				detach();
				return;
			}

			/**
			 * Destructor need not be virtual: it's called by the parent of the reference, which has exact knowledge of its type.
			 */
			~reference_base();

		public:
			/**
			 * Returns the parent of this reference. Used by the reference manager.
			 */
			const referenced* get_parent() const throw ()
			{
				return &parent;
			}

		protected:
			/**
			 * Returns the child of this reference. Needs to be a const reference*.
			 * May return null.
			 * Used by the reference manager.
			 */
			referenced* get_child() const throw ();

		public:
			referenced* get() const throw ()
			{
				return get_child();
			}

			operator bool() const
			{
				return get();
			}

			// --- weak ordering and comparison ---
			bool operator==(const reference_base& rhs) const
			{
				// Only compare child, since we pose as if we're a simple pointer.
				// Simple pointers know nothing of who owns them and it's irrelevant to most pointer users anyway.
				// And if it is relevant to them, they can use the get_parent() function.
				return get_child() == rhs.get_child();
			}

			bool operator<(const reference_base& rhs) const
			{
				return get_child() < rhs.get_child();
			}

			operator boost::intrusive_ptr<referenced>() const
			{
				return boost::intrusive_ptr<referenced>(get());
			}

			operator boost::intrusive_ptr<const referenced>() const
			{
				return boost::intrusive_ptr<const referenced>(get());
			}
	};

	template<class Target>
	class reference : public reference_base
	{
		public:
			typedef Target element_type;

			/**
			 * Constructor. The parent needs to be specified.
			 */
			reference(const referenced& parent) :
				reference_base(parent)
			{
				return;
			}

			/**
			 * Constructor. The parent needs to be specified.
			 * The child is allowed to be null.
			 */
			reference(const referenced& parent, Target* child) :
				reference_base(parent)
			{
				attach(child);
				return;
			}

			reference(const referenced& parent, const boost::intrusive_ptr<Target>& child) :
				reference_base(parent)
			{
				attach(child.get());
				return;
			}

			reference(const referenced& parent, const reference<Target>& child) :
				reference_base(parent)
			{
				attach(child.get());
				return;
			}

			~reference()
			{
				// no detach required: parent class (reference_base) performs this action for us.
				return;
			}

			/**
			 * Returns the child that this reference points to.
			 */
			Target* get() const throw ()
			{
				referenced* ptr = reference_base::get();
				// cast: the assignment functions make sure this will be a Target*.
				return dynamic_cast<Target*>(ptr);
			}

			/**
			 * Assignment operator.
			 */
			reference<Target>& operator=(Target* rhs)
			{
				attach(rhs);
				assert(get() == rhs);
				return *this;
			}

			/**
			 * Assignment operator.
			 */
			reference<Target>& operator=(const boost::intrusive_ptr<Target>& rhs)
			{
				attach(rhs.get());
				assert(get() == rhs.get());
				return *this;
			}

			/**
			 * Assignment operator.
			 */
			reference<Target>& operator=(const reference<Target>& rhs)
			{
				attach(rhs.get());
				assert(get() == rhs.get());
				return *this;
			}

			/**
			 * operator*
			 */
			Target& operator*() const throw ()
			{
				return *get();
			}

			/**
			 * operator&
			 */
			Target* operator->() const throw ()
			{
				return get();
			}

			/**
			 * Conversion function to boost::intrusive_ptr.
			 */
			operator boost::intrusive_ptr<Target>() const
			{
				return boost::intrusive_ptr<Target>(get());
			}

			/**
			 * Swap operation. (Swaps the child, but not the owner.)
			 */
			void swap(reference<Target>& rhs)
			{
				boost::intrusive_ptr<Target> lhs_ptr = *this;
				boost::intrusive_ptr<Target> rhs_ptr = rhs;

				*this = rhs_ptr;
				rhs = lhs_ptr;
				return;
			}
	};
}

// --- implementation boost::intrusive_ptr reference handling functions ---
namespace boost
{
	inline void intrusive_ptr_add_ref(const reference::referenced* r)
	{
		r->intrusive_add_ref();
		return;
	}

	inline void intrusive_ptr_release(const reference::referenced* r)
	{
		r->intrusive_release();
		reference::referenced::cleanup_handle(*r);
		return;
	}
}

#endif // REFERENCE_REFERENCE_H
