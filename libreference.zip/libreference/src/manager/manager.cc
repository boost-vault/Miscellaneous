/*
 * Copyright (c) 2007 A.P. van der Steldt
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */

#include <reference/manager/manager.h>

#include <reference/manager/manager_impl.h>
#include <reference/reference.h>
#include <reference/manager/policy.h>
#include <reference/manager/policy_intf.h>
#include <reference/manager/policy_impl.h>
#include <reference/manager/black_white_grey.h>

#include <cassert>
#include <memory>

#include <boost/config.hpp> // for BOOST_HAS_THREADS
#ifdef BOOST_HAS_THREADS
# include <boost/thread/mutex.hpp>
#endif // BOOST_HAS_THREADS

namespace reference
{
	namespace manager
	{
		inline bool batch_do_run()
		{
			if (impl.batch_counter == 0)
			{
				return true;
			}
			if (impl.parallel_batches && (impl.batch_skip_counter > impl.max_skip_in_batch) && (impl.max_skip_in_batch != 0))
			{
				return true;
			}
			return false;
		}

		std::auto_ptr<policy_intf> create_policy(manager_policy policy)
		{
			std::auto_ptr<policy_intf> created_policy;
			switch (policy)
			{
				case manager_policy_immediate:
					created_policy = std::auto_ptr<policy_intf>(new policy_immediate());
					break;
				case manager_policy_thread:
#ifdef BOOST_HAS_THREADS
					created_policy = std::auto_ptr<policy_intf>(new policy_thread());
#else
					created_policy = std::auto_ptr<policy_intf>(new policy_immediate());
#endif // BOOST_HAS_THREADS
					break;
				case manager_policy_oom:
					created_policy = std::auto_ptr<policy_intf>(new policy_oom());
					break;
			}

			assert(created_policy.get());
#ifdef BOOST_HAS_THREADS
			assert(created_policy->policy == policy);
#else
			assert(created_policy->policy == policy || (policy == manager_policy_thread && created_policy->policy == manager_policy_immediate));
#endif // BOOST_HAS_THREADS
			return created_policy;
		}

		bool policy_based_cleanup()
		{
#ifdef BOOST_HAS_THREADS
			boost::mutex::scoped_lock policy_lock(impl.policy_mutex);
#endif // BOOST_HAS_THREADS
			if (!impl.policy_impl.get())
			{
				impl.policy_impl = create_policy(impl.default_policy);
			}
			return (*impl.policy_impl)();
		}

		bool cleanup(bool force)
		{
			if (force)
			{
				return impl.collect_garbage();
			}
			else
			{
#ifdef BOOST_HAS_THREADS
				boost::mutex::scoped_lock manager_lock(impl.manager_mutex);
#endif // BOOST_HAS_THREADS
				if (!batch_do_run())
				{
					impl.batch_skip_counter++;
					return false;
				}
				impl.batch_skip_counter = 0;
#ifdef BOOST_HAS_THREADS
				manager_lock.unlock();
#endif // BOOST_HAS_THREADS
				return policy_based_cleanup();
			}
		}

		void do_register(reference_base& ref)
		{
			impl.add_reference(ref);
			return;
		}

		void do_deregister(reference_base& ref)
		{
			impl.remove_reference(ref);
			return;
		}

		void activate_children(const referenced* parent)
		{
			impl.activate_children(parent);
			return;
		}

		void set_policy(manager_policy policy)
		{
#ifdef BOOST_HAS_THREADS
			boost::mutex::scoped_lock policy_lock(impl.policy_mutex);
#endif // BOOST_HAS_THREADS
			if (impl.policy_impl.get() && (impl.policy_impl->policy == policy))
			{
				return;
			}
			impl.policy_impl = create_policy(policy);
			return;
		}

		manager_policy get_policy()
		{
			if (impl.policy_impl.get())
			{
				return impl.policy_impl->policy;
			}
			return impl.default_policy;
		}

		void batch::start_batch() throw ()
		{
#ifdef BOOST_HAS_THREADS
			boost::mutex::scoped_lock manager_lock(impl.manager_mutex);
#endif // BOOST_HAS_THREADS
			impl.batch_counter++;
			impl.parallel_batches |= impl.batch_counter >= 2; // TODO: detect nested batches
			return;
		}

		void batch::stop_batch() throw ()
		{
#ifdef BOOST_HAS_THREADS
			boost::mutex::scoped_lock manager_lock(impl.manager_mutex);
#endif // BOOST_HAS_THREADS
			impl.batch_counter--;
			assert(impl.batch_counter >= 0);
			if (!impl.batch_counter)
			{
				impl.parallel_batches = false;
				if (impl.batch_skip_counter > 0)
				{
#ifdef BOOST_HAS_THREADS
					manager_lock.unlock();
#endif // BOOST_HAS_THREADS
					cleanup();
				}
			}
			return;
		}
	}
}
