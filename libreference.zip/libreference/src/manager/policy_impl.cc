/*
 * Copyright (c) 2007 A.P. van der Steldt
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */

#include <reference/manager/policy_impl.h>

#include <reference/manager/manager.h>
#include <reference/manager/manager_impl.h>
#include <reference/manager/black_white_grey.h>

#include <boost/config.hpp> // for BOOST_HAS_THREADS define
#ifdef BOOST_HAS_THREADS
# include <boost/thread/condition.hpp>
# include <boost/thread/thread.hpp>
# include <boost/thread/mutex.hpp>
#endif // BOOST_HAS_THREADS

namespace reference
{
	namespace manager
	{
		policy_immediate::policy_immediate() :
			policy_intf(manager_policy_immediate)
		{
			return;
		}

		policy_immediate::~policy_immediate()
		{
			return;
		}

		bool policy_immediate::operator()() const
		{
			return impl.collect_garbage();
		}

		policy_oom::policy_oom() :
			policy_intf(manager_policy_oom)
		{
			return;
		}

		policy_oom::~policy_oom()
		{
			return;
		}

		bool policy_oom::operator()() const
		{
			return false;
		}

#ifdef BOOST_HAS_THREADS
		policy_thread* policy_thread::instance;

		policy_thread::policy_thread() :
			policy_intf(manager_policy_thread),
			worker_checking_notify(),
			worker_checking(),
			do_not_stop(true),
			worker()
		{
			assert(!instance);
			instance = this;
			worker = std::auto_ptr<boost::thread>(new boost::thread(&thread));
			return;
		}

		policy_thread::~policy_thread()
		{
			{
				boost::mutex::scoped_lock worker_checking_lock(worker_checking);
				do_not_stop = false;
			}
			worker_checking_notify.notify_all();
			worker->join();
			assert(instance == this);
			instance = 0;
			return;
		}

		void policy_thread::thread()
		{
			bool do_not_stop = true;
			while (do_not_stop)
			{
				{
					boost::mutex::scoped_lock worker_checking_lock(instance->worker_checking);
					do_not_stop = instance->do_not_stop;
					if (do_not_stop)
					{
						instance->worker_checking_notify.wait(worker_checking_lock);
					}
					do_not_stop = instance->do_not_stop;
				}
				if (do_not_stop)
				{
					impl.collect_garbage();
				}
			}
			return;
		}

		bool policy_thread::operator()() const
		{
			worker_checking_notify.notify_all();
			return false;
		}
#endif // BOOST_HAS_THREADS
	}
}
