/*
 * Copyright (c) 2007 A.P. van der Steldt
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy
 * of this software and associated documentation files (the "Software"), to deal
 * in the Software without restriction, including without limitation the rights
 * to use, copy, modify, merge, publish, distribute, sublicense, and/or sell
 * copies of the Software, and to permit persons to whom the Software is
 * furnished to do so, subject to the following conditions:
 *
 * The above copyright notice and this permission notice shall be included in
 * all copies or substantial portions of the Software.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR
 * IMPLIED, INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY,
 * FITNESS FOR A PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE
 * AUTHORS OR COPYRIGHT HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER
 * LIABILITY, WHETHER IN AN ACTION OF CONTRACT, TORT OR OTHERWISE, ARISING FROM,
 * OUT OF OR IN CONNECTION WITH THE SOFTWARE OR THE USE OR OTHER DEALINGS IN
 * THE SOFTWARE.
 */

#include <reference/reference.h>

#include <new>
#include <memory>

#include <boost/intrusive_ptr.hpp>
#include <boost/config.hpp> // For the BOOST_HAS_THREADS define.
#ifdef BOOST_HAS_THREADS
# include <boost/thread/mutex.hpp>
#endif // BOOST_HAS_THREADS

#include <reference/manager/manager.h>

// --- referenced ---

#ifdef BOOST_HAS_THREADS
boost::mutex reference::referenced::in_free_store_list_mutex;
#endif // BOOST_HAS_THREADS

std::set<const void*> reference::referenced::in_free_store_list;

reference::referenced::free_store_allocator_type reference::referenced::free_store_allocator;

/**
 * Returns a size_t R such, that R is the smallest value possible where
 * R * sizeof(Type) >= size
 * Used by the operator new and operator delete.
 */
template<class Type>
size_t round_size(size_t size)
{
	return (size + (sizeof(Type)) - 1) / (sizeof(Type));
}

bool reference::referenced::in_free_store_helper(const referenced* this_ptr) throw ()
{
	// We need a void*, since the new and delete operators only use void*.
	// Hence, the list of free storage allocated objects is represented in
	// void*.
	const void* voidptr = static_cast<const void*>(this_ptr);

#ifdef BOOST_HAS_THREADS
	boost::mutex::scoped_lock lock(in_free_store_list_mutex);
#endif // BOOST_HAS_THREADS

	const std::set<const void*>::iterator ifsl_location = in_free_store_list.find(voidptr);
	const bool present = (ifsl_location != in_free_store_list.end());
	if (present)
	{
		in_free_store_list.erase(ifsl_location);
	}
	return present;
}

void* reference::referenced::operator new(size_t size)
{
	void* ptr = free_store_allocator.allocate(round_size<free_store_allocator_type::value_type>(size));
	if (ptr)
	{
#ifdef BOOST_HAS_THREADS
		boost::mutex::scoped_lock lock(in_free_store_list_mutex);
#endif // BOOST_HAS_THREADS
		in_free_store_list.insert(ptr);
	}
	else
	{
		throw std::bad_alloc(); // Should have been done by the allocator.
	}
	return ptr;
}

void reference::referenced::operator delete(void* ptr, size_t size)
{
	if (ptr)
	{
		{
#ifdef BOOST_HAS_THREADS
			boost::mutex::scoped_lock lock(in_free_store_list_mutex);
#endif // BOOST_HAS_THREADS
			in_free_store_list.erase(ptr);
		}

		free_store_allocator.deallocate(reinterpret_cast<free_store_allocator_type::pointer>(ptr), round_size<free_store_allocator_type::value_type>(size));
	}
	return;
}

/**
 * Default constructor, sets all values to reflect that there is no reference present
 * and that the object may have been allocated on the stack, rather than via a new
 * construction.
 */
reference::referenced::referenced() throw () :
	in_free_store(in_free_store_helper(this)),
	intrusive_ptr_count(0),
	reference_ptr_count(0),
	has_been_intrusive_referenced(false),
	deleting(false)
{
	return;
}

/**
 * Copy constructor. The reference counters are local, hence they are set to 0 rather than being copied over.
 * Performs the same function as the default constructor.
 */
reference::referenced::referenced(const ::reference::referenced& rhs) throw () :
	in_free_store(in_free_store_helper(this)),
	intrusive_ptr_count(0),
	reference_ptr_count(0),
	has_been_intrusive_referenced(false),
	deleting(false)
{
	return;
}

/**
 * Destruction routine.
 * Destructors need to be virtual.
 *
 * Throws a destruction_with_active_references if the destructor is called while still being referenced.
 */
reference::referenced::~referenced() throw ()
{
	{
#ifdef BOOST_HAS_THREADS
		// assume refcount lock
		mutex_type::scoped_lock lock(mutex);
#endif // BOOST_HAS_THREADS
		assert(deleting || !in_free_store);
		assert(!(intrusive_ptr_count > 0 || reference_ptr_count > 0));
	}
	return;
}

// --- boost intrusive pointer helper functions ---

/**
 * Increase the number of intrusive pointers pointing to this instance.
 */
void reference::referenced::intrusive_add_ref() const throw ()
{
#ifdef BOOST_HAS_THREADS
	// assume refcount lock
	mutex_type::scoped_lock lock(mutex);
#endif // BOOST_HAS_THREADS
	++intrusive_ptr_count;
	assert(intrusive_ptr_count > 0);
	if (!has_been_intrusive_referenced)
	{
		has_been_intrusive_referenced = true;
#ifdef BOOST_HAS_THREADS
		lock.unlock();
#endif // BOOST_HAS_THREADS
		manager::activate_children(this);
	}
	return;
}

/**
 * Decrease the number of intrusive pointers pointing to this instance.
 * Returns true if a destructor should be called on this instance.
 */
bool reference::referenced::intrusive_release() const throw ()
{
#ifdef BOOST_HAS_THREADS
	// assume refcount lock
	mutex_type::scoped_lock lock(mutex);
#endif // BOOST_HAS_THREADS
	--intrusive_ptr_count;
	assert(intrusive_ptr_count >= 0);
	return should_call_delete();
}

// --- reference manager add_ref and release functions, uses the intrusive_ptr counters

/**
 * Increase the number of reference_mgr pointers pointing to this instance.
 * Reference_mgr pointers will not trigger the 'has_been_intrusive_refernced' state.
 */
void reference::referenced::reference_mgr_add_ref() const throw ()
{
#ifdef BOOST_HAS_THREADS
	// assume refcount lock
	mutex_type::scoped_lock lock(mutex);
#endif // BOOST_HAS_THREADS

	++reference_ptr_count;
	assert(reference_ptr_count > 0);
	return;
}

/**
 * Decrease the number of intrusive pointers pointing to this instance.
 * Returns true if a destructor should be called on this instance.
 */
bool reference::referenced::reference_mgr_release() const throw ()
{
#ifdef BOOST_HAS_THREADS
	// assume refcount lock
	mutex_type::scoped_lock lock(mutex);
#endif // BOOST_HAS_THREADS
	--reference_ptr_count;
	assert(reference_ptr_count >= 0);
	return should_call_delete();
}

// --- reference helper functions ---

/**
 * Increase the number of reference pointers pointing to this instance.
 */
void reference::referenced::reference_add_ref(bool parent_has_been_intrusive_referenced) const throw ()
{
#ifdef BOOST_HAS_THREADS
	// assume refcount lock
	mutex_type::scoped_lock lock(mutex);
#endif // BOOST_HAS_THREADS
	++reference_ptr_count;
	assert(reference_ptr_count > 0);
	if (parent_has_been_intrusive_referenced && !has_been_intrusive_referenced)
	{
		has_been_intrusive_referenced = true;
#ifdef BOOST_HAS_THREADS
		lock.unlock();
#endif // BOOST_HAS_THREADS
		manager::activate_children(this);
	}
	return;
}

/**
 * Decrease the number of reference pointers pointing to this instance.
 * Returns true if a desctructor should be called on this instance.
 */
bool reference::referenced::reference_release() const throw ()
{
#ifdef BOOST_HAS_THREADS
	// assume refcount lock
	mutex_type::scoped_lock lock(mutex);
#endif // BOOST_HAS_THREADS
	--reference_ptr_count;
	assert(reference_ptr_count >= 0);
	return should_call_delete();
}

// --- release helper function ---

/**
 * Returns true if this element is directly reachable from the application.
 * This means that the object was created on the stack (!has_been_intrusive_referenced)
 * or that at least one intrusive_ptr points at this instance (intrusive_ptr_count > 0).
 */
bool reference::referenced::directly_reachable() const throw ()
{
#ifdef BOOST_HAS_THREADS
	// assume refcount lock
	mutex_type::scoped_lock lock(mutex);
#endif // BOOST_HAS_THREADS

	return internal__directly_reachable();
}

/**
 * Calls delete on the reference if nessecary.
 * r may not be a valid object after calling this function.
 */
void reference::referenced::cleanup_handle(const ::reference::referenced& r)
{
	bool should_call_delete;
	bool directly_reachable;

	{
#ifdef BOOST_HAS_THREADS
		// assume refcount lock on r
		mutex_type::scoped_lock lock(r.mutex);
#endif // BOOST_HAS_THREADS

		should_call_delete = r.should_call_delete();
		directly_reachable = r.internal__directly_reachable();

		if (should_call_delete) // no references present any more
		{
			r.deleting = true;
#ifdef BOOST_HAS_THREADS
			lock.unlock();
#endif // BOOST_HAS_THREADS
			delete &r;
			return;
		}
	}

	if (!directly_reachable) // no cleanup nessecary if this is referenced
	{
		// refence_mgr::cleanup will reset all references originating from
		// unreferenced items. Those references will cleanup r if needed.
		manager::cleanup();
	}
	return;
}

// --- reference_base implementation ---

void reference::reference_base::do_register()
{
	manager::do_register(*this);
	return;
}

void reference::reference_base::do_deregister()
{
	manager::do_deregister(*this);
	return;
}

/**
 * Constructor, without child.
 */
reference::reference_base::reference_base(const ::reference::referenced& owner) throw () :
	parent(owner),
	child()
{
	do_register();
	return;
}

/**
 * Performs the actual detach operation, as specified by detach().
 * Requires the mutex to be locked.
 */
const reference::referenced* reference::reference_base::internal_detach()
{
	// store child pointer in old_ptr and clear child.
	const referenced* old_ptr;
	{
		old_ptr = child;
		// one of the advantages of setting child to 0 before deletion,
		// is that this reference won't be considered again, causing
		// endless recursion.
		child = 0;
	}
	return old_ptr;
}

/**
 * Detaches the current child from this reference, decreasing the internal reference counters and
 * performing the delete action as required.
 */
void reference::reference_base::detach()
{
	// Lock and perform internal detach. The detach function is split in an internal and external part,
	// where the internal part requires the modification lock to be present.
	// This is because the attach() functionality also needs to be able to detach.

	const referenced* old_ptr;

	{
#ifdef BOOST_HAS_THREADS
		// assume modification lock
		mutex_type::scoped_lock lock(mutex);
#endif // BOOST_HAS_THREADS
		old_ptr = internal_detach();
	}

	// if the child had a value, perform reference decrease functionality.
	// must be done outside the lock.
	if (old_ptr)
	{
		old_ptr->reference_release();
		referenced::cleanup_handle(*old_ptr);
	}

	return;
}

/**
 * Attaches a child to this reference. Attaching will always trigger detaching first.
 * Attaching a null is the same as detaching.
 */
void reference::reference_base::attach(::reference::referenced* new_ptr)
{
	const referenced* old_ptr;

	{
#ifdef BOOST_HAS_THREADS
		// assume modification lock
		mutex_type::scoped_lock lock(mutex);
#endif // BOOST_HAS_THREADS
		old_ptr = internal_detach();

		child = new_ptr;
		if (child)
		{
			child->reference_add_ref(parent.has_been_intrusive_referenced);
		}
	}

	// if the child had a value, perform reference decrease functionality.
	// must be done outside the lock.
	if (old_ptr)
	{
		old_ptr->reference_release();
		referenced::cleanup_handle(*old_ptr);
	}
	return;
}

/**
 * Destructor need not be virtual: it's called by the parent of the reference, which has exact knowledge of its type.
 */
reference::reference_base::~reference_base()
{
	// deregister first, otherwise the cleanup function would also decide to invoke our destructor.
	do_deregister();
	reset();
	return;
}

/**
 * Returns the child of this reference. Needs to be a const reference*.
 * May return null.
 * Used by the reference manager.
 */
reference::referenced* reference::reference_base::get_child() const throw ()
{
#ifdef BOOST_HAS_THREADS
	// assume modification lock
	mutex_type::scoped_lock lock(mutex);
#endif // BOOST_HAS_THREADS
	return child;
}
