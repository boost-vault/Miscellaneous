//  The templates and inlines for an oriantational dimension class.

//  Copyright (C) 2004-2009
//  Andreas Harnack (ah8 at freenet dot de)
//  version 0.0.4

//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.

//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.

//  You should have received a copy of the GNU General Public License along
//  with this program; if not, write to the Free Software Foundation, Inc.,
//  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.


#ifndef EUCLID_DIMENSION_HPP
#define EUCLID_DIMENSION_HPP

#include <iosfwd>
#include "euclid/traits.hpp"


namespace euclid
{
        // dimension class template
        template<typename T, unsigned int D> class dim
        {
                protected:
                        T v;

                public:
                        typedef T value_type;
                        enum { dimension = D };

                        // default constructor
                        dim() : v(T()) {}
                        // copy constructor
                        dim(dim<T,D> const& d0) : v(d0()) {}

                        // copy constructor with type conversion
                        template<typename U>
                                dim(dim<U,D> const& d0) : v(d0()) {}

                        // explicit initialization
                        explicit dim(T const& v0) : v(v0) {}

                        // base type access
                        const T& operator()() const { return v; }
                        T& operator()() { return v; }

                        // assignment
                        template<typename U>
                                dim<T,D>& operator=(dim<U,D> const& d0) {
                                        v = d0(); return *this; }
                        template<typename U>
                                dim<T,D>& operator+=(dim<U,D> const& d0) {
                                        v += d0(); return *this; }
                        template<typename U>
                                dim<T,D>& operator-=(dim<U,D> const& d0) {
                                        v -= d0(); return *this; }

                        template<typename U>
                                dim<T,D>& operator*=(U const& c) {
                                        v *= c; return *this; }
                        template<typename U>
                                dim<T,D>& operator/=(U const& c) {
                                        v /= c; return *this; }
                        template<typename U>
                                dim<T,D>& operator%=(U const& c) {
                                        v %= c; return *this; }

                        dim<T,D>& operator++() {
                                return *this += dim<T,D>(1); }
                        dim<T,D>& operator--() {
                                return *this -= dim<T,D>(1); }

                        dim<T,D> operator++(int) { dim<T,D> tmp(*this);
                                *this += dim<T,D>(1); return tmp; }
                        dim<T,D> operator--(int) { dim<T,D> tmp(*this);
                                *this -= dim<T,D>(1); return tmp; }

                        // stream output
                        std::ostream& print(std::ostream& os) const;
        };

#ifndef EUCLID_USE_TYPE_TRAITS


        // additive operators
        template<typename T, unsigned int D> inline
                dim<T,D> operator-(dim<T,D> const& x){
                        return dim<T,D>()-x; }

        template<typename T, unsigned int D, typename U> inline
                dim<T,D> operator+(dim<T,D> x, dim<U,D> const& y){
                        return x += y; }

        template<typename T, unsigned int D, typename U> inline
                dim<T,D> operator-(dim<T,D> x, dim<U,D> const& y){
                        return x -= y; }

        // scalar multiplication
        template<typename T, unsigned int D, typename U> inline
                dim<T,D> operator*(U const& x, dim<T,D> y) {
                        return y *= x; }

        template<typename T, unsigned int D, typename U> inline
                dim<T,D> operator*(dim<T,D> x, U const& y) {
                        return x *= y; }

        template<typename T, unsigned int D, typename U> inline
                dim<T,D> operator/(dim<T,D> x, U const& y) {
                        return x /= y; }

        template<typename T, unsigned int D, typename U> inline
                dim<T,D> operator%(dim<T,D> x, U const& y) {
                        return x %= y; }

        // scalar product
        template<typename T, unsigned int D, typename U> inline
                T operator*(dim<T,D> const& x, dim<U,D> const& y) {
                                return x() * y(); }

#else

        // additive operators
        template<typename T, unsigned int D> inline
                dim<typename unary<T>::minus::type, D>
                        operator-(dim<T,D> const& x) { return
                                dim<typename unary<T>::minus::type,D>() -= x; }

        template<typename T, unsigned int D, typename U> inline
                dim<typename binary<T,U>::add::type,D> operator+(
                        dim<T,D> const& x, dim<U,D> const& y) { return
                                dim<typename binary<T,U>::add::type,D>(x)+=y; }

        template<typename T, unsigned int D, typename U> inline
                dim<typename binary<T,U>::sub::type,D> operator-(
                        dim<T,D> const& x, dim<U,D> const& y) { return
                                dim<typename binary<T,U>::sub::type,D>(x)-=y; }

        // scalar multiplication
        template<typename T, unsigned int D, typename U> inline
                dim<typename binary<T,U>::mul::type,D> operator*(
                        U const& x, dim<T,D> const& y) { return
                                dim<typename binary<T,U>::mul::type,D>(y)*=x; }

        template<typename T, unsigned int D, typename U> inline
                dim<typename binary<T,U>::mul::type,D> operator*(
                        dim<T,D> const& x, U const& y) { return
                                dim<typename binary<T,U>::mul::type,D>(x)*=y; }

        template<typename T, unsigned int D, typename U> inline
                dim<typename binary<T,U>::div::type,D> operator/(
                        dim<T,D> const& x, U const& y) { return
                                dim<typename binary<T,U>::div::type,D>(x)/=y; }

        template<typename T, unsigned int D, typename U> inline
                dim<typename binary<T,U>::mod::type,D> operator%(
                        dim<T,D> const& x, U const& y) { return
                                dim<typename binary<T,U>::mod::type,D>(x)%=y; }

        // scalar product
        template<typename T, unsigned int D, typename U> inline
                typename binary<T,U>::mul::type operator*(
                        dim<T,D> const& x, dim<U,D> const& y) {
                                return x() * y(); }

#endif  // EUCLID_USE_TYPE_TRAITS


        // relational operators
        template<typename T, unsigned int D, typename U>
                bool operator==(dim<T,D> const& x, dim<U,D> const& y) {
                        return x() == y(); }
        template<typename T, unsigned int D, typename U>
                bool operator!=(dim<T,D> const& x, dim<U,D> const& y) {
                        return x() != y(); }
        template<typename T, unsigned int D, typename U>
                bool operator<(dim<T,D> const& x, dim<U,D> const& y) {
                        return x() < y(); }
        template<typename T, unsigned int D, typename U>
                bool operator>(dim<T,D> const& x, dim<U,D> const& y) {
                        return x() > y(); }
        template<typename T, unsigned int D, typename U>
                bool operator<=(dim<T,D> const& x, dim<U,D> const& y) {
                        return x() <= y(); }
        template<typename T, unsigned int D, typename U>
                bool operator>=(dim<T,D> const& x, dim<U,D> const& y) {
                        return x() >= y(); }

}  // namespace euclid


#endif  // EUCLID_DIMENSION_HPP
