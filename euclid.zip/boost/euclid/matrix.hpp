//  The templates and inlines for a matrix class.

//  Copyright (C) 2004-2009
//  Andreas Harnack (ah8 at freenet dot de)
//  version 0.0.4

//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.

//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.

//  You should have received a copy of the GNU General Public License along
//  with this program; if not, write to the Free Software Foundation, Inc.,
//  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.


#ifndef EUCLID_MATRIX_HPP
#define EUCLID_MATRIX_HPP

#include <functional>
#include <algorithm>
#include <iterator>     // for reverse iterator
#include <stdexcept>    // for rangecheck
#include "euclid/traits.hpp"
#include "euclid/vector.hpp"
#include "euclid/diagonal.hpp"


namespace euclid
{

        // matrix template
        template <typename T, unsigned int M, unsigned int N> class matrix
        {
                public:
                        // type definitions
                        typedef T               value_type;
                        typedef T*              iterator;
                        typedef const T*        const_iterator;
                        typedef T&              reference;
                        typedef const T&        const_reference;
                        typedef std::size_t     size_type;
                        typedef std::ptrdiff_t  difference_type;

                        enum { rows = M, columns = N, size = M*N };

                private:
                        T v[size];

                        // check range
                        static void rangecheck (std::size_t i) {
                                if ( i >= size )
                                        throw std::range_error("euclid::mtrx");
                        }

                        static void rangecheck (std::size_t i, std::size_t j) {
                                if ( i >= M || j >= N )
                                        throw std::range_error("euclid::mtrx");
                        }

                public:
                        // default constructor, default initialized
                        matrix(): v() {}

                        // const elements
                        explicit matrix(T const& c0) {
                                std::fill(v, v+size, c0); }

                        // copy constructor
                        matrix(const matrix<T,M,N>& m0) {
                                std::copy(m0.v, m0.v+size, v); }
                        // base type transformation
                        template<typename U> matrix(matrix<U,M,N> const& m0) {
                                std::copy(m0.begin(), m0.end(), v); }

                        // iterator support
                        iterator begin() {
                                return v; }
                        const_iterator begin() const {
                                return v; }
                        iterator end() {
                                return v+size; }
                        const_iterator end() const {
                                return v+size; }

                        // reverse iterator support
                        typedef std::reverse_iterator<iterator>
                                                reverse_iterator;
                        typedef std::reverse_iterator<const_iterator>
                                                const_reverse_iterator;

                        reverse_iterator rbegin() {
                                return reverse_iterator(end()); }
                        const_reverse_iterator rbegin() const {
                                return const_reverse_iterator(end()); }
                        reverse_iterator rend() {
                                return reverse_iterator(begin()); }
                        const_reverse_iterator rend() const {
                                return const_reverse_iterator(begin()); }

                        // operator[]
                        T* operator[](size_type i) {
                                return v+columns*i; }
                        T const* operator[](size_type i) const {
                                return v+columns*i; }

                        // element access
                        T& operator()(size_type i, size_type j) {
                                return *(v+columns*i+j); }
                        T const& operator()(size_type i, size_type j) const {
                                return *(v+columns*i+j); }

                        // at() with range check
                        T& at(size_type i, size_type j) {
                                rangecheck(i,j); return *(v+columns*i+j); }
                        T const& at(size_type i, size_type j) const {
                                rangecheck(i,j); return *(v+columns*i+j); }

                        // matrix addition and assignment
                        template<typename U>
                        matrix<T,M,N>& operator=(matrix<U,M,N> const& m) {
                                std::copy(m.v, m.v+size, v); return *this; }
                        template<typename U>
                        matrix<T,M,N>& operator+=(matrix<U,M,N> const& m) {
                                U const* j=m.begin();
                                for (T* i=v; i!=v+size; ++i, ++j )
                                        *i += *j; return *this; }
                        template<typename U>
                        matrix<T,M,N>& operator-=(matrix<U,M,N> const& m) {
                                U const* j=m.begin();
                                for (T* i=v; i!=v+size; ++i, ++j )
                                        *i -= *j; return *this; }

                        // scalar multiplication
                        template<typename U>
                        matrix<T,M,N>& operator*=(U const& c) {
                                for (T *i=v; i!=v+size; ++i)
                                        *i *= c; return *this; }
                        template<typename U>
                        matrix<T,M,N>& operator/=(U const& c) {
                                for (T *i=v; i!=v+size; ++i)
                                        *i /= c; return *this; }
                        template<typename U>
                        matrix<T,M,N>& operator%=(U const& c) {
                                for (T *i=v; i!=v+size; ++i)
                                        *i %= c; return *this; }

                        // equality
                        template<typename U>
                        bool operator==(matrix<U,M,N> const& m) const {
                                U const* j=m.begin();
                                for (T const* i=v; i!=v+size; ++i, ++j )
                                        if ( ! (*i == *j) )
                                                return false;
                                return true; }
                        template<typename U>
                        bool operator!=(matrix<U,M,N> const& m) const {
                                U const* j=m.begin();
                                for (T const* i=v; i!=v+size; ++i, ++j )
                                        if ( ! (*i != *j) )
                                                return false;
                                return true; }

                        // fold, map, join and friends
                        template<typename UnaryFunction>
                        UnaryFunction& foreach(UnaryFunction& fn) const {
                                for (T const* i=v; i!=v+size; ++i)
                                        fn(*i); return fn; }

                        template<typename UnaryFunction>
                        UnaryFunction& foreach(UnaryFunction& fn) {
                                for (T *i=v; i!=v+size; ++i)
                                        fn(*i); return fn; }

                        template<typename UnaryFunction, typename U>
                        UnaryFunction& map(matrix<U,M,N> const& x,
                                UnaryFunction& fn) {
                                U const* j=x.begin();
                                for (T *i=v; i!=v+size; ++i, ++j)
                                        *i = fn(*j); return fn; }

                        template<typename BinaryFunction,typename U,typename V>
                        BinaryFunction& join(matrix<U,M,N> const& x,
                                matrix<V,M,N> const& y, BinaryFunction& fn) {
                                U const* j=x.begin(); V const* k=y.begin();
                                for (T *i=v; i!=v+size; ++i, ++j, ++k)
                                        *i = fn(*j, *k); return fn; }

                        template<typename BinaryFunction>
                        typename BinaryFunction::result_type fold(
                                BinaryFunction const& fn = BinaryFunction(),
                                typename BinaryFunction::result_type const&
                                c0 = typename BinaryFunction::result_type()) {
                                for (T *i=v; i!=v+size; ++i)
                                        c0 = fn(*i, c0); return c0; }
        };


        // transpose a matrix
        template<typename T, unsigned int M, unsigned int N>
        inline matrix<T,N,M> trans(matrix<T,M,N> const& m) {
                matrix<T,N,M> tmp;
                for ( unsigned i=0; i<M; ++i )
                        for ( unsigned j=0; j<N; ++j )
                                tmp[j][i] = m[i][j];
                return tmp;
        }

        // foreach
        template<
                typename UnaryFunction,
                typename T, unsigned int M, unsigned int N
        > inline
        UnaryFunction foreach(
                matrix<T,M,N> const& x,
                UnaryFunction fn = UnaryFunction()) {
                x.foreach(fn); return fn; }

        // map
        template<
                typename UnaryFunction,
                typename T, unsigned int M, unsigned int N
        > inline
        matrix<typename UnaryFunction::result_type,M,N> map(
                matrix<T,M,N> const& x,
                UnaryFunction const& fn = UnaryFunction()) {
                matrix<typename UnaryFunction::result_type,M,N> tmp;
                tmp.map(x, fn); return tmp;
        }

        // join
        template<
                typename BinaryFunction,
                typename T, unsigned int M, unsigned int N, typename U
        > inline
        matrix<typename BinaryFunction::result_type,M,N> join(
                matrix<T,M,N> const& x, matrix<U,M,N> const& y,
                BinaryFunction const& fn = BinaryFunction()) {
                matrix<typename BinaryFunction::result_type,M,N> tmp;
                tmp.join(x, y, fn); return tmp;
        }


        // unary forall
        template<
                typename Predicate,
                typename T, unsigned int M, unsigned int N
        > inline
        bool forall(matrix<T,M,N> const& x, Predicate const& fn=Predicate()) {
                for (T const* i = x.begin(); i != x.end(); ++i)
                        if ( ! fn(*i) ) return false;
                return true; }

        // binary forall
        template<
                typename BinaryPredicate,
                typename T, unsigned int M, unsigned int N, typename U
        > inline
        bool forall(matrix<T,M,N> const& x, matrix<U,M,N> const& y,
                BinaryPredicate const& fn = BinaryPredicate()) {
                U const* j=y.begin();
                for (T const* i=x.begin(); i != x.end(); ++i, ++j )
                        if ( ! fn(*i, *j) ) return false;
                return true; }

        // fold (is that reasonable for a matrix?)
        template<
                typename BinaryFunction,
                typename T, unsigned int M, unsigned int N
        > inline
        typename BinaryFunction::result_type fold(matrix<T,M,N> const& x,
                BinaryFunction const& fn = BinaryFunction() ) {
                T const* i = x.begin(); 
                typename BinaryFunction::result_type c = *i;
                for ( ++i; i != x.end(); ++i)
                        c = fn(*i, c);
                return c; }

        // wrappers to allow template parameter deduction
        template<
                template <class> class UnaryFunction,
                typename T, unsigned int M, unsigned int N
        > inline
        matrix<typename UnaryFunction<T>::result_type,M,N>
        map(matrix<T,M,N> const& x) {
                return map(x, UnaryFunction<T>()); }


        template<
                template <class> class BinaryFunction,
                typename T, unsigned int M, unsigned int N, typename U
        > inline
        matrix<typename BinaryFunction<T>::result_type,M,N>
        join(matrix<T,M,N> const& x, matrix<U,M,N> const& y) {
                return join(x, y, BinaryFunction<T>()); }

        template<
                template <class, class> class BinaryFunction,
                typename T, unsigned int M, unsigned int N, typename U
        > inline
        matrix<typename BinaryFunction<T,U>::result_type,M,N>
        join(matrix<T,M,N> const& x, matrix<U,M,N> const& y) {
                return join(x, y, BinaryFunction<T,U>()); }


        template<
                template <class> class Predicate,
                typename T, unsigned int M, unsigned int N
        > inline
        bool forall(matrix<T,M,N> const& x) {
                return forall(x, Predicate<T>()); }


        template<
                template <class> class BinaryPredicate,
                typename T, unsigned int M, unsigned int N, typename U
        > inline
        bool forall(matrix<T,M,N> const& x, matrix<U,M,N> const& y) {
                return forall(x, y, BinaryPredicate<T>()); }

        template<
                template <class, class> class BinaryPredicate,
                typename T, unsigned int M, unsigned int N, typename U
        > inline
        bool forall(matrix<T,M,N> const& x, matrix<U,M,N> const& y) {
                return forall(x, y, BinaryPredicate<T,U>()); }


        template<
                template <class> class BinaryFunction,
                typename T, unsigned int M, unsigned int N
        > inline
        typename BinaryFunction<T>::result_type fold(matrix<T,M,N> const& x) {
                return fold(x, BinaryFunction<T>()); }

        template<
                template <class, class> class BinaryFunction,
                typename T, unsigned int M, unsigned int N
        > inline
        typename BinaryFunction<T,T>::result_type fold(matrix<T,M,N> const& x) {
                return fold(x, BinaryFunction<T,T>()); }


        // transformations
        template<typename T, unsigned int M> inline
                vec<T,M> vector(matrix<T,M,1> const& m) {
                        vec<T,M> tmp; tmp.map(m.begin()); return tmp; }

        template<typename T, unsigned int N> inline
                vec<T,N> vector(matrix<T,1,N> const& m) {
                        vec<T,N> tmp; tmp.map(m.begin()); return tmp; }

        template<typename T> inline
                vec<T,1> vector(matrix<T,1,1> const& m) {
                        vec<T,1> tmp(*m.begin()); return tmp; }

        template<typename T, unsigned int D> inline
                matrix<T,1,D> rmatrix(vec<T,D> const& v) {
                        matrix<T,1,D> tmp; v.copy(tmp.begin()); return tmp; }

        template<typename T, unsigned int D> inline
                matrix<T,D,1> cmatrix(vec<T,D> const& v) {
                        matrix<T,D,1> tmp; v.copy(tmp.begin()); return tmp; }

        template<typename T, unsigned int D> inline
                diag<T,D> diagonal(matrix<T,D,D> const& m) {
                        T t = T(); diag<T,D> tmp(t);
                        for ( unsigned int i = 0; i<D; ++i )
                                tmp[i] = m(i,i);
                        return tmp; }

#ifndef EUCLID_USE_TYPE_TRAITS

        // additive operators
        template<typename T, unsigned int M, unsigned int N> inline
        matrix<T,M,N> operator-(matrix<T,M,N> const& x) {
                return matrix<T,M,N>() -= x; }

        template<typename T, unsigned int M, unsigned int N, typename U> inline
        matrix<T,M,N> operator+(matrix<T,M,N> x, matrix<U,M,N> const& y) {
                return x += y; }

        template<typename T, unsigned int M, unsigned int N, typename U> inline
        matrix<T,M,N> operator-(matrix<T,M,N> x, matrix<U,M,N> const& y) {
                return x -= y; }

        // scalar multiplication
        template<typename T, unsigned int M, unsigned int N, typename U> inline
        matrix<T,M,N> operator*(U const& x, matrix<T,M,N> y) {
                return y *= x; }

        template<typename T, unsigned int M, unsigned int N, typename U> inline
        matrix<T,M,N> operator*(matrix<T,M,N> x, U const& y) {
                return x *= y; }

        template<typename T, unsigned int M, unsigned int N, typename U> inline
        matrix<T,M,N> operator/(matrix<T,M,N> x, U const& y) {
                return x /= y; }

        template<typename T, unsigned int M, unsigned int N, typename U> inline
        matrix<T,M,N> operator%(matrix<T,M,N> x, U const& y) {
                return x %= y; }

        // matrix multiplication
        template<
                typename T,
                unsigned int M, unsigned int K, unsigned int N
        > inline
        matrix<T,M,N> operator*(
                matrix<T,M,K>const& x,
                matrix<T,K,N>const& y) {
                matrix<T,M,N> tmp;
                for ( unsigned i=0; i<M; ++i )
                        for ( unsigned j=0; j<N; ++j ) {
                                T c = T();
                                for ( unsigned k=0; k<K; ++k )
                                        c+=x[i][k]*y[k][j];
                                tmp[i][j] = c; }
                return tmp;
        }


        // vector multiplication
        template<typename T, unsigned int M, unsigned int N, typename U> inline
        vec<T,M> operator*(matrix<T,M,N> m, vec<U,N> const& v) {
                return euclid::vector(m*euclid::cmatrix(v)); }

        template<typename T, unsigned int M, unsigned int N, typename U> inline
        vec<T,N> operator*(vec<T,M> const& v, matrix<U,M,N> const& m) {
                return euclid::vector(euclid::rmatrix(v)*m); }

#else

        // additive operators
        template<typename T, unsigned int M, unsigned int N> inline
        matrix<typename unary<T>::minus::type,M,N>
        operator-(matrix<T,M,N> const& x) {
                return matrix<typename unary<T>::minus::type,M,N> () -= x; }

        template<typename T, unsigned int M, unsigned int N, typename U> inline
        matrix<typename binary<T,U>::add::type,M,N>
        operator+(matrix<T,M,N> const& x, matrix<U,M,N> const& y) {
                return matrix<typename binary<T,U>::add::type,M,N> (x) += y; }

        template<typename T, unsigned int M, unsigned int N, typename U> inline
        matrix<typename binary<T,U>::sub::type,M,N>
        operator-(matrix<T,M,N> const& x, matrix<U,M,N> const& y) {
                return matrix<typename binary<T,U>::sub::type,M,N> (x) -= y; }

        // scalar multiplication
        template<typename T, unsigned int M, unsigned int N, typename U> inline
        matrix<typename binary<T,U>::mul::type,M,N>
        operator*(T const& x, matrix<U,M,N> const& y) {
                return matrix<typename binary<T,U>::mul::type,M,N> (y) *= x; }

        template<typename T, unsigned int M, unsigned int N, typename U> inline
        matrix<typename binary<T,U>::mul::type,M,N>
        operator*(matrix<T,M,N> const& x, U const& y) {
                return matrix<typename binary<T,U>::mul::type,M,N> (x) *= y; }

        template<typename T, unsigned int M, unsigned int N, typename U> inline
        matrix<typename binary<T,U>::div::type,M,N>
        operator/(matrix<T,M,N> const& x, U const& y) {
                return matrix<typename binary<T,U>::div::type,M,N> (x) /= y; }

        template<typename T, unsigned int M, unsigned int N, typename U> inline
        matrix<typename binary<T,U>::mod::type,M,N>
        operator%(matrix<T,M,N> const& x, U const& y) {
                return matrix<typename binary<T,U>::mod::type,M,N> (x) %= y; }


        // these traits are needed for operator@(vec<T,D> const& x, U& y)
        // in vector.h if U matches matrix<U,M,N>; the operators are overloaded
        // for this case by the following definitions, so the types in
        // here are never really used, however, it seems the compiler
        // needs to deduce the return type even if it finds a better match,
        // so these traits are here merely here to keep the compiler happy

        // matrix multiplication
        template<
                typename T, typename U,
                unsigned int M, unsigned int K, unsigned int N
        > inline
        matrix<typename binary<T,U>::mul::type,M,N> operator*(
                matrix<T,M,K>const& x,
                matrix<U,K,N>const& y) {
                typedef typename binary<T,U>::mul::type  R;
                matrix<R,M,N> tmp;
                for ( unsigned i=0; i<M; ++i )
                        for ( unsigned j=0; j<N; ++j ) {
                                R c = R();
                                for ( unsigned k=0; k<K; ++k )
                                        c+=x[i][k]*y[k][j];
                                tmp[i][j] = c; }
                return tmp;
        }

        // vector multiplication
        template<typename T, unsigned int M, unsigned int N, typename U> inline
        vec<typename binary<T,U>::mul::type,M> operator*(matrix<T,M,N> m, vec<U,N> const& v) {
                return euclid::vector(m*euclid::cmatrix(v)); }

        template<typename T, unsigned int M, unsigned int N, typename U> inline
        vec<typename binary<T,U>::mul::type,N> operator*(vec<T,M> const& v, matrix<U,M,N> const& m) {
                return euclid::vector(euclid::rmatrix(v)*m); }

#endif  // EUCLID_USE_TYPE_TRAITS

}  // namespace euclid


#endif  // EUCLID_MATRIX_HPP
