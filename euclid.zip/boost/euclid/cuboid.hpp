//  The template and inlines for a cuboid class.

//  Copyright (C) 2004-2009
//  Andreas Harnack (ah8 at freenet dot de)
//  version 0.0.4

//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.

//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.

//  You should have received a copy of the GNU General Public License along
//  with this program; if not, write to the Free Software Foundation, Inc.,
//  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.


#ifndef EUCLID_CUBOID_HPP
#define EUCLID_CUBOID_HPP

#include "euclid/diagonal.hpp"
#include <functional>


namespace euclid
{

        template<typename T, unsigned int D> inline
        vec<T,D> inf(vec<T,D> const& x, vec<T,D> const& y) {
                return join<euclid::min>(x,y); }

        template<typename T, unsigned int D> inline
        vec<T,D> sup(const vec<T,D>& x, const vec<T,D>& y) {
                return join<euclid::max>(x,y); }


        template <typename T, unsigned int D> class cuboid
        {
                public:
                        typedef vec<T,D> vect;

                private:
                        vect    P0;
                        vect    P1;

                public:
                        cuboid(): P0(), P1() {}
                        cuboid(const T& c): P0(), P1(c) {}
                        cuboid(const vect& v): P0(), P1(v) {}
                        cuboid(const vect& v0, const vect& v1):
                                P0(v0), P1(v1) {}

                        cuboid(cuboid const& c): P0(c.P0), P1(c.P1) {}

                        cuboid& operator=(cuboid const& c) {
                                P0 = c.P0; P1 = c.P1; return *this; }

                        cuboid& operator+=(vect const& o) {
                                P0 += o; P1 += o; return *this; }
                        cuboid& operator-=(vect const& o) {
                                P0 -= o; P1 -= o; return *this; }

                        template<typename U>
                                cuboid& operator*=(U const& s) {
                                        P0 *= s; P1 *= s; return *this; }
                        template<typename U>
                                cuboid& operator/=(U const& s) {
                                        P0 /= s; P1 /= s; return *this; }
                        template<typename U>
                                cuboid& operator%=(U const& s) {
                                        P0 %= s; P1 %= s; return *this; }

                        cuboid operator+(vect const& o) const {
                                cuboid tmp(*this); tmp+=o; return tmp; }
                        cuboid operator-(vect const& o) const {
                                cuboid tmp(*this); tmp-=o; return tmp; }

                        cuboid operator*(diag<T,D> const& s) const {
                                cuboid tmp(P0*s,P1*s); return tmp; }
                        cuboid operator/(diag<T,D> const& s) const {
                                cuboid tmp(P0/s,P1/s); return tmp; }
                        cuboid operator%(diag<T,D> const& s) const {
                                cuboid tmp(P0%s,P1%s); return tmp; }

                        vect& p0() { return P0; }
                        vect& p1() { return P1; }
                        vect const& p0() const { return P0; }
                        vect const& p1() const { return P1; }

                        vect orig() const { return P0; }
                        vect size() const { return P1-P0; }

                        cuboid& orig(vect const& o) {
                                P1 = size()+o; P0 = o; return *this; }
                        cuboid& size(vect const& s) {
                                P1 = s+orig(); return *this; }

                        cuboid& stretch(vect const& s) {
                                P1 = size()*s + orig(); return *this; }
                        cuboid& grow(vect const& r) {
                                P1 += r; return *this; }
                        cuboid& shrink(vect const& r) {
                                P1 -= r; return *this; }

                        bool proper() const {
                                return forall<std::less>(P0,P1); }

                friend cuboid closure(cuboid const& a, cuboid const& b) {
                        return cuboid( inf(a.P0, b.P0), sup(a.P1, b.P1) ); }
                friend cuboid intersect(cuboid const& a, cuboid const& b) {
                        return cuboid( sup(a.P0, b.P0), inf(a.P1, b.P1) ); }
        };

}  // namespace euclid


#endif  // EUCLID_CUBOID_HPP
