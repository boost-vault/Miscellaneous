//  The Functors for the Euclid vector class's fold, map and join templates.

//  Copyright (C) 2004-2009
//  Andreas Harnack (ah8 at freenet dot de)
//  version 0.0.4

//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.

//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.

//  You should have received a copy of the GNU General Public License along
//  with this program; if not, write to the Free Software Foundation, Inc.,
//  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.


#ifndef EUCLID_NORM_HPP
#define EUCLID_NORM_HPP

#include <functional>
#include "euclid/vector.hpp"


namespace euclid
{

        // pNorm
        template<unsigned int N, typename T>
        struct pNorm {

                typedef T result_type;

                template<unsigned int P, typename U>
                struct power: public std::unary_function<U,U> {
                        U operator()(U const& x) const {
                                power< (P>>1),U > p;
                                return (P&1) ? x*p(x*x) : p(x*x); }
                };

                template<typename U>
                struct power<1,U>: public std::unary_function<U,U> {
                        U operator()(U const& x) const { return x; }
                };

                T operator()(T const& x) const {
                        return power<N,T>()(euclid::abs(x)); }
                T operator()(T const& x, T const& y) const {
                        return x+y; }
        };

        template<typename T>
        struct pNorm<0,T> {
                typedef T result_type;
                T operator()(T const& x) const {
                        return euclid::abs(x); }
                T operator()(T const& x, T const& y) const {
                        return std::max(x,y); }
        };


        template<unsigned int N, unsigned int D, typename T> inline
        typename pNorm<N,T>::result_type pnorm(vec<T,D> const& v) {
                return norm(v, pNorm<N,T>()); }


        // functors
        template<class T>
        struct min: public std::binary_function<T, T, T> {
                T operator()(T const& x, T const& y) const {
                        return x < y ? x : y; }
        };

        template<class T>
        struct max: public std::binary_function<T, T, T> {
                T operator()(T const& x, T const& y) const {
                        return x < y ? y : x; }
        };

        template<class T>
        struct positive: public std::unary_function<T, bool> {
                bool operator()(T const& x) const { return x > T(); }
        };

        template<class T>
        struct negative: public std::unary_function<T, bool> {
                bool operator()(T const& x) const { return x < T(); }
        };

        template<class T>
        struct not_positive: public std::unary_function<T, bool> {
                bool operator()(T const& x) const { return x <= T(); }
        };

        template<class T>
        struct not_negative: public std::unary_function<T, bool> {
                bool operator()(T const& x) const { return x >= T(); }
        };

#ifndef EUCLID_USE_TYPE_TRAITS


        template<class T, class U>
        struct plus: public std::binary_function<T, T, T> {
                T operator()(T const& x, U const& y) const {
                        return x + y; }
        };

        template<class T, class U>
        struct minus: public std::binary_function<T, T, T> {
                T operator()(T const& x, U const& y) const {
                        return x - y; }
        };

        template<class T, class U>
        struct multiplies: public std::binary_function<T, T, T> {
                T operator()(T const& x, U const& y) const {
                        return x * y; }
        };

        template<class T, class U>
        struct divides: public std::binary_function<T, T, T> {
                T operator()(T const& x, U const& y) const {
                        return x / y; }
        };

        template<class T, class U>
        struct modulus: public std::binary_function<T, T, T> {
                T operator()(T const& x, U const& y) const {
                        return x % y; }
        };

#else

        template<class T, class U> struct plus
        : public std::binary_function<T,U, typename binary<T,U>::add::type> {
                typename binary<T,U>::add::type
                operator()(T const& x, U const& y) const { return x + y; }
        };

        template<class T, class U> struct minus
        : public std::binary_function<T,U, typename binary<T,U>::sub::type> {
                typename binary<T,U>::sub::type
                operator()(T const& x, U const& y) const { return x - y; }
        };

        template<class T, class U> struct multiplies
        : public std::binary_function<T,U, typename binary<T,U>::mul::type> {
                typename binary<T,U>::mul::type
                operator()(T const& x, U const& y) const { return x * y; }
        };

        template<class T, class U> struct divides
        : public std::binary_function<T,U, typename binary<T,U>::div::type> {
                typename binary<T,U>::div::type
                operator()(T const& x, U const& y) const { return x / y; }
        };

        template<class T, class U> struct modulus
        : public std::binary_function<T,U, typename binary<T,U>::mod::type> {
                typename binary<T,U>::mod::type
                operator()(T const& x, U const& y) const { return x % y; }
        };

#endif  // EUCLID_USE_TYPE_TRAITS

}  // namespace euclid


#endif  // EUCLID_NORM_HPP
