//  The templates and inlines for an Euclidean vector class.

//  Copyright (C) 2004-2009
//  Andreas Harnack (ah8 at freenet dot de)
//  version 0.0.4

//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.

//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.

//  You should have received a copy of the GNU General Public License along
//  with this program; if not, write to the Free Software Foundation, Inc.,
//  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.


#ifndef EUCLID_VECTOR_HPP
#define EUCLID_VECTOR_HPP

#include <iosfwd>
#include "euclid/traits.hpp"
#include "euclid/dimension.hpp"


namespace euclid
{
        // Forward declarations
        template<typename T, unsigned int D> class vec;

        // base cases for recursive classes
        template<typename T> class vec<T,0>; // never defined
        template<typename T> class vec<T,1>;


        // vector class template
        template<typename T, unsigned int D> class vec
        {
                protected:
                        dim<T,D-1> d;
                        vec<T,D-1> v;

                public:
                        typedef T value_type;
                        enum { dimension = D };

                        // default constructor, zero vector
                        vec(): d(), v() {}
                        // copy constructor
                        vec(vec<T,D> const& v0) : d(v0.d), v(v0.v) {}

                        // const elements
                        explicit vec(T const& c) : d(c), v(c) {}

                        // composition
                        vec(T const& c0, vec<T,D-1> const& v0 ) :
                                d(c0), v(v0) {}

                        vec(dim<T,D-1> const& d0, vec<T,D-1> const& v0 ) :
                                d(d0), v(v0) {}

                        // element access
                        dim<T,D-1>& head() { return d; }
                        dim<T,D-1> const& head() const { return d; }
                        vec<T,D-1>& tail() { return v; }
                        vec<T,D-1> const& tail() const { return v; }

                        // base type transformation
                        template<typename U> vec(vec<U,D> const& v0) :
                                d(v0.head()), v(v0.tail()) {}

                        // transform dimension to vector
                        template <unsigned int I>
                                vec(dim<T, I> const& c) : d(), v(c) {}

                        vec(dim<T, D-1> const& c) : d(c), v() {}

                        // component access
                        template <unsigned int I>
                                operator dim<T,I>() const {
                                        return dim<T,I>(v); }

                        operator dim<T, D-1>() const { return d; }

                        // element access by reference
                        template <typename U, unsigned int I>
                                dim<T,I> const& operator[](dim<U,I> const&)
                                        const { return v[dim<U,I>()]; }

                        template <typename U, unsigned int I>
                                dim<T,I>& operator[](dim<U,I> const&) {
                                        return v[dim<U,I>()]; }

                        template <typename U>
                                dim<T,D-1> const& operator[](dim<U,D-1> const&)
                                        const { return d; }
                        template <typename U>
                                dim<T,D-1>& operator[](dim<U,D-1> const&)
                                        { return d; }

                        // element addition and assignment
                        template<typename U, unsigned int I>
                                vec<T,D>& operator=(dim<U,I> const& d0) {
                                        v = d0; return *this; }
                        template<typename U, unsigned int I>
                                vec<T,D>& operator+=(dim<U,I> const& d0) {
                                        v += d0; return *this; }
                        template<typename U, unsigned int I>
                                vec<T,D>& operator-=(dim<U,I> const& d0) {
                                        v -= d0; return *this; }

                        template<typename U>
                                vec<T,D>& operator=(dim<U,D-1> const& d0) {
                                        d = d0; return *this; }
                        template<typename U>
                                vec<T,D>& operator+=(dim<U,D-1> const& d0) {
                                        d += d0; return *this; }
                        template<typename U>
                                vec<T,D>& operator-=(dim<U,D-1> const& d0) {
                                        d -= d0; return *this; }

                        // vector addition and assignment
                        template<typename U>
                                vec<T,D>& operator=(vec<U,D> const&);
                        template<typename U>
                                vec<T,D>& operator+=(vec<U,D> const&);
                        template<typename U>
                                vec<T,D>& operator-=(vec<U,D> const&);

                        // scalar multiplication
                        template<typename U>
                                vec<T,D>& operator*=(U const&);
                        template<typename U>
                                vec<T,D>& operator/=(U const&);
                        template<typename U>
                                vec<T,D>& operator%=(U const&);

                        // fold, map, join and friends
                        template<typename UnaryFunction>
                        UnaryFunction& foreach(UnaryFunction& fn) const {
                                v.foreach(fn); fn(d()); return fn; }

                        template<typename UnaryFunction>
                        UnaryFunction& foreach(UnaryFunction& fn) {
                                v.foreach(fn); fn(d()); return fn; }

                        template<typename Iterator>
                        Iterator copy(Iterator it) const {
                                *(it=tail().copy(it)) = d(); return ++it; }

                        template<typename Iterator>
                        Iterator map(Iterator it) {
                                d() = *(it=tail().map(it)); return ++it; }

                        template<typename UnaryFunction, typename U>
                        UnaryFunction& map(vec<U,D> const& v0,
                                UnaryFunction& fn) {
                                d() = fn(v0.head()());
                                return v.map(v0.tail(), fn); }

                        template<typename BinaryFunction,typename U,typename V>
                        BinaryFunction& join(vec<U,D> const& v0,
                                vec<V,D> const& v1, BinaryFunction& fn) {
                                d() = fn(v0.head()(), v1.head()());
                                return v.join(v0.tail(), v1.tail(), fn); }

                        template<typename BinaryFunction>
                        typename BinaryFunction::result_type fold(
                                BinaryFunction const& fn = BinaryFunction(),
                                typename BinaryFunction::result_type const&
                                c0 = typename BinaryFunction::result_type()) {
                                return fn(d(), v.fold(fn, c0)); }

                        // stream output
                        template<typename Char, class Traits>
                        std::basic_ostream<Char, Traits>& print(
                                std::basic_ostream<Char, Traits>&) const;

                private:
                        // thinks we explicitely wish to exclude
                        template<unsigned int I> vec(vec<T,I> const&) {}
        };

        // vector addition and assignment
        template<typename T, unsigned int D> template<typename U> inline
                vec<T,D>& vec<T,D>::operator=(vec<U,D> const& v0) {
                        d = v0.head(); v = v0.tail(); return *this; }

        template<typename T, unsigned int D> template<typename U> inline
                vec<T,D>& vec<T,D>::operator+=(vec<U,D> const& v0) {
                        d += v0.head(); v += v0.tail(); return *this; }

        template<typename T, unsigned int D> template<typename U> inline
                vec<T,D>& vec<T,D>::operator-=(vec<U,D> const& v0) {
                        d -= v0.head(); v -= v0.tail(); return *this; }

        // scalar multiplication
        template<typename T, unsigned int D> template<typename U> inline
                vec<T,D>& vec<T,D>::operator*=(U const& c) {
                        d *= c; v *= c; return *this; }

        template<typename T, unsigned int D> template<typename U> inline
                vec<T,D>& vec<T,D>::operator/=(U const& c) {
                        d /= c; v /= c; return *this; }

        template<typename T, unsigned int D> template<typename U> inline
                vec<T,D>& vec<T,D>::operator%=(U const& c) {
                        d %= c; v %= c; return *this; }


        // base case
        template<typename T> class vec<T,1>
        {
                protected:
                        dim<T,0> d;

                public:
                        typedef T value_type;
                        enum { dimension = 1 };

                        // default constructor, zero vector
                        vec(): d() {}
                        // const elements, unit vector
                        explicit vec(T const& c) : d(c) {}
                        // copy constructor
                        vec(vec<T,1> const& v0) : d(v0.d) {}

                        // synthesis
                        explicit vec(dim<T,0> const& d0) : d(d0) {}

                        // element access
                        operator dim<T,0>() const { return d; }

                        // reference access
                        template<typename U>
                                dim<T,0> const& operator[](dim<U,0> const&)
                                        const { return d; }
                        template<typename U>
                                dim<T,0>& operator[](dim<U,0> const&)
                                        { return d; }


                        // component access
                        dim<T,0>& head() { return d; }
                        dim<T,0> const& head() const { return d; }

                        // base type transformation
                        template<typename U> vec(vec<U,1> const& v0) :
                                d(v0.head()) {}

                        // element addition and assignment
                        template<typename U>
                                vec<T,1>& operator=(dim<U,0> const& d0) {
                                        d = d0; return *this; }
                        template<typename U>
                                vec<T,1>& operator+=(dim<U,0> const& d0) {
                                        d += d0; return *this; }
                        template<typename U>
                                vec<T,1>& operator-=(dim<U,0> const& d0) {
                                        d -= d0; return *this; }

                        // vector addition and assignment
                        template<typename U>
                                vec<T,1>& operator=(vec<U,1> const& v0) {
                                        d = v0.head(); return *this; }
                        template<typename U>
                                vec<T,1>& operator+=(vec<U,1> const& v0) {
                                        d += v0.head(); return *this; }
                        template<typename U>
                                vec<T,1>& operator-=(vec<U,1> const& v0) {
                                        d -= v0.head(); return *this; }

                        // scalar multiplication
                        template<typename U>
                                vec<T,1>& operator*=(U const& c) {
                                        d *= c; return *this; }
                        template<typename U>
                                vec<T,1>& operator/=(U const& c) {
                                        d /= c; return *this; }
                        template<typename U>
                                vec<T,1>& operator%=(U const& c) {
                                        d %= c; return *this; }

                        // fold, map, join and friends
                        template<typename UnaryFunction>
                        UnaryFunction& foreach(UnaryFunction& fn) const {
                                fn(d()); return fn; }

                        template<typename UnaryFunction>
                        UnaryFunction& foreach(UnaryFunction& fn) {
                                fn(d()); return fn; }

                        template<typename Iterator>
                        Iterator copy(Iterator it) const {
                                *it = d(); return ++it; }

                        template<typename Iterator>
                        Iterator map(Iterator it) {
                                d() = *it; return ++it; }

                        template<typename UnaryFunction, typename U>
                        UnaryFunction& map(vec<U,1> const& v0,
                                UnaryFunction& fn) {
                                d() = fn(v0.head()()); return fn; }

                        template<typename BinaryFunction,typename U,typename V>
                        BinaryFunction& join(vec<U,1> const& v0,
                                vec<V,1> const& v1, BinaryFunction& fn) {
                                d() = fn(v0.head()(),v1.head()()); return fn; }

                        template<typename BinaryFunction>
                        typename BinaryFunction::result_type fold(
                                BinaryFunction const& fn = BinaryFunction(),
                                typename BinaryFunction::result_type const&
                                c0 = typename BinaryFunction::result_type()) {
                                return fn(d(), c0); }

                        // stream output
                        template<typename Char, class Traits>
                        std::basic_ostream<Char, Traits>& print(
                                std::basic_ostream<Char, Traits>&) const;

                private:
                        // thinks we explicitely wish to exclude
                        template<unsigned int I> vec(vec<T,I> const&) {}
        };


        // component access by reference
        template<typename U, typename T, unsigned int D> inline
                U const& at(vec<T,D> const& v) { return v[U()]; }
        template<typename U, typename T, unsigned int D> inline
                U& at(vec<T,D>& v) { return v[U()]; }

        // foreach
        template<
                typename UnaryFunction,
                typename T, unsigned int D
        > inline
        UnaryFunction foreach(vec<T,D> const& x,
                UnaryFunction fn = UnaryFunction()) {
                x.foreach(fn); return fn; }

        // map
        template<
                typename UnaryFunction,
                typename T, unsigned int D
        > inline
        vec<typename UnaryFunction::result_type,D> map(vec<T,D> const& x,
                UnaryFunction const& fn = UnaryFunction()) {
                vec<typename UnaryFunction::result_type,D> tmp;
                tmp.map(x, fn); return tmp;
        }

        // join
        template<
                typename BinaryFunction,
                typename T, unsigned int D, typename U
        > inline
        vec<typename BinaryFunction::result_type,D> join(
                vec<T,D> const& x, vec<U,D> const& y,
                BinaryFunction const& fn = BinaryFunction()) {
                vec<typename BinaryFunction::result_type,D> tmp;
                tmp.join(x, y, fn); return tmp;
        }


        // unary forall
        template<typename Predicate, typename T, unsigned int D> inline
        bool forall(vec<T,D> const& x, Predicate const& fn = Predicate()) {
                return fn(x.head()()) && forall(x.tail(),fn); }

        template<typename Predicate, typename T> inline
        bool forall(vec<T,1> const& x, Predicate const& fn = Predicate()) {
                return fn(x.head()()); }

        // binary forall
        template<
                typename BinaryPredicate,
                typename T, unsigned int D, typename U
        > inline
        bool forall(vec<T,D> const& x, vec<U,D> const& y,
                BinaryPredicate const& fn = BinaryPredicate()) {
                return fn(x.head()(), y.head()())
                        && forall(x.tail(), y.tail(),fn); }

        template<
                typename BinaryPredicate,
                typename T, typename U> inline
        bool forall(vec<T,1> const& x, vec<U,1> const& y,
                BinaryPredicate const& fn = BinaryPredicate()) {
                return fn(x.head()(), y.head()()); }


        // fold
        template<typename BinaryFunction, typename T, unsigned int D> inline
        typename BinaryFunction::result_type fold(vec<T,D> const& x,
                BinaryFunction const& fn = BinaryFunction() ) {
                return fn(x.head()(), fold(x.tail(), fn)); }

        template<typename BinaryFunction, typename T> inline
        typename BinaryFunction::result_type fold(vec<T,1> const& x,
                BinaryFunction const& fn = BinaryFunction() ) {
                return x.head()(); }


        // norm
        template<typename Norm, typename T, unsigned int D> inline
        typename Norm::result_type norm(vec<T,D> const& x,
                Norm const& fn = Norm()) {
                return fn(fn(x.head()()), norm(x.tail(), fn)); }

        template<typename Norm, typename T> inline
        typename Norm::result_type norm(vec<T,1> const& x,
                Norm const& fn = Norm()) {
                return fn(x.head()()); }


        // wrappers to allow template parameter deduction
        template<
                template <class> class UnaryFunction,
                typename T, unsigned int D
        > inline
        vec<typename UnaryFunction<T>::result_type,D>
        map(vec<T,D> const& x) {
                return map(x, UnaryFunction<T>()); }


        template<
                template <class> class BinaryFunction,
                typename T, unsigned int D, typename U
        > inline
        vec<typename BinaryFunction<T>::result_type,D>
        join(vec<T,D> const& x, vec<U,D> const& y) {
                return join(x, y, BinaryFunction<T>()); }

        template<
                template <class, class> class BinaryFunction,
                typename T, unsigned int D, typename U
        > inline
        vec<typename BinaryFunction<T,U>::result_type,D>
        join(vec<T,D> const& x, vec<U,D> const& y) {
                return join(x, y, BinaryFunction<T,U>()); }


        template<
                template <class> class Predicate,
                typename T, unsigned int D
        > inline
        bool forall(vec<T,D> const& x) {
                return forall(x, Predicate<T>()); }


        template<
                template <class> class BinaryPredicate,
                typename T, unsigned int D, typename U
        > inline
        bool forall(vec<T,D> const& x, vec<U,D> const& y) {
                return forall(x, y, BinaryPredicate<T>()); }

        template<
                template <class, class> class BinaryPredicate,
                typename T, unsigned int D, typename U
        > inline
        bool forall(vec<T,D> const& x, vec<U,D> const& y) {
                return forall(x, y, BinaryPredicate<T,U>()); }


        template<
                template <class> class BinaryFunction,
                typename T, unsigned int D
        > inline
        typename BinaryFunction<T>::result_type fold(vec<T,D> const& x) {
                return fold(x, BinaryFunction<T>()); }


        template<
                template <class> class Norm,
                typename T, unsigned int D
        > inline
        typename Norm<T>::result_type norm(vec<T,D> const& x) {
                return norm(x, Norm<T>()); }


#ifndef EUCLID_USE_TYPE_TRAITS


        // additive operators
        template<typename T, unsigned int D, typename U, unsigned int N> inline
                vec<T,D> operator+(vec<T,D> x, dim<U,N> const& y) {
                        return x += y; }

        template<typename T, unsigned int D, typename U, unsigned int N> inline
                vec<T,D> operator-(vec<T,D> x, dim<U,N> const& y) {
                        return x -= y; }


        template<typename T, unsigned int D> inline
                vec<T,D> operator-(vec<T,D> const& x) {
                        return vec<T,D>() -= x; }

        template<typename T, unsigned int D, typename U> inline
                vec<T,D> operator+(vec<T,D> x, vec<U,D> const& y) {
                        return x += y; }

        template<typename T, unsigned int D, typename U> inline
                vec<T,D> operator-(vec<T,D> x, vec<U,D> const& y) {
                        return x -= y; }

        // scalar multiplication
        template<typename T, unsigned int D, typename U> inline
                vec<T,D> operator*(U const& x, vec<T,D> y) {
                        return y *= x; }

        template<typename T, unsigned int D, typename U> inline
                vec<T,D> operator*(vec<T,D> x, U const& y) {
                        return x *= y; }

        template<typename T, unsigned int D, typename U> inline
                vec<T,D> operator/(vec<T,D> x, U const& y) {
                        return x /= y; }

        template<typename T, unsigned int D, typename U> inline
                vec<T,D> operator%(vec<T,D> x, U const& y) {
                        return x %= y; }


        // scalar product
        template<typename T, unsigned int D, typename U> inline
                T operator*(vec<T,D> const& x, vec<U,D> const& y) {
                        return x.head()*y.head() + x.tail()*y.tail(); }

        template<typename T, typename U> inline
                T operator*(vec<T,1> const& x, vec<U,1> const& y) {
                        return x.head()*y.head(); }

        // cross product
        template<typename T> inline
                vec<T,2> prod(vec<T,2> const& x) {
                        vec<T,2> tmp;
                        tmp += dim<T,0>(dim<T,1>(x)());
                        tmp -= dim<T,1>(dim<T,0>(x)());
                        return tmp; }

        template<typename T, typename U> inline
                vec<T,3> prod(vec<T,3> const& x, vec<U,3> const& y) {
                        vec<T,3> tmp;
                        tmp += dim<T,0>(dim<T,1>(x)()*dim<U,2>(y)());
                        tmp -= dim<T,0>(dim<T,2>(x)()*dim<U,1>(y)());
                        tmp += dim<T,1>(dim<T,0>(x)()*dim<U,2>(y)());
                        tmp -= dim<T,1>(dim<T,2>(x)()*dim<U,0>(y)());
                        tmp += dim<T,2>(dim<T,0>(x)()*dim<U,1>(y)());
                        tmp -= dim<T,2>(dim<T,1>(x)()*dim<U,0>(y)());
                        return tmp; }

#else

        // additive operators
        template<typename T, unsigned int D, typename U, unsigned int I>
                inline vec<typename binary<T,U>::add::type,D>
                        operator+(vec<T,D> const& x, dim<U,I> const& y) {
                                return vec<typename binary<T,U>::add::type,D>
                                        (x) += y; }

        template<typename T, unsigned int D, typename U, unsigned int I>
                inline vec<typename binary<T,U>::sub::type,D>
                        operator-(vec<T,D> const& x, dim<U,I> const& y) {
                                return vec<typename binary<T,U>::sub::type,D>
                                        (x) -= y; }


        template<typename T, unsigned int D>
                inline vec<typename unary<T>::minus::type,D>
                        operator-(vec<T,D> const& x) {
                                return vec<typename unary<T>::minus::type,D>
                                        () -= x; }

        template<typename T, unsigned int D, typename U>
                inline vec<typename binary<T,U>::add::type,D>
                        operator+(vec<T,D> const& x, vec<U,D> const& y) {
                                return vec<typename binary<T,U>::add::type,D>
                                        (x) += y; }

        template<typename T, unsigned int D, typename U>
                inline vec<typename binary<T,U>::sub::type,D>
                        operator-(vec<T,D> const& x, vec<U,D> const& y) {
                                return vec<typename binary<T,U>::sub::type,D>
                                        (x) -= y; }

        // scalar multiplication
        template<typename T, unsigned int D, typename U>
                inline vec<typename binary<T,U>::mul::type,D>
                        operator*(U const& x, vec<T,D> const& y) {
                                return vec<typename binary<T,U>::mul::type,D>
                                        (y) *= x; }

        template<typename T, unsigned int D, typename U>
                inline vec<typename binary<T,U>::mul::type,D>
                        operator*(vec<T,D> const& x, U const& y) {
                                return vec<typename binary<T,U>::mul::type,D>
                                        (x) *= y; }

        template<typename T, unsigned int D, typename U>
                inline vec<typename binary<T,U>::div::type,D>
                        operator/(vec<T,D> const& x, U const& y) {
                                return vec<typename binary<T,U>::div::type,D>
                                        (x) /= y; }

        template<typename T, unsigned int D, typename U>
                inline vec<typename binary<T,U>::mod::type,D>
                        operator%(vec<T,D> const& x, U const& y) {
                                return vec<typename binary<T,U>::mod::type,D>
                                        (x) %= y; }

        // scalar product
        template<typename T, unsigned int D, typename U>
                inline typename binary<T,U>::mul::type
                        operator*(vec<T,D> const& x, vec<U,D> const& y) {
                                return x.head()*y.head()+x.tail()*y.tail(); }

        template<typename T, typename U>
                inline typename binary<T,U>::mul::type
                        operator*(vec<T,1> const& x, vec<U,1> const& y) {
                                return x.head()*y.head(); }

        // cross product
        template<typename T> inline
                vec<T,2> prod(vec<T,2> const& x) {
                        vec<T,2> tmp;
                        tmp += dim<T,0>(dim<T,1>(x)());
                        tmp -= dim<T,1>(dim<T,0>(x)());
                        return tmp; }

        template<typename T, typename U> inline
                vec<typename binary<T,U>::mul::type,3>
                        prod(vec<T,3> const& x, vec<U,3> const& y) {
                                typedef typename binary<T,U>::mul::type t;
                                vec<t,3> tmp;
                                tmp += dim<t,0>(dim<T,1>(x)()*dim<U,2>(y)());
                                tmp -= dim<t,0>(dim<T,2>(x)()*dim<U,1>(y)());
                                tmp += dim<t,1>(dim<T,0>(x)()*dim<U,2>(y)());
                                tmp -= dim<t,1>(dim<T,2>(x)()*dim<U,0>(y)());
                                tmp += dim<t,2>(dim<T,0>(x)()*dim<U,1>(y)());
                                tmp -= dim<t,2>(dim<T,1>(x)()*dim<U,0>(y)());
                                return tmp; }

#endif  // EUCLID_USE_TYPE_TRAITS


        // equality
        template<typename T, unsigned int D, typename U> inline
                bool operator==(vec<T,D> const& x, vec<U,D> const& y) {
                        return x.head() == y.head() && x.tail() == y.tail(); }

        template<typename T, unsigned int D, typename U> inline
                bool operator!=(vec<T,D> const& x, vec<U,D> const& y) {
                        return x.head() != y.head() || x.tail() != y.tail(); }

        template<typename T, typename U> inline
                bool operator==(vec<T,1> const& x, vec<U,1> const& y) {
                        return x.head() == y.head(); }

        template<typename T, typename U> inline
                bool operator!=(vec<T,1> const& x, vec<U,1> const& y) {
                        return x.head() != y.head(); }


        // the comma operator
        // (the additional template parameter is required
        // to avoid unwanted implicit type conversion )
        template<typename T, unsigned int I> inline
                vec<T,2> operator,(dim<T,0> const& d0, dim<T,I> const& d1) {
                        return vec<T,2>(d1, vec<T,1>(d0)); }

        template<typename T, unsigned int D, unsigned int I> inline
                vec<T,D+1> operator,(vec<T,D> const& v0, dim<T,I> const& d0) {
                        return vec<T,D+1>(d0, v0); }

}  // namespace euclid


#endif  // EUCLID_VECTOR_HPP
