//  The type traits for the Euclid class templates.

//  Copyright (C) 2004-2009
//  Andreas Harnack (ah8 at freenet dot de)
//  version 0.0.4

//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.

//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.

//  You should have received a copy of the GNU General Public License along
//  with this program; if not, write to the Free Software Foundation, Inc.,
//  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.


#ifndef EUCLID_TRAITS_HPP
#define EUCLID_TRAITS_HPP

#include <algorithm>


namespace euclid
{

        template<typename T> struct unary
        {
                struct plus  { typedef typeof(+T()) type; };
                struct minus { typedef typeof(-T()) type; };
                struct abs   { typedef typeof(std::abs(T())) type; };
        };

        template<typename T, typename U> struct binary
        {
                struct add  { typedef typeof(T()+U()) type; };
                struct sub  { typedef typeof(T()-U()) type; };
                struct mul  { typedef typeof(T()*U()) type; };
                struct div  { typedef typeof(T()/U(1)) type; };
                struct mod  { typedef typeof(T()%U(1)) type; };
        };


        template<typename T> T inline abs(T v) { return std::abs(v); }
        template<> unsigned char inline abs(unsigned char v) { return v; }
        template<> unsigned int inline abs(unsigned int v) { return v; }
        template<> unsigned long int inline abs(unsigned long int v) { return v; }

}  // namespace euclid


#endif  // EUCLID_TRAITS_HPP
