//  The templates and inlines for a diagonal matrix class.

//  Copyright (C) 2004-2009
//  Andreas Harnack (ah8 at freenet dot de)
//  version 0.0.4

//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.

//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.

//  You should have received a copy of the GNU General Public License along
//  with this program; if not, write to the Free Software Foundation, Inc.,
//  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.


#ifndef EUCLID_DIAGONAL_HPP
#define EUCLID_DIAGONAL_HPP

#include <functional>
#include <algorithm>
#include <iterator>     // for reverse iterator
#include <stdexcept>    // for rangecheck
#include "euclid/traits.hpp"
#include "euclid/vector.hpp"
#include "euclid/norm.hpp"


namespace euclid
{

        // diagonal matrix template
        template <typename T, unsigned int D> class diag
        {
                public:
                        // type definitions
                        typedef T               value_type;
                        typedef T*              iterator;
                        typedef const T*        const_iterator;
                        typedef T&              reference;
                        typedef const T&        const_reference;
                        typedef std::size_t     size_type;
                        typedef std::ptrdiff_t  difference_type;

                        enum { dimension = D };

                private:
                        T v[D];

                        // check range
                        static void rangecheck (std::size_t i) {
                                if (i >= D )
                                        throw std::range_error("euclid::diag");
                        }

                public:
                        // default constructor, default initialized
                        diag(): v() {}

                        // const elements, unit matrix
                        explicit diag(T const& c0) {
                                std::fill(v, v+D, c0); }

                        // copy constructor
                        diag(const diag<T,D>& d0) {
                                std::copy(d0.v, d0.v+D, v); }

                        // iterator support
                        iterator begin() {
                                return v; }
                        const_iterator begin() const {
                                return v; }
                        iterator end() {
                                return v+D; }
                        const_iterator end() const {
                                return v+D; }

                        // base type transformation
                        template<typename U> diag(diag<U,D> const& d0) {
                                std::copy(d0.begin(), d0.end(), v); }

                        // reverse iterator support
                        typedef std::reverse_iterator<iterator>
                                                reverse_iterator;
                        typedef std::reverse_iterator<const_iterator>
                                                const_reverse_iterator;

                        reverse_iterator rbegin() {
                                return reverse_iterator(end()); }
                        const_reverse_iterator rbegin() const {
                                return const_reverse_iterator(end()); }
                        reverse_iterator rend() {
                                return reverse_iterator(begin()); }
                        const_reverse_iterator rend() const {
                                return const_reverse_iterator(begin()); }

                        // operator[]
                        reference operator[](size_type i) {
                                return v[i]; }
                        const_reference operator[](size_type i) const {
                                return v[i]; }

                        // at() with range check
                        reference at(size_type i) {
                                rangecheck(i); return v[i]; }
                        const_reference at(size_type i) const {
                                rangecheck(i); return v[i]; }

                        // matrix addition and assignment
                        template<typename U>
                        diag<T,D>& operator=(diag<U,D> const& d) {
                                std::copy(d.begin(),d.end(),v); return *this; }
                        template<typename U>
                        diag<T,D>& operator+=(diag<U,D> const& d) {
                                U const* j=d.begin();
                                for (T* i=v; i!=v+D; ++i, ++j )
                                        *i += *j; return *this; }
                        template<typename U>
                        diag<T,D>& operator-=(diag<U,D> const& d) {
                                U const* j=d.begin();
                                for (T* i=v; i!=v+D; ++i, ++j )
                                        *i -= *j; return *this; }

                        // scalar multiplication
                        template<typename U>
                        diag<T,D>& operator*=(U const& c) {
                                for (T *i=v; i!=v+D; ++i)
                                        *i *= c; return *this; }
                        template<typename U>
                        diag<T,D>& operator/=(U const& c) {
                                for (T *i=v; i!=v+D; ++i)
                                        *i /= c; return *this; }
                        template<typename U>
                        diag<T,D>& operator%=(U const& c) {
                                for (T *i=v; i!=v+D; ++i)
                                        *i %= c; return *this; }

                        // matrix product
                        template<typename U>
                        diag<T,D>& operator*=(diag<U,D> const& d) {
                                U const* j=d.begin();
                                for (T* i=v; i!=v+D; ++i, ++j )
                                        *i *= *j; return *this; }
                        template<typename U>
                        diag<T,D>& operator/=(diag<U,D> const& d) {
                                U const* j=d.begin();
                                for (T* i=v; i!=v+D; ++i, ++j )
                                        *i /= *j; return *this; }
                        template<typename U>
                        diag<T,D>& operator%=(diag<U,D> const& d) {
                                U const* j=d.begin();
                                for (T* i=v; i!=v+D; ++i, ++j )
                                        *i %= *j; return *this; }

                        // equality
                        template<typename U>
                        bool operator==(diag<U,D> const& d) const {
                                U const* j=d.begin();
                                for (T const* i=v; i!=v+D; ++i, ++j )
                                        if ( ! (*i == *j) )
                                                return false;
                                return true; }
                        template<typename U>
                        bool operator!=(diag<U,D> const& d) const {
                                U const* j=d.begin();
                                for (T const* i=v; i!=v+D; ++i, ++j )
                                        if ( ! (*i != *j) )
                                                return false;
                                return true; }

                        // fold, map, join and friends
                        template<typename UnaryFunction>
                        UnaryFunction& foreach(UnaryFunction& fn) const {
                                for (T const* i=v; i!=v+D; ++i)
                                        fn(*i); return fn; }

                        template<typename UnaryFunction>
                        UnaryFunction& foreach(UnaryFunction& fn) {
                                for (T *i=v; i!=v+D; ++i)
                                        fn(*i); return fn; }

                        template<typename UnaryFunction, typename U>
                        UnaryFunction& map(diag<U,D> const& x,
                                UnaryFunction& fn) {
                                U const* j=x.begin();
                                for (T *i=v; i!=v+D; ++i, ++j)
                                        *i = fn(*j); return fn; }

                        template<typename BinaryFunction,typename U,typename V>
                        BinaryFunction& join(diag<U,D> const& x,
                                diag<V,D> const& y, BinaryFunction& fn) {
                                U const* j=x.begin(); V const* k=y.begin();
                                for (T *i=v; i!=v+D; ++i, ++j, ++k)
                                        *i = fn(*j, *k); return fn; }

                        template<typename BinaryFunction>
                        typename BinaryFunction::result_type fold(
                                BinaryFunction const& fn = BinaryFunction(),
                                typename BinaryFunction::result_type const&
                                c0 = typename BinaryFunction::result_type()) {
                                for (T *i=v; i!=v+D; ++i)
                                        c0 = fn(*i, c0); return c0; }
        };


        // foreach
        template<
                typename UnaryFunction,
                typename T, unsigned int D
        > inline
        UnaryFunction foreach(diag<T,D> const& x,
                UnaryFunction fn = UnaryFunction()) {
                x.foreach(fn); return fn; }

        // map
        template<
                typename UnaryFunction,
                typename T, unsigned int D
        > inline
        diag<typename UnaryFunction::result_type,D> map(diag<T,D> const& x,
                UnaryFunction const& fn = UnaryFunction()) {
                diag<typename UnaryFunction::result_type,D> tmp;
                tmp.map(x, fn); return tmp;
        }

        // join
        template<
                typename BinaryFunction,
                typename T, unsigned int D, typename U
        > inline
        diag<typename BinaryFunction::result_type,D> join(
                diag<T,D> const& x, diag<U,D> const& y,
                BinaryFunction const& fn = BinaryFunction()) {
                diag<typename BinaryFunction::result_type,D> tmp;
                tmp.join(x, y, fn); return tmp;
        }


        // unary forall
        template<typename Predicate, typename T, unsigned int D> inline
        bool forall(diag<T,D> const& x, Predicate const& fn = Predicate()) {
                for (T const* i = x.begin(); i != x.end(); ++i)
                        if ( ! fn(*i) ) return false;
                return true; }

        // binary forall
        template<
                typename BinaryPredicate,
                typename T, unsigned int D, typename U
        > inline
        bool forall(diag<T,D> const& x, diag<U,D> const& y,
                BinaryPredicate const& fn = BinaryPredicate()) {
                U* j=y.begin(); for (T* i=x.begin(); i != x.end(); ++i, ++j )
                        if ( ! fn(*i, *j) ) return false;
                return true; }

        // fold
        template<typename BinaryFunction, typename T, unsigned int D> inline
        typename BinaryFunction::result_type fold(diag<T,D> const& x,
                BinaryFunction const& fn = BinaryFunction() ) {
                T const* i = x.begin();
                typename BinaryFunction::result_type c0 = *i;
                for ( ++i; i != x.end(); ++i)
                        c0 = fn(*i, c0);
                return c0; }


        // a diagonal matrix can have a norm
        template<typename Norm, typename T, unsigned int D> inline
        typename Norm::result_type norm(diag<T,D> const& x,
                Norm const& fn = Norm()) {
                T const* i = x.begin();
                typename Norm::result_type c0 = fn(*i);
                for ( ++i; i != x.end(); ++i)
                        c0 = fn(fn(*i), c0);
                return c0; }

        template<unsigned int N, unsigned int D, typename T> inline
        typename pNorm<N,T>::result_type pnorm(diag<T,D> const& v) {
                return norm(v, pNorm<N,T>()); }


        // wrappers to allow template parameter deduction
        template<
                template <class> class UnaryFunction,
                typename T, unsigned int D
        > inline
        diag<typename UnaryFunction<T>::result_type,D>
        map(diag<T,D> const& x) {
                return map(x, UnaryFunction<T>()); }


        template<
                template <class> class BinaryFunction,
                typename T, unsigned int D, typename U
        > inline
        diag<typename BinaryFunction<T>::result_type,D>
        join(diag<T,D> const& x, diag<U,D> const& y) {
                return join(x, y, BinaryFunction<T>()); }

        template<
                template <class, class> class BinaryFunction,
                typename T, unsigned int D, typename U
        > inline
        diag<typename BinaryFunction<T,U>::result_type,D>
        join(diag<T,D> const& x, diag<U,D> const& y) {
                return join(x, y, BinaryFunction<T,U>()); }


        template<
                template <class> class Predicate,
                typename T, unsigned int D
        > inline
        bool forall(diag<T,D> const& x) {
                return forall(x, Predicate<T>()); }


        template<
                template <class> class BinaryPredicate,
                typename T, unsigned int D, typename U
        > inline
        bool forall(diag<T,D> const& x, diag<U,D> const& y) {
                return forall(x, y, BinaryPredicate<T>()); }

        template<
                template <class, class> class BinaryPredicate,
                typename T, unsigned int D, typename U
        > inline
        bool forall(diag<T,D> const& x, diag<U,D> const& y) {
                return forall(x, y, BinaryPredicate<T,U>()); }


        template<
                template <class> class BinaryFunction,
                typename T, unsigned int D
        > inline
        typename BinaryFunction<T>::result_type fold(diag<T,D> const& x) {
                return fold(x, BinaryFunction<T>()); }

        template<
                template <class, class> class BinaryFunction,
                typename T, unsigned int D
        > inline
        typename BinaryFunction<T,T>::result_type fold(diag<T,D> const& x) {
                return fold(x, BinaryFunction<T,T>()); }


        template<
                template <class> class Norm,
                typename T, unsigned int D
        > inline
        typename Norm<T>::result_type norm(diag<T,D> const& x) {
                return norm(x, Norm<T>()); }


        // transformations
        template<typename T, unsigned int D> inline
                vec<T,D> vector(diag<T,D> const& d) {
                        vec<T,D> tmp; tmp.map(d.begin()); return tmp; }

        template<typename T, unsigned int D> inline
                diag<T,D> diagonal(vec<T,D> const& v) {
                        diag<T,D> tmp; v.copy(tmp.begin()); return tmp; }

#ifndef EUCLID_USE_TYPE_TRAITS

        // additive operators
        template<typename T, unsigned int D> inline
                diag<T,D> operator-(diag<T,D> const& x) {
                        return diag<T,D>() -= x; }

        template<typename T, unsigned int D, typename U> inline
                diag<T,D> operator+(diag<T,D> x, diag<U,D> const& y) {
                        return x += y; }

        template<typename T, unsigned int D, typename U> inline
                diag<T,D> operator-(diag<T,D> x, diag<U,D> const& y) {
                        return x -= y; }

        // scalar multiplication
        template<typename T, unsigned int D, typename U> inline
                diag<T,D> operator*(U const& x, diag<T,D> y) {
                        return y *= x; }

        template<typename T, unsigned int D, typename U> inline
                diag<T,D> operator*(diag<T,D> x, U const& y) {
                        return x *= y; }

        template<typename T, unsigned int D, typename U> inline
                diag<T,D> operator/(diag<T,D> x, U const& y) {
                        return x /= y; }

        template<typename T, unsigned int D, typename U> inline
                diag<T,D> operator%(diag<T,D> x, U const& y) {
                        return x %= y; }


        // matrix multiplication
        template<typename T, unsigned int D, typename U> inline
                diag<T,D> operator*(diag<T,D> x, diag<U,D> const& y) {
                        return x *= y; }

        template<typename T, unsigned int D, typename U> inline
                diag<T,D> operator/(diag<T,D> x, diag<U,D> const& y) {
                        return x /= y; }

        template<typename T, unsigned int D, typename U> inline
                diag<T,D> operator%(diag<T,D> x, diag<U,D> const& y) {
                        return x %= y; }


        // vector multiplication
        template<typename T, unsigned int D, typename U> inline
                vec<T,D> operator*(diag<T,D> x, vec<U,D> const& y) {
                        return euclid::vector(x *= diagonal(y)); }

        template<typename T, unsigned int D, typename U> inline
                vec<T,D> operator*(vec<T,D> const& x, diag<U,D> const& y) {
                        return euclid::vector(diagonal(x) *= y); }

        template<typename T, unsigned int D, typename U> inline
                vec<T,D> operator/(vec<T,D> const& x, diag<U,D> const& y) {
                        return euclid::vector(diagonal(x) /= y); }

        template<typename T, unsigned int D, typename U> inline
                vec<T,D> operator%(vec<T,D> const& x, diag<U,D> const& y) {
                        return euclid::vector(diagonal(x) %= y); }

#else

        // additive operators
        template<typename T, unsigned int D>
                inline diag<typename unary<T>::minus::type,D>
                        operator-(diag<T,D> const& x) {
                                return diag<typename unary<T>::minus::type,D>
                                        () -= x; }

        template<typename T, unsigned int D, typename U>
                inline diag<typename binary<T,U>::add::type,D>
                        operator+(diag<T,D> const& x, diag<U,D> const& y) {
                                return diag<typename binary<T,U>::add::type,D>
                                        (x) += y; }

        template<typename T, unsigned int D, typename U>
                inline diag<typename binary<T,U>::sub::type,D>
                        operator-(diag<T,D> const& x, diag<U,D> const& y) {
                                return diag<typename binary<T,U>::sub::type,D>
                                        (x) -= y; }

        // scalar multiplication
        template<typename T, unsigned int D, typename U>
                inline diag<typename binary<T,U>::mul::type,D>
                        operator*(T const& x, diag<U,D> const& y) {
                                return diag<typename binary<T,U>::mul::type,D>
                                        (y) *= x; }

        template<typename T, unsigned int D, typename U>
                inline diag<typename binary<T,U>::mul::type,D>
                        operator*(diag<T,D> const& x, U const& y) {
                                return diag<typename binary<T,U>::mul::type,D>
                                        (x) *= y; }

        template<typename T, unsigned int D, typename U>
                inline diag<typename binary<T,U>::div::type,D>
                        operator/(diag<T,D> const& x, U const& y) {
                                return diag<typename binary<T,U>::div::type,D>
                                        (x) /= y; }

        template<typename T, unsigned int D, typename U>
                inline diag<typename binary<T,U>::mod::type,D>
                        operator%(diag<T,D> const& x, U const& y) {
                                return diag<typename binary<T,U>::mod::type,D>
                                        (x) %= y; }

        // matrix multiplication
        template<typename T, unsigned int D, typename U>
                inline diag<typename binary<T,U>::mul::type,D>
                        operator*(diag<T,D> const& x, diag<U,D> const& y) {
                                return diag<typename binary<T,U>::mul::type,D>
                                        (x) *= y; }

        template<typename T, unsigned int D, typename U>
                inline diag<typename binary<T,U>::div::type,D>
                        operator/(diag<T,D> const& x, diag<U,D> const& y) {
                                return diag<typename binary<T,U>::div::type,D>
                                        (x) /= y; }

        template<typename T, unsigned int D, typename U>
                inline diag<typename binary<T,U>::mod::type,D>
                        operator%(diag<T,D> const& x, diag<U,D> const& y) {
                                return diag<typename binary<T,U>::mod::type,D>
                                        (x) %= y; }


        // these traits are needed for operator@(vec<T,D> const& x, U& y)
        // in vector.h if U matches diag<U,D>; the operators are overloaded
        // for this case by the following definitions, so the types in
        // here are never really used, however, it seems the compiler
        // needs to deduce the return type even if it finds a better match,
        // so these traits are here merely here to keep the compiler happy

        template<typename T, typename U, unsigned int D>
        struct binary<T, diag<U,D> >
        {
                struct add { typedef typeof(T()+U()) type; };
                struct sub { typedef typeof(T()-U()) type; };
                struct mul { typedef typeof(T()*U()) type; };
                struct div { typedef typeof(T()/U(1)) type; };
                struct mod { typedef typeof(T()%U(1)) type; };
        };

        // vector multiplication
        template<typename T, unsigned int D, typename U>
                inline vec<typename binary<T,U>::mul::type,D>
                        operator*(vec<T,D> const& x, diag<U,D> const& y) {
                                typedef typename binary<T,U>::mul::type type;
                                return euclid::vector(diagonal(vec<type,D>(x)) *= y); }

        template<typename T, unsigned int D, typename U>
                inline vec<typename binary<T,U>::div::type,D>
                        operator/(vec<T,D> const& x, diag<U,D> const& y) {
                                typedef typename binary<T,U>::mul::type type;
                                return euclid::vector(diagonal(vec<type,D>(x)) /= y); }

        template<typename T, unsigned int D, typename U>
                inline vec<typename binary<T,U>::mod::type,D>
                        operator%(vec<T,D> const& x, diag<U,D> const& y) {
                                typedef typename binary<T,U>::mul::type type;
                                return euclid::vector(diagonal(vec<type,D>(x)) %= y); }

        // still vector multiplication
        template<typename T, unsigned int D, typename U>
                inline vec<typename binary<T,U>::mul::type,D>
                        operator*(diag<T,D> const& x, vec<U,D> const& y) {
                                typedef typename binary<T,U>::mul::type type;
                                return euclid::vector(diag<type,D>(x) *= diagonal(y));}

#endif  // EUCLID_USE_TYPE_TRAITS

}  // namespace euclid


#endif  // EUCLID_DIAGONAL_HPP
