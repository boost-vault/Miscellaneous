//  IO declarations for the Euclid class templates.

//  Copyright (C) 2004-2009
//  Andreas Harnack (ah8 at freenet dot de)
//  version 0.0.4

//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.

//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.

//  You should have received a copy of the GNU General Public License along
//  with this program; if not, write to the Free Software Foundation, Inc.,
//  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.


#ifndef EUCLID_EUCLID_HPP
#define EUCLID_EUCLID_HPP

#include <iostream>
#include "euclid/dimension.hpp"
#include "euclid/vector.hpp"
#include "euclid/norm.hpp"
#include "euclid/diagonal.hpp"
#include "euclid/matrix.hpp"
#include "euclid/cuboid.hpp"


namespace euclid
{
        // print a dimension
        template<typename T, unsigned int D, typename Char, class Traits>
        inline std::basic_ostream<Char, Traits>& operator<<(
                std::basic_ostream<Char, Traits>& os,
                const dim<T,D>& d) {
                return os << d(); }

        // print a vector
        template<typename T, unsigned int D, typename Char, class Traits>
        inline std::basic_ostream<Char, Traits>& operator<<(
                std::basic_ostream<Char, Traits>& os, vec<T,D> const& v) {
                return v.template print<Char, Traits>(os << '(') << ')'; }

        template<typename T, unsigned int D>
        template <typename Char, class Traits>
        inline std::basic_ostream<Char, Traits>& vec<T,D>::print(
                std::basic_ostream<Char, Traits>& os) const {
                return v.template print<Char, Traits>(os) << ',' << d; }

        template<typename T>
        template<typename Char, class Traits> inline
        std::basic_ostream<Char, Traits>& vec<T,1>::print(
                std::basic_ostream<Char, Traits>& os) const {
                return os << d; }

        // print a diagonal matrix
        template<
                typename T, unsigned int D,
                typename Char, class Traits
        > inline
        std::basic_ostream<Char, Traits>& operator<<(
                std::basic_ostream<Char, Traits>& os, diag<T,D> const& d) {
                T const* i=d.begin();
                os << '<' << *i; for ( ++i; i!=d.end(); ++i)
                        os << ',' << *i; return os << '>'; }

        // print a diagonal matrix
        template<
                typename T,unsigned int M, unsigned int N,
                typename Char, class Traits
        > inline
        std::basic_ostream<Char, Traits>& operator<<(
                std::basic_ostream<Char, Traits>& os, matrix<T,M,N> const& m) {
                os << '[' << m[0][0];
                for ( unsigned j=1; j<N; ++j )
                        os << ',' << m[0][j];
                for ( unsigned i=1; i<M; ++i ) {
                        os << '|' << m[i][0];
                        for ( unsigned j=1; j<N; ++j )
                                os << ',' << m[i][j];
                }
                return os << ']'; }

}  // namespace euclid


#endif  // EUCLID_EUCLID_HPP
