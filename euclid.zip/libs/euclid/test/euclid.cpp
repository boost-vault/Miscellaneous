//  Test cases for the Euclid library.

//  Copyright (C) 2004-2009
//  Andreas Harnack (ah8 at freenet dot de)
//  version 0.0.4

//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.

//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.

//  You should have received a copy of the GNU General Public License along
//  with this program; if not, write to the Free Software Foundation, Inc.,
//  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.


#include <functional>
#include <iostream>
#include <complex>
#include <cmath>
#include "euclid.hpp"
#include "euclid/cuboid.hpp"


using namespace euclid;


#define CHECK(X) std::cout << #X ":  \t" << (X) << std::endl;

#ifdef PRINT_TYPES
#define CHECK_TYPE(X) std::cout << #X ":  \t" << (X) << '\t' << type_name<typeof(X)>() << std::endl;
#else
#define CHECK_TYPE(X) CHECK(X)
#endif


//template<class T> struct print : public std::unary_function<T, void>
struct print
{
        std::ostream& os; int count;
        print() : os(std::cout), count(0) {}
        print(std::ostream& out) : os(out), count(0) {}
        print(print const& p) : os(p.os), count(p.count) {}
//      ~print() { os << std::endl; }
        template<class T>
        void operator()(T const& x) { os << '(' << x << ')'; ++count; }
};

// traits to print type names
template<typename T> struct type_name {
        operator const char*() { return "unknown"; } };

template<> struct type_name<int> {
        operator const char*() { return "int"; } };
template<> struct type_name<double> {
        operator const char*() { return "double"; } };
template<> struct type_name< std::complex<double> > {
        operator const char*() { return "complex<double>"; } };

template<typename T, unsigned int D> struct type_name< dim<T,D> > {
        operator const char*() { return "dim<T,D>"; } };

template<typename T, unsigned int D> struct type_name< vec<T,D> > {
        operator const char*() { return "vec<T,D>"; } };

template<typename T, unsigned int D> struct type_name< diag<T,D> > {
        operator const char*() { return "diag<T,D>"; } };


template<unsigned int D> struct type_name< dim<int,D> > {
        operator const char*() { return "dim<int,D>"; } };
template<unsigned int D> struct type_name< dim<double,D> > {
        operator const char*() { return "dim<double,D>"; } };
template<unsigned int D> struct type_name< dim< std::complex<double>,D>  > {
        operator const char*() { return "dim< std::complex<double>,D>"; } };

template<> struct type_name< dim<int,0> > {
        operator const char*() { return "dim<int,0>"; } };
template<> struct type_name< dim<double,0> > {
        operator const char*() { return "dim<double,0>"; } };
template<> struct type_name< dim< std::complex<double>,0>  > {
        operator const char*() { return "dim< std::complex<double>,0>"; } };

template<> struct type_name< dim<int,1> > {
        operator const char*() { return "dim<int,1>"; } };
template<> struct type_name< dim<double,1> > {
        operator const char*() { return "dim<double,1>"; } };
template<> struct type_name< dim< std::complex<double>,1>  > {
        operator const char*() { return "dim< std::complex<double>,1>"; } };

template<> struct type_name< dim<int,2> > {
        operator const char*() { return "dim<int,2>"; } };
template<> struct type_name< dim<double,2> > {
        operator const char*() { return "dim<double,2>"; } };
template<> struct type_name< dim< std::complex<double>,2>  > {
        operator const char*() { return "dim< std::complex<double>,2>"; } };


template<unsigned int D> struct type_name< vec<int,D> > {
        operator const char*() { return "vec<int,D>"; } };
template<unsigned int D> struct type_name< vec<double,D> > {
        operator const char*() { return "vec<double,D>"; } };
template<unsigned int D> struct type_name< vec< std::complex<double>,D>  > {
        operator const char*() { return "vec< std::complex<double>,D>"; } };

template<> struct type_name< vec<int,1> > {
        operator const char*() { return "vec<int,1>"; } };
template<> struct type_name< vec<double,1> > {
        operator const char*() { return "vec<double,1>"; } };
template<> struct type_name< vec< std::complex<double>,1>  > {
        operator const char*() { return "vec< std::complex<double>,1>"; } };

template<> struct type_name< vec<int,2> > {
        operator const char*() { return "vec<int,2>"; } };
template<> struct type_name< vec<double,2> > {
        operator const char*() { return "vec<double,2>"; } };
template<> struct type_name< vec< std::complex<double>,2>  > {
        operator const char*() { return "vec< std::complex<double>,2>"; } };

template<> struct type_name< vec<int,3> > {
        operator const char*() { return "vec<int,3>"; } };
template<> struct type_name< vec<double,3> > {
        operator const char*() { return "vec<double,3>"; } };
template<> struct type_name< vec< std::complex<double>,3>  > {
        operator const char*() { return "vec< std::complex<double>,3>"; } };


template<unsigned int D> struct type_name< diag<int,D> > {
        operator const char*() { return "diag<int,D>"; } };
template<unsigned int D> struct type_name< diag<double,D> > {
        operator const char*() { return "diag<double,D>"; } };
template<unsigned int D> struct type_name< diag< std::complex<double>,D>  > {
        operator const char*() { return "diag< std::complex<double>,D>"; } };

template<> struct type_name< diag<int,1> > {
        operator const char*() { return "diag<int,1>"; } };
template<> struct type_name< diag<double,1> > {
        operator const char*() { return "diag<double,1>"; } };
template<> struct type_name< diag< std::complex<double>,1>  > {
        operator const char*() { return "diag< std::complex<double>,1>"; } };

template<> struct type_name< diag<int,2> > {
        operator const char*() { return "diag<int,2>"; } };
template<> struct type_name< diag<double,2> > {
        operator const char*() { return "diag<double,2>"; } };
template<> struct type_name< diag< std::complex<double>,2>  > {
        operator const char*() { return "diag< std::complex<double>,2>"; } };

template<> struct type_name< diag<int,3> > {
        operator const char*() { return "diag<int,3>"; } };
template<> struct type_name< diag<double,3> > {
        operator const char*() { return "diag<double,3>"; } };
template<> struct type_name< diag< std::complex<double>,3>  > {
        operator const char*() { return "diag< std::complex<double>,3>"; } };


// traits to select init values
template<typename T> struct init_val { static int val[]; };
template<typename T> int init_val<T>::val[] = { 1, 2, 3, 4 };

template<> struct init_val<int> { static int val[]; };
int init_val<int>::val[] = { 2, 3, 4, 5, 6  };

template<> struct init_val<double> { static double val[]; };
double init_val<double>::val[] = { 1.2, 2.3, 3.4 };

template<> struct init_val< std::complex<double> > { static double val[]; };
double init_val< std::complex<double> >::val[] = { 1.2, 2.3, 3.4 };

template<typename T> T init(int i)
{
        int array_size = sizeof(init_val<T>::val)/sizeof(*init_val<T>::val);
        while ( i<0 )
                i+=array_size;
        while ( i>=array_size )
                i-=array_size;
        return init_val<T>::val[i];
}


// some operators are undefined for some base types,
// traits to exclude undefined operations

// modulo defined only for integers
template<typename T, unsigned int D, typename U> struct dim_mod_assign_test
{
        dim_mod_assign_test (dim<T,D>& x) {}
};

template<unsigned int D, typename U> struct dim_mod_assign_test<int,D,U>
{
        dim_mod_assign_test(dim<int,D>& x0) {
                CHECK( x0 %= init<U>(D) )
        }
};


template<typename T, unsigned int D, typename U> struct dim_mod_operator_test
{
        dim_mod_operator_test(dim<T,D> const&, dim<U,D> const&) {}
};

template<unsigned int D> struct dim_mod_operator_test<int,D,int>
{
        dim_mod_operator_test(dim<int,D> const& x, dim<int,D> const& y) {
                CHECK_TYPE( x%y() )
        }
};


template<typename T, unsigned int D, typename U> struct vec_mod_assign_test
{
        vec_mod_assign_test (vec<T,D>&, U const&) {}
};

template<unsigned int D> struct vec_mod_assign_test<int,D,int>
{
        vec_mod_assign_test(vec<int,D>& vx, int const& cx) {
                CHECK( vx %= cx )
        }
};


template<typename T, unsigned int D, typename U> struct vec_mod_operator_test
{
        vec_mod_operator_test(vec<T,D> const&, U const&) {}
};

template<unsigned int D> struct vec_mod_operator_test<int,D,int>
{
        vec_mod_operator_test(vec<int,D> const& x, int const& y) {
                CHECK_TYPE( x%y )
        }
};


template<typename T, unsigned int D, typename U> struct diag_mod_assign_test
{
        diag_mod_assign_test (diag<T,D>&, diag<U,D> const&) {}
        diag_mod_assign_test (diag<T,D>&, U const&) {}
};

template<unsigned int D> struct diag_mod_assign_test<int,D,int>
{
        diag_mod_assign_test(diag<int,D>& d0, int const& c) {
                CHECK( d0 %= c )
        }
        diag_mod_assign_test(diag<int,D>& d0, diag<int,D> const& d1) {
                CHECK( d0 %= d1 )
        }
};


template<typename T, unsigned int D, typename U> struct diag_mod_operator_test
{
        diag_mod_operator_test(diag<T,D>&, U const&) {}
        diag_mod_operator_test(diag<T,D>&, diag<U,D> const&) {}
        diag_mod_operator_test(diag<T,D>&, vec<U,D> const&) {}
        diag_mod_operator_test(vec<T,D>&, diag<U,D> const&) {}
};

template<unsigned int D> struct diag_mod_operator_test<int,D,int>
{
        diag_mod_operator_test(diag<int,D> const& x, int const& c) {
                CHECK_TYPE( x%c )
        }
        diag_mod_operator_test(diag<int,D> const& x, diag<int,D> const& y) {
                CHECK_TYPE( x%y )
        }
        diag_mod_operator_test(diag<int,D> const& x, vec<int,D> const& vy) {
                CHECK_TYPE( x%vy )
        }
        diag_mod_operator_test(vec<int,D> const& vx, diag<int,D> const& y) {
                CHECK_TYPE( vx%y )
        }
};


// no relational operators for complex
template<typename T, unsigned int D, typename U>
        struct dim_relational_operator_test
{
        dim_relational_operator_test (
                dim<U,D> const& x, dim<T,D> const& x0, dim<T,D> const& x1)
        {
                CHECK( x0 == x )
                CHECK( x0 != x )
                CHECK( x0 == x0 )
                CHECK( x0 != x0 )
                CHECK( x0 == x1 )
                CHECK( x0 != x1 )
                std::cout << std::endl;
                CHECK( x0 < x )
                CHECK( x0 > x )
                CHECK( x0 <= x )
                CHECK( x0 >= x )
                std::cout << std::endl;
                CHECK( x0 < x0 )
                CHECK( x0 > x0 )
                CHECK( x0 <= x0 )
                CHECK( x0 >= x0 )
                std::cout << std::endl;
                CHECK( x0 < x1 )
                CHECK( x0 > x1 )
                CHECK( x0 <= x1 )
                CHECK( x0 >= x1 )
        }
};

template<unsigned int D, typename U>
        struct dim_relational_operator_test< std::complex<double>, D, U>
{
        dim_relational_operator_test (
                dim<U,D> const& x,
                dim<std::complex<double>,D> const& x0,
                dim<std::complex<double>,D> const& x1)
        {
                std::cout << "... skipped ..." << std::endl;
        }
};


template<typename T, unsigned int D, typename U>
        struct vec_relational_operator_test
{
        vec_relational_operator_test (vec<U,D> v, vec<T,D> v0, vec<T,D> v1)
        {
                CHECK_TYPE( (v) )
                CHECK_TYPE( (v0) )
                CHECK_TYPE( (v1) )
                std::cout << std::endl;
//              CHECK_TYPE( map(v0,euclid::Power<1,T>()) )
//              CHECK_TYPE( map(v0,euclid::Power<2,T>()) )
//              CHECK_TYPE( map(v0,euclid::Power<3,T>()) )
//              CHECK_TYPE( map(v0,euclid::Power<4,T>()) )
//              CHECK_TYPE( map(v0,euclid::Power<5,T>()) )
//              CHECK_TYPE( map(v0,euclid::Power<6,T>()) )
//              CHECK_TYPE( map(v0,euclid::Power<7,T>()) )
//              CHECK_TYPE( map(v0,euclid::Power<8,T>()) )
                CHECK_TYPE( norm(v0, pNorm<1,T>()) )
                CHECK_TYPE( norm(v0, pNorm<2,T>()) )
                CHECK_TYPE( norm(v0, pNorm<0,T>()) )
//              CHECK_TYPE( norm< euclid::abs >(v0) )
//              CHECK_TYPE( norm< euclid::min >(v0) )
//              CHECK_TYPE( norm< euclid::max >(v0) )
                std::cout << std::endl;
                CHECK_TYPE( inf(v0,v1) )
                CHECK_TYPE( sup(v0,v1) )
                std::cout << std::endl;
                CHECK( v0 == v )
                CHECK( v0 != v )
                CHECK( v0 == v0 )
                CHECK( v0 != v0 )
                CHECK( v0 == v1 )
                CHECK( v0 != v1 )
                std::cout << std::endl;
                CHECK( forall <std::less>          (v0,v) )
                CHECK( forall <std::greater>       (v0,v) )
                CHECK( forall <std::less_equal>    (v0,v) )
                CHECK( forall <std::greater_equal> (v0,v) )
                std::cout << std::endl;
                CHECK( forall <std::less>          (v0,v0) )
                CHECK( forall <std::greater>       (v0,v0) )
                CHECK( forall <std::less_equal>    (v0,v0) )
                CHECK( forall <std::greater_equal> (v0,v0) )
                std::cout << std::endl;
                CHECK( forall <std::less>          (v0,v1) )
                CHECK( forall <std::greater>       (v0,v1) )
                CHECK( forall <std::less_equal>    (v0,v1) )
                CHECK( forall <std::greater_equal> (v0,v1) )
                std::cout << std::endl;
                CHECK( forall <euclid::positive>     (v0) )
                CHECK( forall <euclid::negative>     (v0) )
                CHECK( forall <euclid::not_negative> (v0) )
                CHECK( forall <euclid::not_positive> (v0) )
                std::cout << std::endl;
        }
};

template<unsigned int D, typename U>
        struct vec_relational_operator_test< std::complex<double>, D, U>
{
        vec_relational_operator_test(vec<U,D>,
                vec<std::complex<double>,D>, vec<std::complex<double>,D>)
        {
                std::cout << "... skipped ..." << std::endl;
        }
};


template<typename T, typename U, unsigned int D, unsigned int I>
        struct vec_norm_test
{
        vec_norm_test(vec<T,D> const& x0, vec<U,D> const& y, dim<T,I> const& c0) {}
};

template<typename T, unsigned int D, unsigned int I>
        struct vec_norm_test<T,T,D,I>
{
        vec_norm_test(vec<T,D> const& x0, vec<T,D> const& y, dim<T,I> const& c0)
        {
                CHECK_TYPE( norm(x0+c0, pNorm<1,T>()) )
                CHECK_TYPE( norm(x0+c0, pNorm<2,T>()) )
                CHECK_TYPE( norm(x0+c0, pNorm<0,T>()) )
                CHECK_TYPE( norm(x0-c0, pNorm<1,T>()) )
                CHECK_TYPE( norm(x0-c0, pNorm<2,T>()) )
                CHECK_TYPE( norm(x0-c0, pNorm<0,T>()) )
//              CHECK_TYPE( norm< euclid::abs >(x0+c0) )
//              CHECK_TYPE( norm< euclid::min >(x0+c0) )
//              CHECK_TYPE( norm< euclid::max >(x0+c0) )
//              CHECK_TYPE( norm< euclid::abs >(x0-c0) )
//              CHECK_TYPE( norm< euclid::min >(x0-c0) )
//              CHECK_TYPE( norm< euclid::max >(x0-c0) )
                std::cout << std::endl;
                CHECK_TYPE( inf(x0+c0,y) )
                CHECK_TYPE( sup(x0+c0,y) )
                CHECK_TYPE( inf(x0-c0,y) )
                CHECK_TYPE( sup(x0-c0,y) )
                std::cout << std::endl;
//              CHECK_TYPE( forall(x0+c0, std::bind2nd(std::greater<T>(),T())) )
//              CHECK_TYPE( forall(x0-c0, std::bind2nd(std::greater<T>(),T())) )
//              CHECK_TYPE( forall(y+c0, std::bind2nd(std::greater<T>(),T())) )
//              CHECK_TYPE( forall(y-c0, std::bind2nd(std::greater<T>(),T())) )
                CHECK_TYPE( forall(x0+c0, euclid::positive<T>()) )
                CHECK_TYPE( forall(x0-c0, euclid::positive<T>()) )
                CHECK_TYPE( forall<euclid::positive>(y+c0) )
                CHECK_TYPE( forall<euclid::positive>(y-c0) )
                std::cout << std::endl;
        }
};

template<unsigned int D, unsigned int I>
        struct vec_norm_test<std::complex<double>,std::complex<double>,D,I>
{
        vec_norm_test(
                vec<std::complex<double>,D> const&,
                vec<std::complex<double>,D> const&,
                dim<std::complex<double>,I> const&
        ) {}
};


// check cross product for dim=2 and dim=3
template<typename T, unsigned int D, typename U> struct test_vec_cross_product
{
        test_vec_cross_product(vec<T,D> const&) {}
};

template<typename T, typename U> struct test_vec_cross_product<T,2,U>
{
        test_vec_cross_product(vec<T,2> const& v0) {
                std::cout << std::endl;
                CHECK( v0 )
                CHECK( prod(v0) )
        }
};

template<typename T, typename U> struct test_vec_cross_product<T,3,U>
{
        test_vec_cross_product(vec<T,3> const& v0) {
                vec<U,3> v1(1);
                std::cout << std::endl;
                CHECK( v0 )
                CHECK( v1 )
                CHECK( prod(v0,v1) )
        }
};



template<typename T, unsigned int D, typename U>
        struct diag_relational_operator_test
{
        diag_relational_operator_test (diag<U,D> d, diag<T,D> d0, diag<T,D> d1)
        {
                CHECK_TYPE( (d) )
                CHECK_TYPE( (d0) )
                CHECK_TYPE( (d1) )
                std::cout << std::endl;
//              CHECK_TYPE( norm< euclid::abs >(d0) )
//              CHECK_TYPE( norm< euclid::min >(d0) )
//              CHECK_TYPE( norm< euclid::max >(d0) )
                std::cout << std::endl;
                CHECK( d0 == d )
                CHECK( d0 != d )
                CHECK( d0 == d0 )
                CHECK( d0 != d0 )
                CHECK( d0 == d1 )
                CHECK( d0 != d1 )
                std::cout << std::endl;
//              CHECK( norm< euclid::positive >(d0) )
//              CHECK( norm< euclid::negative >(d0) )
//              CHECK( norm< euclid::nonnegative >(d0) )
//              CHECK( norm< euclid::nonpositive >(d0) )
                std::cout << std::endl;
        }
};

template<unsigned int D, typename U>
        struct diag_relational_operator_test< std::complex<double>, D, U>
{
        diag_relational_operator_test(diag<U,D>,
                diag<std::complex<double>,D>, diag<std::complex<double>,D>)
        {
                std::cout << "... skipped ..." << std::endl;
        }
};



/*******************/
/* dimension tests */
/*******************/

// perform dimension tests for all D dimensions recursively
template<typename T, typename U, unsigned int D> struct test_dimensions
{
        typedef dim<T,D-1> dimD;

        test_dimensions() {
                test_dimensions<T,U,D-1>();
                std::cout
                << "###" << std::endl
                << "### test dimension for D-1=" << D-1 << std::endl
                << "###" << std::endl
                << std::endl
                ;
                std::cout << "*** init test" << std::endl;
                dimD x0;
                dimD x1(init<T>(0));
                dimD x2(init<T>(D));
                dimD x3(x2);
                std::cout << "dimD x0(): \t\t" << x0 << std::endl;
                std::cout << "dimD x1(init<T>(0)): \t" << x1 << std::endl;
                std::cout << "dimD x2(init<T>(0)): \t" << x2 << std::endl;
                std::cout << "dimD x3(x2): \t\t" << x3 << std::endl;
                std::cout << std::endl;
                std::cout << "*** type conversion test" << std::endl;
                dim<U,D-1> x(init<U>(D));
                CHECK_TYPE( ( x ) )
                CHECK_TYPE( dimD(x) )
                std::cout << std::endl;
                std::cout << "*** value access test" << std::endl;
                CHECK( x() )
                CHECK( x0() )
                CHECK( x1() )
                CHECK( x2() )
                CHECK( x3() )
                std::cout << std::endl;
                std::cout << "*** assignment operators test" << std::endl;
                CHECK( x0 = x )
                CHECK( x0 += x )
                CHECK( x0 -= x )
                std::cout << std::endl;
                CHECK( x0 = x1 )
                CHECK( x0 += x1 )
                CHECK( x0 -= x1)
                std::cout << std::endl;
                CHECK( init<int>(D-1) )
                CHECK( x0 *= init<int>(D-1) )
                CHECK( x0 /= init<int>(D-1) )
                (dim_mod_assign_test<T,D-1,int>)(x0);
                std::cout << std::endl;
                CHECK( init<T>(D) )
                CHECK( x0 *= init<T>(D) )
                CHECK( x0 /= init<T>(D) )
                (dim_mod_assign_test<T,D-1,T>)(x0);
                std::cout << std::endl;
                std::cout << "*** increment/decrement test" << std::endl;
                CHECK( x0++ )
                CHECK( ++x0 )
                CHECK( x0-- )
                CHECK( --x0 )
                std::cout << std::endl;
                std::cout << "*** relational operator test" << std::endl;
                std::cout << std::endl;
                dim_relational_operator_test<T,D-1,U>(x, x0, x1);
                std::cout << std::endl;
        }
};

template<typename T, typename U> struct test_dimensions<T,U,0>
{
        test_dimensions() {
                std::cout
                << "###" << std::endl
                << "### test dimensions of type '" << type_name<T>()
                << "' for different directions" << std::endl
                ;
        }
};


// perform dimension operator tests of types T and U
// for all D dimensions recursively
template<typename T, typename U, unsigned int D> struct test_dim_operators
{
        test_dim_operators()
        {
                test_dim_operators<T,U,D-1>();
                std::cout << std::endl;
                std::cout << "### dir D-1=" << D-1 << std::endl;
                dim<T,D-1> x(init<T>(D));
                dim<U,D-1> y(init<U>(-D));
                std::cout << "dim<T,D-1> x(init<T>(+D)): \t" << x << std::endl;
                std::cout << "dim<U,D-1> y(init<U>(-D)): \t" << y << std::endl;
                CHECK_TYPE( x )
                CHECK_TYPE( y )
                std::cout << std::endl;
                CHECK_TYPE( -x )
                CHECK_TYPE( x+y )
                CHECK_TYPE( x-y )
                std::cout << std::endl;
                CHECK_TYPE( x*y() )
                CHECK_TYPE( y()*x )
                CHECK_TYPE( x/y() )
                dim_mod_operator_test<T,D-1,U>(x,y);
                std::cout << std::endl;
                CHECK_TYPE( x*y )
                std::cout << std::endl;
        }
};

template<typename T, typename U> struct test_dim_operators<T,U,0>
{
        test_dim_operators()
        {
                std::cout
                        << "###" << std::endl
                        << "### test operators for dimensions" << std::endl
                        << "### of type T='" << type_name<T>()
                                << "' and U='" << type_name<U>()
                                << "' for different directions" << std::endl
                        << "###" << std::endl;
        }
};


/****************/
/* vector tests */
/****************/

// check access to each element of vect<S,D> recursively
template<typename T, unsigned int D, unsigned int I> struct test_vec_access
{
        test_vec_access(const char* n, const vec<T,D>& v) {
                test_vec_access<T,D,I-1>(n,v);
                std::cout  << n << "[" << I-1 << "]=" << dim<T,I-1>(v) << '\t';
        }
};

template<typename T, unsigned int D> struct test_vec_access<T,D,0>
{
        test_vec_access(const char* n, const vec<T,D>& v) {
                std::cout << "%%% test vector element access" << std::endl; }
};


// check assignment to each element of vect<T,D> recursively
template<typename T, typename U, unsigned int D, unsigned int I>
        struct test_vec_assign
{
        test_vec_assign(vec<T,D>& v0, const U& c) {
                test_vec_assign<T,U,D,I-1>(v0, c);
                std::cout << "I-1=" << I-1 << std::endl;
                CHECK( (v0 += dim<U,I-1>(c)) )
                CHECK( (v0 -= dim<U,I-1>(c)) )
                CHECK( (v0 = dim<U,I-1>(c)) )
                CHECK( (v0[dim<U,I-1>()] *= I ) )
                CHECK( (v0) )
        }
};

template<typename T, typename U, unsigned int D> struct test_vec_assign<T,U,D,0>
{
        test_vec_assign(vec<T,D>& v, const U& c) {
        }
};


// perform vector component tests for all components I recursively
template<typename T, typename U, unsigned int D, unsigned int I>
        struct test_vector_dim
{
        typedef vec<T,D> vect;
        typedef dim<T,I-1> dimI;

        test_vector_dim() {
                test_vector_dim<T,U,D,I-1>();
                std::cout << "%%% test for D=" << D;
                std::cout<< " index=" << I << std::endl;
                std::cout << std::endl;
                std::cout << "%%% init test" << std::endl;
                U               c(init<U>(I));
                T               c0(init<T>(I));
                dim<U,I-1>      d(c);
                dim<T,I-1>      d0(c0);
                vec<U,D>        v(d);
                vec<T,D>        v0(d0);
                vec<T,D>        v1(v);
                CHECK_TYPE( c )
                CHECK_TYPE( c0 )
                CHECK_TYPE( d )
                CHECK_TYPE( d0 )
                CHECK_TYPE( v )
                CHECK_TYPE( v0 )
                CHECK_TYPE( v1 )
                std::cout << std::endl;
                test_vec_access<T,D,D>("v0", v0);
                std::cout << std::endl;
                std::cout << std::endl;
                test_vec_access<T,D,D>("v1", v1);
                std::cout << std::endl;
                std::cout << std::endl;

                std::cout << "%%% assignment operators test" << std::endl;
                CHECK( v0 = v )
                CHECK( v0 += v )
                CHECK( v0 -= v )
                std::cout << std::endl;
                CHECK( v0 *= c )
                CHECK( v0 /= c )
                vec_mod_assign_test<T,D,U>(v0,c);
                std::cout << std::endl;
                CHECK( v0 = v1 )
                CHECK( v0 += v1 )
                CHECK( v0 -= v1)
                std::cout << std::endl;
                CHECK( v0 *= c0 )
                CHECK( v0 /= c0 )
                vec_mod_assign_test<T,D,T>(v0,c0);
                std::cout << std::endl;
                test_vec_assign<T,U,D,D>(v0, d());
                std::cout << std::endl;
                CHECK( v0 *= c )
                CHECK( v0 /= c )
                vec_mod_assign_test<T,D,U>(v0,c);
                std::cout << std::endl;
                CHECK( v0 *= c0 )
                CHECK( v0 /= c0 )
                vec_mod_assign_test<T,D,T>(v0,c0);
                std::cout << std::endl;
                std::cout << std::endl;
        }
};

template<typename T, typename U, unsigned int D> struct test_vector_dim<T,U,D,0>
{
        test_vector_dim() {
                std::cout << "%%% test vector components" << std::endl;
        }
};


// perform vector tests for all dimensions D recursively
template<typename T, typename U, unsigned int D> struct test_vectors
{
        typedef vec<T,D> vect;

        test_vectors() {
                test_vectors<T,U,D-1>();
                std::cout
                << "###" << std::endl
                << "### test vectors for D=" << D << std::endl
                << "###" << std::endl
                << std::endl
                ;
                std::cout << "*** init test" << std::endl;
                vect v0;
                vect v1(init<T>(0));
                vect v2(init<T>(D));
                vect v3(v2);
                std::cout << "vect v0: \t\t" << v0 << std::endl;
                std::cout << "vect v1(init<T>(0)): \t" << v1 << std::endl;
                std::cout << "vect v2(init<T>(D)): \t" << v2 << std::endl;
                std::cout << "vect v3(v2): \t\t" << v3 << std::endl;
                std::cout << std::endl;
                std::cout << "*** type conversion test" << std::endl;
                vec<U,D> v(init<U>(-D));
                CHECK_TYPE( ( v ) )
                CHECK_TYPE( vect(v) )
                std::cout << std::endl;
                test_vector_dim<T,U,D,D>();
                std::cout << "*** relational operator test" << std::endl;
                std::cout << std::endl;
                vec_relational_operator_test<T,D,U>(v, v2, v1);
                std::cout << std::endl;
        }
};

template<typename T, typename U> struct test_vectors<T,U,0>
{
        test_vectors() {
                std::cout
                << "###" << std::endl
                << "### test vectors of type '" << type_name<T>()
                        << "' for different dimensions" << std::endl
                ;
        }
};


// perform vector operator tests of types T and U
// for all D dimensions recursively
template<typename T, typename U, unsigned int D, unsigned int I>
        struct test_vec_dim_operators
{
        test_vec_dim_operators(vec<T,D> x0, vec<U,D> const& y)
        {
                test_vec_dim_operators<T,U,D,I-1>(x0,y);
                std::cout << "%%% test for I-1=" << I-1 << std::endl;
                dim<U,I-1> c(init<U>(I));
                dim<T,I-1> c0(init<T>(-I));
                CHECK_TYPE( c )
                CHECK_TYPE( y )
                CHECK_TYPE( c0 )
                CHECK_TYPE( x0 )
                std::cout << std::endl;
                CHECK_TYPE( x0+c )
                CHECK_TYPE( x0-c )
                CHECK_TYPE( x0+c0 )
                CHECK_TYPE( x0-c0 )
                std::cout << std::endl;
                CHECK_TYPE( norm(x0+c0, pNorm<2,T>()) )
                CHECK_TYPE( norm(x0-c0, pNorm<2,T>()) )
//              CHECK_TYPE( norm< euclid::mag >(x0+c0) )
//              CHECK_TYPE( norm< euclid::mag >(x0-c0) )
                (test_vec_cross_product<T,D,U>)(x0);
                (test_vec_cross_product<T,D,U>)(x0+c0);
                (test_vec_cross_product<T,D,U>)(x0-c0);
                std::cout << std::endl;
                vec_norm_test<T,U,D,I-1>(x0,y,c0);
                std::cout << std::endl;
                CHECK_TYPE( map(x0+c0, std::negate<T>()) )
                CHECK_TYPE( map(x0-c0, std::negate<T>()) )
                CHECK_TYPE( map< std::negate >(x0+c0) )
                CHECK_TYPE( map< std::negate >(x0-c0) )
                CHECK_TYPE( join(x0+c0, x0-c0, std::plus<T>()) )
                CHECK_TYPE( join< euclid::plus >(x0+c0, y-c) )
        }
};

template<typename T, typename U, unsigned int D>
        struct test_vec_dim_operators<T,U,D,0>
{
        test_vec_dim_operators(vec<T,D> const&, vec<U,D> const&)
        {
                std::cout << "%%% test vector component operators" << std::endl;
        }
};


// perform vector operator tests of types T and U
// for all D dimensions recursively
template<typename T, typename U, unsigned int D> struct test_vec_operators
{
        test_vec_operators()
        {
                test_vec_operators<T,U,D-1>();
                std::cout << "### dim D=" << D << std::endl;
                std::cout << "###" << std::endl;
                U c(init<U>(-D));
                vec<T,D> x(init<T>(D));
                const vec<U,D> y(init<U>(-D));
                std::cout << "vec<T,D> x(init<T>(+D)): \t" << x << std::endl;
                std::cout << "vec<U,D> y(init<U>(-D)): \t" << y << std::endl;
                CHECK_TYPE( foreach(x, print(std::cout)).count )
                CHECK_TYPE( foreach(y, print(std::cout)).count )
                CHECK_TYPE( foreach< print >(x).count )
                CHECK_TYPE( foreach< print >(y).count )
                CHECK_TYPE( c )
                CHECK_TYPE( x )
                CHECK_TYPE( y )
                std::cout << std::endl;
                CHECK_TYPE( -x )
                CHECK_TYPE( x+y )
                CHECK_TYPE( x-y )
                std::cout << std::endl;
                CHECK_TYPE( x*c )
                CHECK_TYPE( c*x )
                CHECK_TYPE( x/c )
                vec_mod_operator_test<T,D,U>(x,c);
                std::cout << std::endl;
                CHECK_TYPE( x*y )
                CHECK_TYPE( x.fold(std::multiplies<T>(),1) )
                CHECK_TYPE( fold<std::multiplies>(x) )
                CHECK_TYPE( norm(x, pNorm<2,T>()) )
//              CHECK_TYPE( norm< euclid::mag >(x) )
                (test_vec_cross_product<T,D,U>)(x);
                std::cout << std::endl;
                test_vec_dim_operators<T,U,D,D>(x,y);
                std::cout << std::endl;
                std::cout << std::endl;
        }
};

template<typename T, typename U> struct test_vec_operators<T,U,0>
{
        test_vec_operators()
        {
                std::cout
                        << "###" << std::endl
                        << "### test vector operators for vectors" << std::endl
                        << "### of type T='" << type_name<T>()
                                << "' and U='" << type_name<U>()
                                << "' for different dimensions" << std::endl
                        << "###" << std::endl;
        }
};



/*************************/
/* diagonal matrix tests */
/*************************/

// perform diagonal matrix component tests for all components I recursively
template<typename T, typename U, unsigned int D, unsigned int I>
        struct test_diag_dim
{
        test_diag_dim() {
                test_diag_dim<T,U,D,I-1>();
                std::cout << "%%% test for D=" << D;
                std::cout<< " index=" << I << std::endl;
                std::cout << std::endl;
                std::cout << "%%% init test" << std::endl;
                U               c(init<U>(I));
                T               c0(init<T>(-I));
                vec<U,D>        v((dim<U,I-1>(c)));
                vec<T,D>        v0((dim<T,I-1>(c0)));
                diag<U,D>       d(diagonal(v));
                diag<T,D>       d0(diagonal(v0));
                diag<T,D>       d1(c);
                CHECK_TYPE( c )
                CHECK_TYPE( c0 )
                CHECK_TYPE( d )
                CHECK_TYPE( d0 )
                CHECK_TYPE( d1 )
                std::cout << std::endl;
                std::cout << "%%% test vector element access" << std::endl;
                for ( unsigned int i=0; i<D; ++i )
                        std::cout << "d0[" << i << "]=" << d0[i] << '\t';
                std::cout << std::endl;
                std::cout << std::endl;
                std::cout << "%%% assignment operators test" << std::endl;
                CHECK( d0 = d )
                CHECK( d0 += d )
                CHECK( d0 -= d )
                std::cout << std::endl;
                CHECK( d0 *= d1 )
                CHECK( d0 /= d1 )
                diag_mod_assign_test<T,D,T>(d0,d1);
                std::cout << std::endl;
                CHECK( d0 = d1 )
                CHECK( d0 += d1 )
                CHECK( d0 -= d1)
                std::cout << std::endl;
                CHECK( d0 *= c )
                CHECK( d0 /= c )
                diag_mod_assign_test<T,D,U>(d0,c);
                std::cout << std::endl;
        }
};

template<typename T, typename U, unsigned int D> struct test_diag_dim<T,U,D,0>
{
        test_diag_dim() {
                std::cout << "%%% test diagonal matrix components" << std::endl;
        }
};


// perform diagonal matrix tests for all dimensions D recursively
template<typename T, typename U, unsigned int D> struct test_diags
{
        typedef diag<T,D> mtrx;

        test_diags() {
                test_diags<T,U,D-1>();
                std::cout
                << "###" << std::endl
                << "### test diagonal matricies for D=" << D << std::endl
                << "###" << std::endl
                << std::endl
                ;
                std::cout << "*** init test" << std::endl;
                mtrx d0;
                mtrx d1(init<T>(0));
                mtrx d2(init<T>(D));
                mtrx d3(d2);
                std::cout << "mtrx d0: \t\t" << d0 << std::endl;
                std::cout << "mtrx d1(init<T>(0)): \t" << d1 << std::endl;
                std::cout << "mtrx d2(init<T>(D)): \t" << d2 << std::endl;
                std::cout << "mtrx d3(d2): \t\t" << d3 << std::endl;
                std::cout << std::endl;
                std::cout << "*** type conversion test" << std::endl;
                diag<U,D> d(init<U>(-D));
                CHECK_TYPE( ( d ) )
                CHECK_TYPE( mtrx(d) )
                std::cout << std::endl;
                test_diag_dim<T,U,D,D>();
                std::cout << "*** relational operator test" << std::endl;
                std::cout << std::endl;
                diag_relational_operator_test<T,D,U>(d, d2, d1);
                std::cout << std::endl;
        }
};

template<typename T, typename U> struct test_diags<T,U,0>
{
        test_diags() {
                std::cout
                << "###" << std::endl
                << "### test diagonal matricies of type '" << type_name<T>()
                        << "' for different dimensions" << std::endl
                ;
        }
};


// perform matrix operator tests of types T and U
// for all D dimensions recursively
template<typename T, typename U, unsigned int D, unsigned int I>
        struct test_diag_dim_operators
{
        test_diag_dim_operators()
        {
                test_diag_dim_operators<T,U,D,I-1>();
                std::cout << "%%% test for I-1=" << I-1 << std::endl;
                dim<T,I-1> c0(init<T>(I));
                U c(init<U>(-I));
                vec<T,D>  vx(c0);
                vec<U,D>  vy(c);
                diag<T,D> x(diagonal(vx));
                diag<U,D> y(diagonal(vy));
                CHECK_TYPE( c )
                CHECK_TYPE( vx )
                CHECK_TYPE( vy )
                CHECK_TYPE( x )
                CHECK_TYPE( y )
                std::cout << std::endl;
                CHECK_TYPE( -x )
                CHECK_TYPE( x+y )
                CHECK_TYPE( x-y )
                std::cout << std::endl;
                CHECK_TYPE( x*c )
                CHECK_TYPE( c*x )
                CHECK_TYPE( x/c )
                diag_mod_operator_test<T,D,U>(x,c);
                std::cout << std::endl;
                CHECK_TYPE( x*vy )
                CHECK_TYPE( vx*y )
                CHECK_TYPE( vx/y )
                diag_mod_operator_test<T,D,U>(vx,y);
                std::cout << std::endl;
                CHECK_TYPE( x*y )
                CHECK_TYPE( x/y )
                diag_mod_operator_test<T,D,U>(x,y);
                std::cout << std::endl;
//              CHECK_TYPE( norm< euclid::mag >(x) )
                std::cout << std::endl;
        }
};

template<typename T, typename U, unsigned int D>
        struct test_diag_dim_operators<T,U,D,0>
{
        test_diag_dim_operators()
        {
                std::cout << "%%% test matrix component operators" << std::endl;
        }
};


// perform matrix operator tests of types T and U
// for all D dimensions recursively
template<typename T, typename U, unsigned int D> struct test_diag_operators
{
        test_diag_operators()
        {
                test_diag_operators<T,U,D-1>();
                std::cout << "### dim D=" << D << std::endl;
                std::cout << "###" << std::endl;
                U c(init<U>(-D));
                vec<U,D>  vy(init<U>(-D));
                vec<T,D>  vx(init<T>(D));
                diag<U,D> y(init<U>(-D));
                diag<T,D> x(init<T>(D));
                CHECK_TYPE( c )
                CHECK_TYPE( vx )
                CHECK_TYPE( vy )
                CHECK_TYPE( x )
                CHECK_TYPE( y )
                std::cout << std::endl;
                CHECK_TYPE( -x )
                CHECK_TYPE( x+y )
                CHECK_TYPE( x-y )
                std::cout << std::endl;
                CHECK_TYPE( x*c )
                CHECK_TYPE( c*x )
                CHECK_TYPE( x/c )
                diag_mod_operator_test<T,D,U>(x,c);
                std::cout << std::endl;
                CHECK_TYPE( x*vy )
                CHECK_TYPE( vx*y )
                CHECK_TYPE( vx/y )
                diag_mod_operator_test<T,D,U>(vx,y);
                std::cout << std::endl;
                CHECK_TYPE( x*y )
                CHECK_TYPE( x/y )
                diag_mod_operator_test<T,D,U>(x,y);
                std::cout << std::endl;
//              CHECK_TYPE( norm(x, pNorm<2,T>()) )
//              CHECK_TYPE( norm< euclid::mag >(x) )
                std::cout << std::endl;
                test_diag_dim_operators<T,U,D,D>();
                std::cout << std::endl;
                std::cout << std::endl;
        }
};


template<typename T, typename U> struct test_diag_operators<T,U,0>
{
        test_diag_operators()
        {
                std::cout
                        << "###" << std::endl
                        << "### test matrix operators for matricies" << std::endl
                        << "### of type T='" << type_name<T>()
                                << "' and U='" << type_name<U>()
                                << "' for different dimensions" << std::endl
                        << "###" << std::endl;
        }
};



int main()
{

#if 1
        test_dimensions<int,int,4>();
        test_dimensions<double,int,4>();
        test_dimensions<std::complex<double>,int,4>();
        test_dimensions<std::complex<double>,double,4>();
        std::cout << std::endl;
#endif

#if 1
        test_dim_operators<int,int,4>();
        test_dim_operators<double,int,4>();
        test_dim_operators<double,double,4>();
        test_dim_operators<std::complex<double>,double,4>();
        test_dim_operators<std::complex<double>,std::complex<double>,4>();
        std::cout << std::endl;
#ifdef EUCLID_USE_TYPE_TRAITS
        test_dim_operators<int,double,4>();
        test_dim_operators<double,std::complex<double>,4>();
#endif
#endif

#if 1
        test_vectors<int,int,4>();
        test_vectors<double,int,4>();
        test_vectors<std::complex<double>,int,4>();
        test_vectors<std::complex<double>,double,4>();
        std::cout << std::endl;
#endif

#if 1
        test_vec_operators<int,int,4>();
        test_vec_operators<double,int,4>();
        test_vec_operators<double,double,4>();
        test_vec_operators<std::complex<double>,double,4>();
        test_vec_operators<std::complex<double>,std::complex<double>,4>();
        std::cout << std::endl;
#ifdef EUCLID_USE_TYPE_TRAITS
        test_vec_operators<int,double,4>();
        test_vec_operators<double,std::complex<double>,4>();
#endif
#endif

#if 1
        test_diags<int,int,4>();
        test_diags<double,int,4>();
        test_diags<std::complex<double>,int,4>();
        test_diags<std::complex<double>,double,4>();
        std::cout << std::endl;
#endif

#if 1
        test_diag_operators<int,int,4>();
        test_diag_operators<double,int,4>();
        test_diag_operators<double,double,4>();
        test_diag_operators<std::complex<double>,double,4>();
        test_diag_operators<std::complex<double>,std::complex<double>,4>();
        std::cout << std::endl;
#ifdef EUCLID_USE_TYPE_TRAITS
        test_diag_operators<int,double,4>();
        test_diag_operators<double,std::complex<double>,4>();
#endif
#endif

}
