#!/bin/bash

#  FAILCHECK test script: tests if type errors are detected at compile time.

#  Copyright (C) 2004-2009
#  Andreas Harnack (ah8 at freenet dot de)
#  version 0.0.4

#  This program is free software; you can redistribute it and/or modify
#  it under the terms of the GNU General Public License as published by
#  the Free Software Foundation; either version 2 of the License, or
#  (at your option) any later version.

#  This program is distributed in the hope that it will be useful,
#  but WITHOUT ANY WARRANTY; without even the implied warranty of
#  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
#  GNU General Public License for more details.

#  You should have received a copy of the GNU General Public License along
#  with this program; if not, write to the Free Software Foundation, Inc.,
#  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.


echo
echo "trying without error emulation"

g++ -Wall -DDEBUG -I. -I../../../boost -I- -o failcheck failcheck.cpp || {
	echo;
	echo "*** ERROR: compilation doesn't succeded at all ***";
	echo;
	kill $$;
	exit 1;
}

cat failcheck.cpp | grep -e '^#ifdef' -e '^#elif' | awk '$2~/ERROR/{$1=""; print}' | while read label comment
do
	echo
	echo "trying $label:  $comment"
	g++ -Wall -D${label} -DDEBUG -I. -I../../../boost -I- -o failcheck failcheck.cpp && {
		echo;
		echo "*** ERROR: compilation succeded for $label ***";
		echo;
		kill $$;
		exit 1;
	} 
done

echo
echo "*** FAILCHECK OK ***"
echo

