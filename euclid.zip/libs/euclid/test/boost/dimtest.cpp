//  Boost dimension tests

//  Copyright (C) 2004-2009
//  Andreas Harnack (ah8 at freenet dot de)
//  version 0.0.4

//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.

//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.

//  You should have received a copy of the GNU General Public License along
//  with this program; if not, write to the Free Software Foundation, Inc.,
//  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.


#include "euclid/dimension.hpp"
#include <iostream>
#include <complex>

using namespace euclid;


#define BOOST_AUTO_TEST_MAIN
#include <boost/test/auto_unit_test.hpp>

#ifndef EUCLID_TEST_LEVEL
#define EUCLID_TEST_LEVEL 1
#endif

// traits to print type names
template<typename T> struct type {
        static const char* name() { return "unknown"; } };
template<> struct type<char> {
        static const char* name() { return "char"; } };
template<> struct type<int> {
        static const char* name() { return "int"; } };
template<> struct type<unsigned int> {
        static const char* name() { return "unsigned int"; } };
template<> struct type<long int> {
        static const char* name() { return "long int"; } };
template<> struct type<unsigned long int> {
        static const char* name() { return "unsigned long int"; } };
template<> struct type<float> {
        static const char* name() { return "float"; } };
template<> struct type<double> {
        static const char* name() { return "double"; } };
template<> struct type< std::complex<double> > {
        static const char* name() { return "complex<double>"; } };


// traits to select init values
template<typename T> struct array { static int elem[]; };
template<typename T> int array<T>::elem[] = { 1, 2, 3, 4 };

template<> struct array<char> { static char elem[]; };
char array<char>::elem[] = { '\0', '\n', ' ', 'a', 'A' };

template<> struct array<int> { static int elem[]; };
int array<int>::elem[] = { -2, -3, -4, -5, -6  };

template<> struct array<unsigned int> { static unsigned int elem[]; };
unsigned int array<unsigned int>::elem[] = { 2, 3, 4, 5, 6, 7  };

template<> struct array<long int> { static long int elem[]; };
long int array<long int>::elem[] = { -2, -3, -4, -5, -6  };

template<> struct array<unsigned long int> { static unsigned long int elem[]; };
unsigned long int array<unsigned long int>::elem[] = { 2, 3, 4, 5, };

template<> struct array<float> { static float elem[]; };
float array<float>::elem[] = { -0.2, 1.3, -2.4, 3.5, -4.6 };

template<> struct array<double> { static double elem[]; };
double array<double>::elem[] = { 1.2, -2.3, 3.4, -4.5, 5.6 };

template<> struct array< std::complex<double> > { static double elem[]; };
double array< std::complex<double> >::elem[] = { 1.2, -2.3, 3.4 };



template<typename T> T init() { return T(); }

template<typename T> T init(int i)
{
        int size = sizeof(array<T>::elem)/sizeof(*array<T>::elem);
        while ( i<0 ) i+=size;
        while ( i>=size ) i-=size;
        return array<T>::elem[i];
}


// some operators are undefined for some base types,
// traits to exclude undefined operations

// modulo defined only for integers
template<typename T, unsigned int D, typename U>
struct dim_mod_assign_test { dim_mod_assign_test (dim<T,D>& x, T t, U u) {} };

template<unsigned int D, typename U>
struct dim_mod_assign_test<char,D,U> {
        dim_mod_assign_test(dim<char,D>& x, char t, U u) {
                BOOST_CHECK_EQUAL( (x %= u)(), t % u ); } };

template<unsigned int D, typename U>
struct dim_mod_assign_test<int,D,U> {
        dim_mod_assign_test(dim<int,D>& x, int t, U u) {
                BOOST_CHECK_EQUAL( (x %= u)(), (int)(t % u) ); } };

template<unsigned int D, typename U>
struct dim_mod_assign_test<unsigned int,D,U> {
        dim_mod_assign_test(dim<unsigned int,D>& x, unsigned int t, U u) {
                BOOST_CHECK_EQUAL( (x %= u)(), t % u ); } };

template<unsigned int D, typename U>
struct dim_mod_assign_test<long int,D,U> {
        dim_mod_assign_test(dim<long int,D>& x, long int t, U u) {
                BOOST_CHECK_EQUAL( (x %= u)(), (long int)(t % u) ); } };

template<unsigned int D, typename U>
struct dim_mod_assign_test<unsigned long int,D,U> {
        dim_mod_assign_test(dim<unsigned long int,D>& x, unsigned long int t, U u) {
                BOOST_CHECK_EQUAL( (x %= u)(), t % u ); } };


template<typename T, unsigned int D, typename U>
struct dim_mod_operator_test { dim_mod_operator_test(dim<T,D>& x, T t, U u) {} };

template<unsigned int D, typename U>
struct dim_mod_operator_test<char,D,U> {
        dim_mod_operator_test(dim<char,D>& x, char t, U u) {
                BOOST_CHECK_EQUAL( (x % u)(), t % u ); } };

template<unsigned int D, typename U>
struct dim_mod_operator_test<int,D,U> {
        dim_mod_operator_test(dim<int,D>& x, int t, U u) {
                BOOST_CHECK_EQUAL( (x % u)(), (int)(t % u) ); } };

template<unsigned int D, typename U>
struct dim_mod_operator_test<unsigned int,D,U> {
        dim_mod_operator_test(dim<unsigned int,D>& x, unsigned int t, U u) {
                BOOST_CHECK_EQUAL( (x % u)(), t % u ); } };

template<unsigned int D, typename U>
struct dim_mod_operator_test<long int,D,U> {
        dim_mod_operator_test(dim<long int,D>& x, long int t, U u) {
                BOOST_CHECK_EQUAL( (x % u)(), (long int)(t % u) ); } };

template<unsigned int D, typename U>
struct dim_mod_operator_test<unsigned long int,D,U> {
        dim_mod_operator_test(dim<unsigned long int,D>& x, unsigned long int t, U u) {
                BOOST_CHECK_EQUAL( (x % u)(), t % u ); } };


/*******************/
/* dimension tests */
/*******************/

// no increment/decrement operators for std::complex
template<typename T, unsigned int D>
struct dim_incr_decr_operator_test
{
        typedef dim<T,D> dimT;
        dim_incr_decr_operator_test(T t0)
        {
                dimT x0, x1, x2, x3;
                BOOST_CHECK_EQUAL( (x0 = x1 = x2 = x3 = dimT(t0))(), t0 );
                BOOST_CHECK_EQUAL( (x0++)(), t0 );
                BOOST_CHECK_EQUAL( (x1--)(), t0 );
                BOOST_CHECK_EQUAL( (++x2)(), t0+1 );
                BOOST_CHECK_EQUAL( (--x3)(), t0-1 );
                BOOST_CHECK_EQUAL( x0(), t0+1 );
                BOOST_CHECK_EQUAL( x1(), t0-1 );
                BOOST_CHECK_EQUAL( x2(), t0+1 );
                BOOST_CHECK_EQUAL( x3(), t0-1 );
        }
};

template<typename T, unsigned int D>
struct dim_incr_decr_operator_test<std::complex<T>,D> {
        dim_incr_decr_operator_test(std::complex<T>) {}
};


// perform dimension tests for all D dimensions recursively
template<int L, typename T, unsigned int D> struct dimension_test
{
        typedef dim<T,D-1> dimD;

        dimension_test() {
                // handle recursive cases first
                dimension_test<L,T,D-1>();
                T t0(init<T>()), t1(init<T>(0)), t2(init<T>(D));
                // init test
                dimD x0;        // default constructor
                dimD x1(t1);    // pick a init value
                dimD x2(t2);    // pick another init value
                dimD x3(x2);    // check copy constructor
                BOOST_CHECK_EQUAL( x0(), t0 );
                BOOST_CHECK_EQUAL( x1(), t1 );
                BOOST_CHECK_EQUAL( x2(), t2 );
                BOOST_CHECK_EQUAL( x3(), t2 );
                // assignment operatore test
                BOOST_CHECK_EQUAL( (x0 = x1)(), t1 );
                BOOST_CHECK_EQUAL( (x2 += x1)(), t2+t1 );
                BOOST_CHECK_EQUAL( (x3 -= x1)(), t2-t1 );
                BOOST_CHECK_EQUAL( (x2 = x1)(), t1 );
                BOOST_CHECK_EQUAL( (x3 = x1)(), t1 );
                BOOST_CHECK_EQUAL( (x0 *= t0)(), t1*t0 );
                BOOST_CHECK_EQUAL( (x1 *= t2)(), t1*t2 );
                BOOST_CHECK_EQUAL( (x2 /= t2)(), t1/t2 );
                dim_mod_assign_test<T,D-1,T>( x3, t1, t2 );
                // increment/decrement test
                (dim_incr_decr_operator_test<T,D>)(t2);
       }
};


template<int L, typename T> struct dimension_test<L,T,0>
{
        dimension_test() { BOOST_MESSAGE(
                "test dimensions with [T = " << type<T>::name() << "]"); }
};


#if EUCLID_TEST_LEVEL < 3
template<typename T, unsigned int D> struct dimension_test<3,T,D> {};
#if EUCLID_TEST_LEVEL < 2
template<typename T, unsigned int D> struct dimension_test<2,T,D> {};
#endif
#endif


BOOST_AUTO_UNIT_TEST( dimension_tests )
{
        dimension_test<2,char,4>();
        dimension_test<1,int,4>();
        dimension_test<2,unsigned int,4>();
        dimension_test<2,long int,4>();
        dimension_test<3,unsigned long int,4>();
        dimension_test<2,float,4>();
        dimension_test<1,double,4>();
        dimension_test<1,std::complex<double>,4>();
}




// no relational operators for std::complex
template<typename T, unsigned int D, typename U>
struct dim_relational_operator_test
{
        typedef dim<T,D> dimT;
        typedef dim<U,D> dimU;

        dim_relational_operator_test(dimT t, dimU u, T t0, U u0)
        {
                BOOST_CHECK_EQUAL( t == u, (bool)(t0 == u0) );
                BOOST_CHECK_EQUAL( t != u, (bool)(t0 != u0) );
                BOOST_CHECK_EQUAL( t >= u, (bool)(t0 >= u0) );
                BOOST_CHECK_EQUAL( t <= u, (bool)(t0 <= u0) );
                BOOST_CHECK_EQUAL( t > u, (bool)(t0 > u0) );
                BOOST_CHECK_EQUAL( t < u, (bool)(t0 < u0) );
        }
};

template<typename T, unsigned int D, typename U>
struct dim_relational_operator_test<std::complex<T>,D,U> {
        typedef dim<std::complex<T>,D> dimT;
        typedef dim<U,D> dimU;
        dim_relational_operator_test(dimT, dimU, std::complex<T>, U) {}
};


// perform dimension tests for all D dimensions recursively
template<int L, typename T, typename U, unsigned int D>
struct dimension_type_conversion_test
{
        typedef dim<T,D-1> dimT;
        typedef dim<U,D-1> dimU;

        dimension_type_conversion_test() {
                // handle recursive cases first
                dimension_type_conversion_test<L,T,U,D-1>();
                U u0(init<U>(D)); T t0(init<T>(0));
                // type conversion test
                dimU u(u0);
                dimT x1(t0);
                dimT x2(t0);
                dimT x3(t0);
                BOOST_CHECK_EQUAL( u(), u0 );
                BOOST_CHECK_EQUAL( dimT(u)(), T(u0) );
                // assignment operator test
                BOOST_CHECK_EQUAL( (x1  = u)(), T(u0) );
                BOOST_CHECK_EQUAL( (x2 += u)(), T(t0 + u0) );
                BOOST_CHECK_EQUAL( (x3 -= u)(), T(t0 - u0) );
                BOOST_CHECK_EQUAL( (x2 = u)(), T(u0) );
                BOOST_CHECK_EQUAL( (x3 = u)(), T(u0) );
                BOOST_CHECK_EQUAL( (x1 *= u0)(), T(T(u0) * u0) );
                BOOST_CHECK_EQUAL( (x2 /= u0)(), T(T(u0) / u0) );
                dim_mod_assign_test<T,D-1,U>( x3, T(u0), u0 );
                // arithmetic operator test
                dimT x(t0);
                BOOST_CHECK_EQUAL( (-x)(), (-t0) );
                BOOST_CHECK_EQUAL( (x + u)(), T(t0 + u0) );
                BOOST_CHECK_EQUAL( (x - u)(), T(t0 - u0) );
                BOOST_CHECK_EQUAL( (u0 * x)(), T(t0 * u0) );
                BOOST_CHECK_EQUAL( (x * u0)(), T(t0 * u0) );
                BOOST_CHECK_EQUAL( (x / u0)(), T(t0 / u0) );
                dim_mod_operator_test<T,D-1,U>( x, t0, u0 );
                // relational operator test
                dim_relational_operator_test<T,D-1,U>( x, u, t0, u0);
        }
};


template<int L, typename T, typename U>
struct dimension_type_conversion_test<L,T,U,0>
{
        dimension_type_conversion_test() { BOOST_MESSAGE(
                "test dimensions type conversion with ["
                "T = " << type<T>::name() << ", "
                "U = " << type<U>::name() << "]"
        ); }
};


#if EUCLID_TEST_LEVEL < 3
template<typename T, typename U, unsigned int D>
        struct dimension_type_conversion_test<3,T,U,D> {};
#if EUCLID_TEST_LEVEL < 2
template<typename T, typename U, unsigned int D>
        struct dimension_type_conversion_test<2,T,U,D> {};
#endif
#endif


BOOST_AUTO_UNIT_TEST( dimension_type_conversion_tests )
{
        dimension_type_conversion_test<1,int, char, 4>();
        dimension_type_conversion_test<3,unsigned int, char, 4>();
        dimension_type_conversion_test<3,int,unsigned int, 4>();
        dimension_type_conversion_test<3,unsigned int,int, 4>();

        dimension_type_conversion_test<2,long int, char, 4>();
        dimension_type_conversion_test<2,long int, int, 4>();
        dimension_type_conversion_test<3,long int, unsigned int, 4>();
        dimension_type_conversion_test<3,unsigned long int, char, 4>();
        dimension_type_conversion_test<3,unsigned long int, int, 4>();
        dimension_type_conversion_test<2,unsigned long int, unsigned int, 4>();
        dimension_type_conversion_test<3,long int, unsigned long int, 4>();
        dimension_type_conversion_test<3,unsigned long int, long int, 4>();

        dimension_type_conversion_test<3,float,char, 4>();
        dimension_type_conversion_test<2,float,int, 4>();
        dimension_type_conversion_test<3,float,unsigned int, 4>();
        dimension_type_conversion_test<2,float,long int, 4>();
        dimension_type_conversion_test<3,float,unsigned long int, 4>();

        dimension_type_conversion_test<2,double, char, 4>();
        dimension_type_conversion_test<1,double, int, 4>();
        dimension_type_conversion_test<2,double, long int, 4>();
        dimension_type_conversion_test<2,double, float, 4>();

        dimension_type_conversion_test<1,std::complex<double>, double, 4>();
}

