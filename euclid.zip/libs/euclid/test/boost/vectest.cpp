//  Boost vector tests

//  Copyright (C) 2004-2009
//  Andreas Harnack (ah8 at freenet dot de)
//  version 0.0.4

//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.

//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.

//  You should have received a copy of the GNU General Public License along
//  with this program; if not, write to the Free Software Foundation, Inc.,
//  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.


#include <iostream>
#include <iterator>
#include <functional>
#include <numeric>
#include <complex>
#include <cmath>
#include "euclid.hpp"

using namespace euclid;
using namespace std;

#define BOOST_AUTO_TEST_MAIN
#include <boost/test/auto_unit_test.hpp>
#include <boost/test/floating_point_comparison.hpp>

#ifndef EUCLID_TEST_LEVEL
#define EUCLID_TEST_LEVEL 3
#endif

// traits to print type names
template<typename T> struct type {
        static const char* name() { return "unknown"; } };
template<> struct type<char> {
        static const char* name() { return "char"; } };
template<> struct type<int> {
        static const char* name() { return "int"; } };
template<> struct type<unsigned int> {
        static const char* name() { return "unsigned int"; } };
template<> struct type<long int> {
        static const char* name() { return "long int"; } };
template<> struct type<unsigned long int> {
        static const char* name() { return "unsigned long int"; } };
template<> struct type<float> {
        static const char* name() { return "float"; } };
template<> struct type<double> {
        static const char* name() { return "double"; } };
template<> struct type< std::complex<double> > {
        static const char* name() { return "complex<double>"; } };


// traits to select init values
template<typename T> struct array { static int elem[]; };
template<typename T> int array<T>::elem[] = { 1, 2, 3, 4 };

template<> struct array<char> { static char elem[]; }; 
char array<char>::elem[] = { '0', ' ', '@', 'a', 'A' };

template<> struct array<int> { static int elem[]; };
int array<int>::elem[] = { 2, -3, 4, -5, 6  };

template<> struct array<unsigned int> { static unsigned int elem[]; };
unsigned int array<unsigned int>::elem[] = { 2, 3, 4, 5, 6, 7  };

template<> struct array<long int> { static long int elem[]; };
long int array<long int>::elem[] = { 2, -3, 4, -5, 6  };

template<> struct array<unsigned long int> { static unsigned long int elem[]; };
unsigned long int array<unsigned long int>::elem[] = { 2, 3, 4, 5, };

template<> struct array<float> { static float elem[]; };
float array<float>::elem[] = { -0.2, 1.3, -2.4, 3.5, -4.6 };

template<> struct array<double> { static double elem[]; };
double array<double>::elem[] = { 1.2, -2.3, 3.4, -4.5, 5.6 };

template<> struct array< std::complex<double> > { static double elem[]; };
double array< std::complex<double> >::elem[] = { 1.2, -2.3, 3.4 };



template<typename T> T init() { return T(); }

template<typename T> T init(int i)
{
        int size = sizeof(array<T>::elem)/sizeof(*array<T>::elem);
        while ( i<0 ) i+=size;
        while ( i>=size ) i-=size;
        return array<T>::elem[i];
}



template<class ostream=std::ostream> class ostream_iterator
{
        protected:
                ostream& stream;
                const char* string;
        public:
                typedef typename ostream::char_type     char_type;
                typedef typename ostream::traits_type   traits_type;
                typedef ostream                 ostream_type;

                ostream_iterator(ostream& s):
                        stream(s), string(0) {}
                ostream_iterator(ostream& s, const char* c) :
                        stream(s), string(c)  {}
                template<class T> ostream_iterator& operator=(const T& value) {
                        stream << value;
                        if (string) stream << string;
                        return *this;
                }
                ostream_iterator& operator*() { return *this; }
                ostream_iterator& operator++() { return *this; }
                ostream_iterator& operator++(int) { return *this; }
};



template<class OutputIterator> struct copy_out
{
        OutputIterator it;
        copy_out(OutputIterator i) : it(i) {}
        template<class T> void operator()(T const& t) { *it = t; ++it; }
};

template<class InputIterator> struct copy_in
{
        InputIterator it;
        copy_in(InputIterator i) : it(i) {}
        template<class T> void operator()(T& t) { t = *it; ++it; }
};


template<typename OutputIterator, typename T, unsigned int D>
OutputIterator copy(vec<T,D> const& v, OutputIterator i) {
//      BOOST_MESSAGE ( v );
        return foreach(v, copy_out<OutputIterator>(i)).it; }

template<typename InputIterator, typename T, unsigned int D>
InputIterator copy(InputIterator i, vec<T,D>& v) {
        copy_in<InputIterator> in(i);
        return v.foreach(in).it; }



// some operators are undefined for some base types,
// traits to exclude undefined operations

struct true_type {};
struct false_type {};


// modulo defined only for integers
template<typename T, typename U> struct modulo_traits {
        typedef true_type has_modulo; };

template<> struct modulo_traits<float, float> {
        typedef false_type has_modulo; };

template<> struct modulo_traits<double, double> {
        typedef false_type has_modulo; };

template<typename T> struct modulo_traits<complex<T>, complex<T> > {
        typedef false_type has_modulo; };


// choose floating point close check
template<typename T> struct float_traits {
        typedef false_type is_float; };

template<> struct float_traits<float> {
        typedef true_type is_float; };

template<> struct float_traits<double> {
        typedef true_type is_float; };


// choose comparable types
template<typename T> struct cmp_traits {
        typedef true_type less_comparable; };

template<typename T> struct cmp_traits<complex<T> > {
        typedef false_type less_comparable; };


/*******************/
/*  vector tests   */
/*******************/

// pred test
template<typename T, unsigned int D, typename M=typename cmp_traits<T>::less_comparable>
struct vector_predicate_test {
        vector_predicate_test(vec<T,D> const& v, T *a) {
                BOOST_CHECK_EQUAL(
                        forall<euclid::positive>(v),
                        find_if(a, a+D, bind2nd(less_equal<T>(), T())) == a+D
                );
                BOOST_CHECK_EQUAL(
                        forall<euclid::negative>(v),
                        find_if(a, a+D, bind2nd(greater_equal<T>(),T())) == a+D
                );
                BOOST_CHECK_EQUAL(
                        forall<euclid::not_positive>(v),
                        find_if(a, a+D, bind2nd(greater<T>(), T())) == a+D
                );
                BOOST_CHECK_EQUAL(
                        forall<euclid::not_negative>(v),
                        find_if(a, a+D, bind2nd(less<T>(), T())) == a+D
                );
        }
};

template<typename T, unsigned int D>
struct vector_predicate_test<T,D,false_type> {
        vector_predicate_test(vec<T,D> const&, T*) {}
};


// perform vector component tests for all components I recursively
template<typename T, unsigned int D, unsigned int I>
struct test_vector_component_access
{
        typedef vec<T,D> vect;
        typedef dim<T,I-1> dimI;

        test_vector_component_access(vec<T,D>& u1, vec<T,D>& u2, T* b1, T* b2){

                test_vector_component_access<T,D,I-1>(u1, u2, b1, b2);

                T a0[D], a1[D], a2[D];
                T t0(init<T>());
                T t1(init<T>(2*(I-1)+D));
                T t2(init<T>(2*(I-1)+D+1));

                fill(a0, a0+D, t0); a0[I-1] = t1;
                fill(a1, a1+D, t1); a1[I-1] = t2;

                vect v0;        // default constructor
                vect v1(t1);    // pick an init value
                vect v2(t2);    // pick another init value

                copy(a0, v2);
                BOOST_CHECK_EQUAL_COLLECTIONS(a2, copy(v2, a2), a0, a0+D);
                copy(a1, v2);
                BOOST_CHECK_EQUAL_COLLECTIONS(a2, copy(v2, a2), a1, a1+D);

                at<dimI>(v0) = dimI(t1);
                at<dimI>(v1) = dimI(t2);
                BOOST_CHECK_EQUAL_COLLECTIONS(a2, copy(v0, a2), a0, a0+D);
                BOOST_CHECK_EQUAL_COLLECTIONS(a2, copy(v1, a2), a1, a1+D);
                BOOST_CHECK( at<dimI>(v0) == dimI(t1) );
                BOOST_CHECK( at<dimI>(v1) == dimI(t2) );

                BOOST_CHECK_EQUAL_COLLECTIONS(a2, copy(v0 = dimI(t1), a2), a0, a0+D);
                BOOST_CHECK_EQUAL_COLLECTIONS(a2, copy(v1 = dimI(t2), a2), a1, a1+D);

                copy(v0 = dimI(t1), a2);
                BOOST_CHECK_EQUAL_COLLECTIONS(a2, a2+D, a0, a0+D);
                copy(v1 = dimI(t2), a2);
                BOOST_CHECK_EQUAL_COLLECTIONS(a2, a2+D, a1, a1+D);

                BOOST_CHECK( dimI(v0) == dimI(t1) );
                BOOST_CHECK( dimI(v1) == dimI(t2) );
                BOOST_CHECK_EQUAL( dimI(v0)(), t1 );
                BOOST_CHECK_EQUAL( dimI(v1)(), t2 );

                fill(a0, a0+D, t0);
                fill(a1, a1+D, t1);
                BOOST_CHECK_EQUAL_COLLECTIONS(a2, copy(v0 = dimI(t0), a2), a0, a0+D);
                BOOST_CHECK_EQUAL_COLLECTIONS(a2, copy(v1 = dimI(t1), a2), a1, a1+D);

                copy(v0 = dimI(t0), a2);
                BOOST_CHECK_EQUAL_COLLECTIONS(a2, a2+D, a0, a0+D);
                copy(v1 = dimI(t1), a2);
                BOOST_CHECK_EQUAL_COLLECTIONS(a2, a2+D, a1, a1+D);

                fill(a0, a0+D, t0); a0[I-1] += t1;
                fill(a1, a1+D, t1); a1[I-1] += t2;
                BOOST_CHECK_EQUAL_COLLECTIONS(a2, copy(v0 + dimI(t1), a2), a0, a0+D);
                BOOST_CHECK_EQUAL_COLLECTIONS(a2, copy(v1 + dimI(t2), a2), a1, a1+D);

                copy(v0 + dimI(t1), a2);
                BOOST_CHECK_EQUAL_COLLECTIONS(a2, a2+D, a0, a0+D);
                copy(v1 + dimI(t2), a2);
                BOOST_CHECK_EQUAL_COLLECTIONS(a2, a2+D, a1, a1+D);

                fill(a0, a0+D, t0); a0[I-1] -= t1;
                fill(a1, a1+D, t1); a1[I-1] -= t2;
                BOOST_CHECK_EQUAL_COLLECTIONS(a2, copy(v0 - dimI(t1), a2), a0, a0+D);
                BOOST_CHECK_EQUAL_COLLECTIONS(a2, copy(v1 - dimI(t2), a2), a1, a1+D);

                copy(v0 - dimI(t1), a2);
                BOOST_CHECK_EQUAL_COLLECTIONS(a2, a2+D, a0, a0+D);
                copy(v1 - dimI(t2), a2);
                BOOST_CHECK_EQUAL_COLLECTIONS(a2, a2+D, a1, a1+D);

                // set initial value for vector operation tests
                u1 = dimI(t1); b1[I-1] = t1;
                u2 = dimI(t2); b2[I-1] = t2;
                BOOST_CHECK_EQUAL_COLLECTIONS(a2, copy(u1, a2), b1, b1+D);
                BOOST_CHECK_EQUAL_COLLECTIONS(a2, copy(u2, a2), b2, b2+D);

                // use it for pred test
                vector_predicate_test<T,D>(u1, b1);
                vector_predicate_test<T,D>(u2, b2);
        }
};


template<typename T, unsigned int D>
struct test_vector_component_access<T,D,0>
{
        test_vector_component_access(vec<T,D>&, vec<T,D>, T*, T*) {
                BOOST_MESSAGE(
                        "test vector component access with ["
                        "T = " << type<T>::name() << ", "
                        "D = " << D << "]"
                );
        }
};


// traits to exclude modulo test for undefined cases
template<typename T, unsigned int D, typename M=typename modulo_traits<T,T>::has_modulo>
struct vector_mod_operator_test { vector_mod_operator_test(
        vec<T,D> const& v1, T t2, T* a0, T* a1, T* a3) {
                BOOST_CHECK( equal(a0,
                        copy( v1%t2, a0 ),
                        transform(a1,a1+D,a3, bind2nd(std::modulus<T>(),t2))-D
                ));
        }
};

template<typename T, unsigned int D>
struct vector_mod_operator_test<T,D,false_type> { vector_mod_operator_test(
        vec<T,D> const& v1, T t2, T* a0, T* a1, T* a3) {}
};


// scalar product test
template<typename T, unsigned int D, typename F=typename float_traits<T>::is_float>
struct vector_scalar_product_test {
        vector_scalar_product_test(
                vec<T,D> const& v1, vec<T,D> const& v2, T* a1, T* a2
        ) {
                BOOST_CHECK_CLOSE(v1*v2, inner_product(a1,a1+D,a2,T()), 1e-4);
        }
};

template<typename T, unsigned int D>
struct vector_scalar_product_test<T,D,false_type> {
        vector_scalar_product_test(
                vec<T,D> const& v1, vec<T,D> const& v2, T* a1, T* a2
        ) {
#ifndef EUCLID_USE_TYPE_TRAITS
                BOOST_CHECK_EQUAL(v1*v2, inner_product(a1, a1+D, a2, T()));
#else
                // in some cases operators with derived result types provide
                // resultes more accurate then - i.e. different from - the
                // results produced by reference operation, hence the result
                // is converted back to the reference type range in the hope
                // to get a value that matches the reference
                BOOST_CHECK_EQUAL(T(v1*v2), inner_product(a1, a1+D, a2, T()));
#endif
        }
};


// cross product test
template<typename T, unsigned int D, typename F=typename float_traits<T>::is_float>
struct vector_cross_product_test {
        vector_cross_product_test(vec<T,D> const&, vec<T,D> const&) {}
};

// test cross product by applying Lagrange's formula
template<typename T> struct vector_cross_product_test<T,2,false_type> {
        vector_cross_product_test(vec<T,2> const& v1, vec<T,2> const& v2) {
                BOOST_CHECK_EQUAL(prod(v1)*prod(v1), v1*v1);
        }
};

template<typename T> struct vector_cross_product_test<T,2,true_type> {
        vector_cross_product_test(vec<T,2> const& v1, vec<T,2> const& v2) {
                BOOST_CHECK_CLOSE (prod(v1)*prod(v1), v1*v1, 1e-6);
        }
};

// removed for numerical reasons with small data types (char)
// tested now only for float types
//
//template<typename T> struct vector_cross_product_test<T,3,false_type> {
//      vector_cross_product_test(vec<T,3> const& v1, vec<T,3> const& v2) {
//
//
//              vec<T,3> cross_prod(prod(v1,v2));
//              T scalar_prod(v1*v2);
//              BOOST_CHECK_EQUAL(
//                      cross_prod*cross_prod + scalar_prod*scalar_prod,
//                      (v1*v1)*(v2*v2)
//              );
//      }
//};

template<typename T> struct vector_cross_product_test<T,3,true_type> {
        vector_cross_product_test(vec<T,3> const& v1, vec<T,3> const& v2) {
                vec<T,3> cross_prod(prod(v1,v2));
                T scalar_prod(v1*v2);
                BOOST_CHECK_CLOSE (
                        cross_prod*cross_prod + scalar_prod*scalar_prod,
                        (v1*v1)*(v2*v2), 1e-4
                );
        }
};


// vector norm test
template<typename T, unsigned int D, typename F=typename float_traits<T>::is_float>
struct vector_norm_test {
        vector_norm_test(vec<T,D> const& v, T *a) {
                BOOST_CHECK_CLOSE(pnorm<2>(v),inner_product(a,a+D,a,T()),1e-4);
        }
};

template<typename T, unsigned int D>
struct vector_norm_test<T,D,false_type> {
        vector_norm_test(vec<T,D> const& v, T *a) {
                BOOST_CHECK_EQUAL(pnorm<2>(v), inner_product(a, a+D, a, T()));
        }
};


// perform dimension tests for all D dimensions recursively
template<int L, typename T, unsigned int D> struct vector_test
{
        typedef vec<T,D> vect;

        vector_test() {
                // vectors of all smaller dimension too
                vector_test<L,T,D-1>();

                // init values
                T t0(init<T>()), t1(init<T>(0)), t2(init<T>(D));
                T a0[D], a1[D], a2[D], a3[D];

                // init test
                vect v0;        // default constructor
                vect v1(t1);    // init value
                vect v2(t2);    // another init value
                vect v3(v2);    // copy constructor

                BOOST_CHECK(int(D) == count_if(a0,
                        copy(v0, a0), bind2nd(equal_to<T>(), t0)) );
                BOOST_CHECK(int(D) == count_if(a1,
                        copy(v1, a1), bind2nd(equal_to<T>(), t1)) );
                BOOST_CHECK(int(D) == count_if(a2,
                        copy(v2, a2), bind2nd(equal_to<T>(), t2)) );
                BOOST_CHECK(int(D) == count_if(a3,
                        copy(v3, a3), bind2nd(equal_to<T>(), t2)) );

                // pred test should check all or no cases here
                vector_predicate_test<T,D>(v0, a0 );
                vector_predicate_test<T,D>(v1, a1 );

                // relational operators
                BOOST_CHECK( (v2 == v3) );
                BOOST_CHECK( ! (v2 != v3 ) );

                // asignment operator
                v0 = v2;
                BOOST_CHECK(int(D) == count_if(a3,
                        copy(v0, a3), bind2nd(equal_to<T>(), t2)) );

                // relational operators
                BOOST_CHECK( (v2 == v0) );
                BOOST_CHECK( ! (v2 != v0 ) );

                // component access test
                test_vector_component_access<T,D,D>(v1, v2, a1, a2);

                // equality
                BOOST_CHECK_EQUAL( (v1 == v2), equal(a1, a1+D, a2) );
                BOOST_CHECK_EQUAL( (v1 != v2), ! equal(a1, a1+D, a2) );

                // arithmetic operators
                transform(a1, a1+D, a3, std::negate<T>());
                BOOST_CHECK_EQUAL_COLLECTIONS(a0, copy(-v1,a0), a3, a3+D);
                transform(a1, a1+D, a2, a3, std::plus<T>());
                BOOST_CHECK_EQUAL_COLLECTIONS(a0, copy(v1+v2,a0), a3, a3+D);
                transform(a1,a1+D,a2,a3, std::minus<T>());
                BOOST_CHECK_EQUAL_COLLECTIONS(a0, copy(v1-v2,a0), a3, a3+D);

                transform(a1,a1+D,a3,bind2nd(std::multiplies<T>(),t2));
                BOOST_CHECK_EQUAL_COLLECTIONS(a0, copy(v1*t2,a0), a3, a3+D);
                transform(a2,a2+D,a3,bind1st(std::multiplies<T>(),t1));
                BOOST_CHECK_EQUAL_COLLECTIONS(a0, copy(t1*v2,a0), a3, a3+D);
                transform(a1,a1+D,a3,bind2nd(std::divides<T>(),t2));
                BOOST_CHECK_EQUAL_COLLECTIONS(a0, copy(v1/t2,a0), a3, a3+D);

                vector_mod_operator_test<T,D>( v1, t2, a0, a1, a3);

                // scalar and cross product
                vector_scalar_product_test<T,D>(v1, v2, a1, a2);
                vector_cross_product_test<T,D>(v1, v2);

                // vector norm
                vector_norm_test<T,D>(v1, a1);
                vector_norm_test<T,D>(v2, a2);

                // arithmetic operations by STL Function objects
                BOOST_CHECK( -v1 == map(v1, std::negate<T>()) );
#ifndef EUCLID_USE_TYPE_TRAITS
                BOOST_CHECK( v1+v2 == join(v1, v2, std::plus<T>()) );
                BOOST_CHECK( v1-v2 == join(v1, v2, std::minus<T>()) );
                BOOST_CHECK( v1*t2 == map(v1, bind2nd(std::multiplies<T>(),t2)) );
                BOOST_CHECK( t1*v2 == map(v2, bind1st(std::multiplies<T>(),t1)) );
#else
                // in some cases operators with derived result types provide
                // resultes more accurate then - i.e. different from - the
                // results produced by reference operation, hence the result
                // is converted back to the reference type range in the hope
                // to get a value that matches the reference
                BOOST_CHECK( (vec<T,D>(v1+v2)) == join(v1, v2, std::plus<T>()) );
                BOOST_CHECK( (vec<T,D>(v1-v2)) == join(v1, v2, std::minus<T>()) );
                BOOST_CHECK( (vec<T,D>(v1*t2)) == map(v1, bind2nd(std::multiplies<T>(),t2)) );
                BOOST_CHECK( (vec<T,D>(t1*v2)) == map(v2, bind1st(std::multiplies<T>(),t1)) );
#endif
                BOOST_CHECK( v1/t2 == map(v1, bind2nd(std::divides<T>(),t2)) );

        }
};


template<int L, typename T> struct vector_test<L,T,0>
{
        vector_test() {
                BOOST_MESSAGE(
                        "test vectors with [T = " << type<T>::name() << "]"
                );
        }
};


#if EUCLID_TEST_LEVEL < 3
template<typename T, unsigned int D> struct vector_test<3,T,D> {};
#if EUCLID_TEST_LEVEL < 2
template<typename T, unsigned int D> struct vector_test<2,T,D> {};
#endif
#endif


BOOST_AUTO_UNIT_TEST( vector_tests )
{
        vector_test<2,char,4>();
        vector_test<1,int,4>();
        vector_test<2,unsigned int,4>();
        vector_test<2,long int,4>();
        vector_test<3,unsigned long int,4>();
        vector_test<2,float,4>();
        vector_test<1,double,4>();
        vector_test<1,std::complex<double>,4>();
}


/********************************/
/* vector type conversion tests */
/********************************/

// perform vector component tests with type conversion
template<typename T, typename U, unsigned int D, unsigned int I>
struct test_vector_component_conversion
{
        test_vector_component_conversion(vec<T,D>& u1,vec<U,D>& u2,T*b1,U*b2){
                test_vector_component_conversion<T,U,D,I-1>(u1, u2, b1, b2);

                T t1(init<T>(2*(I-1)+D));
                U t2(init<U>(2*(I-1)+D+1));
                T a0[D]; T a1[D]; U a2[D];

                vec<T,D> v1(t1);

                fill(a0, a0+D, t1); a0[I-1] += t2;
                BOOST_CHECK_EQUAL_COLLECTIONS(
                        a1, copy(v1+dim<U,I-1>(t2), a1), a0, a0+D);
                fill(a0, a0+D, t1); a0[I-1] -= t2;
                BOOST_CHECK_EQUAL_COLLECTIONS(
                        a1, copy(v1-dim<U,I-1>(t2), a1), a0, a0+D);
                fill(a0, a0+D, t1); a0[I-1] = t2;
                BOOST_CHECK_EQUAL_COLLECTIONS(
                        a1, copy(v1=dim<U,I-1>(t2), a1), a0, a0+D);

                // set initial value for vector operation tests
                u1 = dim<T,I-1>(t1); b1[I-1] = t1;
                u2 = dim<U,I-1>(t2); b2[I-1] = t2;
                BOOST_CHECK_EQUAL_COLLECTIONS(a1, copy(u1, a1), b1, b1+D);
                BOOST_CHECK_EQUAL_COLLECTIONS(a2, copy(u2, a2), b2, b2+D);
        }
};


template<typename T, typename U, unsigned int D>
struct test_vector_component_conversion<T,U,D,0>
{
        test_vector_component_conversion(vec<T,D>&, vec<U,D>, T*, U*) {
                BOOST_MESSAGE(
                        "test vector component type conversion with ["
                        "T = " << type<T>::name() << ", "
                        "U = " << type<U>::name() << ", "
                        "D = " << D << "]"
                );
        }
};


// vector type conversion tests
template<int L, typename T, typename U, unsigned int D>
struct vector_type_conversion_test
{
        typedef dim<T,D-1> dimT;
        typedef dim<U,D-1> dimU;

        vector_type_conversion_test() {
                // handle recursive cases first
                vector_type_conversion_test<L,T,U,D-1>();

                T t1(init<T>(0)); U t2(init<U>(D));
                T a0[D]; T a1[D]; U a2[D]; T a3[D];
                T *i1; U *i2; T* i3;

                vec<T,D> v1(t1);
                vec<U,D> v2(t2);
                vec<T,D> v3(v2);

                BOOST_CHECK(int(D) == count_if(a1,
                        copy(v1, a1), bind2nd(equal_to<T>(), t1)) );
                BOOST_CHECK(int(D) == count_if(a2,
                        copy(v2, a2), bind2nd(equal_to<U>(), t2)) );
                BOOST_CHECK(int(D) == count_if(a3,
                        copy(v3, a3), bind2nd(equal_to<T>(), T(t2))) );

                // component access test
                test_vector_component_conversion<T,U,D,D>(v1, v2, a1, a2);

                // STL doesn't seem to support multi-type operators
                for ( i1=a1, i2=a2, i3=a3; i3<a3+D; *i3++ = *i1++ + *i2++ );
                BOOST_CHECK_EQUAL_COLLECTIONS(a0, copy(v1+v2,a0), a3, a3+D);
                for ( i1=a1, i2=a2, i3=a3; i3<a3+D; *i3++ = *i1++ - *i2++ );
                BOOST_CHECK_EQUAL_COLLECTIONS(a0, copy(v1-v2,a0), a3, a3+D);

                for ( i1=a1, i3=a3; i3<a3+D; *i3++ = *i1++ * t2 );
                BOOST_CHECK_EQUAL_COLLECTIONS(a0, copy(v1*t2,a0), a3, a3+D);
                BOOST_CHECK_EQUAL_COLLECTIONS(a0, copy(t2*v1,a0), a3, a3+D);
                for ( i1=a1, i3=a3; i3<a3+D; *i3++ = *i1++ / t2 );
                BOOST_CHECK_EQUAL_COLLECTIONS(a0, copy(v1/t2,a0), a3, a3+D);
        }
};


template<int L, typename T, typename U>
struct vector_type_conversion_test<L,T,U,0>
{
        vector_type_conversion_test() { BOOST_MESSAGE(
                "test vector type conversion with ["
                "T = " << type<T>::name() << ", "
                "U = " << type<U>::name() << "]"
        ); }
};


#if EUCLID_TEST_LEVEL < 3
template<typename T, typename U, unsigned int D>
        struct vector_type_conversion_test<3,T,U,D> {};
#if EUCLID_TEST_LEVEL < 2
template<typename T, typename U, unsigned int D>
        struct vector_type_conversion_test<2,T,U,D> {};
#endif
#endif


BOOST_AUTO_UNIT_TEST( vector_type_conversion_tests )
{
        vector_type_conversion_test<1,int, char, 4>();
        vector_type_conversion_test<3,unsigned int, char, 4>();
        vector_type_conversion_test<3,int,unsigned int, 4>();
        vector_type_conversion_test<3,unsigned int,int, 4>();

        vector_type_conversion_test<2,long int, char, 4>();
        vector_type_conversion_test<2,long int, int, 4>();
        vector_type_conversion_test<3,long int, unsigned int, 4>();
        vector_type_conversion_test<3,unsigned long int, char, 4>();
        vector_type_conversion_test<3,unsigned long int, int, 4>();
        vector_type_conversion_test<2,unsigned long int, unsigned int, 4>();
        vector_type_conversion_test<3,long int, unsigned long int, 4>();
        vector_type_conversion_test<3,unsigned long int, long int, 4>();

        vector_type_conversion_test<3,float,char, 4>();
        vector_type_conversion_test<2,float,int, 4>();
        vector_type_conversion_test<3,float,unsigned int, 4>();
        vector_type_conversion_test<2,float,long int, 4>();
        vector_type_conversion_test<3,float,unsigned long int, 4>();

        vector_type_conversion_test<2,double, char, 4>();
        vector_type_conversion_test<1,double, int, 4>();
        vector_type_conversion_test<2,double, long int, 4>();
        vector_type_conversion_test<2,double, float, 4>();

        vector_type_conversion_test<1,std::complex<double>, double, 4>();
}

