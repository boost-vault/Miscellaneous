//  Boost diagonal matrix tests

//  Copyright (C) 2004-2009
//  Andreas Harnack (ah8 at freenet dot de)
//  version 0.0.4

//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.

//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.

//  You should have received a copy of the GNU General Public License along
//  with this program; if not, write to the Free Software Foundation, Inc.,
//  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.


#include <iostream>
#include <iterator>
#include <functional>
#include <numeric>
#include <complex>
#include <cmath>
#include "euclid.hpp"

using namespace euclid;
using namespace std;

#define BOOST_AUTO_TEST_MAIN
#include <boost/test/auto_unit_test.hpp>
#include <boost/test/floating_point_comparison.hpp>

#ifndef EUCLID_TEST_LEVEL
#define EUCLID_TEST_LEVEL 3
#endif

// traits to print type names
template<typename T> struct type {
        static const char* name() { return "unknown"; } };
template<> struct type<char> {
        static const char* name() { return "char"; } };
template<> struct type<int> {
        static const char* name() { return "int"; } };
template<> struct type<unsigned int> {
        static const char* name() { return "unsigned int"; } };
template<> struct type<long int> {
        static const char* name() { return "long int"; } };
template<> struct type<unsigned long int> {
        static const char* name() { return "unsigned long int"; } };
template<> struct type<float> {
        static const char* name() { return "float"; } };
template<> struct type<double> {
        static const char* name() { return "double"; } };
template<> struct type< std::complex<double> > {
        static const char* name() { return "complex<double>"; } };


// traits to select init values
template<typename T> struct array { static int elem[]; };
template<typename T> int array<T>::elem[] = { 1, 2, 3, 4 };

template<> struct array<char> { static char elem[]; };
char array<char>::elem[] = { '0', ' ', '@', 'a', 'A' };

template<> struct array<int> { static int elem[]; };
int array<int>::elem[] = { -2, -3, -4, -5, -6  };

template<> struct array<unsigned int> { static unsigned int elem[]; };
unsigned int array<unsigned int>::elem[] = { 2, 3, 4, 5, 6, 7  };

template<> struct array<long int> { static long int elem[]; };
long int array<long int>::elem[] = { -2, -3, -4, -5, -6  };

template<> struct array<unsigned long int> { static unsigned long int elem[]; };
unsigned long int array<unsigned long int>::elem[] = { 2, 3, 4, 5, };

template<> struct array<float> { static float elem[]; };
float array<float>::elem[] = { -0.2, 1.3, -2.4, 3.5, -4.6 };

template<> struct array<double> { static double elem[]; };
double array<double>::elem[] = { 1.2, -2.3, 3.4, -4.5, 5.6 };

template<> struct array< std::complex<double> > { static double elem[]; };
double array< std::complex<double> >::elem[] = { 1.2, -2.3, 3.4 };


template<typename T> T init()
{
        const int size = sizeof(array<T>::elem)/sizeof(*array<T>::elem);
        static int i = 0;
        if ( i >= size ) i = 0;
        return array<T>::elem[i++];
}

template<typename T> T init(int i)
{
        const int size = sizeof(array<T>::elem)/sizeof(*array<T>::elem);
        while ( i<0 ) i+=size;
        while ( i>=size ) i-=size;
        return array<T>::elem[i];
}

template<typename T> T* fill(T *begin, T *end) 
{
        while ( begin != end )
                *begin++ = init<T>();
        return end;
}



// helpers to copy data between matrices and arrays
template<class OutputIterator> struct copy_out
{
        OutputIterator it;
        copy_out(OutputIterator i) : it(i) {}
        template<class T> void operator()(T const& t) { *it = t; ++it; }
};

template<class InputIterator> struct copy_in
{
        InputIterator it;
        copy_in(InputIterator i) : it(i) {}
        template<class T> void operator()(T& t) { t = *it; ++it; }
};


template<typename OutputIterator, typename T, unsigned int D>
OutputIterator copy(diag<T,D> const& m, OutputIterator i) {
//      BOOST_MESSAGE ( m );
        return foreach(m, copy_out<OutputIterator>(i)).it; }

template<typename InputIterator, typename T, unsigned int D>
InputIterator copy(InputIterator i, diag<T,D>& m) {
        copy_in<InputIterator> in(i);
        return m.foreach(in).it; }


template<typename OutputIterator, typename T, unsigned int D>
OutputIterator copy(vec<T,D> const& v, OutputIterator i) {
//      BOOST_MESSAGE ( v );
        return foreach(v, copy_out<OutputIterator>(i)).it; }

template<typename InputIterator, typename T, unsigned int D>
InputIterator copy(InputIterator i, vec<T,D>& v) {
        copy_in<InputIterator> in(i);
        return v.foreach(in).it; }


// some operators are undefined for some base types,
// traits to exclude undefined operations

struct true_type {};
struct false_type {};


// modulo defined only for integers
template<typename T, typename U> struct modulo_traits {
        typedef true_type has_modulo; };

template<> struct modulo_traits<float, float> {
        typedef false_type has_modulo; };

template<> struct modulo_traits<double, double> {
        typedef false_type has_modulo; };

template<typename T> struct modulo_traits<std::complex<T>, std::complex<T> > {
        typedef false_type has_modulo; };


// choose floating point close check
template<typename T> struct float_traits {
        typedef false_type is_float; };

template<> struct float_traits<float> {
        typedef true_type is_float; };

template<> struct float_traits<double> {
        typedef true_type is_float; };


// choose comparable types
template<typename T> struct cmp_traits {
        typedef true_type less_comparable; };

template<typename T> struct cmp_traits<std::complex<T> > {
        typedef false_type less_comparable; };



/*************************/
/* diagonal matrix tests */
/*************************/

// perform diagonal matrix predicate tests
template<
        typename T, unsigned int D,
        typename M=typename cmp_traits<T>::less_comparable
>
struct diag_predicate_test
{
        void operator()(diag<T,D> const& m) const {

                BOOST_CHECK ( fold<euclid::min>(m) == T() );
                BOOST_CHECK ( fold<euclid::max>(m) == T() );
                BOOST_CHECK ( forall<euclid::positive>(m) == false );
                BOOST_CHECK ( forall<euclid::negative>(m) == false );
                BOOST_CHECK ( forall<euclid::not_positive>(m) == true );
                BOOST_CHECK ( forall<euclid::not_negative>(m) == true );
        }

        void operator()(diag<T,D> const& m, T t) const {
                BOOST_CHECK ( fold<euclid::min>(m) == (t<T()||D==1?t:T()) );
                BOOST_CHECK ( fold<euclid::max>(m) == (t>T()||D==1?t:T()) );
                BOOST_CHECK ( forall<euclid::positive>(m) == (D==1&&t>T()) );
                BOOST_CHECK ( forall<euclid::negative>(m) == (D==1&&t<T()) );
                BOOST_CHECK ( forall<euclid::not_positive>(m) == (t<T()) );
                BOOST_CHECK ( forall<euclid::not_negative>(m) == (t>T()) );
        }
};

template<typename T, unsigned int D>
struct diag_predicate_test<T,D,false_type> {
        void operator()(diag<T,D> const&) const {}
        void operator()(diag<T,D> const&, T) const {}
};


// perform diagonal matrix component access tests (matrix-like version)
template<typename T, unsigned int D>
void test_diagonal_matrix_component_access()
{
        T t0 = T(), a0[D], a[D];
        euclid::diag<T,D> m1(t0), m2(t0);
        std::fill(a0, a0+D, t0);
        diag_predicate_test<T,D>()(m1);
        diag_predicate_test<T,D>()(m2);
        for ( unsigned int i0=0; i0<D; ++i0 ) {
                T t = init<T>();
                a0[i0] = m1[i0] = m2.at(i0) = t;
                BOOST_CHECK(count_if(a0, a0+D, bind2nd(equal_to<T>(), t))==1);
                BOOST_CHECK_EQUAL_COLLECTIONS(a0, a0+D, a, copy(m1,a));
                BOOST_CHECK_EQUAL_COLLECTIONS(a0, a0+D, a, copy(m2,a));
                BOOST_CHECK ( m1 == m2 );
                BOOST_CHECK ( ! (m1 != m2) );
                diag_predicate_test<T,D>()(m1, t);
                diag_predicate_test<T,D>()(m2, t);
                for ( unsigned int i=0; i<D; ++i )
                        if ( i==i0 ) {
                                BOOST_CHECK( (m1[i] == t) );
                                BOOST_CHECK( (m1.at(i) == t) );
                                BOOST_CHECK( (m2[i] == t) );
                                BOOST_CHECK( (m2.at(i) == t) );
                        }
                        else {
                                BOOST_CHECK( (m1[i] == t0) );
                                BOOST_CHECK( (m1.at(i) == t0) );
                                BOOST_CHECK( (m2[i] == t0) );
                                BOOST_CHECK( (m2.at(i) == t0) );
                        }
                a0[i0] = m1[i0] = m2.at(i0) = t0;
                BOOST_CHECK_EQUAL_COLLECTIONS(a0, a0+D, a, copy(m1,a));
                BOOST_CHECK_EQUAL_COLLECTIONS(a0, a0+D, a, copy(m2,a));
        }
};


// perform diagonal matrix component access tests (vector-like version)
template<typename T, unsigned int D, unsigned int I>
struct test_diag_component_access
{
        typedef diag<T,D> mtrx;

        test_diag_component_access(mtrx& u1, mtrx& u2, T* b1, T* b2){
                test_diag_component_access<T,D,I-1>(u1, u2, b1, b2);
                T a2[D];
                T t1(init<T>(2*(I-1)+D));
                T t2(init<T>(2*(I-1)+D+1));

                // set initial value for vector operation tests
                u1[I-1] = t1; b1[I-1] = t1;
                u2[I-1] = t2; b2[I-1] = t2;
                BOOST_CHECK_EQUAL_COLLECTIONS(a2, copy(u1, a2), b1, b1+D);
                BOOST_CHECK_EQUAL_COLLECTIONS(a2, copy(u2, a2), b2, b2+D);

        }
};


template<typename T, unsigned int D>
struct test_diag_component_access<T,D,0>
{
        test_diag_component_access(diag<T,D>&, diag<T,D>, T*, T*) {
                BOOST_MESSAGE(
                        "test diag dimensions with ["
                        "T = " << type<T>::name() << ", "
                        "D = " << D << "]"
                );
        }
};


// traits to exclude modulo test for undefined cases
template<typename T, unsigned int D, typename M=typename modulo_traits<T,T>::has_modulo>
struct diag_mod_operator_test { diag_mod_operator_test(
                diag<T,D> const& m1, diag<T,D> const& m2,
                T t2, T* a0, T* a1, T* a2, T* a3,
                vec<T,D> const& v1, vec<T,D> const& v2
        ) {
                transform(a1, a1+D, a3, bind2nd(std::modulus<T>(), t2));
                BOOST_CHECK_EQUAL_COLLECTIONS(a0, copy(m1%t2,a0), a3, a3+D);
                BOOST_CHECK(m1%t2 == map(m1,bind2nd(std::modulus<T>(),t2)));
                BOOST_CHECK(m1%t2 == join<euclid::modulus>(m1,diag<T,D>(t2)));
                transform(a1, a1+D, a2, a3, std::modulus<T>());
                BOOST_CHECK_EQUAL_COLLECTIONS(a0, copy(m1%m2,a0), a3, a3+D);
                transform(a1, a1+D, a2, a3, std::modulus<T>());
                BOOST_CHECK_EQUAL_COLLECTIONS(a0, copy(v1%m2,a0), a3, a3+D);
        }
};

template<typename T, unsigned int D>
struct diag_mod_operator_test<T,D,false_type> { diag_mod_operator_test(
        diag<T,D> const&, diag<T,D> const&,
        T, T*, T*, T*, T*,
        vec<T,D> const&, vec<T,D> const&) {}
};


// diagonal matrix norm test
template<typename T, unsigned int D, typename F=typename float_traits<T>::is_float>
struct diag_norm_test {
        diag_norm_test(diag<T,D> const& v, T *a) {
                BOOST_CHECK_CLOSE(pnorm<2>(v),inner_product(a,a+D,a,T()),1e-4);
        }
};

template<typename T, unsigned int D>
struct diag_norm_test<T,D,false_type> {
        diag_norm_test(diag<T,D> const& v, T *a) {
                BOOST_CHECK_EQUAL(pnorm<2>(v), inner_product(a, a+D, a, T()));
        }
};


// perform diagonal matrix tests sizes up to DxD recursively
template<int L, typename T, unsigned int D> struct diag_test
{
        typedef diag<T,D> mtrx;

        diag_test() {
                // first go down recursively
                diag_test<L,T,D-1>();

                // init values
                T t0 = T(), t1(init<T>(0)), t2(init<T>(D));
                T a0[D], a1[D], a2[D], a3[D];

                // init test
                mtrx m0;        // default constructor
                mtrx m1(t1);    // init value
                mtrx m2(t2);    // another init value
                mtrx m3(m2);    // copy constructor

                BOOST_CHECK(int(D) == count_if(a0,
                        copy(m0, a0), bind2nd(equal_to<T>(), t0)) );
                BOOST_CHECK(int(D) == count_if(a1,
                        copy(m1, a1), bind2nd(equal_to<T>(), t1)) );
                BOOST_CHECK(int(D) == count_if(a2,
                        copy(m2, a2), bind2nd(equal_to<T>(), t2)) );
                BOOST_CHECK(int(D) == count_if(a3,
                        copy(m3, a3), bind2nd(equal_to<T>(), t2)) );

                // relational operators
                BOOST_CHECK( (m2 == m3) );
                BOOST_CHECK( ! (m2 != m3 ) );

                // asignment operator
                m0 = m2;
                BOOST_CHECK(int(D) == count_if(a3,
                        copy(m0, a3), bind2nd(equal_to<T>(), t2)) );

                // relational operators
                BOOST_CHECK( (m2 == m0) );
                BOOST_CHECK( ! (m2 != m0 ) );

                // component access test
                test_diag_component_access<T,D,D>(m1, m2, a1, a2);
                test_diagonal_matrix_component_access<T,D>();

                BOOST_CHECK_EQUAL( (m1 == m2), equal(a1, a1+D, a2) );
                BOOST_CHECK_EQUAL( (m1 != m2), ! equal(a1, a1+D, a2) );

                // use arbitary values
                fill(a1, a1+D);
                fill(a2, a2+D);

                copy(a1, m1);
                copy(a2, m2);

                BOOST_CHECK_EQUAL( (m1 == m2), equal(a1, a1+D, a2) );
                BOOST_CHECK_EQUAL( (m1 != m2), ! equal(a1, a1+D, a2) );

                // arithmetic operators
                transform(a1, a1+D, a3, std::negate<T>());
                BOOST_CHECK_EQUAL_COLLECTIONS(a0, copy(-m1,a0), a3, a3+D);
                transform(a1, a1+D, a2, a3, std::plus<T>());
                BOOST_CHECK_EQUAL_COLLECTIONS(a0, copy(m1+m2,a0), a3, a3+D);
                transform(a1, a1+D, a2, a3, std::minus<T>());
                BOOST_CHECK_EQUAL_COLLECTIONS(a0, copy(m1-m2,a0), a3, a3+D);

                transform(a1, a1+D, a3, bind2nd(std::multiplies<T>(), t2));
                BOOST_CHECK_EQUAL_COLLECTIONS(a0, copy(m1*t2,a0), a3, a3+D);
                transform(a2, a2+D, a3, bind1st(std::multiplies<T>(), t1));
                BOOST_CHECK_EQUAL_COLLECTIONS(a0, copy(t1*m2,a0), a3, a3+D);
                transform(a1, a1+D, a3, bind2nd(std::divides<T>(), t2));
                BOOST_CHECK_EQUAL_COLLECTIONS(a0, copy(m1/t2,a0), a3, a3+D);

                // arithmetic operations by STL Function objects
                BOOST_CHECK(-m1 == map(m1,std::negate<T>()));
                BOOST_CHECK(m1+m2 == join(m1,m2,std::plus<T>()));
                BOOST_CHECK(m1-m2 == join(m1,m2,std::minus<T>()));
                BOOST_CHECK(m1*t2 == map(m1,bind2nd(std::multiplies<T>(),t2)));
                BOOST_CHECK(t1*m2 == map(m2,bind1st(std::multiplies<T>(),t1)));
                BOOST_CHECK(m1/t2 == map(m1,bind2nd(std::divides<T>(),t2)));

                BOOST_CHECK(m1+m2 == join<euclid::plus>(m1,m2));
                BOOST_CHECK(m1-m2 == join<euclid::minus>(m1,m2));
                BOOST_CHECK(m1*t2 == join<euclid::multiplies>(m1,mtrx(t2)));
                BOOST_CHECK(t1*m2 == join<euclid::multiplies>(mtrx(t1),m2));
                BOOST_CHECK(m1/t2 == join<euclid::divides>(m1,mtrx(t2)));

                // fold and functors
                BOOST_CHECK(fold<std::plus>(m1) == accumulate(a1,a1+D,T(),std::plus<T>()));
                BOOST_CHECK(fold<std::plus>(m2) == accumulate(a2,a2+D,T(),std::plus<T>()));
                BOOST_CHECK(fold<euclid::plus>(m1) == accumulate(a1,a1+D,T(),std::plus<T>()));
                BOOST_CHECK(fold<euclid::plus>(m2) == accumulate(a2,a2+D,T(),std::plus<T>()));
                BOOST_CHECK(fold<std::multiplies>(m1) == accumulate(a1,a1+D,T(1),std::multiplies<T>()));
                BOOST_CHECK(fold<std::multiplies>(m2) == accumulate(a2,a2+D,T(1),std::multiplies<T>()));

                // diagonal matrix multiplication
                transform(a1, a1+D, a2, a3, std::multiplies<T>());
                BOOST_CHECK_EQUAL_COLLECTIONS(a0, copy(m1*m2,a0), a3, a3+D);
                transform(a1, a1+D, a2, a3, std::divides<T>());
                BOOST_CHECK_EQUAL_COLLECTIONS(a0, copy(m1/m2,a0), a3, a3+D);

                // diagonal matrix norm
                diag_norm_test<T,D>(m1, a1);
                diag_norm_test<T,D>(m2, a2);

                // matrix-vector multiplication
                vec<T,D> v1, v2;

                copy(a1, v1);
                copy(a2, v2);

                transform(a1, a1+D, a2, a3, std::multiplies<T>());
                BOOST_CHECK_EQUAL_COLLECTIONS(a0, copy(m1*v2,a0), a3, a3+D);
                transform(a1, a1+D, a2, a3, std::multiplies<T>());
                BOOST_CHECK_EQUAL_COLLECTIONS(a0, copy(v1*m2,a0), a3, a3+D);
                transform(a1, a1+D, a2, a3, std::divides<T>());
                BOOST_CHECK_EQUAL_COLLECTIONS(a0, copy(v1/m2,a0), a3, a3+D);

                diag_mod_operator_test<T,D>(m1, m2, t2, a0, a1, a2, a3, v1, v2);
        }
};


template<int L, typename T> struct diag_test<L,T,0>
{
        diag_test() {
                BOOST_MESSAGE(
                        "test diagonal matrix "
                        " with [T = " << type<T>::name() << "]"
                );
        }
};


#if EUCLID_TEST_LEVEL < 3
template<typename T, unsigned int D> struct diag_test<3,T,D> {};
#if EUCLID_TEST_LEVEL < 2
template<typename T, unsigned int D> struct diag_test<2,T,D> {};
#endif
#endif


BOOST_AUTO_UNIT_TEST( diag_tests )
{
        diag_test<1,int,4>();
        diag_test<2,unsigned int,4>();
        diag_test<2,long int,4>();
        diag_test<3,unsigned long int,4>();
        diag_test<2,float,4>();
        diag_test<1,double,4>();
        diag_test<1,std::complex<double>,4>();
}


/*****************************************/
/* diagonal matrix type conversion tests */
/*****************************************/

template<int L, typename T, typename U, unsigned int D>
struct diagonal_type_conversion_test
{
        diagonal_type_conversion_test() {
                // handle recursive cases first
                diagonal_type_conversion_test<L,T,U,D-1>();

                T t1(init<T>(0)); U t2(init<U>(D));
                T a0[D]; T a1[D]; U a2[D]; T a3[D];
                T *i1; U *i2; T* i3;

                diag<T,D> m1(t1);
                diag<U,D> m2(t2);
                diag<T,D> m3(m2);

                BOOST_CHECK(int(D) == count_if(a1,
                        copy(m1, a1), bind2nd(equal_to<T>(), t1)) );
                BOOST_CHECK(int(D) == count_if(a2,
                        copy(m2, a2), bind2nd(equal_to<U>(), t2)) );
                BOOST_CHECK(int(D) == count_if(a3,
                        copy(m3, a3), bind2nd(equal_to<T>(), T(t2))) );

                // STL doesn't seem to support multi-type operators
                for ( i1=a1, i2=a2, i3=a3; i3<a3+D; *i3++ = *i1++ + *i2++ );
                BOOST_CHECK_EQUAL_COLLECTIONS(a0, copy(m1+m2,a0), a3, a3+D);
                for ( i1=a1, i2=a2, i3=a3; i3<a3+D; *i3++ = *i1++ - *i2++ );
                BOOST_CHECK_EQUAL_COLLECTIONS(a0, copy(m1-m2,a0), a3, a3+D);

                for ( i1=a1, i3=a3; i3<a3+D; *i3++ = *i1++ * t2 );
                BOOST_CHECK_EQUAL_COLLECTIONS(a0, copy(m1*t2,a0), a3, a3+D);
                BOOST_CHECK_EQUAL_COLLECTIONS(a0, copy(t2*m1,a0), a3, a3+D);
                for ( i1=a1, i3=a3; i3<a3+D; *i3++ = *i1++ / t2 );
                BOOST_CHECK_EQUAL_COLLECTIONS(a0, copy(m1/t2,a0), a3, a3+D);

        }
};


template<int L, typename T, typename U>
struct diagonal_type_conversion_test<L,T,U,0>
{
        diagonal_type_conversion_test() { BOOST_MESSAGE(
                "test diagonal type conversion with ["
                "T = " << type<T>::name() << ", "
                "U = " << type<U>::name() << "]"
        ); }
};


#if EUCLID_TEST_LEVEL < 3
template<typename T, typename U, unsigned int D>
        struct diagonal_type_conversion_test<3,T,U,D> {};
#if EUCLID_TEST_LEVEL < 2
template<typename T, typename U, unsigned int D>
        struct diagonal_type_conversion_test<2,T,U,D> {};
#endif
#endif


BOOST_AUTO_UNIT_TEST( matrix_type_conversion_tests )
{
        diagonal_type_conversion_test<1,int, char, 4>();
        diagonal_type_conversion_test<3,unsigned int, char, 4>();
        diagonal_type_conversion_test<3,int,unsigned int, 4>();
        diagonal_type_conversion_test<3,unsigned int,int, 4>();

        diagonal_type_conversion_test<2,long int, char, 4>();
        diagonal_type_conversion_test<2,long int, int, 4>();
        diagonal_type_conversion_test<3,long int, unsigned int, 4>();
        diagonal_type_conversion_test<3,unsigned long int, char, 4>();
        diagonal_type_conversion_test<3,unsigned long int, int, 4>();
        diagonal_type_conversion_test<2,unsigned long int, unsigned int, 4>();
        diagonal_type_conversion_test<3,long int, unsigned long int, 4>();
        diagonal_type_conversion_test<3,unsigned long int, long int, 4>();

        diagonal_type_conversion_test<3,float,char, 4>();
        diagonal_type_conversion_test<2,float,int, 4>();
        diagonal_type_conversion_test<3,float,unsigned int, 4>();
        diagonal_type_conversion_test<2,float,long int, 4>();
        diagonal_type_conversion_test<3,float,unsigned long int, 4>();

        diagonal_type_conversion_test<2,double, char, 4>();
        diagonal_type_conversion_test<1,double, int, 4>();
        diagonal_type_conversion_test<2,double, long int, 4>();
        diagonal_type_conversion_test<2,double, float, 4>();

        diagonal_type_conversion_test<1,std::complex<double>, double, 4>();
}

