//  Boost matrix tests

//  Copyright (C) 2004-2009
//  Andreas Harnack (ah8 at freenet dot de)
//  version 0.0.4

//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.

//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.

//  You should have received a copy of the GNU General Public License along
//  with this program; if not, write to the Free Software Foundation, Inc.,
//  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.


#include <iostream>
#include <iterator>
#include <functional>
#include <numeric>
#include <complex>
#include "euclid.hpp"

using namespace euclid;
using namespace std;

#define BOOST_AUTO_TEST_MAIN
#include <boost/test/auto_unit_test.hpp>
#include <boost/test/floating_point_comparison.hpp>
#include <boost/numeric/ublas/matrix.hpp>

#ifndef EUCLID_TEST_LEVEL
#define EUCLID_TEST_LEVEL 3
#endif

// traits to print type names
template<typename T> struct type {
        static const char* name() { return "unknown"; } };
template<> struct type<char> {
        static const char* name() { return "char"; } };
template<> struct type<int> {
        static const char* name() { return "int"; } };
template<> struct type<unsigned int> {
        static const char* name() { return "unsigned int"; } };
template<> struct type<long int> {
        static const char* name() { return "long int"; } };
template<> struct type<unsigned long int> {
        static const char* name() { return "unsigned long int"; } };
template<> struct type<float> {
        static const char* name() { return "float"; } };
template<> struct type<double> {
        static const char* name() { return "double"; } };
template<> struct type< std::complex<double> > {
        static const char* name() { return "complex<double>"; } };


// traits to select init values
template<typename T> struct array { static int elem[]; };
template<typename T> int array<T>::elem[] = { 1, 2, 3, 4 };

template<> struct array<char> { static char elem[]; };
char array<char>::elem[] = { '0', ' ', '@', 'a', 'A' };

template<> struct array<int> { static int elem[]; };
int array<int>::elem[] = { 2, -3, 4, -5, 6, -7  };

template<> struct array<unsigned int> { static unsigned int elem[]; };
unsigned int array<unsigned int>::elem[] = { 2, 3, 4, 5, 6, 7  };

template<> struct array<long int> { static long int elem[]; };
long int array<long int>::elem[] = { -2, 3, -4, 5, -6, 7  };

template<> struct array<unsigned long int> { static unsigned long int elem[]; };
unsigned long int array<unsigned long int>::elem[] = { 2, 3, 4, 5, 6, 7 };

template<> struct array<float> { static float elem[]; };
float array<float>::elem[] = { -0.2, 1.3, -2.4, 3.5, -4.6, 5.7 };

template<> struct array<double> { static double elem[]; };
double array<double>::elem[] = { 1.2, -2.3, 3.4, -4.5, 5.6, -6.8 };

template<> struct array< std::complex<double> > { static double elem[]; };
double array< std::complex<double> >::elem[] = { -1.2, 2.3, -3.4, 4.5, -5.6, 6.8 };


template<typename T> T init()
{
        const int size = sizeof(array<T>::elem)/sizeof(*array<T>::elem);
        static int i = 0;
        if ( i >= size ) i = 0;
        return array<T>::elem[i++];
}

template<typename T> T init(int i)
{
        const int size = sizeof(array<T>::elem)/sizeof(*array<T>::elem);
        while ( i<0 ) i+=size;
        while ( i>=size ) i-=size;
        return array<T>::elem[i];
}

template<typename T> T* fill(T *begin, T *end) 
{
        while ( begin != end )
                *begin++ = init<T>();
        return end;
}


// helpers to copy data between matrices and arrays
template<typename T, unsigned int M, unsigned int N>
T* mcopy(euclid::matrix<T,M,N> const& m, T* it) {
        for ( unsigned int i = 0; i<M; ++i)
                for ( unsigned int j=0; j<N; ++j )
                        *it++ = m(i,j);
        return it;
}

template<typename T, unsigned int M, unsigned int N>
T* mcopy(T* it, euclid::matrix<T,M,N>& m) {
        for ( unsigned int i = 0; i<M; ++i)
                for ( unsigned int j=0; j<N; ++j )
                        m(i,j) = *it++;
        return it;
}

template<typename T>
T* mcopy(boost::numeric::ublas::matrix<T> const& m, T* it) {
        for ( unsigned int i = 0; i<m.size1(); ++i)
                for ( unsigned int j=0; j<m.size2(); ++j )
                        *it++ = m(i,j);
        return it;
}

template<typename T>
T* mcopy(T* it, boost::numeric::ublas::matrix<T>& m) {
        for ( unsigned int i = 0; i<m.size1(); ++i)
                for ( unsigned int j=0; j<m.size2(); ++j )
                        m(i,j) = *it++;
        return it;
}


template<class OutputIterator> struct copy_out
{
        OutputIterator it;
        copy_out(OutputIterator i) : it(i) {}
        template<class T> void operator()(T const& t) { *it = t; ++it; }
};

template<class InputIterator> struct copy_in
{
        InputIterator it;
        copy_in(InputIterator i) : it(i) {}
        template<class T> void operator()(T& t) { t = *it; ++it; }
};



template<typename OutputIterator, typename T, unsigned int M, unsigned int N>
OutputIterator copy(matrix<T,M,N> const& m, OutputIterator i) {
//      BOOST_MESSAGE ( m );
        return foreach(m, copy_out<OutputIterator>(i)).it; }

template<typename InputIterator, typename T, unsigned int M, unsigned int N>
InputIterator copy(InputIterator i, matrix<T,M,N>& m) {
        copy_in<InputIterator> in(i);
        return m.foreach(in).it; }


// some operators are undefined for some base types,
// traits to exclude undefined operations

struct true_type {};
struct false_type {};


// modulo defined only for integers
template<typename T, typename U> struct modulo_traits {
        typedef true_type has_modulo; };

template<> struct modulo_traits<float, float> {
        typedef false_type has_modulo; };

template<> struct modulo_traits<double, double> {
        typedef false_type has_modulo; };

template<typename T> struct modulo_traits<complex<T>, complex<T> > {
        typedef false_type has_modulo; };


// choose floating point close check
template<typename T> struct float_traits {
        typedef false_type is_float; };

template<> struct float_traits<float> {
        typedef true_type is_float; };

template<> struct float_traits<double> {
        typedef true_type is_float; };


// choose comparable types
template<typename T> struct cmp_traits {
        typedef true_type less_comparable; };

template<typename T> struct cmp_traits<complex<T> > {
        typedef false_type less_comparable; };



/*******************/
/*  matrix tests   */
/*******************/

// perform matrix predicate tests
template<
        typename T, unsigned int M, unsigned int N,
        typename M=typename cmp_traits<T>::less_comparable
>
struct matrix_predicate_test
{
        void operator()(matrix<T,M,N> const& m) const {
                BOOST_CHECK ( fold<euclid::min>(m) == T() );
                BOOST_CHECK ( fold<euclid::max>(m) == T() );
                BOOST_CHECK ( forall<euclid::positive>(m) == false );
                BOOST_CHECK ( forall<euclid::negative>(m) == false );
                BOOST_CHECK ( forall<euclid::not_positive>(m) == true );
                BOOST_CHECK ( forall<euclid::not_negative>(m) == true );
        }

        void operator()(matrix<T,M,N> const& m, T t) const {
                BOOST_CHECK ( fold<euclid::min>(m) == (t<T()||M*N==1?t:T()) );
                BOOST_CHECK ( fold<euclid::max>(m) == (t>T()||M*N==1?t:T()) );
                BOOST_CHECK ( forall<euclid::positive>(m) == (N*M==1&&t>T()) );
                BOOST_CHECK ( forall<euclid::negative>(m) == (M*N==1&&t<T()) );
                BOOST_CHECK ( forall<euclid::not_positive>(m) == (t<T()) );
                BOOST_CHECK ( forall<euclid::not_negative>(m) == (t>T()) );
        }
};

template<typename T, unsigned int M, unsigned int N>
struct matrix_predicate_test<T,M,N,false_type> {
        void operator()(matrix<T,M,N> const&) const {}
        void operator()(matrix<T,M,N> const&, T) const {}
};


// perform matrix to diagonal conversion tests
template<       typename T, unsigned int M, unsigned int N>
struct test_matrix_diag_conversion
{
        void operator()(unsigned int i, unsigned int j, matrix<T,M,N> const& m) {}
};

template<typename T, unsigned int D>
struct test_matrix_diag_conversion<T,D,D> {
        void operator()(unsigned int i, unsigned int j, matrix<T,D,D> const& m) {
                diag<T,D> d = diagonal(m);
                for ( unsigned int k = 0; k<D; ++k )
                        BOOST_CHECK ( d[k] == m(k,k) );
        }
};


// perform matrix component access tests
template<typename T, unsigned int M, unsigned int N>
void test_matrix_component_access()
{
        T t0 = T(), a0[M*N], a[M*N];
        euclid::matrix<T,M,N> m1(t0), m2(t0), m3(t0);
        std::fill(a0, a0+M*N, t0);
        matrix_predicate_test<T,M,N>()(m1);
        matrix_predicate_test<T,M,N>()(m2);
        matrix_predicate_test<T,M,N>()(m3);
        for ( unsigned int i0=0; i0<M; ++i0 )
                for ( unsigned int j0=0; j0<N; ++j0 ) {
                        T t = init<T>();
                        a0[N*i0+j0] = m1(i0,j0) = m2[i0][j0] = m3.at(i0,j0) = t;
                        test_matrix_diag_conversion<T,M,N>()(i0, j0, m1);
                        BOOST_CHECK(count_if(a0, a0+M*N, bind2nd(equal_to<T>(), t))==1);
                        BOOST_CHECK_EQUAL_COLLECTIONS(a0, a0+M*N, a, mcopy(m1,a));
                        BOOST_CHECK_EQUAL_COLLECTIONS(a0, a0+M*N, a, mcopy(m2,a));
                        BOOST_CHECK_EQUAL_COLLECTIONS(a0, a0+M*N, a, mcopy(m3,a));
                        BOOST_CHECK ( m1 == m2 );
                        BOOST_CHECK ( m1 == m3 );
                        BOOST_CHECK ( m2 == m3 );
                        BOOST_CHECK ( ! (m1 != m2) );
                        BOOST_CHECK ( ! (m1 != m3) );
                        BOOST_CHECK ( ! (m2 != m3) );
                        matrix_predicate_test<T,M,N>()(m1, t);
                        matrix_predicate_test<T,M,N>()(m2, t);
                        matrix_predicate_test<T,M,N>()(m3, t);
                        for ( unsigned int i=0; i<M; ++i )
                                for ( unsigned int j=0; j<N; ++j )
                                        if ( i==i0 && j==j0 ) {
                                                BOOST_CHECK( (m1(i,j) == t) );
                                                BOOST_CHECK( (m1[i][j] == t) );
                                                BOOST_CHECK( (m1.at(i,j) == t) );
                                                BOOST_CHECK( (m2(i,j) == t) );
                                                BOOST_CHECK( (m2[i][j] == t) );
                                                BOOST_CHECK( (m2.at(i,j) == t) );
                                                BOOST_CHECK( (m3(i,j) == t) );
                                                BOOST_CHECK( (m3[i][j] == t) );
                                                BOOST_CHECK( (m3.at(i,j) == t) );
                                        }
                                        else {
                                                BOOST_CHECK( (m1(i,j) == t0) );
                                                BOOST_CHECK( (m1[i][j] == t0) );
                                                BOOST_CHECK( (m1.at(i,j) == t0) );
                                                BOOST_CHECK( (m2(i,j) == t0) );
                                                BOOST_CHECK( (m2[i][j] == t0) );
                                                BOOST_CHECK( (m2.at(i,j) == t0) );
                                                BOOST_CHECK( (m3(i,j) == t0) );
                                                BOOST_CHECK( (m3[i][j] == t0) );
                                                BOOST_CHECK( (m3.at(i,j) == t0) );
                                        }
                        a0[N*i0+j0] = m1(i0,j0) = m2[i0][j0] = m3.at(i0,j0) = t0;
                        BOOST_CHECK_EQUAL_COLLECTIONS(a0, a0+M*N, a, mcopy(m1,a));
                        BOOST_CHECK_EQUAL_COLLECTIONS(a0, a0+M*N, a, mcopy(m2,a));
                        BOOST_CHECK_EQUAL_COLLECTIONS(a0, a0+M*N, a, mcopy(m3,a));
                }
};


// perform matrix multiplication tests for all size combinations
template<typename T, unsigned int K, unsigned int M, unsigned int N>
struct matrix_prod_test_rows
{
        typedef euclid::matrix<T,M,K> mtrx;
        typedef boost::numeric::ublas::matrix<T> umtx;

        matrix_prod_test_rows(mtrx const& m1, umtx const& u1) {
                matrix_prod_test_rows<T,K,M,N-1>(m1, u1);
                euclid::matrix<T,K,N> m2;
                umtx u2(K,N), u3(M,N);
                T a0[M*N], a2[K*N], a3[M*N];
                fill(a2, a2+K*N); mcopy(a2, m2); mcopy(a2, u2);
                BOOST_MESSAGE( "$$$ M=" << M << ", K=" << K << ", N=" << N );
                BOOST_MESSAGE( m1 << m2 << m1*m2 );
                BOOST_CHECK_EQUAL_COLLECTIONS(a0, mcopy(m1*m2, a0), a3, mcopy(u3=prod(u1,u2), a3));
        }
};

template<typename T, unsigned int K, unsigned int M>
struct matrix_prod_test_rows<T,K,M,0>
{
        typedef euclid::matrix<T,M,K> mtrx;
        typedef boost::numeric::ublas::matrix<T> umtx;

        matrix_prod_test_rows(mtrx const&, umtx const&) {
                BOOST_MESSAGE(
                        "### test matrix prod operator by rows with [T="
                        << type<T>::name() << ", K=" << K << ", M=" << M << "]"
                );
        }
};


template<typename T, unsigned int K, unsigned int M, unsigned int N>
struct matrix_prod_test_columns
{
        typedef euclid::matrix<T,K,N> mtrx;
        typedef boost::numeric::ublas::matrix<T> umtx;

        matrix_prod_test_columns(mtrx const& m2, umtx const& u2) {
                matrix_prod_test_columns<T,K,M-1,N>(m2, u2);
                euclid::matrix<T,M,K> m1;
                umtx u1(M,K), u3(M,N);
                T a0[M*N], a2[M*K], a3[M*N];
                fill(a2, a2+M*K); mcopy(a2, m1); mcopy(a2, u1);
                BOOST_MESSAGE( "$$$ M=" << M << ", K=" << K << ", N=" << N );
                BOOST_MESSAGE( m1 << m2 << m1*m2 );
                BOOST_CHECK_EQUAL_COLLECTIONS(a0, mcopy(m1*m2, a0), a3, mcopy(u3=prod(u1,u2), a3));
        }
};

template<typename T, unsigned int K, unsigned int N>
struct matrix_prod_test_columns<T,K,0,N>
{
        typedef euclid::matrix<T,K,N> mtrx;
        typedef boost::numeric::ublas::matrix<T> umtx;

        matrix_prod_test_columns(mtrx const&, umtx const&) {
                BOOST_MESSAGE(
                        "### test matrix prod operator by columns with [T="
                        << type<T>::name() << ", K=" << K << ", N=" << N << "]"
                );
        }
};


template<typename T, unsigned int M, unsigned int N> struct matrix_prod_test
{
        typedef matrix<T,M,N> mtrx;
        typedef boost::numeric::ublas::matrix<T> umtx;

        matrix_prod_test(
                T* a0, mtrx const& m1, mtrx const& m2,
                T* a3, umtx const& u1, umtx const& u2, umtx& u3
        ) {
                if ( N > M ) 
                        matrix_prod_test_rows<T,N,M,N>(m1,u1);
                else
                        matrix_prod_test_columns<T,M,M,N>(m2,u2);
        }
};

template<typename T, unsigned int D> struct matrix_prod_test<T,D,D>
{
        typedef euclid::matrix<T,D,D> mtrx;
        typedef boost::numeric::ublas::matrix<T> umtx;

        matrix_prod_test(
                T* a0, mtrx const& m1, mtrx const& m2,
                T* a3, umtx const& u1, umtx const& u2, umtx& u3
        ) {
                BOOST_MESSAGE( "$$$ M=" << D << ", K=" << D << ", N=" << D );
                BOOST_MESSAGE( m1 << m2 << m1*m2 );
                BOOST_CHECK_EQUAL_COLLECTIONS(a0, mcopy(m1*m2, a0), a3, mcopy(u3=prod(u1,u2), a3));
                matrix_prod_test_rows<T,D,D,D-1>(m1, u1);
                matrix_prod_test_columns<T,D,D-1,D>(m2, u2);
        }
};


// traits to exclude modulo test for undefined cases
template<
        typename T, unsigned int M, unsigned int N,
        typename M=typename modulo_traits<T,T>::has_modulo
>
struct matrix_mod_operator_test {
        matrix_mod_operator_test(matrix<T,M,N> const& m1,
                matrix<T,M,N> const& m2, T t2, T* a0, T* a1, T* a2, T* a3
        ) {
                transform(a1, a1+M*N, a3, bind2nd(std::modulus<T>(), t2));
                BOOST_CHECK_EQUAL_COLLECTIONS(a0, copy(m1%t2,a0), a3, a3+M*N);
                BOOST_CHECK(m1%t2 == map(m1,bind2nd(std::modulus<T>(),t2)));
                BOOST_CHECK(m1%t2 == join<euclid::modulus>(m1,matrix<T,M,N>(t2)));
        }
};

template<typename T, unsigned int M, unsigned int N>
struct matrix_mod_operator_test<T,M,N,false_type> { matrix_mod_operator_test(
        matrix<T,M,N> const&, matrix<T,M,N> const&, T, T*, T*, T*, T*) {}
};


// perform matrix tests
template<typename T, unsigned int M,unsigned int N> struct matrix_test
{
        typedef euclid::matrix<T,M,N> mtrx;
        enum { E = mtrx::size };

        matrix_test() {

                // init values
                T t0 = T(), t1(init<T>(0)), t2(init<T>(M+N));
                T a0[E], a1[E], a2[E], a3[E];

                // init test
                mtrx m0;        // default constructor
                mtrx m1(t1);    // init value
                mtrx m2(t2);    // another init value
                mtrx m3(m2);    // copy constructor

                BOOST_CHECK(int(E) == count_if(a0,
                        mcopy(m0, a0), bind2nd(equal_to<T>(), t0)) );
                BOOST_CHECK(int(E) == count_if(a1,
                        mcopy(m1, a1), bind2nd(equal_to<T>(), t1)) );
                BOOST_CHECK(int(E) == count_if(a2,
                        mcopy(m2, a2), bind2nd(equal_to<T>(), t2)) );
                BOOST_CHECK(int(E) == count_if(a3,
                        mcopy(m3, a3), bind2nd(equal_to<T>(), t2)) );

                // relational operators
                BOOST_CHECK( (m2 == m3) );
                BOOST_CHECK( ! (m2 != m3 ) );

                // asignment operator
                m0 = m2;
                BOOST_CHECK(int(E) == count_if(a3,
                        copy(m0, a3), bind2nd(equal_to<T>(), t2)) );

                // relational operators
                BOOST_CHECK( (m2 == m0) );
                BOOST_CHECK( ! (m2 != m0 ) );

                // component access test
                test_matrix_component_access<T,N,M>();

                BOOST_CHECK_EQUAL( (m1 == m2), equal(a1, a1+E, a2) );
                BOOST_CHECK_EQUAL( (m1 != m2), ! equal(a1, a1+E, a2) );

                // use arbitary values
                fill(a1, a1+E);
                fill(a2, a2+E);

                mcopy(a1, m1);
                mcopy(a2, m2);

                BOOST_CHECK_EQUAL( (m1 == m2), equal(a1, a1+E, a2) );
                BOOST_CHECK_EQUAL( (m1 != m2), ! equal(a1, a1+E, a2) );

                // arithmetic operators
                transform(a1, a1+E, a3, std::negate<T>());
                BOOST_CHECK_EQUAL_COLLECTIONS(a0, copy(-m1,a0), a3, a3+E);
                transform(a1, a1+E, a2, a3, std::plus<T>());
                BOOST_CHECK_EQUAL_COLLECTIONS(a0, copy(m1+m2,a0), a3, a3+E);
                transform(a1, a1+E, a2, a3, std::minus<T>());
                BOOST_CHECK_EQUAL_COLLECTIONS(a0, copy(m1-m2,a0), a3, a3+E);

                transform(a1, a1+E, a3, bind2nd(std::multiplies<T>(), t2));
                BOOST_CHECK_EQUAL_COLLECTIONS(a0, copy(m1*t2,a0), a3, a3+E);
                transform(a2, a2+E, a3, bind1st(std::multiplies<T>(), t1));
                BOOST_CHECK_EQUAL_COLLECTIONS(a0, copy(t1*m2,a0), a3, a3+E);
                transform(a1, a1+E, a3, bind2nd(std::divides<T>(), t2));
                BOOST_CHECK_EQUAL_COLLECTIONS(a0, copy(m1/t2,a0), a3, a3+E);

                // arithmetic operations by STL Function objects
                BOOST_CHECK(-m1 == map(m1,std::negate<T>()));
                BOOST_CHECK(m1+m2 == join(m1,m2,std::plus<T>()));
                BOOST_CHECK(m1-m2 == join(m1,m2,std::minus<T>()));
                BOOST_CHECK(m1*t2 == map(m1,bind2nd(std::multiplies<T>(),t2)));
                BOOST_CHECK(t1*m2 == map(m2,bind1st(std::multiplies<T>(),t1)));
                BOOST_CHECK(m1/t2 == map(m1,bind2nd(std::divides<T>(),t2)));

                BOOST_CHECK(m1+m2 == join<euclid::plus>(m1,m2));
                BOOST_CHECK(m1-m2 == join<euclid::minus>(m1,m2));
                BOOST_CHECK(m1*t2 == join<euclid::multiplies>(m1,mtrx(t2)));
                BOOST_CHECK(t1*m2 == join<euclid::multiplies>(mtrx(t1),m2));
                BOOST_CHECK(m1/t2 == join<euclid::divides>(m1,mtrx(t2)));

                matrix_mod_operator_test<T,M,N>(m1, m2, t2, a0, a1, a2, a3);

                // fold and functors
                BOOST_CHECK(fold<std::plus>(m1) == accumulate(a1,a1+E,T(),std::plus<T>()));
                BOOST_CHECK(fold<std::plus>(m2) == accumulate(a2,a2+E,T(),std::plus<T>()));
                BOOST_CHECK(fold<euclid::plus>(m1) == accumulate(a1,a1+E,T(),std::plus<T>()));
                BOOST_CHECK(fold<euclid::plus>(m2) == accumulate(a2,a2+E,T(),std::plus<T>()));
                BOOST_CHECK(fold<std::multiplies>(m1) == accumulate(a1,a1+E,T(1),std::multiplies<T>()));
                BOOST_CHECK(fold<std::multiplies>(m2) == accumulate(a2,a2+E,T(1),std::multiplies<T>()));

                // tests matrix operations based on boost uBlas
                boost::numeric::ublas::matrix<T> u1 (M,N);
                boost::numeric::ublas::matrix<T> u2 (M,N);
                boost::numeric::ublas::matrix<T> u3 (M,N);

                mcopy(a1, u1);
                mcopy(a2, u2);
                
                BOOST_CHECK_EQUAL_COLLECTIONS(a0, mcopy(-m1, a0), a3, mcopy(u3=-u1, a3));
                BOOST_CHECK_EQUAL_COLLECTIONS(a0, mcopy(m1+m2, a0), a3, mcopy(u3=u1+u2, a3));
                BOOST_CHECK_EQUAL_COLLECTIONS(a0, mcopy(m1-m2, a0), a3, mcopy(u3=u1-u2, a3));
                BOOST_CHECK_EQUAL_COLLECTIONS(a0, mcopy(m1*t2, a0), a3, mcopy(u3=u1*t2, a3));
                BOOST_CHECK_EQUAL_COLLECTIONS(a0, mcopy(m1/t2, a0), a3, mcopy(u3=u1/t2, a3));

                matrix_prod_test<T,M,N>(a0, m1, m2, a3, u1, u2, u3);

                // test transpose
                boost::numeric::ublas::matrix<T> ut (N,M);
                euclid::matrix<T,N,M> mt;
                BOOST_CHECK_EQUAL_COLLECTIONS(a0, mcopy((mt=trans(m1)), a0), a3, mcopy((ut=trans(u1)), a3));
                BOOST_CHECK_EQUAL_COLLECTIONS(a0, mcopy((mt=trans(m2)), a0), a3, mcopy((ut=trans(u2)), a3));

                // test vector - matrix multiplication
                boost::numeric::ublas::matrix<T> um(M,1), un(1,N), um1(1,M), un1(N,1);
                euclid::vec<T,M> vm1;
                euclid::vec<T,N> vn1;
                T am0[M], an0[N], am1[M], an1[N], am3[M], an3[N];

                fill(am1, am1+M); vm1.map(am1); mcopy(am1, um1);
                fill(an1, an1+N); vn1.map(an1); mcopy(an1, un1);

                BOOST_CHECK_EQUAL_COLLECTIONS(am0, (m1*vn1).copy(am0), am3, mcopy(um=prod(u1,un1),am3));
                BOOST_CHECK_EQUAL_COLLECTIONS(an0, (vm1*m1).copy(an0), an3, mcopy(un=prod(um1,u1),an3));
        }
};


// count down columns recursively for M rows
template<typename T, unsigned int M,unsigned int N> struct matrix_test_rows
{
        matrix_test_rows() {
                matrix_test_rows<T,M,N-1>();
                matrix_test<T,M,N>();
        }
};

template<typename T, unsigned int M> struct matrix_test_rows<T,M,0>
{
        matrix_test_rows() {
                BOOST_MESSAGE(
                        "### test matrix rows with [T = " 
                                << type<T>::name() << ", M = " << M << "]"
                );
        }
};

// count down rows recursively for N columns
template<typename T, unsigned int M,unsigned int N> struct matrix_test_columns
{
        matrix_test_columns() {
                matrix_test_columns<T,M-1,N>();
                matrix_test<T,M,N>();
        }
};

template<typename T, unsigned int N> struct matrix_test_columns<T,0,N>
{
        matrix_test_columns() {
                BOOST_MESSAGE(
                        "### test matrix columns with [T = "
                                << type<T>::name() << ", N = " << N << "]"
                );
        }
};


// perform matrix test for all size combinations up to DxD
template<int L, typename T, unsigned int D> struct matrix_test_all
{
        matrix_test_all() {
                // first go down recursively
                matrix_test_all<L,T,D-1>();
                // then handle DxD
                matrix_test<T,D,D>();
                // count down columns recursively for D rows
                matrix_test_rows<T,D,D-1>();
                // count down rows recursively for D columns
                matrix_test_columns<T,D-1,D>();
        }
};

template<int L, typename T> struct matrix_test_all<L,T,0>
{
        matrix_test_all() {
                BOOST_MESSAGE(
                        "### test matrix "
                        " with [T = " << type<T>::name() << "]"
                );
        }
};


#if EUCLID_TEST_LEVEL < 3
template<typename T, unsigned int D> struct matrix_test_all<3,T,D> {};
#if EUCLID_TEST_LEVEL < 2
template<typename T, unsigned int D> struct matrix_test_all<2,T,D> {};
#endif
#endif


BOOST_AUTO_UNIT_TEST( matrix_tests )
{
        matrix_test_all<1,int,6>();
        matrix_test_all<2,unsigned int,4>();
        matrix_test_all<2,long int,4>();
        matrix_test_all<3,unsigned long int,4>();
        matrix_test_all<2,float,4>();
        matrix_test_all<1,double,4>();
        matrix_test_all<1,std::complex<double>,4>();
}


/********************************/
/* matrix type conversion tests */
/********************************/

template<int L, typename T, typename U, unsigned int D>
struct matrix_type_conversion_test
{
        matrix_type_conversion_test() {
                // handle recursive cases first
                matrix_type_conversion_test<L,T,U,D-1>();

                T t1(init<T>(0)); U t2(init<U>(D*D));
                T a0[D*D]; T a1[D*D]; U a2[D*D]; T a3[D*D];
                T *i1; U *i2; T* i3;

                matrix<T,D,D> m1(t1);
                matrix<U,D,D> m2(t2);
                matrix<T,D,D> m3(m2);

                BOOST_CHECK(int(D*D) == count_if(a1,
                        copy(m1, a1), bind2nd(equal_to<T>(), t1)) );
                BOOST_CHECK(int(D*D) == count_if(a2,
                        copy(m2, a2), bind2nd(equal_to<U>(), t2)) );
                BOOST_CHECK(int(D*D) == count_if(a3,
                        copy(m3, a3), bind2nd(equal_to<T>(), T(t2))) );

                // STL doesn't seem to support multi-type operators
                for ( i1=a1, i2=a2, i3=a3; i3<a3+D*D; *i3++ = *i1++ + *i2++ );
                BOOST_CHECK_EQUAL_COLLECTIONS(a0, copy(m1+m2,a0), a3, a3+D*D);
                for ( i1=a1, i2=a2, i3=a3; i3<a3+D*D; *i3++ = *i1++ - *i2++ );
                BOOST_CHECK_EQUAL_COLLECTIONS(a0, copy(m1-m2,a0), a3, a3+D*D);

                for ( i1=a1, i3=a3; i3<a3+D*D; *i3++ = *i1++ * t2 );
                BOOST_CHECK_EQUAL_COLLECTIONS(a0, copy(m1*t2,a0), a3, a3+D*D);
                BOOST_CHECK_EQUAL_COLLECTIONS(a0, copy(t2*m1,a0), a3, a3+D*D);
                for ( i1=a1, i3=a3; i3<a3+D*D; *i3++ = *i1++ / t2 );
                BOOST_CHECK_EQUAL_COLLECTIONS(a0, copy(m1/t2,a0), a3, a3+D*D);

        }
};


template<int L, typename T, typename U>
struct matrix_type_conversion_test<L,T,U,0>
{
        matrix_type_conversion_test() { BOOST_MESSAGE(
                "test matrix type conversion with ["
                "T = " << type<T>::name() << ", "
                "U = " << type<U>::name() << "]"
        ); }
};


#if EUCLID_TEST_LEVEL < 3
template<typename T, typename U, unsigned int D>
        struct matrix_type_conversion_test<3,T,U,D> {};
#if EUCLID_TEST_LEVEL < 2
template<typename T, typename U, unsigned int D>
        struct matrix_type_conversion_test<2,T,U,D> {};
#endif
#endif


BOOST_AUTO_UNIT_TEST( matrix_type_conversion_tests )
{
        matrix_type_conversion_test<1,int, char, 4>();
        matrix_type_conversion_test<3,unsigned int, char, 4>();
        matrix_type_conversion_test<3,int,unsigned int, 4>();
        matrix_type_conversion_test<3,unsigned int,int, 4>();

        matrix_type_conversion_test<2,long int, char, 4>();
        matrix_type_conversion_test<2,long int, int, 4>();
        matrix_type_conversion_test<3,long int, unsigned int, 4>();
        matrix_type_conversion_test<3,unsigned long int, char, 4>();
        matrix_type_conversion_test<3,unsigned long int, int, 4>();
        matrix_type_conversion_test<2,unsigned long int, unsigned int, 4>();
        matrix_type_conversion_test<3,long int, unsigned long int, 4>();
        matrix_type_conversion_test<3,unsigned long int, long int, 4>();

        matrix_type_conversion_test<3,float,char, 4>();
        matrix_type_conversion_test<2,float,int, 4>();
        matrix_type_conversion_test<3,float,unsigned int, 4>();
        matrix_type_conversion_test<2,float,long int, 4>();
        matrix_type_conversion_test<3,float,unsigned long int, 4>();

        matrix_type_conversion_test<2,double, char, 4>();
        matrix_type_conversion_test<1,double, int, 4>();
        matrix_type_conversion_test<2,double, long int, 4>();
        matrix_type_conversion_test<2,double, float, 4>();

        matrix_type_conversion_test<1,std::complex<double>, double, 4>();
}

