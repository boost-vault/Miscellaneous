//  Test cases for the Euclid library.

//  Copyright (C) 2004-2009
//  Andreas Harnack (ah8 at freenet dot de)
//  version 0.0.4

//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.

//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.

//  You should have received a copy of the GNU General Public License along
//  with this program; if not, write to the Free Software Foundation, Inc.,
//  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.


#include "euclid.hpp"
#include <iostream>



typedef int scalar;

// definitions for a two dimensional application
typedef euclid::dim<scalar,0> dimX;
typedef euclid::dim<scalar,1> dimY;
typedef euclid::vec<scalar,2> vect;

// additioanl definitions for a three dimensional application
typedef euclid::dim<scalar,2> dimZ;
typedef euclid::vec<scalar,3> vec3;



void foo(vect v) {
        std::cout << v << std::endl;
}

void bar(dimX x) {
        std::cout << x << std::endl;
}

void bar(dimX x, dimY y) {
        std::cout << x << ',' << y << std::endl;
}


int main()
{
        dimX x(-1);
        dimY y(-2);
        dimZ z(-3);
        vect v;
        vec3 v3((x,y,z));

        std::cout << v3 << std::endl; // get rid of 'unused variable' warning

#ifdef ERROR_A01 // no matching function for call
        dimX x0(y);
#elif ERROR_A02 // constructor is private
        vect v0(v3);
#elif ERROR_A03 // constructor is private
        vect v0( (dimX(1),dimY(2),dimZ(3)) );
#elif ERROR_A04 // constructor is private
        vec3 v0(v);
#elif ERROR_A05 // constructor is private
        vec3 v0( (dimX(1),dimY(2)) );
#endif
        foo( v );                       // ok, obviously :-)
        foo( (x,y) );               // ok, tuple initializer
        foo( (dimX(1),dimY(2)) );       // ok, tuple initializer

#ifdef ERROR_B01 // conversion from `int' to non-scalar type `vect' requested
        foo( (1,2) );
#elif ERROR_B02 // no matching function for call to `vec<T,2>(dim<T,0>, vec<T,1>)'
        foo( (dimX(1),dimX(2)) );
#endif
        foo( (dimY(1),dimY(2)) );       // NOT DETECTED


        foo( dimX(1) );                 // ok, calls foo( (dimX(2),dimY(0)) );
        foo( dimY(2) );                 // ok, calls foo( (dimX(0),dimY(2)) );

#ifdef ERROR_B03 // constructor is private
        foo( v3 );
#elif ERROR_B04 // constructor is private
        foo( (x,y,z) );
#elif ERROR_B05 // constructor is private
        foo( (dimX(1),dimY(2),dimZ(3)) );
#endif
        std::cout << std::endl;

        bar( x, y );                    // ok
        bar( dimX(1), dimY(2) );        // ok
        bar( dimX(v), dimY(v) );        // ok, explicit conversion
        bar( v, v );                    // ok, call bar(dimx(v0), dimY(v0))
#ifdef ERROR_C02 // type mismatch
        bar( x, x );
#elif ERROR_C03 // type mismatch
        bar( y, y );
#elif ERROR_C04 // type mismatch
        bar( y, x );
#endif


#ifdef ERROR_D01 // no match for 'operator+='
        x += y;
#elif ERROR_D02 // no match for 'operator-='
        x -= y;
#elif ERROR_D03 // no match for 'operator+='
        y += x;
#elif ERROR_D04 // no match for 'operator-='
        y -= x;
#elif ERROR_D05 // no match for 'operator*='
        x *= x;
#elif ERROR_D06 // no match for 'operator/='
        x /= x;
#elif ERROR_D07 // no match for 'operator%='
        x %= x;
#elif ERROR_D08 // no match for 'operator*='
        x *= y;
#elif ERROR_D09 // no match for 'operator/='
        x /= y;
#elif ERROR_D10 // no match for 'operator%='
        x %= y;
#elif ERROR_D11 // no match for 'operator*='
        y *= x;
#elif ERROR_D12 // no match for 'operator/='
        y /= x;
#elif ERROR_D13 // no match for 'operator%='
        y %= x;
#endif

        bar( -x );                      // ok
#ifdef ERROR_E01 // no matching function for call
        bar( -y );
#elif ERROR_E02 // no match for 'operator+'
        bar( x+y );
#elif ERROR_E03 // no match for 'operator-'
        bar( x-y );
#elif ERROR_E04 // no match for 'operator+'
        bar( y+x );
#elif ERROR_E05 // no match for 'operator-'
        bar( y-x );
#elif ERROR_E06 // ambiguous overload for 'operator*'
        bar( x*x );
#elif ERROR_E07 // no match for 'operator/='
        bar( x/x );
#elif ERROR_E08 // no match for 'operator%='
        bar( x%x );
#elif ERROR_E09 // ambiguous overload for 'operator*'
        bar( x*y );
#elif ERROR_E10 // no match for 'operator/='
        bar( x/y );
#elif ERROR_E11 // no match for 'operator%='
        bar( x%y );
#elif ERROR_E12 // ambiguous overload for 'operator*'
        bar( y*x );
#elif ERROR_E13 // no match for 'operator/='
        bar( y/x );
#elif ERROR_E14 // no match for 'operator%='
        bar( y%x );
#endif

        std::cout << std::endl;
        std::cout << "*** OK ***" << std::endl;
        std::cout << std::endl;
}

