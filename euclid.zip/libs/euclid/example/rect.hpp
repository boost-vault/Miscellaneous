//  An application example for the Euclid library.

//  Copyright (C) 2004-2009
//  Andreas Harnack (ah8 at freenet dot de)
//  version 0.0.4

//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.

//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.

//  You should have received a copy of the GNU General Public License along
//  with this program; if not, write to the Free Software Foundation, Inc.,
//  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.


#ifndef EUCLID_RECT_HPP
#define EUCLID_RECT_HPP

#include <qwidget.h>
#include <qpainter.h>
#include "euclid.hpp"


// The widget draws four rectangles:
// 1) one in the centre of the widget,
// 2) one that can be dragged around with a mouse button pressed,
// 3) the smallest rectangle enclosing both,
// 4) the smallest rectangle enclosing the overlapping area, if any.


class RectApplWidget : public QWidget
{
                Q_OBJECT

        public:
                typedef euclid::dim<int,0> dimX;
                typedef euclid::dim<int,1> dimY;
                typedef euclid::vec<int,2> vect;
                typedef euclid::cuboid<int,2> rect;

        private:
                vect sizeCentral;
                vect sizeMovable;
                vect mousePosition;

        public:
                dimX width() const { return dimX(QWidget::width()); }
                dimY height() const { return dimY(QWidget::height()); }
                vect size() const { return (width(),height()); }

                static dimX x(const QPoint& p) { return dimX(p.x()); }
                static dimY y(const QPoint& p) { return dimY(p.y()); }
                static vect vector(const QPoint& p) { return (x(p),y(p)); }

        private:
                void drawRect(QPainter& paint, dimX x, dimY y, dimX w, dimY h)
                        { paint.drawRect(x(), y(), w(), h()); }
                void drawRect(QPainter& paint, vect orig, vect size)
                        { drawRect(paint, orig, orig, size, size); }

                void drawRect(QPainter&, rect const&, PenStyle, QColor const&);
                void paintEvent(QPaintEvent*);
                void mousePressEvent(QMouseEvent*);
                void mouseMoveEvent(QMouseEvent*);

        public:
                RectApplWidget(QWidget* parent=0, const char *name=0);
};



#endif  // EUCLID_RECT_HPP
