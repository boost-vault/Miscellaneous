//  An application example for the Euclid library.

//  Copyright (C) 2004-2009
//  Andreas Harnack (ah8 at freenet dot de)
//  version 0.0.4

//  This program is free software; you can redistribute it and/or modify
//  it under the terms of the GNU General Public License as published by
//  the Free Software Foundation; either version 2 of the License, or
//  (at your option) any later version.

//  This program is distributed in the hope that it will be useful,
//  but WITHOUT ANY WARRANTY; without even the implied warranty of
//  MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
//  GNU General Public License for more details.

//  You should have received a copy of the GNU General Public License along
//  with this program; if not, write to the Free Software Foundation, Inc.,
//  51 Franklin Street, Fifth Floor, Boston, MA 02110-1301 USA.


#include <qapplication.h>
#include <qwidget.h>
#include "rect.hpp"



// The widget draws four rectangles:
// 1) one in the centre of the widget,
// 2) one that can be dragged around with a mouse button pressed,
// 3) the smallest rectangle enclosing both,
// 4) the smallest rectangle enclosing the overlapping area, if any.


void RectApplWidget::drawRect(QPainter& painter, rect const& r,
        PenStyle style, QColor const& color)
{
        if ( r.proper() ) {
                QPen pen(style);
                pen.setColor(color);
                painter.setPen(pen);
                drawRect(painter, r.orig(), r.size());
        }
}


void RectApplWidget::mousePressEvent( QMouseEvent* e )
{
        mousePosition = vector(e->pos());
        repaint();
}

void RectApplWidget::mouseMoveEvent( QMouseEvent* e )
{
        mousePosition = vector(e->pos());
        repaint();
}


void RectApplWidget::paintEvent( QPaintEvent* )
{
        QPainter painter;
        painter.begin(this);

        rect central((size()-sizeCentral)/2, (size()+sizeCentral)/2);
        rect movable(mousePosition-sizeMovable/2, mousePosition+sizeMovable/2);

        drawRect(painter, central, Qt::SolidLine, Qt::black);
        drawRect(painter, movable, Qt::SolidLine, Qt::black);
        drawRect(painter, closure(central, movable), Qt::DotLine, Qt::blue);
        drawRect(painter, intersect(central, movable), Qt::DotLine, Qt::red);

        painter.end();
}


RectApplWidget::RectApplWidget(QWidget *parent, const char *name)
        : QWidget(parent, name)
        , sizeCentral( (dimX(100), dimY(150)) )
        , sizeMovable( (dimX(50), dimY(100)) )
        , mousePosition( size()/2 )
{}


int main(int argc, char *argv[])
{
        QApplication appl(argc, argv);
        RectApplWidget win;
        appl.setMainWidget(&win);
        win.show();
        return appl.exec();
}

