#ifndef TIMING_CLOCK_H
#define TIMING_CLOCK_H

#include <windows.h>
#include <exception>

namespace timing
{
	typedef int Milliseconds;

	class Clock
	{
	public:
		struct Fail : std::exception
		{
			char const *what() const throw()
			{
				return "timing::Clock::Fail";
			}
		};

		explicit Clock( Milliseconds ms = 0 )
		{
			if( ! m_frequency )
				throw Fail();
			Set( ms );
		}

		void Set( Milliseconds ms )
		{
			m_begin = Milliseconds( ReadCounter() / m_frequency ) - ms;
		}

		Milliseconds Read() const
		{
			return Milliseconds( ReadCounter() / m_frequency ) - m_begin;
		}

	private:
		static long long ReadCounter()
		{
			long long count;
			QueryPerformanceCounter( static_cast< LARGE_INTEGER * >( static_cast< void * >( &count ) ) );
			return count;
		}

		static long long FindFrequency()
		{
			long long frequency, count;
			if( QueryPerformanceFrequency( static_cast< LARGE_INTEGER * >( static_cast< void * >( &frequency ) ) ) && QueryPerformanceCounter( static_cast< LARGE_INTEGER * >( static_cast< void * >( &count ) ) ) ) 
				return frequency / 1000;
			return 0;
		}

		static long long const m_frequency;
		Milliseconds m_begin;
	};
}

#endif
