#include "Clock.h"

long long const timing::Clock::m_frequency = FindFrequency();
