#include "containers/String.h"
#include <iostream>

void Print( containers::String< char const > const &string )
{
	std::cout << string;
}

int main()
{
	Print( "Good evening.\n" );
	return 0;
}
