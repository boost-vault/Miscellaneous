#ifndef CONTAINERS_STRING_H
#define CONTAINERS_STRING_H

#include "Array.h"

namespace containers
{
	template< class T >
	struct String : private Array< T >
	{
		typedef typename Array< T >::value_type value_type;
		typedef typename Array< T >::const_iterator const_iterator;
		typedef typename Array< T >::const_pointer const_pointer;
		typedef typename Array< T >::const_reference const_reference;
		typedef typename Array< T >::const_reverse_iterator const_reverse_iterator;
		typedef typename Array< T >::iterator iterator;
		typedef typename Array< T >::pointer pointer;
		typedef typename Array< T >::reference reference;
		typedef typename Array< T >::reverse_iterator reverse_iterator;
		typedef typename Array< T >::difference_type difference_type;
		typedef typename Array< T >::size_type size_type;

		String()
		{
		}

		String( T *pT, size_type size ) : Array< T >( pT, size )
		{
		}

		template< size_type size >
		String( T ( &ts )[ size ] ) : Array< T >( ts, size - 1 )
		{
		}

		friend struct String< T const >;

		String( String< typename Nonconst< T >::type > const &rhs ) : Array< T >( rhs )
		{
		}

		using Array< T >::at;
		using Array< T >::back;
		using Array< T >::begin;
		using Array< T >::capacity;
		using Array< T >::empty;
		using Array< T >::end;
		using Array< T >::front;
		using Array< T >::rbegin;
		using Array< T >::rend;
		using Array< T >::size;
		using Array< T >::swap;
		using Array< T >::operator [];
	};

	template< class C, class T, class D >
	std::basic_ostream< C, T > &operator <<( std::basic_ostream< C, T > &lhs, String< D > const &rhs )
	{
		typedef std::basic_ostream< typename Nonconst< C >::type, T > ostream;
		bool fail( true );
		try
		{
			typename ostream::sentry sentry( lhs );
			if( sentry )
			{
				if( std::streamsize size = std::streamsize( rhs.size() ) )
				{
					std::streamsize width( lhs.width() );
					if( width <= size )
						fail = lhs.rdbuf()->sputn( &rhs[ 0 ], size ) != size;
					else
					{
						width -= size;
						typename ostream::char_type fill( lhs.fill() );
						if( lhs.flags() & ostream::left )
						{
							if( lhs.rdbuf()->sputn( &rhs[ 0 ], size ) == size )
							{
								for( ; ; -- width )
								{
									if( width )
									{
										if( T::not_eof( lhs.rdbuf()->sputc( fill ) ) )
											continue;
										break;
									}
									fail = false;
									break;
								}
							}
						}
						else
						{
							for( ; ; -- width )
							{
								if( width )
								{
									if( T::not_eof( lhs.rdbuf()->sputc( fill ) ) )
										continue;
									break;
								}
								fail = lhs.rdbuf()->sputn( &rhs[ 0 ], size ) != size;
								break;
							}
						}
					}
				}
				lhs.width( 0 );
			}
		}
		catch( ... )
		{
			try
			{
				lhs.setstate( ostream::badbit | ostream::failbit );
			}
			catch( ... )
			{
			}
			if( lhs.exceptions() & ostream::badbit )
				throw;
		}
		if( fail )
			lhs.setstate( ostream::failbit );
		return lhs;
	}
}

#endif
