#ifndef CONTAINERS_ARRAY_H
#define CONTAINERS_ARRAY_H

#include <iterator>
#include <stdexcept>

namespace containers
{
	template< class T >
	struct Nonconst
	{
		typedef T type;
	};

	template< class T >
	struct Nonconst< T const >
	{
		typedef T type;
	};

	template< class T >
	class Array
	{
	public:
		typedef T value_type;
		typedef value_type const *const_iterator;
		typedef value_type const *const_pointer;
		typedef value_type const &const_reference;
		typedef std::reverse_iterator< const_iterator > const_reverse_iterator;
		typedef value_type *iterator;
		typedef value_type *pointer;
		typedef value_type &reference;
		typedef std::reverse_iterator< iterator > reverse_iterator;
		typedef std::ptrdiff_t difference_type;
		typedef std::size_t size_type;

		Array() : m_pT(), m_size()
		{
		}

		Array( T *pT, size_type size ) : m_pT( pT ), m_size( size )
		{
		}

		template< size_type size >
		Array( T ( &ts )[ size ] ) : m_pT( ts ), m_size( size )
		{
		}

		friend class Array< T const >;

		Array( Array< typename Nonconst< T >::type > const &rhs ) : m_pT( rhs.m_pT ), m_size( rhs.m_size )
		{
		}

		reference at( size_type index )
		{
			Verify( index );
			return m_pT[ index ];
		}

		const_reference at( size_type index ) const
		{
			Verify( index );
			return m_pT[ index ];
		}

		reference back()
		{
			return m_pT[ m_size - 1 ];
		}

		const_reference back() const
		{
			return m_pT[ m_size - 1 ];
		}

		iterator begin()
		{
			return m_pT;
		}

		const_iterator begin() const
		{
			return m_pT;
		}

		size_type capacity() const
		{
			return m_size;
		}

		bool empty() const
		{
			return m_size == 0;
		}

		iterator end()
		{
			return m_pT + m_size;
		}

		const_iterator end() const
		{
			return m_pT + m_size;
		}

		reference front()
		{
			return m_pT[ 0 ];
		}

		const_reference front() const
		{
			return m_pT[ 0 ];
		}

		reverse_iterator rbegin()
		{
			return reverse_iterator( end() );
		}

		const_reverse_iterator rbegin() const
		{
			return const_reverse_iterator( end() );
		}

		reverse_iterator rend()
		{
			return reverse_iterator( begin() );
		}

		const_reverse_iterator rend() const
		{
			return const_reverse_iterator( begin() );
		}

		size_type size() const
		{
			return m_size;
		}

		void swap( Array< T > &rhs )
		{
			std::swap( m_pT, rhs.m_pT );
			std::swap( m_size, rhs.m_size );
		}

		reference operator []( size_type index )
		{
			return m_pT[ index ];
		}

		const_reference operator []( size_type index ) const
		{
			return m_pT[ index ];
		}

		friend bool operator ==( Array const &lhs, Array const &rhs )
		{
			using std::equal;
			return lhs.size() == rhs.size() && ( lhs.m_pT == rhs.m_pT || equal( lhs.begin(), lhs.end(), rhs.begin() ) );
		}

		friend bool operator !=( Array const &lhs, Array const &rhs )
		{
			return ! ( lhs == rhs );
		}

		friend bool operator <( Array const &lhs, Array const &rhs )
		{
			if( lhs.size() == rhs.size() && lhs.m_pT == rhs.m_pT )
				return false;
			using std::lexicographical_compare;
			return lexicographical_compare( lhs.begin(), lhs.end(), rhs.begin(), rhs.end() );
		}

		friend bool operator >( Array const &lhs, Array const &rhs )
		{
			return rhs < lhs;
		}

		friend bool operator <=( Array const &lhs, Array const &rhs )
		{
			return ! ( lhs > rhs );
		}

		friend bool operator >=( Array const &lhs, Array const &rhs )
		{
			return ! ( lhs < rhs );
		}

	private:
		void Verify( size_type index ) const
		{
			if( index >= m_size )
				throw std::out_of_range( "Array" );
		}

		T *m_pT;
		size_type m_size;
	};
}

#endif
