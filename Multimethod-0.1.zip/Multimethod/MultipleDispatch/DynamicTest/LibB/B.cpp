#include "B.h"
#include "PublicBasesOfA.h"

void CallLibBMethod( A &a1, A &a2 )
{
	types::MethodManager< LibBMethod >::GetMethod()( a1, a2 );
}

namespace
{
	types::TypeRegistration registrationA( types::Register< A >() );
	types::TypeRegistration registrationB( types::Register< B >() );
}
