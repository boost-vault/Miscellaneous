#ifndef B_H
#define B_H

#ifdef LIBB_EXPORTS
#define LIBB_INTERFACE __declspec( dllexport )
#else
#define LIBB_INTERFACE __declspec( dllimport )
#endif

#include "../LibA/A.h"
#include "types/Multimethod.h"

struct LIBB_INTERFACE B : virtual public A
{
};

namespace types
{
	template<>
	struct PublicBasesOf< B > : vector< A >
	{
	};
}

struct LibBMethod : types::Multimethod< void ( A &, A & ) >
{
};

template class LIBB_INTERFACE types::MethodRegistration< LibBMethod >;
typedef types::MethodRegistration< LibBMethod > LibBMethodRegistration;

LIBB_INTERFACE void CallLibBMethod( A &a1, A &a2 );

#endif
