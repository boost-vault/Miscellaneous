#ifndef LIBB_BASESOFA_H
#define LIBB_BASESOFA_H

#include "types/PublicBasesOf.h"

struct A;

namespace types
{
	template<>
	struct PublicBasesOf< A > : vector<>
	{
	};
}

#endif
