#include "A.h"

A::~A()
{
}
