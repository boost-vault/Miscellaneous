#ifndef A_H
#define A_H

#ifdef LIBA_EXPORTS
#define LIBA_INTERFACE __declspec( dllexport )
#else
#define LIBA_INTERFACE __declspec( dllimport )
#endif

struct LIBA_INTERFACE A
{
	virtual ~A();
};

#endif
