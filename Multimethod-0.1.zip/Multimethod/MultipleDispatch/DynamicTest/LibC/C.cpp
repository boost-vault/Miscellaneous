#include "C.h"
#include "PublicBasesOfA.h"

void CallLibCMethod( A &a1, A &a2 )
{
	types::MethodManager< LibCMethod >::GetMethod()( a1, a2 );
}

namespace
{
	types::TypeRegistration registrationA( types::Register< A >() );
	types::TypeRegistration registrationC( types::Register< C >() );
}
