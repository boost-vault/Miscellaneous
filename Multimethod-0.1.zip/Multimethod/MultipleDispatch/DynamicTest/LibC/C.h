#ifndef C_H
#define C_H

#ifdef LIBC_EXPORTS
#define LIBC_INTERFACE __declspec( dllexport )
#else
#define LIBC_INTERFACE __declspec( dllimport )
#endif

#include "../LibA/A.h"
#include "types/Multimethod.h"

struct LIBC_INTERFACE C : virtual public A
{
};

namespace types
{
	template<>
	struct PublicBasesOf< C > : vector< A >
	{
	};
}

struct LibCMethod : types::Multimethod< void ( A &, A & ) >
{
};

template class LIBC_INTERFACE types::MethodRegistration< LibCMethod >;
typedef types::MethodRegistration< LibCMethod > LibCMethodRegistration;

LIBC_INTERFACE void CallLibCMethod( A &a1, A &a2 );

#endif
