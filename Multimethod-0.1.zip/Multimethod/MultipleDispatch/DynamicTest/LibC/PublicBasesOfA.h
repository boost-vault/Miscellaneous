#ifndef LIBC_BASESOFA_H
#define LIBC_BASESOFA_H

#include "types/PublicBasesOf.h"

struct A;

namespace types
{
	template<>
	struct PublicBasesOf< A > : vector<>
	{
	};
}

#endif
