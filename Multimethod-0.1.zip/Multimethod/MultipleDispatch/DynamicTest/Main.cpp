#include "LibB/B.h"
#include "LibC/C.h"
#include "PublicBasesOfA.h"
#include <iostream>

struct D : public B, public C
{
};

namespace types
{
	template<>
	struct PublicBasesOf< D > : vector< B, C >
	{
	};
}

namespace
{
	types::TypeRegistration registrationD( types::Register< D >() );
}

void LibBMethodTest( A &, A & )
{
	std::cout << typeid( A & ).name() << ", " << typeid( A & ).name() << std::endl;
}

void LibBMethodTest( B &, B & )
{
	std::cout << typeid( B & ).name() << ", " << typeid( B & ).name() << std::endl;
}

void LibCMethodTest( A &, A & )
{
	std::cout << typeid( A & ).name() << ", " << typeid( A & ).name() << std::endl;
}

void LibCMethodTest( C &, C & )
{
	std::cout << typeid( C & ).name() << ", " << typeid( C & ).name() << std::endl;
}

void LibBMethodAA( A &a1, A &a2 )
{
	LibBMethodTest( a1, a2 );
}

void LibBMethodBB( B &b1, B &b2 )
{
	LibBMethodTest( b1, b2 );
}

void LibCMethodAA( A &a1, A &a2 )
{
	LibCMethodTest( a1, a2 );
}

void LibCMethodCC( C &c1, C &c2 )
{
	LibCMethodTest( c1, c2 );
}

namespace
{
	LibBMethodRegistration registrationBMethodAA( LibBMethod::Register< A, A, &LibBMethodAA >() );
	LibBMethodRegistration registrationBMethodBB( LibBMethod::Register< B, B, &LibBMethodBB >() );
	LibCMethodRegistration registrationCMethodAA( LibCMethod::Register< A, A, &LibCMethodAA >() );
	LibCMethodRegistration registrationCMethodBB( LibCMethod::Register< C, C, &LibCMethodCC >() );
}

int main()
{
	B b;
	C c;
	D d;

	LibBMethodTest( b, b );
	LibBMethodTest( b, c );
	LibBMethodTest( b, d );

	LibBMethodTest( c, b );
	LibBMethodTest( c, c );
	LibBMethodTest( c, d );

	LibBMethodTest( d, b );
	LibBMethodTest( d, c );
	LibBMethodTest( d, d );

	LibCMethodTest( b, b );
	LibCMethodTest( b, c );
	LibCMethodTest( b, d );

	LibCMethodTest( c, b );
	LibCMethodTest( c, c );
	LibCMethodTest( c, d );

	LibCMethodTest( d, b );
	LibCMethodTest( d, c );
	LibCMethodTest( d, d );

	std::cout << std::endl;

	CallLibBMethod( b, b );
	CallLibBMethod( b, c );
	CallLibBMethod( b, d );

	CallLibBMethod( c, b );
	CallLibBMethod( c, c );
	CallLibBMethod( c, d );

	CallLibBMethod( d, b );
	CallLibBMethod( d, c );
	CallLibBMethod( d, d );

	CallLibCMethod( b, b );
	CallLibCMethod( b, c );
	CallLibCMethod( b, d );

	CallLibCMethod( c, b );
	CallLibCMethod( c, c );
	CallLibCMethod( c, d );

	CallLibCMethod( d, b );
	CallLibCMethod( d, c );
	CallLibCMethod( d, d );

	return 0;
}
