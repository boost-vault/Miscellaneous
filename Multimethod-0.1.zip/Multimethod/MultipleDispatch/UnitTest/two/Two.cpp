#include "Two.h"
#include "TestARefARef.h"
#include "TestARefARefMethod.h"
#include <iostream>

void two::Test()
{
	A a;
	B b;
	C c;
	D d;
	E e;

	A *pAs[][ 2 ] = {
		{ &a, &a },
		{ &a, &b },
		{ &a, &c },
		{ &a, &d },
		{ &a, &e },

		{ &b, &a },
		{ &b, &b },
		{ &b, &c },
		{ &b, &d },
		{ &b, &e },

		{ &c, &a },
		{ &c, &b },
		{ &c, &c },
		{ &c, &d },
		{ &c, &e },

		{ &d, &a },
		{ &d, &b },
		{ &d, &c },
		{ &d, &d },
		{ &d, &e },

		{ &e, &a },
		{ &e, &b },
		{ &e, &c },
		{ &e, &d },
		{ &e, &e },
	};

	std::cout << "two::Test\n";

	for( std::size_t index( 0 ), size( sizeof( pAs ) / sizeof( pAs[ 0 ] ) ); index != size; ++ index )
	{
		if( ! ( index % 5 ) )
			std::cout << '\n';

		try
		{
			TestARefARef( pAs[ index ][ 0 ], pAs[ index ][ 1 ] );
			Result result( TestARefARef( pAs[ index ][ 0 ], pAs[ index ][ 1 ] ) );
			std::cout << result.first.first << ' ' << result.first.second.name() << ", " << result.second.first << ' ' << result.second.second.name() << '\n';
		}
		catch( TestARefARefMethod::Ambiguous const &e )
		{
			TestARefARefMethod::Ambiguous::Key const &key( e.GetKey() );
			std::cerr << '\n' << e.what() << "\n\n\t" << key.first.name() << ", " << key.second.name() << '\n';
			for( std::size_t index( 0 ), size( e.Size() ); index != size; ++ index )
			{
				TestARefARefMethod::Ambiguous::Key const &key( e[ index ] );
				std::cerr << '\t' << key.first.name() << ", " << key.second.name() << '\n';
			}
			std::cerr << std::endl;
		}
		catch( TestARefARefMethod::NotRegistered const &e )
		{
			TestARefARefMethod::NotRegistered::Key const &key( e.GetKey() );
			std::cerr << '\n' << e.what() << "\n\n\t" << key.first.name() << ", " << key.second.name() << '\n' << std::endl;
		}
		catch( std::bad_cast const &e )
		{
			std::cerr << '\n' << e.what() << '\n' << std::endl;
		}
	}

	std::cout << std::endl;
}

namespace
{
	types::TypeRegistration registerA( types::Register< two::A >() );
	types::TypeRegistration registerB( types::Register< two::B >() );
	types::TypeRegistration registerC( types::Register< two::C >() );
	types::TypeRegistration registerD( types::Register< two::D >() );
	types::TypeRegistration registerE( types::Register< two::E >() );
}
