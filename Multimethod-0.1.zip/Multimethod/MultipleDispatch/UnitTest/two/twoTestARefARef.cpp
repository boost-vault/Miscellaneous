#include "TestARefARef.h"

two::Result two::TestARefARef( A const *pA1, A const *pA2 )
{
	return types::MethodManager< TestARefARefMethod >::GetMethod()( pA1, pA2 );
}
