#ifndef TWO_TWO_H
#define TWO_TWO_H

#include "types/Type.h"

namespace two
{
	struct A
	{
		virtual ~A()
		{
		}
	};

	struct B : virtual A
	{
	};

	struct C : B
	{
	};

	struct D : B
	{
	};

	struct E : C, D
	{
	};

	void Test();
}

namespace types
{
	template<>
	struct PublicBasesOf< two::A > : vector<>
	{
	};

	template<>
	struct PublicBasesOf< two::B > : vector< two::A >
	{
	};

	template<>
	struct PublicBasesOf< two::C > : vector< two::B >
	{
	};

	template<>
	struct PublicBasesOf< two::D > : vector< two::B >
	{
	};

	template<>
	struct PublicBasesOf< two::E > : vector< two::C, two::D >
	{
	};
}

#endif
