#ifndef TWO_TESTAREFAREFMETHOD_H
#define TWO_TESTAREFAREFMETHOD_H

#include "Two.h"

namespace two
{
	Result Test( A const *, A const * );
	Result Test( B const *, B const * );
}

#endif
