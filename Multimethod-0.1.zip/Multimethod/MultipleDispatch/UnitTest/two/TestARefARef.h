#ifndef TWO_TESTAREFAREF_H
#define TWO_TESTAREFAREF_H

#include "Two.h"
#include "types/Multimethod.h"
#include <utility>

namespace two
{
	typedef std::pair< std::pair< void const *, types::Info >, std::pair< void const *, types::Info > > Result;

	struct TestARefARefMethod : types::Multimethod< Result ( A const *, A const * ) >
	{
	};

	typedef types::MethodRegistration< TestARefARefMethod > TestARefARefRegistration;

	Result TestARefARef( A const *, A const * );
}

#endif
