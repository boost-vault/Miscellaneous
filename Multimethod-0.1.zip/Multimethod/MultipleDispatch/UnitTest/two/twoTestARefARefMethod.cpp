#include "TestARefARef.h"
#include "TestARefARefMethod.h"

two::Result two::Test( A const *pA1, A const *pA2 )
{
	using std::make_pair;
	return make_pair( make_pair( pA1, types::Info( typeid( A const * ) ) ), make_pair( pA2, types::Info( typeid( A const * ) ) ) );
}

two::Result two::Test( B const *pB1, B const *pB2 )
{
	using std::make_pair;
	return make_pair( make_pair( pB1, types::Info( typeid( B const * ) ) ), make_pair( pB2, types::Info( typeid( B const * ) ) ) );
}

namespace
{
	template< class F, class S >
	struct Test
	{
		static two::Result Method( F first, S second )
		{
			return two::Test( first, second );
		}
	};

	two::TestARefARefRegistration registerARefAref( two::TestARefARefMethod::Register< two::A, two::A, &Test< two::A const *, two::A const * >::Method >() );
	two::TestARefARefRegistration registerBRefBref( two::TestARefARefMethod::Register< two::B, two::B, &Test< two::B const *, two::B const * >::Method >() );
}
