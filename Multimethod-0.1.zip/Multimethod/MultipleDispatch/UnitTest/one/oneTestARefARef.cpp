#include "TestARefARef.h"

std::pair< types::Info, types::Info > one::TestARefARef( A &a1, A &a2 )
{
	return types::MethodManager< TestARefARefMethod >::GetMethod()( a1, a2 );
}
