#ifndef ONE_TESTAREFAREF_H
#define ONE_TESTAREFAREF_H

#include "One.h"
#include "types/Multimethod.h"
#include <utility>

namespace one
{
	struct TestARefARefMethod : types::Multimethod< std::pair< types::Info, types::Info > ( A &, A & ) >
	{
	};

	typedef types::MethodRegistration< TestARefARefMethod > TestARefARefRegistration;

	std::pair< types::Info, types::Info > TestARefARef( A &, A & );
}

#endif
