#ifndef ONE_TESTAREFAREFMETHOD_H
#define ONE_TESTAREFAREFMETHOD_H

#include "One.h"

namespace one
{
	std::pair< types::Info, types::Info > Test( A &, A & );
	std::pair< types::Info, types::Info > Test( B &, B & );
}

#endif
