#include "One.h"
#include "TestARefARef.h"
#include "TestARefARefMethod.h"
#include <iostream>

void one::Test()
{
	A a;
	B b;
	C c;
	D d;

	B *pB( &d );
	C *pC( &d );

	A *pAs[][ 2 ] = {
		{ &a, &a },
		{ &a, &b },
		{ &a, &c },
		{ &a, pB },
		{ &a, pC },

		{ &b, &a },
		{ &b, &b },
		{ &b, &c },
		{ &b, pB },
		{ &b, pC },

		{ &c, &a },
		{ &c, &b },
		{ &c, &c },
		{ &c, pB },
		{ &c, pC },

		{ pB, &a },
		{ pB, &b },
		{ pB, &c },
		{ pB, pB },
		{ pB, pC },

		{ pC, &a },
		{ pC, &b },
		{ pC, &c },
		{ pC, pB },
		{ pC, pC }
	};

	std::cout << "one::Test\n";

	for( std::size_t index( 0 ), size( sizeof( pAs ) / sizeof( pAs[ 0 ] ) ); index != size; ++ index )
	{
		if( ! ( index % 5 ) )
			std::cout << '\n';

		try
		{
			TestARefARef( *pAs[ index ][ 0 ], *pAs[ index ][ 1 ] );
			typedef std::pair< types::Info, types::Info > Result;
			Result result( TestARefARef( *pAs[ index ][ 0 ], *pAs[ index ][ 1 ] ) );
			std::cout << result.first.name() << ", " << result.second.name() << '\n';
		}
		catch( TestARefARefMethod::Ambiguous const &e )
		{
			TestARefARefMethod::Ambiguous::Key const &key( e.GetKey() );
			std::cerr << '\n' << e.what() << "\n\n\t" << key.first.name() << ", " << key.second.name() << '\n';
			for( std::size_t index( 0 ), size( e.Size() ); index != size; ++ index )
			{
				TestARefARefMethod::Ambiguous::Key const &key( e[ index ] );
				std::cerr << '\t' << key.first.name() << ", " << key.second.name() << '\n';
			}
			std::cerr << std::endl;
		}
		catch( TestARefARefMethod::NotRegistered const &e )
		{
			TestARefARefMethod::NotRegistered::Key const &key( e.GetKey() );
			std::cerr << '\n' << e.what() << "\n\n\t" << key.first.name() << ", " << key.second.name() << '\n' << std::endl;
		}
		catch( std::bad_cast const &e )
		{
			std::cerr << '\n' << e.what() << '\n' << std::endl;
		}
	}

	std::cout << std::endl;
}

namespace
{
	types::TypeRegistration registerA( types::Register< one::A >() );
	types::TypeRegistration registerB( types::Register< one::B >() );
	types::TypeRegistration registerC( types::Register< one::C >() );
	types::TypeRegistration registerD( types::Register< one::D >() );
}
