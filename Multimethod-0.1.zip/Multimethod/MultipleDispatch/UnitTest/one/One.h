#ifndef ONE_ONE_H
#define ONE_ONE_H

#include "types/Type.h"

namespace one
{
	struct A
	{
		virtual ~A()
		{
		}
	};

	struct B : A
	{
	};

	struct C : A
	{
	};

	struct D : B, C
	{
	};

	void Test();
}

namespace types
{
	template<>
	struct PublicBasesOf< one::A > : vector<>
	{
	};

	template<>
	struct PublicBasesOf< one::B > : vector< one::A >
	{
	};

	template<>
	struct PublicBasesOf< one::C > : vector< one::A >
	{
	};

	template<>
	struct PublicBasesOf< one::D > : vector< one::B, one::C >
	{
	};
}

#endif
