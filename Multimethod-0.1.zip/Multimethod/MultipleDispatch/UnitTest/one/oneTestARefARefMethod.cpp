#include "TestARefARef.h"
#include "TestARefARefMethod.h"

std::pair< types::Info, types::Info > one::Test( A &, A & )
{
	using std::make_pair;
	return make_pair( types::Info( typeid( A & ) ), types::Info( typeid( A & ) ) );
}

std::pair< types::Info, types::Info > one::Test( B &, B & )
{
	using std::make_pair;
	return make_pair( types::Info( typeid( B & ) ), types::Info( typeid( B & ) ) );
}

namespace
{
	template< class F, class S >
	struct Test
	{
		static std::pair< types::Info, types::Info > Method( F first, S second )
		{
			return one::Test( first, second );
		}
	};

	one::TestARefARefRegistration registerARefAref( one::TestARefARefMethod::Register< one::A, one::A, &Test< one::A &, one::A & >::Method >() );
	one::TestARefARefRegistration registerBRefBref( one::TestARefARefMethod::Register< one::B, one::B, &Test< one::B &, one::B & >::Method >() );
}
