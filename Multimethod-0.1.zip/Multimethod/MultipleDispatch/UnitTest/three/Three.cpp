#include "Three.h"
#include "TestARefARef.h"
#include "TestARefARefMethod.h"
#include <iostream>

void three::Test()
{
	A a;
	B b;
	C c;
	E e;

	B *pB( &e );
	C *pC( &e );

	A *pAs[][ 2 ] = {
		{ &a, &a },
		{ &a, &b },
		{ &a, &c },
		{ &a, pB },
		{ &a, pC },

		{ &b, &a },
		{ &b, &b },
		{ &b, &c },
		{ &b, pB },
		{ &b, pC },

		{ &c, &a },
		{ &c, &b },
		{ &c, &c },
		{ &c, pB },
		{ &c, pC },

		{ pB, &a },
		{ pB, &b },
		{ pB, &c },
		{ pB, pB },
		{ pB, pC },

		{ pC, &a },
		{ pC, &b },
		{ pC, &c },
		{ pC, pB },
		{ pC, pC },
	};

	std::cout << "three::Test\n";

	for( std::size_t index( 0 ), size( sizeof( pAs ) / sizeof( pAs[ 0 ] ) ); index != size; ++ index )
	{
		if( ! ( index % 5 ) )
			std::cout << '\n';

		try
		{
			TestARefARef( *pAs[ index ][ 0 ], *pAs[ index ][ 1 ] );
			typedef std::pair< types::Info, types::Info > Result;
			Result result( TestARefARef( *pAs[ index ][ 0 ], *pAs[ index ][ 1 ] ) );
			std::cout << result.first.name() << ", " << result.second.name() << '\n';
		}
		catch( TestARefARefMethod::Ambiguous const &e )
		{
			TestARefARefMethod::Ambiguous::Key const &key( e.GetKey() );
			std::cerr << '\n' << e.what() << "\n\n\t" << key.first.name() << ", " << key.second.name() << '\n';
			for( std::size_t index( 0 ), size( e.Size() ); index != size; ++ index )
			{
				TestARefARefMethod::Ambiguous::Key const &key( e[ index ] );
				std::cerr << '\t' << key.first.name() << ", " << key.second.name() << '\n';
			}
			std::cerr << std::endl;
		}
		catch( TestARefARefMethod::NotRegistered const &e )
		{
			TestARefARefMethod::NotRegistered::Key const &key( e.GetKey() );
			std::cerr << '\n' << e.what() << "\n\n\t" << key.first.name() << ", " << key.second.name() << '\n' << std::endl;
		}
		catch( std::bad_cast const &e )
		{
			std::cerr << '\n' << e.what() << '\n' << std::endl;
		}
	}

	std::cout << std::endl;
}

namespace
{
	types::TypeRegistration registerA( types::Register< three::A >() );
	types::TypeRegistration registerB( types::Register< three::B >() );
	types::TypeRegistration registerC( types::Register< three::C >() );
	types::TypeRegistration registerD( types::Register< three::D >() );
	types::TypeRegistration registerE( types::Register< three::E >() );
}
