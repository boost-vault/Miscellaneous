#ifndef THREE_TESTAREFAREFMETHOD_H
#define THREE_TESTAREFAREFMETHOD_H

#include "Three.h"

namespace three
{
	std::pair< types::Info, types::Info > Test( A &, A & );
	std::pair< types::Info, types::Info > Test( A &, B & );
	std::pair< types::Info, types::Info > Test( B &, A & );
	std::pair< types::Info, types::Info > Test( D &, D & );
}

#endif
