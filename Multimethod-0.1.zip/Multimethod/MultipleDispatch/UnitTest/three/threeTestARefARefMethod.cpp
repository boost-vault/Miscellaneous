#include "TestARefARef.h"
#include "TestARefARefMethod.h"

std::pair< types::Info, types::Info > three::Test( A &, A & )
{
	using std::make_pair;
	return make_pair( types::Info( typeid( A & ) ), types::Info( typeid( A & ) ) );
}

std::pair< types::Info, types::Info > three::Test( A &, B & )
{
	using std::make_pair;
	return make_pair( types::Info( typeid( A & ) ), types::Info( typeid( B & ) ) );
}

std::pair< types::Info, types::Info > three::Test( B &, A & )
{
	using std::make_pair;
	return make_pair( types::Info( typeid( B & ) ), types::Info( typeid( A & ) ) );
}

std::pair< types::Info, types::Info > three::Test( D &, D & )
{
	using std::make_pair;
	return make_pair( types::Info( typeid( D & ) ), types::Info( typeid( D & ) ) );
}

namespace
{
	template< class F, class S >
	struct Test
	{
		static std::pair< types::Info, types::Info > Method( F first, S second )
		{
			return three::Test( first, second );
		}
	};

	three::TestARefARefRegistration registerARefAref( three::TestARefARefMethod::Register< three::A, three::A, &Test< three::A &, three::A & >::Method >() );
	three::TestARefARefRegistration registerARefBref( three::TestARefARefMethod::Register< three::A, three::B, &Test< three::A &, three::B & >::Method >() );
	three::TestARefARefRegistration registerBRefAref( three::TestARefARefMethod::Register< three::B, three::A, &Test< three::B &, three::A & >::Method >() );
	three::TestARefARefRegistration registerDRefDref( three::TestARefARefMethod::Register< three::D, three::D, &Test< three::D &, three::D & >::Method >() );
}
