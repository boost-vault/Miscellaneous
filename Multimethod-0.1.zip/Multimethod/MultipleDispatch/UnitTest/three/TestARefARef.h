#ifndef THREE_TESTAREFAREF_H
#define THREE_TESTAREFAREF_H

#include "Three.h"
#include "types/Multimethod.h"
#include <utility>

namespace three
{
	struct TestARefARefMethod : types::Multimethod< std::pair< types::Info, types::Info > ( A &, A & ) >
	{
	};

	typedef types::MethodRegistration< TestARefARefMethod > TestARefARefRegistration;

	std::pair< types::Info, types::Info > TestARefARef( A &, A & );
}

#endif
