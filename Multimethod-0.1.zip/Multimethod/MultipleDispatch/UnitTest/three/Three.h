#ifndef THREE_THREE_H
#define THREE_THREE_H

#include "types/Type.h"

namespace three
{
	struct A
	{
		virtual ~A()
		{
		}
	};

	struct B : A
	{
	};

	struct C : A
	{
	};

	struct D
	{
		virtual ~D()
		{
		}
	};

	struct E : B, C, D
	{
	};

	void Test();
}

namespace types
{
	template<>
	struct PublicBasesOf< three::A > : vector<>
	{
	};

	template<>
	struct PublicBasesOf< three::B > : vector< three::A >
	{
	};

	template<>
	struct PublicBasesOf< three::C > : vector< three::A >
	{
	};

	template<>
	struct PublicBasesOf< three::D > : vector<>
	{
	};

	template<>
	struct PublicBasesOf< three::E > : vector< three::B, three::C, three::D >
	{
	};
}

#endif
