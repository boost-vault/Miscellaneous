#include "one/One.h"
#include "two/Two.h"
#include "three/Three.h"
#include <iostream>

int main() try
{
	one::Test();
	two::Test();
	three::Test();
	return 0;
}
catch( std::exception const &e )
{
	std::cerr << e.what() << std::endl;
	return 0;
}
catch( ... )
{
	return 0;
}
