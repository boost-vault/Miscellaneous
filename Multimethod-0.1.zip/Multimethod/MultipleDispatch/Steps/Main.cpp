#include <iostream>

template< class T >
struct Steps
{
	virtual ~Steps()
	{
	}

	virtual void StepTwo( T &t )
	{
		t.StepThree( static_cast< T & >( *this ) );
	}

	virtual void StepThree( T &t ) = 0;
};

struct A : Steps< A >
{
	virtual void StepOne( A &a )
	{
		a.StepTwo( *this );
	}

	void StepThree( A &a )
	{
		std::cout << "A and A\n";
	}
};

template< class Sub, class Super >
struct First : Super, Steps< Sub >
{
	void StepOne( A &a )
	{
		if( Steps< Sub > *pSteps = dynamic_cast< Steps< Sub > * >( &a ) )
			pSteps->StepTwo( static_cast< Sub & >( *this ) );
		else
			Super::StepOne( a );
	}

	void StepTwo( A &a )
	{
		if( Steps< Sub > *pSteps = dynamic_cast< Steps< Sub > * >( &a ) )
			pSteps->StepThree( static_cast< Sub & >( *this ) );
		else
			StepThree( a );
	}

	using Super::StepThree;

	using Steps< Sub >::StepTwo;
	using Steps< Sub >::StepThree;
};

template< class Sub, class T, class Super = Steps< T > >
struct Second : Super
{
	void StepTwo( T &t )
	{
		if( Steps< Sub > *pSteps = dynamic_cast< Steps< Sub > * >( &t ) )
			pSteps->StepThree( static_cast< Sub & >( *this ) );
		else
			StepThree( t );
	}

	using Super::StepTwo;
};

template< class Sub, class T, class Super = First< Sub, T > >
struct Next : Second< Sub, T, Super >
{
};

struct B : First< B, A >
{
	void StepThree( A &a )
	{
		std::cout << "B and A\n";
	}

	void StepThree( B &b )
	{
		std::cout << "B and B\n";
	}
};

struct C : Next< C, B >
{
	void StepThree( A &a )
	{
		std::cout << "C and A\n";
	}

	void StepThree( B &b )
	{
		std::cout << "C and B\n";
	}

	void StepThree( C &c )
	{
		std::cout << "C and C\n";
	}
};

struct D : First< D, A >, Second< D, B >, Second< D, C >
{
	void StepThree( A &a )
	{
		std::cout << "D and A\n";
	}

	void StepThree( B &b )
	{
		std::cout << "D and B\n";
	}

	void StepThree( C &c )
	{
		std::cout << "D and C\n";
	}

	void StepThree( D &d )
	{
		std::cout << "D and D\n";
	}
};

struct E : Next< E, B, Next< E, C, Next< E, D > > >
{
	void StepThree( A &a )
	{
		std::cout << "E and A\n";
	}

	void StepThree( B &b )
	{
		std::cout << "E and B\n";
	}

	void StepThree( C &c )
	{
		std::cout << "E and C\n";
	}

	void StepThree( D &d )
	{
		std::cout << "E and D\n";
	}

	void StepThree( E &e )
	{
		std::cout << "E and E\n";
	}
};

#include "types/Multimethod.h"

namespace types
{
	template<>
	struct PublicBasesOf< A > : vector<>
	{
	};
}

namespace a
{
	types::TypeRegistration registration( types::Register< A >() );
}

namespace types
{
	template<>
	struct PublicBasesOf< B > : vector< A >
	{
	};
}

namespace b
{
	types::TypeRegistration registration( types::Register< B >() );;
}

namespace types
{
	template<>
	struct PublicBasesOf< C > : vector< B >
	{
	};
}

namespace c
{
	types::TypeRegistration registration( types::Register< C >() );;
}

namespace types
{
	template<>
	struct PublicBasesOf< D > : vector< A >
	{
	};
}

namespace d
{
	types::TypeRegistration registration( types::Register< D >() );;
}

namespace types
{
	template<>
	struct PublicBasesOf< E > : vector< D >
	{
	};
}

namespace e
{
	types::TypeRegistration registration( types::Register< E >() );;
}

//class F : public C, public E
//{
//};
//
//namespace types
//{
//	template<>
//	struct PublicBasesOf< F > : vector< C, E >
//	{
//	};
//}
//
//namespace f
//{
//	types::TypeRegistration registration( types::Register< F >() );;
//}

void DispatchAA( A &, A & )
{
	std::cout << "A and A\n";
}

void DispatchAB( A &, B & )
{
	std::cout << "A and B\n";
}

void DispatchAC( A &, C & )
{
	std::cout << "A and C\n";
}

void DispatchAD( A &, D & )
{
	std::cout << "A and D\n";
}

void DispatchAE( A &, E & )
{
	std::cout << "A and E\n";
}

void DispatchBA( B &, A & )
{
	std::cout << "B and A\n";
}

void DispatchBB( B &, B & )
{
	std::cout << "B and B\n";
}

void DispatchBC( B &, C & )
{
	std::cout << "B and C\n";
}

void DispatchBD( B &, D & )
{
	std::cout << "B and D\n";
}

void DispatchBE( B &, E & )
{
	std::cout << "B and E\n";
}

void DispatchCA( C &, A & )
{
	std::cout << "C and A\n";
}

void DispatchCB( C &, B & )
{
	std::cout << "C and B\n";
}

void DispatchCC( C &, C & )
{
	std::cout << "C and C\n";
}

void DispatchCD( C &, D & )
{
	std::cout << "C and D\n";
}

void DispatchCE( C &, E & )
{
	std::cout << "C and E\n";
}

void DispatchDA( D &, A & )
{
	std::cout << "D and A\n";
}

void DispatchDB( D &, B & )
{
	std::cout << "D and B\n";
}

void DispatchDC( D &, C & )
{
	std::cout << "D and C\n";
}

void DispatchDD( D &, D & )
{
	std::cout << "D and D\n";
}

void DispatchDE( D &, E & )
{
	std::cout << "D and E\n";
}

void DispatchEA( E &, A & )
{
	std::cout << "E and A\n";
}

void DispatchEB( E &, B & )
{
	std::cout << "E and B\n";
}

void DispatchEC( E &, C & )
{
	std::cout << "E and C\n";
}

void DispatchED( E &, D & )
{
	std::cout << "E and D\n";
}

void DispatchEE( E &, E & )
{
	std::cout << "E and E\n";
}

struct MultimethodAA : types::Multimethod< void ( A &, A & ) >
{
};

typedef types::MethodRegistration< MultimethodAA > AARegistration;

void Dispatch( A &lhs, A &rhs )
{
	types::MethodManager< MultimethodAA >::GetMethod()( lhs, rhs );
}

namespace
{
	AARegistration registrationAA( MultimethodAA::Register< A, A, &DispatchAA >() );
	//AARegistration registrationAB( MultimethodAA::Register< A, B, &DispatchAB >() );
	//AARegistration registrationAC( MultimethodAA::Register< A, C, &DispatchAC >() );
	//AARegistration registrationAD( MultimethodAA::Register< A, D, &DispatchAD >() );
	//AARegistration registrationAE( MultimethodAA::Register< A, E, &DispatchAE >() );

	//AARegistration registrationBA( MultimethodAA::Register< B, A, &DispatchBA >() );
	AARegistration registrationBB( MultimethodAA::Register< B, B, &DispatchBB >() );
	//AARegistration registrationBC( MultimethodAA::Register< B, C, &DispatchBC >() );
	AARegistration registrationBD( MultimethodAA::Register< B, D, &DispatchBD >() );
	//AARegistration registrationBE( MultimethodAA::Register< B, E, &DispatchBE >() );

	//AARegistration registrationCA( MultimethodAA::Register< C, A, &DispatchCA >() );
	//AARegistration registrationCB( MultimethodAA::Register< C, B, &DispatchCB >() );
	AARegistration registrationCC( MultimethodAA::Register< C, C, &DispatchCC >() );
	//AARegistration registrationCD( MultimethodAA::Register< C, D, &DispatchCD >() );
	AARegistration registrationCE( MultimethodAA::Register< C, E, &DispatchCE >() );

	//AARegistration registrationDA( MultimethodAA::Register< D, A, &DispatchDA >() );
	AARegistration registrationDB( MultimethodAA::Register< D, B, &DispatchDB >() );
	//AARegistration registrationDC( MultimethodAA::Register< D, C, &DispatchDC >() );
	AARegistration registrationDD( MultimethodAA::Register< D, D, &DispatchDD >() );
	//AARegistration registrationDE( MultimethodAA::Register< D, E, &DispatchDE >() );

	//AARegistration registrationEA( MultimethodAA::Register< E, A, &DispatchEA >() );
	//AARegistration registrationEB( MultimethodAA::Register< E, B, &DispatchEB >() );
	AARegistration registrationEC( MultimethodAA::Register< E, C, &DispatchEC >() );
	//AARegistration registrationED( MultimethodAA::Register< E, D, &DispatchED >() );
	AARegistration registrationEE( MultimethodAA::Register< E, E, &DispatchEE >() );
}

struct MultimethodAvoidi : types::Multimethod< void ( A *&, void const *, int ) >
{
};

typedef types::MethodRegistration< MultimethodAvoidi > AvoidiRegistration;

void DispatchAvoidi( A *&, void const *, int )
{
	std::cout << "A *&, void const *, int\n";
}

//void DispatchBvoidi( B *&, void const *, int )
//{
//	std::cout << "B *&, void const *, int\n";
//}

namespace
{
	AvoidiRegistration registrationAvoidi( MultimethodAvoidi::Register< A, void, int, &DispatchAvoidi >() );
	//AvoidiRegistration registrationBvoidi( MultimethodAvoidi::Register< B, void, int, &DispatchBvoidi >() );
}

void Dispatch( A *&a1, void const *a2, int i )
{
	types::MethodManager< MultimethodAvoidi >::GetMethod()( a1, a2, i );
}

struct MultimethodAiii : types::Multimethod< void ( A const &, int const *const *const *, int const *const *&, int ) >
{
};

typedef types::MethodRegistration< MultimethodAiii > AiiiRegistration;

void DispatchAiii( A const &, int const *const *const *, int const *const *&, int )
{
	std::cout << "A const &, int const *const *const *, int const *const *&, int\n";
}

//void DispatchAffi( A const &, float const *const *const *, float const *const *&, int )
//{
//	std::cout << "A const &, float const *const *const *, float const *const *&, int\n";
//}

namespace
{
	AiiiRegistration registrationAiii( MultimethodAiii::Register< A, int, int, int, &DispatchAiii >() );
	//AiiiRegistration registrationAffi( MultimethodAiii::Register< A, float, float, int, &DispatchAffi >() );
}

void Dispatch( A const &a1, int const *const *const *a2, int const *const *&a3, int i )
{
	types::MethodManager< MultimethodAiii >::GetMethod()( a1, a2, a3, i );
}

int main()
{
	A a;
	B b;
	C c;
	D d;
	E e;

	a.StepOne( a );
	a.StepOne( b );
	a.StepOne( c );
	a.StepOne( d );
	a.StepOne( e );
	std::cout << std::endl;

	b.StepOne( a );
	b.StepOne( b );
	b.StepOne( c );
	b.StepOne( d );
	b.StepOne( e );
	std::cout << std::endl;

	c.StepOne( a );
	c.StepOne( b );
	c.StepOne( c );
	c.StepOne( d );
	c.StepOne( e );
	std::cout << std::endl;

	d.StepOne( a );
	d.StepOne( b );
	d.StepOne( c );
	d.StepOne( d );
	d.StepOne( e );
	std::cout << std::endl;

	e.StepOne( a );
	e.StepOne( b );
	e.StepOne( c );
	e.StepOne( d );
	e.StepOne( e );
	std::cout << std::endl;

	Dispatch( a, a );
	Dispatch( a, b );
	Dispatch( a, c );
	Dispatch( a, d );
	Dispatch( a, e );
	std::cout << std::endl;

	Dispatch( b, a );
	Dispatch( b, b );
	Dispatch( b, c );
	Dispatch( b, d );
	Dispatch( b, e );
	std::cout << std::endl;

	Dispatch( c, a );
	Dispatch( c, b );
	Dispatch( c, c );
	Dispatch( c, d );
	Dispatch( c, e );
	std::cout << std::endl;

	Dispatch( d, a );
	Dispatch( d, b );
	Dispatch( d, c );
	Dispatch( d, d );
	Dispatch( d, e );
	std::cout << std::endl;

	Dispatch( e, a );
	Dispatch( e, b );
	Dispatch( e, c );
	Dispatch( e, d );
	Dispatch( e, e );
	std::cout << std::endl;

	//F f;
	//Dispatch( f, a );

	//Dispatch( 0, 0, 0 );
	A *pA( &a );
	Dispatch( pA, 0, 0 );
	pA = &b;
	Dispatch( pA, 0, 0 );
	int const *const *p = 0;
	Dispatch( a, 0, p, 0 );

	return 0;
}
