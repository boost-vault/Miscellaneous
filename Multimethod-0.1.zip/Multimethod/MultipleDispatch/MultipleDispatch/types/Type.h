#ifndef TYPES_TYPE_H
#define TYPES_TYPE_H

#include "PublicBasesOf.h"
#include "Couple.h"
#include "Info.h"
#include "Interface.h"
#include "containers/Array.h"
#include "boost/functional/hash.hpp"
#include "boost/mpl/for_each.hpp"
#include "boost/mpl/size.hpp"

namespace types
{
	class MULTIPLEDISPATCH_INTERFACE TypeInfo;

	class MULTIPLEDISPATCH_INTERFACE Type;
	typedef containers::Array< Type const > Types;

	//Type is copyable interface for TypeInfo.
	class MULTIPLEDISPATCH_INTERFACE Type
	{
	public:
		Type() : m_pTypeInfo( &m_ti )
		{
		}

		Type( TypeInfo const &ti ) : m_pTypeInfo( &ti )
		{
		}

		Type( Info const &info );

		Types const &bases() const;
		bool before( Type const &rhs ) const;
		char const *name() const;

		friend bool operator ==( Type const &lhs, Type const &rhs );
		friend bool operator !=( Type const &lhs, Type const &rhs );
		friend bool operator <( Type const &lhs, Type const &rhs );
		friend bool operator >( Type const &lhs, Type const &rhs );
		friend bool operator <=( Type const &lhs, Type const &rhs );
		friend bool operator >=( Type const &lhs, Type const &rhs );

	private:
		TypeInfo const *m_pTypeInfo;

		static TypeInfo const m_ti;
	};

	//TypeInfo augments std::type_info with a list of public bases.
	class MULTIPLEDISPATCH_INTERFACE TypeInfo
	{
	public:
		explicit TypeInfo( Info const &info = Info(), Types const &bases = Types() ) : m_types( bases ), m_info( info )
		{
		}

		Types const &bases() const
		{
			return m_types;
		}

		bool before( TypeInfo const &rhs ) const
		{
			return m_info.before( rhs.m_info );
		}

		char const *name() const
		{
			return m_info.name();
		}

		friend bool operator ==( TypeInfo const &lhs, TypeInfo const &rhs )
		{
			return lhs.m_info == rhs.m_info;
		}

		friend bool operator !=( TypeInfo const &lhs, TypeInfo const &rhs )
		{
			return lhs.m_info != rhs.m_info;
		}

		friend bool operator <( TypeInfo const &lhs, TypeInfo const &rhs )
		{
			return lhs.m_info < rhs.m_info;
		}

		friend bool operator >( TypeInfo const &lhs, TypeInfo const &rhs )
		{
			return lhs.m_info > rhs.m_info;
		}

		friend bool operator <=( TypeInfo const &lhs, TypeInfo const &rhs )
		{
			return lhs.m_info <= rhs.m_info;
		}

		friend bool operator >=( TypeInfo const &lhs, TypeInfo const &rhs )
		{
			return lhs.m_info >= rhs.m_info;
		}

	private:
		Types m_types;
		Info m_info;
	};

	inline Types const &Type::bases() const
	{
		return m_pTypeInfo->bases();
	}

	inline bool Type::before( Type const &rhs ) const
	{
		return m_pTypeInfo->before( *rhs.m_pTypeInfo );
	}

	inline char const *Type::name() const
	{
		return m_pTypeInfo->name();
	}

	inline bool operator ==( Type const &lhs, Type const &rhs )
	{
		return *lhs.m_pTypeInfo == *rhs.m_pTypeInfo;
	}

	inline bool operator !=( Type const &lhs, Type const &rhs )
	{
		return *lhs.m_pTypeInfo != *rhs.m_pTypeInfo;
	}

	inline bool operator <( Type const &lhs, Type const &rhs )
	{
		return *lhs.m_pTypeInfo < *rhs.m_pTypeInfo;
	}

	inline bool operator >( Type const &lhs, Type const &rhs )
	{
		return *lhs.m_pTypeInfo > *rhs.m_pTypeInfo;
	}

	inline bool operator <=( Type const &lhs, Type const &rhs )
	{
		return *lhs.m_pTypeInfo <= *rhs.m_pTypeInfo;
	}

	inline bool operator >=( Type const &lhs, Type const &rhs )
	{
		return *lhs.m_pTypeInfo >= *rhs.m_pTypeInfo;
	}

	template< class T >
	Type TypeFrom();

	template< class B >
	struct Wrap
	{
	};

	//BaseAdder adds bases to an array.
	template< class T >
	class BaseAdder
	{
	public:
		explicit BaseAdder( Type *pTypes ) : m_pTypes( pTypes ), m_index()
		{
		}

		template< class B >
		void operator ()( Wrap< B > )
		{
			m_pTypes[ m_index ++ ] = TypeFrom< B >();
		}

	private:
		void operator ()( Wrap< T > );

		Type *m_pTypes;
		std::size_t m_index;
	};

	//BaseTypes creates an array of bases, fills it in, and gives access to a reference.
	template< class T, class Vector, std::size_t size = boost::mpl::size< Vector >::value >
	class BaseTypes
	{
	public:
		BaseTypes()
		{
			boost::mpl::for_each< Vector, Wrap< boost::mpl::_1 > >( BaseAdder< T >( m_bases ) );
		}

		Types GetTypes() const
		{
			return Types( m_bases, size );
		}

	private:
		Type m_bases[ size ];
	};

	//This specialization gives access to a reference to a default-initialized array of bases.
	template< class T, class Vector >
	class BaseTypes< T, Vector, 0 >
	{
	public:
		BaseTypes()
		{
		}

		Types GetTypes() const
		{
			return Types();
		}
	};

	//BasesFrom creates a static BaseTypes and returns its array reference.
	template< class T, class Vector >
	Types BasesFrom()
	{
		static BaseTypes< T, Vector > bases;
		return bases.GetTypes();
	}

	//TypeFrom creates a static TypeInfo and returns a reference.
	template< class T >
	Type TypeFrom()
	{
		static TypeInfo ti( typeid( T ), BasesFrom< T, typename PublicBasesOf< T >::type >() );
		return Type( ti );
	}

	//Register returns the data used by TypeRegistration to register a type.
	template< class T >
	inline Couple< Info, Type > Register()
	{
		return MakeCouple( Info( typeid( T ) ), TypeFrom< T >() );
	}

	//TypeRegistration unregisters a type when it is destroyed.
	class MULTIPLEDISPATCH_INTERFACE TypeRegistration
	{
	public:
		TypeRegistration( Couple< Info, Type > const & );
		~TypeRegistration();

	private:
		TypeRegistration( TypeRegistration const & );
		TypeRegistration &operator =( TypeRegistration const & );

		Info m_info;
	};
}

namespace containers
{
	template class MULTIPLEDISPATCH_INTERFACE Array< types::Type const >;
}

namespace boost
{
	//The specialization of hash for Info and Type hashes their name strings.
	template<>
	struct hash< types::Info >
	{
		std::size_t operator ()( types::Info const &info ) const
		{
			std::size_t hash( 0 );
			for( char const *p( info.name() ); *p; ++ p )
				hash_combine( hash, *p );
			return hash;
		}
	};

	template<>
	struct hash< types::Type >
	{
		std::size_t operator ()( types::Type const &type ) const
		{
			std::size_t hash( 0 );
			for( char const *p( type.name() ); *p; ++ p )
				hash_combine( hash, *p );
			return hash;
		}
	};
}

#endif
