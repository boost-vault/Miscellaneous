#ifndef TYPES_FAIL_H
#define TYPES_FAIL_H

#include <exception>

namespace types
{
	//Fail is the base class of all exceptions.
	//It provides a string identifying the exception.
	struct Fail : std::exception
	{
		char const *what() const throw()
		{
			return typeid( *this ).name();
		}
	};
}

#endif
