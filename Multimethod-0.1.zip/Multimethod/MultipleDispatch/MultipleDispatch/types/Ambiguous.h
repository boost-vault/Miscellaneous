#ifndef TYPES_AMBIGUOUS_H
#define TYPES_AMBIGUOUS_H

#include "Fail.h"
#include <vector>

namespace types
{
	//Ambiguous contains the search key and the resulting keys of equal cost.
	template< class K >
	class Ambiguous : public Fail
	{
		typedef std::vector< K > Keys;

	public:
		typedef K Key;

		Ambiguous( Key const &key, Key const &first, Keys &rest ) : m_key( key ), m_first( first )
		{
			rest.swap( m_rest );
		}

		~Ambiguous() throw()
		{
		}

		Key const &GetKey() const
		{
			return m_key;
		}

		std::size_t Size() const
		{
			return 1 + m_rest.size();
		}

		Key const &operator []( std::size_t index ) const
		{
			if( index )
				return m_rest[ index - 1 ];
			return m_first;
		}

	private:
		Key m_key;
		Key m_first;
		Keys m_rest;
	};
}

#endif
