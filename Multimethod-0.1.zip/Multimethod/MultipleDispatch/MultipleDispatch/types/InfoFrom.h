#ifndef TYPES_INFOFROM_H
#define TYPES_INFOFROM_H

#include "Info.h"
#include "RemoveQualifiers.h"

namespace types
{
	//InfoFrom uses typeid to get the appropriate std::type_info for an object.
	//It ensures no pointer types are used.  It accepts null pointers.
	inline Info InfoFrom( void * )
	{
		return typeid( void );
	}

	inline Info InfoFrom( void const * )
	{
		return typeid( void const );
	}

	inline Info InfoFrom( void volatile * )
	{
		return typeid( void volatile );
	}

	inline Info InfoFrom( void const volatile * )
	{
		return typeid( void const volatile );
	}

	template< class T >
	inline Info InfoFrom( T &t )
	{
		return typeid( t );
	}

	template< class T >
	inline Info InfoFrom( T *pT )
	{
		return pT ? typeid( *pT ) : typeid( T );
	}

	template< class T >
	inline Info InfoFrom( T ** )
	{
		return typeid( typename RemoveQualifiers< T >::type );
	}

	template< class T >
	inline Info InfoFrom( T *const * )
	{
		return typeid( typename RemoveQualifiers< T >::type );
	}

	template< class T >
	inline Info InfoFrom( T *volatile * )
	{
		return typeid( typename RemoveQualifiers< T >::type );
	}

	template< class T >
	inline Info InfoFrom( T *const volatile * )
	{
		return typeid( typename RemoveQualifiers< T >::type );
	}
}

#endif
