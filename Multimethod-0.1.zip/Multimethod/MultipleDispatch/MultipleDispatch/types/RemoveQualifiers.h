#ifndef TYPES_REMOVEQUALIFIERS_H
#define TYPES_REMOVEQUALIFIERS_H

namespace types
{
	//RemoveQualifiers strips a type.
	template< class T >
	struct RemoveQualifiers
	{
		typedef T type;
	};

	template< class T >
	struct RemoveQualifiers< T const >
	{
		typedef typename RemoveQualifiers< T >::type type;
	};

	template< class T >
	struct RemoveQualifiers< T volatile >
	{
		typedef typename RemoveQualifiers< T >::type type;
	};

	template< class T >
	struct RemoveQualifiers< T const volatile >
	{
		typedef typename RemoveQualifiers< T >::type type;
	};

	template< class T >
	struct RemoveQualifiers< T & >
	{
		typedef typename RemoveQualifiers< T >::type type;
	};

	template< class T >
	struct RemoveQualifiers< T * >
	{
		typedef typename RemoveQualifiers< T >::type type;
	};
}

#endif
