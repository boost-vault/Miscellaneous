//This file is included multiple times to define multimethods with different numbers of parameters.
namespace types
{
	template< TYPES_DISPATCHER_TEMPLATE_PARAMETERS( class P ), class R, class MutexPolicy = SharedMutex, template< class, class > class Caster = DynamicCaster >
	class TYPES_DISPATCHER_NAME : public MethodMap< TYPES_DISPATCHER_KEY_PARAMETERS( Info ), TYPES_DISPATCHER_KEY_PARAMETERS( Type ), R ( * )( TYPES_DISPATCHER_TEMPLATE_PARAMETERS( P ) ), MutexPolicy >
	{
	public:
		typedef typename MethodMap< TYPES_DISPATCHER_KEY_PARAMETERS( Info ), TYPES_DISPATCHER_KEY_PARAMETERS( Type ), R ( * )( TYPES_DISPATCHER_TEMPLATE_PARAMETERS( P ) ), MutexPolicy >::CacheKey CacheKey;
		typedef typename MethodMap< TYPES_DISPATCHER_KEY_PARAMETERS( Info ), TYPES_DISPATCHER_KEY_PARAMETERS( Type ), R ( * )( TYPES_DISPATCHER_TEMPLATE_PARAMETERS( P ) ), MutexPolicy >::MethodKey MethodKey;
		typedef typename MethodMap< TYPES_DISPATCHER_KEY_PARAMETERS( Info ), TYPES_DISPATCHER_KEY_PARAMETERS( Type ), R ( * )( TYPES_DISPATCHER_TEMPLATE_PARAMETERS( P ) ), MutexPolicy >::MethodPtr MethodPtr;
		typedef typename MethodMap< TYPES_DISPATCHER_KEY_PARAMETERS( Info ), TYPES_DISPATCHER_KEY_PARAMETERS( Type ), R ( * )( TYPES_DISPATCHER_TEMPLATE_PARAMETERS( P ) ), MutexPolicy >::KeyMethod KeyMethod;

		//Register returns the data used by MethodRegistration to register a method.
		//It defines the function that casts parameters to the appropriate types.
		template< TYPES_DISPATCHER_TEMPLATE_PARAMETERS( class T ), R ( *pMethod )( TYPES_DISPATCHER_METHOD_PARAMETERS ) >
		static KeyMethod Register()
		{
			struct Local
			{
				static R Method( TYPES_DISPATCHER_DISPATCH_PARAMETERS )
				{
					return ( *pMethod )( TYPES_DISPATCHER_CAST_PARAMETERS );
				}
			};
			return MakeCouple( Key( TYPES_DISPATCHER_TYPES_FROM ), &Local::Method );
		};

		typedef types::Ambiguous< MethodKey > Ambiguous;
		typedef types::NotRegistered< CacheKey > NotRegistered;
		typedef types::Registered< MethodKey > Registered;

		//This constructor causes compile errors if PublicBasesOf is not defined for a parameter.
		TYPES_DISPATCHER_NAME()
		{
			TYPES_DISPATCHER_VERIFY_PARAMETERS
		}

		//When invoked, a multimethod first checks the cache, then attempts to load the cache
		//with the best method, then throws if there isn't one.
		R operator ()( TYPES_DISPATCHER_DISPATCH_PARAMETERS )
		{
			CacheKey key( Key( TYPES_DISPATCHER_INFOS_FROM ) );
			if( MethodPtr pMethod = CheckCache( key ) )
				return ( *pMethod )( TYPES_DISPATCHER_CALL_PARAMETERS );
			if( MethodPtr pMethod = LoadCache( key ) )
				return ( *pMethod )( TYPES_DISPATCHER_CALL_PARAMETERS );
			throw NotRegistered( key );
		}

	protected:
		template< class T >
		static TYPES_DISPATCHER_KEY_PARAMETERS( T ) Key( TYPES_DISPATCHER_MAKE_KEY_PARAMETERS )
		{
			return TYPES_DISPATCHER_MAKE_KEY;
		}
	};

	//This derivation works around a problem in Visual C++ 8, where the return type of the method is lost when defining Register.
	template< TYPES_DISPATCHER_TEMPLATE_PARAMETERS( class P ), class R, class MutexPolicy, template< class, class > class Caster >
	class Multimethod< R ( TYPES_DISPATCHER_TEMPLATE_PARAMETERS( P ) ), MutexPolicy, Caster > : public TYPES_DISPATCHER_NAME< TYPES_DISPATCHER_TEMPLATE_PARAMETERS( P ), R, MutexPolicy, Caster >
	{
	};
}
