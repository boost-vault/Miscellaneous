#ifndef TYPES_MULTIMETHOD_H
#define TYPES_MULTIMETHOD_H

#include "CopyQualifiers.h"
#include "DynamicCaster.h"
#include "InfoFrom.h"
#include "MethodMap.h"
#include "NotRegistered.h"
#include "RemoveQualifiers.h"
#include "boost/preprocessor.hpp"

namespace types
{
	template< class F, class MutexPolicy = SharedMutex, template< class, class > class Caster = DynamicCaster >
	class Multimethod;

	//MethodManager<>::GetMethod provides an initialized method singleton.
	//MethodManager<>::m_method ensures it is initialized before main begins.
	template< class M >
	class MethodManager
	{
	public:
		static M &GetMethod();

	private:
		static M const &m_method;
	};

	template< class M >
	M &MethodManager< M >::GetMethod()
	{
		static M method;
		return method;
	}

	template< class M >
	M const &MethodManager< M >::m_method = GetMethod();

	//This undefined specialization prevents the direct use of Multimethod<>.
	template< class F, class MutexPolicy, template< class, class > class Caster >
	class MethodManager< Multimethod< F, MutexPolicy, Caster > >;

	//MethodRegistration registers a method with the multimethod contained in the
	//appropriate MethodManager.  It unregisters it when it is destroyed.  Client
	//libraries need only export specializations of MethodRegistration and functions
	//that call the multimethods in the appropriate MethodManagers.  This reduces
	//the potential for conflicting symbols.  It contains a method key pointer
	//because the MethodKey is not exported, and that causes Intel compiler 10.1.020
	//to complain.
	template< class M >
	class MethodRegistration
	{
		typedef M Method;
		typedef typename Method::MethodKey MethodKey;
		typedef typename Method::KeyMethod KeyMethod;

	public:
		MethodRegistration( KeyMethod const &keyMethod );
		~MethodRegistration();

	private:
		MethodRegistration( MethodRegistration const & );
		MethodRegistration &operator =( MethodRegistration const & );

		MethodKey *m_pKey;
	};

	template< class M >
	MethodRegistration< M >::MethodRegistration( KeyMethod const &keyMethod ) : m_pKey()
	{
		std::auto_ptr< MethodKey > pKey( new MethodKey( keyMethod.first ) );
		MethodManager< M >::GetMethod().Add( *pKey, keyMethod.second );
		m_pKey = pKey.release();
	}

	template< class M >
	MethodRegistration< M >::~MethodRegistration()
	{
		std::auto_ptr< MethodKey > pKey( m_pKey );
		MethodManager< M >::GetMethod().Remove( *pKey );
	}
}

//Multimethod is specialized for 1 to TYPES_MULTIMETHOD_ARGUMENT_MAX arguments.

#define TYPES_DISPATCHER_NAME							BOOST_PP_CAT( Dispatcher, TYPES_DISPATCHER_ARGUMENT_COUNT )

#define TYPES_DISPATCHER_TEMPLATE_PARAMETER( z, n, t )	BOOST_PP_COMMA_IF( n ) BOOST_PP_CAT( t, n )
#define TYPES_DISPATCHER_TEMPLATE_PARAMETERS( t )		BOOST_PP_REPEAT( TYPES_DISPATCHER_ARGUMENT_COUNT, TYPES_DISPATCHER_TEMPLATE_PARAMETER, t )

#define TYPES_DISPATCHER_QUALIFY_PARAMETER( n )			typename CopyQualifiers< BOOST_PP_CAT( P, n ), BOOST_PP_CAT( T, n ) >::type
#define TYPES_DISPATCHER_DISQUALIFY_PARAMETER( n )		typename RemoveQualifiers< BOOST_PP_CAT( P, n ) >::type

#define TYPES_DISPATCHER_METHOD_PARAMETER( z, n, d )	BOOST_PP_COMMA_IF( n ) TYPES_DISPATCHER_QUALIFY_PARAMETER( n ) BOOST_PP_CAT( t, n )
#define TYPES_DISPATCHER_METHOD_PARAMETERS				BOOST_PP_REPEAT( TYPES_DISPATCHER_ARGUMENT_COUNT, TYPES_DISPATCHER_METHOD_PARAMETER, 0 )

#define TYPES_DISPATCHER_CAST_PARAMETER( z, n, a )		BOOST_PP_COMMA_IF( n ) Caster< BOOST_PP_CAT( P, n ), TYPES_DISPATCHER_QUALIFY_PARAMETER( n ) >()( BOOST_PP_CAT( p, n ) )
#define TYPES_DISPATCHER_CAST_PARAMETERS				BOOST_PP_REPEAT( TYPES_DISPATCHER_ARGUMENT_COUNT, TYPES_DISPATCHER_CAST_PARAMETER, 0 )

#define TYPES_DISPATCHER_DISPATCH_PARAMETER( z, n, d )	BOOST_PP_COMMA_IF( n ) BOOST_PP_CAT( P, n ) BOOST_PP_CAT( p, n )
#define TYPES_DISPATCHER_DISPATCH_PARAMETERS			BOOST_PP_REPEAT( TYPES_DISPATCHER_ARGUMENT_COUNT, TYPES_DISPATCHER_DISPATCH_PARAMETER, 0 )

#define TYPES_DISPATCHER_VERIFY_PARAMETER( z, n, d )	TypeFrom< TYPES_DISPATCHER_DISQUALIFY_PARAMETER( n ) >();
#define TYPES_DISPATCHER_VERIFY_PARAMETERS				BOOST_PP_REPEAT( TYPES_DISPATCHER_ARGUMENT_COUNT, TYPES_DISPATCHER_VERIFY_PARAMETER, 0 )

#define TYPES_DISPATCHER_KEY_START( z, n, t )			Couple< t,
#define TYPES_DISPATCHER_KEY_END( z, n, t )				>
#define TYPES_DISPATCHER_KEY_PARAMETERS( t )			BOOST_PP_REPEAT( BOOST_PP_SUB( TYPES_DISPATCHER_ARGUMENT_COUNT, 1 ), TYPES_DISPATCHER_KEY_START, t ) t BOOST_PP_REPEAT( BOOST_PP_SUB( TYPES_DISPATCHER_ARGUMENT_COUNT, 1 ), TYPES_DISPATCHER_KEY_END, t )

#define TYPES_DISPATCHER_MAKE_KEY_START( z, n, d )		MakeCouple BOOST_PP_LPAREN() BOOST_PP_CAT( t, n ),
#define TYPES_DISPATCHER_MAKE_KEY_END( z, n, d )		BOOST_PP_RPAREN()
#define TYPES_DISPATCHER_MAKE_KEY						BOOST_PP_REPEAT( BOOST_PP_SUB( TYPES_DISPATCHER_ARGUMENT_COUNT, 1 ), TYPES_DISPATCHER_MAKE_KEY_START, 0 ) BOOST_PP_CAT( t, BOOST_PP_SUB( TYPES_DISPATCHER_ARGUMENT_COUNT, 1 ) ) BOOST_PP_REPEAT( BOOST_PP_SUB( TYPES_DISPATCHER_ARGUMENT_COUNT, 1 ), TYPES_DISPATCHER_MAKE_KEY_END, 0 )

#define TYPES_DISPATCHER_TYPE_FROM( z, n, d )			BOOST_PP_COMMA_IF( n ) TypeFrom< BOOST_PP_CAT( T, n ) >()
#define TYPES_DISPATCHER_TYPES_FROM						BOOST_PP_REPEAT( TYPES_DISPATCHER_ARGUMENT_COUNT, TYPES_DISPATCHER_TYPE_FROM, 0 )

#define TYPES_DISPATCHER_INFO_FROM( z, n, d )			BOOST_PP_COMMA_IF( n ) InfoFrom( BOOST_PP_CAT( p, n ) )
#define TYPES_DISPATCHER_INFOS_FROM						BOOST_PP_REPEAT( TYPES_DISPATCHER_ARGUMENT_COUNT, TYPES_DISPATCHER_INFO_FROM, 0 )

#define TYPES_DISPATCHER_CALL_PARAMETER( z, n, d )		BOOST_PP_COMMA_IF( n ) BOOST_PP_CAT( p, n )
#define TYPES_DISPATCHER_CALL_PARAMETERS				BOOST_PP_REPEAT( TYPES_DISPATCHER_ARGUMENT_COUNT, TYPES_DISPATCHER_CALL_PARAMETER, 0 )

#define TYPES_DISPATCHER_MAKE_KEY_PARAMETER( z, n, d )	BOOST_PP_COMMA_IF( n ) T const & BOOST_PP_CAT( t, n )
#define TYPES_DISPATCHER_MAKE_KEY_PARAMETERS			BOOST_PP_REPEAT( TYPES_DISPATCHER_ARGUMENT_COUNT, TYPES_DISPATCHER_MAKE_KEY_PARAMETER, 0 )

#define TYPES_DISPATCHER_ARGUMENT_COUNT BOOST_PP_ITERATION()

#ifndef TYPES_MULTIMETHOD_ARGUMENT_MAX
#define TYPES_MULTIMETHOD_ARGUMENT_MAX 10
#endif

#define BOOST_PP_FILENAME_1 "types/Dispatcher.h"
#define BOOST_PP_ITERATION_LIMITS ( 1, TYPES_MULTIMETHOD_ARGUMENT_MAX )

#include BOOST_PP_ITERATE()

#undef TYPES_DISPATCHER_NAME

#undef TYPES_DISPATCHER_TEMPLATE_PARAMETER
#undef TYPES_DISPATCHER_TEMPLATE_PARAMETERS

#undef TYPES_DISPATCHER_QUALIFY_PARAMETER
#undef TYPES_DISPATCHER_DISQUALIFY_PARAMETER

#undef TYPES_DISPATCHER_METHOD_PARAMETER
#undef TYPES_DISPATCHER_METHOD_PARAMETERS

#undef TYPES_DISPATCHER_CAST_PARAMETER
#undef TYPES_DISPATCHER_CAST_PARAMETERS

#undef TYPES_DISPATCHER_DISPATACH_PARAMETER
#undef TYPES_DISPATCHER_DISPATACH_PARAMETERS

#undef TYPES_DISPATCHER_VERIFY_PARAMETER
#undef TYPES_DISPATCHER_VERIFY_PARAMETERS

#undef TYPES_DISPATCHER_KEY_START
#undef TYPES_DISPATCHER_KEY_END
#undef TYPES_DISPATCHER_KEY_PARAMETERS

#undef TYPES_DISPATCHER_MAKE_KEY_START
#undef TYPES_DISPATCHER_MAKE_KEY_END
#undef TYPES_DISPATCHER_MAKE_KEY

#undef TYPES_DISPATCHER_TYPE_FROM
#undef TYPES_DISPATCHER_TYPES_FROM

#undef TYPES_DISPATCHER_INFO_FROM
#undef TYPES_DISPATCHER_INFOS_FROM

#undef TYPES_DISPATCHER_CALL_PARAMETER
#undef TYPES_DISPATCHER_CALL_PARAMETERS

#undef TYPES_DISPATCHER_MAKE_KEY_PARAMETER
#undef TYPES_DISPATCHER_MAKE_KEY_PARAMETERS

#undef TYPES_DISPATCHER_ARGUMENT_COUNT

#undef TYPES_MULTIMETHOD_ARGUMENT_MAX

#endif
