#ifndef TYPES_COPYQUALIFIERS_H
#define TYPES_COPYQUALIFIERS_H

namespace types
{
	//CopyQualifiers transfers qualifiers from one type to another.
	template< class From, class To >
	struct CopyQualifiers
	{
		typedef To type;
	};

	template< class From, class To >
	struct CopyQualifiers< From const, To >
	{
		typedef typename CopyQualifiers< From, To >::type const type;
	};

	template< class From, class To >
	struct CopyQualifiers< From volatile, To >
	{
		typedef typename CopyQualifiers< From, To >::type volatile type;
	};

	template< class From, class To >
	struct CopyQualifiers< From const volatile, To >
	{
		typedef typename CopyQualifiers< From, To >::type const volatile type;
	};

	template< class From, class To >
	struct CopyQualifiers< From &, To >
	{
		typedef typename CopyQualifiers< From, To >::type &type;
	};

	template< class From, class To >
	struct CopyQualifiers< From *, To >
	{
		typedef typename CopyQualifiers< From, To >::type *type;
	};
}

#endif
