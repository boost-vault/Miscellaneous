#ifndef TYPES_COUPLE_H
#define TYPES_COUPLE_H

#include "boost/functional/hash.hpp"

namespace types
{
	//Couple is used in place of std::pair to give the library control over implementation changes.
	//This is important because couples might cross library boundaries.  They mustn't change unexpectedly.
	template< class F, class S >
	struct Couple
	{
		typedef F First;
		First first;

		typedef S Second;
		Second second;
	};

	template< class F1, class S1, class F2, class S2 >
	inline bool operator ==( Couple< F1, S1 > const &lhs, Couple< F2, S2 > const &rhs )
	{
		return lhs.first == rhs.first && lhs.second == rhs.second;
	}

	template< class F1, class S1, class F2, class S2 >
	inline bool operator !=( Couple< F1, S1 > const &lhs, Couple< F2, S2 > const &rhs )
	{
		return lhs.first != rhs.first || lhs.second != rhs.second;
	}

	template< class F, class S >
	inline Couple< F, S > MakeCouple( F const &f, S const &s )
	{
		Couple< F, S > couple = { f, s };
		return couple;
	}

	template< class T >
	inline T CopyCouple( T const &t )
	{
		return t;
	}

	template< class C, class F, class S >
	inline C CopyCouple( Couple< F, S > const &couple )
	{
		C c = { CopyCouple< typename C::First >( couple.first ), CopyCouple< typename C::Second >( couple.second ) };
		return c;
	}
}

namespace boost
{
	//The specialization of hash for Couple combines the hash of the contents.
	template< class F, class S >
	struct hash< types::Couple< F, S > >
	{
	public:
		std::size_t operator ()( types::Couple< F, S > const &couple ) const
		{
			return Walk( 0, couple );
		}

	private:
		template< class T >
		std::size_t Hash( std::size_t seed, T const &t ) const
		{
			hash_combine( seed, t );
			return seed;
		}

		template< class T, class N >
		std::size_t Walk( std::size_t seed, types::Couple< T, N > const &couple ) const
		{
			return Walk( Hash( seed, couple.first ), couple.second );
		}

		template< class T >
		std::size_t Walk( std::size_t seed, T const &t ) const
		{
			return Hash( seed, t );
		}
	};
}

#endif
