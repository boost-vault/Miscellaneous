#ifndef MULTIPLEDISPATCH_INTERFACE
#ifndef MULTIPLEDISPATCH_DLL
#ifndef _DLL
#define MULTIPLEDISPATCH_DLL 0
#else
#define MULTIPLEDISPATCH_DLL 1
#endif
#endif
#if ! MULTIPLEDISPATCH_DLL
#define MULTIPLEDISPATCH_INTERFACE
#else
#ifndef MULTIPLEDISPATCH_EXPORTS
#define MULTIPLEDISPATCH_INTERFACE __declspec( dllimport )
#else
#define MULTIPLEDISPATCH_INTERFACE __declspec( dllexport )
#endif
#endif
#endif
