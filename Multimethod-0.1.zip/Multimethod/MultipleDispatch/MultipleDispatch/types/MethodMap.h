#ifndef TYPES_METHODMAP_H
#define TYPES_METHODMAP_H

#include "Ambiguous.h"
#include "Couple.h"
#include "Registered.h"
#include "Type.h"
#include "boost/unordered_map.hpp"
#include "boost/thread/locks.hpp"
#include "boost/thread/mutex.hpp"
#include "boost/thread/shared_mutex.hpp"

namespace types
{
	//Mapper<>::Find maps one key to another by finding the best match.
	//If there are no matches, it returns an iterator pointing to the end of the map.
	//If there is more than one best match, it throws Ambiguous.
	template< class M >
	class Mapper
	{
	public:
		typedef M Map;
		typedef typename Map::key_type Key;

		Mapper( Map const &map ) : m_pMap( &map )
		{
		}

		//Key is a list of Couples containing Types
		//(i.e., Couple< Type, Couple< Type, ... > >).
		typename Map::const_iterator Find( Key const &key )
		{
			m_keys.clear();
			m_key = key;
			m_iterator = m_pMap->end();
			m_cost = std::size_t( -1 );
			Walk( 0, m_key );
			if( m_keys.empty() )
				return m_iterator;
			throw Ambiguous< Key >( key, m_iterator->first, m_keys );
		}

	private:
		//Upcast modifies the key, replacing the type in the current position
		//with its base types and testing the result.  It finishes by restoring
		//the original type.
		template< class T >
		void Upcast( std::size_t cost, Type &type, T &t )
		{
			Type derived( type );
			Types const &bases( derived.bases() );
			for( Types::const_iterator begin( bases.begin() ), end( bases.end() ); begin != end; ++ begin )
			{
				Type const &base( *begin );
				type = base;
				Walk( cost + 1, t );
			}
			type = derived;
		}

		template< class T >
		void Walk( std::size_t cost, Couple< Type, T > &couple )
		{
			Walk( cost, couple.second );
			Upcast( cost, couple.first, couple );
		}

		void Walk( std::size_t cost, Type &type )
		{
			//Return if we've already found a better match.
			if( m_cost < cost )
				return;

			//Determine if this key is mapped.
			typename Map::const_iterator iterator( m_pMap->find( m_key ) );
			if( iterator == m_pMap->end() )
			{
				//If not, try its bases.
				Upcast( cost, type, type );
				return;
			}

			//If this is a better match than any previous, use it.
			if( cost < m_cost )
			{
				m_keys.clear();
				m_iterator = iterator;
				m_cost = cost;
				return;
			}

			//Return if we've found this match before.
			if( m_iterator == iterator )
				return;

			//Add this match to the list of matching keys, if it's not there already.
			using std::find;
			if( find( m_keys.begin(), m_keys.end(), m_key ) == m_keys.end() )
				m_keys.push_back( m_key );
		}

		typedef std::vector< Key > Keys;
		Keys m_keys;
		Key m_key;
		typename Map::const_iterator m_iterator;
		Map const *m_pMap;
		std::size_t m_cost;
	};

	//Mutex policies support changing the mutex used to protect the multimethod.
	struct NoMutex
	{
		struct Mutex
		{
		};

		struct ReadLock
		{
			explicit ReadLock( Mutex & )
			{
			}
		};

		struct WriteLock
		{
			explicit WriteLock( Mutex & )
			{
			}
		};

		Mutex mutex;
	};

	struct UniqueMutex
	{
		typedef boost::mutex Mutex;
		typedef boost::lock_guard< Mutex > ReadLock;
		typedef boost::lock_guard< Mutex > WriteLock;
		Mutex mutex;
	};

	struct SharedMutex
	{
		typedef boost::shared_mutex Mutex;
		typedef boost::shared_lock< Mutex > ReadLock;
		typedef boost::lock_guard< Mutex > WriteLock;
		Mutex mutex;
	};

	//MethodMap stores multimethod data and supports adding, removing and finding methods.
	template< class C, class M, class P, class MutexPolicy = SharedMutex >
	class MethodMap : private MutexPolicy
	{
		template< class >
		friend class MethodRegistration;

	protected:
		typedef C CacheKey;
		typedef M MethodKey;
		typedef P MethodPtr;
		typedef Couple< MethodKey, MethodPtr > KeyMethod;

		//Add clears the cache and attempts to map the key to the method.
		//If the key is already mapped it throws Registered.
		void Add( MethodKey const &key, MethodPtr pMethod )
		{
			WriteLock lock( this->mutex );
			m_cache.clear();
			if( ! m_method.insert( typename Method::value_type( key, pMethod ) ).second )
				throw Registered< MethodKey >( key );
		}

		//Remove clears the cache and erases the key.
		void Remove( MethodKey const &key )
		{
			WriteLock lock( this->mutex );
			m_cache.clear();
			m_method.erase( key );
		}

		//CheckCache searches the cache for the key, which, if found, is mapped
		//directly to the appropriate method.
		MethodPtr CheckCache( CacheKey const &key )
		{
			ReadLock lock( this->mutex );
			typename Cache::iterator iterator( m_cache.find( key ) );
			return iterator != m_cache.end() ? iterator->second : 0;
		}

		//LoadCache searches for the appropriate method for the given key.
		//If it finds it, it adds it to the cache.
		MethodPtr LoadCache( CacheKey const &key )
		{
			WriteLock lock( this->mutex );
			typename Method::const_iterator iterator( Mapper< Method >( m_method ).Find( CopyCouple< MethodKey >( key ) ) );
			if( iterator == m_method.end() )
				return 0;
			MethodPtr pMethod( iterator->second );
			m_cache.insert( typename Cache::value_type( key, pMethod ) );
			return pMethod;
		}

	private:
		typedef boost::unordered_map< MethodKey, MethodPtr > Method;
		Method m_method;

		typedef boost::unordered_map< CacheKey, MethodPtr > Cache;
		Cache m_cache;

		typedef typename MutexPolicy::Mutex Mutex;
		typedef typename MutexPolicy::ReadLock ReadLock;
		typedef typename MutexPolicy::WriteLock WriteLock;
	};
}

#endif
