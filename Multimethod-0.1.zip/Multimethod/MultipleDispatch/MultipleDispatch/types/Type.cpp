#include "Type.h"
#include "NotRegistered.h"
#include "Registered.h"
#include "boost/unordered_map.hpp"
#include "boost/thread/locks.hpp"
#include "boost/thread/shared_mutex.hpp"

types::TypeInfo const types::Type::m_ti;

namespace
{
	//Manager manages the mapping of Infos to Types.
	class Manager
	{
	public:
		//TypeFrom searches for a Type given an Info.
		//It throws NotRegistered if it doesn't find one.
		types::Type TypeFrom( types::Info const &info )
		{
			ReadLock lock( m_mutex );
			Map::iterator iterator( m_map.find( info ) );
			if( iterator != m_map.end() )
				return iterator->second.first;
			throw types::NotRegistered< types::Info >( info );
		}

		//Add maps an Info to a Type.  If the correct mapping
		//already exists, it succeeds.  This allows multiple
		//libraries to map the same types when they share dependencies
		//on other libraries that don't map their types themselves.
		void Add( types::Info const &info, types::Type const &type )
		{
			WriteLock lock( m_mutex );
			typedef std::pair< Map::iterator, bool > Result;
			Result result( m_map.insert( Map::value_type( info, Pair( type, 1 ) ) ) );
			if( ! result.second )
			{
				if( type != result.first->second.first || type.bases() != result.first->second.first.bases() )
					throw types::Registered< types::Info >( info );
				++ result.first->second.second;
			}
		}

		//Remove decrements an Info's reference count, and unmaps it
		//if the count reaches zero.
		void Remove( types::Info const &info )
		{
			WriteLock lock( m_mutex );
			Map::iterator iterator( m_map.find( info ) );
			if( iterator != m_map.end() && ! -- iterator->second.second )
				m_map.erase( iterator );
		}

	private:
		typedef std::pair< types::Type, std::size_t > Pair;
		typedef boost::unordered_map< types::Info, Pair > Map;
		Map m_map;

		typedef boost::shared_mutex Mutex;
		typedef boost::shared_lock< Mutex > ReadLock;
		typedef boost::lock_guard< Mutex > WriteLock;
		Mutex m_mutex;
	};

	//GetManager provides an initialized manager singleton.
	Manager &GetManager()
	{
		static Manager manager;
		return manager;
	}

	//manager ensures the manager singleton is initialized before main begins.
	Manager const &manager = GetManager();
}

//Constructor for Type from Info that uses the manager to find the mapping.
types::Type::Type( Info const &info ) : m_pTypeInfo( GetManager().TypeFrom( info ).m_pTypeInfo )
{
}

types::TypeRegistration::TypeRegistration( Couple< Info, Type > const &couple ) : m_info( couple.first )
{
	GetManager().Add( m_info, couple.second );
}

types::TypeRegistration::~TypeRegistration()
{
	GetManager().Remove( m_info );
}

namespace
{
	//Register fundamental types.
	types::TypeRegistration registerVoid( types::Register< void >() );
	types::TypeRegistration registerBool( types::Register< bool >() );
	types::TypeRegistration registerChar( types::Register< char >() );
	types::TypeRegistration registerWchar( types::Register< wchar_t >() );
	types::TypeRegistration registerSignedChar( types::Register< signed char >() );
	types::TypeRegistration registerUnsignedChar( types::Register< unsigned char >() );
	types::TypeRegistration registerSignedShort( types::Register< signed short >() );
	types::TypeRegistration registerUnsignedShort( types::Register< unsigned short >() );
	types::TypeRegistration registerSignedInt( types::Register< signed int >() );
	types::TypeRegistration registerUnsignedInt( types::Register< unsigned int >() );
	types::TypeRegistration registerSignedLong( types::Register< signed long >() );
	types::TypeRegistration registerUnsignedLong( types::Register< unsigned long >() );
	types::TypeRegistration registerSignedLongLong( types::Register< signed long long >() );
	types::TypeRegistration registerUnsignedLongLong( types::Register< unsigned long long >() );
	types::TypeRegistration registerFloat( types::Register< float >() );
	types::TypeRegistration registerDouble( types::Register< double >() );
	types::TypeRegistration registerLongDouble( types::Register< long double >() );
}
