#ifndef TYPES_INFO_H
#define TYPES_INFO_H

#include "Interface.h"
#include <typeinfo>

namespace types
{
	//Info is a wrapper for std::type_info based on Loki::TypeInfo.
	//It provides std::type_info's interface with copying.
	class MULTIPLEDISPATCH_INTERFACE Info
	{
	public:
		Info( std::type_info const &ti = typeid( Info ) ) : m_pTypeInfo( &ti )
		{
		}

		char const *name() const
		{
			return m_pTypeInfo->name();
		}

		bool before( Info const &rhs ) const
		{
			return m_pTypeInfo->before( *rhs.m_pTypeInfo ) != 0;
		}

		friend bool operator ==( Info const &lhs, Info const &rhs )
		{
			return *lhs.m_pTypeInfo == *rhs.m_pTypeInfo;
		}

		friend bool operator !=( Info const &lhs, Info const &rhs )
		{
			return *lhs.m_pTypeInfo != *rhs.m_pTypeInfo;
		}

	private:
		std::type_info const *m_pTypeInfo;
	};

	inline bool operator <( Info const &lhs, Info const &rhs )
	{
		return lhs.before( rhs );
	}

	inline bool operator >( Info const &lhs, Info const &rhs )
	{
		return rhs < lhs;
	}

	inline bool operator <=( Info const &lhs, Info const &rhs )
	{
		return ! ( lhs > rhs );
	}

	inline bool operator >=( Info const &lhs, Info const &rhs )
	{
		return ! ( lhs < rhs );
	}
}

#endif
