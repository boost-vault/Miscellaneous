#ifndef TYPES_DYNAMICCASTER_H
#define TYPES_DYNAMICCASTER_H

namespace types
{
	//DynamicCaster uses dynamic_cast to get from one type to another when necessary.
	template< class From, class To >
	struct DynamicCaster;

	template< class T >
	struct DynamicCaster< T, T >
	{
		T &operator ()( T &t ) const
		{
			return t;
		}
	};

	template< class T >
	struct DynamicCaster< T &, T & >
	{
		T &operator ()( T &t ) const
		{
			return t;
		}
	};

	template< class From, class To >
	struct DynamicCaster< From &, To & >
	{
		To &operator ()( From &from ) const
		{
			return dynamic_cast< To & >( from );
		}
	};

	template< class T >
	struct DynamicCaster< T *, T * >
	{
		T *operator ()( T *pT ) const
		{
			return pT;
		}
	};

	template< class From, class To >
	struct DynamicCaster< From *, To * >
	{
		To *operator ()( From *from ) const
		{
			return dynamic_cast< To * >( from );
		}
	};
}

#endif
