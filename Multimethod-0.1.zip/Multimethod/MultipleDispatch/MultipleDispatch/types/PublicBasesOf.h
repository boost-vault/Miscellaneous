#ifndef TYPES_PUBLICBASESOF_H
#define TYPES_PUBLICBASESOF_H

#include "boost/mpl/vector.hpp"

namespace types
{
	using boost::mpl::vector;

	//PublicBasesOf defines a vector containing the public base
	//classes of the type for which it is specialized.
	template< class T >
	struct PublicBasesOf;

	template<>
	struct PublicBasesOf< void > : vector<>
	{
	};

	template<>
	struct PublicBasesOf< bool > : vector<>
	{
	};

	template<>
	struct PublicBasesOf< char > : vector<>
	{
	};

	template<>
	struct PublicBasesOf< wchar_t > : vector<>
	{
	};

	template<>
	struct PublicBasesOf< signed char > : vector<>
	{
	};

	template<>
	struct PublicBasesOf< unsigned char > : vector<>
	{
	};

	template<>
	struct PublicBasesOf< signed short > : vector<>
	{
	};

	template<>
	struct PublicBasesOf< unsigned short > : vector<>
	{
	};

	template<>
	struct PublicBasesOf< signed int > : vector<>
	{
	};

	template<>
	struct PublicBasesOf< unsigned int > : vector<>
	{
	};

	template<>
	struct PublicBasesOf< signed long > : vector<>
	{
	};

	template<>
	struct PublicBasesOf< unsigned long > : vector<>
	{
	};

	template<>
	struct PublicBasesOf< signed long long > : vector<>
	{
	};

	template<>
	struct PublicBasesOf< unsigned long long > : vector<>
	{
	};

	template<>
	struct PublicBasesOf< float > : vector<>
	{
	};

	template<>
	struct PublicBasesOf< double > : vector<>
	{
	};

	template<>
	struct PublicBasesOf< long double > : vector<>
	{
	};
}

#endif
