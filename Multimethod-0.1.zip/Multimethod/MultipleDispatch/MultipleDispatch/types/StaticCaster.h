#ifndef TYPES_STATICCASTER_H
#define TYPES_STATICCASTER_H

namespace types
{
	//StaticCaster uses static_cast to get from one type to another when necessary.
	//It does not support conversions such as float to double.
	template< class From, class To >
	struct StaticCaster;

	template< class T >
	struct StaticCaster< T, T >
	{
		T &operator ()( T &t ) const
		{
			return t;
		}
	};

	template< class T >
	struct StaticCaster< T &, T & >
	{
		T &operator ()( T &t ) const
		{
			return t;
		}
	};

	template< class From, class To >
	struct StaticCaster< From &, To & >
	{
		To &operator ()( From &from ) const
		{
			return static_cast< To & >( from );
		}
	};

	template< class T >
	struct StaticCaster< T *, T * >
	{
		T *operator ()( T *pT ) const
		{
			return pT;
		}
	};

	template< class From, class To >
	struct StaticCaster< From *, To * >
	{
		To *operator ()( From *from ) const
		{
			return static_cast< To * >( from );
		}
	};
}

#endif
