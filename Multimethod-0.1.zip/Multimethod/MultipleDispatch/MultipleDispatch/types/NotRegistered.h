#ifndef TYPES_NOTREGISTERED_H
#define TYPES_NOTREGISTERED_H

#include "Fail.h"

namespace types
{
	//NotRegistered is thrown when a key isn't registered and it should be.
	template< class K >
	class NotRegistered : public Fail
	{
	public:
		typedef K Key;

		explicit NotRegistered( Key const &key ) : m_key( key )
		{
		}

		Key const &GetKey() const
		{
			return m_key;
		}

	private:
		Key m_key;
	};
}

#endif
