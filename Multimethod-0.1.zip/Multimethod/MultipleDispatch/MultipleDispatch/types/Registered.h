#ifndef TYPES_REGISTERED_H
#define TYPES_REGISTERED_H

#include "Fail.h"

namespace types
{
	//Registered is thrown when a key is registered and it shouldn't be.
	template< class K >
	class Registered : public Fail
	{
	public:
		typedef K Key;

		explicit Registered( Key const &key ) : m_key( key )
		{
		}

		Key const &GetKey() const
		{
			return m_key;
		}

	private:
		Key m_key;
	};
}

#endif
