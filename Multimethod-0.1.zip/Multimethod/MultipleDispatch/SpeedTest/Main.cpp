#include "timing/Clock.h"
#include "types/Multimethod.h"
#include <iostream>

struct E;
struct D;
struct C;
struct B;
struct A
{
	virtual ~A()
	{
	}

	virtual std::pair< types::Info, types::Info > Test( A const & ) const = 0;
	virtual std::pair< types::Info, types::Info > TestB( B const & ) const = 0;
	virtual std::pair< types::Info, types::Info > TestC( C const & ) const = 0;
	virtual std::pair< types::Info, types::Info > TestD( D const & ) const = 0;
	virtual std::pair< types::Info, types::Info > TestE( E const & ) const = 0;
};

struct B : A
{
	std::pair< types::Info, types::Info > Test( A const & ) const;
	std::pair< types::Info, types::Info > TestB( B const & ) const;
	std::pair< types::Info, types::Info > TestC( C const & ) const;
	std::pair< types::Info, types::Info > TestD( D const & ) const;
	std::pair< types::Info, types::Info > TestE( E const & ) const;
};

struct C : A
{
	std::pair< types::Info, types::Info > Test( A const & ) const;
	std::pair< types::Info, types::Info > TestB( B const & ) const;
	std::pair< types::Info, types::Info > TestC( C const & ) const;
	std::pair< types::Info, types::Info > TestD( D const & ) const;
	std::pair< types::Info, types::Info > TestE( E const & ) const;
};

struct D : B
{
	std::pair< types::Info, types::Info > Test( A const & ) const;
	std::pair< types::Info, types::Info > TestB( B const & ) const;
	std::pair< types::Info, types::Info > TestC( C const & ) const;
	std::pair< types::Info, types::Info > TestD( D const & ) const;
	std::pair< types::Info, types::Info > TestE( E const & ) const;
};

struct E : C
{
	std::pair< types::Info, types::Info > Test( A const & ) const;
	std::pair< types::Info, types::Info > TestB( B const & ) const;
	std::pair< types::Info, types::Info > TestC( C const & ) const;
	std::pair< types::Info, types::Info > TestD( D const & ) const;
	std::pair< types::Info, types::Info > TestE( E const & ) const;
};

inline std::pair< types::Info, types::Info > Identify( B const &, B const & )
{
	return std::pair< types::Info, types::Info >( typeid( B const & ), typeid( B const & ) );
}

inline std::pair< types::Info, types::Info > Identify( B const &, C const & )
{
	return std::pair< types::Info, types::Info >( typeid( B const & ), typeid( C const & ) );
}

inline std::pair< types::Info, types::Info > Identify( B const &, D const & )
{
	return std::pair< types::Info, types::Info >( typeid( B const & ), typeid( D const & ) );
}

inline std::pair< types::Info, types::Info > Identify( B const &, E const & )
{
	return std::pair< types::Info, types::Info >( typeid( B const & ), typeid( E const & ) );
}

inline std::pair< types::Info, types::Info > Identify( C const &, B const & )
{
	return std::pair< types::Info, types::Info >( typeid( C const & ), typeid( B const & ) );
}

inline std::pair< types::Info, types::Info > Identify( C const &, C const & )
{
	return std::pair< types::Info, types::Info >( typeid( C const & ), typeid( C const & ) );
}

inline std::pair< types::Info, types::Info > Identify( C const &, D const & )
{
	return std::pair< types::Info, types::Info >( typeid( C const & ), typeid( D const & ) );
}

inline std::pair< types::Info, types::Info > Identify( C const &, E const & )
{
	return std::pair< types::Info, types::Info >( typeid( C const & ), typeid( E const & ) );
}

inline std::pair< types::Info, types::Info > Identify( D const &, B const & )
{
	return std::pair< types::Info, types::Info >( typeid( D const & ), typeid( B const & ) );
}

inline std::pair< types::Info, types::Info > Identify( D const &, C const & )
{
	return std::pair< types::Info, types::Info >( typeid( D const & ), typeid( C const & ) );
}

inline std::pair< types::Info, types::Info > Identify( D const &, D const & )
{
	return std::pair< types::Info, types::Info >( typeid( D const & ), typeid( D const & ) );
}

inline std::pair< types::Info, types::Info > Identify( D const &, E const & )
{
	return std::pair< types::Info, types::Info >( typeid( D const & ), typeid( E const & ) );
}

inline std::pair< types::Info, types::Info > Identify( E const &, B const & )
{
	return std::pair< types::Info, types::Info >( typeid( E const & ), typeid( B const & ) );
}

inline std::pair< types::Info, types::Info > Identify( E const &, C const & )
{
	return std::pair< types::Info, types::Info >( typeid( E const & ), typeid( C const & ) );
}

inline std::pair< types::Info, types::Info > Identify( E const &, D const & )
{
	return std::pair< types::Info, types::Info >( typeid( E const & ), typeid( D const & ) );
}

inline std::pair< types::Info, types::Info > Identify( E const &, E const & )
{
	return std::pair< types::Info, types::Info >( typeid( E const & ), typeid( E const & ) );
}

std::pair< types::Info, types::Info > B::Test( A const &a ) const
{
	return a.TestB( *this );
}

std::pair< types::Info, types::Info > B::TestB( B const &b ) const
{
	return Identify( b, *this );
}

std::pair< types::Info, types::Info > B::TestC( C const &c ) const
{
	return Identify( c, *this );
}

std::pair< types::Info, types::Info > B::TestD( D const &d ) const
{
	return Identify( d, *this );
}

std::pair< types::Info, types::Info > B::TestE( E const &e ) const
{
	return Identify( e, *this );
}

std::pair< types::Info, types::Info > C::Test( A const &a ) const
{
	return a.TestC( *this );
}

std::pair< types::Info, types::Info > C::TestB( B const &b ) const
{
	return Identify( b, *this );
}

std::pair< types::Info, types::Info > C::TestC( C const &c ) const
{
	return Identify( c, *this );
}

std::pair< types::Info, types::Info > C::TestD( D const &d ) const
{
	return Identify( d, *this );
}

std::pair< types::Info, types::Info > C::TestE( E const &e ) const
{
	return Identify( e, *this );
}

std::pair< types::Info, types::Info > D::Test( A const &a ) const
{
	return a.TestD( *this );
}

std::pair< types::Info, types::Info > D::TestB( B const &b ) const
{
	return Identify( b, *this );
}

std::pair< types::Info, types::Info > D::TestC( C const &c ) const
{
	return Identify( c, *this );
}

std::pair< types::Info, types::Info > D::TestD( D const &d ) const
{
	return Identify( d, *this );
}

std::pair< types::Info, types::Info > D::TestE( E const &e ) const
{
	return Identify( e, *this );
}

std::pair< types::Info, types::Info > E::Test( A const &a ) const
{
	return a.TestE( *this );
}

std::pair< types::Info, types::Info > E::TestB( B const &b ) const
{
	return Identify( b, *this );
}

std::pair< types::Info, types::Info > E::TestC( C const &c ) const
{
	return Identify( c, *this );
}

std::pair< types::Info, types::Info > E::TestD( D const &d ) const
{
	return Identify( d, *this );
}

std::pair< types::Info, types::Info > E::TestE( E const &e ) const
{
	return Identify( e, *this );
}

namespace types
{
	template<>
	struct PublicBasesOf< A > : vector<>
	{
	};

	template<>
	struct PublicBasesOf< B > : vector< A >
	{
	};

	template<>
	struct PublicBasesOf< C > : vector< A >
	{
	};

	template<>
	struct PublicBasesOf< D > : vector< B >
	{
	};

	template<>
	struct PublicBasesOf< E > : vector< C >
	{
	};
}

namespace
{
	types::TypeRegistration registerA( types::Register< A >() );
	types::TypeRegistration registerB( types::Register< B >() );
	types::TypeRegistration registerC( types::Register< C >() );
	types::TypeRegistration registerD( types::Register< D >() );
	types::TypeRegistration registerE( types::Register< E >() );
}

struct TestMethod : public types::Multimethod< std::pair< types::Info, types::Info > ( A const &, A const & ) >
{
};

typedef types::MethodRegistration< TestMethod > TestMethodRegistration;

std::pair< types::Info, types::Info > Test( A const &lhs, A const &rhs )
{
	return types::MethodManager< TestMethod >::GetMethod()( lhs, rhs );
}

namespace
{
	template< class F, class S >
	struct Identifier
	{
		static std::pair< types::Info, types::Info > Method( F first, S second )
		{
			return Identify( first, second );
		}
	};

	TestMethodRegistration registerBB( TestMethod::Register< B, B, &Identifier< B const &, B const & >::Method >() );
	TestMethodRegistration registerBC( TestMethod::Register< B, C, &Identifier< B const &, C const & >::Method >() );
	TestMethodRegistration registerBD( TestMethod::Register< B, D, &Identifier< B const &, D const & >::Method >() );
	TestMethodRegistration registerBE( TestMethod::Register< B, E, &Identifier< B const &, E const & >::Method >() );
	TestMethodRegistration registerCB( TestMethod::Register< C, B, &Identifier< C const &, B const & >::Method >() );
	TestMethodRegistration registerCC( TestMethod::Register< C, C, &Identifier< C const &, C const & >::Method >() );
	TestMethodRegistration registerCD( TestMethod::Register< C, D, &Identifier< C const &, D const & >::Method >() );
	TestMethodRegistration registerCE( TestMethod::Register< C, E, &Identifier< C const &, E const & >::Method >() );
	TestMethodRegistration registerDB( TestMethod::Register< D, B, &Identifier< D const &, B const & >::Method >() );
	TestMethodRegistration registerDC( TestMethod::Register< D, C, &Identifier< D const &, C const & >::Method >() );
	TestMethodRegistration registerDD( TestMethod::Register< D, D, &Identifier< D const &, D const & >::Method >() );
	TestMethodRegistration registerDE( TestMethod::Register< D, E, &Identifier< D const &, E const & >::Method >() );
	TestMethodRegistration registerEB( TestMethod::Register< E, B, &Identifier< E const &, B const & >::Method >() );
	TestMethodRegistration registerEC( TestMethod::Register< E, C, &Identifier< E const &, C const & >::Method >() );
	TestMethodRegistration registerED( TestMethod::Register< E, D, &Identifier< E const &, D const & >::Method >() );
	TestMethodRegistration registerEE( TestMethod::Register< E, E, &Identifier< E const &, E const & >::Method >() );
}

#include "boost/thread/thread.hpp"

int TestThread()
{
	B b;
	C c;
	D d;
	E e;

	for( std::size_t test( 0 ), tests( 1048576 ); test != tests; ++ test )
	{
		Test( b, b );
		Test( b, c );
		Test( b, d );
		Test( b, e );

		Test( c, b );
		Test( c, c );
		Test( c, d );
		Test( c, e );

		Test( d, b );
		Test( d, c );
		Test( d, d );
		Test( d, e );

		Test( e, b );
		Test( e, c );
		Test( e, d );
		Test( e, e );
	}
	return 0;
}

int main()
{
	B b;
	C c;
	D d;
	E e;

	b.Test( b );
	b.Test( c );
	b.Test( d );
	b.Test( e );

	c.Test( b );
	c.Test( c );
	c.Test( d );
	c.Test( e );

	d.Test( b );
	d.Test( c );
	d.Test( d );
	d.Test( e );

	e.Test( b );
	e.Test( c );
	e.Test( d );
	e.Test( e );

	Test( b, b );
	Test( b, c );
	Test( b, d );
	Test( b, e );

	Test( c, b );
	Test( c, c );
	Test( c, d );
	Test( c, e );

	Test( d, b );
	Test( d, c );
	Test( d, d );
	Test( d, e );

	Test( e, b );
	Test( e, c );
	Test( e, d );
	Test( e, e );

	std::size_t tests( 1048576 );

	timing::Clock clock;
	timing::Milliseconds begin( clock.Read() );

	for( std::size_t test( 0 ); test != tests; ++ test )
	{
		b.Test( b );
		b.Test( c );
		b.Test( d );
		b.Test( e );

		c.Test( b );
		c.Test( c );
		c.Test( d );
		c.Test( e );

		d.Test( b );
		d.Test( c );
		d.Test( d );
		d.Test( e );

		e.Test( b );
		e.Test( c );
		e.Test( d );
		e.Test( e );
	}

	timing::Milliseconds end( clock.Read() );
	float duration( ( end - begin ) * 0.001f );
	std::cout << "\nVistor: " << duration << " seconds.\n" << std::endl;

	begin = clock.Read();

	boost::thread testThread0( &TestThread );
	boost::thread testThread1( &TestThread );
	boost::thread testThread2( &TestThread );
	TestThread();
	testThread2.join();
	testThread1.join();
	testThread0.join();

	//for( std::size_t test( 0 ); test != tests; ++ test )
	//{
	//	Test( b, b );
	//	Test( b, c );
	//	Test( b, d );
	//	Test( b, e );

	//	Test( c, b );
	//	Test( c, c );
	//	Test( c, d );
	//	Test( c, e );

	//	Test( d, b );
	//	Test( d, c );
	//	Test( d, d );
	//	Test( d, e );

	//	Test( e, b );
	//	Test( e, c );
	//	Test( e, d );
	//	Test( e, e );
	//}

	end = clock.Read();
	duration = ( end - begin ) * 0.001f;
	std::cout << "\nMultimethod: " << duration << " seconds.\n" << std::endl;

	return 0;
}
