#include "types/Multimethod.h"
#include <iostream>

//User types.
struct A
{
	virtual ~A()
	{
	}
};

struct B : A
{
};

//Method implementations.
void TestMethodBB( B const &, B const & )
{
	char const *pName( typeid( B ).name() );
	std::cout << pName << ", " << pName << std::endl;
}

void TestMethodAA( A const &, A const & )
{
	char const *pName( typeid( A ).name() );
	std::cout << pName << ", " << pName << std::endl;
}

//Specializations of PublicBasesOf
namespace types
{
	template<>
	struct PublicBasesOf< B > : vector< A >
	{
	};

	template<>
	struct PublicBasesOf< A > : vector<>
	{
	};
}

//Multimethod declaration
struct TestMethod : types::Multimethod< void ( A const &, A const & ) >
{
};

//MethodRegistration typedef
typedef types::MethodRegistration< TestMethod > TestRegistration;

//Multimethod interface
void Test( A const &a1, A const &a2 )
{
	types::MethodManager< TestMethod >::GetMethod()( a1, a2 );
}

namespace
{
	//Register user types
	types::TypeRegistration registerB( types::Register< B >() );
	types::TypeRegistration registerA( types::Register< A >() );

	//Register multimethod implementations
	TestRegistration registerBB( TestMethod::Register< B, B, &TestMethodBB >() );
	TestRegistration registerAA( TestMethod::Register< A, A, &TestMethodAA >() );
}

int main()
{
	//Create two objects
	A a;
	B b;

	//Call Test with each combination
	Test( a, a );	//Resolves to TestMethodAA
	Test( a, b );	//Resolves to TestMethodAA
	Test( b, a );	//Resolves to TestMethodAA
	Test( b, b );	//Resolves to TestMethodBB

	return 0;
}
