//  Boost general library SafeIntException.hpp header file ---------------------------//
//
//          Copyright Ziv Levi and Omer Katz 2009.
// Distributed under the Boost Software License, Version 1.0.
//    (See accompanying file LICENSE_1_0.txt or copy at
//          http://www.boost.org/LICENSE_1_0.txt)
//
//  See http://www.boost.org/ for latest version.
//
// Description:
//  This file contains a class which implements a generic exception thrown
//  by the SafeInt library.
//  This exception can be used with either a default error message or a
//  custom erroe message.

#ifndef BOOST_SAFEINT_EXCEPTION_HPP
#define BOOST_SAFEINT_EXCEPTION_HPP

#include <exception>
#include <stdlib.h>
#include <cstring>

#define _BOOST_SAFE_INT_EXCEPTION_DEFAULT_MESSAGE "SafeInt has detected an Inetger overflow/underflow\n"

using namespace std;

namespace boost
{
    class SafeIntException: public exception
    {
        public:
 
            SafeIntException() throw()
            : exception()
            {
                exception_string = (char*)malloc(strlen(_BOOST_SAFE_INT_EXCEPTION_DEFAULT_MESSAGE)+1);
                strcpy(exception_string,_BOOST_SAFE_INT_EXCEPTION_DEFAULT_MESSAGE);
            }

            SafeIntException(const char* message) throw()
            : exception()
            {
                exception_string = (char*)malloc(strlen(message) + strlen(_BOOST_SAFE_INT_EXCEPTION_DEFAULT_MESSAGE) + 1);
                strcpy(_BOOST_SAFE_INT_EXCEPTION_DEFAULT_MESSAGE,message);
                strcat(exception_string,message);
            }

            SafeIntException(const SafeIntException &other) throw()
            : exception(other)
            {
                exception_string = (char*)malloc(strlen(other.exception_string)+1);
                strcpy(exception_string,other.exception_string);
            }

            virtual ~SafeIntException() throw()
            {
                if(exception_string != NULL)
                {
                    free(exception_string);
                    exception_string = NULL;
                }
            }

            virtual const char *what() const throw()
            {
                return exception_string;
            }


    
        private:
            char* exception_string;
    };
}

#endif
