//  Boost general library SafeInt.hpp header file ---------------------------//
//
//          Copyright Ziv Levi and Omer Katz 2009.
// Distributed under the Boost Software License, Version 1.0.
//    (See accompanying file LICENSE_1_0.txt or copy at
//          http://www.boost.org/LICENSE_1_0.txt)
//
//  See http://www.boost.org/ for latest version.
//
// Description:
//  This file is a testing file for the SafeInt library.
//  The tests include testing for for all of the implemented operators'
//  functionality and error detection
//
// This tester is not yet completed and should be continued 

#include <iostream>

#include "SafeInt.hpp"
#include "SafeIntException.hpp"

#define _START_EXCEPTION_TEST try {
#define _CLOSE_EXCEPTION_TEST(testString) printResult(testString, false);\
    } catch(SafeIntException&)\
    {printResult(testString, true);}

using namespace std;
using namespace boost;

void printResult(char* test, bool ok)
{
    printf("Test: %s\tResult: ",test);
    if(ok)
    {
        printf("SUCCESS");
    }
    else
    {
        printf("FAILED");
    }
    printf("\n");
}

void checkConstructors()
{
    printf("Check constructors:\n");
    SafeInt<int> si;
    printResult("default constructor", si.getValue() == 0);
    SafeInt<int>* psi = new SafeInt<int>(1);
    printResult("constructor with value", psi->getValue() == 1);
    SafeInt<short>* psi2 = new SafeInt<short>(*psi);
    free(psi);
    psi = new SafeInt<int>(2);
    printResult("copy constructor", (psi->getValue() == 2) && (psi2->getValue() == 1));
    printf("\n");
}

void checkAssignments()
{
    printf("Check assignments:\n");
    SafeInt<signed int> si = 5;
    SafeInt<unsigned int> usi = 5;
    printResult("assignment", (si.getValue() == 5) && (usi.getValue() == 5));
    _START_EXCEPTION_TEST
    usi = -1;
    _CLOSE_EXCEPTION_TEST("assign negative number to unsigned variable")
    _START_EXCEPTION_TEST
    si = 4294967295;
    _CLOSE_EXCEPTION_TEST("assign too big number to variable")
    _START_EXCEPTION_TEST
    si = -2147483648;
    _CLOSE_EXCEPTION_TEST("assign too small number to variable")
    printf("\n");
}

void checkBooleans()
{
    printf("Check boolean operators:\n");
    SafeInt<int> sint = 5;
    printResult("boolean equal to value", sint == 5);
    printResult("boolean not equal to value", sint != 7);
    SafeInt<unsigned int> suint = 5;
    printResult("boolean equal to Safeint", sint == suint);
    suint = 3;
    printResult("boolean not equal to SafeInt", sint != suint);
    suint = 4294967295;
    sint = -1;
    printResult("unsigned and signed, same hex value", sint != suint);
    printf("\n");
}

void checkAdditions()
{
    printf("Check addition operators:\n");
    SafeInt<int> s1 = 10;
    // int i1 = 10;
    // SafeInt<int> s4 = i1;
    SafeInt<int> s2 = 70;
    SafeInt<int> s3 = s1+s2;
    printResult("addition of safeInts to safeInts", s3==80);
    s1++;
    printResult("increment integer with ++", s1==11);
    printResult("increment integer with int++", s1++==11);
    printResult("increment integer with ++int", ++s1==13);
    s2+=34;
    printResult("incremention by arbitrary number with +=", s2==104);
    SafeInt<unsigned char> c1 = 0xfe;
    SafeInt<unsigned char> c2 = 0x10;
    _START_EXCEPTION_TEST
        c1 += c2;
    _CLOSE_EXCEPTION_TEST("overflow in adding unsigned numbers")
    SafeInt<char> c3 = 0x7f;
    SafeInt<char> c4 = 0x10;
    _START_EXCEPTION_TEST
        c3 += c4;
    _CLOSE_EXCEPTION_TEST("overflow in adding signed numbers")
    printf("\n");
}

void checkReductions()
{
    printf("Check reductions operators:\n");
    SafeInt<int> s1 = 10;
    // int i1 = 10;
    // SafeInt<int> s4 = i1;
    SafeInt<int> s2 = 70;
    SafeInt<int> s3 = s2-s1;
    printResult("reductions of safeInts from safeInts", s3==60);
    s1--;
    printResult("decrement integer with --", s1==9);
    printResult("decrement integer with int--", s1--==9);
    printResult("decrement integer with --int", --s1==7);
    s2-=34;
    printResult("decrement by arbitrary number with -=", s2==36);
    SafeInt<unsigned char> c1 = 0x01;
    SafeInt<unsigned char> c2 = 0x10;
    _START_EXCEPTION_TEST
        c1 -= c2;
    _CLOSE_EXCEPTION_TEST("overflow in substracting unsigned numbers")
    SafeInt<char> c3 = -0x7f;
    SafeInt<char> c4 = 0x10;
    _START_EXCEPTION_TEST
        c3 -= c4;
    _CLOSE_EXCEPTION_TEST("overflow in substracting signed numbers")
    printf("\n");
}

void checkSigns()
{
    printf("Check sign (+ -) operators:\n");
    SafeInt<int> s1 = 11;
    SafeInt<int> s2 = -70;
    SafeInt<int> s3 = -s1;
    printResult("sign - of positive safeInts", -s1==-11);
    printResult("sign - of negative safeInts", -s3==11);
    printResult("sign + of positive safeInts", +s2==-70);    
    printResult("sign + of negative safeInts", -s2==70);
    SafeInt<char> c = -0x80;
    _START_EXCEPTION_TEST
        -c;
    _CLOSE_EXCEPTION_TEST("overflow in negative of min value of signed variable")
    printf("\n");
}

void checkMultiplications()
{
    printf("Check multiplication operators:\n");
    SafeInt<int> s1 = 11;
    SafeInt<int> s2 = 70;
    SafeInt<int> s3 = s2*s1;
    printResult("multiplication of safeInts with safeInts", s3==770);
    s2*=6;
    printResult("multiply by arbitrary number with *=", s2==420);
    SafeInt<unsigned char> c1 = 0xff;
    SafeInt<unsigned char> c2 = 0x10;
    _START_EXCEPTION_TEST
        c1 *= c2;
    _CLOSE_EXCEPTION_TEST("overflow in multiplying numbers")
    printf("\n");
}

void checkDivisions()
{
    printf("Check divisons operators:\n");
    SafeInt<int> s1 = 5;
    SafeInt<int> s2 = 70;
    SafeInt<int> s3 = s2/s1;
    printResult("division of safeInts with safeInts", s3==14);
    s2/=7;
    printResult("divide by arbitrary number with /=", s2==10);
    // TODO: check what's going on here with 10/3
    s2/=3;
    printResult("divide by arbitrary number with /=", s2==3);
    SafeInt<char> c = -128;
    _START_EXCEPTION_TEST
        c /= -1;
    _CLOSE_EXCEPTION_TEST("overflow in dividing min value of signed variable by -1")
    printf("\n");
    printf("\n");
}

void checkMods()
{
    printf("Check mods (%%) operators:\n");
    SafeInt<int> s1 = 5;
    SafeInt<int> s2 = 70;
    SafeInt<int> s3 = s2%s1;
    printResult("mods of safeInts with safeInts", s3==0);
    s3 = s2%9;
    printResult("mods of safeInts with ints", s3==7);
    s2%=6; // s2=70
    printResult("mod by arbitrary number with %=", s2==4);
    s2%=3;
    printResult("mod by arbitrary number with %=", s2==1);
    printf("\n");
}

void checkXors()
{
    printf("Check Xor(^) operators:\n");
    SafeInt<int> s1 = 0xffff;
    SafeInt<int> s2 = 0xffff;
    SafeInt<int> s3 = s2^s1;
    printResult("Xor of safeInts with safeInts", s3==0);
    s3 = s2^s3;
    printResult("Xor of safeInts with ints", s3==0xffff);
    s1 = 0xfa00;
    s2^=s1; // s2= 0xffff ^ 0xfa00 = 0x05ff
    printResult("Xor by arbitrary sa with safeint with ^=", s2==0x05ff);
    s2^=0xf00f; // s2= 0x05ff ^ 0xf00f = 0xf5f0
    printResult("Xor by arbitrary number with ^=", s2==0xf5f0);
    printf("\n");
}

int main()
{
    // Check Constructors:
    checkConstructors();
    // Check Assingnments:
    checkAssignments();
    // Check boolean operators:
    checkBooleans();
    // Check the additions operators:
    checkAdditions();
    // Check the reductions operators:
    checkReductions();
    // Check the signs (+ -) operators:
    checkSigns();
    // Check the multiplications operators:
    checkMultiplications();
    // check division operators:
    checkDivisions();
    // check mod (%) operators:
    checkMods();
    // check xor (^) operators:
    checkXors();
    return 0;
}

