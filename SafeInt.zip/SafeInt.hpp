//  Boost general library SafeInt.hpp header file ---------------------------//
//
//          Copyright Ziv Levi and Omer Katz 2009.
// Distributed under the Boost Software License, Version 1.0.
//    (See accompanying file LICENSE_1_0.txt or copy at
//          http://www.boost.org/LICENSE_1_0.txt)
//
//  See http://www.boost.org/ for latest version.
//
// Description:
//  This file contains a class which implements a library used to inforce safe
//  operations on integers.
//  The library is implemeted as a template class which can accept all existing
//  integer types.
//  In case an overflow or an underflow is detected the library will throw an
//  exception of type SafeIntException.
//
// This library is not yet complete and should be continued

#ifndef BOOST_SAFEINT_HPP
#define BOOST_SAFEINT_HPP

// TODO: change to cmath?
#include <math.h>
#include <limits>
#include "SafeIntException.hpp"

#define BOOST_SIGNED ((T) -1 < 0)

// this macro checks if a and be have the same sign. 
// if they do, the msb is 0, if not it's 1 and the XOR result is negative
#define BOOST_SAME_SIGN(a,b) (!(compare(a ^ b, 0) == -1))

// the class Definition
namespace boost
{
    template <class T> class SafeInt
    {
        public:
            // constructors
            SafeInt();
            template <class S> SafeInt(S num) throw(SafeIntException);
            template <class S> SafeInt(SafeInt<S>& rhs) throw(SafeIntException);

            /** return the value of the object */
            T getValue() const;

            // operators overloading

            /* the assignment operator */
            template <class S> T & operator=(const S &rhs) throw(SafeIntException);
            template <class S> T & operator=(const SafeInt<S> &rhs) throw(SafeIntException);

            /* arithmetic operators */
            T & operator+=(const T &rhs) throw(SafeIntException);
            T & operator-=(const T &rhs) throw(SafeIntException);
            T & operator*=(const T &rhs) throw(SafeIntException);
            T & operator/=(const T &rhs) throw(SafeIntException);
            T & operator%=(const T &rhs) throw(SafeIntException);
            T & operator^=(const T &rhs) throw(SafeIntException);
            template <class S> T & operator+=(const S &rhs) throw(SafeIntException);
            template <class S> T & operator-=(const S &rhs) throw(SafeIntException);
            template <class S> T & operator*=(const S &rhs) throw(SafeIntException);
            template <class S> T & operator/=(const S &rhs) throw(SafeIntException);
            template <class S> T & operator%=(const S &rhs) throw(SafeIntException);
            template <class S> T & operator^=(const S &rhs) throw(SafeIntException);
            template <class S> T & operator+=(const SafeInt<S>& rhs) throw(SafeIntException);
            template <class S> T & operator-=(const SafeInt<S>& rhs) throw(SafeIntException);
            template <class S> T & operator*=(const SafeInt<S>& rhs) throw(SafeIntException);
            template <class S> T & operator/=(const SafeInt<S>& rhs) throw(SafeIntException);
            template <class S> T & operator%=(const SafeInt<S>& rhs) throw(SafeIntException);
            template <class S> T & operator^=(const SafeInt<S>& rhs) throw(SafeIntException);
            // prefix version of ++
            T & operator++() throw(SafeIntException);
            // postfix version of ++
            T & operator++(int notused) throw(SafeIntException);
            // prefix version of --
            T & operator--() throw(SafeIntException);
            // postfix version of --
            T & operator--(int notused) throw(SafeIntException);

            const T operator+(const T &rhs) const throw(SafeIntException);
            const T operator-(const T &rhs) const throw(SafeIntException);
            const T operator*(const T &rhs) const throw(SafeIntException);
            const T operator/(const T &rhs) const throw(SafeIntException);
            const T operator%(const T &rhs) const throw(SafeIntException);
            const T operator^(const T &rhs) const throw(SafeIntException);
            template <class S> const T operator+(const S &rhs) const throw(SafeIntException);
            template <class S> const T operator-(const S &rhs) const throw(SafeIntException);
            template <class S> const T operator*(const S &rhs) const throw(SafeIntException);
            template <class S> const T operator/(const S &rhs) const throw(SafeIntException);
            template <class S> const T operator%(const S &rhs) const throw(SafeIntException);
            template <class S> const T operator^(const S &rhs) const throw(SafeIntException);
            template <class S> const T operator+(const SafeInt<S>& rhs) const throw(SafeIntException);
            template <class S> const T operator-(const SafeInt<S>& rhs) const throw(SafeIntException);
            template <class S> const T operator*(const SafeInt<S>& rhs) const throw(SafeIntException);
            template <class S> const T operator/(const SafeInt<S>& rhs) const throw(SafeIntException);
            template <class S> const T operator%(const SafeInt<S>& rhs) const throw(SafeIntException);
            template <class S> const T operator^(const SafeInt<S>& rhs) const throw(SafeIntException);
            const T & operator+() const throw(SafeIntException);
            const T & operator-() const throw(SafeIntException);

            /* comparison operators */
            template <class S> const bool operator==(const S &rhs) const;
            template <class S> const bool operator!=(const S &rhs) const;
            template <class S> const bool operator==(SafeInt<S> &rhs) const;
            template <class S> const bool operator!=(SafeInt<S> &rhs) const;

        private:
            // value will hold the int value of the object of the specific type
            T value;
            T max_value;
            T min_value;

            /* will set the new value */
            void setValue(T new_value);
            void calculateMax();
            template <class S1, class S2> const int compare(const S1& lhs, const S2& rhs) const;
    };
}

/* calculates the min and max values for the type T 
and set min_value and max_value accordingly */
template <class T> void boost::SafeInt<T>::calculateMax()
{
    int num_of_bits = 8*sizeof(T);
    if BOOST_SIGNED
    {
        max_value = (T)(pow(2,(long double)(num_of_bits-1))-1);
        min_value = (T)(-pow(2,(long double)(num_of_bits-1)));
    }
    else
    {
        max_value = (T)(pow(2,(long double)(num_of_bits))-1);
        min_value = 0;
    }
}

/** a default constructor, gives the new int the value 0 */
template <class T> boost::SafeInt<T>::SafeInt()
: value(0)
{
    calculateMax();
}

/** a constructor - gives the new SafeInt the value of the number num */
template <class T> template <class S> boost::SafeInt<T>::SafeInt(S num) throw(SafeIntException)
: value(0)
{
    calculateMax();
    operator=(num);
}

/** a constructor - gives the new SafeInt the value of the SafeInt rhs */
template <class T> template <class S> boost::SafeInt<T>::SafeInt(SafeInt<S>& rhs) throw(SafeIntException)
: value(0)
{
    calculateMax();
    operator=(rhs.getValue());
}

/** returns the T value of the SafeInt */
template <class T> T boost::SafeInt<T>::getValue() const
{
    return value;
}

/** sets the value od the SafeInt to new_value */
template <class T> void boost::SafeInt<T>::setValue(T new_value) 
{
    value = new_value;
}

/** this function is used to compare two numbers which can be of different types 
if lhs > rhs return 1
if lhs == rhs return 0
if lhs < rhs return -1 
*/
template <class T> template <class S1, class S2> const int boost::SafeInt<T>::compare(const S1& lhs, const S2& rhs) const
{
    if((S1) -1 < 0)
    {
        // S1 is a signed type
        if((S2) -1 < 0)
        {
            // S1 and S2 are signed types
            if ((signed)lhs < (signed)rhs)
            {
                return -1;
            }
            else if ((signed)lhs > (signed)rhs)
            {
                return 1;
            }
            else
            {
                return 0;
            }
        }
        else
        {
            // S2 is an unsigned type
            if ((signed)lhs < 0)
            {
                return -1;
            }
            else if ((unsigned)lhs < (unsigned)rhs)
            {
                return -1;
            }
            else if ((unsigned)lhs > (unsigned)rhs)
            {
                return 1;
            }
            else
            {
                return 0;
            }
        }
    }
    else
    {
        // S1 is an unsigned type
        if((S2) -1 < 0)
        {
            // S2 is a signed type
            if ((signed)rhs < 0)
            {
                return 1;
            }
            else if ((unsigned)lhs < (unsigned)rhs)
            {
                return -1;
            }
            else if ((unsigned)lhs > (unsigned)rhs)
            {
                return 1;
            }
            else
            {
                return 0;
            }
        }
        else
        {
            // S1 and S2 are unsigned types
            if (lhs < rhs)
                return -1;
            else if (lhs > rhs)
                return 1;
            else
                return 0;
        }
    }
}

/** the assignment operator implementation 
returns the new value of the SafeInt */
template <class T> template <class S> T& boost::SafeInt<T>::operator=(const S &rhs) throw(SafeIntException)
{
    // avoid copy to self
    if (value != rhs) {
        // check the type min and max values
        if ((compare((S)rhs,(T)max_value) == 1) || (compare((S)rhs,(T)min_value) == -1)) throw *(new SafeIntException());
        setValue((T) rhs);
    }
    return value;
}

/** the assignment operator implementation with another SafeInt 
returns the new value of the SafeInt */
template <class T> template <class S> T& boost::SafeInt<T>::operator=(const boost::SafeInt<S> &rhs) throw(SafeIntException)
{
    return operator=(rhs.getValue());
}

/** the add value operator with another SafeInt type
returns the new value after the addition */
template <class T> template <class S> T& boost::SafeInt<T>::operator+=(const SafeInt<S> &rhs) throw(SafeIntException)
{
    SafeInt<T> tmp = rhs;
    return operator+=(tmp.getValue());
}

/** the add value operator 
returns the new value after the addition */
template <class T> template <class S> T& boost::SafeInt<T>::operator+=(const S &rhs) throw(SafeIntException)
{    
    SafeInt<T> tmp = rhs;
    return operator+=(tmp.getValue());
}

/** the add value operator 
returns the new value after the addition */
template <class T> T& boost::SafeInt<T>::operator+=(const T &rhs) throw(SafeIntException)
{
    if (BOOST_SIGNED) {
        if (BOOST_SAME_SIGN(value, rhs))
        {    // lhs and rhs have the same sign, so may overflow
            if (compare(rhs, 0) == -1) { // both negative
                if (compare (value, min_value - rhs) == -1) throw *(new SafeIntException());
            }
            else if (compare (value, max_value - rhs) == 1) throw *(new SafeIntException());
        }
    }
    else { // unsigned type
        // if there's an underflow (lhs + rhs < 0)
        if ((compare(rhs, 0) == -1) && (compare(abs(rhs), value) == 1)) throw *(new SafeIntException());
        // if there's an overflow
        if (compare(value, max_value - rhs) == 1) throw *(new SafeIntException());
    }
    // set the new value
    setValue(value + (rhs));

    return value;
}

/** the subtract value operator with another SafeInt type
returns the new value after the subtraction */
template <class T> template <class S> T& boost::SafeInt<T>::operator-=(const SafeInt<S> &rhs) throw(SafeIntException)
{
    SafeInt<T> tmp = rhs;
    return operator-=(tmp.getValue());
}

/** the subtract value operator 
returns the new value after the subtraction */
template <class T> template <class S> T& boost::SafeInt<T>::operator-=(const S &rhs) throw(SafeIntException)
{    
    SafeInt<T> tmp = rhs;
    return operator-=(tmp.getValue());
}

/** the subtract value operator 
returns the new value after the subtraction */
template <class T> T& boost::SafeInt<T>::operator-=(const T &rhs) throw(SafeIntException)
{
    if (BOOST_SIGNED) {
        if (!(BOOST_SAME_SIGN(value, rhs)))
        {    // lhs and rhs have different signs, so may overflow
            if (compare(value, 0) >= 0) { // rhs negative
                if (compare (value, max_value + rhs) == 1) throw *(new SafeIntException());
            }
            else if (compare (value, min_value + rhs) == -1) throw *(new SafeIntException());
        }
    }
    else { // unsigned type
        // if there's an underflow
        if (compare(value, rhs) == -1) throw *(new SafeIntException());
    }
    // set the new value
    setValue(value - (rhs));

    return value;
}

/** the mutiply value operator with another SafeInt type
returns the new value after the multiplication */
template <class T> template <class S> T& boost::SafeInt<T>::operator*=(const SafeInt<S> &rhs) throw(SafeIntException)
{
    SafeInt<T> tmp = rhs;
    return operator*=(tmp.getValue());
}

/** the mutiply value operator 
returns the new value after the multiplication */
template <class T> template <class S> T& boost::SafeInt<T>::operator*=(const S &rhs) throw(SafeIntException)
{    
    SafeInt<T> tmp = rhs;
    return operator*=(tmp.getValue());
}

/** the mutiply value operator 
returns the new value after the multiplication */
template <class T> T& boost::SafeInt<T>::operator*=(const T &rhs) throw(SafeIntException)
{
    // we don't use here checks with the division operator, since it is computationally expensive
    if (BOOST_SIGNED) {
        // TODO: what should we do if T is long long? maybe we can declare long T
        long long res = value * rhs;
        // all 33 upper bits should be 0 or all should be 1 if there is no overflow
        long long upper33bitsOn = 0xffffffff;
        upper33bitsOn = upper33bitsOn << 32;
        upper33bitsOn += 0x80000000;
        // upperRes = 0xffffffff80000000;
        long long upperRes = upper33bitsOn ^ res;
        // (upperRes >= 0xffffffff80000000) means all upper 33 bits in res were 0 (and the result res was positive in the proper range)
        // (upperRes <= 0x0000000070000000) means all upper 33 bits in res were 1 (and the result res was negative in the proper range)
        if (!((compare(upperRes, upper33bitsOn) >= 0) || (compare(upperRes, 0x0000000070000000) <= 0)))
        {
            throw *(new SafeIntException());
        }
    }
    else 
    {    // unsigned
        int size;
        // put the result in the next power of 2 number of bits, and check if some of the upper half bits are on (overflow)
        // TODO check if less than 4 bits
        if ((compare(sizeof(value), 1) == -1) && (compare(sizeof(rhs), 1) == -1))
        {
            size = 8;
            unsigned short res = value * rhs;
            if (res > 0xf) throw *(new SafeIntException());
        }
        else if ((compare(sizeof(value), 1) <= 0) && (compare(sizeof(rhs), 1) <= 0))
        {
            size = 16;
            unsigned int res = value * rhs;
            if (compare(res, 0xff) == 1) throw *(new SafeIntException());
        }
        else if ((compare(sizeof(value), 2) <=0) && (compare(sizeof(rhs), 2) <= 0))
        {
            size = 32;
            unsigned long res = value * rhs;
            if (res > 0xffff) throw *(new SafeIntException());
        }
        else 
        {    // only if 32 bit use the division operator for the check because of its cost
            if (compare(value, 0xffffffff / rhs) == 1) throw *(new SafeIntException());
        }

    }

    value = (T) (value * rhs);
    return value;
}

/** the divide by value operator with another SafeInt type
returns the new value after the division */
template <class T> template <class S> T& boost::SafeInt<T>::operator/=(const SafeInt<S> &rhs) throw(SafeIntException)
{
    SafeInt<T> tmp = rhs;
    return operator/=(tmp.getValue());
}

/** the divide by value operator 
returns the new value after the division */
template <class T> template <class S> T& boost::SafeInt<T>::operator/=(const S &rhs) throw(SafeIntException)
{    
    SafeInt<T> tmp = rhs;
    return operator/=(tmp.getValue());
}

/** the divide by value operator 
returns the new value after the division */
template <class T> T& boost::SafeInt<T>::operator/=(const T &rhs) throw(SafeIntException)
{
    if (rhs == 0) throw *(new SafeIntException());
    if (BOOST_SIGNED) {
        if ((value == min_value) && (rhs == -1)) throw *(new SafeIntException());
    }
    value = (value) / (rhs);
    // TODO: should check cases of casting from signed to unsigned (for signed numerator and unsigned denominator)
    return value;
}

/** the modulo by value operator with another SafeInt type
returns the new value after the modulo */
template <class T> template <class S> T& boost::SafeInt<T>::operator%=(const SafeInt<S> &rhs) throw(SafeIntException)
{
    SafeInt<T> tmp = rhs;
    return operator%=(tmp.getValue());
}

/** the modulo by value operator
returns the new value after the modulo */
template <class T> template <class S> T& boost::SafeInt<T>::operator%=(const S &rhs) throw(SafeIntException)
{    
    SafeInt<T> tmp = rhs;
    return operator%=(tmp.getValue());
}

/** the modulo by value operator 
returns the new value after the modulo */
template <class T> T& boost::SafeInt<T>::operator%=(const T &rhs) throw(SafeIntException)
{
    // may throw division by zero exception if rhs = 0
    value = (value) % (rhs);
    
    return value;
}

/** the xor by value operator with another SafeInt type
returns the new value after the xor */
template <class T> template <class S> T& boost::SafeInt<T>::operator^=(const SafeInt<S> &rhs) throw(SafeIntException)
{
    SafeInt<T> tmp = rhs;
    return operator^=(tmp.getValue());
}

/** the xor by value operator 
returns the new value after the xor */
template <class T> template <class S> T& boost::SafeInt<T>::operator^=(const S &rhs) throw(SafeIntException)
{    
    SafeInt<T> tmp = rhs;
    return operator^=(tmp.getValue());
}

/** the xor by value operator 
returns the new value after the xor */
template <class T> T& boost::SafeInt<T>::operator^=(const T &rhs) throw(SafeIntException)
{
    setValue((T) (value^rhs));
    return value;
}

/** the unary +, just returns the value */
template <class T> const T& boost::SafeInt<T>::operator+() const throw(SafeIntException)
{
    return value;
}

/** the unary negation, returns the negation of the number */
template <class T> const T& boost::SafeInt<T>::operator-() const throw(SafeIntException)
{
    if (BOOST_SIGNED) {
        if (value == min_value) throw *(new SafeIntException());
        return -value;
    }
    // trying to negate an unsigned number
    else throw *(new SafeIntException());
}

/** the increment operator ++a
first sets the value to be value+1 and returns the new value */
template <class T> T& boost::SafeInt<T>::operator++() throw(SafeIntException)
{
    if (value == max_value) throw *(new SafeIntException());
    setValue(value + 1);
    return value;
}

/** the increment operator a++
sets the value to be value+1 and returns the old value */
template <class T> T& boost::SafeInt<T>::operator++(int notused) throw(SafeIntException)
{
    if (value == max_value) throw *(new SafeIntException());
    T result = value;
    setValue(value + 1);
    return result;
}

/** the decrement operator --a
first sets the value to be value-1 and returns the new value */
template <class T> T& boost::SafeInt<T>::operator--() throw(SafeIntException)
{
    if (value == min_value) throw *(new SafeIntException());
    setValue(value - 1);
    return value;
}

/** the increment operator a--
sets the value to be value-1 and returns the old value */
template <class T> T& boost::SafeInt<T>::operator--(int notused) throw(SafeIntException)
{
    if (value == min_value) throw *(new SafeIntException());
    T result = value;
    setValue(value - 1);
    return result;
}

/** the addition operator with another SafeInt type. 
returns the addition of the value+rhs */
template <class T> template <class S> const T boost::SafeInt<T>::operator+(const SafeInt<S> &rhs) const throw(SafeIntException)
{
    SafeInt<T> tmp = rhs;
    return operator+(tmp.getValue());
}

/** the addition operator. 
returns the addition of the value+rhs */
template <class T> template <class S> const T boost::SafeInt<T>::operator+(const S &rhs) const throw(SafeIntException)
{    
    SafeInt<T> tmp = rhs;
    return operator+(tmp.getValue());
}

/** the addition operator. 
returns the addition of the value+rhs */
template <class T> const T boost::SafeInt<T>::operator+(const T &rhs) const throw(SafeIntException)
{
    SafeInt<T> result = value;
    result += rhs;
    return result.getValue();
}

/** the subtraction operator with another SafeInt type. 
returns the result of the value-rhs */
template <class T> template <class S> const T boost::SafeInt<T>::operator-(const SafeInt<S> &rhs) const throw(SafeIntException)
{
    SafeInt<T> tmp = rhs;
    return operator-(tmp.getValue());
}

/** the subtraction operator. returns the result of the value-rhs */
template <class T> template <class S> const T boost::SafeInt<T>::operator-(const S &rhs) const throw(SafeIntException)
{    
    SafeInt<T> tmp = rhs;
    return operator-(tmp.getValue());
}

/** the subtraction operator. returns the result of the value-rhs */
template <class T> const T boost::SafeInt<T>::operator-(const T &rhs) const throw(SafeIntException)
{
    SafeInt<T> result = value;
    result -= rhs;
    return result.getValue();
}

/** the multiplication operator with another SafeInt type. 
returns the result of value*rhs */
template <class T> template <class S> const T boost::SafeInt<T>::operator*(const SafeInt<S> &rhs) const throw(SafeIntException)
{
    SafeInt<T> tmp = rhs;
    return operator*(tmp.getValue());
}

/** the multiplication operator 
returns the result of value*rhs */
template <class T> template <class S> const T boost::SafeInt<T>::operator*(const S &rhs) const throw(SafeIntException)
{    
    SafeInt<T> tmp = rhs;
    return operator*(tmp.getValue());
}

/** the multiplication operator
returns the result of value*rhs */
template <class T> const T boost::SafeInt<T>::operator*(const T &rhs) const throw(SafeIntException)
{
    SafeInt<T> result = value;
    result *= rhs;
    return result.getValue();
}

/** the division operator with another SafeInt type. 
returns the result of value/rhs */
template <class T> template <class S> const T boost::SafeInt<T>::operator/(const SafeInt<S> &rhs) const throw(SafeIntException)
{
    SafeInt<T> tmp = rhs;
    return operator/(tmp.getValue());
}

/** the division operator. 
returns the result of value/rhs */
template <class T> template <class S> const T boost::SafeInt<T>::operator/(const S &rhs) const throw(SafeIntException)
{    
    SafeInt<T> tmp = rhs;
    return operator/(tmp.getValue());
}

/** the division operator. 
returns the result of value/rhs */
template <class T> const T boost::SafeInt<T>::operator/(const T &rhs) const throw(SafeIntException)
{
    SafeInt<T> result = value;
    result /= rhs;
    return result.getValue();
}

/** the modulus operator with another SafeInt type. 
returns the result of value%rhs */
template <class T> template <class S> const T boost::SafeInt<T>::operator%(const SafeInt<S> &rhs) const throw(SafeIntException)
{
    SafeInt<T> tmp = rhs;
    return operator%(tmp.getValue());
}

/** the modulus operator. 
returns the result of value%rhs */
template <class T> template <class S> const T boost::SafeInt<T>::operator%(const S &rhs) const throw(SafeIntException)
{    
    SafeInt<T> tmp = rhs;
    return operator%(tmp.getValue());
}

/** the modulus operator. 
returns the result of value%rhs */
template <class T> const T boost::SafeInt<T>::operator%(const T &rhs) const throw(SafeIntException)
{
    SafeInt<T> result = value;
    result %= rhs;
    return result.getValue();
}

/** the xor operator with another SafeInt type. 
returns the result of value^rhs */
template <class T> template <class S> const T boost::SafeInt<T>::operator^(const SafeInt<S> &rhs) const throw(SafeIntException)
{
    SafeInt<T> tmp = rhs;
    return operator^(tmp.getValue());
}

/** the xor operator. 
returns the result of value^rhs */
template <class T> template <class S> const T boost::SafeInt<T>::operator^(const S &rhs) const throw(SafeIntException)
{    
    SafeInt<T> tmp = rhs;
    return operator^(tmp.getValue());
}

/** the xor operator. 
returns the result of value^rhs */
template <class T> const T boost::SafeInt<T>::operator^(const T &rhs) const throw(SafeIntException)
{
    SafeInt<T> result = value;
    result ^= rhs;
    return result.getValue();
}

/** the comparison operator. 
returns the result of value==rhs */
template <class T> template <class S> const bool boost::SafeInt<T>::operator==(const S &rhs) const
{
    return (compare(value,rhs) == 0);
}

/** the "not equal" (!=) operator. 
returns the result of value!=rhs */
template <class T> template <class S> const bool boost::SafeInt<T>::operator!=(const S &rhs) const
{
    return (compare(value,rhs) != 0);
}

/** the comparison operator with another SafeInt type. 
returns the result of value==rhs */
template <class T> template <class S> const bool boost::SafeInt<T>::operator==(SafeInt<S> &rhs) const
{
   return (compare(value,rhs.getValue()) == 0);
}

/** the "not equal" (!=) operator with another SafeInt type. 
returns the result of value!=rhs */
template <class T> template <class S> const bool boost::SafeInt<T>::operator!=(SafeInt<S> &rhs) const
{
    return (compare(value,rhs.getValue()) != 0);
}

#endif
