/*============================================================================.
 | Copyright (C) 2006 Gareth Buxton                                           |
 |----------------------------------------------------------------------------|
 | LogPlusPlus is free software; you can redistribute it and/or               |
 | modify it under the terms of the GNU Lesser General Public                 |
 | License as published by the Free Software Foundation; either               |
 | version 2.1 of the License, or (at your option) any later version.         |
 |                                                                            |
 | LogPlusPlus is distributed in the hope that it will be useful,             |
 | but WITHOUT ANY WARRANTY; without even the implied warranty of             |
 | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU          |
 | Lesser General Public License for more details.                            |
 |                                                                            |
 | You should have received a copy of the GNU Lesser General Public           |
 | License along with this library; if not, write to the Free Software        |
 | Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA |
 '============================================================================*/
#ifndef BOOST_LOGGER_LOG_OUTPUT_HPP
#define BOOST_LOGGER_LOG_OUTPUT_HPP

#include <boost/logger/log_types.hpp>
#include <boost/logger/log_mask.hpp>
#include <boost/logger/log_form.hpp>
#include <boost/logger/log_writer.hpp>

#include <set>
#include <string>
#include <sstream>

//=============================================================================
LPP_NAMESPACE_BEGIN
//=============================================================================

typedef std::set<std::ostream*> log_ostream_set;

/**
 * A log_output is the final recipient of all Log messages
 * and makes the decision as to whether or not the message
 * will be sent to one of the configured ostreams.
 **/
class log_output
{
private:

	//static Log& log;

	std::string name;
	log_mask mask;
	log_ostream_set ostream_set;
	const log_form* default_form;
	const log_form* form;

public:

	/**
	 * Construct a new log_output.
	 **/
	log_output(const std::string& name, const log_mask& log_mask);
	virtual ~log_output();
	
	/**
	 * Get the name of this log_output.
	 * @return The name of this log_output.
	 **/
	inline const std::string& get_name() { return name;	}
	
	/*------------------------------------------------------------------------.
	 | std::ostream Management                                                |
	 '------------------------------------------------------------------------*/

	/**
	 * Attach a std::ostream to this log_output.
	 * If the std::ostream already exists
	 * an error message will be
	 * generated on the internal log.
	 * @param os The std::ostream to add to this log_output.
	 **/
	void attach_ostream(std::ostream& os);
	
	/**
	 * Remove a std::ostream from this log_output.
	 * If the std::ostream is not present 
	 * an error message will be
	 * generated on the internal log.
	 * @param os The std::ostream to remove from this log_output.
	 **/
	void remove_ostream(std::ostream& os);
	
	/**
	 * Set the log_mask for this log_output.
	 * @param log_mask The log_mask to set.
	 * @param mod_type The mod_type with which to apply
	 * the log_mask.
	 **/
	void set_log_mask(const log_mask& log_mask, const mod_type& type = REPLACE);

	/**
	 * Get the log_mask for this log_output.
	 * @return The log_mask for this log_output.
	 **/
	inline
	log_mask get_log_mask()
	{
		return mask;
	}

	/**
	 * Write an entry to each std::ostream attached
	 * to this log_output.
	 * @param message The log_message to write.
	 **/
	void write(const log_message& message) const;

	/**
	 * Change the internal log_form formatting object.
	 * @param format The new log_form object to use.
	 **/
	void set_log_form(const log_form* const log_form);
};

//=============================================================================
LPP_NAMESPACE_END
//=============================================================================

#endif /*BOOST_LOGGER_LOG_OUTPUT_HPP*/
