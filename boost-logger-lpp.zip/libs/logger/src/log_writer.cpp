/*============================================================================.
 | Copyright (C) 2006 Gareth Buxton                                           |
 |----------------------------------------------------------------------------|
 | LogPlusPlus is free software; you can redistribute it and/or               |
 | modify it under the terms of the GNU Lesser General Public                 |
 | License as published by the Free Software Foundation; either               |
 | version 2.1 of the License, or (at your option) any later version.         |
 |                                                                            |
 | LogPlusPlus is distributed in the hope that it will be useful,             |
 | but WITHOUT ANY WARRANTY; without even the implied warranty of             |
 | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU          |
 | Lesser General Public License for more details.                            |
 |                                                                            |
 | You should have received a copy of the GNU Lesser General Public           |
 | License along with this library; if not, write to the Free Software        |
 | Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA |
 '============================================================================*/

#include <boost/logger/log.hpp>
#include <boost/logger/log_writer.hpp>
#include "log_output.hpp"

//=============================================================================
LPP_NAMESPACE_BEGIN
//=============================================================================

//Log& log_writer::log = Log::getLog();

log_writer::log_writer()
: isDone(false)
{
}


log_writer::~log_writer()
{
	log_output_map::iterator i;

	for(i = output_map.begin(); i != output_map.end(); i++)
	{
		delete (*i).second;
	}
}

void log_writer::flush()
{
}	

void log_writer::add_output(const std::string& name, const log_mask& mask,
	std::ostream& os)
{
	log_output* output = output_map[name];

	if(!output)
	{
		output = new log_output(name, mask);
		output->set_log_form(logger::configured_log_form());
		output->attach_ostream(os);
		output_map[name] = output;
	}
	else
	{
		//log.error << "output " << name << " already exists.";
		//log.error << std::endl;
	}
}

void log_writer::set_log_mask(const std::string& name, const log_mask& mask,
	mod_type mod_type)
{
	log_output* output = output_map[name];

	if(output)
	{
		output->set_log_mask(mask, mod_type);
	}
	else
	{
		//log.error << "Attempt to modify non-existent output " << name;
		//log.error << std::endl;
	}
}

log_mask log_writer::get_log_mask(const std::string& name)
{
	log_output* output = output_map[name];

	if(output)
	{
		return output->get_log_mask();
	}

	//log.error << "Attempt to modify non-existent output " << name;
	//log.error << std::endl;

	return log_mask(0UL);
}

void log_writer::set_log_form(const std::string& name, const log_form* const format)
{
	log_output* output = output_map[name];

	if(output)
	{
		output->set_log_form(format);
	}
	else
	{
//		log.error << "Attempt to re-format a non-existent output " << name;
//		log.error << std::endl;
	}
}

void log_writer::del_output(const std::string& name)
{
	log_output* output = output_map[name];

	if(output)
	{
		output_map.erase(name);
	}
	else
	{
		//log.error << "Attempt to delete non-existent output " << name;
		//log.error << std::endl;
	}
}

void log_writer::attach_ostream(const std::string& name, std::ostream& os)
{
	log_output* output = output_map[name];

	if(output)
	{
		output->attach_ostream(os);
	}
	else
	{
		//log.error << "Attempt to attach an ostream to non-existent output ";
		//log.error << name << std::endl;
	}
}

void log_writer::remove_ostream(const std::string& name, std::ostream& os)
{
	log_output* output = output_map[name];

	if(output)
	{
		output->remove_ostream(os);
	}
	else
	{
		//log.error << "Attempt to remove an ostream from non-existent output ";
		//log.error << name << std::endl;
	}
}

void log_writer::write(log_message& message)
{
	log_output_map::const_iterator i;

	for(i = output_map.begin(); i != output_map.end(); i++)
	{
		(*i).second->write(message);
	}
}

//=============================================================================
LPP_NAMESPACE_END
//=============================================================================

