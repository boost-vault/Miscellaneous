/*============================================================================.
 | Copyright (C) 2006 Gareth Buxton                                           |
 |----------------------------------------------------------------------------|
 | LogPlusPlus is free software; you can redistribute it and/or               |
 | modify it under the terms of the GNU Lesser General Public                 |
 | License as published by the Free Software Foundation; either               |
 | version 2.1 of the License, or (at your option) any later version.         |
 |                                                                            |
 | LogPlusPlus is distributed in the hope that it will be useful,             |
 | but WITHOUT ANY WARRANTY; without even the implied warranty of             |
 | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU          |
 | Lesser General Public License for more details.                            |
 |                                                                            |
 | You should have received a copy of the GNU Lesser General Public           |
 | License along with this library; if not, write to the Free Software        |
 | Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA |
 '============================================================================*/

#include <boost/logger/log_writer.hpp>
#include <boost/logger/log_stream.hpp>

//=============================================================================
LPP_NAMESPACE_BEGIN
//=============================================================================

log_stream::log_stream(const std::string& name, const std::string& logName,
		log_writer& writer, const log_level& level)
: std::ostream()
, name(name)
, logName(logName)
, writer(writer)
, level(level)
, flag(1UL << static_cast<unsigned int>(level))
, isEnabled(false)
{
	std::ostream::init(this);
	on();
}

log_stream::~log_stream()
{
}

int log_stream::sync()
{
	write(std::stringbuf::str());
	std::stringbuf::str("");
	return 0;
}

void log_stream::set_log_level(const log_level& level)
{
	this->level = level;

	// Only re-cache the log_flag value if we are enabled
	// If not the user must specifically call on() to
	// re-cache this value and thereby re-enable the
	// log_stream.
	if(isEnabled)
	{
		this->flag = (1UL << static_cast<unsigned int>(level));
	}
}

const log_level log_stream::get_log_level()
{
	return this->level;
}

void log_stream::write(const std::string& info) const
{
	//log_writer.writeToOutputs(name, log_flag, info);
	log_message message(time(0), flag, logName, name, info);
	writer.write(message);
}

//=============================================================================
LPP_NAMESPACE_END
//=============================================================================
