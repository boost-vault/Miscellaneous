#include <boost/logger/log.hpp>

#include <iostream>
#include <fstream>

using namespace std;
using namespace boost::logger;

int main()
{
	/*
	 * The basic principle behing logplusplus logger is to provide only
	 * the most basic services at the base and to allow greater functionality
	 * to be added by building on this base in a natural manner.
	 * 
	 * At its most basic a logger is a std::ostream, so one can begin using
	 * it very quickly without having to wande through a whole bunch of
	 * technical instructions:
	 */
	logger& log = logger::get_logger(BASIC_LOGGER);

	log << "here is some logging text" << endl;
	
	/*
	 * The logger is a std::ostream so the learning curve is negligable and
	 * the default output will of course go to std::clog.
	 * 
	 * Further to this the user might want to send the log messages to
	 * more than one place. They might want to also write the messages
	 * to a file for instance:
	 */
	
	ofstream ofs("file.log");
	log.attach_ostream(ofs);
	
	log << "Now goes to std::clog and file.log" << endl;
	
	/*
	 * Indeed as many streams as desired may be added to a logger. 
	 * It might be though that you no longer wish the log messages to
	 * go to std::log any more and ony send them to the file:
	 */
	
	log.remove_ostream(std::clog);
	
	log << "This comment will only go to the file" << endl;
	
	/*
	 * Of course if the user had never wanted the output to
	 * go to std::clog in the first instance they would have
	 * simply specified that when they retrieved the logger
	 * object like this:
	 */
	
	logger& file_log = logger::get_logger(BASIC_LOGGER, ofs);
	
	file_log << "Writing to this log will only go to the file" << endl;
	
	
	/*
	 * Now lets re-attach std::clog to our main logger:
	 */
	
	log.attach_ostream(std::clog);

	/*
	 * A common desire is to be able to send messages to a logger by
	 * specifying a specific 'level for the message such that the output
	 * might specify the 'level' through which the message was sent and 
	 * also so that messages sent at (and|or above) specified 'levels'
	 * can be turned on or off at runtime.
	 * 
	 * Rather that impose specific 'levels' on the user, logplusplus
	 * allows them to specify their own at runtime thus:
	 */
	
	log.add_log_stream("debug", 0);
	
	log.to("debug") << "This message will be sent at level '0' (debug)" << endl;
	
	/*
	 * More streams can be added at will:
	 */
	
	log.add_log_stream("info", 1);
	log.add_log_stream("warn", 2);
	log.add_log_stream("error", 3);
	log.add_log_stream("fatal", 4);
	
	log.to("info") << "Some general info" << endl;
	log.to("warn") << "A warning about something" << endl;
	log.to("error") << "An error beware!!" << endl;
	log.to("fatal") << "Absolute meltdown :0" << endl;
	
	/*
	 * Having created several, named streams for this logger it then becomes 
	 * trivial to set the required amount of 'noise' that this logger will
	 * produce at runtime. For instance of you wanted to display messages
	 * that were sent at the level of 'warn' or above you might do this: 
	 */ 
	
	log.set_log_mask_level(log.to("warn").get_log_level());

	/*
	 * This works because log.to("warn") is a boost::logger::log_stream object
	 * as well as a std::ostream object and so can be configured and return its
	 * internal configuration.
	 * 
	 * Setting the log's mask_level has the effect of turning off (masking) all
	 * streams below the specified level (in this case "warn"):
	 */
	
	log.to("debug") << "Debugging will not appear." << endl;
	log.to("info") << "Also 'info' messages will not appear" << endl;
	log.to("warn") << "Warnings and above will be displayed" << endl;
	log.to("error") << "This includes errors" << endl;
	log.to("fatal") << "And fatalities!" << endl;
	
	/*
	 * Now some, especially difficult programmers might want to do something
	 * even more clever than this. They might want to display "debug", "error"
	 * and "fatal" messages but not "info" or warnings:
	 */
	
	log.set_log_mask(log_mask("11001"));
	
	log.to("debug") << "Now we have debugging." << endl;
	log.to("info") << "But not info" << endl;
	log.to("warn") << "Nor warnings" << endl;
	log.to("error") << "But we still have errors" << endl;
	log.to("fatal") << "And fatalities!" << endl;
	
	/*
	 * This betrays the fact that logging 'levels' are actually
	 * implemented using a bit mask to allow for random stream selection
	 * at runtime. This is why the methods to set the log_level are called
	 * logger::set_log_mask_level. This actually means 'set the log_mask
	 * such that all streams from this level and below are turned
	 * off'.
	 *
	 * So to return things back to normal one might do:
	 */

	log.set_log_mask_level(log.get_log_level());
	
	/*
	 * This works because it actually means 'set the log_mask
	 * such that all streams from this level and below are turned
	 * off'. Or set the log mask level to the level of the whole log
	 * (which is '0' by default), and hence this turns all streams
	 * on.
	 */
	
	/*
	 * Another aspect of logging that the user might want to change is the 
	 * format of the log messages. This can be achieved by supplying a
	 * formatting object (a functor) called a log_form:
	 */
	
	log.set_log_form(LOG_FORM_STANDARD);
	
	log << "Now the output of the logging information has changed" << endl;
	log << "no longer do we have the time printed in unix raw format" << endl;
	log << "we have it in a more human readable form." << endl;
	
	/*
	 * LOG_FORM_STANDARD is basically a pre-defined functor as an example
	 * but in reality it might be useful to have a number of commonly used
	 * log_form objects defined in the library. For instance there are some
	 * well known 'standard' logging formats that people might want to use 
	 * 'off the shelf'.
	 */
	
	/*
	 * This basic tutorial has presented just the basics of how logplusplus
	 * operates. At its core it is very simple but with the ability to keep
	 * aggregating streams, masks and levels it can build (like lego) into
	 * a highly configurable, versatile and powerful logging system.
	 * 
	 * For example it is also possible to have several log_outputs, each with
	 * their own log_masks and so each one receiving only those messages it
	 * is configured for. 
	 * 
	 * Also because a logger is basically a std::ostream you can attach
	 * one logger to another! So you can set up several different loggers
	 * each with their own configurations and attach them to a master logger.
	 * 
	 * This master logger can then have its mask (and|or level) configured to
	 * only write to some of the attached logs!
	 * 
	 * NOTE: This example is not currently working :'( but I left it in to
	 *       give an idea of how complex you can get of you wanted to...
	 */
	
	logger& master_log = logger::get_logger(BASIC_LOGGER, "mastah");
	
	ofstream file_1("file-1.log");
	ofstream file_2("file-2.log");
	ofstream file_3("file-3.log");
	
	logger& log_1 = logger::get_logger(BASIC_LOGGER, "log-1", file_1);
	logger& log_2 = logger::get_logger(BASIC_LOGGER, "log-2", file_2);
	logger& log_3 = logger::get_logger(BASIC_LOGGER, "log-3", file_3);
	
	master_log.add_output("output-1", log_mask("01"), log_1);
	master_log.add_output("output-2", log_mask("10"), log_2);
	master_log.add_output("output-3", log_mask("11"), log_3);

	master_log.add_log_stream("info", 0);
	master_log.add_log_stream("warn", 1);
	
	master_log.to("info") << "Here is some info for the mastah!" << endl;
	master_log.to("warn") << "Here is a warning for the mastah!" << endl;
	
	/*
	 * As well as being simple, yet highy configurable to the limit of
	 * the desired complexity (?!?) from a runtime perspective, logplusplus
	 * is also highy configurable from a developer perspective. By this I mean
	 * the logging system is built to be extensible. All the example so far
	 * have user the 'basic_logger' defined in the library. As an example
	 * the library also includes a 'standard_logger'.
	 * 
	 * This 'standard_logger' is essentially an assembly of logger and some
	 * log_stream classes to put together a 'hard coded' logger that behaves
	 * the way many typical loggers behave. Actually all it does if formalise
	 * the notion of the levels 'debug', 'info', 'warn' etc..
	 * 
	 * The 'standard_logger' can be accessed using the STANDARD_LOGGER
	 * log_type<> factory passed to a call to logger::get_logger() thus:
	 */
	
	standard_logger& slog = logger::get_logger(STANDARD_LOGGER);
	
	/*
	 * Actually the only difference between the standard_logger and the basic_logger
	 * is that the standard_logger has defined a set of public log_stream objects
	 * that operate at pre-defined (though still configurable) log_levels.
	 * 
	 * This means one can convenienty do your logging thus:
	 */ 
	
	slog.debug << "Here is some debug." << endl;
	slog.info << "Here is some info." << endl;
	slog.warn << "Here is some warn." << endl;
	slog.error << "Here is some error." << endl;
	slog.fatal << "Here is some fatal." << endl;
	
	/*
	 * Creating your own logger is trivial:
	 */
	void go_to_my_logger_example_below();

	go_to_my_logger_example_below();
}

/*
 * First we derive our logger from basic_logger
 */ 
class my_logger : public basic_logger
{
	/*
	 * then we make friends with the logger
	 * type factory
	 */
	friend class log_type<my_logger>;
	
public:
	
	/*
	 * here we declare our personal log levels
	 */
	log_stream bug;
	log_stream inf;
	log_stream err;

protected:
	
	/*
	 * This will need to be simplified, its still too
	 * complex...
	 */
	my_logger(const std::string& name, std::ostream& os)
	: basic_logger(name, os)
	, bug("bug", name, writer, 1) // defined for level 1
	, inf("inf", name, writer, 2) // defined for level 2
	, err("err", name, writer, 3) // defined for level 3
	{
		
	}
	
	~my_logger(){}
};

void go_to_my_logger_example_below()
{
	/*
	 * Then to instantiate our logger we invoke the log_type
	 * template logger factory supplying our new class as the
	 * parameter.
	 */ 
	my_logger& mlog = logger::get_logger(log_type<my_logger>());
	
	/*
	 * Then use the log just like the built in ones :)
	 */ 
	mlog.bug << "now writing to my 'bug'" << endl;
	mlog.inf << "now writing to my 'inf'" << endl;
	mlog.err << "now writing to my 'err'" << endl;
	
	/*
	 * Additionally formatting can be achieved my creating
	 * your own log_form classes:
	 */
	
	class my_log_form
	: public log_form
	{
	public:
		my_log_form(){}
		~my_log_form(){}
		std::string operator()(const log_message& message) const
		{
			std::ostringstream oss;
			tm local = *(localtime(&message.time)); // dereference and assign
			oss << std::setfill('0');
			oss << (1900 + local.tm_year);
			oss << "/" << std::setw(2) << local.tm_mon;
			oss << "/" << std::setw(2) << local.tm_wday;
			oss << " " << std::setw(2) << local.tm_hour;
			oss << ":" << std::setw(2) << local.tm_min;
			oss << ":" << std::setw(2) << local.tm_sec;
			oss << std::setfill(' ');
			oss << " " + message.log_name;
			oss << " ";
			oss << "{" + message.log_stream_name;
			oss << "}";
			oss << " " << message.text;
			return  oss.str();
		}
	};

	const my_log_form form;
	mlog.set_log_form(&form);
	
	mlog << "Now writes in a new way..." << endl;
}

