/*============================================================================.
 | Copyright (C) 2006 Gareth Buxton                                           |
 |----------------------------------------------------------------------------|
 | LogPlusPlus is free software; you can redistribute it and/or               |
 | modify it under the terms of the GNU Lesser General Public                 |
 | License as published by the Free Software Foundation; either               |
 | version 2.1 of the License, or (at your option) any later version.         |
 |                                                                            |
 | LogPlusPlus is distributed in the hope that it will be useful,             |
 | but WITHOUT ANY WARRANTY; without even the implied warranty of             |
 | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU          |
 | Lesser General Public License for more details.                            |
 |                                                                            |
 | You should have received a copy of the GNU Lesser General Public           |
 | License along with this library; if not, write to the Free Software        |
 | Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA |
 '============================================================================*/

#include "log_output.hpp"

#include <boost/logger/log.hpp>

//=============================================================================
LPP_NAMESPACE_BEGIN
//=============================================================================

//Log& log_output::log = Log::getLog();

log_output::log_output(const std::string& name, const log_mask& mask)
: name(name)
, mask(mask)
, default_form(new log_form)
, form(0)
{
}

log_output::~log_output()
{
	delete default_form;
}

void log_output::attach_ostream(std::ostream& os)
{
	log_ostream_set::iterator found = ostream_set.find(&os);
	
	if(found == ostream_set.end())
	{
		ostream_set.insert(&os);
	}
	else
	{
		//log.error << "ostream already assigned to output ";
		//log.error << name << std::endl; 
	}
}

void log_output::remove_ostream(std::ostream& os)
{
	log_ostream_set::iterator found = ostream_set.find(&os);
	
	if(found != ostream_set.end())
	{
		ostream_set.erase(found);
	}
	else
	{
		//log.error << "attempt to delete ostream not assigned to output ";
		//log.error << name << std::endl; 
	}
}

void log_output::set_log_mask(const log_mask& mask, const mod_type& type)
{
	this->mask.apply(mask, type);
}

void log_output::write(const log_message& message) const
{
	if(!mask(message.flag))
	{
		std::string entry;
		
		if(form)
		{
			entry = (*form)(message);	
		}
		else
		{
			entry = (*default_form)(message);
		}
		
		log_ostream_set::iterator os;
		for(os = ostream_set.begin(); os != ostream_set.end(); os++)
		{
			(**os) << entry;			
		}
	}
}

void log_output::set_log_form(const log_form* const form)
{
	this->form = form;
}

//=============================================================================
LPP_NAMESPACE_END
//=============================================================================
