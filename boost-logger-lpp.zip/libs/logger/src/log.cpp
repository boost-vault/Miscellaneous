/*============================================================================.
 | Copyright (C) 2006 Gareth Buxton                                           |
 |----------------------------------------------------------------------------|
 | LogPlusPlus is free software; you can redistribute it and/or               |
 | modify it under the terms of the GNU Lesser General Public                 |
 | License as published by the Free Software Foundation; either               |
 | version 2.1 of the License, or (at your option) any later version.         |
 |                                                                            |
 | LogPlusPlus is distributed in the hope that it will be useful,             |
 | but WITHOUT ANY WARRANTY; without even the implied warranty of             |
 | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU          |
 | Lesser General Public License for more details.                            |
 |                                                                            |
 | You should have received a copy of the GNU Lesser General Public           |
 | License along with this library; if not, write to the Free Software        |
 | Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA |
 '============================================================================*/

#include <boost/logger/log.hpp>

#include <iostream>
#include <string>
#include <ctime>
#include <map>
#include <algorithm>
#include <vector>
#include <iomanip>

//=============================================================================
LPP_NAMESPACE_BEGIN
//=============================================================================

log_exception::log_exception(const std::string& message)
throw()
: message(message)
{
	
}

log_exception::~log_exception()
throw()
{
	
}

const char* log_exception::what() const throw()
{
	return message.c_str();
}

/*============================================================================.
 | logger        .                                                            |
 '============================================================================*/

/*----------------------------------------------------------------------------.
 : Constructors / Destructors                                                 :
 '----------------------------------------------------------------------------*/

logger::logger(const std::string& name, log_writer& writer, const log_level& level)
: log_stream(NATURAL_INFO_STREAM_NAME, name, writer, level)
{
//	set_log_form(configured_log_form());
}

logger::~logger(){}

/*----------------------------------------------------------------------------.
 : Static methods                                                             :
 '----------------------------------------------------------------------------*/

const log_form* logger::configured_log_form(const log_form* form)
{
	static const log_form* configured_log_form = 0;
	
	if(form)
	{
		configured_log_form = form;
	}
	
	return configured_log_form;
}

//template<typename L> L& logger::get_logger(const log_type<L>& type, std::ostream& os)
//{
//	return logger::get_logger(type, DEFAULT_LOG_NAME, os);
//}
//
//template<typename L> L& logger::get_logger(const log_type<L>& type, const char* name, std::ostream& os)
//{
//	return get_logger(type, std::string(name), os);
//}
//
//template<typename L> L& logger::get_logger(const log_type<L>& type, const std::string& name, std::ostream& os)
//{
//	return type(name, os);
//}

//void logger::closedown(const log_type<L>& type)
//{
//	type.closedown();
//}

/*============================================================================.
 | basic_logger  .                                                            |
 '============================================================================*/

/*----------------------------------------------------------------------------.
 : Constructors / Destructors                                                 :
 '----------------------------------------------------------------------------*/

basic_logger::basic_logger(const std::string& name, std::ostream& os)
: logger(name, writer, default_log_level())
, name(name)
, writer()
{
	writer.add_output(NATURAL_LOG_OUTPUT_NAME, default_log_mask(), os);
}

basic_logger::~basic_logger()
{
	for(log_stream_map_iterator i = stream_map.begin();
		i != stream_map.end(); ++i)
	{
		delete (*i).second;
	}
}

const std::string& basic_logger::get_name() const { return name; }

/*------------------------------------------------------------------------.
 : Static methods                                                         :
 '------------------------------------------------------------------------*/

const log_level& basic_logger::check_log_level(const log_level& level)
{
    static const log_level log_level_max(sizeof(log_mask) * 8);
    return level <= log_level_max ? level : log_level_max;
}

const log_level& basic_logger::default_log_level(const log_level* level)
{
    static log_level default_log_level(DEFAULT_LEVEL_NONE);

    if(level) // Change value
    {
        default_log_level = check_log_level(*level);
    }

    return default_log_level;
}

const log_mask& basic_logger::default_log_mask(const log_mask* mask)
{
    static log_mask default_log_mask = log_mask::levelToMask(DEFAULT_LEVEL_DEBUG);

    if(mask) // Change value
    {
        default_log_mask = *mask;
    }

    return default_log_mask;
}

/*----------------------------------------------------------------------------.
 : log_output management                                                      :
 '----------------------------------------------------------------------------*/

void basic_logger::add_output(const std::string& name, const log_mask& mask,
	std::ostream& os)
{
	writer.add_output(name, mask, os);
}

void basic_logger::set_log_mask(const log_mask& mask, mod_type type)
{
	set_log_mask(NATURAL_LOG_OUTPUT_NAME, mask, type);
}

void basic_logger::set_log_mask_level(const log_level& level,
	mod_type type)
{
	set_log_mask_level(NATURAL_LOG_OUTPUT_NAME, level, type);
}

log_mask basic_logger::get_log_mask()
{
	return get_log_mask(NATURAL_LOG_OUTPUT_NAME);
}

void basic_logger::set_log_mask(const std::string& name, const log_mask& mask,
	mod_type type)
{
	writer.set_log_mask(name, mask, type);
}

void basic_logger::set_log_mask_level(const std::string& name, const log_level& level,
	mod_type type)
{
	set_log_mask(name, log_mask::levelToMask(level), type);
}

log_mask basic_logger::get_log_mask(const std::string& name)
{
	return writer.get_log_mask(name);
}

void basic_logger::del_output(const std::string& name)
{
	writer.del_output(name);
}

/*----------------------------------------------------------------------------.
 : log_stream management                                                      :
 '----------------------------------------------------------------------------*/

void basic_logger::add_log_stream(const std::string& name, const log_level& level)
{
    log_stream* stream = stream_map[name];

    if(!stream)
    {
    	stream_map[name] = new log_stream(name, this->name, writer,
                                             check_log_level(level));
    }
    else
    {
        mod_log_stream(name, level);
        //info << "log_stream already exists. Modifying instead: ";
        //info << name << " " << level << std::endl;
    }
}

void basic_logger::mod_log_stream(const std::string& name, const log_level& level)
{
    log_stream* log_stream = stream_map[name];

    if(log_stream)
    {
        log_stream->set_log_level(level);
    }
    else
    {
        add_log_stream(name, level);
        //info << "Automatically added log_stream " << name << " " << level << std::endl;
    }
}

void basic_logger::del_log_stream(const std::string& name)
{
    log_stream* log_stream = stream_map[name];

    if(!log_stream)
    {
        //error << "Attempt to delete non existent log_stream " << name << std::endl;
    }
    else
    {
        if(name != NATURAL_INFO_STREAM_NAME)
        {
        	stream_map.erase(name);
            delete log_stream;
        }
    }
}

/*----------------------------------------------------------------------------.
 : User defined log_stream access                                              :
 '----------------------------------------------------------------------------*/

log_stream& basic_logger::to(std::string name)
{
    log_stream* log_stream = stream_map[name];

    if(!log_stream)
    {
        add_log_stream(name, default_log_level());
        log_stream = stream_map[name];

        if(!log_stream)
        {
           // error << "Failed to create info stream " << name << std::endl;
        }
    }

    return *log_stream;
}

log_stream& basic_logger::to(std::string name, std::string info)
{
    return static_cast<log_stream&>(to(name) << info);
}

/*------------------------------------------------------------------------.
 | std::ostream Management                                                |
 '------------------------------------------------------------------------*/

void basic_logger::attach_ostream(std::ostream& os)
{
	attach_ostream(NATURAL_LOG_OUTPUT_NAME, os);
}

void basic_logger::remove_ostream(std::ostream& os)
{
	remove_ostream(NATURAL_LOG_OUTPUT_NAME, os);
}
	
void basic_logger::attach_ostream(const std::string& name, std::ostream& os)
{
	writer.attach_ostream(name, os);
}

void basic_logger::remove_ostream(const std::string& name, std::ostream& os)
{
	writer.remove_ostream(name, os);
}

//void basic_logger::close()
//{
//}

void basic_logger::set_log_form(const log_form* const format)
{
	set_log_form(NATURAL_LOG_OUTPUT_NAME, format);
}

void basic_logger::set_log_form(const std::string& name, const log_form* const format)
{
	writer.set_log_form(name, format);
}

/*============================================================================.
 | standard_logger                                                            |
 '============================================================================*/

standard_logger::standard_logger(const std::string& name, std::ostream& os)
: basic_logger(name, os)
, debug("debug", name, writer, DEFAULT_LEVEL_DEBUG)
, info("info", name, writer, DEFAULT_LEVEL_INFO)
, warn("warn", name, writer, DEFAULT_LEVEL_WARN)
, error("error", name,  writer, DEFAULT_LEVEL_ERROR)
, fatal("fatal", name, writer, DEFAULT_LEVEL_FATAL)
{
}

standard_logger::~standard_logger(){}

log_type<basic_logger> BASIC_LOGGER;
log_type<standard_logger> STANDARD_LOGGER;


//=============================================================================
LPP_NAMESPACE_END
//=============================================================================

