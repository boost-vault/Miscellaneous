/*============================================================================.
 | Copyright (C) 2006 Gareth Buxton                                           |
 |----------------------------------------------------------------------------|
 | LogPlusPlus is free software; you can redistribute it and/or               |
 | modify it under the terms of the GNU Lesser General Public                 |
 | License as published by the Free Software Foundation; either               |
 | version 2.1 of the License, or (at your option) any later version.         |
 |                                                                            |
 | LogPlusPlus is distributed in the hope that it will be useful,             |
 | but WITHOUT ANY WARRANTY; without even the implied warranty of             |
 | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU          |
 | Lesser General Public License for more details.                            |
 |                                                                            |
 | You should have received a copy of the GNU Lesser General Public           |
 | License along with this library; if not, write to the Free Software        |
 | Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA |
 '============================================================================*/

// debug
//#include <boost/logger/log.hpp>
//#include <fstream>

#include <boost/logger/log_form.hpp>
#include <iomanip>
#include <vector>
#include <algorithm>

//=============================================================================
LPP_NAMESPACE_BEGIN
//=============================================================================
//std::ofstream formFile("form.log");
//logger& log = logger::get_logger(STANDARD_LOGGER, "form", formFile);


log_form::log_form(){}
log_form::~log_form(){}

	
std::string log_form::operator()(const log_message& message) const
{
	static std::ostringstream oss;
	oss.str("");
	oss << std::hex << message.time;
	return  "|" + oss.str() + "| [" + message.log_name + "] ("
		+ message.log_stream_name + ") " + message.text;
}

log_form_std::log_form_std(){}
log_form_std::~log_form_std(){}

std::string log_form_std::operator()(const log_message& message) const
{
	std::ostringstream oss;
	tm local = *(localtime(&message.time)); // dereference and assign
	oss << std::setfill('0');
	oss << (1900 + local.tm_year);
	oss << "-" << std::setw(2) << local.tm_mon;
	oss << "-" << std::setw(2) << local.tm_wday;
	oss << " " << std::setw(2) << local.tm_hour;
	oss << ":" << std::setw(2) << local.tm_min;
	oss << ":" << std::setw(2) << local.tm_sec;
	oss << std::setfill(' ');
	oss << std::setw(5) << " " + message.log_name;
	oss.seekp(24) << ":";
	oss << std::setw(6) << "[" + message.log_stream_name;
	oss.seekp(31) << "]";
	oss << " " << message.text;
	return  oss.str();
}

//static const std::string ESC_XTERM = std::string("\x1B");
//
//static const std::string attType[] =
//{
//	ESC_XTERM + "(B" + ESC_XTERM + "[m"							// CLEAR
//,	ESC_XTERM + "[1m"											// BOLD
//,	ESC_XTERM + "[5m"											// BLINK
//,	ESC_XTERM + "[5m" + ESC_XTERM + "[4m"						// UNDERLINE_ON
//,	ESC_XTERM + "[5m" + ESC_XTERM + "[4m" + ESC_XTERM + "[24m"	// UNDERLINE_OFF
//};
//
//enum LogColType
//{
//	COL_FORE = 0
//	, COL_BACK
//};
//
//static const std::string strColType[][2] =
//{
//	{"[3", "m"} // COL_FORE
//,	{"[4", "m"} // COL_BACK
//};
//
//enum LogAtt
//{
//	ATT_CLEAR = 0
//	, ATT_BOLD
//	, ATT_BLINK
//	, ATT_UNDERLINE_ON
//	, ATT_UNDERLINE_OFF
//};
//
//
//static const std::string STR_BLACK = "0";
//static const std::string STR_RED = "1";
//static const std::string STR_GREEN = "2";
//static const std::string STR_YELLOW = "3";
//static const std::string STR_BLUE = "4";
//static const std::string STR_MAGENTA = "5";
//static const std::string STR_CYAN = "6";
//static const std::string STR_WHITE = "7";
//
//static const std::string strCol[] = 
//{
//	STR_BLACK
//,	STR_RED
//,	STR_GREEN
//,	STR_YELLOW
//,	STR_BLUE
//,	STR_MAGENTA
//,	STR_CYAN
//,	STR_WHITE
//};
//
//static const std::string lsCol[] =
//{
//	std::string("none")
//,	std::string("fatal")
//,	std::string("info")
//,	std::string("warn")
//,	std::string("debug")
//,	std::string("error")
//};
//
//std::string getColor(LogColType colType, LogCol col)
//{
//	return ESC_XTERM + strColType[colType][0] + strCol[col] + strColType[colType][1];
//}
//
//std::string getAttribute(LogAtt att)
//{
//	return /*attType[ATT_CLEAR] + */attType[att];
//}
//
//std::string getClear()
//{
//	return getAttribute(ATT_CLEAR);
//}
//
//template <typename T, size_t N> size_t array_size(T (&)[N])
//{
//	return N;
//}
//
//template <typename T, size_t N> size_t array_size_in_bytes(T (&)[N])
//{
//	return sizeof(T[N]);
//}
//
//LogCol getLsCol(const std::string& s)
//{
////	for(unsigned int i = 0; i < sizeof(lsCol)/sizeof(std::string); ++i)
//	for(unsigned int i = 0; i < array_size(lsCol); ++i)
//	{
//		if(lsCol[i] == s) { return static_cast<LogCol>(i); }
//	}
//	
//	return COL_WHITE;
//}
//
//// log_stream collor map
//
//const LogColInfo logColArr[] =
//{
//	LogColInfo("log", COL_NONE, COL_WHITE)
//,	LogColInfo("fatal", COL_NONE, COL_RED, COL_RED, COL_RED, COL_RED, COL_RED, true, true, true) 
//,	LogColInfo("error", COL_NONE, COL_MAGENTA, COL_NONE, COL_NONE, COL_NONE, COL_NONE, true)
//,	LogColInfo("warn", COL_NONE, COL_YELLOW)
//,	LogColInfo("info", COL_NONE, COL_GREEN)
//,	LogColInfo("debug", COL_NONE, COL_BLUE)
//,	LogColInfo("+", COL_NONE, COL_NONE, COL_NONE, COL_NONE, COL_NONE, COL_GREEN, false, false, true)
//,	LogColInfo("*", COL_NONE, COL_NONE, COL_NONE, COL_NONE, COL_NONE, COL_NONE, false, false, false)
//};
//
//class LogColMap
//: public std::map<std::string, LogColInfo>
//{
//public:
//	LogColMap(const LogColInfo (&colArr)[sizeof(logColArr) / sizeof(LogColInfo)])
//	{
//		for(unsigned int i = 0; i < sizeof(colArr) / sizeof(LogColInfo); i++)
//		{
////			log << "adding: " << colArr[i].stream << std::endl;
//			(*this)[colArr[i].stream] = colArr[i];
//		}
//	}
//};
//
//const LogColMap logColMap(logColArr);
//
//log_form_term::log_form_term(const std::map<std::string, LogColInfo>* stream_map)
//: stream_map(stream_map == 0 ? &logColMap : stream_map)
//{
//	
//}
//
//log_form_term::~log_form_term(){}
//
//std::string log_form_term::operator()(const log_message& message) const
//{
////	log.set_log_form(LOG_FORM_STANDARD);
//	
////	log << "log_form()" << std::endl;
//	
//	std::ostringstream oss;
//	
//	std::string bold = "";
//	std::string blink = "";
//	std::string lineOn = "";
//	std::string lineOff = "";
//
//	std::string colDate = "";
//	std::string colTime = "";
//	std::string colLName = "";
//	std::string colSName = "";
//	std::string colText = "";
//		
//	std::string bColStream = "";
//	std::string fColStream = "";
//	
//	std::map<std::string, LogColInfo>::const_iterator i = stream_map->find("*");
//	if(i != stream_map->end()) // apply "*" (global streams)
//	{
//		if(i->second.bCol != COL_NONE) { bColStream = getColor(COL_BACK, i->second.bCol); }
//		if(i->second.fCol != COL_NONE) { fColStream = getColor(COL_FORE, i->second.fCol); }
//		if(i->second.dateCol != COL_NONE) { colDate = getColor(COL_FORE, i->second.dateCol); }
//		if(i->second.timeCol != COL_NONE) { colTime = getColor(COL_FORE, i->second.timeCol); }
//		if(i->second.lNameCol != COL_NONE) { colLName = getColor(COL_FORE, i->second.lNameCol); }
//		if(i->second.sNameCol != COL_NONE) { colSName = getColor(COL_FORE, i->second.sNameCol); }
//		bold = i->second.bold ? getAttribute(ATT_BOLD) : bold;
//		blink = i->second.blink ? getAttribute(ATT_BLINK) : blink;
//		lineOn = i->second.uline ? getAttribute(ATT_UNDERLINE_ON) : lineOn;
//		lineOff = i->second.uline ? getAttribute(ATT_UNDERLINE_ON) : lineOff;
//	}
//	
//	bool done = false;
//	i = stream_map->begin();
//	for(; i != stream_map->end(); i++)
//	{
////		log << "scanning: " << i->first << std::endl;
//		if(message.log_stream_name == i->first)
//		{
//			done = true;
//			if(i->second.bCol != COL_NONE) { bColStream = getColor(COL_BACK, i->second.bCol); }
//			if(i->second.fCol != COL_NONE) { fColStream = getColor(COL_FORE, i->second.fCol); }
//			if(i->second.dateCol != COL_NONE) { colDate = getColor(COL_FORE, i->second.dateCol); }
//			if(i->second.timeCol != COL_NONE) { colTime = getColor(COL_FORE, i->second.timeCol); }
//			if(i->second.lNameCol != COL_NONE) { colLName = getColor(COL_FORE, i->second.lNameCol); }
//			if(i->second.sNameCol != COL_NONE) { colSName = getColor(COL_FORE, i->second.sNameCol); }
//			bold = i->second.bold ? getAttribute(ATT_BOLD) : bold;
//			blink = i->second.blink ? getAttribute(ATT_BLINK) : blink;
//			lineOn = i->second.uline ? getAttribute(ATT_UNDERLINE_ON) : lineOn;
//			lineOff = i->second.uline ? getAttribute(ATT_UNDERLINE_ON) : lineOff;
//			
////			log << "> found: " << bColStream << ", " << fColStream << ", " << bold << ", " << blink << ", " << lineOn << ", " << lineOff << std::endl;
//		}
//	}
//	
//	i = stream_map->find("+");
//	if(!done && i != stream_map->end()) // apply "+" (user streams)
//	{
//		if(i->second.bCol != COL_NONE) { bColStream = getColor(COL_BACK, i->second.bCol); }
//		if(i->second.fCol != COL_NONE) { fColStream = getColor(COL_FORE, i->second.fCol); }
//		if(i->second.dateCol != COL_NONE) { colDate = getColor(COL_FORE, i->second.dateCol); }
//		if(i->second.timeCol != COL_NONE) { colTime = getColor(COL_FORE, i->second.timeCol); }
//		if(i->second.lNameCol != COL_NONE) { colLName = getColor(COL_FORE, i->second.lNameCol); }
//		if(i->second.sNameCol != COL_NONE) { colSName = getColor(COL_FORE, i->second.sNameCol); }
//		bold = i->second.bold ? getAttribute(ATT_BOLD) : bold;
//		blink = i->second.blink ? getAttribute(ATT_BLINK) : blink;
//		lineOn = i->second.uline ? getAttribute(ATT_UNDERLINE_ON) : lineOn;
//		lineOff = i->second.uline ? getAttribute(ATT_UNDERLINE_ON) : lineOff;
//	}
//	
//	int offL = 0
//		+ bold.length()
//		+ blink.length()
//		//+ lineOn.length()
//		+ bColStream.length()
//		+ colDate.length()
//		+ colTime.length()
//		+ colLName.length()
//		;
//	
//	int offS = offL + colSName.length();
//	
//	oss << bold  << blink;// << lineOn;
//	oss << bColStream;
//	
//	tm local = *(localtime(&message.time)); // dereference and assign
//	oss << std::setfill('0');
//	oss << colDate << (1900 + local.tm_year);
//	oss << "-" << std::setw(2) << local.tm_mon;
//	oss << "-" << std::setw(2) << local.tm_wday;
//	oss << colTime << " " << std::setw(2) << local.tm_hour;
//	oss << ":" << std::setw(2) << local.tm_min;
//	oss << ":" << std::setw(2) << local.tm_sec;
//	oss << std::setfill(' ');
//	oss << colLName << std::setw(5) << " " + message.log_name;
//	oss.seekp(24 + offL) << ":";
//	oss << colSName << std::setw(6) << "[" + message.log_stream_name;
//	oss.seekp(31 + offS) << "]";
//	oss << getClear();
//	oss << bold  << blink;
//	oss << bColStream;
//	oss << fColStream;
//	oss << " ";
//	oss << lineOn;
//	oss << message.text;
//	oss << lineOff;
//	oss << getClear();
//	return  oss.str();
//}

const log_form _LOG_FORM_RAW;
const log_form_std _LOG_FORM_STANDARD;
//const log_form_term _LOG_FORM_XTERM;

const log_form* const LOG_FORM_RAW = &_LOG_FORM_RAW;
const log_form_std* const LOG_FORM_STANDARD = &_LOG_FORM_STANDARD;
//const log_form_term* const LOG_FORM_XTERM = &_LOG_FORM_XTERM;

//=============================================================================
LPP_NAMESPACE_END
//=============================================================================

