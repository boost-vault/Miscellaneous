/*============================================================================.
 | Copyright (C) 2006 Gareth Buxton                                           |
 |----------------------------------------------------------------------------|
 | LogPlusPlus is free software; you can redistribute it and/or               |
 | modify it under the terms of the GNU Lesser General Public                 |
 | License as published by the Free Software Foundation; either               |
 | version 2.1 of the License, or (at your option) any later version.         |
 |                                                                            |
 | LogPlusPlus is distributed in the hope that it will be useful,             |
 | but WITHOUT ANY WARRANTY; without even the implied warranty of             |
 | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU          |
 | Lesser General Public License for more details.                            |
 |                                                                            |
 | You should have received a copy of the GNU Lesser General Public           |
 | License along with this library; if not, write to the Free Software        |
 | Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA |
 '============================================================================*/

#include <boost/logger/log_mask.hpp>
#include <sstream>
#include <iostream>

//=============================================================================
LPP_NAMESPACE_BEGIN
//=============================================================================

log_mask::log_mask()
: std::bitset<LOG_MASK_SIZE>()
{
}

log_mask::log_mask(unsigned int ui)
: std::bitset<LOG_MASK_SIZE>(ui)
{
}

log_mask::log_mask(const std::string& str)
{
	std::istringstream iss(str);
	iss >> (*this);
}

log_mask::log_mask(const log_mask& log_mask)
: std::bitset<LOG_MASK_SIZE>(log_mask.to_ulong())
{
}

log_mask::~log_mask()
{
}

log_mask log_mask::levelToMask(const log_level& log_level)
{
	return log_mask(~(0L) << static_cast<unsigned int>(log_level));//static_cast<unsigned int>(log_level));
}

std::string log_mask::to_string()
{
	static std::ostringstream oss;
	oss << (*this);
	return oss.str();
}

//=============================================================================
LPP_NAMESPACE_END
//=============================================================================

