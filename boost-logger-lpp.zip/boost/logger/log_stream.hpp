/*============================================================================.
 | Copyright (C) 2006 Gareth Buxton                                           |
 |----------------------------------------------------------------------------|
 | LogPlusPlus is free software; you can redistribute it and/or               |
 | modify it under the terms of the GNU Lesser General Public                 |
 | License as published by the Free Software Foundation; either               |
 | version 2.1 of the License, or (at your option) any later version.         |
 |                                                                            |
 | LogPlusPlus is distributed in the hope that it will be useful,             |
 | but WITHOUT ANY WARRANTY; without even the implied warranty of             |
 | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU          |
 | Lesser General Public License for more details.                            |
 |                                                                            |
 | You should have received a copy of the GNU Lesser General Public           |
 | License along with this library; if not, write to the Free Software        |
 | Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA |
 '============================================================================*/
#ifndef BOOST_LOGGER_LOG_STREAM_HPP
#define BOOST_LOGGER_LOG_STREAM_HPP

#include <boost/logger/log_types.hpp>
#include <boost/logger/log_flag.hpp>
#include <boost/logger/log_level.hpp>
#include <boost/logger/log_writer.hpp>

#include <ctime>
#include <sstream>

//=============================================================================
LPP_NAMESPACE_BEGIN
//=============================================================================

/**
 * An log_stream sends all its output to
 * a log_writer. The log_stream class maintains
 * a log_flag which it sends to the log_writer
 * whenever it requests it to write to its outputs
 * in order that the log_writer might determine
 * whether or not to actually propergate the message
 * to the actual std::ostream objects.
 **/
class log_stream
: public std::ostream
, public std::stringbuf
{
private:

	std::string name;
	const std::string logName;
	class log_writer& writer;
	log_level level;
	log_flag flag;
	bool isEnabled;

public:

	/**
	 * Override of the std::streambuf::sync() method
	 * used to notify the log_stream that
	 * a buffer is ready for writing to the log_writer
	 **/
	virtual int sync();

	/**
	 * Construct a new log_stream.
	 * @param writer The log_writer object that
	 * will recieve all the output that was sent
	 * to this log_stream.
	 * @param name The name of this log_stream, This is the
	 * 'handle' by which the user of the Log library
	 * identifies and uses this log_stream.
	 * @param log_level The level at which this stream operates.
	 * This value is internally converted into a bit flag which
	 * will subsequently be logically anded to the log_writer's
	 * LogMask in order to determine whether or not to propergate
	 * messages from this log_stream to its configured std::ostream
	 * objects.
	 **/
	log_stream(const std::string& name, const std::string& logName,
		class log_writer& writer, const log_level& level = 0);
	virtual ~log_stream();

	/**
	 * Get the name of this log_stream.
	 * @return The name of this log_stream.
	 **/
	inline
	const std::string& get_name() const { return name; }

	/**
	 * Set the name of this log_stream.
	 * @return This log_stream.
	 **/
	inline
	log_stream& set_name(const std::string& name)
	{
		this->name = name;
		return *this;
	}

	/**
	 * Set the logging level of this log_stream.
	 * @param log_level The level at which this stream operates.
	 * This value is internally converted into a bit flag which
	 * will subsequently be logically anded to the log_writer's
	 * LogMask in order to determine whether or not to propergate
	 * messages from this log_stream to its configured std::ostream
	 * objects.
	 **/
	void set_log_level(const log_level& level);

	/**
	 * Get the logging level of this log_stream.
	 * @return The currently configured logging level of
	 * this log_stream.
	 **/
	const log_level get_log_level();

	/**
	 * Get the logging flag of this log_stream.
	 * @return A flag consisting of a single set bit
	 * determined by the configured logging level
	 * of this log_stream. This flag is used by the
	 * associated log_writer to determine
	 * whether of not messages from this log_stream
	 * should be propergated its configured std::ostream objects.
	 **/
	inline
	const log_flag get_log_flag()
	{
		return flag;
	}

	/**
	 * Write to the associated log_writer.
	 * @param info The message to be sent to the associated
	 * log_writer. The log_writer will only receive this message
	 * if the logging level of this log_stream permits.
	 **/
	void write(const std::string& info) const;

	/**
	 * This operator allows for constructs such
	 * as infoStream() << "message";
	 * @return The underlying std::ostream.
	 **/
	inline
	std::ostream& operator()()
	{
		return *this;
	}

	/**
	 * This operator allows for constructs such
	 * as infoStream("message 1") << "message 2";
	 * @return The underlying std::ostream.
	 **/
	inline
	std::ostream& operator()(const std::string& info)
	{
		return (*this) << info;
	}

	/**
	 * Turn this log_stream on.
	 **/
	inline
	void on()
	{
		flag = (1UL << static_cast<unsigned int>(level));
		//flag = level;
		isEnabled = true;
	}

	/**
	 * Turn this log_stream off.
	 **/
	inline
	void off()
	{
		isEnabled = false;
		flag = 0;
	}

	/**
	 * Chech if this Infotream is enabled.
	 * @return true if this log_stream is enabled.
	 **/
	inline
	bool is_on() const
	{
		return isEnabled;
	}
	
	/*------------------------------------------------------------------------.
	 | Syntactic Sugar                                                        |
	 '------------------------------------------------------------------------*/

	/**
	 * Chech if this Infotream is disabled.
	 * @return true if this log_stream is disabled.
	 **/
	inline
	bool is_off() const
	{
		return !is_on();
	}

	/**
	 * Turn this log_stream on or off.
	 **/
	inline
	void tog()
	{
		is_on() ? off() : on();
	}
	
	/*------------------------------------------------------------------------.
	 | Syntactic Sugar compatability with minisplat Dbg class                 |
	 '------------------------------------------------------------------------*/

	/**
	 * Turn this log_stream on.
	 **/
	inline
	void setEnabled(bool enabled)
	{
		enabled ? on() : off();
	}

	/**
	 * Chech if this log_stream is enabled.
	 * @return true if this log_stream is enabled.
	 **/
	inline
	bool getEnabled() const
	{
		return is_on();
	}
};

//=============================================================================
LPP_NAMESPACE_END
//=============================================================================

#endif // BOOST_LOGGER_LOG_STREAM_HPP
