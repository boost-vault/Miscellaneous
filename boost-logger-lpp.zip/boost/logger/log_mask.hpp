/*============================================================================.
 | Copyright (C) 2006 Gareth Buxton                                           |
 |----------------------------------------------------------------------------|
 | LogPlusPlus is free software; you can redistribute it and/or               |
 | modify it under the terms of the GNU Lesser General Public                 |
 | License as published by the Free Software Foundation; either               |
 | version 2.1 of the License, or (at your option) any later version.         |
 |                                                                            |
 | LogPlusPlus is distributed in the hope that it will be useful,             |
 | but WITHOUT ANY WARRANTY; without even the implied warranty of             |
 | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU          |
 | Lesser General Public License for more details.                            |
 |                                                                            |
 | You should have received a copy of the GNU Lesser General Public           |
 | License along with this library; if not, write to the Free Software        |
 | Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA |
 '============================================================================*/
#ifndef BOOST_LOGGER_LOG_MASK_HPP
#define BOOST_LOGGER_LOG_MASK_HPP

#include <bitset>

#include <boost/logger/log_types.hpp>
#include <boost/logger/log_flag.hpp>
#include <boost/logger/log_level.hpp>

//=============================================================================
LPP_NAMESPACE_BEGIN
//=============================================================================

/**
 * Log and masked ostreams each maintain a
 * log_mask object. The log_mask is a bitset that
 * is used to determine whether or not to output
 * an info message arriving at a given log_level.
 **/
class log_mask
: public std::bitset<LOG_MASK_SIZE>
{
public:
	log_mask();
	log_mask(unsigned int ui);
	log_mask(const std::string&);
	log_mask(const log_mask& mask);
	virtual ~log_mask();
	
	inline
	log_mask& operator=(const log_mask& mask)
	{
		// Safer...
		//std::bitset<LOG_MASK_SIZE>::operator=(mask);
		//return (*this);
		
		// Faster??
		return static_cast<log_mask&>(std::bitset<LOG_MASK_SIZE>::operator=(mask));
	}
	
	inline
	void apply(const log_mask &mask, const mod_type& type)
	{
		switch(type)
		{
			case REPLACE: (*this) = mask; break;
			case AND: (*this) &= mask; break;
			case IOR: (*this) |= mask; break;
			case EOR: (*this) ^= mask; break;
			case NAND: (*this) &= ~mask; break;
			default: (*this) = mask;
		} 
	}
	
	inline
	bool operator()(const log_flag& flag) const
	{
		return !(*this & flag).any();
	}

	std::string to_string();
	
	static log_mask levelToMask(const log_level& level);
};

//=============================================================================
LPP_NAMESPACE_END
//=============================================================================

#endif /*BOOST_LOGGER_LOG_MASK_HPP*/
