/*============================================================================.
 | Copyright (C) 2006 Gareth Buxton                                           |
 |----------------------------------------------------------------------------|
 | LogPlusPlus is free software; you can redistribute it and/or               |
 | modify it under the terms of the GNU Lesser General Public                 |
 | License as published by the Free Software Foundation; either               |
 | version 2.1 of the License, or (at your option) any later version.         |
 |                                                                            |
 | LogPlusPlus is distributed in the hope that it will be useful,             |
 | but WITHOUT ANY WARRANTY; without even the implied warranty of             |
 | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU          |
 | Lesser General Public License for more details.                            |
 |                                                                            |
 | You should have received a copy of the GNU Lesser General Public           |
 | License along with this library; if not, write to the Free Software        |
 | Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA |
 '============================================================================*/
#ifndef BOOST_LOGGER_LOG_LEVEL_HPP
#define BOOST_LOGGER_LOG_LEVEL_HPP

#include <boost/logger/log_types.hpp>
#include <ostream>
#include <string>

//=============================================================================
LPP_NAMESPACE_BEGIN
//=============================================================================

/**
 * log_stream objects are set to a specific log_level.
 * The log_level is used with the log_mask to determine
 * weather or not to output the log_stream.
 **/
typedec(log_level, unsigned int);

static const log_level DEFAULT_LEVEL_DEBUG = log_level(0);
static const log_level DEFAULT_LEVEL_INFO = log_level(1);
static const log_level DEFAULT_LEVEL_WARN = log_level(2);
static const log_level DEFAULT_LEVEL_ERROR = log_level(3);
static const log_level DEFAULT_LEVEL_FATAL = log_level(4);
static const log_level MAX_LEVEL = log_level(LOG_MASK_SIZE - 1);
static const log_level DEFAULT_LEVEL_NONE = MAX_LEVEL;


//=============================================================================
LPP_NAMESPACE_END
//=============================================================================


#endif /*BOOST_LOGGER_LOG_LEVEL_HPP*/
