/*============================================================================.
 | Copyright (C) 2006 Gareth Buxton                                           |
 |----------------------------------------------------------------------------|
 | LogPlusPlus is free software; you can redistribute it and/or               |
 | modify it under the terms of the GNU Lesser General Public                 |
 | License as published by the Free Software Foundation; either               |
 | version 2.1 of the License, or (at your option) any later version.         |
 |                                                                            |
 | LogPlusPlus is distributed in the hope that it will be useful,             |
 | but WITHOUT ANY WARRANTY; without even the implied warranty of             |
 | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU          |
 | Lesser General Public License for more details.                            |
 |                                                                            |
 | You should have received a copy of the GNU Lesser General Public           |
 | License along with this library; if not, write to the Free Software        |
 | Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA |
 '============================================================================*/
#ifndef BOOST_LOGGER_LOG_FLAG_HPP
#define BOOST_LOGGER_LOG_FLAG_HPP

#include <boost/logger/log_types.hpp>

#include <bitset>

//=============================================================================
LPP_NAMESPACE_BEGIN
//=============================================================================

/**
 * Each LogStream maintains its own
 * LogFlag. This is a bitset which is
 * internally matched against a LogMask
 * in order to determine whether or not
 * to allow a message to be sent to one
 * of the outputs.
 **/
class log_flag
: public std::bitset<LOG_MASK_SIZE>
{
public:

	log_flag(unsigned long ui);
	~log_flag();
};

//=============================================================================
LPP_NAMESPACE_END
//=============================================================================

#endif /*BOOST_LOGGER_LOG_FLAG_HPP*/
