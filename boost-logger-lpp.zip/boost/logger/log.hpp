/*============================================================================.
 | Copyright (C) 2006-2007 Gareth Buxton                                           |
 |----------------------------------------------------------------------------|
 | Distributed under the Boost Software License, ersion 1.0 (see accompanying |                                                                            |
 | file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)      |
 '============================================================================*/
#ifndef BOOST_LOGGER_LOG_HPP
#define BOOST_LOGGER_LOG_HPP
 
#include <boost/logger/log_types.hpp>
#include <boost/logger/log_stream.hpp>
#include <boost/logger/log_level.hpp>
#include <boost/logger/log_mask.hpp>
#include <boost/logger/log_writer.hpp>

#include <string>
#include <map>
#include <iostream>

//=============================================================================
LPP_NAMESPACE_BEGIN
//=============================================================================

class log_exception
: public std::exception
{
private:
	std::string message;
	
public:
	log_exception(const std::string& message) throw();
	~log_exception()  throw();
	const char* what() const throw();
};

/**
 * This is a factory class for creating logger objects
 * of a given type.
 **/
template<typename L> class log_type
{
	typedef std::map<std::string, class logger*> log_map;
	typedef log_map::iterator log_map_iterator;
	
private:
	static log_map& get_log_map()
	{
		static log_map map;
		return map;
	}

public:
	L& operator()(const std::string& name, std::ostream& os = std::clog) const
	{
		log_map& map = get_log_map();
		
		if(!map[name])
		{
			map[name] = new L(name, os);
			// TODO: Add this!!
			//map[name]->set_log_form(configured_log_form());
		}
		
		return static_cast<L&>(*map[name]);
	}
	
	void closedown()
	{
		log_map& map = get_log_map();
		
		for(log_map_iterator i = map.begin(); i != map.end(); i++)
		{
			delete (*i).second;
		}
	}
};

class logger
: public log_stream
{
protected:
	logger(const std::string& name, class log_writer& writer, const log_level& level);

public:

	virtual ~logger();

	/*========================================================================.
	 | Static Interface                                                       |
	 '========================================================================*/

	static const class log_form* configured_log_form(const log_form* logForm = 0);

	/**
	 * Either create or retrieve a previously
	 * created, unnamed, Log. If this method has
	 * been called previously, the same log will
	 * be returned, otherwise a new one is created.
	 * @param os An optional std::ostream to report to.
	 * If not specified then std::clog will be used.
	 **/
	template<typename L> static L& get_logger(const log_type<L> type, std::ostream& os = std::clog)
	{
		return logger::get_logger(type, DEFAULT_LOG_NAME, os);
	}

	/**
	 * Either create or retrieve a previously
	 * created, named logger. If this method has
	 * been called previously with the same value in
	 * the parameter the same log will
	 * be returned, otherwise a new one is created.
	 * 
	 * @param name The name of the logger to create/return.
	 * @param os An optional std::ostream to report to.
	 * If not specified then std::clog will be used.
	 **/
	template<typename L> static L& get_logger(const log_type<L> type
		, const char* name, std::ostream& os = std::clog)
	{
		return get_logger(type, std::string(name), os);
	}
	
	/**
	 * Either create or retrieve a previously
	 * created, named logger. If this method has
	 * been called previously with the same value in
	 * the parameter the same log will
	 * be returned, otherwise a new one is created.
	 * 
	 * @param name The name of the logger to create/return.
	 * @param os An optional std::ostream to report to.
	 * If not specified then std::clog will be used.
	 * 
	 **/
	template<typename L> static L& get_logger(const log_type<L> type
		, const std::string& name, std::ostream& os = std::clog)
	{
		return type(name, os);
	}
	
	/**
	 * Set the logging level at which all new logs will operate.
	 * 
	 * @param level This value is used internally to determine
	 * whether or not to publish messages to the log based on the
	 * current mask setting of the log.
	 **/
	static void set_default_log_level(const log_level& level);
	
	/**
	 * Set the logging mask that which all new logs will apply
	 * to received messages.
	 * 
	 * @param mask This value is used internally to determine
	 * whether or not to publish messages to the log based on the
	 * the messages current logging level setting.
	 **/
	static void set_default_log_mask(const log_mask& mask);

	// TODO: setInternallog_mask()
	// sets the log mask of the log's log. 
	// so you can choose how noisy the log is
	// when you cause an error eg. by deleting
	// a non-existant log.

	/**
	 * Close all log_streams freeing all resources.
	 **/
	template<typename L> static void closedown(const log_type<L>& type)
	{
		type.closedown();
	}

	/*========================================================================.
	 | Dynamic Interface                                                      |
	 '========================================================================*/

	/**
	 * Return the name of this Log. This is the unique
	 * 'handle' for this log and any calls to the static
	 * method get_logger(std::string name) with the returned
	 * value of this method will always return the same log.
	 **/
	virtual const std::string& get_name() const = 0;

	/*------------------------------------------------------------------------.
	 | log_output Management                                                   |
	 '------------------------------------------------------------------------*/

	/**
	 * Add a log_output to this Log.
	 * @param name The name by which to refer to the
	 * new log_output.
	 * @param mask The log_mask to apply to
	 * the new log_output.
	 * @param os An optional std::ostream to attach to
	 * the new log_output.
	 **/
	virtual void add_output(const std::string& name, const log_mask& mask,
		std::ostream& os = std::cout) = 0;
	
	/**
	 * Modify the log_mask for the default log_output of this Log.
	 * @param mask The new log_mask to apply to
	 * the named log_output.
	 * @param type The method by which to apply the new log_mask.
	 **/
	virtual void set_log_mask(const log_mask& mask,
		mod_type type = REPLACE) = 0;

	/**
	 * Modify the log_mask for a log_output added to this Log.
	 * @param name The name of the log_output to modify.
	 * @param mask The new log_mask to apply to
	 * the named log_output.
	 * @param type The method by which to apply the new log_mask.
	 **/
	virtual void set_log_mask(const std::string& name, const log_mask& mask,
		mod_type type = REPLACE) = 0;	

	/**
	 * Modify the log_mask for the default log_output of this Log based
	 * on which log_stream log_level is required as a minimum to pass
	 * through the log_output log_mask.
	 * @param level The new log_mask is calculated from this value such
	 * that it will prevent any log_stream objects of a log_level lower than
	 * this from writing to the log_output.
	 * @param type The method by which to apply the new log_mask.
	 **/
	virtual void set_log_mask_level(const log_level& level,
		mod_type type = REPLACE) = 0;

	/**
	 * Modify the log_mask for a log_output added to this Log based
	 * on which log_stream log_level is required as a minimum to pass
	 * through the log_output log_mask.
	 * @param level The new log_mask is calculated from this value such
	 * that it will prevent any log_stream objects of a log_level lower than
	 * this from writing to the log_output.
	 * @param type The method by which to apply the new log_mask.
	 **/
	virtual void set_log_mask_level(const std::string& name, const log_level& level,
		mod_type type = REPLACE) = 0;
	
	/**
	 * Get the log_mask for the default log_output of this Log.
	 * @return The log_mask assigned to the default log_output
	 * of this Log.
	 **/
	virtual log_mask get_log_mask() = 0;
	
	/**
	 * Get the log_mask for a log_output added to this Log.
	 * @param name The name of the log_output to query.
	 * @return The log_mask assigned to the specified log_output
	 * of this Log.
	 **/
	virtual log_mask get_log_mask(const std::string& name) = 0;
	
	/**
	 * Change the internal log_form formatting object of the
	 * default log_output for this Log.
	 * @param name The name of the log_output to modify.
	 * @param format The new log_form object to use.
	 **/
	virtual void set_log_form(const class log_form* const format) = 0;
	
	/**
	 * Change the internal log_form formatting object of a
	 * log_output added to this Log.
	 * @param name The name of the log_output to modify.
	 * @param format The new log_form object to use.
	 **/
	virtual void set_log_form(const std::string& name, const log_form* const format) = 0;

	/**
	 * Delete a log_output from this Log.
	 * @param name The name of the log_output to delete.
	 **/
	virtual void del_output(const std::string& name) = 0;
		
	/*------------------------------------------------------------------------.
	 | std::ostream Management                                                |
	 '------------------------------------------------------------------------*/

	/**
	 * Attach an output stream to the default log_output
	 * of this Log.
	 * @param os The std::ostream attach.
	 **/
	virtual void attach_ostream(std::ostream& os) = 0;

	/**
	 * Attach an std::ostream to one of the log_output
	 * objects added to this Log.
	 * @param name The name of the log_output to attach the std::ostream to.
	 * @param os The std::ostream to attach.
	 **/
	virtual void attach_ostream(const std::string& name, std::ostream& os) = 0;

	/**
	 * Remove an output stream from the default log_output
	 * of this Log.
	 * @param os The std::ostream remove.
	 **/
	virtual void remove_ostream(std::ostream& os) = 0;
	
	/**
	 * Remove an ostream from one of the log_output
	 * objects added to this Log.
	 * @param name The log_output to remove the std::ostream from.
	 * @param os The std::ostream remove.
	 **/
	virtual void remove_ostream(const std::string& name, std::ostream& os) = 0;

	// Add new message levels in addition to the builtin
	// ones, eg. debug(), error(), info(), ... etc.

	/*------------------------------------------------------------------------.
	 | log_stream Management                                                  |
	 '------------------------------------------------------------------------*/

	/**
	 * Add an log_stream to this log.
	 * @param name The name by which this new
	 * log_stream will be known.
	 * @param level The log_level at which the new log_stream
	 * will operate.
	 **/
	virtual void add_log_stream(const std::string& name,
		const log_level& level = MAX_LEVEL) = 0;

	/**
	 * Modify either one of the builtin log_stream objects
	 * or an log_stream attached to this log with
	 * a previous call to add_log_stream(std::string, log_level).
	 * @param name The name (handle) of the log_stream to modify.
	 * @param level The new log_level at which the log_stream
	 * will now operate.
	 **/
	virtual void mod_log_stream(const std::string& name, const log_level& level) = 0;

	/**
	 * Remove an log_stream attached to this log with
	 * a previous call to add_log_stream(std::string, log_level).
	 * @param name The name (handle) of the log_stream to remove.
	 **/
	virtual void del_log_stream(const std::string& name) = 0;
	
	/*------------------------------------------------------------------------.
	 | User defined log_stream access                                         |
	 '------------------------------------------------------------------------*/

	/**
	 * Method to access either one of the builtin log_stream objects
	 * or an log_stream attached to this log with
	 * a previous call to add_log_stream(std::string, log_level).
	 * @param name The name (handle) of the log_stream to access.
	 **/
	virtual log_stream& to(std::string name) = 0;

	/**
	 * Method to send info to either one of the builtin log_stream objects
	 * or an log_stream attached to this log with
	 * a previous call to add_log_stream(std::string, log_level).
	 * @param name The name (handle) of the log_stream to access.
	 * @param info The message to send to this log_stream.
	 **/
	virtual log_stream& to(std::string name, std::string info) = 0;
};

class basic_logger
: public logger
{
	// User defined log levels in addition to 
	// the builtin ones (debug, info etc...
	typedef std::map<std::string, log_stream*> log_stream_map;
	typedef log_stream_map::iterator log_stream_map_iterator;
	friend class log_type<basic_logger>;
	
protected:

	std::string name;
	log_writer writer;

	/**
	 * Note stream_map only holds the user
	 * created log_stream objects to allow for string key
	 * access to the log_streams.
	 **/
	log_stream_map stream_map;

	static const log_level& check_log_level( const log_level& level);
	static const log_level& default_log_level(const log_level* level = 0);
	static const log_mask& default_log_mask(const log_mask* mask = 0);
	
protected:       
	basic_logger(const std::string& name, std::ostream& os);
	~basic_logger();

public:

	 const std::string& get_name() const;
	 
	 void add_output(const std::string& name, const log_mask& mask,
		std::ostream& os = std::cout);

	 void set_log_mask(const log_mask& mask,
		mod_type type = REPLACE);
	 void set_log_mask(const std::string& name, const log_mask& mask,
		mod_type type = REPLACE);	

	 void set_log_mask_level(const log_level& level,
			mod_type type = REPLACE);
	 void set_log_mask_level(const std::string& name, const log_level& level,
		mod_type type = REPLACE);

	 log_mask get_log_mask();
	 log_mask get_log_mask(const std::string& name);

	 void set_log_form(const class log_form* const format);
	 void set_log_form(const std::string& name, const log_form* const format);

	 void del_output(const std::string& name);

	 void attach_ostream(std::ostream& os);
	 void attach_ostream(const std::string& name, std::ostream& os);

	 void remove_ostream(std::ostream& os);
	 void remove_ostream(const std::string& name, std::ostream& os);

	 void add_log_stream(const std::string& name,
		const log_level& level = MAX_LEVEL);
	 void mod_log_stream(const std::string& name, const log_level& level);
	 void del_log_stream(const std::string& name);

	 log_stream& to(std::string name);
	 log_stream& to(std::string name, std::string info);
};

class standard_logger
: public basic_logger
{
	friend class log_type<standard_logger>;
	
private:

protected:
	standard_logger(const std::string& name, std::ostream& os);
	~standard_logger();

public:

	/*========================================================================.
	 | Builtin log_streams                                                     |
	 '========================================================================*/
	 
	/**
	 * Builtin InputStream. 'debug' operates
	 * at a level below all other builtin
	 * input streams.
	 **/
	log_stream debug;

	/**
	 * Builtin InputStream. 'info' operates
	 * at a level above 'debug' and below all
	 * other builtin input streams.
	 **/
	log_stream info;

	/**
	 * Builtin InputStream. 'warn' operates
	 * at a level above 'info' and below all
	 * other builtin input streams.
	 **/
	log_stream warn;

	/**
	 * Builtin InputStream. 'error' operates
	 * at a level above 'warn' and below
	 * 'fatal'.
	 **/
	log_stream error;

	/**
	 * Builtin InputStream. 'fatal' operates
	 * at a level above all other builtin
	 * input streams.
	 **/
	log_stream fatal;	
};

extern log_type<basic_logger> BASIC_LOGGER;
extern log_type<standard_logger> STANDARD_LOGGER;

//=============================================================================
LPP_NAMESPACE_END
//=============================================================================

#endif /*BOOST_LOGGER_LOG_HPP*/
