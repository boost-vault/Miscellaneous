/*============================================================================.
 | Copyright (C) 2006 Gareth Buxton                                           |
 |----------------------------------------------------------------------------|
 | LogPlusPlus is free software; you can redistribute it and/or               |
 | modify it under the terms of the GNU Lesser General Public                 |
 | License as published by the Free Software Foundation; either               |
 | version 2.1 of the License, or (at your option) any later version.         |
 |                                                                            |
 | LogPlusPlus is distributed in the hope that it will be useful,             |
 | but WITHOUT ANY WARRANTY; without even the implied warranty of             |
 | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU          |
 | Lesser General Public License for more details.                            |
 |                                                                            |
 | You should have received a copy of the GNU Lesser General Public           |
 | License along with this library; if not, write to the Free Software        |
 | Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA |
 '============================================================================*/
#ifndef BOOST_LOGGER_LOG_FORM_HPP
#define BOOST_LOGGER_LOG_FORM_HPP

#include <boost/logger/log_types.hpp>
#include <boost/logger/log_flag.hpp>
//#include <boost/logger/log_stream.hpp>

#include <sstream>
#include <string>
#include <iomanip>
#include <map>

//=============================================================================
LPP_NAMESPACE_BEGIN
//=============================================================================

struct log_message
{
	/**
	 * The system time at which this log_message
	 * was constructed.
	 **/
	const time_t time;
	
	/**
	 * The log_flag of the log_stream through which
	 * this log_message was sent.
	 **/
	const log_flag flag;

	/**
	 * The name of the Log this log_message
	 * was sent to.
	 **/
	const std::string log_name;

	/**
	 * The name of the log_stream this log_message
	 * was sent to (as created by a call to
	 * Log::addlog_stream(const std::string& name, LogLevel level = MAX_LEVEL);
	 **/
	const std::string log_stream_name;

	/**
	 * The text of this log_message. 
	 **/
	const std::string text;

private:
	
	/**
	 * Only this member function can create instances
	 * of a log_message.
	 **/
	//friend void log_stream::write(const std::string& info) const;
	friend class log_stream;
	
	/**
	 * Create a log_message object.
	 **/
	log_message(time_t time, const log_flag& flag, const std::string& log_name,
		const std::string& log_stream_name, const std::string& text): time(time),
		flag(flag),	log_name(log_name), log_stream_name(log_stream_name),
		text(text) {}
};

/**
 * log_form is the base class of all classes that are used to
 * format the messeges through the stream. Implementing
 * classes should override the
 * std::string operator()( const log_message& message)
 * member function to provide a new logging format.
 * 
 **/
class log_form
{
public:
	log_form();
	virtual ~log_form();

	/**
	 * This overrided function receives a log_message as its
	 * parameter and from that produces a formattes std::string 
	 * which will be sent to the LogWriter for output.
	 * @param message The log_message to be formatted into a std::string.
	 * @return A std::string formated from the information provided
	 * in the log_message.
	 **/
	virtual std::string operator()(const log_message& message) const;
};

/*---------------------------------------------------------------------------.
 | Convienient log_forms                                                      |
 '---------------------------------------------------------------------------*/

/**
 * log_form_std provides a basic output format suitable
 * for most purposes. The Log name and the log_stream
 * name are truncated to four characters width to 
 * provide a nicely columated format.
 * <pre> 
 * Date       Time     Log  Stream  Message
 * 
 * 2007-02-03 00:15:49 core:  [log] message to log
 * 2007-02-03 00:15:49 core:[fatal] message to fatal
 * 2007-02-03 00:15:49 core:[error] message to error
 * 2007-02-03 00:15:49 core: [warn] message to warn
 * 2007-02-03 00:15:49 core: [info] message to info
 * 2007-02-03 00:15:49 core:[debug] message to debug
 * 2007-02-03 00:19:31 core:[defin] message to defined
 * </pre>
 **/
class log_form_std
: public log_form
{
public:
	log_form_std();
	~log_form_std();
	std::string operator()(const log_message& message) const;
};

enum LogCol
{
	COL_NONE = -1
,	COL_BLACK = 0
,	COL_RED
,	COL_GREEN
,	COL_YELLOW
,	COL_BLUE
,	COL_MAGENTA
,	COL_CYAN
,	COL_WHITE
};

struct LogColInfo
{
	std::string stream;
	LogCol bCol;
	LogCol fCol;
	LogCol dateCol;
	LogCol timeCol;
	LogCol lNameCol;
	LogCol sNameCol;
	
	bool bold;
	bool blink;
	bool uline;
	
	LogColInfo(const std::string& logStream = ""
			, LogCol bCol = COL_NONE
			, LogCol fCol = COL_NONE
			, LogCol dateCol = COL_NONE
			, LogCol timeCol = COL_NONE
			, LogCol lNameCol = COL_NONE
			, LogCol sNameCol = COL_NONE
			, bool bold = false, bool blink = false, bool uline = false)
	: stream(stream)
	, bCol(bCol)
	, fCol(fCol)
	, dateCol(dateCol)
	, timeCol(timeCol)
	, lNameCol(lNameCol)
	, sNameCol(sNameCol)
	, bold(bold)
	, blink(blink)
	, uline(uline)
	{
		
	}
};

//class log_form_term
//: public log_form
//{
//private:
//	const std::map<std::string, LogColInfo>* stream_map;
//	
//public:
//	log_form_term(const std::map<std::string, LogColInfo>* stream_map = 0);
//	~log_form_term();
//	
//	std::string operator()(const log_message& message) const;
//};

extern const log_form* const LOG_FORM_RAW;
extern const log_form_std* const LOG_FORM_STANDARD;
//extern const log_form_term* const LOG_FORM_XTERM;

//=============================================================================
LPP_NAMESPACE_END
//=============================================================================

#endif /*BOOST_LOGGER_LOG_FORM_HPP*/

