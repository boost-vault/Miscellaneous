/*============================================================================.
 | Copyright (C) 2006 Gareth Buxton                                           |
 |----------------------------------------------------------------------------|
 | LogPlusPlus is free software; you can redistribute it and/or               |
 | modify it under the terms of the GNU Lesser General Public                 |
 | License as published by the Free Software Foundation; either               |
 | version 2.1 of the License, or (at your option) any later version.         |
 |                                                                            |
 | LogPlusPlus is distributed in the hope that it will be useful,             |
 | but WITHOUT ANY WARRANTY; without even the implied warranty of             |
 | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU          |
 | Lesser General Public License for more details.                            |
 |                                                                            |
 | You should have received a copy of the GNU Lesser General Public           |
 | License along with this library; if not, write to the Free Software        |
 | Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA |
 '============================================================================*/
#ifndef BOOST_LOGGER_LOG_WRITER_HPP
#define BOOST_LOGGER_LOG_WRITER_HPP

#include <boost/logger/log_types.hpp>
#include <boost/logger/log_flag.hpp>
#include <boost/logger/log_mask.hpp>
#include <boost/logger/log_form.hpp>

#include <map>
#include <string>
#include <iostream>
#include <queue>
#include <ctime>

//=============================================================================
LPP_NAMESPACE_BEGIN
//=============================================================================

class log_output;
typedef std::map<std::string, log_output*> log_output_map;

/**
 * The log_writer class maintains a list of log_output objects
 * and potentially a log_message queue if threaded queueing is
 * enabled.
 **/
class log_writer
//: public Runnable
{
private:

	log_output_map output_map;

	bool isDone;
	void flush();
	
public:

	log_writer();
	virtual ~log_writer();

	/*------------------------------------------------------------------------.
	 | log_output Management                                                   |
	 '------------------------------------------------------------------------*/

	/**
	 * Add a log_output to this log_writer.
	 * @param name The name by which to refer to the
	 * new log_output.
	 * @param log_mask The log_mask to apply to
	 * the new log_output.
	 * @param os A std::ostream to attach to
	 * the new log_output.
	 **/
	void add_output(const std::string& name, const log_mask& mask,
		std::ostream& os);

	/**
	 * Modify a log_output added to this log_writer.
	 * @param name The name of the log_output to modify.
	 * @param log_mask The new log_mask to apply to
	 * the named log_output.
	 * @param type The method by which to apply the new log_mask.
	 **/
	void set_log_mask(const std::string& name, const log_mask& mask,
		mod_type type = REPLACE);

	/**
	 * Get the log_mask for a log_output added to this log_writer.
	 * @param name The name of the log_output to query.
	 * @return The log_mask assigned to the specified log_output
	 * of this log_writer.
	 **/
	log_mask get_log_mask(const std::string& name);

	/**
	 * Change the internal log_form formatting object of a
	 * log_output added to this log_writer.
	 * @param name The name of the log_output to modify.
	 * @param format The new log_form object to use.
	 **/
	void set_log_form(const std::string& name, const class log_form* const format);

	/**
	 * Delete a log_output from this log_writer.
	 * @param name The name of the log_output to delete.
	 **/
	void del_output(const std::string& name);

	/*------------------------------------------------------------------------.
	 | std::ostream Management                                                |
	 '------------------------------------------------------------------------*/

	/**
	 * Attach an ostream to one of the log_outputs
	 * of this log_writer.
	 * @param name The log_output to attach the std::ostream to.
	 * @param os The std::ostream attach.
	 **/
	void attach_ostream(const std::string& name, std::ostream& os);

	/**
	 * Remove an output stream from one of the log_outputs
	 * of this log_writer.
	 * @param name The log_output to remove the std::ostream from.
	 * @param os The std::ostream remove.
	 **/
	void remove_ostream(const std::string& name, std::ostream& os);

	/*------------------------------------------------------------------------.
	 | Action Interface                                                       |
	 '------------------------------------------------------------------------*/

	/**
	 * Write a log_message to each log_output maintained
	 * by this log_writer.
	 * @param message The log_message to write.
	 **/
	void write(log_message& message);
};

//=============================================================================
LPP_NAMESPACE_END
//=============================================================================

#endif /*BOOST_LOGGER_LOG_WRITER_HPP*/
