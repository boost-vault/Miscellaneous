/*============================================================================.
 | Copyright (C) 2006 Gareth Buxton                                           |
 |----------------------------------------------------------------------------|
 | LogPlusPlus is free software; you can redistribute it and/or               |
 | modify it under the terms of the GNU Lesser General Public                 |
 | License as published by the Free Software Foundation; either               |
 | version 2.1 of the License, or (at your option) any later version.         |
 |                                                                            |
 | LogPlusPlus is distributed in the hope that it will be useful,             |
 | but WITHOUT ANY WARRANTY; without even the implied warranty of             |
 | MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU          |
 | Lesser General Public License for more details.                            |
 |                                                                            |
 | You should have received a copy of the GNU Lesser General Public           |
 | License along with this library; if not, write to the Free Software        |
 | Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA |
 '============================================================================*/
#ifndef  BOOST_LOGGER_LOG_TYPES_H
#define  BOOST_LOGGER_LOG_TYPES_H

#include <exception>

#define LPP_NAMESPACE boost

#define LPP_NAMESPACE_BEGIN namespace LPP_NAMESPACE { namespace logger {
#define LPP_NAMESPACE_END }}
#define USING_NAMESPACE_LPP using namespace LPP_NAMESPACE ;

//=============================================================================
LPP_NAMESPACE_BEGIN
//=============================================================================

#define typedec_cdec(C, T) \
 \
class C \
{ \
public: \
	T t; \
 \
public: \
	C() {} \
	C(T t) : t(t) {} \
	C(const C& c) : t(c.t) {} \
	virtual ~C() {} \
  \
	C& operator=(const C& c) { t = c.t; return *this; } \
 \
	operator T() const { return t; } \
\
	bool operator<(const C& c) const { return t < c.t; } \
	bool operator<=(const C& c) const { return t <= c.t; } \
	bool operator>(const C& c) const { return t > c.t; } \
	bool operator>=(const C& c) const { return t >= c.t; } \
	bool operator==(const C& c) const { return t == c.t; } \
 \
	C& operator++() { ++t; return *this; } \
	C& operator++(int) { ++t; return *this; } \
 \
	T operator()() const { return 6; } \
}

#define typedec_sdec(C) inline std::ostream& operator<<(std::ostream &os, const C& c) \
{ \
	return os << c.t; \
}

#define typedec_ddec(C) class _C {}

#define typedec(C, T) typedec_cdec(C, T); typedec_sdec(C) typedec_ddec(C)

#define LOG_MASK_SIZE (sizeof(unsigned long) * 8)

#define NATURAL_INFO_STREAM_NAME "log"
#define NATURAL_LOG_OUTPUT_NAME "*"
#define INTERNAL_LOG_NAME "~"
#define DEFAULT_LOG_NAME "-"

extern const char* const version;
extern const char* const build;

//class Log;

typedef unsigned int mod_type;

/**
 * Bitwise modification style: Replace all bits.
 **/
static const mod_type REPLACE = 0;

/**
 * Bitwise modification style: AND all bits.
 **/
static const mod_type AND = 1;

/**
 * Bitwise modification style: Inclusive OR all bits.
 **/
static const mod_type OR = 2;

/**
 * Bitwise modification style: Inclusive OR all bits.
 **/
static const mod_type IOR = 2;

/**
 * Bitwise modification style: Inclusive OR all bits.
 **/
static const mod_type SET = 2;

/**
 * Bitwise modification style: Exclusive OR all bits.
 **/
static const mod_type EOR = 3;

/**
 * Bitwise modification style: Exclusive OR all bits.
 **/
static const mod_type XOR = 3;

/**
 * Bitwise modification style: Exclusive OR all bits.
 **/
static const mod_type TOGGLE = 3;

/**
 * Bitwise modification style: NAND all bits.
 **/
static const mod_type NAND = 4;

/**
 * Bitwise modification style: NAND all bits.
 **/
static const mod_type CLEAR = 4;

static const mod_type MOD_TYPE_COUNT = 5;

//class LogFlag;

//=============================================================================
LPP_NAMESPACE_END
//=============================================================================

#endif /*BOOST_LOGGER_LOG_TYPES_H*/
