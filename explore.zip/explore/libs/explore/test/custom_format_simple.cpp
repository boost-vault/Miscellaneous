// Boost.Explore library
//
// Copyright (C) 2007, Jared McIntyre
// Copyright (C) 2009, Jeffrey Faust
//
// Distributed under the Boost Software License, Version 1.0. (See accompanying
// file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
//

#define BOOST_TEST_MODULE PrintLib
#include <boost/test/unit_test.hpp>
#include <boost/range/iterator_range.hpp>
#include <boost/explore/manipulators.hpp>
#include <boost/explore/vector.hpp>
#include <boost/explore/map.hpp>
#include <boost/explore/iterator_range.hpp>
#include <vector>
#include "boost_explore_test_tools.hpp"

std::ostream& basic_stream_format(std::ostream& ostr)
{
    using namespace boost::explore;
    return ostr << start("<=") << separator("#") << end("=>")
                << assoc_item_start("\\") << assoc_item_separator("**") << assoc_item_end("//");
}

std::wostream& basic_stream_format(std::wostream& ostr)
{
    using namespace boost::explore;
    return ostr << start(L"<=") << separator(L"#") << end(L"=>")
                << assoc_item_start(L"\\") << assoc_item_separator(L"**") << assoc_item_end(L"//");
}

BOOST_AUTO_TEST_CASE_TEMPLATE( basic_vector_custom_format_stream_test, C, test_types )
{
    typename test_traits<C>::stream_type str_out;
    str_out << basic_stream_format;

    std::vector<int> vi;
    str_out << vi;
    BOOST_CHECK_EQUAL(output(str_out), "<==>");

    reset(str_out);

    vi.push_back(1);
    str_out << vi;
    BOOST_CHECK_EQUAL(output(str_out), "<=1=>");

    reset(str_out);

    vi.push_back(2);
    vi.push_back(3);
    str_out << vi;
    BOOST_CHECK_EQUAL(output(str_out), "<=1#2#3=>");

    reset(str_out);

    str_out << boost::explore::make_iterator_range(vi.begin(), ++(++vi.begin()));
    BOOST_CHECK_EQUAL(output(str_out), "<=1#2=>");

    reset(str_out);

    str_out << vi;
    BOOST_CHECK_EQUAL(output(str_out), "<=1#2#3=>");
}

BOOST_AUTO_TEST_CASE_TEMPLATE( basic_map_custom_format_stream_test, C, test_types )
{
    typedef typename test_traits<C>::string_type string_type;
    typename test_traits<C>::stream_type str_out;
    str_out << basic_stream_format;

    std::map<int, string_type> mis;
    str_out << mis;
    BOOST_CHECK_EQUAL(output(str_out), "<==>");

    reset(str_out);

    mis.insert(std::make_pair(1, str_to<C>("first")));
    str_out << mis;
    BOOST_CHECK_EQUAL(output(str_out), "<=\\1**first//=>");

    reset(str_out);

    mis.insert(std::make_pair(2, str_to<C>("second")));
    mis.insert(std::make_pair(3, str_to<C>("third")));

    str_out << mis;
    BOOST_CHECK_EQUAL(output(str_out), "<=\\1**first//#\\2**second//#\\3**third//=>");

    reset(str_out);

    str_out << boost::explore::make_iterator_range(mis.begin(), ++(++mis.begin()));
    BOOST_CHECK_EQUAL(output(str_out), "<=\\1**first//#\\2**second//=>");
}

// safe_test_types: boost test tools have trouble with no intrinsic wchar_t
BOOST_AUTO_TEST_CASE_TEMPLATE( get_sticky_values_test, C, safe_test_types )
{
    using namespace boost::explore;
    typename test_traits<C>::stream_type str_out;

    BOOST_CHECK_EQUAL( get_start(str_out).c_str(),     str_to<C>("[") );
    BOOST_CHECK_EQUAL( get_separator(str_out).c_str(), str_to<C>(", ") );
    BOOST_CHECK_EQUAL( get_end(str_out).c_str(),       str_to<C>("]") );
    
    BOOST_CHECK_EQUAL( get_assoc_item_start(str_out).c_str(),     str_to<C>("") );
    BOOST_CHECK_EQUAL( get_assoc_item_separator(str_out).c_str(), str_to<C>(":") );
    BOOST_CHECK_EQUAL( get_assoc_item_end(str_out).c_str(),       str_to<C>("") );
    
    str_out << basic_stream_format;

    BOOST_CHECK_EQUAL( get_start(str_out).c_str(),     str_to<C>("<=") );
    BOOST_CHECK_EQUAL( get_separator(str_out).c_str(), str_to<C>("#") );
    BOOST_CHECK_EQUAL( get_end(str_out).c_str(),       str_to<C>("=>") );
    
    BOOST_CHECK_EQUAL( get_assoc_item_start(str_out).c_str(),     str_to<C>("\\") );
    BOOST_CHECK_EQUAL( get_assoc_item_separator(str_out).c_str(), str_to<C>("**") );
    BOOST_CHECK_EQUAL( get_assoc_item_end(str_out).c_str(),       str_to<C>("//") );
}

BOOST_AUTO_TEST_CASE_TEMPLATE( begin_end_helper_test, C, test_types )
{
    typename test_traits<C>::stream_type str_out;
    
    std::vector<int> vi;
    vi.push_back(1);
    vi.push_back(2);
    vi.push_back(3);
    str_out << boost::explore::begin_end(str_to<C>("B "), str_to<C>(" E")) << vi;
    BOOST_CHECK_EQUAL(output(str_out), "B 1, 2, 3 E");
}

BOOST_AUTO_TEST_CASE_TEMPLATE( delimeters_helper_test, C, test_types )
{
    typename test_traits<C>::stream_type str_out;
    
    std::vector<int> vi;
    vi.push_back(1);
    vi.push_back(2);
    vi.push_back(3);
    str_out << boost::explore::delimiters(str_to<C>("F "), str_to<C>(" - "), str_to<C>(" L")) << vi;
    BOOST_CHECK_EQUAL(output(str_out), "F 1 - 2 - 3 L");
}


BOOST_AUTO_TEST_CASE_TEMPLATE( assoc_item_begin_end_helper_test, C, test_types )
{
    typename test_traits<C>::stream_type str_out;
    
    std::map<int,int> mii;
    mii.insert( std::make_pair(1,10) );
    mii.insert( std::make_pair(2,20) );
    mii.insert( std::make_pair(3,30) );
    str_out << boost::explore::assoc_item_begin_end(str_to<C>("\\"), str_to<C>("//")) << mii;
    BOOST_CHECK_EQUAL(output(str_out), "[\\1:10//, \\2:20//, \\3:30//]");
}

BOOST_AUTO_TEST_CASE_TEMPLATE( assoc_item_delimeters_helper_test, C, test_types )
{
    typename test_traits<C>::stream_type str_out;
    
    std::map<int,int> mii;
    mii.insert( std::make_pair(1,10) );
    mii.insert( std::make_pair(2,20) );
    mii.insert( std::make_pair(3,30) );
    str_out << boost::explore::assoc_item_delimiters(str_to<C>("\\"), str_to<C>("--"), str_to<C>("//")) << mii;
    BOOST_CHECK_EQUAL(output(str_out), "[\\1--10//, \\2--20//, \\3--30//]");
}