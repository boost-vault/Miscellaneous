#include <vector>
#include <boost/array.hpp>
#include <boost/static_assert.hpp>
#include <boost/mpl/vector.hpp>
#include <boost/mpl/fold.hpp>
#include <d3dx9.h>

#define BOOST_MEM_FN_ENABLE_STDCALL
#include <boost/mem_fn.hpp>
#include <boost/shared_ptr.hpp>

namespace boost
{
	namespace directx
	{
		typedef float float1;
		typedef D3DXVECTOR2 float2;
		typedef D3DXVECTOR3 float3;
		typedef D3DXVECTOR4 float4;
		typedef D3DXMATRIX float4x4;

		namespace uniform_type
		{
			/// each uniform type has a unique and statically-bound type number
			struct number
			{
				enum type
				{
					None = 0,
					Int,
					Bool,
					float1,
					float2,
					float3,
					float4,
					color,
					float2x2,
					float3x3,
					float4x4,
					Texture,
					Sampler,
				};
				int value;
				number(int T = None) : value(T) { }
				friend bool operator==(number A, number B) { return A.value == B.value; }
				friend bool operator<(number A, number B) { return A.value < B.value; }
			};

			/// the traits of a uniform map a C++ type to its const static type number
			template <class T>
			struct Traits;

			template <class T, int N, DWORD D>
			struct TraitsBase
			{
				BOOST_STATIC_CONSTANT(int, TypeNumber = N);
				BOOST_STATIC_CONSTANT(DWORD, DeclType = D);
				typedef T Type;
			};

			#define BOOST_DIRECTX_UNIFORM_TRAITS_NUMBER_DECL(T, N, D) \
				template <> \
					struct Traits<T> : TraitsBase<T, N, D> { }

			#define BOOST_DIRECTX_UNIFORM_TRAITS_NUMBER(T, N) \
				BOOST_DIRECTX_UNIFORM_TRAITS_NUMBER_DECL(T, N, 0)

			#define BOOST_DIRECTX_UNIFORM_TRAITS_DECL(T, D) \
				BOOST_DIRECTX_UNIFORM_TRAITS_NUMBER_DECL(T, number:: T, D)

			#define BOOST_DIRECTX_UNIFORM_TRAITS(T) \
				BOOST_DIRECTX_UNIFORM_TRAITS_NUMBER(T, number:: T)

			BOOST_DIRECTX_UNIFORM_TRAITS_NUMBER(bool, number::Bool);
			BOOST_DIRECTX_UNIFORM_TRAITS_NUMBER(int, number::Int);
			BOOST_DIRECTX_UNIFORM_TRAITS_DECL(float1, D3DDECLTYPE_FLOAT1);
			BOOST_DIRECTX_UNIFORM_TRAITS_DECL(float2, D3DDECLTYPE_FLOAT2);
			BOOST_DIRECTX_UNIFORM_TRAITS_DECL(float3, D3DDECLTYPE_FLOAT3);
			BOOST_DIRECTX_UNIFORM_TRAITS_DECL(float4, D3DDECLTYPE_FLOAT4);
			BOOST_DIRECTX_UNIFORM_TRAITS_NUMBER_DECL(D3DCOLOR, number::color, D3DDECLTYPE_D3DCOLOR);
			BOOST_DIRECTX_UNIFORM_TRAITS(float4x4);
		}

		namespace vertex
		{
			struct declaration
			{
				typedef D3DVERTEXELEMENT9 Element;
				typedef std::vector<Element> Elements;

			private:
				Elements elements;
				std::size_t offset;

			public:
				declaration() : offset(0) {}

				Element const &front() const { return elements.front(); }
				Elements const &get_elements() const { return elements; }
				void add(Element const &element, size_t size = 0)
				{
					elements.push_back(element);
					offset += size;
				}

				template <class T>
				void add(BYTE usage, std::size_t size = sizeof(T), WORD stream = 0, BYTE usage_index = 0)
				{
					Element element;
					element.Method = D3DDECLMETHOD_DEFAULT;
					element.Offset = offset;
					element.Stream = stream;
					element.Type = uniform_type::Traits<T>::DeclType;
					element.Usage = usage;
					element.UsageIndex = usage_index;
					add(element, size);
				}
			};

			template <class Ty = float3>
			struct Position
			{
				Ty position;
				static void AddDecl(declaration &decl)
				{
					decl.add<Ty>(D3DDECLUSAGE_POSITION);
				}
			};
			template < ::size_t N = 1>
			struct Color
			{
				BOOST_STATIC_ASSERT(N > 0);
				boost::array<D3DCOLOR, N> color;
				static void AddDecl(declaration &decl)
				{
					decl.add<D3DCOLOR>(D3DDECLUSAGE_COLOR, N*sizeof(D3DCOLOR));
				}
			};
			template <::size_t N = 1, class Ty = float2>
			struct Texture
			{
				BOOST_STATIC_ASSERT(N > 0);
				boost::array<Ty, N> tex;
				static void AddDecl(declaration &decl)
				{
					decl.add<Ty>(D3DDECLUSAGE_TEXCOORD, N*sizeof(Ty));
				}
			};
			template <::size_t N = 1, class Ty = float2>
			struct Mask
			{
				BOOST_STATIC_ASSERT(N > 0);
				boost::array<Ty, N> mask;
				static void AddDecl(declaration &decl)
				{
					decl.add<Ty>(D3DDECLUSAGE_TEXCOORD, N*sizeof(Ty));
				}
			};
			template <class Ty = float3>
			struct Normal
			{
				Ty normal;
				static void AddDecl(declaration &decl)
				{
					decl.add<Ty>(D3DDECLUSAGE_NORMAL);
				}
			};
			template <class Ty = float4>
			struct Tangent
			{
				Ty tangent;
				static void AddDecl(declaration &decl)
				{
					decl.add<Ty>(D3DDECLUSAGE_TANGENT);
				}
			};

		} // namespace vertex

		namespace detail
		{
			struct Nothing 
			{ 
				static void AddDecl(vertex::declaration &) {}
			};

			struct AddBase
			{
				template <class In, class Add>
				struct BaseVertex : In, Add {};

				template <class In, class T>
				struct apply
				{
					typedef BaseVertex<In, T> type;
				};
			};

			struct AddDeclaration
			{
				template <class In, class Add>
				struct BaseDecl
				{
					static void AddDecl(vertex::declaration &decl)
					{
						In::AddDecl(decl);
						Add::AddDecl(decl);
					}
				};

				template <class In, class T>
				struct apply
				{
					typedef BaseDecl<In, T> type;
				};
			};
			template <class Vec>
			struct make_vertex : boost::mpl::fold<Vec, detail::Nothing, detail::AddBase>::type
			{
				typedef typename boost::mpl::fold<Vec, detail::Nothing, detail::AddDeclaration>::type MakeDecl;
				static vertex::declaration make_decl()
				{
					vertex::declaration decl;
					MakeDecl::AddDecl(decl);
					vertex::declaration::Element end = { 0xFF, 0, D3DDECLTYPE_UNUSED, 0, 0, 0 };
					decl.add(end);
					return decl;
				}
			};

		} // namespace detail

		/// axillary structure to create a vertex structure from a static list of 
		/// components.
		///
		/// the means to create a Direct3D declaration is also generated statically
		#pragma pack(push)
		#pragma pack(1)
		template <
			class T0 = boost::mpl::na
				, class T1 = boost::mpl::na
				, class T2 = boost::mpl::na
				, class T3 = boost::mpl::na
				, class T4 = boost::mpl::na
				, class T5 = boost::mpl::na
				, class T6 = boost::mpl::na
				, class T7 = boost::mpl::na
				, class T8 = boost::mpl::na
		>
		struct make_vertex : detail::make_vertex<boost::mpl::vector<T0,T1,T2,T3,T4,T5,T6,T7,T8> > { };
		#pragma pack(pop)

		/// a com pointer
		template <class Iface>
		struct com_ptr : boost::shared_ptr<Iface>
		{
			typedef boost::shared_ptr<Iface> Parent;
			com_ptr() { }
			com_ptr(Iface *P) : Parent(P, boost::mem_fn(&Iface::Release)) { }
			com_ptr(com_ptr<Iface> const &X) : Parent(X) { }
		};

	} // namespace directx

} // namespace boost

int main()
{
	using namespace boost::directx;
	
	typedef make_vertex<vertex::Position<>, vertex::Normal<>, vertex::Texture<2> > vertex_type;
	
	vertex_type vert;
	vert.position = float3(1,2,3);
	vert.tex[0] = float2(1,2);
	vert.tex[1] = float2(3,4);
	vert.normal = float3(4,5,6);

	vertex::declaration decl = vertex_type::make_decl();
	assert(decl.get_elements().size() == 4);
	assert(decl.get_elements()[0].Type == D3DDECLTYPE_FLOAT3);
	assert(decl.get_elements()[1].Type == D3DDECLTYPE_FLOAT3);
	assert(decl.get_elements()[2].Type == D3DDECLTYPE_FLOAT2);

	return 0;
}

//EOF
