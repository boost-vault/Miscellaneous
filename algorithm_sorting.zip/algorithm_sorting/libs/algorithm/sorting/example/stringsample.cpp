// Distributed under the Boost Software License, Version 1.0.
//    (See accompanying file LICENSE_1_0.txt or copy at
//          http://www.boost.org/LICENSE_1_0.txt)

//  See http://www.boost.org/ for updates, documentation, and revision history.

#include <boost/algorithm/sorting/string_sort.hpp>
#include <time.h>
#include <stdio.h>
#include <stdlib.h>
#include <algorithm>
#include <vector>
#include <iostream>
#include <fstream>
#include <string>
using std::string;
using namespace boost;

#define DATA_TYPE string

//Pass in an argument to test std::sort
int main(int argc, const char ** argv) {
	std::ifstream indata;
	std::ofstream outfile;
	bool stdSort = false;
	unsigned loopCount = 1;
	for(int u = 1; u < argc; ++u) {
		if(std::string(argv[u]) == "-std")
			stdSort = true;
		else
			loopCount = atoi(argv[u]);
	}
	double total = 0.0;
	//Run multiple loops, if requested
	std::vector<DATA_TYPE> array;
	for(unsigned u = 0; u < loopCount; ++u) {
		indata.open("input.txt", std::ios_base::in | std::ios_base::binary);	
		if(indata.bad()) {
			printf("input.txt could not be opened\n");
			return 1;
		}
		DATA_TYPE inval;
		while ( !indata.eof() ) {
			indata >> inval;
			array.push_back(inval);
		}
			
		indata.close();
		clock_t start, end;
		double elapsed;
		start = clock();
		if(stdSort)
			//std::sort(&(array[0]), &(array[0]) + uCount);
			std::sort(array.begin(), array.end());
		else
			//string_sort(&(array[0]), &(array[0]) + uCount);
			string_sort(array.begin(), array.end());
		end = clock();
		elapsed = ((double) (end - start));
		if(stdSort)
			outfile.open("standard_sort_out.txt", std::ios_base::out | std::ios_base::binary | std::ios_base::trunc);
		else
			outfile.open("spread_sort_out.txt", std::ios_base::out | std::ios_base::binary | std::ios_base::trunc);
		if(outfile.good()) {
			for(unsigned u = 0; u < array.size(); ++u)
				outfile << array[u] << "\n";
			outfile.close();
		}
		total += elapsed;
		array.clear();
	}
	if(stdSort)
		printf("std::sort elapsed time %f\n", total / CLOCKS_PER_SEC);
	else
		printf("spreadsort elapsed time %f\n", total / CLOCKS_PER_SEC);
	return 0;
}


