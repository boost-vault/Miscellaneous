#ifndef __COMPREHENSION_FUNCTOR_H__
#define __COMPREHENSION_FUNCTOR_H__

/* Allow use of an arbitrary function object in a comprehension expression
 * or as the source of a value sequence.
 *
 * Copyright (c) 2010-2011 Brent Spillner
 * Distributed under the Boost Software License, Version 1.0. (See accompanying 
 * file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
 */

#include <boost/config.hpp>
#include <boost/function.hpp>
#include <boost/functional.hpp>
#include "value_sequence.hpp"

namespace comprehension {

namespace meta {

// Some ad-hoc extensions to boost::Functional to safely handle nullary functors
template <typename T> struct nullary_traits { };

// Specialization for generic function pointers
template <typename ReturnValue>
struct nullary_traits<ReturnValue()> {
  typedef ReturnValue result_type;
};

// Specialization for boost::function<> values
template <typename ReturnValue>
struct nullary_traits<boost::function<ReturnValue()> > {
  typedef ReturnValue result_type;
};

// Wrapper for boost::unary_traits that will not match a nullary functor
// The _ArgumentTypeHint is unused by default but provided for extensibility to
// polymorphic function objects (e.g. those created by boost::phoenix)
template <typename Functor, typename _ArgumentTypeHint = void>
struct unary_traits {
  typedef typename boost::unary_traits<Functor>::argument_type argument_type;
  typedef typename boost::unary_traits<Functor>::result_type result_type;
};

// Prevent unary traits from being associated with a nullary function pointer
template <typename ReturnValue>
    struct unary_traits<ReturnValue()> { };

// Prevent unary traits from being associated with a nullary boost::function object
template <typename ReturnValue>
    struct unary_traits<boost::function<ReturnValue()> > { };

} // end namespace meta


// Expression that evaluates to the output of an arbitrary nullary function
template <typename OutputValue, bool IsIndefiniteSequence = false>
struct nullary_functor {
  typedef OutputValue evaluates_to;
  typedef nullary_functor<OutputValue, IsIndefiniteSequence> expr_self_type;
  boost::function<OutputValue()> const functor;

  nullary_functor(boost::function<OutputValue()> const &func)
          : functor(func) { /* nothing */ }

  evaluates_to evaluate() const { return functor(); }
  bool next() const { return IsIndefiniteSequence; }

  // Provide the value_sequence interface for use as a generator function
  bool first_value(evaluates_to &dest) const { dest = evaluate(); return true; }
  bool next_value(evaluates_to &dest) const {
      return  IsIndefiniteSequence && first_value(dest);
  }
};

// Specialization: void functors are treated as returning 'true' when
// evaluated within a list of comprehension criteria
template <bool IsIndefiniteSequence>
struct nullary_functor<void, IsIndefiniteSequence> {
  typedef bool evaluates_to;
  typedef nullary_functor<void, IsIndefiniteSequence> expr_self_type;
  boost::function<void()> const functor;

  nullary_functor(boost::function<void()> const &func)
          : functor(func) { /* nothing */ }

  evaluates_to evaluate() const { functor(); return true; }
  bool next() const { return IsIndefiniteSequence; }

  bool first_value(evaluates_to &dest) const { dest = evaluate(); return true; }
  bool next_value(evaluates_to &dest) const {
      return  IsIndefiniteSequence && first_value(dest);
  }
};

namespace meta {

// Traits specialization for comprehension::nullary_functor<>
template <typename OutputValue>
struct nullary_traits<nullary_functor<OutputValue> > {
  typedef OutputValue result_type;
};

} // end namespace meta


// Wrap a nullary function object as an expression
template <class Functor>
nullary_functor< typename meta::nullary_traits<Functor>::result_type >
     call(Functor const &func)
{
  typedef typename meta::nullary_traits<Functor>::result_type result_type;
  return nullary_functor<result_type>((boost::function<result_type ()>) func);
}


// Explicit call() is not required when the functor appears within in a list of
// comprehension criteria (other than at the leftmost position)
template < class Expr, class Functor >
expression_sequence< typename meta::is_expr<Expr>::type,
        nullary_functor<typename meta::nullary_traits<Functor>::result_type> >
    operator,(Expr const &expr, Functor const &func)
{
  typedef typename meta::nullary_traits<Functor>::result_type result_type;
  return expression_sequence<Expr, nullary_functor<result_type> >
             (expr, (boost::function<result_type ()>) func);
}


// Adapt a nullary functor as the generator for a sequence of values
// WARNING: no termination condition; the user MUST be explicitly filling a finite
// range or pass an explicit limit to the comprehender<> object.
template < class Variable, class Functor >
sequential_assignment< typename meta::assignable_expr<Variable>::type,
        nullary_functor<typename meta::nullary_traits<Functor>::result_type, true> >
    operator<<=(Variable &var, Functor const &func)
{
  typedef typename meta::nullary_traits<Functor>::result_type result_type;
  return sequential_assignment< Variable, nullary_functor<result_type, true> >
             (var, (boost::function<result_type ()>) func);
}

// Permit use of any lvalue when the RHS is explicitly a nullary_functor
// Note that single-valued functors are always promoted to sequences when used in <<=
template < class DestT, class OutputType, bool _Ignored >
sequential_assignment< DestT &, nullary_functor<OutputType, true> >
    operator<<=(DestT &var, nullary_functor<OutputType, _Ignored> const &func)
{
  return sequential_assignment< DestT &,
             nullary_functor<OutputType, true> > (var, func.functor);
}


// Expression encapsulating an arbitrary unary function
template <typename InputValue, typename OutputValue, typename ArgExpr1,
          bool IsIndefiniteSequence = false>
struct unary_functor {
  typedef OutputValue evaluates_to;
  typedef unary_functor<InputValue, OutputValue, ArgExpr1,
                        IsIndefiniteSequence> expr_self_type;
  boost::function<OutputValue(InputValue)> const functor;
  ArgExpr1 const &first;

  unary_functor(boost::function<OutputValue(InputValue)> const &func,
                ArgExpr1 const &arg1)
          : functor(func), first(arg1) { /* nothing */ }

  evaluates_to evaluate() const { return functor(first.evaluate()); }
  bool next() const { return IsIndefiniteSequence; }
};

namespace meta {

// Traits specialization for comprehension::unary_functor<>
template <typename InputValue, typename OutputValue, typename Arg1>
struct unary_traits<unary_functor<InputValue, OutputValue, Arg1> > {
  typedef InputValue argument_type;
  typedef OutputValue result_type;
};

} // end namespace meta


// Wrap a unary function object application as an expression
template < class Functor, class ArgExpr1 >
unary_functor< typename meta::unary_traits<Functor,
                   typename ArgExpr1::evaluates_to>::argument_type,
               typename meta::unary_traits<Functor,
                   typename ArgExpr1::evaluates_to>::result_type,
               typename meta::is_expr<ArgExpr1>::type >
     apply(Functor const &func, ArgExpr1 const &arg1)
{
  return unary_functor< typename meta::unary_traits<Functor,
                            typename ArgExpr1::evaluates_to>::argument_type,
                        typename meta::unary_traits<Functor,
                            typename ArgExpr1::evaluates_to>::result_type,
                        ArgExpr1 > (func, arg1);
}

// Specialization for the case where the argument is not an expression type
template < class Functor, class Arg1 >
unary_functor< typename meta::unary_traits<Functor,
                            typename meta::force_to_expr<Arg1>::type::evaluates_to>::argument_type,
               typename meta::unary_traits<Functor,
                            typename meta::force_to_expr<Arg1>::type::evaluates_to>::result_type,
               typename meta::force_to_expr<Arg1>::type >
     apply(Functor const &func, Arg1 const &arg1)
{
  typedef typename meta::force_to_expr<Arg1>::type arg_expr_type;
  typedef typename arg_expr_type::evaluates_to argument_type;
  typedef typename meta::unary_traits<Functor, argument_type>::result_type result_type;
  typedef boost::function<result_type(argument_type)> functor_type;

  return unary_functor< argument_type,
                        result_type,
                        arg_expr_type >((functor_type) func, (arg_expr_type) arg1);
}

} // end namespace comprehension

/* end of __COMPREHENSION_FUNCTOR_H__ */
#endif
