#ifndef __COMPREHENSION_IS_EXPR_H__
#define __COMPREHENSION_IS_EXPR_H__

/* Metaprogramming predicates to test whether a given type is or is not
 * interpretable as an expression.  (Useful in preventing ambiguous operator
 * overloads.)
 *
 * Copyright (c) 2010-2011 Brent Spillner
 * Distributed under the Boost Software License, Version 1.0. (See accompanying 
 * file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
 */

#include <boost/config.hpp>
#include <boost/mpl/if.hpp>
#include <boost/mpl/or.hpp>
#include <boost/mpl/has_xxx.hpp>
#include "expressions.hpp"

namespace comprehension {

namespace meta {

// Provides nested ::type iff the supplied condition is true
template < class T, bool Enable > struct define_if { } ;
template < class T > struct define_if<T, true> { typedef T type; } ;

// Provides nested ::type iff the supplied condition is false
template < class T, bool Enable > struct define_unless { } ;
template < class T > struct define_unless<T, false> { typedef T type; } ;

BOOST_MPL_HAS_XXX_TRAIT_DEF(expr_self_type);
BOOST_MPL_HAS_XXX_TRAIT_DEF(compr_self_type);
BOOST_MPL_HAS_XXX_TRAIT_DEF(iterator);

// Metafunction for which ::type resolves if and only if the parametric
// type provides a nested expr_self_type
template < class T >
struct is_expr : public define_if<T, has_expr_self_type<T>::value > { };

// Metafunction for which ::type resolves if and only if the parametric
// type does /not/ provide a nested expr_self_type
template < class T >
struct not_expr : public define_unless<T, has_expr_self_type<T>::value > { };


// Metafunction for which ::type always resolves to a legal expression type
template < class T >
struct to_expr {
  typedef typename boost::mpl::if_< has_expr_self_type<T>, T,
                                    constant_expression<T> >::type type;
};

// Specialization: pass comprehension_variables with reference semantics
// This allows every instance of a comprehension_variable's name to refer
// to the object, even when used in an rvalue context
template < class Value >
struct to_expr< comprehension_variable<Value> > {
  typedef expression_reference< comprehension_variable<Value> > type;
};

// Specialization: wrap explicit references to non-expression types
template < class Value >
struct to_expr< boost::reference_wrapper<Value> > {
  typedef explicit_reference<Value> type;
};


// Metafunction for which ::type resolves to an expression type if and
// only if the parametric type is not itself an expression
template < class T >
struct force_to_expr : public define_unless< typename meta::to_expr<T>::type,
                                             has_expr_self_type<T>::value > { };


// Metafunction for which ::type resolves to an expression type iff
// either parametric type is an expression
template < class A, class B >
struct either_expr
    : public define_if< typename to_expr<A>::type,
                        boost::mpl::or_< has_expr_self_type<A>,
                                         has_expr_self_type<B> >::value > { };


// Metafunction for which ::type resolves iff the parametric type
// appears to be a container (i.e. provides an ::iterator subtype)
template < class T >
struct is_container : public define_if<T, has_iterator<T>::value > { };

// Metafunction for which ::type resolves iff the parametric type
// does /not/ appear to be a container
template < class T >
struct not_container : public define_unless<T, has_iterator<T>::value > { };


// Metafunction for which ::type resolves iff the parametric type
// is a fully specified comprehension
template < class T >
struct is_comprehension : public define_if<T, has_compr_self_type<T>::value > { };

// Metafunction for which ::type resolves iff the parametric type
// is /not/ a comprehension
template < class T >
struct not_comprehension : public define_unless<T, has_compr_self_type<T>::value > { };


// Metafunction which passes through the first parametric type; useful for
// simultaneous SFINAE on multiple types (nest as needed)
template < class One, class Two = void, class Three = void, class Four = void >
struct return_first { typedef One type; };


// Metafunction for which ::type resolves iff the dependent type is an assignable
// expression
template < class T> struct assignable_expr { };

template <class Dep> struct assignable_expr< comprehension_variable<Dep> > {
  typedef comprehension_variable<Dep> type;
};

template <class Dep> struct assignable_expr< expression_reference<Dep> > {
  typedef expression_reference<Dep> type;
};

template <class Dep> struct assignable_expr< explicit_reference<Dep> > {
  typedef explicit_reference<Dep> type;
};

template <class Var, class Expr> struct assignable_expr< assignment_expr<Var, Expr> > {
  typedef assignment_expr<Var, Expr> type;
};


// Metafunction for which ::type resolves iff we do not risk ambiguity by promoting this
// type to an expression type when it appears as the LHS of a binary operation
// Allowed by default, but can be disabled for things like Boost.Phoenix expressions
template < class T > struct override_ok { typedef T type; };

} // end namespace meta

} // end namespace comprehension

/* end __COMPREHENSION_IS_EXPR_H__ */
#endif
