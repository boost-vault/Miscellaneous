#ifndef __COMPREHENSION_TUPLES_H__
#define __COMPREHENSION_TUPLES_H__

/* Helper types for bundling expressions into boost::tuples
 * (Permits expressions to return multiple values)
 *
 * Copyright (c) 2010-2011 Brent Spillner
 * Distributed under the Boost Software License, Version 1.0. (See accompanying 
 * file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
 */

#include <boost/config.hpp>
#include <boost/tuple/tuple.hpp>
#include "is_expression.hpp"

namespace comprehension {

template <class Value1, class Value2>
class expr_tuple2 {
 private:
  typedef typename meta::to_expr<Value1>::type Expr1;
  typedef typename meta::to_expr<Value2>::type Expr2;
  Expr1 one;
  Expr2 two;
 public:
  typedef expr_tuple2<Value1, Value2> expr_self_type;
  typedef boost::tuple<typename Expr1::evaluates_to,
                       typename Expr2::evaluates_to> evaluates_to;

  expr_tuple2(Expr1 const &v1, Expr2 const &v2)
          : one(v1), two(v2) { /* nothing */ }

  evaluates_to evaluate(void) const {
      return evaluates_to (one.evaluate(), two.evaluate());
  }
};


template <class Value1, class Value2, class Value3>
struct expr_tuple3 {
 private:
  typedef typename meta::to_expr<Value1>::type Expr1;
  typedef typename meta::to_expr<Value2>::type Expr2;
  typedef typename meta::to_expr<Value3>::type Expr3;
 public:
  Expr1 one;
  Expr2 two;
  Expr3 three;
  typedef expr_tuple3<Value1, Value2, Value3> expr_self_type;
  typedef boost::tuple<typename Expr1::evaluates_to,
                       typename Expr2::evaluates_to,
                       typename Expr2::evaluates_to> evaluates_to;

  expr_tuple3(Expr1 const &v1, Expr2 const &v2, Expr3 const &v3)
          : one(v1), two(v2), three(v3) { /* nothing */ }

  evaluates_to evaluate(void) const {
      return evaluates_to (one.evaluate(), two.evaluate(), three.evaluate());
  }
};


template <class Expr1, class Expr2>
expr_tuple2<Expr1, Expr2> make_tuple(Expr1 const &one, Expr2 const &two)
{
  return expr_tuple2<Expr1, Expr2>(one, two);
}


template <class Expr1, class Expr2, class Expr3>
expr_tuple3<Expr1, Expr2, Expr3> make_tuple(Expr1 const &one, Expr2 const &two,
                                            Expr3 const &three)
{
  return expr_tuple3<Expr1, Expr2, Expr3>(one, two, three);
}


} // end namespace comprehension

/* end of __COMPREHENSION_TUPLES_H__ */
#endif
