/* Test/example program for the comprehension library.
 *
 * Copyright (c) 2010-2011 Brent Spillner
 * Distributed under the Boost Software License, Version 1.0. (See accompanying 
 * file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
 */

#include "comprehension.hpp"
#include <iostream>
#include <vector>
#include <boost/lambda/bind.hpp>

using namespace comprehension;


// Demonstrate use of boost::tuple to return multiple values per comprehension step
void pyth_triples(int n)
{
  comprehender _;
  comprehension_variable<int> x, y, z;
  typedef boost::tuple<int, int, int> triple;
  std::vector<triple> triples;

  triples += _(x, y, z)[x <<= range(1, n), y <<= range(x, n), z <<= range(y, n), x*x + y*y == z*z];

  std::cout << "Pythagorean triples with all sides < " << n << std::endl;
  for (int i = 0; i < triples.size(); i++)
      std::cout << triples[i].get<0>() << ' ' << triples[i].get<1>() << ' ' << triples[i].get<2>() << std::endl;
}


int main(int argc, const char *argv[])
{
  pyth_triples(40);
  return 0;
}

