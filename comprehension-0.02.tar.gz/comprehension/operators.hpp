#ifndef __COMPREHENSION_OPERATORS_H__
#define __COMPREHENSION_OPERATORS_H__

/* Overloaded operators for assembling an expression's syntax tree
 *
 * Copyright (c) 2010-2011 Brent Spillner
 * Distributed under the Boost Software License, Version 1.0. (See accompanying 
 * file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
 */

#include "expressions.hpp"
#include "is_expression.hpp"

namespace comprehension {

#define _COMPREHENSION_UNARY_OPERATOR(Name, Op) \
  template <class SubExpr> expression_ ## Name < \
          typename meta::is_expr<SubExpr>::type > \
  operator Op (SubExpr const &expr) { \
      return expression_ ## Name <SubExpr>(expr); \
  }

#define _COMPREHENSION_UNARY_OPERATOR_(Name, Op, DefaultType) \
            _COMPREHENSION_UNARY_OPERATOR(Name, Op)

// Support workaround for GCC decltype issue-- no effect on this file
#define _COMPREHENSION_PROBLEMATIC_UNARY_OPERATOR(Name, Op) \
            _COMPREHENSION_UNARY_OPERATOR(Name, Op)

#define _COMPREHENSION_LVALUE_OPERATOR(Name, Op) \
  template <class SubExpr> expression_ ## Name < \
          typename meta::assignable_expr<SubExpr>::type > \
  operator Op (SubExpr &expr) { \
      return expression_ ## Name <SubExpr>(expr); \
  }

#define _COMPREHENSION_LVALUE_OPERATOR_(Name, Op, DefaultType) \
            _COMPREHENSION_LVALUE_OPERATOR(Name, Op)

#define _COMPREHENSION_POSTFIX_OPERATOR(Name, Op) \
  template <class SubExpr> expression_ ## Name < \
          typename meta::assignable_expr<SubExpr>::type > \
  operator Op (SubExpr &expr, int _unused) { \
      return expression_ ## Name <SubExpr>(expr); \
  }

#define _COMPREHENSION_POSTFIX_OPERATOR_(Name, Op, DefaultType) \
            _COMPREHENSION_POSTFIX_OPERATOR(Name, Op)

#define _COMPREHENSION_BINARY_OPERATOR(Name, Op) \
  template <class LHS, class RHS> expression_ ## Name < \
          typename meta::either_expr<LHS, RHS>::type ::expr_self_type, \
          typename meta::return_first<typename meta::to_expr<RHS>::type, \
                                      typename meta::override_ok<LHS>::type> \
                       ::type ::expr_self_type > \
  operator Op (LHS const &expr1, RHS const &expr2) { \
      return expression_ ## Name <typename meta::to_expr<LHS>::type, \
                                  typename meta::to_expr<RHS>::type>(expr1, expr2); \
  }

#define _COMPREHENSION_BINARY_OPERATOR_(Name, Op, DefaultType) \
            _COMPREHENSION_BINARY_OPERATOR(Name, Op)

// First version covers cases where LHS is already an lvalue implicitly
// convertible to a comprehension expression.
// Second version allows assignment when LHS is an explicit reference to a
// non-expression type and RHS is a comprehension expression.
#define _COMPREHENSION_ASSIGNMENT_OPERATOR(Name, Op) \
  template <class LHS, class RHS> expression_ ## Name < \
          typename meta::assignable_expr<typename meta::either_expr<LHS, RHS>::type>::type, \
          typename meta::to_expr<RHS>::type > \
  operator Op (LHS &expr1, RHS const &expr2) { \
      return expression_ ## Name <typename meta::to_expr<LHS>::type, \
                                  typename meta::to_expr<RHS>::type>(expr1, expr2); \
  } \
  template <class Variable, class RHS> expression_ ## Name < \
          explicit_reference<typename meta::not_expr<Variable>::type>, \
          typename RHS::expr_self_type > \
  operator Op (boost::reference_wrapper<Variable> const &expr1, RHS const &expr2) { \
      return expression_ ## Name <explicit_reference<Variable>, RHS>(explicit_reference<Variable>(expr1), expr2); \
  }

#define _COMPREHENSION_ASSIGNMENT_OPERATOR_(Name, Op, DefaultType) \
            _COMPREHENSION_ASSIGNMENT_OPERATOR(Name, Op)

#include "supported_operators.hpp"

#undef _COMPREHENSION_UNARY_OPERATOR_
#undef _COMPREHENSION_UNARY_OPERATOR
#undef _COMPREHENSION_PROBLEMATIC_UNARY_OPERATOR
#undef _COMPREHENSION_LVALUE_OPERATOR_
#undef _COMPREHENSION_LVALUE_OPERATOR
#undef _COMPREHENSION_POSTFIX_OPERATOR_
#undef _COMPREHENSION_POSTFIX_OPERATOR
#undef _COMPREHENSION_BINARY_OPERATOR_
#undef _COMPREHENSION_BINARY_OPERATOR
#undef _COMPREHENSION_ASSIGNMENT_OPERATOR_
#undef _COMPREHENSION_ASSIGNMENT_OPERATOR

} // end namespace comprehension

/* end __COMPREHENSION_OPERATORS_H__ */
#endif
