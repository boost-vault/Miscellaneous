/* Test/example program for the comprehension library.
 *
 * Copyright (c) 2010-2011 Brent Spillner
 * Distributed under the Boost Software License, Version 1.0. (See accompanying 
 * file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
 */

#include <iostream>
#include <vector>
#include "comprehension.hpp"
#include "phoenix_support.hpp"

using namespace comprehension;
using namespace boost::phoenix;
using namespace boost::phoenix::arg_names;

// Demonstrate the use of lazy operators from the Phoenix library
void evens(int max)
{
  comprehender _;
  comprehension_variable<int> i;

  std::cout << "Even natural numbers < " << max << ":\n";
  std::vector<int> dummy = _(i)[i <<= range(0, max), i % 2 == 0, apply(std::cout << arg1 << ' ', i)];
}


// Demonstrate the use of more complicated Phoenix statements
void factors(int max)
{
  comprehender _;
  int i, j;

  std::cout << "\nFactors:";
  std::vector<int> dummy =
      _(boost::ref(i))[i <<= range(2, max),
                       apply(std::cout << val('\n') << *arg1 << ':', val_(&i)),
                       for_(ref(j) = 2, ref(j) <= ref(i) / 2, ++ref(j)) [
                           if_(ref(i) % ref(j) == val(0)) [
                               std::cout << val(' ') << ref(j)
                           ]
                       ] ];
  std::cout << std::endl;
}


int main(int argc, const char *argv[])
{
  evens(15);
  factors(15);
  return 0;
}

