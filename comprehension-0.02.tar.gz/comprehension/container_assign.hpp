#ifndef __COMPREHENSION_CONTAINER_ASSIGN_H__
#define __COMPREHENSION_CONTAINER_ASSIGN_H__

/* Operators that copy values from a comprehension to a container,
 * or vice versa.
 *
 * Copyright (c) 2010-2011 Brent Spillner
 * Distributed under the Boost Software License, Version 1.0. (See accompanying 
 * file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
 */

#include <boost/config.hpp>
#include "range.hpp"
#include "comprehender.hpp"

namespace comprehension {

// Replace the existing contents of the container, without increasing its capacity
// Does not overwrite the last old items if the source length is less than the
// initial container size!
template < class Container, class Comprehension >
typename meta::return_first<typename meta::is_container<Container>::type,
                            typename meta::is_comprehension<Comprehension>::type>
             ::type & operator<<=(Container &dest, Comprehension source)
{
  typename Comprehension::output_type result;
  typename Container::iterator begin = dest.begin(), end = dest.end();

  if (begin != end && source.generate_first(result)) {
      *begin = result;
      while (++begin != end && source.generate_next(result))
          *begin = result;
  }

  return dest;
}


// Append to a container using push_back until the source is exhausted
template < class Container, class Comprehension >
typename meta::return_first<typename meta::is_container<Container>::type,
                            typename meta::is_comprehension<Comprehension>::type>
             ::type & operator+=(Container &dest, Comprehension source)
{
  typename Comprehension::output_type result;

  if (source.generate_first(result)) {
      dest.push_back(result);
      while (source.generate_next(result))
          dest.push_back(result);
  }

  return dest;
}


} // end namespace comprehension

/* end of __COMPREHENSION_CONTAINER_ASSIGN_H__ */
#endif
