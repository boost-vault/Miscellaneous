#ifndef __COMPREHENSION_H__
#define __COMPREHENSION_H__

/* Top-level header that includes the entirety of the comprehension library.
 *
 * Copyright (c) 2010-2011 Brent Spillner
 * Distributed under the Boost Software License, Version 1.0. (See accompanying 
 * file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
 */

#include <boost/config.hpp>

#include "expressions.hpp"
#include "operators.hpp"
#include "expr_sequence.hpp"
#include "range.hpp"
#include "value_sequence.hpp"
#include "comprehender.hpp"
#include "container_assign.hpp"
#include "iterator_assign.hpp"
#include "functor.hpp"

// Some users may not require this and wish to limit the generated binary size
// (GNU libstdc++ is really bad on this point)
#if !defined(COMPREHENSION_NO_IOSTREAMS)
#include "iostream_support.hpp"
#endif

/* end of __COMPREHENSION_H__ */
#endif
