#ifndef __COMPREHENSION_VALUE_SEQUENCE_H__
#define __COMPREHENSION_VALUE_SEQUENCE_H__

/* Generator functors that assign values from the sequence represented
 * by an iterator, pair of iterators, or STL-compliant container.
 *
 * Copyright (c) 2010-2011 Brent Spillner
 * Distributed under the Boost Software License, Version 1.0. (See accompanying 
 * file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
 */

#include <boost/config.hpp>
#include <iterator>
#include <boost/ref.hpp>
#include "expressions.hpp"

namespace comprehension {

// An expression that assigns the sequence's values in turn to the given variable
// Note that next() and evaluate() have const signatures but do have side effects
// and alter the underlying sequence.
template < class OutputValue, class Sequence >
struct sequential_assignment {
  OutputValue &dest;
  Sequence sequence;
  typedef sequential_assignment<OutputValue, Sequence> expr_self_type;
  typedef bool evaluates_to;

  sequential_assignment(OutputValue &out, Sequence const &s)
          : dest(out), sequence(s) { /* nothing */ }

  bool next(void) { return sequence.next_value(dest); }
  bool evaluate(void) { return sequence.first_value(dest); }
};


// An finite sequence of values represented by two iterators
template <class Iterator >
struct definite_sequence {
  Iterator const begin, end;
  Iterator last;
  typedef typename std::iterator_traits<Iterator>::value_type value_type;
  typedef definite_sequence<Iterator> sequence_type;

  definite_sequence(Iterator const &start, Iterator const &stop)
          : begin(start), end(stop), last(start) { /* nothing */ }

  template <class OutputType> bool first_value(OutputType &v) { 
      if (begin == end)
          return false;
      v = *(last = begin);
      return true;
  }

  template <class OutputType> bool next_value(OutputType &v) { 
      if (last == end || ++last == end)
          return false;
      v = *last;
      return true;
  }
};


// An indefinite sequence of values represented by an iterator pointing to
// the first (use with caution!)
template <class Iterator >
struct indefinite_sequence {
  Iterator const begin;
  Iterator last;
  typedef typename std::iterator_traits<Iterator>::value_type value_type;
  typedef indefinite_sequence<Iterator> sequence_type;

  indefinite_sequence(Iterator const &start)
          : begin(start), last(start) { /* nothing */ }

  template <class OutputType> bool first_value(OutputType &v) { 
      v = *(last = begin);
      return true;
  }

  template <class OutputType> bool next_value(OutputType &v) { 
      v = *++last;
      return true;
  }
};



// Generate a definite_sequence object
template < class Iterator >
definite_sequence< Iterator >
    sequence(Iterator const &start, Iterator const &stop)
{
  return definite_sequence<Iterator>(start, stop);
}


// Generate an indefinite_sequence object
template < class Iterator >
indefinite_sequence< Iterator >
    sequence(Iterator const &start)
{
  return indefinite_sequence<Iterator>(start);
}


// Create a generator that sequentially assigns the values in a given range
// to the provided comprehension_variable
template < class DestT, class Sequence >
sequential_assignment< comprehension_variable<DestT>, typename Sequence::sequence_type >
    operator<<=(comprehension_variable<DestT> &var, Sequence const &seq)
{
  return sequential_assignment<comprehension_variable<DestT>, Sequence >(var, seq);
}

// Allow assignment to an expression reference even in a const context
// (not yet used in the library, but potentially part of a future refactoring)
template < class DestT, class Sequence >
sequential_assignment< expression_reference<DestT>, typename Sequence::sequence_type >
    operator<<=(expression_reference<DestT> const &var, Sequence const &seq)
{
  return sequential_assignment<expression_reference<DestT>, Sequence >(var, seq);
}

// Allow assignment to other lvalue references for interoperability with boost::ref
template < class DestT, class Sequence >
sequential_assignment< DestT, typename Sequence::sequence_type >
    operator<<=(DestT &var, Sequence const &seq)
{
  return sequential_assignment< DestT, Sequence >(var, seq);
}

// Automatically create a generator expression from an arbitrary container type
// when the LHS is explicitly a comprehension_variable<>
template < class DestT, class Container >
sequential_assignment< comprehension_variable<DestT>,
                       definite_sequence<typename Container::const_iterator> >
    operator<<=(comprehension_variable<DestT> &var, Container const &container)
{
  return sequential_assignment<comprehension_variable<DestT>,
                               definite_sequence<typename Container::const_iterator> >
             (var, sequence(container.begin(), container.end()));
}


// Adapt one comprehension to function as a value sequence within
// another comprehension
template <class Comprehension >
struct nested_sequence {
  Comprehension comp;
  typedef typename Comprehension::output_type value_type;
  typedef nested_sequence<Comprehension> sequence_type;

  nested_sequence(Comprehension const &nested)
          : comp(nested) { /* nothing */ }

  template <class OutputType> bool first_value(OutputType &v) { 
      value_type tmp;
      if (comp.generate_first(tmp)) {
         v = tmp;
         return true;
      } else
         return false;
  }

  template <class OutputType> bool next_value(OutputType &v) { 
      value_type tmp;
      if (comp.generate_next(tmp)) {
         v = tmp;
         return true;
      } else
         return false;
  }
};


// Allow use of a nested comprehension when the LHS of the sequential assignment
// is a comprehension_variable<>.  Auto-promotion for other lvalues is not provided
// in order to minimize the risk of misusing a top-level comprehension expression.
template < class DestT, class Comprehension >
sequential_assignment< comprehension_variable<DestT>,
        nested_sequence<typename meta::is_comprehension<Comprehension>::type> >
    operator<<=(comprehension_variable<DestT> &var, Comprehension const &nested)
{
  return sequential_assignment<comprehension_variable<DestT>,
                               nested_sequence<Comprehension> >
             (var, nested);
}

} // end namespace comprehension

/* end of __COMPREHENSION_VALUE_SEQUENCE_H__ */
#endif
