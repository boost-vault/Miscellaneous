#ifndef __COMPREHENSION_EXPR_SEQUENCE_H__
#define __COMPREHENSION_EXPR_SEQUENCE_H__

/* Encapsulation of a serial sequence of comprehension expressions.
 *
 * Copyright (c) 2010-2011 Brent Spillner
 * Distributed under the Boost Software License, Version 1.0. (See accompanying 
 * file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
 */

#include <boost/config.hpp>
#include "expressions.hpp"

namespace comprehension {

// A serial sequence of expressions, which evaluates to true for every set of
// variable bindings for which each subexpression evaluates to a non-false value
template <class Expr1, class Expr2>
struct expression_sequence {
  Expr1 lhs;
  Expr2 rhs;
  typedef expression_sequence<Expr1, Expr2> expr_self_type;
  typedef bool evaluates_to;

  expression_sequence(Expr1 const &one, Expr2 const &two)
          : lhs(one), rhs(two) { /* nothing */ }

  // True iff there is another set of bindings for which all subexpressions hold
  bool next(void) {
    if (rhs.next())
        return true;
    while (lhs.next())
        if (rhs.evaluate())
            return true;
    return false;
  }

  // Find the first set of bindings for which all subexpressions hold
  bool evaluate(void) {
    if (!lhs.evaluate())
        return false;
    do {
        if (rhs.evaluate())
            return true;
    } while (lhs.next());
    return false;
  }
};


// Chain together an arbitrary series of expressions
template < class LHS, class RHS >
expression_sequence< typename meta::is_expr<LHS>::type,
                     typename meta::is_expr<RHS>::type >
    operator,(LHS const &expr1, RHS const &expr2)
{
  return expression_sequence<LHS, RHS>(expr1, expr2);
}


} // end namespace comprehension

/* end of __COMPREHENSION_EXPR_SEQUENCE_H__ */
#endif
