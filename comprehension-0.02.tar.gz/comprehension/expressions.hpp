#ifndef __COMPREHENSION_EXPRESSIONS_H__
#define __COMPREHENSION_EXPRESSIONS_H__

/* Types permitting expression evaluation within a
 * list comprehension.
 *
 * Copyright (c) 2010-2011 Brent Spillner
 * Distributed under the Boost Software License, Version 1.0. (See accompanying 
 * file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
 */

#include <boost/config.hpp>
#include <boost/ref.hpp>
#include "workarounds.hpp"

#if !defined(BOOST_HAS_DECLTYPE) && COMPREHENSION_USE_BOOST_TYPEOF
  #include <boost/typeof/typeof.hpp>
#endif

namespace comprehension {

// Metafunction for which ::type evaluates to a default-constructible type
template < class T> struct constructible_value { typedef T type; };
template < class T> struct constructible_value<T &> { typedef T type; };
template < class T> struct constructible_value<boost::reference_wrapper<T> > { typedef T type; };

// Base type for the family of expressions that represent only a single value
// (as opposed to generators that sequentially take on each in a series of values)
struct primitive_expression {
  bool next(void) const { return false; }
};


// An expression that always evaluates to the given value
template <typename Value>
struct constant_expression : public primitive_expression {
  typedef constant_expression<Value> expr_self_type;
  typedef typename constructible_value<Value>::type evaluates_to;
  Value const value;

  constant_expression(Value const &v) : value(v) { /* nothing */ }

  evaluates_to evaluate(void) const { return value; }
  operator evaluates_to const &() { return value; }
};


// Helper function to package an arbitrary value as a constant_expression
// This is technically redundant with boost::lambda::constant and may be removed
// for the final version
template <typename Value>
constant_expression<Value> val_(Value const &v)
{
  return constant_expression<Value>(v);
}


// Lazily-evaluated assignment statement
template <class Variable, class Expr>
struct assignment_expr : public primitive_expression {
  typedef assignment_expr<Variable, Expr> expr_self_type;
  typedef typename Variable::evaluates_to evaluates_to;
  Variable &var;
  Expr expr;

  assignment_expr(Variable &v, Expr const &e) : var(v), expr(e) { /* nothing */ }

  // NOTE: self-assignment would be inefficient but correct
  evaluates_to evaluate(void) const { return var = expr.evaluate(); }
  evaluates_to & access(void) { return (var = expr.evaluate()).access(); }
  operator Variable & () { return var = expr.evaluate(); }
  operator evaluates_to const & () { return var = expr.evaluate(); }
};


// Representation of a placeholder variable within the list comprehension
// Acts as an expression that evaluates to the last value assigned to this variable
template <typename Value>
struct comprehension_variable : public primitive_expression {
  typedef comprehension_variable<Value> expr_self_type;
  typedef typename constructible_value<Value>::type evaluates_to;
  Value value;

  // WARNING: no-argument constructor leaves 'value' uninitialized; this is OK
  // for the typical use pattern (assigned via <<= within the comprehension),
  // allows us to wrap types that don't have a conversion from the literal 0,
  // and prevents inadvertent misconstruction of reference wrappers
  comprehension_variable(void) { /* nothing */ }

  // Passes by value to allow construction when the wrapped type is a reference.
  // Compiler will likely ellide the copy when invoked with a value type.
  comprehension_variable(Value v) : value(v) { /* nothing */ }

  evaluates_to evaluate(void) const { return value; }
  evaluates_to & access(void) { return value; }
  operator evaluates_to const &() { return value; }

  // Assign a new constant value to this variable
  expr_self_type & operator=(evaluates_to const &v) { value = v; return *this; }

  // Define the value of this variable as that of a lazily-evaluated subexpression
  template <class RHSExpr> assignment_expr<expr_self_type,
                                        typename RHSExpr::expr_self_type>
      operator=(RHSExpr const &expr) {
        return assignment_expr<expr_self_type, RHSExpr>(*this, expr); }
};


// Encapsulate a reference to another expression.
// Permits reference semantics for comprehension_variables that do not
// already wrap reference types
template <typename Expr>
struct expression_reference : public primitive_expression {
  typedef expression_reference<Expr> expr_self_type;
  typedef typename Expr::evaluates_to evaluates_to;
  Expr &expr;

  expression_reference(Expr &e) : expr(e) { /* nothing */ }

  // WART: assigns lvalue semantics to comprehension_variable handles obtained
  // in an rvalue context.  This is safe in the normal usage case, where all
  // comprehension_variables are in scope throughout the comprehension.
  // THIS WILL BLOW UP if the user is declaring anonymous comprehension_variables
  // within comprehension expressions (not easy to do, fortunately.)
  template <typename Value>
  expression_reference(comprehension_variable<Value> const &e)
          : expr(const_cast<Expr &>(e)) { /* nothing */ }

  evaluates_to evaluate(void) const { return expr.evaluate(); }
  evaluates_to & access(void) { return expr.access(); }
  expr_self_type & operator=(evaluates_to const &v) { expr = v; return *this; }

  // Define the value of the referenced variable as that of a lazily-evaluated subexpression
  template <class RHSExpr> assignment_expr<expr_self_type,
                                        typename RHSExpr::expr_self_type>
      operator=(RHSExpr const &expr) {
        return assignment_expr<expr_self_type, RHSExpr>(*this, expr); }
};


// Encapsulate a reference represented by a Boost.Ref object
// Since these are often passed in with const semantics (e.g. as the return
// value from boost::ref()), a separate type is cleaner than shoehorning them into
// the ordinary expression_reference<> class via a const_cast<>
template <typename Value>
struct explicit_reference : public primitive_expression {
  typedef explicit_reference<Value> expr_self_type;
  typedef Value evaluates_to;
  boost::reference_wrapper<Value> value;

  explicit_reference(boost::reference_wrapper<Value> const &v) : value(v) { /* nothing */ }

  evaluates_to evaluate(void) const { return value; }
  evaluates_to & access(void) { return value; }
  expr_self_type & operator=(evaluates_to const &v) { value = v; return *this; }

  // Define the value of the referenced variable as that of a lazily-evaluated subexpression
  template <class RHSExpr> assignment_expr<expr_self_type,
                                        typename RHSExpr::expr_self_type>
      operator=(RHSExpr const &expr) {
        return assignment_expr<expr_self_type, RHSExpr>(*this, expr); }
};


#ifdef BOOST_HAS_DECLTYPE
  #define _COMPREHENSION_DECLTYPE(Expr, Default) decltype(Expr)
#elif COMPREHENSION_USE_BOOST_TYPEOF
  #define _COMPREHENSION_DECLTYPE(Expr, Default) BOOST_TYPEOF(Expr)
#else
  #define _COMPREHENSION_DECLTYPE(Expr, Default) Default
#endif


// Representation of a unary expression with no side effects
#define _COMPREHENSION_UNARY_OPERATOR_(Name, Op, DefaultType) \
  template <class SubExpr> struct expression_ ## Name : public primitive_expression { \
      SubExpr sub; \
      typedef  _COMPREHENSION_DECLTYPE(Op sub.evaluate(), DefaultType) evaluates_to; \
      typedef expression_ ## Name<SubExpr> expr_self_type; \
      expression_ ## Name (SubExpr const &arg) : sub(arg) { } \
      evaluates_to evaluate(void) const { return Op sub.evaluate(); } \
  };

// Unless otherwise specified, assume operand type is preserved when decltype is not available
#define _COMPREHENSION_UNARY_OPERATOR(Name, Op) \
  _COMPREHENSION_UNARY_OPERATOR_(Name, Op, typename SubExpr::evaluates_to)

// Handle operators that decltype() cannot (e.g. ~ on most versions of GCC)
#if defined(BOOST_HAS_DECLTYPE) && WORKAROUND_DECLTYPE_UNARY_OP_BUGS
  #define _COMPREHENSION_PROBLEMATIC_UNARY_OPERATOR(Name, Op) \
      template <class SubExpr> struct expression_ ## Name : public primitive_expression { \
          SubExpr sub; \
          typedef typename SubExpr::evaluates_to evaluates_to; \
          typedef expression_ ## Name<SubExpr> expr_self_type; \
          expression_ ## Name (SubExpr const &arg) : sub(arg) { } \
          evaluates_to evaluate(void) const { return Op sub.evaluate(); } \
      };
#else
  #define _COMPREHENSION_PROBLEMATIC_UNARY_OPERATOR(Name, Op) \
              _COMPREHENSION_UNARY_OPERATOR(Name, Op)
#endif

// Representation of a unary expression that requires an lvalue operand (e.g. to modify it or
// take its address)
#define _COMPREHENSION_LVALUE_OPERATOR_(Name, Op, DefaultType) \
  template <class SubExpr> struct expression_ ## Name : public primitive_expression { \
      SubExpr &sub; \
      typedef  _COMPREHENSION_DECLTYPE(Op sub.access(), DefaultType) evaluates_to; \
      typedef expression_ ## Name<SubExpr> expr_self_type; \
      expression_ ## Name (SubExpr &arg) : sub(arg) { } \
      evaluates_to evaluate(void) { return Op sub.access(); } \
      evaluates_to & access(void) { return Op sub.access(); } \
 };

// Unless otherwise specified, assume operand type is preserved when decltype is not available
#define _COMPREHENSION_LVALUE_OPERATOR(Name, Op) \
  _COMPREHENSION_LVALUE_OPERATOR_(Name, Op, typename SubExpr::evaluates_to)


// Representation of a unary postfix expression (i.e. ++ or --) requiring an lvalue operand
#define _COMPREHENSION_POSTFIX_OPERATOR_(Name, Op, DefaultType) \
  template <class SubExpr> struct expression_ ## Name : public primitive_expression { \
      SubExpr &sub; \
      typedef  _COMPREHENSION_DECLTYPE(sub.access() Op, DefaultType) evaluates_to; \
      typedef expression_ ## Name<SubExpr> expr_self_type; \
      expression_ ## Name (SubExpr &arg) : sub(arg) { } \
      evaluates_to evaluate(void) { return sub.access() Op; } \
      evaluates_to & access(void) { return sub.access() Op; } \
 };

// Unless otherwise specified, assume operand type is preserved when decltype is not available
#define _COMPREHENSION_POSTFIX_OPERATOR(Name, Op) \
  _COMPREHENSION_POSTFIX_OPERATOR_(Name, Op, typename SubExpr::evaluates_to)


// Representation of a binary expression with no side effects
#define _COMPREHENSION_BINARY_OPERATOR_(Name, Op, DefaultType) \
  template <class Expr1, class Expr2> struct expression_ ## Name : public primitive_expression { \
      Expr1 lhs;  Expr2 rhs; \
      typedef  _COMPREHENSION_DECLTYPE(lhs.evaluate() Op rhs.evaluate(), DefaultType) evaluates_to; \
      typedef expression_ ## Name<Expr1, Expr2> expr_self_type; \
      expression_ ## Name (Expr1 const &one, Expr2 const &two) : lhs(one), rhs(two) { } \
      evaluates_to evaluate(void) const { return lhs.evaluate() Op rhs.evaluate(); } \
  };

// Unless otherwise specified, assume the first operand's type is preserved when decltype is not available
#define _COMPREHENSION_BINARY_OPERATOR(Name, Op) \
  _COMPREHENSION_BINARY_OPERATOR_(Name, Op, typename Expr1::evaluates_to)


// Representation of a binary expression that modifies its left operand
#define _COMPREHENSION_ASSIGNMENT_OPERATOR_(Name, Op, DefaultType) \
  template <class Expr1, class Expr2> struct expression_ ## Name : public primitive_expression { \
      Expr1 lhs;  Expr2 rhs; \
      typedef  _COMPREHENSION_DECLTYPE(lhs.access() Op rhs.evaluate(), bool) evaluates_to; \
      typedef expression_ ## Name<Expr1, Expr2> expr_self_type; \
      expression_ ## Name (Expr1 const &one, Expr2 const &two) : lhs(one), rhs(two) { } \
      evaluates_to evaluate(void) { return lhs.access() Op rhs.evaluate(); } \
      evaluates_to & access(void) { return lhs.access() Op rhs.evaluate(); } \
  };

// Unless otherwise specified, assume the first operand's type is preserved when decltype is not available
#define _COMPREHENSION_ASSIGNMENT_OPERATOR(Name, Op) \
  _COMPREHENSION_ASSIGNMENT_OPERATOR_(Name, Op, typename Expr1::evaluates_to)

#include "supported_operators.hpp"

#undef _COMPREHENSION_DECLTYPE
#undef _COMPREHENSION_UNARY_OPERATOR_
#undef _COMPREHENSION_UNARY_OPERATOR
#undef _COMPREHENSION_PROBLEMATIC_UNARY_OPERATOR
#undef _COMPREHENSION_LVALUE_OPERATOR_
#undef _COMPREHENSION_LVALUE_OPERATOR
#undef _COMPREHENSION_POSTFIX_OPERATOR_
#undef _COMPREHENSION_POSTFIX_OPERATOR
#undef _COMPREHENSION_BINARY_OPERATOR_
#undef _COMPREHENSION_BINARY_OPERATOR
#undef _COMPREHENSION_ASSIGNMENT_OPERATOR_
#undef _COMPREHENSION_ASSIGNMENT_OPERATOR

} // end namespace comprehension

/* end of __COMPREHENSION_EXPRESSIONS_H__ */
#endif
