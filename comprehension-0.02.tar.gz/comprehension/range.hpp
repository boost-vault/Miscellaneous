#ifndef __COMPREHENSION_RANGE_H__
#define __COMPREHENSION_RANGE_H__

/* Generator functors that represent a finite value range.
 *
 * Copyright (c) 2010-2011 Brent Spillner
 * Distributed under the Boost Software License, Version 1.0. (See accompanying 
 * file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
 */

#include <boost/config.hpp>
#include <boost/ref.hpp>
#include "expressions.hpp"

namespace comprehension {

// Note that next() and evaluate() appear const but may have a side effect
// (updating the value bound to the destination variable)
template <class OutputValue, class RangeSpec >
struct comprehension_range {
  OutputValue &dest;
  typename RangeSpec::value_type memo;
  RangeSpec range;
  typedef comprehension_range<OutputValue, RangeSpec> expr_self_type;
  typedef bool evaluates_to;

  comprehension_range(OutputValue &out, RangeSpec const &r)
          : dest(out), range(r) { /* nothing */ }

  bool next(void) {
    memo = range.next_value(memo);
    if (range.within_range(memo)) {
        dest = memo;
        return true;
    } else
        return false;
  }

  bool evaluate(void) {
    memo = range.first_value();
    if (range.within_range(memo)) {
        dest = memo;
        return true;
    } else
        return false;
  }
};


// A range of consecutive values
template <class BaseExpr, class LimitExpr >
struct compact_range_spec {
  BaseExpr base;
  LimitExpr limit;
  typedef typename BaseExpr::evaluates_to value_type;
  typedef compact_range_spec<BaseExpr, LimitExpr> range_type;

  compact_range_spec(BaseExpr const &start, LimitExpr const &stop)
          : base(start), limit(stop) { /* nothing */ }

  value_type first_value(void) const { return base.evaluate(); }
  value_type next_value(value_type v) const { return ++v; }
  bool within_range(value_type const &v) const { return v < limit.evaluate(); }
};


// A range of values separated by an arbitrary step value
template < class BaseExpr, class LimitExpr, class StepExpr >
struct sparse_range_spec : public compact_range_spec<BaseExpr, LimitExpr> {
  StepExpr delta;
  typedef typename BaseExpr::evaluates_to value_type;
  typedef sparse_range_spec<BaseExpr, LimitExpr, StepExpr> range_type;

  sparse_range_spec(BaseExpr const &start, LimitExpr const &stop,
                    StepExpr const &step)
          : compact_range_spec<BaseExpr, LimitExpr>(start, stop), delta(step)
      { /* nothing */ }

  value_type next_value(value_type const &v) const { return v + delta.evaluate(); }
};


// Generate a compact_range_spec object
template < class First, class Second >
compact_range_spec< typename meta::to_expr<First>::type,
                    typename meta::to_expr<Second>::type >
    range(First const &start, Second const &stop)
{
  return compact_range_spec< typename meta::to_expr<First>::type,
                             typename meta::to_expr<Second>::type >(start, stop);
}


// Generate a sparse_range_spec object
template < class First, class Second, class Third >
sparse_range_spec< typename meta::to_expr<First>::type,
                   typename meta::to_expr<Second>::type,
                   typename meta::to_expr<Third>::type >
    range(First const &start, Second const &stop, Third const &step)
{
  return sparse_range_spec< typename meta::to_expr<First>::type,
                            typename meta::to_expr<Second>::type,
                            typename meta::to_expr<Third>::type >(start, stop, step);
}


// Create a generator that sequentially assigns the values in a given range
// to the provided comprehension_variable
template < class DestT, class Range >
comprehension_range< comprehension_variable<DestT>, typename Range::range_type >
    operator<<=(comprehension_variable<DestT> &var, Range const &rng)
{
  return comprehension_range<comprehension_variable<DestT>, Range >(var, rng);
}

// Allow assignment to an expression reference even in a const context
// (not yet used in the library, but potentially part of a future refactoring)
template < class DestT, class Range >
comprehension_range< expression_reference<DestT>, typename Range::range_type >
    operator<<=(expression_reference<DestT> const &var, Range const &rng)
{
  return comprehension_range< expression_reference<DestT>, Range >(var, rng);
}

// Allow assignment to other lvalue references for interoperability with boost::ref
template < class DestT, class Range >
comprehension_range< DestT, typename Range::range_type >
    operator<<=(DestT &var, Range const &rng)
{
  return comprehension_range< DestT, Range >(var, rng);
}


} // end namespace comprehension

/* end of __COMPREHENSION_RANGE_H__ */
#endif
