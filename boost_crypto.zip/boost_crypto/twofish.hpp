#ifndef BOOST_CRYPTO_TWOFISH_HPP_INCLUDED
#define BOOST_CRYPTO_TWOFISH_HPP_INCLUDED
#         
#include "crypto.hpp"
#include "crypto_endian.hpp"
#include "crypto_rotation.hpp"
#
#include <boost/cstdint.hpp>



#define CALC_K_2(a, b, c, d, j) \
	mds[0][q0[a ^ ik[(j) + 8]] ^ ik[j]] \
	^ mds[1][q0[b ^ ik[(j) + 9]] ^ ik[(j) + 1]] \
	^ mds[2][q1[c ^ ik[(j) + 10]] ^ ik[(j) + 2]] \
	^ mds[3][q1[d ^ ik[(j) + 11]] ^ ik[(j) + 3]]

#define CALC_K(a, j, k, l, m, n) \
	x = CALC_K_2 (k, l, k, l, 0); \
	y = CALC_K_2 (m, n, m, n, 4); \
	y = BOOST_ROL32(y, 8); \
	x += y; y += x; a[j] = x; \
	a[(j) + 1] = BOOST_ROL32(y, 9)

#define CALC_S(a, b, c, d, i, w, x, y, z) \
	if (ik[i]) { \
	tmp = poly_to_exp[ik[i] - 1]; \
	(a) ^= exp_to_poly[tmp + (w)]; \
	(b) ^= exp_to_poly[tmp + (x)]; \
	(c) ^= exp_to_poly[tmp + (y)]; \
	(d) ^= exp_to_poly[tmp + (z)]; \
	}

#define CALC_SB_2(i, a, b) \
	m_s[0][i] = mds[0][q0[(a) ^ sa] ^ se]; \
	m_s[1][i] = mds[1][q0[(b) ^ sb] ^ sf]; \
	m_s[2][i] = mds[2][q1[(a) ^ sc] ^ sg]; \
	m_s[3][i] = mds[3][q1[(b) ^ sd] ^ sh]

#define CALC_SB256_2(i, a, b) \
	m_s[0][i] = mds[0][q0[q0[q1[(b) ^ sa] ^ se] ^ si] ^ sm]; \
	m_s[1][i] = mds[1][q0[q1[q1[(a) ^ sb] ^ sf] ^ sj] ^ sn]; \
	m_s[2][i] = mds[2][q1[q0[q0[(a) ^ sc] ^ sg] ^ sk] ^ so]; \
	m_s[3][i] = mds[3][q1[q1[q0[(b) ^ sd] ^ sh] ^ sl] ^ sp];

#define CALC_K192_2(a, b, c, d, j) \
	CALC_K_2 (q0[a ^ ik[(j) + 16]], \
	q1[b ^ ik[(j) + 17]], \
	q0[c ^ ik[(j) + 18]], \
	q1[d ^ ik[(j) + 19]], j)

#define CALC_K192(a, j, k, l, m, n) \
	x = CALC_K192_2 (l, l, k, k, 0); \
	y = CALC_K192_2 (n, n, m, m, 4); \
	y = BOOST_ROL32(y, 8); \
	x += y; y += x; ctx->a[j] = x; \
	ctx->a[(j) + 1] = BOOST_ROL32(y, 9)

#define CALC_K256_2(a, b, j) \
	CALC_K192_2 (q1[b ^ ik[(j) + 24]], \
	q1[a ^ ik[(j) + 25]], \
	q0[a ^ ik[(j) + 26]], \
	q0[b ^ ik[(j) + 27]], j)

#define CALC_K256(a, j, k, l, m, n) \
	x = CALC_K256_2 (k, l, 0); \
	y = CALC_K256_2 (m, n, 4); \
	y = BOOST_ROL32(y, 8); \
	x += y; y += x; a[j] = x; \
	a[(j) + 1] = BOOST_ROL32(y, 9)

#define G1(a) \
	(m_s[0][(a)         & 0xFF]) ^ (m_s[1][((a) >> 8) & 0xFF]) ^\
	(m_s[2][((a) >> 16) & 0xFF]) ^ (m_s[3][(a) >> 24        ])

#define G2(b) \
	(m_s[1][(b)         & 0xFF]) ^ (m_s[2][((b) >> 8) & 0xFF]) ^\
	(m_s[3][((b) >> 16) & 0xFF]) ^ (m_s[0][(b) >> 24        ])

#define ENCROUND(n, a, b, c, d) \
	x = G1 (a); y = G2 (b); \
	x += y; y += x + m_k[2 * (n) + 1]; \
	(c) ^= x + m_k[2 * (n)]; \
	(c) = BOOST_ROR32((c), 1); \
	(d) = BOOST_ROL32((d), 1) ^ y

#define DECROUND(n, a, b, c, d) \
	x = G1 (a); y = G2 (b); \
	x += y; y += x; \
	(d) ^= y + m_k[2 * (n) + 1]; \
	(d) = BOOST_ROR32((d), 1); \
	(c) = BOOST_ROL32((c), 1); \
	(c) ^= (x + m_k[2 * (n)])

#define ENCCYCLE(n) \
	ENCROUND (2 * (n), a, b, c, d); \
	ENCROUND (2 * (n) + 1, c, d, a, b)

#define DECCYCLE(n) \
	DECROUND (2 * (n) + 1, c, d, a, b); \
	DECROUND (2 * (n), a, b, c, d)

#define INPACK(ptr, n, x, m) \
	x = endian::read_le(((uint32_t*)ptr) + n) ^ m_w[m]

#define OUTUNPACK(ptr,n, x, m) \
	x ^= m_w[m]; \
	endian::write_le(((uint32_t*)ptr) + n, x)

namespace boost {
	namespace crypto {
		namespace detail {
			namespace twofish {
				// TODO:
#				define UINT32_C(x) x ## UL
				extern constexpr uint8_t q0[256];
				extern constexpr uint8_t q1[256];
				extern constexpr uint32_t mds[4][256];
				extern constexpr uint8_t poly_to_exp[255];
				extern constexpr uint8_t exp_to_poly[492];
				extern constexpr uint8_t calc_sb_tbl[512];
			} // namespace boost::crypto::detail::twofish
		} // namespace boost::crypto::detail

		
		template<size_t NR>
		class twofish_cipher;

		template<>
		class twofish_cipher<16>
		{
		public:
			typedef byte_t value_type;
			typedef size_t size_type;

			static constexpr size_type min_key_size = 4;
			static constexpr size_type max_key_size = 32;
			static constexpr size_type block_size   = 16;
			static constexpr size_type rounds       = 16;
			static constexpr char*  name() { return "Twofish"; }
		private:
			bool			m_initialise;
			uint8_t		m_k[32];
			uint32_t	m_s[4][256];
			uint32_t	m_w[8];
		public:

			twofish_cipher()
				:
			m_initialise(false)
			{
			}

			twofish_cipher(const void* key, size_t key_size)
			{
				setkey(key, key_size);
			}

			constexpr void setkey(const void* key, size_t key_size) throw (std::length_error)
			{
				if(!(min_key_size <= key_size && key_size <= max_key_size))
					throw std::length_error(std::string("twofish_cipher::setkey() : invalid key size"));

				using namespace detail::twofish;

				m_initialise = true;
				int i, j, k;
				const uint8_t *ik = (const uint8_t *)key;
				register uint32_t x, y;
				register uint8_t sa = 0, sb = 0, sc = 0, sd = 0, se = 0, sf = 0, sg = 0, sh = 0;
				register uint8_t si = 0, sj = 0, sk = 0, sl = 0, sm = 0, sn = 0, so = 0, sp = 0;
				uint8_t tmp;				

				CALC_S (sa, sb, sc, sd, 0 , 0x00, 0x2D, 0x01, 0x2D); /* 01 A4 02 A4 */
				CALC_S (sa, sb, sc, sd, 1 , 0x2D, 0xA4, 0x44, 0x8A); /* A4 56 A1 55 */
				CALC_S (sa, sb, sc, sd, 2 , 0x8A, 0xD5, 0xBF, 0xD1); /* 55 82 FC 87 */
				CALC_S (sa, sb, sc, sd, 3 , 0xD1, 0x7F, 0x3D, 0x99); /* 87 F3 C1 5A */
				CALC_S (sa, sb, sc, sd, 4 , 0x99, 0x46, 0x66, 0x96); /* 5A 1E 47 58 */
				CALC_S (sa, sb, sc, sd, 5 , 0x96, 0x3C, 0x5B, 0xED); /* 58 C6 AE DB */
				CALC_S (sa, sb, sc, sd, 6 , 0xED, 0x37, 0x4F, 0xE0); /* DB 68 3D 9E */
				CALC_S (sa, sb, sc, sd, 7 , 0xE0, 0xD0, 0x8C, 0x17); /* 9E E5 19 03 */
				CALC_S (se, sf, sg, sh, 8 , 0x00, 0x2D, 0x01, 0x2D); /* 01 A4 02 A4 */
				CALC_S (se, sf, sg, sh, 9 , 0x2D, 0xA4, 0x44, 0x8A); /* A4 56 A1 55 */
				CALC_S (se, sf, sg, sh, 10, 0x8A, 0xD5, 0xBF, 0xD1); /* 55 82 FC 87 */
				CALC_S (se, sf, sg, sh, 11, 0xD1, 0x7F, 0x3D, 0x99); /* 87 F3 C1 5A */
				CALC_S (se, sf, sg, sh, 12, 0x99, 0x46, 0x66, 0x96); /* 5A 1E 47 58 */
				CALC_S (se, sf, sg, sh, 13, 0x96, 0x3C, 0x5B, 0xED); /* 58 C6 AE DB */
				CALC_S (se, sf, sg, sh, 14, 0xED, 0x37, 0x4F, 0xE0); /* DB 68 3D 9E */
				CALC_S (se, sf, sg, sh, 15, 0xE0, 0xD0, 0x8C, 0x17); /* 9E E5 19 03 */
				CALC_S (si, sj, sk, sl, 16, 0x00, 0x2D, 0x01, 0x2D); /* 01 A4 02 A4 */
				CALC_S (si, sj, sk, sl, 17, 0x2D, 0xA4, 0x44, 0x8A); /* A4 56 A1 55 */
				CALC_S (si, sj, sk, sl, 18, 0x8A, 0xD5, 0xBF, 0xD1); /* 55 82 FC 87 */
				CALC_S (si, sj, sk, sl, 19, 0xD1, 0x7F, 0x3D, 0x99); /* 87 F3 C1 5A */
				CALC_S (si, sj, sk, sl, 20, 0x99, 0x46, 0x66, 0x96); /* 5A 1E 47 58 */
				CALC_S (si, sj, sk, sl, 21, 0x96, 0x3C, 0x5B, 0xED); /* 58 C6 AE DB */
				CALC_S (si, sj, sk, sl, 22, 0xED, 0x37, 0x4F, 0xE0); /* DB 68 3D 9E */
				CALC_S (si, sj, sk, sl, 23, 0xE0, 0xD0, 0x8C, 0x17); /* 9E E5 19 03 */
				CALC_S (sm, sn, so, sp, 24, 0x00, 0x2D, 0x01, 0x2D); /* 01 A4 02 A4 */
				CALC_S (sm, sn, so, sp, 25, 0x2D, 0xA4, 0x44, 0x8A); /* A4 56 A1 55 */
				CALC_S (sm, sn, so, sp, 26, 0x8A, 0xD5, 0xBF, 0xD1); /* 55 82 FC 87 */
				CALC_S (sm, sn, so, sp, 27, 0xD1, 0x7F, 0x3D, 0x99); /* 87 F3 C1 5A */
				CALC_S (sm, sn, so, sp, 28, 0x99, 0x46, 0x66, 0x96); /* 5A 1E 47 58 */
				CALC_S (sm, sn, so, sp, 29, 0x96, 0x3C, 0x5B, 0xED); /* 58 C6 AE DB */
				CALC_S (sm, sn, so, sp, 30, 0xED, 0x37, 0x4F, 0xE0); /* DB 68 3D 9E */
				CALC_S (sm, sn, so, sp, 31, 0xE0, 0xD0, 0x8C, 0x17); /* 9E E5 19 03 */

				/* Compute the S-boxes. */
				for ( i = j = 0, k = 1; i < 256; i++, j += 2, k += 2 ) {
					CALC_SB256_2( i, calc_sb_tbl[j], calc_sb_tbl[k] );
				}

				for ( i = 0; i < 8; i += 2 ) {
					CALC_K256 (m_w, i, q0[i], q1[i], q0[i+1], q1[i+1]);
				}
				for ( i = 0; i < 32; i += 2 ) {
					CALC_K256 (m_k, i, q0[i+8], q1[i+8], q0[i+9], q1[i+9]);
				}

				return ;
			}


			constexpr void encrypt(void* ctxt, const void* ptxt)
			{
				using namespace detail::twofish;

				/* The four 32-bit chunks of the text. */
				register uint32_t a, b, c, d;
				

				/* Temporaries used by the round function. */
				uint32_t x, y;

				/* Input whitening and packing. */
				INPACK (ptxt, 0, a, 0);
				INPACK (ptxt, 1, b, 1);
				INPACK (ptxt, 2, c, 2);
				INPACK (ptxt, 3, d, 3);

				/* Encryption Feistel cycles. */
				ENCCYCLE (0);
				ENCCYCLE (1);
				ENCCYCLE (2);
				ENCCYCLE (3);
				ENCCYCLE (4);
				ENCCYCLE (5);
				ENCCYCLE (6);
				ENCCYCLE (7);

				/* Output whitening and unpacking. */
				OUTUNPACK (ctxt, 0, c, 4);
				OUTUNPACK (ctxt, 1, d, 5);
				OUTUNPACK (ctxt, 2, a, 6);
				OUTUNPACK (ctxt, 3, b, 7);		
			}

			constexpr void decrypt(void* ptxt, const void* ctxt)
			{
				using namespace detail::twofish;

				/* The four 32-bit chunks of the text. */
				register uint32_t a, b, c, d;

				/* Temporaries used by the round function. */
				uint32_t x, y;

				/* Input whitening and packing. */
				INPACK (ctxt, 0, c, 4);
				INPACK (ctxt, 1, d, 5);
				INPACK (ctxt, 2, a, 6);
				INPACK (ctxt, 3, b, 7);

				/* Encryption Feistel cycles. */
				DECCYCLE (7);
				DECCYCLE (6);
				DECCYCLE (5);
				DECCYCLE (4);
				DECCYCLE (3);
				DECCYCLE (2);
				DECCYCLE (1);
				DECCYCLE (0);

				/* Output whitening and unpacking. */
				OUTUNPACK (ptxt, 0, a, 0);
				OUTUNPACK (ptxt, 1, b, 1);
				OUTUNPACK (ptxt, 2, c, 2);
				OUTUNPACK (ptxt, 3, d, 3);
			}
		};

		typedef twofish_cipher<16> twofish;

	} // namespace boost::crypto
} // namespace boost 

#undef CALC_S
#undef CALC_SB_2
#undef CALC_SB256_2
#undef CALC_K256
#undef CALC_K256_2
#undef CALC_K192
#undef CALC_K192_2
#undef CALC_K
#undef CALC_K_2
#undef G1
#undef G2
#undef ENCROUND
#undef DECROUND
#undef ENCCYCLE
#undef DECCYCLE
#
#endif /* BOOST_CRYPTO_TWOFISH_HPP_INCLUDED */
