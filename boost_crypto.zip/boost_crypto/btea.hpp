#ifndef BOOST_CRYPTO_BTEA_HPP_INCLUDED
#define BOOST_CRYPTO_BTEA_HPP_INCLUDED
#
#include "crypto.hpp"
#include "crypto_endian.hpp"

namespace boost { 
	namespace crypto {

		template<size_t WBlockSize=32>
		class btea_cipher
		{
		public:			
			typedef byte_t   value_type;
			typedef uint32_t word_type;
			typedef size_t   size_type;

			static constexpr size_type block_size   = WBlockSize * 4;
			static constexpr size_type rounds       = size_type(-1);
			static constexpr size_type min_key_size = 0;
			static constexpr size_type max_key_size = 16;
			static constexpr char* name() { return "B-TEA"; }

		private:
			BOOST_STATIC_ASSERT(block_size >= 8);
			
			uint32_t m_key[4];
			bool m_initialised;

			void dbtea(uint32_t* v, const uint32_t* v_i) 
			{
				uint32_t z=v[WBlockSize-1], y=v[0], sum=0, e;
				long p, q ;

				// copy input to output
				std::memcpy(v, v_i, block_size);

				q = 6 + 52/WBlockSize;
				sum = q*UINT32_C(0x9e3779b9) ;
				while (sum != 0)
				{
					e = (sum >> 2) & 3;
					for (p=WBlockSize-1; p>0; p--) 
					{
						z = v[p-1];
						y = v[p] -= ((z>>5)^(y<<2)) + ((y>>3)^(z<<4))^(sum^y) + (m_key[(p&3)^e]^z);
					}
					z = v[WBlockSize-1];
					y = v[0] -= ((z>>5)^(y<<2)) + ((y>>3)^(z<<4))^(sum^y) + (m_key[(p&3)^e]^z);
					sum -= UINT32_C(0x9e3779b9);
				}
			}

			void ebtea(uint32_t* v, const uint32_t* v_i) 
			{
				uint32_t z=v[WBlockSize-1], y=v[0], sum=0, e;
				long p, q ;

				// copy input to output
				std::memcpy(v, v_i, block_size);

				q = 6 + 52/WBlockSize;
				while (q-- > 0) 
				{
					sum += UINT32_C(0x9e3779b9);
					e = (sum >> 2) & 3;
					for (p=0; p<WBlockSize-1; p++) 
					{
						y = v[p+1];
						z = v[p] += ((z>>5)^(y<<2)) + ((y>>3)^(z<<4))^(sum^y) + (m_key[(p&3)^e]^z);
					}
					y = v[0];
					z = v[WBlockSize-1] += ((z>>5)^(y<<2)) + ((y>>3)^(z<<4))^(sum^y) + (m_key[(p&3)^e]^z);
				}			
			}

		public:
			btea_cipher() : m_initialised(false)
			{
			}

			btea_cipher(const void* key, size_type key_size) : m_initalised(false)
			{
				setkey(key,key_size);
			}

			void setkey(const void* key, size_type key_size) throw(invalid_key_size)
			{
				BOOST_CRYPTO_CHECK_KEYSIZE(key_size,boost::crypto::tea_cipher::setkey());

				std::memcpy(m_key         , key, key_size);
				std::memset(m_key+key_size, 000, max_key_size-key_size);

				// correct endian allignment
				for(int i=0; i<4; i++) endian::ensure_le(m_key+i);

				m_initialised = true;
			}

			// [output] size == padding_type::output_size(input_size)
			void encrypt(void* ctxt, const void* ptxt) throw(cipher_not_initialised)
			{
				BOOST_CRYPTO_CHECK_STATE(boost::crypto::tea_cipher::encrypt());

				ebtea(reinterpret_cast<uint32_t*>(ctxt), reinterpret_cast<const uint32_t*>(ptxt));
			}

			void decrypt(void* ptxt, const void* ctxt) throw(cipher_not_initialised)
			{
				BOOST_CRYPTO_CHECK_STATE(boost::crypto::tea_cipher::decrypt());

				dbtea(reinterpret_cast<uint32_t*>(ptxt), reinterpret_cast<const uint32_t*>(ctxt));
			}
		};

		// block tea block size is recommended to be
		// about 32-bytes
		typedef btea_cipher<32> btea;

	} // namespace crypto
} // namespace boost

#endif /* BOOST_CRYPTO_BTEA_HPP_INCLUDED */


