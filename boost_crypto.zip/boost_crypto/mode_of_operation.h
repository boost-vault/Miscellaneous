/*
NOTE: Mode of operation concept is not clear enough therefor only
CBC is implemented at this time.


mode of operation is an algorithm which could convert a block cipher
into a stream cipher.

since most of the known mode of operation do not perform paralised
encryption paralised encryption is a rare event.

so an encryption stream is one that could append data to the end of
the stream.

however, a decryption stream could read from any arbitary position
within the stream given enough pre-data is available.

// methods for stream transformation
template <Direction>	this_type create();
template <Direction>	this_type create( ostream ); // bind to a stream
template <Direction>	size_type update( const void* in, size_type size); // when attached to a stream
template <Direction>	this_type flush ();
template <Direction>	void close();
											pos_type tell();
											pos_type seek();

// methods for inplace transformation
size_type transform<Encryption>( void* out, const void* in, size_type size );
size_type transform<Decryption>( void* out, const void* in, size_type size );

a class which when initialised requires two sets of secret strings: 
	key and typically iv.

this class could encrypt or decrypt data given enough pre-data is available.

## mode of operation
	* - performs no buffering. 
	* - requires at least 2 secret strings
	* - could process if data is feed in constant
			blocks.
	* - encrypt data upto max_size()
	* - decrypt data if:		
			* - previous encrypted block is available; or
			* - current block index is known (counter and etc); or
			* - ECB mode of operation.
*/