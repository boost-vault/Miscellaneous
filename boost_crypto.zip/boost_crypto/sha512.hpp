#ifndef BOOST_CRYPTO_SHA512_HPP_INCLUDED
#define BOOST_CRYPTO_SHA512_HPP_INCLUDED
#
#include "sha2.hpp"

namespace boost {
	namespace crypto {

		typedef sha2_ctx<uint64_t, 64,
			UINT64_C(0x6a09e667f3bcc908), UINT64_C(0xbb67ae8584caa73b),
			UINT64_C(0x3c6ef372fe94f82b), UINT64_C(0xa54ff53a5f1d36f1),
			UINT64_C(0x510e527fade682d1), UINT64_C(0x9b05688c2b3e6c1f),
			UINT64_C(0x1f83d9abfb41bd6b), UINT64_C(0x5be0cd19137e2179)
		> sha512_ctx;

	} // namespace crypto
} // namespace boost

#endif /* BOOST_CRYPTO_SHA512_HPP_INCLUDED */
