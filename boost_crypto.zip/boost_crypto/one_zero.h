#ifndef BOOST_CRYPTO_ONE_ZERO_HPP_INCLUDED
#define BOOST_CRYPTO_ONE_ZERO_HPP_INCLUDED
#
#include <stdexcept>
#include <exception>
#include <cstring>
#include <string>
#
#include "crypto.hpp"
#include "padding_traits.hpp"

namespace boost { 
	namespace crypto {

		template<size_type B,typename T=byte_t>
		struct one_zero_padding
		{
			typedef size_t							size_type;
			static constexpr size_type	min_block_size = 1;
			static constexpr size_type	max_block_size = 256;
			static constexpr bool				allways_pad = false;
			static constexpr size_type	padding_block_size = B;
			static constexpr T					pad_block = T(1) << (bitsof<T>::value - 1);

			BOOST_STATIC_ASSERT(padding_block_size <= max_block_size);

			// return the size of string with input_size after the padding
			static constexpr size_type output_size(size_type input_size)
			{
				return input_size + (padding_block_size - (input_size % padding_block_size));
			}

			static size_type pad(T* output, const T* input, size_type input_size) throw(std::length_error)
			{				
				T outsize = output_size(input_size);
				if(input != output) memcpy(output, input, input_size);
				for(int i = input_size; i < outsize ; i++) output[i] = 0;
				output[input_size] = pad_block;

				return outsize;
			}

			// return the size of string with input_size after the unpadding
			static size_type unpad(T* output, const T* input, size_type input_size) throw(bad_padding)
			{
				T margin = T(0);
				const T* in = input;
				size_type insize = input_size;

				while(*in == T(0) && insize) in--;

				if(*in == pad_block)
					margin = T(input_size-insize);
				else
					throw bad_padding("boost::crypto::one_zero_padding::unpad() : invalid padding");

				if(input != output) memcpy(output, input, input_size-margin);
				return input_size-margin;
			}
		};

	} // namepace boost::crypto
} // namespace boost 


#endif /* BOOST_CRYPTO_ONE_ZERO_HPP_INCLUDED */
