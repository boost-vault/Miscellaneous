#ifndef BOOST_CRYPTO_HC128_HPP_INCLUDED
#define BOOST_CRYPTO_HC128_HPP_INCLUDED
#
#include "crypto.hpp"
#include "crypto_rotation.hpp"
#include "stream_cipher.hpp"
#include "hc.hpp"
#include "fixed_buffer.hpp"
#
#ifdef BOOST_MSVC 
#pragma once
#endif

/*h1 function*/
#define h1(ctx, x, y) {    \
	uint8_t a,c;               \
	a = (uint8_t) (x);         \
	c = (uint8_t) ((x) >> 16);  \
	y = (ctx ## T[512+a])+(ctx ## T[512+256+c]); \
		}

/*h2 function*/
#define h2(ctx, x, y) {    \
	uint8_t a,c;               \
	a = (uint8_t) (x);         \
	c = (uint8_t) ((x) >> 16); \
	y = (ctx ## T[a])+(ctx ## T[256+c]); \
		}

/*one step of HC-128, update P and generate 32 bits keystream*/
#define step_P(u,v,a,b,c,d,n){    \
	uint32_t tem0,tem1,tem2,tem3;         \
	h1(this->,(X[(d)]),tem3);              \
	tem0 = BOOST_ROR32((T[(v)]),23);\
	tem1 = BOOST_ROR32((X[(c)]),10);\
	tem2 = BOOST_ROR32((X[(b)]),8);\
	(T[(u)]) += tem2+(tem0 ^ tem1);       \
	(X[(a)]) = (T[(u)]);             \
	(n) = tem3 ^ (T[(u)]) ;               \
		}       

/*one step of HC-128, update Q and generate 32 bits keystream*/
#define step_Q(u,v,a,b,c,d,n){      \
	uint32_t tem0,tem1,tem2,tem3;           \
	h2(this->,(Y[(d)]),tem3);              \
	tem0 = BOOST_ROR32((T[(v)]),(32-23));      \
	tem1 = BOOST_ROR32((Y[(c)]),(32-10));      \
	tem2 = BOOST_ROR32((Y[(b)]),(32-8));       \
	(T[(u)]) += tem2 + (tem0 ^ tem1);     \
	(Y[(a)]) = (T[(u)]);             \
	(n) = tem3 ^ (T[(u)]) ;               \
		}   

#define f1(x)  (BOOST_ROR32((x),7) ^ BOOST_ROR32((x),18) ^ ((x) >> 3))
#define f2(x)  (BOOST_ROR32((x),17) ^ BOOST_ROR32((x),19) ^ ((x) >> 10))

/*update table P*/
#define update_P(u,v,a,b,c,d){      \
	uint32_t tem0,tem1,tem2,tem3;           \
	tem0 = BOOST_ROR32((ctx.T[(v)]),23);           \
	tem1 = BOOST_ROR32((ctx.X[(c)]),10);           \
	tem2 = BOOST_ROR32((ctx.X[(b)]),8);            \
	h1(ctx., ctx.X[(d)],tem3);              \
	(ctx.T[(u)]) = ((ctx.T[(u)]) + tem2+(tem0^tem1)) ^ tem3;\
	(ctx.X[(a)]) = (ctx.T[(u)]);             \
		}  

/*update table Q*/
#define update_Q(u,v,a,b,c,d){      \
	uint32_t tem0,tem1,tem2,tem3;      \
	tem0 = BOOST_ROR32((ctx.T[(v)]),(32-23));\
	tem1 = BOOST_ROR32((ctx.Y[(c)]),(32-10));\
	tem2 = BOOST_ROR32((ctx.Y[(b)]),(32-8));\
	h2(ctx., (ctx.Y[(d)]),tem3);              \
	(ctx.T[(u)]) = ((ctx.T[(u)]) + tem2+(tem0^tem1)) ^ tem3; \
	(ctx.Y[(a)]) = (ctx.T[(u)]);                       \
		} 
namespace boost { 
	namespace crypto {
		namespace detail {
		} // namespace boost::crypto::detail 

		template<> class hc_stream_cipher<128>
		{
		public:
			typedef size_t size_type;
			typedef byte_t value_type;
			static constexpr size_type min_key_size   = 0;
			static constexpr size_type max_key_size   = 16;
			static constexpr size_type min_iv_size    = 0;
			static constexpr size_type max_iv_size    = 16;
			// if blocks of 64-bytes is used for buffering
			// optimal performance is ensured.
			static constexpr size_type transform_size = 64;

			struct stream_ctx
			{
				stream_ctx_state state;
				uint32_t T[1024];       /* P[i] = T[i]; Q[i] = T[1024+i];*/
				uint32_t X[16];
				uint32_t Y[16];
				uint16_t counter1024;   /*counter1024 = i mod 1024 at the i-th step */				

				constexpr void generate_keystream(uint32_t* keystream) throw()  
				{
					uint32_t cc,dd;
					cc =counter1024 & 0x1ff;
					dd = (cc+16)&0x1ff;

					if (counter1024 < 512)	
					{   		
						counter1024 = (counter1024 + 16) & 0x3ff;
						step_P(cc+0, cc+1, 0, 6, 13,4, keystream[0]);
						step_P(cc+1, cc+2, 1, 7, 14,5, keystream[1]);
						step_P(cc+2, cc+3, 2, 8, 15,6, keystream[2]);
						step_P(cc+3, cc+4, 3, 9, 0, 7, keystream[3]);
						step_P(cc+4, cc+5, 4, 10,1, 8, keystream[4]);
						step_P(cc+5, cc+6, 5, 11,2, 9, keystream[5]);
						step_P(cc+6, cc+7, 6, 12,3, 10,keystream[6]);
						step_P(cc+7, cc+8, 7, 13,4, 11,keystream[7]);
						step_P(cc+8, cc+9, 8, 14,5, 12,keystream[8]);
						step_P(cc+9, cc+10,9, 15,6, 13,keystream[9]);
						step_P(cc+10,cc+11,10,0, 7, 14,keystream[10]);
						step_P(cc+11,cc+12,11,1, 8, 15,keystream[11]);
						step_P(cc+12,cc+13,12,2, 9, 0, keystream[12]);
						step_P(cc+13,cc+14,13,3, 10,1, keystream[13]);
						step_P(cc+14,cc+15,14,4, 11,2, keystream[14]);
						step_P(cc+15,dd+0, 15,5, 12,3, keystream[15]);
					}
					else				    
					{
						counter1024 = (counter1024 + 16) & 0x3ff;
						step_Q(512+cc+0, 512+cc+1, 0, 6, 13,4, keystream[0]);
						step_Q(512+cc+1, 512+cc+2, 1, 7, 14,5, keystream[1]);
						step_Q(512+cc+2, 512+cc+3, 2, 8, 15,6, keystream[2]);
						step_Q(512+cc+3, 512+cc+4, 3, 9, 0, 7, keystream[3]);
						step_Q(512+cc+4, 512+cc+5, 4, 10,1, 8, keystream[4]);
						step_Q(512+cc+5, 512+cc+6, 5, 11,2, 9, keystream[5]);
						step_Q(512+cc+6, 512+cc+7, 6, 12,3, 10,keystream[6]);
						step_Q(512+cc+7, 512+cc+8, 7, 13,4, 11,keystream[7]);
						step_Q(512+cc+8, 512+cc+9, 8, 14,5, 12,keystream[8]);
						step_Q(512+cc+9, 512+cc+10,9, 15,6, 13,keystream[9]);
						step_Q(512+cc+10,512+cc+11,10,0, 7, 14,keystream[10]);
						step_Q(512+cc+11,512+cc+12,11,1, 8, 15,keystream[11]);
						step_Q(512+cc+12,512+cc+13,12,2, 9, 0, keystream[12]);
						step_Q(512+cc+13,512+cc+14,13,3, 10,1, keystream[13]);
						step_Q(512+cc+14,512+cc+15,14,4, 11,2, keystream[14]);
						step_Q(512+cc+15,512+dd+0, 15,5, 12,3, keystream[15]);
					}
				}

				stream_ctx() { }

				size_type operator () (void* output, const void* input, size_type input_size) throw(bad_cipher_state)
				{
					if(!(state != stream_ctx_created || state != stream_ctx_updating))
						throw bad_cipher_state("hc128_stream_cipher::stream_ctx() : could not transform any more");

					uint8_t *out;		
					const uint8_t *in;		
					out = reinterpret_cast<uint8_t*>(output);
					in  = reinterpret_cast<const uint8_t*>(input);
					uint32_t i, keystream[16];

					for ( ; input_size >= 64; input_size -= 64, in += 64, out += 64)
					{
						generate_keystream(keystream);

						((uint32_t*)out)[ 0] = ((uint32_t*)in)[ 0] ^ endian::cpu_to_le((uint32_t)keystream[0 ]);
						((uint32_t*)out)[ 1] = ((uint32_t*)in)[ 1] ^ endian::cpu_to_le((uint32_t)keystream[1 ]);
						((uint32_t*)out)[ 2] = ((uint32_t*)in)[ 2] ^ endian::cpu_to_le((uint32_t)keystream[2 ]);
						((uint32_t*)out)[ 3] = ((uint32_t*)in)[ 3] ^ endian::cpu_to_le((uint32_t)keystream[3 ]);
						((uint32_t*)out)[ 4] = ((uint32_t*)in)[ 4] ^ endian::cpu_to_le((uint32_t)keystream[4 ]);
						((uint32_t*)out)[ 5] = ((uint32_t*)in)[ 5] ^ endian::cpu_to_le((uint32_t)keystream[5 ]);
						((uint32_t*)out)[ 6] = ((uint32_t*)in)[ 6] ^ endian::cpu_to_le((uint32_t)keystream[6 ]);
						((uint32_t*)out)[ 7] = ((uint32_t*)in)[ 7] ^ endian::cpu_to_le((uint32_t)keystream[7 ]);
						((uint32_t*)out)[ 8] = ((uint32_t*)in)[ 8] ^ endian::cpu_to_le((uint32_t)keystream[8 ]);
						((uint32_t*)out)[ 9] = ((uint32_t*)in)[ 9] ^ endian::cpu_to_le((uint32_t)keystream[9 ]);
						((uint32_t*)out)[10] = ((uint32_t*)in)[10] ^ endian::cpu_to_le((uint32_t)keystream[10]);
						((uint32_t*)out)[11] = ((uint32_t*)in)[11] ^ endian::cpu_to_le((uint32_t)keystream[11]);
						((uint32_t*)out)[12] = ((uint32_t*)in)[12] ^ endian::cpu_to_le((uint32_t)keystream[12]);
						((uint32_t*)out)[13] = ((uint32_t*)in)[13] ^ endian::cpu_to_le((uint32_t)keystream[13]);
						((uint32_t*)out)[14] = ((uint32_t*)in)[14] ^ endian::cpu_to_le((uint32_t)keystream[14]);
						((uint32_t*)out)[15] = ((uint32_t*)in)[15] ^ endian::cpu_to_le((uint32_t)keystream[15]);
					}

					if (input_size > 0)
					{
						generate_keystream(keystream);

						for (i = 0; i < input_size; i ++)
							out[i] = in[i] ^ ((uint8_t*)keystream)[i];
					}
				}

				// there would never be any outstanding buffer for this class
				// although such buffers could increase performance however
				// at this low-level API it is expected the programmer to do 
				// the buffering right for optimal performance
				size_type operator () (void* final, size_type size) throw()
				{
					state = stream_ctx_finished;
					return size_type(0);
				}

				// is there outstanding data in the buffers
				bool operator () () const { return false; }

				// same as operator ()()
				operator bool () { return false; }
			};

		private:
			friend class stream_ctx;
			uint8_t m_key[max_key_size];
			uint8_t m_iv[max_iv_size];
			stream_ctx m_stream_ctx; // create 1 member cache
			bool    m_info_changed;
			bool		m_have_iv;
			bool    m_have_key;
			bool    m_initialised;
					
			constexpr void key_setup(stream_ctx& ctx) throw(key_not_set, iv_not_set)
			{	
				// copy key and iv
				if(!m_have_key) throw key_not_set("hc128_stream_cipher::create() : key not set");
				std::memcpy(ctx.T, m_key, max_key_size);
				// duplicate the key
				for(int i = 0; i < 4; i++) ctx.T[4+i] = ctx.T[i];
				
				if(!m_have_iv) throw iv_not_set("hc128_stream_cipher::create() : IV not set");
				std::memcpy(ctx.T+8, m_iv , max_iv_size);
				// duplicate the iv
				for(int i = 0; i < 4; i++) ctx.T[12+i] = ctx.T[8+i];

				// ensure correct endianess 
				for (int i = 0; i < 16; i++)	endian::ensure_le(ctx.T+i);

				/* (expand the key and IV into the table P and Q) */ 
				for (int i = 16; i < (256+16); i++) 
					ctx.T[i] = f2(ctx.T[i-2]) +ctx.T[i-7] + f1(ctx.T[i-15]) +ctx.T[i-16]+i;

				for (int i = 0; i < 16;  i++) ctx.T[i] =ctx.T[256+i];

				for (int i = 16; i < 1024; i++) 
					ctx.T[i] = f2(ctx.T[i-2]) +ctx.T[i-7] + f1(ctx.T[i-15]) +ctx.T[i-16]+256+i;

				/* initialize counter1024, X and Y */
				ctx.counter1024 = 0;
				for (int i = 0; i < 16; i++)ctx.X[i] =ctx.T[512-16+i];
				for (int i = 0; i < 16; i++)ctx.Y[i] =ctx.T[512+512-16+i];

				/* run the cipher 1024 steps before generating the output */
				for (int i = 0; i < 64; i++)  setup_update(ctx);  
			}

			constexpr void setup_update(stream_ctx& ctx) throw()  /*each time 16 steps*/
			{
				uint32_t cc,dd;
				cc =ctx.counter1024 & 0x1ff;
				dd = (cc+16)&0x1ff;

				if (ctx.counter1024 < 512)	
				{   		
					ctx.counter1024 = (ctx.counter1024 + 16) & 0x3ff;
					update_P(cc+0, cc+1, 0, 6, 13, 4);
					update_P(cc+1, cc+2, 1, 7, 14, 5);
					update_P(cc+2, cc+3, 2, 8, 15, 6);
					update_P(cc+3, cc+4, 3, 9, 0,  7);
					update_P(cc+4, cc+5, 4, 10,1,  8);
					update_P(cc+5, cc+6, 5, 11,2,  9);
					update_P(cc+6, cc+7, 6, 12,3,  10);
					update_P(cc+7, cc+8, 7, 13,4,  11);
					update_P(cc+8, cc+9, 8, 14,5,  12);
					update_P(cc+9, cc+10,9, 15,6,  13);
					update_P(cc+10,cc+11,10,0, 7,  14);
					update_P(cc+11,cc+12,11,1, 8,  15);
					update_P(cc+12,cc+13,12,2, 9,  0);
					update_P(cc+13,cc+14,13,3, 10, 1);
					update_P(cc+14,cc+15,14,4, 11, 2);
					update_P(cc+15,dd+0, 15,5, 12, 3);   
				}
				else				    
				{
					ctx.counter1024 = (ctx.counter1024 + 16) & 0x3ff;
					update_Q(512+cc+0, 512+cc+1, 0, 6, 13, 4);
					update_Q(512+cc+1, 512+cc+2, 1, 7, 14, 5);
					update_Q(512+cc+2, 512+cc+3, 2, 8, 15, 6);
					update_Q(512+cc+3, 512+cc+4, 3, 9, 0,  7);
					update_Q(512+cc+4, 512+cc+5, 4, 10,1,  8);
					update_Q(512+cc+5, 512+cc+6, 5, 11,2,  9);
					update_Q(512+cc+6, 512+cc+7, 6, 12,3,  10);
					update_Q(512+cc+7, 512+cc+8, 7, 13,4,  11);
					update_Q(512+cc+8, 512+cc+9, 8, 14,5,  12);
					update_Q(512+cc+9, 512+cc+10,9, 15,6,  13);
					update_Q(512+cc+10,512+cc+11,10,0, 7,  14);
					update_Q(512+cc+11,512+cc+12,11,1, 8,  15);
					update_Q(512+cc+12,512+cc+13,12,2, 9,  0);
					update_Q(512+cc+13,512+cc+14,13,3, 10, 1);
					update_Q(512+cc+14,512+cc+15,14,4, 11, 2);
					update_Q(512+cc+15,512+dd+0, 15,5, 12, 3); 
				}       
			}	


			/*16 steps of HC-128, generate 512 bits keystream*/
		public:	
			hc_stream_cipher() : 
			m_have_iv(false),
			m_have_key(false)
			{
			}

			hc_stream_cipher(const void* key, size_type key_size) : 
			m_have_iv(false),
			m_have_key(false)
			{
				setkey(key,key_size);
			}

			hc_stream_cipher(const void* key, size_type key_size,
				const uint8_t* iv, size_type iv_size) : 
			m_have_iv(false),
			m_have_key(false)
			{
				setkey(key,key_size);
				setiv(iv,iv_size);
			}

			template<StreamDirection Direction> 
			stream_ctx create()
			{
				// return the cache 
				if(!m_info_changed) return m_stream_ctx;

				stream_ctx ctx;
				key_setup(m_stream_ctx);
				m_stream_ctx.state = stream_ctx_created;
				
				m_info_changed = false;
				return m_stream_ctx;
			}

			void setkey(const void* key, size_type key_size) throw(invalid_key_size)
			{ 
				if(!(min_key_size <= key_size && key_size <= max_key_size))
					throw invalid_key_size("hc128_stream_cipher::setkey() : invalid key size");

				// copy and expand key
				weak_fixed_buffer<max_key_size> key_ref_wrapper(key,key_size):

				m_info_changed = m_have_key = true;
			}

			void setiv(const void* iv=nullptr, size_type iv_size=0) throw(invalid_iv_size)
			{ 
				if(!(min_iv_size <= iv_size && iv_size <= max_iv_size))
					throw invalid_iv_size("hc128_stream_cipher::setiv() : invalid IV size");

				// copy and expand iv
				std::memcpy(m_iv, iv, iv_size);
				std::memset(m_iv + iv_size, 0, max_iv_size-iv_size);

				m_info_changed = m_have_iv = true;
			}

			constexpr void encrypt(void* output, const void* input, size_type input_size)  throw (key_not_set, iv_not_set)
			{
				if(!m_have_key) 
					throw key_not_set("hc128_stream_cipher::decrypt() : key not set");

				if(!m_have_iv) 
					throw iv_not_set("hc128_stream_cipher::decrypt() : IV not set");
				
				stream_ctx ctx = create<Encryption>();
				ctx(output, input, input_size);
			}

			constexpr void decrypt(void* output, const void* input, size_type input_size) throw (key_not_set, iv_not_set)
			{
				if(!m_have_key) 
					throw key_not_set("hc128_stream_cipher::decrypt() : key not set");

				if(!m_have_iv) 
					throw iv_not_set("hc128_stream_cipher::decrypt() : IV not set");

				stream_ctx ctx = create<Decryption>();
				ctx(output, input, input_size);
			}
		};

		typedef hc_stream_cipher<128> hc128_stream_cipher;
	} // namespace boost::crypto
} // namespace boost 

#undef f1
#undef f2
#undef h1
#undef h2
#undef step_P
#undef step_Q
#
#endif /* BOOST_CRYPTO_HC128_HPP_INCLUDED */
