#ifndef BOOST_CRYPTO_SALSA_HPP_INCLUDED
#define BOOST_CRYPTO_SALSA_HPP_INCLUDED

#include "crypto.hpp"
#include "stream_cipher.hpp"
#include "crypto_rotation.hpp"

#define ROTATE(v,c) BOOST_ROL32(v,c)
#define XOR(v,w)    ((v) ^ (w))
#define PLUS(v,w)   (((v) + (w)))
#define PLUSONE(v)  (PLUS((v),1))

namespace boost {
	namespace crypto {
		namespace detail {
			namespace salsa {
				static const char sigma[17] = "expand 32-byte k";
				static const char tau  [17] = "expand 16-byte k";
			} // namespace boost::crypto::detail::salsa
		} // namespace boost::crypto::detail

		template<size_t NR /* # of rounds (multiple of 2) */>
		class salsa_stream_cipher
		{
		private:
			// NR MUST be multiples of 2 for efficient salsa
			// implememtation
			BOOST_STATIC_ASSERT((NR & 1) == 0);
		public:
			typedef size_t size_type;
			typedef byte_t value_type;
			typedef salsa_stream_cipher<NR> this_type;
			static constexpr size_type min_key_size   = 0;
			static constexpr size_type max_key_size   = 16;
			static constexpr size_type min_iv_size    = 0;
			static constexpr size_type max_iv_size    = 16;
			static constexpr size_type transform_size = 64;
			static constexpr size_type rounds         = NR; // rounds the cipher uses

			struct stream_ctx
			{
				stream_ctx_state state;
				uint32_t input[16]; /* could be compressed */	

				void operator () (void* output, const void* input, size_type input_size) throw(bad_cipher_state)
				{
					if(!(state != stream_ctx_created || state != stream_ctx_updating))
						throw bad_cipher_state("salsa_stream_cipher::stream_ctx() : could not transform any more");

					uint8_t outstream[64];
					uint8_t *c = reinterpret_cast<uint8_t*>(output);
					const uint8_t *m = reinterpret_cast<const uint8_t*>(input);
					int i;

					if (!input_size) return;
					while (true)
					{
						this_type::wordtobyte(outstream,this->input);
						this->input[8] = PLUSONE(this->input[8]);
						if (!this->input[8]) {
							this->input[9] = PLUSONE(this->input[9]);
							/* stopping at 2^70 bytes per nonce is user's responsibility */
						}
						if (input_size <= 64) {
							for (i = 0;i < input_size;++i) c[i] = m[i] ^ outstream[i];
							return;
						}
						for (i = 0;i < 64;++i) c[i] = m[i] ^ outstream[i];
						input_size -= 64;
						c += 64;
						m += 64;
					}
				}

				bool operator () () { return false; }
				operator bool () { return false; }
				size_type flush (void* finalblock, size_type size) { return size_type(0); }
			};

		private:
			uint8_t m_key[max_key_size];
			uint8_t m_iv [max_iv_size];
			stream_ctx m_stream_ctx;
			const char *constants;
			bool m_state_changed;
			bool m_have_key;
			bool m_have_iv;

			void key_setup(stream_ctx& ctx) throw(invalid_key_size, invalid_iv_size)
			{				
				if(!m_have_key) throw invalid_key_size("salsa_stream_cipher::stream_ctx() : key not set");
				if(!m_have_iv) throw invalid_iv_size("salsa_stream_cipher::stream_ctx() : IV not set");

				uint8_t *k = reinterpret_cast<uint8_t*>(m_key);
				ctx.input[1] = endian::read_le(((uint32_t*)k) + 0);
				ctx.input[2] = endian::read_le(((uint32_t*)k) + 1);
				ctx.input[3] = endian::read_le(((uint32_t*)k) + 2);
				ctx.input[4] = endian::read_le(((uint32_t*)k) + 3);
				k += 16;
				ctx.input[11] = endian::read_le(((uint32_t*)k) + 0);
				ctx.input[12] = endian::read_le(((uint32_t*)k) + 1);
				ctx.input[13] = endian::read_le(((uint32_t*)k) + 2);
				ctx.input[14] = endian::read_le(((uint32_t*)k) + 3);
				ctx.input[0 ] = endian::read_le((uint32_t*)(constants + 0));
				ctx.input[5 ] = endian::read_le((uint32_t*)(constants + 4));
				ctx.input[10] = endian::read_le((uint32_t*)(constants + 8));
				ctx.input[15] = endian::read_le((uint32_t*)(constants + 12));

				ctx.input[6] = endian::read_le(((uint32_t*)m_iv));
				ctx.input[7] = endian::read_le(((uint32_t*)m_iv)+1);
				ctx.input[8] = 0;
				ctx.input[9] = 0;
			}

			static void wordtobyte(uint8_t output[64],const uint32_t input[16])
			{
				int i;
				uint32_t x[16];

				for (i = 0 ; i < 16; ++i) x[i] = input[i];
				for (i = NR; i > 00; i -= 2) {
					x[ 4] = XOR(x[ 4],ROTATE(PLUS(x[ 0],x[12]), 7));
					x[ 8] = XOR(x[ 8],ROTATE(PLUS(x[ 4],x[ 0]), 9));
					x[12] = XOR(x[12],ROTATE(PLUS(x[ 8],x[ 4]),13));
					x[ 0] = XOR(x[ 0],ROTATE(PLUS(x[12],x[ 8]),18));
					x[ 9] = XOR(x[ 9],ROTATE(PLUS(x[ 5],x[ 1]), 7));
					x[13] = XOR(x[13],ROTATE(PLUS(x[ 9],x[ 5]), 9));
					x[ 1] = XOR(x[ 1],ROTATE(PLUS(x[13],x[ 9]),13));
					x[ 5] = XOR(x[ 5],ROTATE(PLUS(x[ 1],x[13]),18));
					x[14] = XOR(x[14],ROTATE(PLUS(x[10],x[ 6]), 7));
					x[ 2] = XOR(x[ 2],ROTATE(PLUS(x[14],x[10]), 9));
					x[ 6] = XOR(x[ 6],ROTATE(PLUS(x[ 2],x[14]),13));
					x[10] = XOR(x[10],ROTATE(PLUS(x[ 6],x[ 2]),18));
					x[ 3] = XOR(x[ 3],ROTATE(PLUS(x[15],x[11]), 7));
					x[ 7] = XOR(x[ 7],ROTATE(PLUS(x[ 3],x[15]), 9));
					x[11] = XOR(x[11],ROTATE(PLUS(x[ 7],x[ 3]),13));
					x[15] = XOR(x[15],ROTATE(PLUS(x[11],x[ 7]),18));
					x[ 1] = XOR(x[ 1],ROTATE(PLUS(x[ 0],x[ 3]), 7));
					x[ 2] = XOR(x[ 2],ROTATE(PLUS(x[ 1],x[ 0]), 9));
					x[ 3] = XOR(x[ 3],ROTATE(PLUS(x[ 2],x[ 1]),13));
					x[ 0] = XOR(x[ 0],ROTATE(PLUS(x[ 3],x[ 2]),18));
					x[ 6] = XOR(x[ 6],ROTATE(PLUS(x[ 5],x[ 4]), 7));
					x[ 7] = XOR(x[ 7],ROTATE(PLUS(x[ 6],x[ 5]), 9));
					x[ 4] = XOR(x[ 4],ROTATE(PLUS(x[ 7],x[ 6]),13));
					x[ 5] = XOR(x[ 5],ROTATE(PLUS(x[ 4],x[ 7]),18));
					x[11] = XOR(x[11],ROTATE(PLUS(x[10],x[ 9]), 7));
					x[ 8] = XOR(x[ 8],ROTATE(PLUS(x[11],x[10]), 9));
					x[ 9] = XOR(x[ 9],ROTATE(PLUS(x[ 8],x[11]),13));
					x[10] = XOR(x[10],ROTATE(PLUS(x[ 9],x[ 8]),18));
					x[12] = XOR(x[12],ROTATE(PLUS(x[15],x[14]), 7));
					x[13] = XOR(x[13],ROTATE(PLUS(x[12],x[15]), 9));
					x[14] = XOR(x[14],ROTATE(PLUS(x[13],x[12]),13));
					x[15] = XOR(x[15],ROTATE(PLUS(x[14],x[13]),18));
				}
				for (i = 0;i < 16;++i) x[i] = PLUS(x[i],input[i]);	
				for (i = 0;i < 16;++i) endian::write_le(((uint32_t*)output) + i, x[i]);
			}

		public:
			salsa_stream_cipher() 
				:
			m_state_changed(true),
				m_have_key(false),
				m_have_iv(false)
			{
			}

			salsa_stream_cipher(const void* key, size_type key_size) 
				:
			m_state_changed(true),
				m_have_key(false),
				m_have_iv(false)
			{
				setkey(key, key_size);
			}

			salsa_stream_cipher(const void* key, size_type key_size,
				const void* iv, size_type iv_size) 
				:
			m_state_changed(true),
				m_have_key(false),
				m_have_iv(false)
			{
				setkey(key, key_size);
				setiv(iv, iv_size);
			}

			template<StreamDirection Direction>
			stream_ctx create()
			{
				if(!m_state_changed) return m_stream_ctx;

				stream_ctx ctx;
				key_setup(ctx);
				ctx.state = stream_ctx_created;

				m_state_changed = false;
				return (m_stream_ctx = ctx);
			}

			void setkey(const void *key, size_type key_size) throw(invalid_key_size)
			{
				BOOST_CRYPTO_CHECK_KEYSIZE(key_size,salsa_stream_cipher);

				std::memcpy(m_key, key, key_size);
				std::memset(m_key+ key_size, 0, max_key_size-key_size);

				if(key_size > 16)
					constants = detail::salsa::sigma;
				else
					constants = detail::salsa::tau;

				m_state_changed = m_have_key = true;
			}

			void setiv(const void* iv, size_type iv_size) throw(invalid_iv_size)
			{
				BOOST_CRYPTO_CHECK_IVSIZE(salsa_stream_cipher);

				std::memcpy(m_iv, iv, iv_size);
				std::memset(m_iv + iv_size, 0, max_iv_size-iv_size);

				m_state_changed = m_have_iv = true;
			}

			void encrypt(void *output, const void* input, size_type input_size)
			{
				create<Encryption>()(output,input,input_size);
			}

			void decrypt(void *output, const void* input, size_type input_size)
			{
				create<Decryption>()(output,input,input_size);
			}
		};

		typedef salsa_stream_cipher<20> salsa20;
		typedef salsa_stream_cipher<12> salsa12;

	} // namespace boost::crypto 
}  // namespace boost


#undef ROTATE
#undef XOR
#undef PLUS
#undef PLUSONE
#
#endif /* BOOST_CRYPTO_SALSA_HPP_INCLUDED */