#ifndef BOOST_CRYPTO_ISO10126_HPP_INCLUDED
#define BOOST_CRYPTO_ISO10126_HPP_INCLUDED
#
#include <stdexcept>
#include <exception>
#include <cstring>
#include <string>
#
#include "crypto.hpp"
#include "padding_traits.hpp"

namespace boost { 
	namespace crypto {

		template<size_type B, typename PRNGT, typename T=byte_t>
		struct iso10126_padding
		{
			typedef PRNGT		prng_type;
			typedef size_t	size_type;

			static prng_type prng;
			static constexpr bool				allways_pad = true;
			static constexpr size_type	min_block_size = 002;
			static constexpr size_type	max_block_size = pow<2,bitsof<T>::value>::value;
			static constexpr size_type	padding_block_size = B;

			// return the size of string with input_size after the padding
			static constexpr size_type output_size(size_type input_size)
			{
				return input_size + (padding_block_size - (input_size % padding_block_size));
			}
			
			static void pad(T* output, const T* input, size_type input_size) throw(std::length_error)
			{
				if(input_size > max_block_size)
					throw std::length_error(std::string("boost::crypto::iso10126_padding::pad() : invalid length"));
				
				T margin  = input_size % padding_block_size;
				T outsize = output_size(input_size);

				if(input != output) memcpy(output, input, input_size);
				for(int i = input_size; i < outsize; i++) output[i] = prng();
				output[padding_block_size-1] = margin;
			}

			// return the size of string with input_size after the unpadding
			static size_type unpad(T* output, const T* input, size_type input_size) throw(bad_padding)
			{
				T margin = input[input_size-1] ;
				if(margin > padding_block_size || margin > input_size)
					throw bad_padding("boost::crypto::iso10126_padding::unpad() : invalid padding");
				
				if(input != output) memcpy(output, input, input_size-margin);
				return input_size-margin;
			}
		};

	} // namepace boost::crypto
} // namespace boost 

#endif /* BOOST_CRYPTO_ISO10126_HPP_INCLUDED */
