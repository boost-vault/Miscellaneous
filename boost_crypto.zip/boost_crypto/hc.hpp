#ifndef BOOST_CRYPTO_HC_HPP_INCLUDED
#define BOOST_CRYPTO_HC_HPP_INCLUDED
#
#include "crypto.hpp"
#include "crypto_rotation.hpp"
#include "stream_cipher.hpp"
#
#ifdef BOOST_MSVC 
#pragma once
#endif

namespace boost { 
	namespace crypto {
		template<size_t N>
		class hc_stream_cipher
		{
			// N should be either 128 or 256, other values is not supported
			BOOST_STATIC_ASSERT((N == 128 || N == 256) == true);
		};

	} // namespace boost::crypto
}  // namespace boost
#endif /* BOOST_CRYPTO_HC_HPP_INCLUDED */
