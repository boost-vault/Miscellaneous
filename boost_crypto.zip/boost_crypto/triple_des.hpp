/*
* Cryptographic API.
*
* DES & Triple DES EDE Cipher Algorithms.
*
* Copyright (c) 2008 Kasra Nassiri <>
* Copyright (c) 2005 Dag Arne Osvik <da@osvik.no>
*
* This program is free software; you can redistribute it and/or modify
* it under the terms of the GNU General Public License as published by
* the Free Software Foundation; either version 2 of the License, or
* (at your option) any later version.
*
*/
#ifndef BOOST_CRYPTO_TRIPLE_DES_HPP_INCLUDED
#define BOOST_CRYPTO_TRIPLE_DES_HPP_INCLUDED
#
#include "crypto.hpp"
#include "crypto_endian.hpp"
#include "crypto_rotation.hpp"
#include "des.hpp"
#define DES_KEY_SIZE						8
#define DES_BLOCK_SIZE					8
#define DES_EXPKEY_WORDS				(rounds*2)
#
#define DES3_EDE_KEY_SIZE				(3 * DES_KEY_SIZE)
#define DES3_EDE_EXPKEY_WORDS		(3 * DES_EXPKEY_WORDS)
#define DES3_EDE_BLOCK_SIZE			DES_BLOCK_SIZE
#
#define ROL(x, r) ((x) = BOOST_ROL32((x), (r)))
#define ROR(x, r) ((x) = BOOST_ROR32((x), (r)))
#
#/* Encryption components: IP, FP, and round function */
#define IP(L, R, T)		\
	using namespace detail::des; \
	ROL(R, 4);		\
	T  = L;			\
	L ^= R;			\
	L &= 0xf0f0f0f0;	\
	R ^= L;			\
	L ^= T;			\
	ROL(R, 12);		\
	T  = L;			\
	L ^= R;			\
	L &= 0xffff0000;	\
	R ^= L;			\
	L ^= T;			\
	ROR(R, 14);		\
	T  = L;			\
	L ^= R;			\
	L &= 0xcccccccc;	\
	R ^= L;			\
	L ^= T;			\
	ROL(R, 6);		\
	T  = L;			\
	L ^= R;			\
	L &= 0xff00ff00;	\
	R ^= L;			\
	L ^= T;			\
	ROR(R, 7);		\
	T  = L;			\
	L ^= R;			\
	L &= 0xaaaaaaaa;	\
	R ^= L;			\
	L ^= T;			\
	ROL(L, 1);
#
#define FP(L, R, T)		\
	ROR(L, 1);		\
	T  = L;			\
	L ^= R;			\
	L &= 0xaaaaaaaa;	\
	R ^= L;			\
	L ^= T;			\
	ROL(R, 7);		\
	T  = L;			\
	L ^= R;			\
	L &= 0xff00ff00;	\
	R ^= L;			\
	L ^= T;			\
	ROR(R, 6);		\
	T  = L;			\
	L ^= R;			\
	L &= 0xcccccccc;	\
	R ^= L;			\
	L ^= T;			\
	ROL(R, 14);		\
	T  = L;			\
	L ^= R;			\
	L &= 0xffff0000;	\
	R ^= L;			\
	L ^= T;			\
	ROR(R, 12);		\
	T  = L;			\
	L ^= R;			\
	L &= 0xf0f0f0f0;	\
	R ^= L;			\
	L ^= T;			\
	ROR(R, 4);
#
#define ROUND(L, R, A, B, K, d)					\
	B = K[0];			A = K[1];	K += d;	\
	B ^= R;				A ^= R;			\
	B &= 0x3f3f3f3f;		ROR(A, 4);		\
	L ^= S8[0xff & B];		A &= 0x3f3f3f3f;	\
	L ^= S6[0xff & (B >> 8)];	B >>= 16;		\
	L ^= S7[0xff & A];					\
	L ^= S5[0xff & (A >> 8)];	A >>= 16;		\
	L ^= S4[0xff & B];					\
	L ^= S2[0xff & (B >> 8)];				\
	L ^= S3[0xff & A];					\
	L ^= S1[0xff & (A >> 8)];
#
#/*
#* PC2 lookup tables are organized as 2 consecutive sets of 4 interleaved
#* tables of 128 elements.  One set is for C_i and the other for D_i, while
#* the 4 interleaved tables correspond to four 7-bit subsets of C_i or D_i.
#*
#* After PC1 each of the variables a,b,c,d contains a 7 bit subset of C_i
#* or D_i in bits 7-1 (bit 0 being the least significant).
#*/
#
#define T1(x) pt[2 * (x) + 0]
#define T2(x) pt[2 * (x) + 1]
#define T3(x) pt[2 * (x) + 2]
#define T4(x) pt[2 * (x) + 3]
#
#define PC2(a, b, c, d) (T4(d) | T3(c) | T2(b) | T1(a))

namespace boost { 
	namespace crypto {
		namespace detail {
			namespace triple_des {
				using namespace des;
			} // namespace triple_des
		} // namespace detail 

		template<size_t NR>
		class triple_des_cipher /* more percisely: DES-EDE3 */
		{
		public:
			typedef byte_t	value_type;
			typedef size_t	size_type;

			static constexpr size_type block_size   = 8;
			static constexpr size_type min_key_size = 0;
			static constexpr size_type max_key_size = 24;
			static constexpr size_type rounds = NR;
			static constexpr char* name() { return "DES-EDE3"; } 

		private:
			// currently only 16 round key schedule is implemented
			BOOST_STATIC_ASSERT(NR == 16);
			BOOST_STATIC_ASSERT((NR % 2) == 0);

			uint32_t m_expkey[DES3_EDE_EXPKEY_WORDS];
			bool m_initialised;

		public:

			triple_des_cipher() : m_initialised(false) { }

			triple_des_cipher(const void*vkey, size_type key_size) : m_initialised(false)
			{
				setkey(key,key_size);
			}

			~triple_des_cipher()
			{
				std::memset(m_expkey, 0, sizeof(m_expkey));
			}

			/*
			* RFC2451:
			*
			*   For DES-EDE3, there is no known need to reject weak or
			*   complementation keys.  Any weakness is obviated by the use of
			*   multiple keys.
			*
			*   However, if the first two or last two independent 64-bit keys are
			*   equal (k1 == k2 or k2 == k3), then the DES3 operation is simply the
			*   same as DES.  Implementers MUST reject keys that exhibit this
			*   property.
			*
			*/
			static constepxr void setkey(const void *key, size_type key_size) throw(invalid_key_size, week_key)
			{
				BOOST_CRYPTO_CHECK_KEYSIZE(key_size,boost::crypto::triple_des_cipher::setkey());

				uint8_t keybuf[max_key_size+1];
				const uint32_t *k = reinterpret_cast<const uint32_t *>(keybuf);

				std::memcpy(keybuf         , key, key_size);
				std::memcpy(keybuf+key_size, 000, max_key_size-key_size);
				keybuf[key_size] = 0x80U;

				uint32_t *expkey = m_expkey;

				detail::triple_des::ekey(expkey, k);	expkey += DES_EXPKEY_WORDS; k += DES_KEY_SIZE/sizeof(uint32_t);
				detail::triple_des::dkey(expkey, k);	expkey += DES_EXPKEY_WORDS; k += DES_KEY_SIZE/sizeof(uint32_t);
				detail::triple_des::ekey(expkey, k);

				m_initialised = true;

				k = reinterpret_cast<const uint32_t *>(keybuf);
				if(!(
					!((k[0] ^ k[2]) | (k[1] ^ k[3])) ||
					!((k[2] ^ k[4]) | (k[3] ^ k[5]))
					))	throw week_key("boost::crypto::triple_des_cipher::setkey() : week key");
			}

			static void encrypt(uint8_t *dst, const uint8_t *src)
			{
				const uint32_t *K = m_expkey;
				register uint32_t L, R, A, B;
				int i;

				L = endian::read_le32(reinterpret_cast<const uint32_t*>(src)+0);
				R = endian::read_le32(reinterpret_cast<const uint32_t*>(src)+1);

				IP(L, R, A);
				for (i = 0; i < rounds/2; i++) {
					ROUND(L, R, A, B, K, 2);
					ROUND(R, L, A, B, K, 2);
				}
				for (i = 0; i < rounds/2; i++) {
					ROUND(R, L, A, B, K, 2);
					ROUND(L, R, A, B, K, 2);
				}
				for (i = 0; i < rounds/2; i++) {
					ROUND(L, R, A, B, K, 2);
					ROUND(R, L, A, B, K, 2);
				}
				FP(R, L, A);

				endian::write_le32(reinterpret_cast<const uint32_t*>(dst)+0, R);
				endian::write_le32(reinterpret_cast<const uint32_t*>(dst)+1, L);
			}

			static void decrypt(uint8_t *dst, const uint8_t *src)
			{
				const uint32_t *K = m_expkey + DES3_EDE_EXPKEY_WORDS - 2;
				register uint32_t L, R, A, B;
				int i;

				L = endian::read_le32(reinterpret_cast<const uint32_t*>(src)+0);
				R = endian::read_le32(reinterpret_cast<const uint32_t*>(src)+1);

				IP(L, R, A);
				for (i = 0; i < rounds/2; i++) {
					ROUND(L, R, A, B, K, -2);
					ROUND(R, L, A, B, K, -2);
				}
				for (i = 0; i < rounds/2; i++) {
					ROUND(R, L, A, B, K, -2);
					ROUND(L, R, A, B, K, -2);
				}
				for (i = 0; i < rounds/2; i++) {
					ROUND(L, R, A, B, K, -2);
					ROUND(R, L, A, B, K, -2);
				}
				FP(R, L, A);

				endian::write_le32(reinterpret_cast<const uint32_t*>(dst)+0, R);
				endian::write_le32(reinterpret_cast<const uint32_t*>(dst)+1, L);
			}
		};



	} // namespace crypto 
} // namespace boost 


#undef  DES_KEY_SIZE						
#undef  DES_BLOCK_SIZE					
#undef  DES_EXPKEY_WORDS				
#
#undef  DES3_EDE_KEY_SIZE				
#undef  DES3_EDE_EXPKEY_WORDS		
#undef  DES3_EDE_BLOCK_SIZE			
#
#undef ROL(x, r) 
#undef ROR(x, r) 
#
#endif /* BOOST_CRYPTO_TRIPLE_DES_HPP_INCLUDED */
