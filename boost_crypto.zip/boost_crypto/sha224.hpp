#ifndef BOOST_CRYPTO_SHA224_HPP_INCLUDED
#define BOOST_CRYPTO_SHA224_HPP_INCLUDED
#
#include "sha2.hpp"

namespace boost {
	namespace crypto {

		typedef sha2_ctx<uint32_t, 28,
			0xc1059ed8UL, 0x367cd507UL, 0x3070dd17UL, 0xf70e5939UL,
			0xffc00b31UL, 0x68581511UL, 0x64f98fa7UL, 0xbefa4fa4UL
		> sha224_ctx;

	} // namespace crypto
} // namespace boost

#endif /* BOOST_CRYPTO_SHA224_HPP_INCLUDED */
