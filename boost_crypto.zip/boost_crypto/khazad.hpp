#ifndef BOOST_CRYPTO_KHAZAD_HPP_INCLUDED
#define BOOST_CRYPTO_KHAZAD_HPP_INCLUDED
#
#include <boost/static_assert.hpp>
#
#include "crypto.hpp"
#include "crypto_buffer.hpp"
#include "block_cipher.hpp"

namespace boost { 
	namespace crypto {
		namespace detail {
			namespace khazad {

				extern constexpr uint64_t T0[256];
				extern constexpr uint64_t T1[256];
				extern constexpr uint64_t T2[256];
				extern constexpr uint64_t T3[256];
				extern constexpr uint64_t T4[256];
				extern constexpr uint64_t T5[256];
				extern constexpr uint64_t T6[256];
				extern constexpr uint64_t T7[256];
				extern constexpr uint64_t c[];

			} // namespace boost::crypto::detail::khazad
		} // namespace boost::crypto::detail 

		template<size_t NR /* # of rounds */>
		class khazad_cipher
		{			
		public:
			typedef size_t size_type;
			typedef byte_t value_type;
			static constexpr size_type rounds = NR;
			static constexpr size_type min_key_size = 0;
			static constexpr size_type max_key_size = 16;
			static constexpr size_type block_size   = 16;
			static constexpr char* name() { return "Khazad"; }

		private:
			// Maximum of 8 rounds is supported
			BOOST_STATIC_ASSERT(NR <= 8);

			bool m_initialised;
			uint64_t E[NR + 1];
			uint64_t D[NR + 1];

			constexpr void crypt(const uint64_t roundKey[rounds + 1], 
				void *ciphertext, const void *plaintext)
			{
				const uint64_t *src = (const uint64_t *)plaintext;
				uint64_t *dst = (uint64_t *)ciphertext;
				int r;
				uint64_t state;

				state = endian::be64_to_cpu(*src) ^ roundKey[0];

				using namespace detail::khazad;

				for (r = 1; r < rounds; r++) {
					state = 
						T0[(int)(state >> 56)       ] ^
						T1[(int)(state >> 48) & 0xff] ^
						T2[(int)(state >> 40) & 0xff] ^
						T3[(int)(state >> 32) & 0xff] ^
						T4[(int)(state >> 24) & 0xff] ^
						T5[(int)(state >> 16) & 0xff] ^
						T6[(int)(state >>  8) & 0xff] ^
						T7[(int)(state      ) & 0xff] ^
						roundKey[r];
				}

				state =
					(T0[(int)(state >> 56)       ] & 0xff00000000000000ULL) ^
					(T1[(int)(state >> 48) & 0xff] & 0x00ff000000000000ULL) ^
					(T2[(int)(state >> 40) & 0xff] & 0x0000ff0000000000ULL) ^
					(T3[(int)(state >> 32) & 0xff] & 0x000000ff00000000ULL) ^
					(T4[(int)(state >> 24) & 0xff] & 0x00000000ff000000ULL) ^
					(T5[(int)(state >> 16) & 0xff] & 0x0000000000ff0000ULL) ^
					(T6[(int)(state >>  8) & 0xff] & 0x000000000000ff00ULL) ^
					(T7[(int)(state      ) & 0xff] & 0x00000000000000ffULL) ^
					roundKey[rounds];

				*dst = endian::cpu_to_be64(state);
			}

		public:
			khazad_cipher() : m_initialised(false) { }
			khazad_cipher(const void* key, size_type key_size) : m_initialised(false) 
			{
				setkey(key, key_size);
			}

			constexpr void setkey(const void* vkey, size_type key_size) throw(invalid_key_size)
			{
				BOOST_CRYPTO_CHECK_KEYSIZE(key_size,boost::crypto::khazad_cipher::setkey());

				int r;
				uint64_t K2, K1;
				const uint64_t *S = T7;
				const uint64_t *key = (const uint64_t *)vkey;

				using namespace detail::khazad;

				/* key is supposed to be 32-bit aligned */
				K2 = endian::be64_to_cpu(key[0]);
				K1 = endian::be64_to_cpu(key[1]);

				/* setup the encrypt key */
				for (r = 0; r <= rounds; r++) {
					this->E[r] = 
						T0[(int)(K1 >> 56)       ] ^
						T1[(int)(K1 >> 48) & 0xff] ^
						T2[(int)(K1 >> 40) & 0xff] ^
						T3[(int)(K1 >> 32) & 0xff] ^
						T4[(int)(K1 >> 24) & 0xff] ^
						T5[(int)(K1 >> 16) & 0xff] ^
						T6[(int)(K1 >>  8) & 0xff] ^
						T7[(int)(K1      ) & 0xff] ^
						c[r] ^ K2;
					K2 = K1; 
					K1 = this->E[r];
				}

				/* Setup the decrypt key */
				this->D[0] = this->E[rounds];
				for (r = 1; r < rounds; r++) {
					K1 = this->E[rounds - r];
					this->D[r] = 
						T0[(int)S[(int)(K1 >> 56)       ] & 0xff] ^
						T1[(int)S[(int)(K1 >> 48) & 0xff] & 0xff] ^
						T2[(int)S[(int)(K1 >> 40) & 0xff] & 0xff] ^
						T3[(int)S[(int)(K1 >> 32) & 0xff] & 0xff] ^
						T4[(int)S[(int)(K1 >> 24) & 0xff] & 0xff] ^
						T5[(int)S[(int)(K1 >> 16) & 0xff] & 0xff] ^
						T6[(int)S[(int)(K1 >>  8) & 0xff] & 0xff] ^
						T7[(int)S[(int)(K1      ) & 0xff] & 0xff];
				}
				this->D[rounds] = this->E[0];

				m_initialised = true;
			}


			constexpr void encrypt(void *ctxt, const void* ptxt) throw (cipher_not_initialised)
			{
				BOOST_CRYPTO_CHECK_STATE(boost::crypto::khazad_cipher::encrypt());

				crypt(this->E, ctxt, ptxt);
			}

			constexpr void decrypt(void *ptxt, const void* ctxt) throw (cipher_not_initialised)
			{
				BOOST_CRYPTO_CHECK_STATE(boost::crypto::khazad_cipher::encrypt());
				crypt(this->D, ptxt, ctxt);
			}
		};

		// 
		typedef khazad_cipher<8> khazad;

	} // namespace boost::crypto
} // namespace boost 

#endif /* BOOST_CRYPTO_KHAZAD_HPP_INCLUDED */
