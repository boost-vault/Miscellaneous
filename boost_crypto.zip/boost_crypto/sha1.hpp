/*
---------------------------------------------------------------------------
Copyright (c) 2002, Dr Brian Gladman, Worcester, UK.   All rights reserved.

LICENSE TERMS

The free distribution and use of this software is allowed (with or without
changes) provided that:

1. source code distributions include the above copyright notice, this
list of conditions and the following disclaimer;

2. binary distributions include the above copyright notice, this list
of conditions and the following disclaimer in their documentation;

3. the name of the copyright holder is not used to endorse products
built using this software without specific written permission.

DISCLAIMER

This software is provided 'as is' with no explicit or implied warranties
in respect of its properties, including, but not limited to, correctness
and/or fitness for purpose.
---------------------------------------------------------------------------
Issue Date: 18/06/2004

This is a byte oriented version of SHA1 that operates on arrays of bytes
stored in memory.
*/
#ifndef BOOST_CRYPTO_SHA1_HPP_INCLDUED
#define BOOST_CRYPTO_SHA1_HPP_INCLDUED
#
#include <cstring>     /* for memcpy() etc.        */
#include "crypto.hpp"
#include "crypto_rotation.hpp"
#
#define rotl32  BOOST_ROL32
#define rotr32  BOOST_ROR32
#
#/* Discovered by Rich Schroeppel and Colin Plumb   */
#define ch(x,y,z)       ((z) ^ ((x) & ((y) ^ (z))))
#define parity(x,y,z)   ((x) ^ (y) ^ (z))
#define maj(x,y,z)      (((x) & (y)) | ((z) & ((x) ^ (y))))
#
#define q(v,n)  v##n
#
#define one_cycle(v,a,b,c,d,e,f,k,h)\
	q(v,e) += rotr32(q(v,a),27) +     \
	f(q(v,b),q(v,c),q(v,d)) + k + h;  \
	q(v,b)  = rotr32(q(v,b), 2)
#
#define five_cycle(v,f,k,i)               \
	one_cycle(v, 0,1,2,3,4, f,k,hf(i  ));   \
	one_cycle(v, 4,0,1,2,3, f,k,hf(i+1));   \
	one_cycle(v, 3,4,0,1,2, f,k,hf(i+2));   \
	one_cycle(v, 2,3,4,0,1, f,k,hf(i+3));   \
	one_cycle(v, 1,2,3,4,0, f,k,hf(i+4))

namespace boost {
	namespace crypto {

		class sha1_ctx
		{
		public:
			typedef uint8_t  char_type;
			typedef uint32_t word_type;
			typedef size_t   size_type;

			/* size of the digest */
			static constexpr size_type digest_size       = 16;

			/* size of the internal state */
			static constexpr size_type state_size        = 16;

			/* minimum required size of each input block */
			static constexpr size_type transform_size    = 64;

			sha1_ctx() 
			{
				create(); 
			}

			sha1_ctx& operator = (sha1_ctx& rhs)
			{
				m_state = rhs.m_state;
				m_message_bits = rhs.m_message_bits;

				std::memcpy(m_buf, rhs.m_buf   , state_size);
				std::memcpy(m_buf, rhs.m_digest, digest_size);

				return (*this);
			}

			~sha1_ctx()
			{
				std::memset(m_buf, 0, sizeof(m_buf));
				std::memset(m_digest, 0, sizeof(m_digest));
				std::memset(&m_message_bits, 0, sizeof(m_message_bits));
			}

			// create a new stream, destroying any previously created streams
			sha1_ctx& create() throw()
			{
				/* load magic initialization constants. */
				m_message_bits = 0x00000000;
				m_buf[0]       = 0x67452301;
				m_buf[1]       = 0xefcdab89;
				m_buf[2]       = 0x98badcfe;
				m_buf[3]       = 0x10325476;
				m_buf[4]       = 0xc3d2e1f0;
				return (*this);
			}

			/* transform using previously set buffer, or assign a new pointer */
			/* [buf] should point to memory of size at least [transform_size] */
			sha1_ctx& transform (const void* input) throw(bad_hash_state)
			{
				if(m_state != hash_function_processing)
					if(m_state == hash_function_created)		
						m_state = hash_function_processing;
					else if(m_state != hash_function_finalising)
						throw bad_hash_state("md5_ctx::transform() : could not transform an empty stream");

				uint32_t w[16];
				uint32_t v0, v1, v2, v3, v4;

				v0 = m_buf[0]; v1 = m_buf[1];
				v2 = m_buf[2]; v3 = m_buf[3];
				v4 = m_buf[4];

				std::memcpy(w, input, transform_size);

#define hf(i)   w[i]

				five_cycle(v, ch, 0x5a827999,  0);
				five_cycle(v, ch, 0x5a827999,  5);
				five_cycle(v, ch, 0x5a827999, 10);
				one_cycle(v,0,1,2,3,4, ch, 0x5a827999, hf(15)); \

#undef  hf
#define hf(i) (w[(i) & 15] = rotl32(     \
	w[((i) + 13) & 15] ^ w[((i) + 8) & 15] \
	^ w[((i) +  2) & 15] ^ w[(i) & 15], 1))

					one_cycle(v,4,0,1,2,3, ch, 0x5a827999, hf(16));
				one_cycle(v,3,4,0,1,2, ch, 0x5a827999, hf(17));
				one_cycle(v,2,3,4,0,1, ch, 0x5a827999, hf(18));
				one_cycle(v,1,2,3,4,0, ch, 0x5a827999, hf(19));

				five_cycle(v, parity, 0x6ed9eba1,  20);
				five_cycle(v, parity, 0x6ed9eba1,  25);
				five_cycle(v, parity, 0x6ed9eba1,  30);
				five_cycle(v, parity, 0x6ed9eba1,  35);

				five_cycle(v, maj, 0x8f1bbcdc,  40);
				five_cycle(v, maj, 0x8f1bbcdc,  45);
				five_cycle(v, maj, 0x8f1bbcdc,  50);
				five_cycle(v, maj, 0x8f1bbcdc,  55);

				five_cycle(v, parity, 0xca62c1d6,  60);
				five_cycle(v, parity, 0xca62c1d6,  65);
				five_cycle(v, parity, 0xca62c1d6,  70);
				five_cycle(v, parity, 0xca62c1d6,  75);

				m_buf[0] += v0; m_buf[1] += v1;
				m_buf[2] += v2; m_buf[3] += v3;
				m_buf[4] += v4;

				return (*this);
			}


			// [input] is and in/complete buffer with size of [input_size]
			// returns a const pointer to the digest
			sha1_ctx& finalise(const void* input, size_type input_bits) throw(bad_hash_state)
			{		
				m_state = hash_function_finalising;

				uint8_t wbuf[transform_size];
				size_type input_size = input_bits / 8;

				assert((input_bits & 64) == (m_message_bits & 63));

				// copy input
				bitcpy(wbuf            , input         , input_bits);					
				std::memset(wbuf+input_size , 0, transform_size-input_size);

				// append a '1' bit
				setbyte(wbuf+input_size, input_bits & 7, 0x80);

				// see if there is enough space on buffer
				if(input_size > 55)
				{
					if(input_size < 60)		*reinterpret_cast<uint32_t*>(wbuf+4*15) = 0;
					transform(wbuf);
					std::memset(wbuf, 0, 64);
				}

				endian::write_be64(wbuf+56, m_message_bits);

				transform(wbuf);

				/* store buffer in digest */
				for (int i = 0; i < 5; i++)				
					endian::write_le32(reinterpret_cast<uint32_t*>(m_digest)+i, m_buf[i]);

				m_state = hash_function_finished;

				return (*this);
			}

			/* 
			* get the pointer to state buffer
			*/
			const word_type* operator () () const
			{
				return m_buf;
			}

			/*
			* return the digest
			*/
			const void *digest() const throw(bad_hash_state)
			{
				if(m_state == hash_function_finished)
					return m_digest; 
				else
					throw bad_hash_state("sha1_ctx::digest() : digest is not computed");
			}

		private:				
			// state of the m_buf instance
			hash_function_state m_state;

			// current buffer
			word_type	m_buf[5];
			uint64_t	m_message_bits; /* total _bits_ handled mod 2^64 */
			uint8_t		m_digest[16];		/* working digest */
		};
	} // namespace crypto
}// namespace boost 


#undef rotl32
#undef rotr32
#
#undef ch
#undef parity
#undef maj
#undef q
#undef one_cycle
#undef five_cycle
#
#endif /* BOOST_CRYPTO_SHA1_HPP_INCLDUED */
