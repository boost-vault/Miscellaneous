//#ifndef BOOST_CRYPTO_HC256_HPP_INCLUDED
//#define BOOST_CRYPTO_HC256_HPP_INCLUDED
//#
//#include "crypto.hpp"
//#include "crypto_rotation.hpp"
//#include "hc.hpp"
//
//#define f1(x)    (BOOST_ROR32((x),7) ^ BOOST_ROR32((x),18) ^ ((x) >> 3))
//
//#define f2(x)    (BOOST_ROR32((x),17) ^ BOOST_ROR32((x),19) ^ ((x) >> 10))
//
//#define h1(u) \
//	this->Q[(u) & 0xff]+ \
//	this->Q[256+((u >> 8) & 0xff)]+\
//	this->Q[512+((u >> 16) & 0xff)]+\
//	this->Q[768+((u >> 24) & 0xff)];
//
//#define h2(u)  \
//	this->P[(u) & 0xff]+ \
//	this->P[256+((u >> 8) & 0xff)]+\
//	this->P[512+((u >> 16) & 0xff)]+\
//	this->P[768+((u >> 24) & 0xff)];
//
//namespace boost { 
//	namespace crypto {
//		namespace detail {
//		} // namespace boost::crypto::detail 
//
//		template<> 
//		hc_stream_cipher<256>
//		{
//		public:
//			typedef size_t size_type;
//			static constexpr size_type min_key_size = 0;
//			static constexpr size_type max_key_size = 32;
//			static constexpr size_type min_iv_size = 0;
//			static constexpr size_type max_iv_size = 32;
//
//		private:
//			bool m_initialised;
//			uint32_t P[1024];
//			uint32_t Q[1024];
//			uint16_t counter2048;
//			uint32_t key[8];
//			uint32_t iv[8];
//
//			uint32_t generate() /*one step of the cipher*/
//			{
//				uint32_t i,i3, i10, i12, i1023;
//				uint32_t output;
//
//				i   = this->counter2048 & 0x3ff;
//				i3  = (i - 3) & 0x3ff;
//				i10 = (i - 10) & 0x3ff;
//				i12 = (i - 12) & 0x3ff;
//				i1023 = (i - 1023) & 0x3ff;
//
//				if (this->counter2048 < 1024) {
//					this->P[i] = this->P[i] + this->P[i10] + (BOOST_ROR32(this->P[i3],10)^BOOST_ROR32(this->P[i1023],23))+this->Q[(this->P[i3]^this->P[i1023])&0x3ff];
//					output = h1(ctx,this->P[i12]) ^ this->P[i];
//				}
//				else {                                   
//					this->Q[i] = this->Q[i] + this->Q[i10] + (BOOST_ROR32(this->Q[i3],10)^BOOST_ROR32(this->Q[i1023],23))+this->P[(this->Q[i3]^this->Q[i1023])&0x3ff];
//					output = h2(ctx, this->Q[i12]) ^ this->Q[i];
//				}
//				this->counter2048 = (this->counter2048+1) & 0x7ff;
//				return (output);
//			}
//
//			void transform(void* output, const void* input, size_type input_size)                /* Message length in bytes. */ 
//			{
//				uint8_t *in, *out;
//				uint32_t i, j, msglen32, keystreamword;
//
//				out= reinterpret_cast<uint8_t*>(output);
//				in = reinterpret_cast<const uint8_t*>(input);
//
//				msglen32 = in_size >> 2;
//
//				for (i = 0; i < msglen32; i++) { 
//					keystreamword = generate(ctx);                 /*generate a 32-bit word*/
//					for (j = 0; j < 4; j++) {
//						*out = *in ^ keystreamword;       /*encrypt one byte*/
//						out += 1; 
//						in +=1;
//						keystreamword >>= sizeof(uint8_t);
//					}
//				}  
//
//				keystreamword = generate(ctx);
//				for (i = 0; i < (in_size & 3); i++) {
//					*out = *in ^ keystreamword;       /*encrypt one byte*/
//					out += 1; 
//					in +=1;
//					keystreamword >>= sizeof(uint8_t);
//				}
//			}
//
//		public:
//			hc_stream_cipher() { }
//
//			void setkey(const uint8_t* key, size_type key_size) throw (std::length_error)
//			{ 
//				if(!(min_key_size <= key_size && key_size <= max_key_size))
//					throw std::length_error(std::string("hc256_stream_cipher::setkey() : invalid m_key size"));
//
//				uint32_t i;  
//
//				this->keysize = keysize >> 3;
//				this->ivsize = ivsize >> 3;
//
//				for (i = 0; i < 8; i++) m_key[i] = 0;
//				for (i = 0; (i < this->keysize) & (i < 32); i++) {
//					m_key[i >> 2] =  m_key[i >> 2] | m_key[i];
//					m_key[i >> 2] = BOOST_ROL32(m_key[i >> 2],8);
//				}
//
//			} /* initialize the key, save the iv size*/
//
//			void setiv(const uint8_t* iv, size_type iv_size)  throw (std::length_error)
//			{ 
//				if(!(min_m_iv_size <= m_iv_size && m_iv_size <= max_m_iv_size))
//					throw std::length_error(std::string("hc256_stream_cipher::setm_iv() : invalid m_key size"));
//
//				uint32_t W[2560],i;
//
//				/* initialize the m_iv */
//				for (i = 0; i < 8; i++) this->m_iv[i] = 0;
//				for (i = 0; (i < this->m_ivsize) & (i < 32); i++) {
//					this->m_iv[i >> 2] =  this->m_iv[i >> 2] | m_iv[i];
//					this->m_iv[i >> 2] = BOOST_ROL32(this->m_iv[i >> 2],8);
//				}
//
//				/* setup the table P and Q */ 
//
//				for (i = 0; i < 8;  i++) W[i] = this->m_key[i];
//				for (i = 8; i < 16; i++) W[i] = this->m_iv[i-8];
//
//				for (i = 16; i < 2560; i++) W[i] = f2(W[i-2]) + W[i-7] + f1(W[i-15]) + W[i-16]+i; 
//
//				for (i = 0; i < 1024; i++)  this->P[i] = W[i+512];
//				for (i = 0; i < 1024; i++)  this->Q[i] = W[i+1536];
//
//				this->counter2048 = 0;
//
//				/* run the cipher 4096 steps before generating the output */
//				for (i = 0; i < 4096; i++)  generate(ctx);  
//			}
//
//			constexpr void encrypt(void* output, const void* input, size_type input_size) throw(bad_cipher_state)
//			{
//				if(!m_initialised)
//					throw bad_cipher_state("hc256_stream_cipher::encrypt() : !initialised");
//
//				transform(output, input, input_size);
//			}
//
//			constexpr void decrypt(void* output, const void* input, size_type input_size) throw(bad_cipher_state)
//			{
//				if(!m_initialised)
//					throw bad_cipher_state("hc256_stream_cipher::encrypt() : !initialised");
//
//				transform(output, input, input_size);
//			}
//
//		};
//
//		typedef hc_stream_cipher<256> hc256;
//
//	} // namespace boost::crypto
//}  // namespace boost
//
//#endif /* BOOST_CRYPTO_HC256_HPP_INCLUDED */
