#ifndef _BOOST_CRYPTO_FIXED_BUFFER_HPP_INCLUDED
#define _BOOST_CRYPTO_FIXED_BUFFER_HPP_INCLUDED

#include "crypto.hpp"

namespace boost {
	namespace crypto {

		template<typename T=byte_t, size_t SizeT>
		class fixed_buffer
		{			
			T elem[size];
		public:
			typedef T value_type;
			static constexpr size_t size = SizeT;

			template<typename U>
			fixed_buffer(U *buffer, size_t count)
			{
				size_t amount = min(size, count);
				std::memcpy(elem			 , buffer, amount);
				std::memset(elem+amount, 000000, size-amount);
			}

			operator T* () const 
			{
				return elem;
			}
		};
		
		template<size_t SizeT,typename T=byte_t>
		class weak_fixed_buffer
		{			
			T* elem;
		public:
			typedef T value_type;
			static constexpr size_t size = SizeT;

			template<typename U>
			fixed_buffer(T* buffer, U *buffer, size_t count)
			{
				size_t amount = min(size, count);
				std::memcpy(elem			 , buffer, amount);
				std::memset(elem+amount, 000000, size-amount);
			}

			operator T* () const 
			{
				return elem;
			}
		};

	}
}

#endif /* _BOOST_CRYPTO_FIXED_BUFFER_HPP_INCLUDED */
