#ifndef BOOST_CRYPTO_TEA_HPP_INCLUDED
#define BOOST_CRYPTO_TEA_HPP_INCLUDED
#
#include "crypto.hpp"
#include "crypto_endian.hpp"

namespace boost { 
	namespace crypto {

		template<size_t NR=32>
		class tea_cipher
		{
		public:
			typedef byte_t   value_type;
			typedef uint32_t word_type;
			typedef size_t   size_type;

			static constexpr size_type rounds = NR;
			static constexpr size_type block_size   = 8;
			static constexpr size_type min_key_size = 0;
			static constexpr size_type max_key_size = 16;
			static constexpr char* name() { return "TEA"; }

		private:
			BOOST_STATIC_ASSERT((rounds % 4) == 0);
			uint32_t m_key[4];
			bool m_initialised;

		public:
			tea_cipher() : m_initialised(false)
			{
			}

			tea_cipher(const void* key, size_type key_size) : m_initalised(false)
			{
				setkey(key,key_size);
			}

			void setkey(const void* key, size_type key_size) throw(invalid_key_size)
			{
				BOOST_CRYPTO_CHECK_KEYSIZE(key_size,boost::crypto::tea_cipher::setkey());

				std::memcpy(m_key         , key, key_size);
				std::memset(m_key+key_size, 000, max_key_size-key_size);

				// correct endian allignment
				for(int i=0; i<4; i++) endian::ensure_le(m_key+i);

				m_initialised = true;
			}


			void encrypt(void* ctxt, const void* ptxt) throw(cipher_not_initialised)
			{
				BOOST_CRYPTO_CHECK_STATE(boost::crypto::tea_cipher::encrypt());

				register uint32_t v0,v1,sum=0;
				register uint32_t k0,k1,k2,k3;

				v0 = endian::read_le32(reinterpret_cast<const uint32_t*>(ptxt)+0);
				v1 = endian::read_le32(reinterpret_cast<const uint32_t*>(ptxt)+1);		
				k0=m_key[0], k1=m_key[1], k2=m_key[2], k3=m_key[3];   /* cache key */

				for (int i=0; i<rounds; i += 4) 
				{
					sum += UINT32_C(0x9e3779b9);
					v0 += ((v1<<4) + k0) ^ (v1 + sum) ^ ((v1>>5) + k1);
					v1 += ((v0<<4) + k2) ^ (v0 + sum) ^ ((v0>>5) + k3);  

					sum += UINT32_C(0x9e3779b9);
					v0 += ((v1<<4) + k0) ^ (v1 + sum) ^ ((v1>>5) + k1);
					v1 += ((v0<<4) + k2) ^ (v0 + sum) ^ ((v0>>5) + k3);  

					sum += UINT32_C(0x9e3779b9);
					v0 += ((v1<<4) + k0) ^ (v1 + sum) ^ ((v1>>5) + k1);
					v1 += ((v0<<4) + k2) ^ (v0 + sum) ^ ((v0>>5) + k3);  

					sum += UINT32_C(0x9e3779b9);
					v0 += ((v1<<4) + k0) ^ (v1 + sum) ^ ((v1>>5) + k1);
					v1 += ((v0<<4) + k2) ^ (v0 + sum) ^ ((v0>>5) + k3);  					 
				}

				endian::write_le32(reinterpret_cast<uint32_t*>(ctxt)+0, v0);
				endian::write_le32(reinterpret_cast<uint32_t*>(ctxt)+1, v1);
			}

			void decrypt(void* ptxt, const void* ctxt) throw(cipher_not_initialised)
			{
				BOOST_CRYPTO_CHECK_STATE(boost::crypto::tea_cipher::decrypt());

				register uint32_t v0,v1,sum=UINT32_C(0x9e3779b9)*rounds;
				register uint32_t k0,k1,k2,k3;

				v0 = endian::read_le32(reinterpret_cast<const uint32_t*>(ctxt)+0);
				v1 = endian::read_le32(reinterpret_cast<const uint32_t*>(ctxt)+1);	
				k0=m_key[0], k1=m_key[1], k2=m_key[2], k3=m_key[3];   /* cache key */

				for (int i=0; i<rounds; i += 4)
				{
					v1 -= ((v0<<4) + k2) ^ (v0 + sum) ^ ((v0>>5) + k3);
					v0 -= ((v1<<4) + k0) ^ (v1 + sum) ^ ((v1>>5) + k1);
					sum -= UINT32_C(0x9e3779b9);                                   

					v1 -= ((v0<<4) + k2) ^ (v0 + sum) ^ ((v0>>5) + k3);
					v0 -= ((v1<<4) + k0) ^ (v1 + sum) ^ ((v1>>5) + k1);
					sum -= UINT32_C(0x9e3779b9);                                   

					v1 -= ((v0<<4) + k2) ^ (v0 + sum) ^ ((v0>>5) + k3);
					v0 -= ((v1<<4) + k0) ^ (v1 + sum) ^ ((v1>>5) + k1);
					sum -= UINT32_C(0x9e3779b9);                                   

					v1 -= ((v0<<4) + k2) ^ (v0 + sum) ^ ((v0>>5) + k3);
					v0 -= ((v1<<4) + k0) ^ (v1 + sum) ^ ((v1>>5) + k1);
					sum -= UINT32_C(0x9e3779b9);    
				}

				endian::write_le32(reinterpret_cast<uint32_t*>(ptxt)+0, v0);
				endian::write_le32(reinterpret_cast<uint32_t*>(ptxt)+1, v1);
			}
		};

		typedef tea_cipher<32> tea;

	} // namespace crypto
} // namespace boost

#endif /* BOOST_CRYPTO_TEA_HPP_INCLUDED */
