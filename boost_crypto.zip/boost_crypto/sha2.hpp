/*
---------------------------------------------------------------------------
Copyright (c) 2002-2008, Kasra Nassiri, UK. All rights reserved.
Copyright (c) 2002, Dr Brian Gladman, Worcester, UK.   All rights reserved.

LICENSE TERMS

The free distribution and use of this software is allowed (with or without
changes) provided that:

1. source code distributions include the above copyright notice, this
list of conditions and the following disclaimer;

2. binary distributions include the above copyright notice, this list
of conditions and the following disclaimer in their documentation;

3. the name of the copyright holder is not used to endorse products
built using this software without specific written permission.

DISCLAIMER

This software is provided 'as is' with no explicit or implied warranties
in respect of its properties, including, but not limited to, correctness
and/or fitness for purpose.
---------------------------------------------------------------------------
Issue Date: 01/08/2005
*/
#ifndef BOOST_CRYPTO_SHA2_HPP_INCLUDED
#define BOOST_CRYPTO_SHA2_HPP_INCLUDED
#
#include "crypto.hpp"
#include "crypto_endian.hpp"
#include "hash_function.hpp"
#
#if defined( _MSC_VER ) && ( _MSC_VER > 800 )
#pragma intrinsic(memcpy)
#endif
#
#define rotl32				BOOST_ROL32
#define rotr32			  BOOST_ROR32
#
#if !defined(bswap_32)
#define bswap_32(x) ((rotr32((x), 24) & 0x00ff00ff) | (rotr32((x), 8) & 0xff00ff00))
#endif
#
#/* Thanks to Rich Schroeppel and Colin Plumb for the following      */
#define ch(x,y,z)       ((z) ^ ((x) & ((y) ^ (z))))
#define maj(x,y,z)      (((x) & (y)) | ((z) & ((x) ^ (y))))
#
#/* round transforms for SHA256 and SHA512 compression functions */
#
#define vf(n,i) v[(n - i) & 7]
#
#define hf(i) (p[i & 15] += \
	g_1(p[(i + 14) & 15]) + p[(i + 9) & 15] + g_0(p[(i + 1) & 15]))
#
#define v_cycle(i,j)                                \
	vf(7,i) += (j ? hf(i) : p[i]) + k_0[i+j]        \
	+ s_1(vf(4,i)) + ch(vf(4,i),vf(5,i),vf(6,i));   \
	vf(3,i) += vf(7,i);                             \
	vf(7,i) += s_0(vf(0,i))+ maj(vf(0,i),vf(1,i),vf(2,i))
#
#
#
#define SHA224_DIGEST_SIZE		28
#define SHA224_BLOCK_SIZE			64
#define SHA256_DIGEST_SIZE		32
#define SHA256_BLOCK_SIZE			64
#define SHA384_DIGEST_SIZE		48
#define SHA384_BLOCK_SIZE			128
#define SHA512_DIGEST_SIZE		64
#define SHA512_BLOCK_SIZE			128
#define SHA2_MAX_DIGEST_SIZE	SHA512_DIGEST_SIZE
#
#
namespace boost {
	namespace crypto {
		namespace detail {
			namespace sha2 {

				static constexpr uint32_t k256[64] =
				{  
					0x428a2f98ul, 0x71374491ul, 0xb5c0fbcful, 0xe9b5dba5ul,
					0x3956c25bul, 0x59f111f1ul, 0x923f82a4ul, 0xab1c5ed5ul,
					0xd807aa98ul, 0x12835b01ul, 0x243185beul, 0x550c7dc3ul,
					0x72be5d74ul, 0x80deb1feul, 0x9bdc06a7ul, 0xc19bf174ul,
					0xe49b69c1ul, 0xefbe4786ul, 0x0fc19dc6ul, 0x240ca1ccul,
					0x2de92c6ful, 0x4a7484aaul, 0x5cb0a9dcul, 0x76f988daul,
					0x983e5152ul, 0xa831c66dul, 0xb00327c8ul, 0xbf597fc7ul,
					0xc6e00bf3ul, 0xd5a79147ul, 0x06ca6351ul, 0x14292967ul,
					0x27b70a85ul, 0x2e1b2138ul, 0x4d2c6dfcul, 0x53380d13ul,
					0x650a7354ul, 0x766a0abbul, 0x81c2c92eul, 0x92722c85ul,
					0xa2bfe8a1ul, 0xa81a664bul, 0xc24b8b70ul, 0xc76c51a3ul,
					0xd192e819ul, 0xd6990624ul, 0xf40e3585ul, 0x106aa070ul,
					0x19a4c116ul, 0x1e376c08ul, 0x2748774cul, 0x34b0bcb5ul,
					0x391c0cb3ul, 0x4ed8aa4aul, 0x5b9cca4ful, 0x682e6ff3ul,
					0x748f82eeul, 0x78a5636ful, 0x84c87814ul, 0x8cc70208ul,
					0x90befffaul, 0xa4506cebul, 0xbef9a3f7ul, 0xc67178f2ul,
				};

				const uint64_t  k512[80] =
				{
					UINT64_C(0x428a2f98d728ae22), UINT64_C(0x7137449123ef65cd),
					UINT64_C(0xb5c0fbcfec4d3b2f), UINT64_C(0xe9b5dba58189dbbc),
					UINT64_C(0x3956c25bf348b538), UINT64_C(0x59f111f1b605d019),
					UINT64_C(0x923f82a4af194f9b), UINT64_C(0xab1c5ed5da6d8118),
					UINT64_C(0xd807aa98a3030242), UINT64_C(0x12835b0145706fbe),
					UINT64_C(0x243185be4ee4b28c), UINT64_C(0x550c7dc3d5ffb4e2),
					UINT64_C(0x72be5d74f27b896f), UINT64_C(0x80deb1fe3b1696b1),
					UINT64_C(0x9bdc06a725c71235), UINT64_C(0xc19bf174cf692694),
					UINT64_C(0xe49b69c19ef14ad2), UINT64_C(0xefbe4786384f25e3),
					UINT64_C(0x0fc19dc68b8cd5b5), UINT64_C(0x240ca1cc77ac9c65),
					UINT64_C(0x2de92c6f592b0275), UINT64_C(0x4a7484aa6ea6e483),
					UINT64_C(0x5cb0a9dcbd41fbd4), UINT64_C(0x76f988da831153b5),
					UINT64_C(0x983e5152ee66dfab), UINT64_C(0xa831c66d2db43210),
					UINT64_C(0xb00327c898fb213f), UINT64_C(0xbf597fc7beef0ee4),
					UINT64_C(0xc6e00bf33da88fc2), UINT64_C(0xd5a79147930aa725),
					UINT64_C(0x06ca6351e003826f), UINT64_C(0x142929670a0e6e70),
					UINT64_C(0x27b70a8546d22ffc), UINT64_C(0x2e1b21385c26c926),
					UINT64_C(0x4d2c6dfc5ac42aed), UINT64_C(0x53380d139d95b3df),
					UINT64_C(0x650a73548baf63de), UINT64_C(0x766a0abb3c77b2a8),
					UINT64_C(0x81c2c92e47edaee6), UINT64_C(0x92722c851482353b),
					UINT64_C(0xa2bfe8a14cf10364), UINT64_C(0xa81a664bbc423001),
					UINT64_C(0xc24b8b70d0f89791), UINT64_C(0xc76c51a30654be30),
					UINT64_C(0xd192e819d6ef5218), UINT64_C(0xd69906245565a910),
					UINT64_C(0xf40e35855771202a), UINT64_C(0x106aa07032bbd1b8),
					UINT64_C(0x19a4c116b8d2d0c8), UINT64_C(0x1e376c085141ab53),
					UINT64_C(0x2748774cdf8eeb99), UINT64_C(0x34b0bcb5e19b48a8),
					UINT64_C(0x391c0cb3c5c95a63), UINT64_C(0x4ed8aa4ae3418acb),
					UINT64_C(0x5b9cca4f7763e373), UINT64_C(0x682e6ff3d6b2b8a3),
					UINT64_C(0x748f82ee5defb2fc), UINT64_C(0x78a5636f43172f60),
					UINT64_C(0x84c87814a1f0ab72), UINT64_C(0x8cc702081a6439ec),
					UINT64_C(0x90befffa23631e28), UINT64_C(0xa4506cebde82bde9),
					UINT64_C(0xbef9a3f7b2c67915), UINT64_C(0xc67178f2e372532b),
					UINT64_C(0xca273eceea26619c), UINT64_C(0xd186b8c721c0c207),
					UINT64_C(0xeada7dd6cde0eb1e), UINT64_C(0xf57d4f7fee6ed178),
					UINT64_C(0x06f067aa72176fba), UINT64_C(0x0a637dc5a2c898a6),
					UINT64_C(0x113f9804bef90dae), UINT64_C(0x1b710b35131c471b),
					UINT64_C(0x28db77f523047d84), UINT64_C(0x32caab7b40c72493),
					UINT64_C(0x3c9ebe0a15c9bebc), UINT64_C(0x431d67c49c100d4c),
					UINT64_C(0x4cc5d4becb3e42b6), UINT64_C(0x597f299cfc657e2a),
					UINT64_C(0x5fcb6fab3ad6faec), UINT64_C(0x6c44198c4a475817)
				};
			} // namespace sha2
		} // namespace detail


		/* generic implementation of sha-2 algorithms */
		template<typename T, T DS, T TT0, T TT1, T TT2, T TT3, T TT4, T TT5, T TT6, T TT7>
		class sha2_ctx;

#		define SHA256_MASK (SHA256_BLOCK_SIZE - 1)
#
#		ifdef BOOST_LITTLE_ENDIAN
#		define bsw_32(p,n) \
		{ int _i = (n); while(_i--) ((uint32_t*)p)[_i] = bswap_32(((uint32_t*)p)[_i]); }
#		else
#		define bsw_32(p,n)
#		endif
#
#		define s_0(x)  (rotr32((x),  2) ^ rotr32((x), 13) ^ rotr32((x), 22))
#		define s_1(x)  (rotr32((x),  6) ^ rotr32((x), 11) ^ rotr32((x), 25))
#		define g_0(x)  (rotr32((x),  7) ^ rotr32((x), 18) ^ ((x) >>  3))
#		define g_1(x)  (rotr32((x), 17) ^ rotr32((x), 19) ^ ((x) >> 10))
#		define k_0     k256
#
#/* rotated SHA256 round definition. Rather than swapping variables as in    */
#/* FIPS-180, different variables are 'rotated' on each round, returning     */
#/* to their starting positions every eight rounds                           */
#
#		define q(n)  v##n
#
#		define one_cycle(a,b,c,d,e,f,g,h,k,w)  \
	q(h) += s_1(q(e)) + ch(q(e), q(f), q(g)) + k + w; \
	q(d) += q(h); q(h) += s_0(q(a)) + maj(q(a), q(b), q(c))

		// 32-bit algorithms 
		template<uint32_t DS, uint32_t TT0, uint32_t TT1, uint32_t TT2, uint32_t TT3, uint32_t TT4, uint32_t TT5, uint32_t TT6, uint32_t TT7>
		class sha2_ctx<uint32_t, DS, TT0,TT1,TT2,TT3,TT4,TT5,TT6,TT7>
		{
		public:
			typedef uint8_t  char_type;
			typedef uint32_t word_type;
			typedef size_t   size_type;

			/* size of the digest */
			static constexpr size_type digest_size       = DS;

			/* size of the internal state */
			static constexpr size_type state_size        = 32;

			/* minimum required size of each input block */
			static constexpr size_type transform_size    = 64;

			sha2_ctx() { create(); }
			sha2_ctx& operator = (sha2_ctx& rhs)
			{
				m_state = rhs.m_state;
				memcpy(m_message_bits, rhs.m_message_bits, 8);

				std::memcpy(m_buf, rhs.m_buf   , state_size);
				std::memcpy(m_buf, rhs.m_digest, digest_size);

				return (*this);
			}


			~sha2_ctx()
			{
				std::memset(m_buf, 0, sizeof(m_buf));
				std::memset(m_digest, 0, sizeof(m_digest));
				std::memset(&m_message_bits, 0, sizeof(m_message_bits));
			}

			void create() throw()
			{
				m_message_bits[0] = m_message_bits[1] = 0;
				m_buf[0] = TT0;
				m_buf[1] = TT1;
				m_buf[2] = TT2;
				m_buf[3] = TT3;
				m_buf[4] = TT4;
				m_buf[5] = TT5;
				m_buf[6] = TT6;
				m_buf[7] = TT7;
			}

			void finalise(const void* input, size_type input_bits) throw(bad_hash_state)
			{
				m_state = hash_function_finalising;

				if( (m_message_bits[0] += bits_to_bytes(input_bits)) < bits_to_bytes(input_bits))
					m_message_bits[1]++;
				
				uint32_t wbuf[16];
				uint32_t    i = (m_message_bits[0] & (SHA256_BLOCK_SIZE-1));

				bitcpy(wbuf, input, input_bits);

				endian::ensure_be(wbuf, (i + 7) >> 3);
				
				wbuf[i >> 2] &= UINT32_C(0xffffff80) << 8 * (~i & 7);
				wbuf[i >> 2] |= UINT32_C(0x00000080) << 8 * (~i & 7);

				if(i > SHA256_BLOCK_SIZE - 9)
				{
					if(i < 60) wbuf[15] = 0;
					transform(wbuf);
					i = 0;
				}
				else
					i = (i >> 2) + 1;

				while(i < 14)     wbuf[i++] = 0;

				wbuf[14] = (m_message_bits[1] << 3) | (m_message_bits[0] >> 29);
				wbuf[15] = m_message_bits[0] << 3;
				transform(wbuf);

				for(i = 0; i < digest_size/4; i++)
					endian::write_be32(m_digest+4*i, m_buf[i]);

				m_state = hash_function_finished;
			}

			void transform(const void* input) throw(bad_hash_state)
			{
				if(m_state != hash_function_processing)
					if(m_state == hash_function_created)		
						m_state = hash_function_processing;
					else if(m_state != hash_function_finalising)
						throw bad_hash_state("sha2_ctx::transform() : could not transform an empty stream");

				using namespace detail::sha2;

				uint32_t p[16],v0,v1,v2,v3,v4,v5,v6,v7;
				memcpy(p, input, transform_size);

				v0 = this->m_buf[0]; v1 = this->m_buf[1];
				v2 = this->m_buf[2]; v3 = this->m_buf[3];
				v4 = this->m_buf[4]; v5 = this->m_buf[5];
				v6 = this->m_buf[6]; v7 = this->m_buf[7];

				if( (m_message_bits[0] += transform_size) < transform_size)
					m_message_bits[1]++;

				one_cycle(0,1,2,3,4,5,6,7,k256[ 0],p[ 0]);
				one_cycle(7,0,1,2,3,4,5,6,k256[ 1],p[ 1]);
				one_cycle(6,7,0,1,2,3,4,5,k256[ 2],p[ 2]);
				one_cycle(5,6,7,0,1,2,3,4,k256[ 3],p[ 3]);
				one_cycle(4,5,6,7,0,1,2,3,k256[ 4],p[ 4]);
				one_cycle(3,4,5,6,7,0,1,2,k256[ 5],p[ 5]);
				one_cycle(2,3,4,5,6,7,0,1,k256[ 6],p[ 6]);
				one_cycle(1,2,3,4,5,6,7,0,k256[ 7],p[ 7]);
				one_cycle(0,1,2,3,4,5,6,7,k256[ 8],p[ 8]);
				one_cycle(7,0,1,2,3,4,5,6,k256[ 9],p[ 9]);
				one_cycle(6,7,0,1,2,3,4,5,k256[10],p[10]);
				one_cycle(5,6,7,0,1,2,3,4,k256[11],p[11]);
				one_cycle(4,5,6,7,0,1,2,3,k256[12],p[12]);
				one_cycle(3,4,5,6,7,0,1,2,k256[13],p[13]);
				one_cycle(2,3,4,5,6,7,0,1,k256[14],p[14]);
				one_cycle(1,2,3,4,5,6,7,0,k256[15],p[15]);

				one_cycle(0,1,2,3,4,5,6,7,k256[16],hf( 0));
				one_cycle(7,0,1,2,3,4,5,6,k256[17],hf( 1));
				one_cycle(6,7,0,1,2,3,4,5,k256[18],hf( 2));
				one_cycle(5,6,7,0,1,2,3,4,k256[19],hf( 3));
				one_cycle(4,5,6,7,0,1,2,3,k256[20],hf( 4));
				one_cycle(3,4,5,6,7,0,1,2,k256[21],hf( 5));
				one_cycle(2,3,4,5,6,7,0,1,k256[22],hf( 6));
				one_cycle(1,2,3,4,5,6,7,0,k256[23],hf( 7));
				one_cycle(0,1,2,3,4,5,6,7,k256[24],hf( 8));
				one_cycle(7,0,1,2,3,4,5,6,k256[25],hf( 9));
				one_cycle(6,7,0,1,2,3,4,5,k256[26],hf(10));
				one_cycle(5,6,7,0,1,2,3,4,k256[27],hf(11));
				one_cycle(4,5,6,7,0,1,2,3,k256[28],hf(12));
				one_cycle(3,4,5,6,7,0,1,2,k256[29],hf(13));
				one_cycle(2,3,4,5,6,7,0,1,k256[30],hf(14));
				one_cycle(1,2,3,4,5,6,7,0,k256[31],hf(15));

				one_cycle(0,1,2,3,4,5,6,7,k256[32],hf( 0));
				one_cycle(7,0,1,2,3,4,5,6,k256[33],hf( 1));
				one_cycle(6,7,0,1,2,3,4,5,k256[34],hf( 2));
				one_cycle(5,6,7,0,1,2,3,4,k256[35],hf( 3));
				one_cycle(4,5,6,7,0,1,2,3,k256[36],hf( 4));
				one_cycle(3,4,5,6,7,0,1,2,k256[37],hf( 5));
				one_cycle(2,3,4,5,6,7,0,1,k256[38],hf( 6));
				one_cycle(1,2,3,4,5,6,7,0,k256[39],hf( 7));
				one_cycle(0,1,2,3,4,5,6,7,k256[40],hf( 8));
				one_cycle(7,0,1,2,3,4,5,6,k256[41],hf( 9));
				one_cycle(6,7,0,1,2,3,4,5,k256[42],hf(10));
				one_cycle(5,6,7,0,1,2,3,4,k256[43],hf(11));
				one_cycle(4,5,6,7,0,1,2,3,k256[44],hf(12));
				one_cycle(3,4,5,6,7,0,1,2,k256[45],hf(13));
				one_cycle(2,3,4,5,6,7,0,1,k256[46],hf(14));
				one_cycle(1,2,3,4,5,6,7,0,k256[47],hf(15));

				one_cycle(0,1,2,3,4,5,6,7,k256[48],hf( 0));
				one_cycle(7,0,1,2,3,4,5,6,k256[49],hf( 1));
				one_cycle(6,7,0,1,2,3,4,5,k256[50],hf( 2));
				one_cycle(5,6,7,0,1,2,3,4,k256[51],hf( 3));
				one_cycle(4,5,6,7,0,1,2,3,k256[52],hf( 4));
				one_cycle(3,4,5,6,7,0,1,2,k256[53],hf( 5));
				one_cycle(2,3,4,5,6,7,0,1,k256[54],hf( 6));
				one_cycle(1,2,3,4,5,6,7,0,k256[55],hf( 7));
				one_cycle(0,1,2,3,4,5,6,7,k256[56],hf( 8));
				one_cycle(7,0,1,2,3,4,5,6,k256[57],hf( 9));
				one_cycle(6,7,0,1,2,3,4,5,k256[58],hf(10));
				one_cycle(5,6,7,0,1,2,3,4,k256[59],hf(11));
				one_cycle(4,5,6,7,0,1,2,3,k256[60],hf(12));
				one_cycle(3,4,5,6,7,0,1,2,k256[61],hf(13));
				one_cycle(2,3,4,5,6,7,0,1,k256[62],hf(14));
				one_cycle(1,2,3,4,5,6,7,0,k256[63],hf(15));

				this->m_buf[0] += v0; this->m_buf[1] += v1;
				this->m_buf[2] += v2; this->m_buf[3] += v3;
				this->m_buf[4] += v4; this->m_buf[5] += v5;
				this->m_buf[6] += v6; this->m_buf[7] += v7;
			}

			/* 
			* get the pointer to state buffer
			*/
			const word_type* operator () () const { return m_buf; }

			/*
			* return the digest
			*/
			const void *digest() const throw(bad_hash_state)
			{
				if(m_state == hash_function_finished)
					return m_digest; 
				else
					throw bad_hash_state("sha2_ctx::digest() : digest is not computed");
			}

		private:				
			// state of the hash instance
			hash_function_state m_state;

			uint32_t m_message_bits[2];
			uint32_t m_buf[8];
			uint8_t  m_digest[digest_size + ((digest_size&3) ? (1):(0))];
		};

#
#		define rotr64		BOOST_ROR64
#
#		if !defined(bswap_64)
#		define bswap_64(x) (((uint64_t)(bswap_32((uint32_t)(x)))) << 32 | bswap_32((uint32_t)((x) >> 32)))
#		endif
#
#		ifdef BOOST_LITTLE_ENDIAN
#		define bsw_64(p,n) \
		{ int _i = (n); while(_i--) ((uint64_t*)p)[_i] = bswap_64(((uint64_t*)p)[_i]); }
#		else
#		 define bsw_64(p,n)
#		endif
#
#		 undef  s_0
# 	 undef  s_1
#		 undef  g_0
# 	 undef  g_1
#		 undef  k_0
#
#		define s_0(x)  (rotr64((x), 28) ^ rotr64((x), 34) ^ rotr64((x), 39))
#		define s_1(x)  (rotr64((x), 14) ^ rotr64((x), 18) ^ rotr64((x), 41))
#		define g_0(x)  (rotr64((x),  1) ^ rotr64((x),  8) ^ ((x) >>  7))
#		define g_1(x)  (rotr64((x), 19) ^ rotr64((x), 61) ^ ((x) >>  6))
#		define k_0     k512

		// 64-bit algorithms 
		template<uint64_t DS, uint64_t TT0, uint64_t TT1, uint64_t TT2, uint64_t TT3, uint64_t TT4, uint64_t TT5, uint64_t TT6, uint64_t TT7>
		class sha2_ctx<uint64_t, DS, TT0,TT1,TT2,TT3,TT4,TT5,TT6,TT7>
		{
		public:
			typedef uint8_t  char_type;
			typedef uint64_t word_type;
			typedef size_t   size_type;

			/* size of the digest */
			static constexpr size_type digest_size       = DS;

			/* size of the internal state */
			static constexpr size_type state_size        = 64;

			/* minimum required size of each input block */
			static constexpr size_type transform_size    = 128;

			void create() throw()
			{
				m_message_bits[0] = m_message_bits[1] = 0;
				m_buf[0] = TT0;
				m_buf[1] = TT1;
				m_buf[2] = TT2;
				m_buf[3] = TT3;
				m_buf[4] = TT4;
				m_buf[5] = TT5;
				m_buf[6] = TT6;
				m_buf[7] = TT7;
			}

			void finalise(const void* input, size_type input_bits) throw(bad_hash_state)
			{
				m_state = hash_function_finalising;

				if( (m_message_bits[0] += bits_to_bytes(input_bits)) < bits_to_bytes(input_bits))
					m_message_bits[1]++;
				
				uint64_t wbuf[16];
				uint32_t    i = (m_message_bits[0] & (SHA512_BLOCK_SIZE-1));

				bitcpy(wbuf, input, input_bits);

				endian::ensure_be(wbuf, (i + 7) >> 3);
				
				wbuf[i >> 3] &= UINT64_C(0xffffffffffffff00) << 8 * (~i & 7);
				wbuf[i >> 3] |= UINT64_C(0x0000000000000080) << 8 * (~i & 7);

				if(i > SHA512_BLOCK_SIZE - 17)
				{
					if(i < 120) wbuf[15] = 0;
					transform(wbuf);
					i = 0;
				}
				else
					i = (i >> 3) + 1;

				while(i < 14)     wbuf[i++] = 0;

				wbuf[14] = (m_message_bits[1] << 3) | (m_message_bits[0] >> 61);
				wbuf[15] = m_message_bits[0] << 3;
				transform(wbuf);

				for(i = 0; i < digest_size/8; i++)
					endian::write_be64(m_digest+8*i, m_buf[i]);

				m_state = hash_function_finished;
			}

			void transform(const void* input) throw(bad_hash_state)
			{
				if(m_state != hash_function_processing)
					if(m_state == hash_function_created)		
						m_state = hash_function_processing;
					else if(m_state != hash_function_finalising)
						throw bad_hash_state("sha2_ctx::transform() : could not transform an empty stream");

				using namespace detail::sha2;

				uint64_t v[8], p[16];

				memcpy(p, input, transform_size);
				memcpy(v, m_buf, 8 * sizeof(word_type));

				if( (m_message_bits[0] += transform_size*8) < transform_size*8)
					m_message_bits[1]++;

				for(int j = 0; j < 80; j += 16)
				{
					v_cycle( 0, j); v_cycle( 1, j);
					v_cycle( 2, j); v_cycle( 3, j);
					v_cycle( 4, j); v_cycle( 5, j);
					v_cycle( 6, j); v_cycle( 7, j);
					v_cycle( 8, j); v_cycle( 9, j);
					v_cycle(10, j); v_cycle(11, j);
					v_cycle(12, j); v_cycle(13, j);
					v_cycle(14, j); v_cycle(15, j);
				}

				this->m_buf[0] += v[0]; this->m_buf[1] += v[1];
				this->m_buf[2] += v[2]; this->m_buf[3] += v[3];
				this->m_buf[4] += v[4]; this->m_buf[5] += v[5];
				this->m_buf[6] += v[6]; this->m_buf[7] += v[7];
			}


			/* 
			* get the pointer to state buffer
			*/
			const word_type* operator () () const { 
				return m_buf; 
			}

			/*
			* return the digest
			*/
			const void *digest() const throw(bad_hash_state)
			{
				if(m_state == hash_function_finished)
					return m_digest; 
				else
					throw bad_hash_state("sha2_ctx::digest() : digest is not computed");
			}

		private:				
			// state of the hash instance
			hash_function_state m_state;

			uint64_t m_message_bits[2];
			uint64_t m_buf[8];
			uint8_t  m_digest[digest_size + ((digest_size&3) ? (1):(0))];;
		};

	} // namespace crypto
} // namespace boost


#undef rotl32
#undef rotr32
#undef rotr64
#undef bswap_32
#undef bswap_64
#undef ch
#undef maj
#undef vf
#undef hf
#undef v_cycle
#undef  s_0
#undef  s_1
#undef  g_0
#undef  g_1
#undef  k_0
#undef bsw_64
#undef bsw_32
#
#endif /* BOOST_CRYPTO_SHA2_HPP_INCLUDED */
