/********************************************************************\
*
*      FILE:     rmd160.h
*
*      CONTENTS: Header file for a sample C-implementation of the
*                RIPEMD-160 hash-function. 
*      TARGET:   any computer with an ANSI C compiler
*
*      AUTHOR:   Antoon Bosselaers, ESAT-COSIC
*      DATE:     1 March 1996
*      VERSION:  1.0
*
*      Copyright (c) Katholieke Universiteit Leuven
*      1996, All Rights Reserved
*
*  Conditions for use of the RIPEMD-160 Software
*
*  The RIPEMD-160 software is freely available for use under the terms and
*  conditions described hereunder, which shall be deemed to be accepted by
*  any user of the software and applicable on any use of the software:
* 
*  1. K.U.Leuven Department of Electrical Engineering-ESAT/COSIC shall for
*     all purposes be considered the owner of the RIPEMD-160 software and of
*     all copyright, trade secret, patent or other intellectual property
*     rights therein.
*  2. The RIPEMD-160 software is provided on an "as is" basis without
*     warranty of any sort, express or implied. K.U.Leuven makes no
*     representation that the use of the software will not infringe any
*     patent or proprietary right of third parties. User will indemnify
*     K.U.Leuven and hold K.U.Leuven harmless from any claims or liabilities
*     which may arise as a result of its use of the software. In no
*     circumstances K.U.Leuven R&D will be held liable for any deficiency,
*     fault or other mishappening with regard to the use or performance of
*     the software.
*  3. User agrees to give due credit to K.U.Leuven in scientific publications 
*     or communications in relation with the use of the RIPEMD-160 software 
*     as follows: RIPEMD-160 software written by Antoon Bosselaers, 
*     available at http://www.esat.kuleuven.be/~cosicart/ps/AB-9601/.
*
\********************************************************************/
#ifndef _BOOST_CRYPTO_RMD160_HPP_INCLUDED
#define _BOOST_CRYPTO_RMD160_HPP_INCLUDED
#
#include "crypto.hpp"
#include "crypto_endian.hpp"
#include "crypto_rotation.hpp"
#
#/* ROL(x, n) cyclically rotates x over n bits to the left */
#/* x must be of an unsigned 32 bits type and 0 <= n < 32. */
#define ROL(x, n)        BOOST_ROL32(x,n)
#
#/* the five basic functions F(), G() and H() */
#define F(x, y, z)        ((x) ^ (y) ^ (z)) 
#define G(x, y, z)        ((z) ^ ((x) & ((y) ^ (z))))
#define H(x, y, z)        (((x) | ~(y)) ^ (z))
#define I(x, y, z)        (((x) & (z)) | ((y) & ~(z))) 
#define J(x, y, z)        ((x) ^ ((y) | ~(z)))
#
#
#/* the ten basic operations FF() through III() */
#define FF(a, b, c, d, e, x, s)        {\
	(a) += F((b), (c), (d)) + (x) + K0<word_type>::value;\
	(a) = ROL((a), (s)) + (e);\
	(c) = ROL((c), 10);\
	 }
#define GG(a, b, c, d, e, x, s)        {\
	(a) += G((b), (c), (d)) + (x) + K1<word_type>::value;\
	(a) = ROL((a), (s)) + (e);\
	(c) = ROL((c), 10);\
	 }
#define HH(a, b, c, d, e, x, s)        {\
	(a) += H((b), (c), (d)) + (x) + K2<word_type>::value;\
	(a) = ROL((a), (s)) + (e);\
	(c) = ROL((c), 10);\
	 }
#define II(a, b, c, d, e, x, s)        {\
	(a) += I((b), (c), (d)) + (x) + K3<word_type>::value;\
	(a) = ROL((a), (s)) + (e);\
	(c) = ROL((c), 10);\
	 }
#define JJ(a, b, c, d, e, x, s)        {\
	(a) += J((b), (c), (d)) + (x) + K4<word_type>::value;\
	(a) = ROL((a), (s)) + (e);\
	(c) = ROL((c), 10);\
	 }
#define FFF(a, b, c, d, e, x, s)        {\
	(a) += F((b), (c), (d)) + (x) + K5<word_type>::value;\
	(a) = ROL((a), (s)) + (e);\
	(c) = ROL((c), 10);\
	 }
#define GGG(a, b, c, d, e, x, s)        {\
	(a) += G((b), (c), (d)) + (x) + K6<word_type>::value;\
	(a) = ROL((a), (s)) + (e);\
	(c) = ROL((c), 10);\
	 }
#define HHH(a, b, c, d, e, x, s)        {\
	(a) += H((b), (c), (d)) + (x) + K7<word_type>::value;\
	(a) = ROL((a), (s)) + (e);\
	(c) = ROL((c), 10);\
	 }
#define III(a, b, c, d, e, x, s)        {\
	(a) += I((b), (c), (d)) + (x) + K8<word_type>::value;\
	(a) = ROL((a), (s)) + (e);\
	(c) = ROL((c), 10);\
	 }
#define JJJ(a, b, c, d, e, x, s)        {\
	(a) += J((b), (c), (d)) + (x) + K9<word_type>::value;\
	(a) = ROL((a), (s)) + (e);\
	(c) = ROL((c), 10);\
	 }

namespace boost {
	namespace crypto {
		template<typename T, T TT0, T TT1, T TT2, T TT3, T TT4>
		class ripemd_ctx
		{
		public:
			typedef byte_t   char_type;
			typedef T				 word_type;
			typedef size_t   size_type;

			/* size of the digest */
			static constexpr size_type digest_size       = 5 * sizeof(word_type);

			/* size of the internal state */
			static constexpr size_type state_size        = 5 * sizeof(word_type);

			/* minimum required size of each input block */
			static constexpr size_type transform_size    = 16 * sizeof(word_type);

		private:
			// bits in words minus 1 for each 16-bits
			static constexpr word_type wsfx = bitsof<T>::value - 1 * (bitsof<T>::value / 16);

			template<typename T>
			struct K0 {
				static constexpr T value = 0;
			};

			template<typename T>
			struct K1 { // sqrt(2) * 2^(w-a)
				static constexpr T value = static_cast<T>(
					1.4142135623730950488016887242097 * static_cast<long double>(T(1) << wsfx));
			};

			template<typename T>
			struct K2 { // sqrt(3) * 2^(w-a)
				static constexpr T value = static_cast<T>(
					1.7320508075688772935274463415059 * static_cast<long double>(T(1) << wsfx));
			};

			template<typename T>
			struct K3 { // sqrt(5) * 2^(w-a)
				static constexpr T value = static_cast<T>(
					2.2360679774997896964091736687313 * static_cast<long double>(T(1) << wsfx));
			};

			template<typename T>
			struct K4 { // sqrt(7) * 2^(w-a)
				static constexpr T value = static_cast<T>(
					2.6457513110645905905016157536393 * static_cast<long double>(T(1) << wsfx));
			};

			template<typename T>
			struct K5 { // 2^(1/3) * 2^(w-a)
				static constexpr T value = static_cast<T>(
					1.2599210498948731647672106072779 * static_cast<long double>(T(1) << wsfx));
			};

			template<typename T>
			struct K6 { // 3^(1/3) * 2^(w-a)
				static constexpr T value = static_cast<T>(
					1.4422495703074083823216383107796 * static_cast<long double>(T(1) << wsfx));
			};

			template<typename T>
			struct K7 { // 5^(1/3) * 2^(w-a)
				static constexpr T value = static_cast<T>(
					1.7099759466766969893531088725429 * static_cast<long double>(T(1) << wsfx));
			};

			template<typename T>
			struct K8 { // 7^(1/3) * 2^(w-a)
				static constexpr T value = static_cast<T>(
					1.9129311827723891011991168395475 * static_cast<long double>(T(1) << wsfx));
			};
						
			template<typename T>
			struct K9 {
				static constexpr word_type value = 0;
			};

			// check the constants
			BOOST_STATIC_ASSERT(K0<uint32_t>::value == 0x00000000UL);
			BOOST_STATIC_ASSERT(K9<uint32_t>::value == 0x00000000UL);

			BOOST_STATIC_ASSERT(K1<uint32_t>::value == 0x5a827999UL);
			BOOST_STATIC_ASSERT(K8<uint32_t>::value == 0x7a6d76e9UL);
                                                   
			BOOST_STATIC_ASSERT(K2<uint32_t>::value == 0x6ed9eba1UL);
			BOOST_STATIC_ASSERT(K7<uint32_t>::value == 0x6d703ef3UL);

			BOOST_STATIC_ASSERT(K3<uint32_t>::value == 0x8f1bbcdcUL);
			BOOST_STATIC_ASSERT(K6<uint32_t>::value == 0x5c4dd124UL);

			BOOST_STATIC_ASSERT(K4<uint32_t>::value == 0xa953fd4eUL);
			BOOST_STATIC_ASSERT(K5<uint32_t>::value == 0x50a28be6UL);

		public:
			ripemd_ctx() { 
				create();
			}

			ripemd_ctx& operator = (ripemd_ctx& rhs) {
				m_state = rhs.m_state;
				memcpy(m_message_bytes, rhs.m_message_bytes, 8);

				std::memcpy(m_buf, rhs.m_buf   , state_size);
				std::memcpy(m_buf, rhs.m_digest, digest_size);

				return (*this);
			}

			~ripemd_ctx() {
				std::memset(m_buf           , 00, sizeof(m_buf));
				std::memset(m_digest        , 00, sizeof(m_digest));
				std::memset(&m_message_bytes, 00, sizeof(m_message_bytes));
			}

			void create() {
				m_message_bytes[0] = m_message_bytes[1] = 0;

				m_buf[0] = TT0;
				m_buf[1] = TT1;
				m_buf[2] = TT2;
				m_buf[3] = TT3;
				m_buf[4] = TT4;

				m_state = hash_function_created;
			}

			void transform(const void* input) throw(bad_hash_state) {

				if(m_state != hash_function_processing)
					if(m_state == hash_function_created)		
						m_state = hash_function_processing;
					else if(m_state != hash_function_finalising)
						throw bad_hash_state("ripemd_ctx::transform() : could not transform an empty stream");

				const word_type *X = reinterpret_cast<const word_type*>(input);

				word_type aa  = m_buf[0],  bb = m_buf[1],  cc = m_buf[2],  dd = m_buf[3],  ee = m_buf[4];
				word_type aaa = m_buf[0], bbb = m_buf[1], ccc = m_buf[2], ddd = m_buf[3], eee = m_buf[4];

				/* round 1 */
				FF(aa, bb, cc, dd, ee, X[ 0], 11);
				FF(ee, aa, bb, cc, dd, X[ 1], 14);
				FF(dd, ee, aa, bb, cc, X[ 2], 15);
				FF(cc, dd, ee, aa, bb, X[ 3], 12);
				FF(bb, cc, dd, ee, aa, X[ 4],  5);
				FF(aa, bb, cc, dd, ee, X[ 5],  8);
				FF(ee, aa, bb, cc, dd, X[ 6],  7);
				FF(dd, ee, aa, bb, cc, X[ 7],  9);
				FF(cc, dd, ee, aa, bb, X[ 8], 11);
				FF(bb, cc, dd, ee, aa, X[ 9], 13);
				FF(aa, bb, cc, dd, ee, X[10], 14);
				FF(ee, aa, bb, cc, dd, X[11], 15);
				FF(dd, ee, aa, bb, cc, X[12],  6);
				FF(cc, dd, ee, aa, bb, X[13],  7);
				FF(bb, cc, dd, ee, aa, X[14],  9);
				FF(aa, bb, cc, dd, ee, X[15],  8);

				/* round 2 */
				GG(ee, aa, bb, cc, dd, X[ 7],  7);
				GG(dd, ee, aa, bb, cc, X[ 4],  6);
				GG(cc, dd, ee, aa, bb, X[13],  8);
				GG(bb, cc, dd, ee, aa, X[ 1], 13);
				GG(aa, bb, cc, dd, ee, X[10], 11);
				GG(ee, aa, bb, cc, dd, X[ 6],  9);
				GG(dd, ee, aa, bb, cc, X[15],  7);
				GG(cc, dd, ee, aa, bb, X[ 3], 15);
				GG(bb, cc, dd, ee, aa, X[12],  7);
				GG(aa, bb, cc, dd, ee, X[ 0], 12);
				GG(ee, aa, bb, cc, dd, X[ 9], 15);
				GG(dd, ee, aa, bb, cc, X[ 5],  9);
				GG(cc, dd, ee, aa, bb, X[ 2], 11);
				GG(bb, cc, dd, ee, aa, X[14],  7);
				GG(aa, bb, cc, dd, ee, X[11], 13);
				GG(ee, aa, bb, cc, dd, X[ 8], 12);

				/* round 3 */
				HH(dd, ee, aa, bb, cc, X[ 3], 11);
				HH(cc, dd, ee, aa, bb, X[10], 13);
				HH(bb, cc, dd, ee, aa, X[14],  6);
				HH(aa, bb, cc, dd, ee, X[ 4],  7);
				HH(ee, aa, bb, cc, dd, X[ 9], 14);
				HH(dd, ee, aa, bb, cc, X[15],  9);
				HH(cc, dd, ee, aa, bb, X[ 8], 13);
				HH(bb, cc, dd, ee, aa, X[ 1], 15);
				HH(aa, bb, cc, dd, ee, X[ 2], 14);
				HH(ee, aa, bb, cc, dd, X[ 7],  8);
				HH(dd, ee, aa, bb, cc, X[ 0], 13);
				HH(cc, dd, ee, aa, bb, X[ 6],  6);
				HH(bb, cc, dd, ee, aa, X[13],  5);
				HH(aa, bb, cc, dd, ee, X[11], 12);
				HH(ee, aa, bb, cc, dd, X[ 5],  7);
				HH(dd, ee, aa, bb, cc, X[12],  5);

				/* round 4 */
				II(cc, dd, ee, aa, bb, X[ 1], 11);
				II(bb, cc, dd, ee, aa, X[ 9], 12);
				II(aa, bb, cc, dd, ee, X[11], 14);
				II(ee, aa, bb, cc, dd, X[10], 15);
				II(dd, ee, aa, bb, cc, X[ 0], 14);
				II(cc, dd, ee, aa, bb, X[ 8], 15);
				II(bb, cc, dd, ee, aa, X[12],  9);
				II(aa, bb, cc, dd, ee, X[ 4],  8);
				II(ee, aa, bb, cc, dd, X[13],  9);
				II(dd, ee, aa, bb, cc, X[ 3], 14);
				II(cc, dd, ee, aa, bb, X[ 7],  5);
				II(bb, cc, dd, ee, aa, X[15],  6);
				II(aa, bb, cc, dd, ee, X[14],  8);
				II(ee, aa, bb, cc, dd, X[ 5],  6);
				II(dd, ee, aa, bb, cc, X[ 6],  5);
				II(cc, dd, ee, aa, bb, X[ 2], 12);

				/* round 5 */
				JJ(bb, cc, dd, ee, aa, X[ 4],  9);
				JJ(aa, bb, cc, dd, ee, X[ 0], 15);
				JJ(ee, aa, bb, cc, dd, X[ 5],  5);
				JJ(dd, ee, aa, bb, cc, X[ 9], 11);
				JJ(cc, dd, ee, aa, bb, X[ 7],  6);
				JJ(bb, cc, dd, ee, aa, X[12],  8);
				JJ(aa, bb, cc, dd, ee, X[ 2], 13);
				JJ(ee, aa, bb, cc, dd, X[10], 12);
				JJ(dd, ee, aa, bb, cc, X[14],  5);
				JJ(cc, dd, ee, aa, bb, X[ 1], 12);
				JJ(bb, cc, dd, ee, aa, X[ 3], 13);
				JJ(aa, bb, cc, dd, ee, X[ 8], 14);
				JJ(ee, aa, bb, cc, dd, X[11], 11);
				JJ(dd, ee, aa, bb, cc, X[ 6],  8);
				JJ(cc, dd, ee, aa, bb, X[15],  5);
				JJ(bb, cc, dd, ee, aa, X[13],  6);

				/* parallel round 1 */
				JJJ(aaa, bbb, ccc, ddd, eee, X[ 5],  8);
				JJJ(eee, aaa, bbb, ccc, ddd, X[14],  9);
				JJJ(ddd, eee, aaa, bbb, ccc, X[ 7],  9);
				JJJ(ccc, ddd, eee, aaa, bbb, X[ 0], 11);
				JJJ(bbb, ccc, ddd, eee, aaa, X[ 9], 13);
				JJJ(aaa, bbb, ccc, ddd, eee, X[ 2], 15);
				JJJ(eee, aaa, bbb, ccc, ddd, X[11], 15);
				JJJ(ddd, eee, aaa, bbb, ccc, X[ 4],  5);
				JJJ(ccc, ddd, eee, aaa, bbb, X[13],  7);
				JJJ(bbb, ccc, ddd, eee, aaa, X[ 6],  7);
				JJJ(aaa, bbb, ccc, ddd, eee, X[15],  8);
				JJJ(eee, aaa, bbb, ccc, ddd, X[ 8], 11);
				JJJ(ddd, eee, aaa, bbb, ccc, X[ 1], 14);
				JJJ(ccc, ddd, eee, aaa, bbb, X[10], 14);
				JJJ(bbb, ccc, ddd, eee, aaa, X[ 3], 12);
				JJJ(aaa, bbb, ccc, ddd, eee, X[12],  6);

				/* parallel round 2 */
				III(eee, aaa, bbb, ccc, ddd, X[ 6],  9); 
				III(ddd, eee, aaa, bbb, ccc, X[11], 13);
				III(ccc, ddd, eee, aaa, bbb, X[ 3], 15);
				III(bbb, ccc, ddd, eee, aaa, X[ 7],  7);
				III(aaa, bbb, ccc, ddd, eee, X[ 0], 12);
				III(eee, aaa, bbb, ccc, ddd, X[13],  8);
				III(ddd, eee, aaa, bbb, ccc, X[ 5],  9);
				III(ccc, ddd, eee, aaa, bbb, X[10], 11);
				III(bbb, ccc, ddd, eee, aaa, X[14],  7);
				III(aaa, bbb, ccc, ddd, eee, X[15],  7);
				III(eee, aaa, bbb, ccc, ddd, X[ 8], 12);
				III(ddd, eee, aaa, bbb, ccc, X[12],  7);
				III(ccc, ddd, eee, aaa, bbb, X[ 4],  6);
				III(bbb, ccc, ddd, eee, aaa, X[ 9], 15);
				III(aaa, bbb, ccc, ddd, eee, X[ 1], 13);
				III(eee, aaa, bbb, ccc, ddd, X[ 2], 11);

				/* parallel round 3 */
				HHH(ddd, eee, aaa, bbb, ccc, X[15],  9);
				HHH(ccc, ddd, eee, aaa, bbb, X[ 5],  7);
				HHH(bbb, ccc, ddd, eee, aaa, X[ 1], 15);
				HHH(aaa, bbb, ccc, ddd, eee, X[ 3], 11);
				HHH(eee, aaa, bbb, ccc, ddd, X[ 7],  8);
				HHH(ddd, eee, aaa, bbb, ccc, X[14],  6);
				HHH(ccc, ddd, eee, aaa, bbb, X[ 6],  6);
				HHH(bbb, ccc, ddd, eee, aaa, X[ 9], 14);
				HHH(aaa, bbb, ccc, ddd, eee, X[11], 12);
				HHH(eee, aaa, bbb, ccc, ddd, X[ 8], 13);
				HHH(ddd, eee, aaa, bbb, ccc, X[12],  5);
				HHH(ccc, ddd, eee, aaa, bbb, X[ 2], 14);
				HHH(bbb, ccc, ddd, eee, aaa, X[10], 13);
				HHH(aaa, bbb, ccc, ddd, eee, X[ 0], 13);
				HHH(eee, aaa, bbb, ccc, ddd, X[ 4],  7);
				HHH(ddd, eee, aaa, bbb, ccc, X[13],  5);

				/* parallel round 4 */   
				GGG(ccc, ddd, eee, aaa, bbb, X[ 8], 15);
				GGG(bbb, ccc, ddd, eee, aaa, X[ 6],  5);
				GGG(aaa, bbb, ccc, ddd, eee, X[ 4],  8);
				GGG(eee, aaa, bbb, ccc, ddd, X[ 1], 11);
				GGG(ddd, eee, aaa, bbb, ccc, X[ 3], 14);
				GGG(ccc, ddd, eee, aaa, bbb, X[11], 14);
				GGG(bbb, ccc, ddd, eee, aaa, X[15],  6);
				GGG(aaa, bbb, ccc, ddd, eee, X[ 0], 14);
				GGG(eee, aaa, bbb, ccc, ddd, X[ 5],  6);
				GGG(ddd, eee, aaa, bbb, ccc, X[12],  9);
				GGG(ccc, ddd, eee, aaa, bbb, X[ 2], 12);
				GGG(bbb, ccc, ddd, eee, aaa, X[13],  9);
				GGG(aaa, bbb, ccc, ddd, eee, X[ 9], 12);
				GGG(eee, aaa, bbb, ccc, ddd, X[ 7],  5);
				GGG(ddd, eee, aaa, bbb, ccc, X[10], 15);
				GGG(ccc, ddd, eee, aaa, bbb, X[14],  8);

				/* parallel round 5 */
				FFF(bbb, ccc, ddd, eee, aaa, X[12] ,  8);
				FFF(aaa, bbb, ccc, ddd, eee, X[15] ,  5);
				FFF(eee, aaa, bbb, ccc, ddd, X[10] , 12);
				FFF(ddd, eee, aaa, bbb, ccc, X[ 4] ,  9);
				FFF(ccc, ddd, eee, aaa, bbb, X[ 1] , 12);
				FFF(bbb, ccc, ddd, eee, aaa, X[ 5] ,  5);
				FFF(aaa, bbb, ccc, ddd, eee, X[ 8] , 14);
				FFF(eee, aaa, bbb, ccc, ddd, X[ 7] ,  6);
				FFF(ddd, eee, aaa, bbb, ccc, X[ 6] ,  8);
				FFF(ccc, ddd, eee, aaa, bbb, X[ 2] , 13);
				FFF(bbb, ccc, ddd, eee, aaa, X[13] ,  6);
				FFF(aaa, bbb, ccc, ddd, eee, X[14] ,  5);
				FFF(eee, aaa, bbb, ccc, ddd, X[ 0] , 15);
				FFF(ddd, eee, aaa, bbb, ccc, X[ 3] , 13);
				FFF(ccc, ddd, eee, aaa, bbb, X[ 9] , 11);
				FFF(bbb, ccc, ddd, eee, aaa, X[11] , 11);

				/* combine results */
				ddd += cc + m_buf[1];               /* final result for m_buf[0] */
				m_buf[1] = m_buf[2] + dd + eee;
				m_buf[2] = m_buf[3] + ee + aaa;
				m_buf[3] = m_buf[4] + aa + bbb;
				m_buf[4] = m_buf[0] + bb + ccc;
				m_buf[0] = ddd;

				return;
			}


			void finalise(const void*input, size_type input_bits) {

				m_state = hash_function_finalising;

				if( (m_message_bytes[0] += bits_to_bytes(input_bits)) < bits_to_bytes(input_bits))
					m_message_bytes[1]++;

				word_type wbuf[16];
				word_type i = input_bits;

				bitcpy(wbuf, input, i);
				
				endian::ensure_be(wbuf, (i + sizeof(word_type) + 1) / sizeof(word_type));
				
				wbuf[i / sizeof(word_type)] &= ((word_type(-1) << 8) | word_type(128)) << 8 * (~i & (sizeof(word_type) - 1));
				wbuf[i / sizeof(word_type)] |= word_type(128)                          << 8 * (~i & (sizeof(word_type) - 1));

				if(i > 64 - 9)
				{
					if(i < 60) wbuf[15] = 0;
					transform(wbuf);
					i = 0;
				}
				else
					i = (i / sizeof(word_type)) + 1;

				for( ;i < 14; i++)     wbuf[i] = 0;

				wbuf[14] = m_message_bytes[0] << 3;
				wbuf[15] = (m_message_bytes[1] << 3) |
					(m_message_bytes[0] >> (bitsof<word_type>::value - 3));

				transform(wbuf);

				for(i = 0; i < 5; i++)
					endian::write_be32(m_digest + sizeof(word_type) * i, m_buf[i]);
					//endian::write_le32(m_digest + sizeof(word_type) * i, m_buf[i]);

				// these values are not needed
				std::memset(m_buf           , 0, sizeof(m_buf));
				std::memset(&m_message_bytes, 0, sizeof(m_message_bytes));

				m_state = hash_function_finished;

				return;
			}

			/* 
			* get the pointer to state buffer
			*/
			const word_type* operator () () const {
				return m_buf; 
			}

			/*
			* return the digest
			*/
			const void *digest() const throw(bad_hash_state) {
				if(m_state == hash_function_finished)
					return m_digest; 
				else
					throw bad_hash_state("ripemd_ctx::digest() : digest is not computed");
			}

		private:				
			// state of the hash instance
			hash_function_state m_state;

			word_type m_message_bytes[2];
			word_type m_buf[5];
			char_type m_digest[digest_size + 2];
		};

	} // namespace crypto
} // namespace boost 


#undef ROL
#undef F
#undef G
#undef H
#undef I
#undef J
#undef FF
#undef GG
#undef HH
#undef II
#undef JJ
#undef FFF
#undef GGG
#undef HHH
#undef III
#undef JJJ
#
#endif /* _BOOST_CRYPTO_RMD160_HPP_INCLUDED */
