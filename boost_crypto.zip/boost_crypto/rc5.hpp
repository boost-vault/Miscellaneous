#ifndef BOOST_CRYPTO_RC5_HPP_INCLUDED
#define BOOST_CRYPTO_RC5_HPP_INCLUDED
#         
#include "crypto.hpp"
#include "crypto_endian.hpp"
#include "crypto_rotation.hpp"
#
#include <boost/cstdint.hpp>

namespace boost {
	namespace crypto {
		namespace detail {
			namespace rc5 {

				template<typename T>
				struct pw {
					static constexpr T value = static_cast<T>(
						0.71828182845904523536 * 2 * static_cast<long double>(
						uintmax_t(1) << bitsof<T>::value)) / 2;
				};

				template<typename T>
				struct qw {
					static constexpr T value = static_cast<T>(
						0.6180339887498948482045868343656 * 2 * static_cast<long double>(
						uintmax_t(1) << bitsof<T>::value)) / 2;
				};

				template<>
				struct qw<uint64_t> {
					static constexpr uint64_t value = 0xb7e151628aed2a6b;
				};

				template<>
				struct pw<uint64_t> {
					static constexpr uint64_t value = 0x9e3779b97f4a7c15;
				};

			} // namespace boost::crypto::detail::rc5
		} // namespace boost::crypto::detail

		template<size_t NR, typename T>
		class rc5_cipher
		{
		public:
			typedef byte_t value_type;
			typedef T				word_type;
			typedef size_t	size_type;

			static constexpr size_type min_key_size = 0;
			static constexpr size_type max_key_size = 56;
			static constexpr size_type block_size   = 8;
			static constexpr size_type rounds       = NR;
			static constexpr char*  name() { return "RC5"; }
		private:
			bool			m_initialise;
			uint32_t	m_S[44];
				
		public:

			rc5_cipher()
				:
			m_initialise(false)
			{
			}

			rc5_cipher(const void* key, size_t key_size)
			{
				setkey(key, key_size);
			}

			~rc5_cipher()
			{
				std::memset(m_S,0,sizeof(m_S));
			}

			constexpr void setkey(const void*key, size_t key_size) throw (std::length_error)
			{
				if(!(min_key_size <= key_size && key_size <= max_key_size))
					throw std::length_error(std::string("rc5_cipher::setkey() : invalid key size"));

				m_initialise = true;

				uint32_t L[44];
				int c = key_size / 4 + ((key_size&3)?(1):(0));
				std::memset(L,0,c<<2);
				std::memcpy(L,key,key_size);
				for(int i=0; i<c; i++) endian::ensure_le(L+i);

				m_S[0] = detail::rc5::pw<word_type>::value;
				for(int i = 1; i<44; i++)
					m_S[i] = m_S[i-1] + detail::rc5::qw<word_type>::value;

				uint32_t a=0, b=0;
				for(int s=1, i=0, j=0; s <= (3*((2*(rounds+2)))); s++)
				{ 
					a = m_S[ i ] = rol<word_type>(m_S[i] + a + b, 3);
					b = L[ j ] = rol<word_type>(L[j] + a + b, a + b);
					i = ( i + 1 )  % 44;
					j = ( j + 1 )  % c;
				}

			}

			constexpr void encrypt(void* ctxt, const void* ptxt)
			{
				register uint32_t a,b;

				a = endian::read_le(reinterpret_cast<const word_type*>(ptxt)+0);
				b = endian::read_le(reinterpret_cast<const word_type*>(ptxt)+1);

				a += m_S[ 0 ];
				b += m_S[ 1 ];
				for(int r = 1; r <= rounds; r++)
				{					
					a = rol<word_type>(a ^ b, b) + m_S[(r<<1)];
					b = rol<word_type>(b ^ a, a) + m_S[(r<<1)+1];
				}

				endian::write_le(reinterpret_cast<word_type*>(ctxt)+0,a);
				endian::write_le(reinterpret_cast<word_type*>(ctxt)+1,b);
			}

			constexpr void decrypt(void* ptxt, const void* ctxt)
			{
				register uint32_t a,b;

				a = endian::read_le(reinterpret_cast<const word_type*>(ctxt)+0);
				b = endian::read_le(reinterpret_cast<const word_type*>(ctxt)+1);

				for(int r = rounds; r > 0; r--)
				{
					b = ror<word_type>((b - m_S[(r<<1)+1]), a) ^ a;
					a = ror<word_type>((a - m_S[(r<<1)  ]), b) ^ b;
				}
				a -= m_S[ 0 ];
				b -= m_S[ 1 ];

				
				endian::write_le(reinterpret_cast<word_type*>(ptxt)+0,a);
				endian::write_le(reinterpret_cast<word_type*>(ptxt)+1,b);
			}
		};

	} // namespace boost::crypto
} // namespace boost 

#endif /* BOOST_CRYPTO_RC5_HPP_INCLUDED */

