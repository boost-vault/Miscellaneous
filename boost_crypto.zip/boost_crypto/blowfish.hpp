#ifndef BOOST_CRYPTO_BLOWFISH_HPP_INCLUDED
#define BOOST_CRYPTO_BLOWFISH_HPP_INCLUDED
#
#include <algorithm>
#
#include <boost/static_assert.hpp>
#
#include "crypto.hpp"
#include "crypto_buffer.hpp"
#include "block_cipher.hpp"

//#define F(x) \
//(((this->S0[((x) >> 24) & 0xFF] + this->S1[((x) >> 16) & 0xFF]) ^ \
//	this->S2[((x) >> 8) & 0xFF]) + this->S3[((x)) & 0xFF])

namespace boost { 
	namespace crypto {
		namespace detail {
			namespace blowfish {
				/* blowfish sboxes */
				extern constexpr uint32_t S0[256];
				extern constexpr uint32_t S1[256];
				extern constexpr uint32_t S2[256];
				extern constexpr uint32_t S3[256];
				/* blowfish pbox */
				extern constexpr uint32_t P[];
			} // namespace boost::crypto::detail::blowfish
		} // namespace boost::crypto::detail 

		template<size_t NR/* # of rounds */>
		class blowfish_cipher
		{
		public:				
			typedef byte_t value_type;
			typedef size_t size_type;

			static constexpr size_type rounds          = NR;
			static constexpr size_type block_size      = 8;
			static constexpr size_type min_key_size    = 4;
			static constexpr size_type max_key_size    = 56;
			static constexpr char * name () { return "Blowfish"; }

		private:
			// ensure (rounds mod 2 == 0)
			BOOST_STATIC_ASSERT((rounds % 2) == 0);

		private:
			bool m_initialised;

			strong_used_buffer<max_key_size, value_type> m_key;

			uint32_t P [rounds+02], S0[256], S1[256], S2[256], S3[256];

			// macro replacement is available, however, speed gain is marginal
			inline constexpr register uint32_t F(register uint32_t x) const
			{
				uint8_t a = x >> 24;
				uint8_t b = x >> 16;
				uint8_t c = x >>  8;
				uint8_t d = x;
				return (((S0[a] ^ S1[a]) + S2[a]) ^ S3[a]);
			}

		public:
			blowfish_cipher()
				:
			m_initialised(false)
			{
			}

			blowfish_cipher(const void* vkey, size_type key_size) 
				:
			m_initialised(false)
			{
				setkey(vkey, key_size);
			}

			/* compile time computations */
			template<size_type N> constexpr void setkey(crypto_buffer_t<N>& key);
			constexpr void encrypt(crypto_buffer_t <block_size>& ctxt, const crypto_buffer_t <block_size>& ptxt);
			constexpr void decrypt(crypto_buffer_t <block_size>& ptxt, const crypto_buffer_t <block_size>& ctxt);

			
			template<size_type N> constexpr void setkey(weak_used_buffer<N>& key)
			{
				BOOST_STATIC_ASSERT(N <= max_key_size);
				BOOST_CRYPTO_CHECK_KEYSIZE(key.size(), blowfish::setkey());

				using namespace detail::blowfish;
				std::memcpy(this->S0, S0, 256*sizeof(uint32_t));
				std::memcpy(this->S1, S1, 256*sizeof(uint32_t));
				std::memcpy(this->S2, S2, 256*sizeof(uint32_t));
				std::memcpy(this->S3, S3, 256*sizeof(uint32_t));

				// Copy key then schedule inplace 
				m_key.size(N);
				memcpy(m_key, key, N);
				for(size_t i=N; i<max_key_size; i += key_wrap.size())
					memcpy(&key_wrap[i], &key_wrap[i-N], min(max_key_size - i, N));
				
				// expand the key
				m_initialised = true;
				const uint32_t* k = m_key;
				uint32_t block[2] = {0};

				for (int i = 0; i < rounds + 2; ++i)
					this->P[i] = P[i] ^ endian::read_le32(&m_key[i]);

				for (int i = 0; i < rounds + 2; i += 2) {
					encrypt(block, block);
					P[i  ] = block[0];
					P[i+1] = block[1];
				}

				for (int j = 0; j < 256; j += 2) {
					encrypt(block, block);
					S0[j  ] = block[0];	
					S0[j+1] = block[1];
				}

				for (int j = 0; j < 256; j += 2) {
					encrypt(block, block);
					S1[j  ] = block[0];	
					S1[j+1] = block[1];
				}

				for (int j = 0; j < 256; j += 2) {
					encrypt(block, block);
					S2[j  ] = block[0];	
					S2[j+1] = block[1];
				}

				for (int j = 0; j < 256; j += 2) {
					encrypt(block, block);
					S3[j  ] = block[0];		
					S3[j+1] = block[1];
				}

			}
			
			template<size_type N> constexpr void setkey(weak_buffer<N>& key)
			{
				BOOST_STATIC_ASSERT(N <= max_key_size);

				using namespace detail::blowfish;
				std::memcpy(this->S0, S0, 256*sizeof(uint32_t));
				std::memcpy(this->S1, S1, 256*sizeof(uint32_t));
				std::memcpy(this->S2, S2, 256*sizeof(uint32_t));
				std::memcpy(this->S3, S3, 256*sizeof(uint32_t));

				// Copy key then schedule inplace 
				m_key.size(N);
				memcpy(m_key, key, N);
				for(size_t i=N; i<max_key_size; i += key_wrap.size())
					memcpy(&key_wrap[i], &key_wrap[i-N], min(max_key_size - i, N));
				
				// expand the key
				m_initialised = true;
				const uint32_t* k = m_key;
				uint32_t block[2] = {0};

				for (int i = 0; i < rounds + 2; ++i)
					this->P[i] = P[i] ^ endian::read_le32(&m_key[i]);

				for (int i = 0; i < rounds + 2; i += 2) {
					encrypt(block, block);
					P[i  ] = block[0];
					P[i+1] = block[1];
				}

				for (int j = 0; j < 256; j += 2) {
					encrypt(block, block);
					S0[j  ] = block[0];	
					S0[j+1] = block[1];
				}

				for (int j = 0; j < 256; j += 2) {
					encrypt(block, block);
					S1[j  ] = block[0];	
					S1[j+1] = block[1];
				}

				for (int j = 0; j < 256; j += 2) {
					encrypt(block, block);
					S2[j  ] = block[0];	
					S2[j+1] = block[1];
				}

				for (int j = 0; j < 256; j += 2) {
					encrypt(block, block);
					S3[j  ] = block[0];		
					S3[j+1] = block[1];
				}

			}

			/* runtime computations */
			void setkey(const void* key, size_type key_size) throw(invalid_key_size)
			{
				weak_used_buffer<max_key_size, value_type> wk(key, key, key_size);
				wk.size(key_size);
				setkey(wk);
			}

			void encrypt(void* ctxt, const void* ptxt) throw(cipher_not_initialised)
			{
				BOOST_CRYPTO_CHECK_STATE(blowfish<NR>::encrypt);

				register uint32_t xL, xR;
				xL = static_cast<const uint32_t*>(ptxt)[0];
				xR = static_cast<const uint32_t*>(ptxt)[1];

				/* on AMD athlon 32-bit with MSVC >= 1500, there was no
				 * significant speed improvement for unrolled loops further than
				 * current two rounds. I suspect it would be the same for other
				 * platforms. 
				 * 2-rounded improves performance since it removes xL <--> xR swap
				 * operation (althought xL and xR are most likely registers anyway)
				 */
				for (int i = 0; i < rounds; i += 2)
				{
					xL ^= P[i];
					xR ^= F(xL);
					
					xR ^= P[i+1];
					xL ^= F(xR);
				}

				xL ^= P[rounds];
				xR ^= P[rounds + 1];

				static_cast<uint32_t*>(ctxt)[0] = xR;
				static_cast<uint32_t*>(ctxt)[1] = xL;
			}

			void decrypt(void* ptxt, const void* ctxt) throw(cipher_not_initialised)
			{
				BOOST_CRYPTO_CHECK_STATE(blowfish<NR>::decrypt);

				uint32_t xL = static_cast<const uint32_t*>(ctxt)[0];
				uint32_t xR = static_cast<const uint32_t*>(ctxt)[1];

				for (int i = rounds + 1 ; i > 1; i -= 2)
				{
					xL ^= P[i];
					xR ^= F(xL);
					
					xR ^= P[i-1];
					xL ^= F(xR);
				}

				static_cast<uint32_t*>(ptxt)[0] = xR ^ P[0];
				static_cast<uint32_t*>(ptxt)[1] = xL ^ P[1];
			}
			/* memory wipe */
			~blowfish_cipher()
			{
				std::memset(this-> P, 0, sizeof(P ));
				std::memset(this->S0, 0, sizeof(S0));
				std::memset(this->S1, 0, sizeof(S1));
				std::memset(this->S2, 0, sizeof(S2));
				std::memset(this->S3, 0, sizeof(S3));
			}
		};

		typedef blowfish_cipher<16> blowfish;

	} // namespace boost::crypto
} // namespace boost 

#endif /* BOOST_CRYPTO_BLOWFISH_HPP_INCLUDED */
