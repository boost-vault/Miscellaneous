#ifndef BOOST_CRYPTO_BLOCK_CIPHER_HPP_INCLUDED
#define BOOST_CRYPTO_BLOCK_CIPHER_HPP_INCLUDED

#include "crypto.hpp"
#include "fixed_buffer.hpp"

#define BOOST_CRYPTO_CHECK_STATE(...) \
	if(!m_initialised) \
	throw cipher_not_initialised(BOOST_STRINGIZE(__VA_ARGS__) " : not initialised")

namespace boost { 
	namespace crypto {
		class null_block_cipher
		{
			static constexpr size_t min_key_size = 0;
			static constexpr size_t max_key_size = 0;
			static constexpr size_t block_size	 = 0;
			static constexpr size_t rounds       = 0;
		};

		// securely allocated buffer
		// holds a copy of the data
		template<size_t MaxSize, typename T=byte_t>
		class strong_buffer
		{
			T elem[size];
		public:
			typedef T 							value_type;
			typedef T* 							pointer;
			typedef T&							reference;
			typedef const pointer		const_pointer;
			typedef const reference	const_reference;
			static constexpr size_t max_size = SizeT;

			template<typename U>
			strong_buffer(U *buffer, size_t count)
			{
				size_t amount = min(size, count);
				std::memcpy(elem			 , buffer, amount);
				std::memset(elem+amount, 000000, size-amount);
			}

			~strong_buffer() {
				BOOST_CRYPTO_ZEROISE(elem, sizeof(elem));
			}

			size_t size() const {
				return SizeT;
			}

			operator T* () const {
				return elem;
			}
			
			reference operator[] (size_t index) {
				return elem[index];
			}
		};


		// weakly referenced buffer
		template<size_t MaxSize, typename T=byte_t>
		class weak_buffer
		{
			T *elem;
		public:
			typedef T 							value_type;
			typedef T* 							pointer;
			typedef T&							reference;
			typedef const pointer		const_pointer;
			typedef const reference	const_reference;
			static constexpr size_t max_size = SizeT;

			template<typename U>
			weak_buffer(T* base, U *buffer, size_t count)
				: elem(base)
			{
				size_t amount = min(size, count);
				std::memcpy(elem			 , buffer, amount);
				std::memset(elem+amount, 000000, size-amount);
			}
			
			weak_buffer(T* base, size_t count)
				: elem(base)
			{
				size_t amount = min(size, count);
			}

			~weak_buffer() {
			}

			size_t size() const {
				return SizeT;
			}

			template<typename U>
			operator U* () {
				return (U*)elem;
			}

			operator T* () const {
				return elem;
			}

			reference operator[] (size_t index) {
				return elem[index];
			}
		};

	
		template<size_t MaxSize, typename T, typename Buffer>
		class partially_used_buffer 
			: Buffer
		{
			m_size;
		public:
			typedef T 							value_type;
			typedef T* 							pointer;
			typedef T&							reference;
			typedef const pointer		const_pointer;
			typedef const reference	const_reference;
			typedef Buffer buffer_type;
			
			partially_used_buffer(T* ptr, size_t size)
				: m_size(size), buffer_type(ptr,size) {
			}

			void size(size_t newsize) {
				m_size = newsize;
			}

			size_t size() const {
				return m_size;
			}
		};
	
		template<size_t MaxSize, typename T=byte_t>
		class strong_used_buffer 
			: partially_used_buffer<MaxSize,T,strong_buffer<MaxSize,T> >
		{
			typedef T 							value_type;
			typedef T* 							pointer;
			typedef T&							reference;
			typedef const pointer		const_pointer;
			typedef const reference	const_reference;
			typedef partially_used_buffer<MaxSize,T,strong_buffer<MaxSize,T> > partial_base_type;
			strong_used_buffer(T* ptr, size_t size)
				: partial_base_type(ptr, size) {
			}
		};


		template<size_t MaxSize, typename T=byte_t>
		class weak_used_buffer 
			: partially_used_buffer<MaxSize,T,weak_buffer<MaxSize,T> >
		{
			typedef T 							value_type;
			typedef T* 							pointer;
			typedef T&							reference;
			typedef const pointer		const_pointer;
			typedef const reference	const_reference;
			typedef partially_used_buffer<MaxSize,T,weak_buffer<MaxSize,T> > partial_base_type;
			template<typename U>
			weak_used_buffer(T* baseptr, U* ptr, size_t size)
				: partial_base_type(baseptr, ptr, size) {
			}
			
			weak_used_buffer(T* baseptr, size_t size)
				: partial_base_type(baseptr, size) {
			}
		};

	} // namespace boost::crypto
} // namespace boost 

#endif /* BOOST_CRYPTO_BLOCK_CIPHER_HPP_INCLUDED */
