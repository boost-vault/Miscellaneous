#include <windows.h>
#include <iostream>
//#include "blowfish.hpp"
//#include "mars.hpp"
//#include "rc6.hpp"
//#include "rc5.hpp"
//#include "rc4.hpp"
//#include "rc2.hpp"
//#include "hc128.hpp"
////#include "hc256.hpp"
//#include "salsa.hpp"
//#include "md5.hpp"
//#include "md4.hpp"
//#include "md2.hpp"
//#include "whirlpool.hpp"
//#include "rijndael.hpp"
//#include "cast.hpp"
//#include "serpent.hpp"
//#include "twofish.hpp"
//#include "cbc.hpp"
//#include "pkcs7.hpp"
//#include "dynamic_buffer.hpp"
//#include "large_counter.hpp"
//#include <ctime>
//#include "sha2.hpp"
//#include "sha224.hpp"
//#include "sha256.hpp"
//#include "sha384.hpp"
#include "sha512.hpp"
//#include "tea.hpp"
//#include "xtea.hpp"
//#include "btea.hpp"
//#include "ripemd160.hpp"

#include "crypto_random.h"

using namespace boost::crypto;
using namespace boost;

#include <array>
#include <random>
#include <regex>
#include <tuple>
#include <type_traits>
#include <unordered_map>
#include <unordered_set>
#include <functional>

//template<typename CIPHER>
//void encryption_speed_test(const char* name=nullptr)
//{			
//	try {
//		/* expected behaviour */
//		typename CIPHER::value_type ptxt[(int)(typename CIPHER::block_size)] = {0};
//		typename CIPHER::value_type ctxt[(int)(typename CIPHER::block_size)];
//		typename CIPHER::value_type ckey[(int)(typename CIPHER::max_key_size)] = {0};
//		CIPHER c;
//		c.setkey(ckey, typename CIPHER::max_key_size);
//		clock_t clock_value = clock();
//		for(int i=0; i<1024*1024;i++)
//		{		
//			c.encrypt(ctxt, ptxt);
//			c.decrypt(ptxt, ctxt);
//			ptxt[0] ^= ctxt[0]--;
//		}
//		clock_value -= clock(); clock_value  =- clock_value ;
//
//		cout << 
//			name << ": speed was " <<
//			2*(float)(typename CIPHER::block_size)*CLOCKS_PER_SEC/clock_value << "\t" <<
//			(char)ptxt[0] << endl;
//	} catch(...) { }
//}
//
//#define BOOST_CRYPTO_STRINGIZE(...) _BOOST_CRYPTO_STRINGIZE_DO(__VA_ARGS__)
//#define _BOOST_CRYPTO_STRINGIZE_DO(...) _BOOST_CRYPTO_STRINGIZE_DO_I(__VA_ARGS__)
//#define _BOOST_CRYPTO_STRINGIZE_DO_I(...) #__VA_ARGS__

#include "hash_test.hpp"
#include <boost/thread.hpp>
#include <boost/bind.hpp>


#include <boost/random.hpp>

int main()
{
	// instantiate a new instance of kernel_entropy source
	win32_random kernel_entropy;

	// a class that maintins
	entropy_poller
	<
		1024,													// Have pool size of 1024 byte
		crypto_random_device<mt19937>,// use a random device base
		digest_buffer<sha512_ctx>			// use byte buffered SHA-512 as PRF
	> rnd;
	

	//typedef crypto_random_pool<1024,digest_buffer<sha512_ctx> > pool_type;

	
	rnd.connect_device(new crypto_random_device<mt19937>(""));

	for(int i=0; i<32; i++)
		kernel_entropy.slow_poll(rnd.get_random_pool());

	for(int i=0; i<64; i++)
		kernel_entropy.fast_poll<1024,digest_buffer<sha512_ctx> >
		(rnd.get_random_pool());

	this_thread::sleep(posix_time::millisec(1000));

	for(int i=0; i<512*2048; i++)
	{
		if((i&15)==0) puts("");
		printf("%02X ", rnd());
	}


	//{
	//	typedef digest_buffer<ripemd160_ctx> hash;
	//	cout << hash::compute("").to_string() << endl;
	//	cout << hash::compute("a").to_string() << endl;		
	//	cout << hash::compute("abc").to_string() << endl;	
	//	cout << hash::compute("message digest").to_string() << endl;		
	//	cout << hash::compute("abcdefghijklmnopqrstuvwxyz").to_string() << endl;				
	//	cout << hash::compute("abcdbcdecdefdefgefghfghighijhijkijkljklmklmnlmnomnopnopq").to_string() << endl;
	//}
	//typedef rc6_cipher<20,uint16_t> cipher;	
	///* expected behaviour */
	//cipher::value_type ptxt[(int)(cipher::block_size*16)] = {0};
	//cipher::value_type ctxt[(int)(cipher::block_size*16)];
	//{
	//	typedef digest_buffer<sha512_ctx, false> hash;
	//	char buffer[64] = {0};
	//	buffer[63 ] =1;
	//	cout << hash::compute("abc").to_string() << endl;
	//	cout << hash::compute("abcdefghijklmnopqrstuvwxyz").to_string() << endl;
	//	cout << hash::compute(buffer, 64).to_string() << endl;
	//}
	//{
	//	typedef digest_buffer<whirlpool_ctx, false> hash;
	//	char buffer[64] = {0};
	//	buffer[63 ] =1;
	//	cout << hash::compute("abc").to_string() << endl;
	//	cout << hash::compute("abcdefghijklmnopqrstuvwxyz").to_string() << endl;
	//	cout << hash::compute(buffer, 64).to_string() << endl;
	//}
	//cipher c;
	//c.setkey("this is my quiet long key", 16);
	//c.encrypt(ctxt, ptxt);
	//c.decrypt(ptxt, ctxt);

	//encryption_speed_test<tea >(BOOST_CRYPTO_STRINGIZE(tea));
	//encryption_speed_test<xtea>(BOOST_CRYPTO_STRINGIZE(xtea));
	//encryption_speed_test<btea>(BOOST_CRYPTO_STRINGIZE(btea));
	//encryption_speed_test<twofish>(BOOST_CRYPTO_STRINGIZE(twofish));
	//encryption_speed_test<mars_cipher>(BOOST_CRYPTO_STRINGIZE(mars_cipher));
	//encryption_speed_test<serpent>(BOOST_CRYPTO_STRINGIZE(serpent));
	//encryption_speed_test<aes128>(BOOST_CRYPTO_STRINGIZE(aes128));
	//encryption_speed_test<aes192>(BOOST_CRYPTO_STRINGIZE(aes192));
	//encryption_speed_test<aes256>(BOOST_CRYPTO_STRINGIZE(aes256));
	//encryption_speed_test<rc6_cipher<20,uint8_t> >(BOOST_CRYPTO_STRINGIZE(rc6_cipher<20,uint8_t>));
	//encryption_speed_test<rc6_cipher<20,uint16_t> >(BOOST_CRYPTO_STRINGIZE(rc6_cipher<20,uint16_t>));
	//encryption_speed_test<rc6_cipher<20,uint32_t> >(BOOST_CRYPTO_STRINGIZE(rc6_cipher<20,uint32_t>));
	//encryption_speed_test<rc6_cipher<20,uint64_t> >(BOOST_CRYPTO_STRINGIZE(rc6_cipher<20,uint64_t>));

	//cbc<cipher,pkcs7_padding<cipher::block_size> > stream_cipher;
	////hc128_stream_cipher stream_cipher;
	////hc128_stream_cipher stream_cipher;

	//stream_cipher.setkey("this is my quiet long key", 8);
	//stream_cipher.setiv("this is my quiet long key", 8);
	//stream_cipher.encrypt(ctxt, ptxt, sizeof(ptxt));
	//stream_cipher.decrypt(ptxt, ctxt, sizeof(ctxt));
	//stream_cipher.create<Encryption>() (ctxt, ptxt, sizeof(ptxt));

#	ifdef _DEBUG
	system("pause");
#endif
	return 0;
}
//
//#define R 16
//static uint32_t pbox[R+8];
//static uint32_t sbox[16][256];
//
//static void encrypt(uint8_t *c, const uint8_t *p);
//static void decrypt(uint8_t *c, const uint8_t *p);
//
//static void keyset(uint8_t *key, size_t key_size)
//{
//	int i, j, k;
//	uint32_t sum, delta, lambda;
//	sum = lambda = 0xb7e151628aed2a6bULL * 0x9e3779b97f4a7c15ULL;
//	delta = 0ULL;
//
//	// key and padding
//	memcpy(pbox, key, key_size);
//	memset(((uint8_t*)pbox)+key_size, 0, 8*(R+4)-key_size);
//	pbox[key_size/8+((key_size&7)?(1ULL):(0ULL))] |= 1ULL << 63;
//
//	/* precomptable */
//	for(i=0;i<16;i++)
//		for(j=0;j<256;j++)
//		{
//			sbox[i][j] = (sum - delta) * lambda + 0x9e3779b97f4a7c15ULL;
//			sum += 0x9e3779b97f4a7c15ULL;
//			lambda -= 0xb7e151628aed2a6bULL;
//			delta -= (i << 9) + j;
//		}
//
//		/* partially precomptable */
//		for(i=0; i<R+8; i++)
//		{
//			pbox[i] ^= sum ++ - (--lambda);
//			sum -= 0x9e3779b97f4a7c15ULL + 0xb7e151628aed2a6bULL;
//			lambda -= 0xb7e151628aed2a6bULL - 0x9e3779b97f4a7c15ULL;
//		}
//
//		uint32_t b[4] = {0};
//		for(i=0; i<R+8; i+=4)
//		{
//			encrypt((uint8_t*)b, (uint8_t*)b);
//			pbox[i+0] ^= b[0];
//			pbox[i+1] ^= b[1];	
//			pbox[i+2] ^= b[2];
//			pbox[i+3] ^= b[3];		
//		}
//
//		for(i=0;i<16;i++)
//			for(j=0;j<256;j+=4)
//			{			
//				encrypt((uint8_t*)b, (uint8_t*)b);
//				sbox[i][j+0] ^= b[0];
//				sbox[i][j+1] ^= b[1];
//				sbox[i][j+2] ^= b[2];
//				sbox[i][j+3] ^= b[3];
//			}
//}
//
//__forceinline uint32_t __E(uint32_t x)
//{
//	uint8_t x0,x1,x2,x3,x4,x5,x6,x7;
//	x0 = x; (x >>= 8);
//	x1 = x; (x >>= 8);
//	x2 = x; (x >>= 8);
//	x3 = x; (x >>= 8);
//	x4 = x; (x >>= 8);
//	x5 = x; (x >>= 8);
//	x6 = x; (x >>= 8);
//	x7 = (x);
//	return 
//		sbox[ 8][x0] + sbox[ 9][x1] + sbox[10][x2] + sbox[11][x3] + 
//		sbox[ 0][x4] + sbox[ 1][x5] + sbox[ 2][x6] + sbox[ 3][x7] ;
//}
//
//__forceinline uint32_t __F(uint32_t x)
//{
//	uint8_t x0,x1,x2,x3,x4,x5,x6,x7;
//	x0 = x; (x >>= 8);
//	x1 = x; (x >>= 8);
//	x2 = x; (x >>= 8);
//	x3 = x; (x >>= 8);
//	x4 = x; (x >>= 8);
//	x5 = x; (x >>= 8);
//	x6 = x; (x >>= 8);
//	x7 = (x);
//	return 
//		sbox[ 4][x0] + sbox[ 5][x1] + sbox[ 6][x2] + sbox[ 7][x3] + 		
//		sbox[12][x4] + sbox[13][x5] + sbox[14][x6] + sbox[15][x7] ;
//}
//
//static void encrypt(uint8_t *ct, const uint8_t *pt)
//{
//	register uint32_t a,b,c,d;
//	uint32_t *p = &pbox[4];
//
//	/* input whitening */
//	a = ((const uint32_t *)pt)[0] ^ pbox[0];
//	b = ((const uint32_t *)pt)[1] ^ pbox[1];
//	c = ((const uint32_t *)pt)[2] ^ pbox[2];
//	d = ((const uint32_t *)pt)[3] ^ pbox[3];
//
//	/* core-cryptographical rounds */
//	for(int r = 0; r < R; r += 4)
//	{
//		a ^= __F(b);			b ^= p[r+0];
//		c ^= __E(d);			d ^= p[r+1];
//
//		b ^= __F(c);			c ^= p[r+2];
//		d ^= __E(a);			a ^= p[r+3];
//
//		c ^= __F(d);			d ^= p[r+4];
//		a ^= __E(b);			b ^= p[r+5];
//
//		d ^= __F(a);			a ^= p[r+6];
//		b ^= __E(c);			c ^= p[r+7];
//	}
//
//	/* multi-avalanche */
//	a ^= __E(b+c+d) ^ __F(b^c^d);
//	b ^= __E(a+c+d) ^ __F(a^c^d);
//	c ^= __E(b+a+d) ^ __F(b^a^d);
//	d ^= __E(b+c+a) ^ __F(b^c^a);
//
//	/* output whitening */
//	((uint32_t *)ct)[0] = a ^ pbox[R+4];
//	((uint32_t *)ct)[1] = b ^ pbox[R+5];
//	((uint32_t *)ct)[2] = c ^ pbox[R+6];
//	((uint32_t *)ct)[3] = d ^ pbox[R+7];
//}
//
//static void decrypt(uint8_t *pt, const uint8_t *ct)
//{
//	register uint32_t a,b,c,d;
//	uint32_t *p = &pbox[4];
//
//	a = ((const uint32_t *)ct)[0] ^ pbox[R+4];
//	b = ((const uint32_t *)ct)[1] ^ pbox[R+5];
//	c = ((const uint32_t *)ct)[2] ^ pbox[R+6];
//	d = ((const uint32_t *)ct)[3] ^ pbox[R+7];
//
//	d ^= __E(b+c+a) ^ __F(b^c^a);		
//	c ^= __E(b+a+d) ^ __F(b^a^d);
//	b ^= __E(a+c+d) ^ __F(a^c^d);
//	a ^= __E(b+c+d) ^ __F(b^c^d);
//
//	for(int r = R-4; r >= 0 ; r -= 4)
//	{
//		c ^= p[r+7];		b ^= __E(c);	
//		a ^= p[r+6];		d ^= __F(a);	
//
//		b ^= p[r+5];		a ^= __E(b);
//		d ^= p[r+4];		c ^= __F(d);	
//
//		a ^= p[r+3];		d ^= __E(a);	
//		c ^= p[r+2];		b ^= __F(c);	
//
//		d ^= p[r+1];		c ^= __E(d);
//		b ^= p[r+0];		a ^= __F(b);	
//	}
//
//	((uint32_t *)pt)[0] = a ^ pbox[0];
//	((uint32_t *)pt)[1] = b ^ pbox[1];
//	((uint32_t *)pt)[2] = c ^ pbox[2];
//	((uint32_t *)pt)[3] = d ^ pbox[3];
//}
//
