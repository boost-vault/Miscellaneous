namespace boost {
	namespace crypto {
		namespace detail {
			namespace rabbit {
			}
		}

		class rabbit {
		public:
			typedef byte_t	 value_type;
			typedef uint32_t word_type;
			typedef size_t	 size_type;

			static constexpr size_type min_key_size =  0;
			static constexpr size_type min_iv_size  =  0;
			static constexpr size_type max_key_size = 16;
			static constexpr size_type max_iv_size  =  8;
			static constexpr size_type rounds       = size_type();

		private:
			bool m_initialised = false;
			word_type m_x[8];
			word_type m_c[8];
			word_type m_carry;

			/* -------------------------------------------------------------------------- */
			/* Square a 32-bit unsigned integer to obtain the 64-bit result and return */
			/* the upper 32 bits XOR the lower 32 bits */
			static inline const word_type g_func(word_type x)
			{
				/* Temporary variables */
				uint32_t a, b, h, l;

				/* Construct high and low argument for squaring */
				a = x&0xFFFF;
				b = x>>16;

				/* Calculate high and low result of squaring */
				h = ((((a*a)>>17) + (a*b))>>15) + b*b;
				l = x*x;

				/* Return high XOR low */
				return (h^l) & 0xFFFFFFFF;
			}

			/* -------------------------------------------------------------------------- */
			/* Calculate the next internal state */
			inline const void next_state()
			{
				/* Temporary variables */
				uint32_t g[8], c_old[8], i;

				/* Save old counter values */
				for (i=0; i<8; i++)
					c_old[i] = m_c[i];

				/* Calculate new counter values */
				m_c[0] = (m_c[0] + 0x4D34D34D + m_m_carry);
				m_c[1] = (m_c[1] + 0xD34D34D3 + (m_c[0] < c_old[0]));
				m_c[2] = (m_c[2] + 0x34D34D34 + (m_c[1] < c_old[1]));
				m_c[3] = (m_c[3] + 0x4D34D34D + (m_c[2] < c_old[2]));
				m_c[4] = (m_c[4] + 0xD34D34D3 + (m_c[3] < c_old[3]));
				m_c[5] = (m_c[5] + 0x34D34D34 + (m_c[4] < c_old[4]));
				m_c[6] = (m_c[6] + 0x4D34D34D + (m_c[5] < c_old[5]));
				m_c[7] = (m_c[7] + 0xD34D34D3 + (m_c[6] < c_old[6]));
				m_m_carry= (m_c[7] < c_old[7]);

				/* Calculate the g-values */
				for (i=0;i<8;i++)
					g[i] = g_func(m_x[i] + m_c[i]);

				/* Calculate new state values */
				m_x[0] = (g[0] + rol<word_type>(g[7],16) + rol<word_type>(g[6], 16));
				m_x[1] = (g[1] + rol<word_type>(g[0], 8) + g[7]);
				m_x[2] = (g[2] + rol<word_type>(g[1],16) + rol<word_type>(g[0], 16));
				m_x[3] = (g[3] + rol<word_type>(g[2], 8) + g[1]);
				m_x[4] = (g[4] + rol<word_type>(g[3],16) + rol<word_type>(g[2], 16));
				m_x[5] = (g[5] + rol<word_type>(g[4], 8) + g[3]);
				m_x[6] = (g[6] + rol<word_type>(g[5],16) + rol<word_type>(g[4], 16));
				m_x[7] = (g[7] + rol<word_type>(g[6], 8) + g[5]);
			}


			/* ------------------------------------------------------------------------- */
			/* Encrypt/decrypt a message of any size */
			const void process_bytes(const uint8_t* input, uint8_t* output, size_type msglen)
			{
				/* Temporary variables */
				uint32_t i;
				uint8_t buffer[16];

				/* Encrypt/decrypt all full blocks */
				while (msglen >= 16)
				{
					/* Iterate the system */
					next_state();

					/* Encrypt/decrypt 16 bytes of data */

					*(uint32_t*)(output+ 0) = *(uint32_t*)(input+ 0) ^ endian::cpu_to_le32(m_cm_x[0] ^
						(m_cm_x[5]>>16) ^ (m_cm_x[3]<<16));

					*(uint32_t*)(output+ 4) = *(uint32_t*)(input+ 4) ^ endian::cpu_to_le32(m_cm_x[2] ^ 
						(m_cm_x[7]>>16) ^ (m_cm_x[5]<<16));

					*(uint32_t*)(output+ 8) = *(uint32_t*)(input+ 8) ^ endian::cpu_to_le32(m_cm_x[4] ^ 
						(m_cm_x[1]>>16) ^ (m_cm_x[7]<<16));

					*(uint32_t*)(output+12) = *(uint32_t*)(input+12) ^ endian::cpu_to_le32(m_cm_x[6] ^ 
						(m_cm_x[3]>>16) ^ (m_cm_x[1]<<16));

					/* Increment pointers and decrement length */
					input += 16;
					output += 16;
					msglen -= 16;
				}

				/* Encrypt/decrypt remaining data */
				if (msglen)
				{
					/* Iterate the system */
					next_state();

					/* Generate 16 bytes of pseudo-random data */
					*(uint32_t*)(buffer+ 0) = endian::cpu_to_le32(m_cm_x[0] ^
						(m_cm_x[5]>>16) ^ (m_cm_x[3]<<16));

					*(uint32_t*)(buffer+ 4) = endian::cpu_to_le32(m_cm_x[2] ^ 
						(m_cm_x[7]>>16) ^ (m_cm_x[5]<<16));

					*(uint32_t*)(buffer+ 8) = endian::cpu_to_le32(m_cm_x[4] ^ 
						(m_cm_x[1]>>16) ^ (m_cm_x[7]<<16));

					*(uint32_t*)(buffer+12) = endian::cpu_to_le32(m_cm_x[6] ^ 
						(m_cm_x[3]>>16) ^ (m_cm_x[1]<<16));

					/* Encrypt/decrypt the data */
					for (i=0; i<msglen; i++)
						output[i] = input[i] ^ buffer[i];
				}
			}
		public:
			rabbit_stream_cipher() 
				: m_initialised(false) {
			}

			rabbit_stream_cipher(const void* key, uint32_t key_size, ) 
				: m_initialised(false) {
			}

			/* ------------------------------------------------------------------------- */
			/* Key setup */
			const void setkey(const void* key, uint32_t key_size) throw(invalid_key_size)
			{
				/* Temporary variables */
				uint32_t k0, k1, k2, k3, i;

				uint8_t k[max_key_size];
				std::memcpy(k         , key, key_size);
				std::memset(k+key_size, 000, max_key_size-key_size);

				/* Generate four subkeys */		
				k0 = endian::read_le32(key+ 0);
				k1 = endian::read_le32(key+ 4);
				k2 = endian::read_le32(key+ 8);
				k3 = endian::read_le32(key+12);

				/* Generate initial state variables */
				m_x[0] = k0;
				m_x[2] = k1;
				m_x[4] = k2;
				m_x[6] = k3;
				m_x[1] = (k3<<16) | (k2>>16);
				m_x[3] = (k0<<16) | (k3>>16);
				m_x[5] = (k1<<16) | (k0>>16);
				m_x[7] = (k2<<16) | (k1>>16);

				/* Generate initial counter values */
				m_c[0] = rol<word_type>(k2, 16);
				m_c[2] = rol<word_type>(k3, 16);
				m_c[4] = rol<word_type>(k0, 16);
				m_c[6] = rol<word_type>(k1, 16);
				m_c[1] = (k0&0xFFFF0000) | (k1&0xFFFF);
				m_c[3] = (k1&0xFFFF0000) | (k2&0xFFFF);
				m_c[5] = (k2&0xFFFF0000) | (k3&0xFFFF);
				m_c[7] = (k3&0xFFFF0000) | (k0&0xFFFF);

				/* Clear m_carry bit */
				m_carry = 0;

				/* Iterate the system four times */
				for (i=0; i<4; i++)
					next_state();

				/* Modify the counters */
				for (i=0; i<8; i++)
					m_c[i] ^= m_x[(i+4)&0x7];

				/* Copy master instance to work instance */
				for (i=0; i<8; i++)
				{
					m_cm_x[i] = m_x[i];
					m_cm_c[i] = m_c[i];
				}
				m_cm_carry = m_carry;
			}

			/* ------------------------------------------------------------------------- */
			/* IV setup */
			void setiv(const void* iv, size_type iv_size) throw(invalid_iv_size)
			{
				/* Temporary variables */
				uint32_t i0, i1, i2, i3, i;

				uint8_t IV[max_iv_size];
				std::memcpy(IV         , iv, iv_size);
				std::memset(IV+key_size, 00, max_iv_size-iv_size);

				/* Generate four subvectors */
				i0 = endian::read_le32(IV+0);
				i2 = endian::read_le32(IV+4);
				i1 = (i0>>16) | (i2&0xFFFF0000);
				i3 = (i2<<16) | (i0&0x0000FFFF);

				/* Modify counter values */
				m_cm_c[0] = m_c[0] ^ i0;
				m_cm_c[1] = m_c[1] ^ i1;
				m_cm_c[2] = m_c[2] ^ i2;
				m_cm_c[3] = m_c[3] ^ i3;
				m_cm_c[4] = m_c[4] ^ i0;
				m_cm_c[5] = m_c[5] ^ i1;
				m_cm_c[6] = m_c[6] ^ i2;
				m_cm_c[7] = m_c[7] ^ i3;

				/* Copy state variables */
				for (i=0; i<8; i++)		m_cm_x[i] = m_x[i];
				m_cm_carry = m_carry;

				/* Iterate the system four times */
				for (i=0; i<4; i++)		next_state(&(work_this));
			}

		};

	} // namespace crypto 

} // namespace boost