//          Copyright Kasra Nassiri 2008-*.
//          Copyright Kevin Sopp 2007.
// Distributed under the Boost Software License, Version 1.0.
//    (See accompanying file LICENSE_1_0.txt or copy at
//          http://www.boost.org/LICENSE_1_0.txt)

#ifndef BOOST_CRYPTO_SECURE_ALLOCATOR_HPP_INCLUDED
#define BOOST_CRYPTO_SECURE_ALLOCATOR_HPP_INCLUDED

#include <cstring> // memset

namespace boost {
	namespace crypto {

		struct secure_allocator_tag { };

		template<typename T, class Alloc = std::allocator<T> >
		struct secure_allocator : Alloc
		{
			// okay not really defined on STL but it is essential in this case			
			typedef secure_allocator_tag allocator_category;
			typedef Alloc allocator_type;
			typedef typename allocator_type::size_type       size_type;
			typedef typename allocator_type::difference_type difference_type;
			typedef typename allocator_type::pointer         pointer;
			typedef typename allocator_type::const_pointer   const_pointer;
			typedef typename allocator_type::reference       reference;
			typedef typename allocator_type::const_reference const_reference;
			typedef typename allocator_type::value_type      value_type;

			template <class U>
			struct rebind
			{
				typedef secure_allocator<
					typename allocator_type::template rebind<U>::other
				> other;
			};

			secure_allocator() throw() {}

			secure_allocator(const secure_allocator& copy) throw()
				:
			allocator_type(copy)
			{ }

			template <class U>
			secure_allocator(const secure_allocator<U>& copy) throw()
				:
			allocator_type(copy)
			{ }

			~secure_allocator() throw() {}

			void deallocate(pointer p, size_type n)
			{
				if(p == nullptr) return ;
				std::memset(p, 0, n);
				allocator_type::deallocate(p, n);
			}
		};


		template<class T, class U>
		inline bool operator == (
			const secure_allocator<T>& lhs, const secure_allocator<U>& rhs)
		{
			return lhs.allocator_type == rhs.allocator_type;
		}

		template<class T, class U>
		inline bool operator != (
			const secure_allocator<T>& lhs, const secure_allocator<U>& rhs)
		{
			return lhs.allocator_type != rhs.allocator_type;
		}

	} // namespace boost::crypto
} // namespace boost

#endif /* BOOST_CRYPTO_SECURE_ALLOCATOR_HPP_INCLUDED */
