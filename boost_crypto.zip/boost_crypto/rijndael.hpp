#ifndef BOOST_CRYPTO_RIJNDAEL_HPP_INCLUDED
#define BOOST_CRYPTO_RIJNDAEL_HPP_INCLUDED
#         
#include "crypto.hpp"
#include "crypto_endian.hpp"
#include "crypto_rotation.hpp"
#
#include <boost/cstdint.hpp>
#include <boost/static_assert.hpp>

namespace boost {
	namespace crypto {
		namespace detail {
			namespace rijndael {
				extern constexpr uint32_t Te0[256];
				extern constexpr uint32_t Te1[256];
				extern constexpr uint32_t Te2[256];
				extern constexpr uint32_t Te3[256];
				extern constexpr uint32_t Te4[256];
				extern constexpr uint32_t Td0[256];
				extern constexpr uint32_t Td1[256];
				extern constexpr uint32_t Td2[256];
				extern constexpr uint32_t Td3[256];
				extern constexpr uint32_t Td4[256];
				extern constexpr uint8_t S[256];
				extern constexpr uint8_t Si[256];
				extern constexpr uint32_t rcon[];

			} // namespace boost::crypto::detail::rijndael
		} // namespace boost::crypto::detail


		// [NOTE] The rcon[] is only computed for 255-rounds
		// for more rounds rcon needs to be expanded
		// using: rcon(i) = x^(253+i) mod x^8+x^4+x^3+x+1
		// within finite field F(2^8)
		template <
			/* key size */
			size_t K=128, 
			/* block size */
			size_t B=128,
			/* # of rounds */
			size_t NR=((K == 128) ? (10) : ((K == 192) ? (12) : (14)))
		> class rijndael_cipher;		

		// Very Slow Implementation for genericity
		template<size_t K, size_t B, size_t NR>
		class rijndael_cipher
		{
		public:
			typedef byte_t value_type;
			typedef size_t size_type;
			static constexpr size_type rounds = NR;
			static constexpr size_type min_key_size = 0;
			static constexpr size_type max_key_size = K / 8;
			static constexpr size_type block_size   = B / 8;
			static constexpr char* name () { return "Rijndael"; }

		private:
			BOOST_STATIC_ASSERT(block_size > 16);
			static constexpr uint8_t shifts(int i) {
					return i + (i + 1) / (block_size / 4);
			}

			static constexpr uint8_t mul(uint8_t a, uint8_t b) {
				/* multiply two elements of GF(2^m)
				* needed for MixColumn and InvMixColumn
				*/
				using detail::rijndael::alog;
				using detail::rijndael::log;
				if (a && b) 					
					return alog[(log[a] + log[b]) & 255];
				else 
					return 0;
			}

			void AddRoundKey(uint8_t a[4][block_size / 4], uint8_t rk[4][block_size / 4]) {
				/* Exor corresponding text input and round key input bytes
				*/
				int i, j;

				for(i = 0; i < 4; i++)
					for(j = 0; j < block_size / 4; j++) 
						a[i][j] ^= rk[i][j];
			}

			void ShiftRows(uint8_t a[4][block_size / 4]) {
				/* Row 0 remains unchanged
				* The other three rows are shifted a variable amount
				*/
				uint8_t tmp[(block_size/ 4)];
				int i, j;
				
				for(i = 1; i < 4; i++) {
					for(j = 0; j < block_size / 4; j++) 
						tmp[j] = a[i][(j + shifts(i)) % (block_size / 4)];

					for(j = 0; j < block_size / 4; j++) 
						a[i][j] = tmp[j];
				}
			}
			void InvShiftRows(uint8_t a[4][block_size / 4]) {
				/* Row 0 remains unchanged
				* The other three rows are shifted a variable amount
				*/
				uint8_t tmp[(block_size/ 4)];
				int i, j;
				
				for(i = 1; i < 4; i++) {
					for(j = 0; j < block_size / 4; j++) 
						tmp[j] = a[i][(j + (block_size / 4 - shifts(i))) % (block_size / 4)];

					for(j = 0; j < block_size / 4; j++) 
						a[i][j] = tmp[j];
				}
			}

			void SubBytes(uint8_t a[4][block_size / 4]) {
				/* Replace every byte of the input by the byte at that place
				* in the nonlinear S-box.
				*/
				int i, j;
				using detail::rijndael::S;
				for(i = 0; i < 4; i++)
					for(j = 0; j < block_size / 4; j++)
						a[i][j] = S[a[i][j]] ;
			}

			void InvSubBytes(uint8_t a[4][block_size / 4]) {
				/* Replace every byte of the input by the byte at that place
				* in the nonlinear S-box.
				*/
				int i, j;
				using detail::rijndael::Si;
				for(i = 0; i < 4; i++)
					for(j = 0; j < block_size / 4; j++)
						a[i][j] = Si[a[i][j]] ;
			}

			void MixColumns(uint8_t a[4][block_size / 4]) {
				/* Mix the four bytes of every column in a linear way
				*/
				uint8_t b[4][block_size / 4];
				int i, j;

				for(j = 0; j < block_size / 4; j++)
					for(i = 0; i < 4; i++)
						b[i][j] = mul(2,a[i][j])
						^ mul(3,a[(i + 1) & 3][j])
						^ a[(i + 2) & 3][j] 
					^ a[(i + 3) & 3][j];

					for(i = 0; i < 4; i++)
						for(j = 0; j < block_size / 4; j++) 
							a[i][j] = b[i][j];
			}

			void InvMixColumns(uint8_t a[4][block_size/ 4]) {
				/* Mix the four bytes of every column in a linear way
				* This is the opposite operation of Mixcolumns
				*/
				uint8_t b[4][block_size / 4];
				int i, j;

				for(j = 0; j < block_size / 4; j++)
					for(i = 0; i < 4; i++)             
						b[i][j] = mul(0xe,a[i][j])
						^ mul(0xb,a[(i + 1) & 3][j])                 
						^ mul(0xd,a[(i + 2) & 3][j])
						^ mul(0x9,a[(i + 3) & 3][j]);                        

				for(i = 0; i < 4; i++)
					for(j = 0; j < block_size / 4; j++) 
						a[i][j] = b[i][j];
			}

			void KeySched (uint8_t k[4][max_key_size / 4], 
				uint8_t W[NR+1][4][block_size / 4]) {
					/* Calculate the necessary round keys
					* The number of calculations depends on keyBits and blockBits
					*/
					int i, j, t, rconpointer = 0;
					uint8_t tk[4][max_key_size / 4];

					for(j = 0; j < (max_key_size / 4); j++)
						for(i = 0; i < 4; i++)
							tk[i][j] = k[i][j];

					t = 0;
					/* copy values into round key array */
					for(j = 0; (j < (max_key_size / 4)) && (t < (NR+1)*(block_size / 4)); j++, t++)
						for(i = 0; i < 4; i++) 
							W[t / (block_size / 4)][i][t % (block_size / 4)] = tk[i][j];

					while (t < (NR+1)*(block_size / 4)) { 
						/* while not enough round key material calculated */
						/* calculate new values */
						for(i = 0; i < 4; i++)
							tk[i][0] ^= S[tk[(i+1)%4][(max_key_size / 4)-1]];

						tk[0][0] ^= rcon[rconpointer++];

						if ((max_key_size / 4) != 8)
							for(j = 1; j < (max_key_size / 4); j++)
								for(i = 0; i < 4; i++) 
									tk[i][j] ^= tk[i][j-1];
						else {
							for(j = 1; j < (max_key_size / 4)/2; j++)
								for(i = 0; i < 4; i++) 
									tk[i][j] ^= tk[i][j-1];

							for(i = 0; i < 4; i++) 
								tk[i][(max_key_size / 4)/2] ^= S[tk[i][(max_key_size / 4)/2 - 1]];

							for(j = (max_key_size / 4)/2 + 1; j < (max_key_size / 4); j++)
								for(i = 0; i < 4; i++) tk[i][j] ^= tk[i][j-1];
						}

						/* copy values into round key array */
						for(j = 0; (j < (max_key_size / 4)) && (t < (NR+1)*(block_size / 4)); j++, t++)
							for(i = 0; i < 4; i++) 
								W[t / (block_size / 4)][i][t % (block_size / 4)] = tk[i][j];
					}
			}

			void Encrypt(uint8_t a[4][(block_size/ 4)],
				uint8_t rk[NR+1][4][(block_size/ 4)]) {
				/* Encryption of one block. 
				*/
				int r;		

				/* begin with a key addition
				*/
				AddRoundKey(a,rk[0]); 

				/* NR-1 ordinary rounds
				*/
				for(r = 1; r < NR; r++) {
					SubBytes(a);
					ShiftRows(a,0);
					MixColumns(a);
					AddRoundKey(a,rk[r]);
				}

				/* Last round is special: there is no MixColumns
				*/
				SubBytes(a);
				ShiftRows(a,0);
				AddRoundKey(a,rk[NR]);
			}

			void Decrypt (uint8_t a[4][block_size / 4], 
				uint8_t rk[NR+1][4][block_size / 4]) {
				int r;
				/* To decrypt: apply the inverse operations of the encrypt routine,
				*             in opposite order
				* 
				* (AddRoundKey is an involution: it 's equal to its inverse)
				* (the inverse of Substitution with table S is Substitution with 
				*           the inverse table of S)
				* (the inverse of ShiftRows is ShiftRows over a suitable distance)
				*/

				/* First the special round:
				*   without InvMixColumns
				*   with extra AddRoundKey
				*/
				AddRoundKey(a,rk[NR]);
				InvSubBytes(a);
				ShiftRows(a,1);              

				/* NR-1 ordinary rounds
				*/
				for(r = NR-1; r > 0; r--) {
					AddRoundKey(a,rk[r]);
					InvMixColumns(a);      
					InvSubBytes(a);
					ShiftRows(a,1);                
				}

				/* End with the extra key addition
				*/
				AddRoundKey(a,rk[0]);
			}
		};

		template<size_t NR>
		class rijndael_cipher<128,128,NR> {
		public:
			typedef byte_t value_type;
			typedef size_t size_type;

			static constexpr char* name() { return "Rijndael<128,128>"; }
			static constexpr size_type rounds = NR;
			static constexpr size_type min_key_size = 0;
			static constexpr size_type max_key_size = 128 / 8;
			static constexpr size_type block_size   = 128 / 8;

		private:
			// Rounds should be multiple of 2 rounds
			BOOST_STATIC_ASSERT(!(rounds % 2));

			bool m_initialised;
			uint32_t m_enc_rk[(rounds+2)*4];
			uint32_t m_dec_rk[(rounds+2)*4];

		public:
			rijndael_cipher() 
				: m_initialised(false) {
			}

			rijndael_cipher(const void* key, size_type key_size) {
				setkey(key, key_size);
			}

			int setkey(const void* key, size_type key_size) throw (invalid_key_size) {

				BOOST_CRYPTO_CHECK_KEYSIZE(key_size,rijndael_cipher::setkey());

				int i, j;
				uint32_t temp;
				uint8_t k[max_key_size];
				uint32_t *rk = m_enc_rk;

				std::memcpy(k, key    , key_size);
				std::memset(k+key_size, 000, max_key_size-key_size);

				using namespace detail::rijndael;

				rk[0] = endian::read_le32(reinterpret_cast<const uint32_t*>(k)+0);
				rk[1] = endian::read_le32(reinterpret_cast<const uint32_t*>(k)+1);
				rk[2] = endian::read_le32(reinterpret_cast<const uint32_t*>(k)+2);
				rk[3] = endian::read_le32(reinterpret_cast<const uint32_t*>(k)+3);
				for (i=0;;) {
					temp  = rk[3];
					rk[4] = rk[0] ^
						(Te4[(temp >> 16) & 0xff] & 0xff000000) ^
						(Te4[(temp >>  8) & 0xff] & 0x00ff0000) ^
						(Te4[(temp      ) & 0xff] & 0x0000ff00) ^
						(Te4[(temp >> 24)       ] & 0x000000ff) ^
						rcon[i];
					rk[5] = rk[1] ^ rk[4];
					rk[6] = rk[2] ^ rk[5];
					rk[7] = rk[3] ^ rk[6];
					if (++i == rounds) {
						break ;
					}
					rk += 4;
				}
				/* expand the cipher key: */
				std::memcpy(m_dec_rk, m_enc_rk, (rounds+1)*16);
				rk = m_dec_rk;

				/* invert the order of the round keys: */
				for (i = 0, j = 4*rounds; i < j; i += 4, j -= 4) {
					temp = rk[i    ]; rk[i    ] = rk[j    ]; rk[j    ] = temp;
					temp = rk[i + 1]; rk[i + 1] = rk[j + 1]; rk[j + 1] = temp;
					temp = rk[i + 2]; rk[i + 2] = rk[j + 2]; rk[j + 2] = temp;
					temp = rk[i + 3]; rk[i + 3] = rk[j + 3]; rk[j + 3] = temp;
				}
				/* apply the inverse MixColumn transform to all round keys but the first and the last: */
				for (i = 1; i < rounds; i++) {
					rk += 4;
					rk[0] =
						Td0[Te4[(rk[0] >> 24)       ] & 0xff] ^
						Td1[Te4[(rk[0] >> 16) & 0xff] & 0xff] ^
						Td2[Te4[(rk[0] >>  8) & 0xff] & 0xff] ^
						Td3[Te4[(rk[0]      ) & 0xff] & 0xff];
					rk[1] =
						Td0[Te4[(rk[1] >> 24)       ] & 0xff] ^
						Td1[Te4[(rk[1] >> 16) & 0xff] & 0xff] ^
						Td2[Te4[(rk[1] >>  8) & 0xff] & 0xff] ^
						Td3[Te4[(rk[1]      ) & 0xff] & 0xff];
					rk[2] =
						Td0[Te4[(rk[2] >> 24)       ] & 0xff] ^
						Td1[Te4[(rk[2] >> 16) & 0xff] & 0xff] ^
						Td2[Te4[(rk[2] >>  8) & 0xff] & 0xff] ^
						Td3[Te4[(rk[2]      ) & 0xff] & 0xff];
					rk[3] =
						Td0[Te4[(rk[3] >> 24)       ] & 0xff] ^
						Td1[Te4[(rk[3] >> 16) & 0xff] & 0xff] ^
						Td2[Te4[(rk[3] >>  8) & 0xff] & 0xff] ^
						Td3[Te4[(rk[3]      ) & 0xff] & 0xff];
				}

				m_initialised = true;
			}

			void encrypt(void* ctxt, const void* ptxt) throw (cipher_not_initialised) {
				BOOST_CRYPTO_CHECK_STATE(rijndael_cipher::encrypt());

				uint32_t s0, s1, s2, s3, t0, t1, t2, t3;
				uint32_t *rk = m_enc_rk;

				using namespace detail::rijndael;
				/*
				* map byte array block to cipher state
				* and add initial round key:
				*/
				s0 = endian::read_be32(reinterpret_cast<const uint32_t*>(ptxt) + 0) ^ rk[0];
				s1 = endian::read_be32(reinterpret_cast<const uint32_t*>(ptxt) + 1) ^ rk[1];
				s2 = endian::read_be32(reinterpret_cast<const uint32_t*>(ptxt) + 2) ^ rk[2];
				s3 = endian::read_be32(reinterpret_cast<const uint32_t*>(ptxt) + 3) ^ rk[3];
				/*
				* Nr - 1 full rounds:
				*/
				;
				for (int r = rounds/2; ; ) {
					t0 =
						Te0[(s0 >> 24)       ] ^
						Te1[(s1 >> 16) & 0xff] ^
						Te2[(s2 >>  8) & 0xff] ^
						Te3[(s3      ) & 0xff] ^
						rk[4];
					t1 =
						Te0[(s1 >> 24)       ] ^
						Te1[(s2 >> 16) & 0xff] ^
						Te2[(s3 >>  8) & 0xff] ^
						Te3[(s0      ) & 0xff] ^
						rk[5];
					t2 =
						Te0[(s2 >> 24)       ] ^
						Te1[(s3 >> 16) & 0xff] ^
						Te2[(s0 >>  8) & 0xff] ^
						Te3[(s1      ) & 0xff] ^
						rk[6];
					t3 =
						Te0[(s3 >> 24)       ] ^
						Te1[(s0 >> 16) & 0xff] ^
						Te2[(s1 >>  8) & 0xff] ^
						Te3[(s2      ) & 0xff] ^
						rk[7];

					rk += 8;
					if (--r == 0) {
						break;
					}

					s0 =
						Te0[(t0 >> 24)       ] ^
						Te1[(t1 >> 16) & 0xff] ^
						Te2[(t2 >>  8) & 0xff] ^
						Te3[(t3      ) & 0xff] ^
						rk[0];
					s1 =
						Te0[(t1 >> 24)       ] ^
						Te1[(t2 >> 16) & 0xff] ^
						Te2[(t3 >>  8) & 0xff] ^
						Te3[(t0      ) & 0xff] ^
						rk[1];
					s2 =
						Te0[(t2 >> 24)       ] ^
						Te1[(t3 >> 16) & 0xff] ^
						Te2[(t0 >>  8) & 0xff] ^
						Te3[(t1      ) & 0xff] ^
						rk[2];
					s3 =
						Te0[(t3 >> 24)       ] ^
						Te1[(t0 >> 16) & 0xff] ^
						Te2[(t1 >>  8) & 0xff] ^
						Te3[(t2      ) & 0xff] ^
						rk[3];
				}
				/*
				* apply last round and
				* map cipher state to byte array block:
				*/
				s0 =
					(Te4[(t0 >> 24)       ] & 0xff000000) ^
					(Te4[(t1 >> 16) & 0xff] & 0x00ff0000) ^
					(Te4[(t2 >>  8) & 0xff] & 0x0000ff00) ^
					(Te4[(t3      ) & 0xff] & 0x000000ff) ^
					rk[0];
				endian::write_be32(reinterpret_cast<uint32_t*>(ctxt)+0, s0);
				s1 =
					(Te4[(t1 >> 24)       ] & 0xff000000) ^
					(Te4[(t2 >> 16) & 0xff] & 0x00ff0000) ^
					(Te4[(t3 >>  8) & 0xff] & 0x0000ff00) ^
					(Te4[(t0      ) & 0xff] & 0x000000ff) ^
					rk[1];
				endian::write_be32(reinterpret_cast<uint32_t*>(ctxt)+1, s1);
				s2 =
					(Te4[(t2 >> 24)       ] & 0xff000000) ^
					(Te4[(t3 >> 16) & 0xff] & 0x00ff0000) ^
					(Te4[(t0 >>  8) & 0xff] & 0x0000ff00) ^
					(Te4[(t1      ) & 0xff] & 0x000000ff) ^
					rk[2];
				endian::write_be32(reinterpret_cast<uint32_t*>(ctxt)+2, s2);
				s3 =
					(Te4[(t3 >> 24)       ] & 0xff000000) ^
					(Te4[(t0 >> 16) & 0xff] & 0x00ff0000) ^
					(Te4[(t1 >>  8) & 0xff] & 0x0000ff00) ^
					(Te4[(t2      ) & 0xff] & 0x000000ff) ^
					rk[3];
				endian::write_be32(reinterpret_cast<uint32_t*>(ctxt)+3, s3);
			}

			void decrypt(void* ptxt, const void* ctxt)  throw (cipher_not_initialised) {

				BOOST_CRYPTO_CHECK_STATE(rijndael_cipher::decrypt());

				uint32_t s0, s1, s2, s3, t0, t1, t2, t3;
				const uint32_t *rk = m_dec_rk;

				using namespace detail::rijndael;
				/*
				* add initial round key:
				*/		
				s0 = endian::read_be32(reinterpret_cast<const uint32_t*>(ctxt) + 0) ^ rk[0];
				s1 = endian::read_be32(reinterpret_cast<const uint32_t*>(ctxt) + 1) ^ rk[1];
				s2 = endian::read_be32(reinterpret_cast<const uint32_t*>(ctxt) + 2) ^ rk[2];
				s3 = endian::read_be32(reinterpret_cast<const uint32_t*>(ctxt) + 3) ^ rk[3];

				/*
				* Nr - 1 full rounds:
				*/
				for (int r = rounds / 2; ; ) {
					t0 =
						Td0[(s0 >> 24)       ] ^
						Td1[(s3 >> 16) & 0xff] ^
						Td2[(s2 >>  8) & 0xff] ^
						Td3[(s1      ) & 0xff] ^
						rk[4];
					t1 =
						Td0[(s1 >> 24)       ] ^
						Td1[(s0 >> 16) & 0xff] ^
						Td2[(s3 >>  8) & 0xff] ^
						Td3[(s2      ) & 0xff] ^
						rk[5];
					t2 =
						Td0[(s2 >> 24)       ] ^
						Td1[(s1 >> 16) & 0xff] ^
						Td2[(s0 >>  8) & 0xff] ^
						Td3[(s3      ) & 0xff] ^
						rk[6];
					t3 =
						Td0[(s3 >> 24)       ] ^
						Td1[(s2 >> 16) & 0xff] ^
						Td2[(s1 >>  8) & 0xff] ^
						Td3[(s0      ) & 0xff] ^
						rk[7];

					rk += 8;
					if (--r == 0) {
						break;
					}

					s0 =
						Td0[(t0 >> 24)       ] ^
						Td1[(t3 >> 16) & 0xff] ^
						Td2[(t2 >>  8) & 0xff] ^
						Td3[(t1      ) & 0xff] ^
						rk[0];
					s1 =
						Td0[(t1 >> 24)       ] ^
						Td1[(t0 >> 16) & 0xff] ^
						Td2[(t3 >>  8) & 0xff] ^
						Td3[(t2      ) & 0xff] ^
						rk[1];
					s2 =
						Td0[(t2 >> 24)       ] ^
						Td1[(t1 >> 16) & 0xff] ^
						Td2[(t0 >>  8) & 0xff] ^
						Td3[(t3      ) & 0xff] ^
						rk[2];
					s3 =
						Td0[(t3 >> 24)       ] ^
						Td1[(t2 >> 16) & 0xff] ^
						Td2[(t1 >>  8) & 0xff] ^
						Td3[(t0      ) & 0xff] ^
						rk[3];
				}
				/*
				* apply last round and
				* map cipher state to byte array block:
				*/
				s0 =
					(Td4[(t0 >> 24)       ] & 0xff000000) ^
					(Td4[(t3 >> 16) & 0xff] & 0x00ff0000) ^
					(Td4[(t2 >>  8) & 0xff] & 0x0000ff00) ^
					(Td4[(t1      ) & 0xff] & 0x000000ff) ^
					rk[0];
				endian::write_be32(reinterpret_cast<uint32_t*>(ptxt)+0, s0);
				s1 =
					(Td4[(t1 >> 24)       ] & 0xff000000) ^
					(Td4[(t0 >> 16) & 0xff] & 0x00ff0000) ^
					(Td4[(t3 >>  8) & 0xff] & 0x0000ff00) ^
					(Td4[(t2      ) & 0xff] & 0x000000ff) ^
					rk[1];
				endian::write_be32(reinterpret_cast<uint32_t*>(ptxt)+1, s1);
				s2 =
					(Td4[(t2 >> 24)       ] & 0xff000000) ^
					(Td4[(t1 >> 16) & 0xff] & 0x00ff0000) ^
					(Td4[(t0 >>  8) & 0xff] & 0x0000ff00) ^
					(Td4[(t3      ) & 0xff] & 0x000000ff) ^
					rk[2];
				endian::write_be32(reinterpret_cast<uint32_t*>(ptxt)+2, s2);
				s3 =
					(Td4[(t3 >> 24)       ] & 0xff000000) ^
					(Td4[(t2 >> 16) & 0xff] & 0x00ff0000) ^
					(Td4[(t1 >>  8) & 0xff] & 0x0000ff00) ^
					(Td4[(t0      ) & 0xff] & 0x000000ff) ^
					rk[3];
				endian::write_be32(reinterpret_cast<uint32_t*>(ptxt)+3, s3);
			}
		};

		template<size_t NR>
		class rijndael_cipher<192,128,NR>
		{
		public:
			typedef byte_t value_type;
			typedef size_t size_type;

			static constexpr char* name() { return "Rijndael<192,128>"; }
			static constexpr size_type rounds = NR;
			static constexpr size_type min_key_size = 0;
			static constexpr size_type max_key_size = 192 / 8;
			static constexpr size_type block_size   = 128 / 8;

		private:
			// Rounds should be multiple of 2 rounds
			BOOST_STATIC_ASSERT(!(rounds % 2));

			bool m_initialised;
			uint32_t m_enc_rk[(rounds+2)*4];
			uint32_t m_dec_rk[(rounds+2)*4];

		public:
			rijndael_cipher() 
				: m_initialised(false) {
			}

			rijndael_cipher(const void* key, size_type key_size) {
				setkey(key, key_size);
			}

			int setkey(const void* key, size_type key_size) throw (invalid_key_size) {

				BOOST_CRYPTO_CHECK_KEYSIZE(key_size,rijndael_cipher::setkey());

				int i, j;
				uint32_t temp;
				uint8_t k[max_key_size];
				uint32_t *rk = m_enc_rk;

				std::memcpy(k, key    , key_size);
				std::memset(k+key_size, 000, max_key_size-key_size);

				using namespace detail::rijndael;

				rk[0] = endian::read_le32(reinterpret_cast<const uint32_t*>(k)+0);
				rk[1] = endian::read_le32(reinterpret_cast<const uint32_t*>(k)+1);
				rk[2] = endian::read_le32(reinterpret_cast<const uint32_t*>(k)+2);
				rk[3] = endian::read_le32(reinterpret_cast<const uint32_t*>(k)+3);
				rk[4] = endian::read_le32(reinterpret_cast<const uint32_t*>(k)+4);
				rk[5] = endian::read_le32(reinterpret_cast<const uint32_t*>(k)+5);

				for (i=0;;) {
					temp = rk[ 5];
					rk[ 6] = rk[ 0] ^
						(Te4[(temp >> 16) & 0xff] & 0xff000000) ^
						(Te4[(temp >>  8) & 0xff] & 0x00ff0000) ^
						(Te4[(temp      ) & 0xff] & 0x0000ff00) ^
						(Te4[(temp >> 24)       ] & 0x000000ff) ^
						rcon[i];
					rk[ 7] = rk[ 1] ^ rk[ 6];
					rk[ 8] = rk[ 2] ^ rk[ 7];
					rk[ 9] = rk[ 3] ^ rk[ 8];
					if (++i == rounds/2) {
						break ;
					}
					rk[10] = rk[ 4] ^ rk[ 9];
					rk[11] = rk[ 5] ^ rk[10];
					rk += 6;
				}

				/* expand the cipher key: */
				std::memcpy(m_dec_rk, m_enc_rk, (rounds+1)*16);
				rk = m_dec_rk;

				/* invert the order of the round keys: */
				for (i = 0, j = 4*rounds; i < j; i += 4, j -= 4) {
					temp = rk[i    ]; rk[i    ] = rk[j    ]; rk[j    ] = temp;
					temp = rk[i + 1]; rk[i + 1] = rk[j + 1]; rk[j + 1] = temp;
					temp = rk[i + 2]; rk[i + 2] = rk[j + 2]; rk[j + 2] = temp;
					temp = rk[i + 3]; rk[i + 3] = rk[j + 3]; rk[j + 3] = temp;
				}
				/* apply the inverse MixColumn transform to all round keys but the first and the last: */
				for (i = 1; i < rounds; i++) {
					rk += 4;
					rk[0] =
						Td0[Te4[(rk[0] >> 24)       ] & 0xff] ^
						Td1[Te4[(rk[0] >> 16) & 0xff] & 0xff] ^
						Td2[Te4[(rk[0] >>  8) & 0xff] & 0xff] ^
						Td3[Te4[(rk[0]      ) & 0xff] & 0xff];
					rk[1] =
						Td0[Te4[(rk[1] >> 24)       ] & 0xff] ^
						Td1[Te4[(rk[1] >> 16) & 0xff] & 0xff] ^
						Td2[Te4[(rk[1] >>  8) & 0xff] & 0xff] ^
						Td3[Te4[(rk[1]      ) & 0xff] & 0xff];
					rk[2] =
						Td0[Te4[(rk[2] >> 24)       ] & 0xff] ^
						Td1[Te4[(rk[2] >> 16) & 0xff] & 0xff] ^
						Td2[Te4[(rk[2] >>  8) & 0xff] & 0xff] ^
						Td3[Te4[(rk[2]      ) & 0xff] & 0xff];
					rk[3] =
						Td0[Te4[(rk[3] >> 24)       ] & 0xff] ^
						Td1[Te4[(rk[3] >> 16) & 0xff] & 0xff] ^
						Td2[Te4[(rk[3] >>  8) & 0xff] & 0xff] ^
						Td3[Te4[(rk[3]      ) & 0xff] & 0xff];
				}

				m_initialised = true;
			}

			void encrypt(void* ctxt, const void* ptxt) throw (cipher_not_initialised) {
				BOOST_CRYPTO_CHECK_STATE(rijndael_cipher::encrypt());

				uint32_t s0, s1, s2, s3, t0, t1, t2, t3;
				uint32_t *rk = m_enc_rk;

				using namespace detail::rijndael;
				/*
				* map byte array block to cipher state
				* and add initial round key:
				*/
				s0 = endian::read_be32(reinterpret_cast<const uint32_t*>(ptxt) + 0) ^ rk[0];
				s1 = endian::read_be32(reinterpret_cast<const uint32_t*>(ptxt) + 1) ^ rk[1];
				s2 = endian::read_be32(reinterpret_cast<const uint32_t*>(ptxt) + 2) ^ rk[2];
				s3 = endian::read_be32(reinterpret_cast<const uint32_t*>(ptxt) + 3) ^ rk[3];
				/*
				* Nr - 1 full rounds:
				*/
				;
				for (int r = rounds/2; ; ) {
					t0 =
						Te0[(s0 >> 24)       ] ^
						Te1[(s1 >> 16) & 0xff] ^
						Te2[(s2 >>  8) & 0xff] ^
						Te3[(s3      ) & 0xff] ^
						rk[4];
					t1 =
						Te0[(s1 >> 24)       ] ^
						Te1[(s2 >> 16) & 0xff] ^
						Te2[(s3 >>  8) & 0xff] ^
						Te3[(s0      ) & 0xff] ^
						rk[5];
					t2 =
						Te0[(s2 >> 24)       ] ^
						Te1[(s3 >> 16) & 0xff] ^
						Te2[(s0 >>  8) & 0xff] ^
						Te3[(s1      ) & 0xff] ^
						rk[6];
					t3 =
						Te0[(s3 >> 24)       ] ^
						Te1[(s0 >> 16) & 0xff] ^
						Te2[(s1 >>  8) & 0xff] ^
						Te3[(s2      ) & 0xff] ^
						rk[7];

					rk += 8;
					if (--r == 0) {
						break;
					}

					s0 =
						Te0[(t0 >> 24)       ] ^
						Te1[(t1 >> 16) & 0xff] ^
						Te2[(t2 >>  8) & 0xff] ^
						Te3[(t3      ) & 0xff] ^
						rk[0];
					s1 =
						Te0[(t1 >> 24)       ] ^
						Te1[(t2 >> 16) & 0xff] ^
						Te2[(t3 >>  8) & 0xff] ^
						Te3[(t0      ) & 0xff] ^
						rk[1];
					s2 =
						Te0[(t2 >> 24)       ] ^
						Te1[(t3 >> 16) & 0xff] ^
						Te2[(t0 >>  8) & 0xff] ^
						Te3[(t1      ) & 0xff] ^
						rk[2];
					s3 =
						Te0[(t3 >> 24)       ] ^
						Te1[(t0 >> 16) & 0xff] ^
						Te2[(t1 >>  8) & 0xff] ^
						Te3[(t2      ) & 0xff] ^
						rk[3];
				}
				/*
				* apply last round and
				* map cipher state to byte array block:
				*/
				s0 =
					(Te4[(t0 >> 24)       ] & 0xff000000) ^
					(Te4[(t1 >> 16) & 0xff] & 0x00ff0000) ^
					(Te4[(t2 >>  8) & 0xff] & 0x0000ff00) ^
					(Te4[(t3      ) & 0xff] & 0x000000ff) ^
					rk[0];
				endian::write_be32(reinterpret_cast<uint32_t*>(ctxt)+0, s0);
				s1 =
					(Te4[(t1 >> 24)       ] & 0xff000000) ^
					(Te4[(t2 >> 16) & 0xff] & 0x00ff0000) ^
					(Te4[(t3 >>  8) & 0xff] & 0x0000ff00) ^
					(Te4[(t0      ) & 0xff] & 0x000000ff) ^
					rk[1];
				endian::write_be32(reinterpret_cast<uint32_t*>(ctxt)+1, s1);
				s2 =
					(Te4[(t2 >> 24)       ] & 0xff000000) ^
					(Te4[(t3 >> 16) & 0xff] & 0x00ff0000) ^
					(Te4[(t0 >>  8) & 0xff] & 0x0000ff00) ^
					(Te4[(t1      ) & 0xff] & 0x000000ff) ^
					rk[2];
				endian::write_be32(reinterpret_cast<uint32_t*>(ctxt)+2, s2);
				s3 =
					(Te4[(t3 >> 24)       ] & 0xff000000) ^
					(Te4[(t0 >> 16) & 0xff] & 0x00ff0000) ^
					(Te4[(t1 >>  8) & 0xff] & 0x0000ff00) ^
					(Te4[(t2      ) & 0xff] & 0x000000ff) ^
					rk[3];
				endian::write_be32(reinterpret_cast<uint32_t*>(ctxt)+3, s3);
			}


			void decrypt(void* ptxt, const void* ctxt)  throw (cipher_not_initialised) {
				BOOST_CRYPTO_CHECK_STATE(rijndael_cipher::encrypt());

				uint32_t s0, s1, s2, s3, t0, t1, t2, t3;
				const uint32_t *rk = m_dec_rk;

				using namespace detail::rijndael;
				/*
				* add initial round key:
				*/		
				s0 = endian::read_be32(reinterpret_cast<const uint32_t*>(ctxt) + 0) ^ rk[0];
				s1 = endian::read_be32(reinterpret_cast<const uint32_t*>(ctxt) + 1) ^ rk[1];
				s2 = endian::read_be32(reinterpret_cast<const uint32_t*>(ctxt) + 2) ^ rk[2];
				s3 = endian::read_be32(reinterpret_cast<const uint32_t*>(ctxt) + 3) ^ rk[3];

				/*
				* Nr - 1 full rounds:
				*/
				for (int r = rounds / 2; ; ) {
					t0 =
						Td0[(s0 >> 24)       ] ^
						Td1[(s3 >> 16) & 0xff] ^
						Td2[(s2 >>  8) & 0xff] ^
						Td3[(s1      ) & 0xff] ^
						rk[4];
					t1 =
						Td0[(s1 >> 24)       ] ^
						Td1[(s0 >> 16) & 0xff] ^
						Td2[(s3 >>  8) & 0xff] ^
						Td3[(s2      ) & 0xff] ^
						rk[5];
					t2 =
						Td0[(s2 >> 24)       ] ^
						Td1[(s1 >> 16) & 0xff] ^
						Td2[(s0 >>  8) & 0xff] ^
						Td3[(s3      ) & 0xff] ^
						rk[6];
					t3 =
						Td0[(s3 >> 24)       ] ^
						Td1[(s2 >> 16) & 0xff] ^
						Td2[(s1 >>  8) & 0xff] ^
						Td3[(s0      ) & 0xff] ^
						rk[7];

					rk += 8;
					if (--r == 0) {
						break;
					}

					s0 =
						Td0[(t0 >> 24)       ] ^
						Td1[(t3 >> 16) & 0xff] ^
						Td2[(t2 >>  8) & 0xff] ^
						Td3[(t1      ) & 0xff] ^
						rk[0];
					s1 =
						Td0[(t1 >> 24)       ] ^
						Td1[(t0 >> 16) & 0xff] ^
						Td2[(t3 >>  8) & 0xff] ^
						Td3[(t2      ) & 0xff] ^
						rk[1];
					s2 =
						Td0[(t2 >> 24)       ] ^
						Td1[(t1 >> 16) & 0xff] ^
						Td2[(t0 >>  8) & 0xff] ^
						Td3[(t3      ) & 0xff] ^
						rk[2];
					s3 =
						Td0[(t3 >> 24)       ] ^
						Td1[(t2 >> 16) & 0xff] ^
						Td2[(t1 >>  8) & 0xff] ^
						Td3[(t0      ) & 0xff] ^
						rk[3];
				}
				/*
				* apply last round and
				* map cipher state to byte array block:
				*/
				s0 =
					(Td4[(t0 >> 24)       ] & 0xff000000) ^
					(Td4[(t3 >> 16) & 0xff] & 0x00ff0000) ^
					(Td4[(t2 >>  8) & 0xff] & 0x0000ff00) ^
					(Td4[(t1      ) & 0xff] & 0x000000ff) ^
					rk[0];
				endian::write_be32(reinterpret_cast<uint32_t*>(ptxt)+0, s0);
				s1 =
					(Td4[(t1 >> 24)       ] & 0xff000000) ^
					(Td4[(t0 >> 16) & 0xff] & 0x00ff0000) ^
					(Td4[(t3 >>  8) & 0xff] & 0x0000ff00) ^
					(Td4[(t2      ) & 0xff] & 0x000000ff) ^
					rk[1];
				endian::write_be32(reinterpret_cast<uint32_t*>(ptxt)+1, s1);
				s2 =
					(Td4[(t2 >> 24)       ] & 0xff000000) ^
					(Td4[(t1 >> 16) & 0xff] & 0x00ff0000) ^
					(Td4[(t0 >>  8) & 0xff] & 0x0000ff00) ^
					(Td4[(t3      ) & 0xff] & 0x000000ff) ^
					rk[2];
				endian::write_be32(reinterpret_cast<uint32_t*>(ptxt)+2, s2);
				s3 =
					(Td4[(t3 >> 24)       ] & 0xff000000) ^
					(Td4[(t2 >> 16) & 0xff] & 0x00ff0000) ^
					(Td4[(t1 >>  8) & 0xff] & 0x0000ff00) ^
					(Td4[(t0      ) & 0xff] & 0x000000ff) ^
					rk[3];
				endian::write_be32(reinterpret_cast<uint32_t*>(ptxt)+3, s3);
			}

		};

		template<size_t NR>
		class rijndael_cipher<256,128,NR>
		{
		public:
			typedef byte_t value_type;
			typedef size_t size_type;

			static constexpr char* name() { return "Rijndael<256,128>"; }
			static constexpr size_type rounds = NR;
			static constexpr size_type min_key_size = 0;
			static constexpr size_type max_key_size = 256 / 8;
			static constexpr size_type block_size   = 128 / 8;

		private:
			// Rounds should be multiple of 2 rounds
			BOOST_STATIC_ASSERT(!(rounds % 2));

			bool m_initialised;
			uint32_t m_enc_rk[(rounds+2)*4];
			uint32_t m_dec_rk[(rounds+2)*4];

		public:
			rijndael_cipher() 
				: m_initialised(false) {
			}

			rijndael_cipher(const void* key, size_type key_size) {
				setkey(key, key_size);
			}

			int setkey(const void* key, size_type key_size) throw (invalid_key_size) {

				BOOST_CRYPTO_CHECK_KEYSIZE(key_size,rijndael_cipher::setkey());

				int i, j;
				uint32_t temp;
				uint8_t k[max_key_size];
				uint32_t *rk = m_enc_rk;

				std::memcpy(k, key    , key_size);
				std::memset(k+key_size, 000, max_key_size-key_size);

				using namespace detail::rijndael;

				rk[0] = endian::read_le32(reinterpret_cast<const uint32_t*>(k)+0);
				rk[1] = endian::read_le32(reinterpret_cast<const uint32_t*>(k)+1);
				rk[2] = endian::read_le32(reinterpret_cast<const uint32_t*>(k)+2);
				rk[3] = endian::read_le32(reinterpret_cast<const uint32_t*>(k)+3);
				rk[4] = endian::read_le32(reinterpret_cast<const uint32_t*>(k)+4);
				rk[5] = endian::read_le32(reinterpret_cast<const uint32_t*>(k)+5);
				rk[6] = endian::read_le32(reinterpret_cast<const uint32_t*>(k)+6);
				rk[7] = endian::read_le32(reinterpret_cast<const uint32_t*>(k)+7);

				for (i=0; ; ) {
					temp = rk[ 7];
					rk[ 8] = rk[ 0] ^
						(Te4[(temp >> 16) & 0xff] & 0xff000000) ^
						(Te4[(temp >>  8) & 0xff] & 0x00ff0000) ^
						(Te4[(temp      ) & 0xff] & 0x0000ff00) ^
						(Te4[(temp >> 24)       ] & 0x000000ff) ^
						rcon[i];
					rk[ 9] = rk[ 1] ^ rk[ 8];
					rk[10] = rk[ 2] ^ rk[ 9];
					rk[11] = rk[ 3] ^ rk[10];
					if (++i == NR / 2) {
						break ;
					}
					temp = rk[11];
					rk[12] = rk[ 4] ^
						(Te4[(temp >> 24)       ] & 0xff000000) ^
						(Te4[(temp >> 16) & 0xff] & 0x00ff0000) ^
						(Te4[(temp >>  8) & 0xff] & 0x0000ff00) ^
						(Te4[(temp      ) & 0xff] & 0x000000ff);
					rk[13] = rk[ 5] ^ rk[12];
					rk[14] = rk[ 6] ^ rk[13];
					rk[15] = rk[ 7] ^ rk[14];

					rk += 8;
				}

				/* expand the cipher key: */
				std::memcpy(m_dec_rk, m_enc_rk, (rounds+2)*16);
				rk = m_dec_rk;

				/* invert the order of the round keys: */
				for (i = 0, j = 4*rounds; i < j; i += 4, j -= 4) {
					temp = rk[i    ]; rk[i    ] = rk[j    ]; rk[j    ] = temp;
					temp = rk[i + 1]; rk[i + 1] = rk[j + 1]; rk[j + 1] = temp;
					temp = rk[i + 2]; rk[i + 2] = rk[j + 2]; rk[j + 2] = temp;
					temp = rk[i + 3]; rk[i + 3] = rk[j + 3]; rk[j + 3] = temp;
				}

				/* apply the inverse MixColumn transform to all round keys but the first and the last: */
				for (i = 1; i < rounds; i++) {
					rk += 4;
					rk[0] =
						Td0[Te4[(rk[0] >> 24)       ] & 0xff] ^
						Td1[Te4[(rk[0] >> 16) & 0xff] & 0xff] ^
						Td2[Te4[(rk[0] >>  8) & 0xff] & 0xff] ^
						Td3[Te4[(rk[0]      ) & 0xff] & 0xff];
					rk[1] =
						Td0[Te4[(rk[1] >> 24)       ] & 0xff] ^
						Td1[Te4[(rk[1] >> 16) & 0xff] & 0xff] ^
						Td2[Te4[(rk[1] >>  8) & 0xff] & 0xff] ^
						Td3[Te4[(rk[1]      ) & 0xff] & 0xff];
					rk[2] =
						Td0[Te4[(rk[2] >> 24)       ] & 0xff] ^
						Td1[Te4[(rk[2] >> 16) & 0xff] & 0xff] ^
						Td2[Te4[(rk[2] >>  8) & 0xff] & 0xff] ^
						Td3[Te4[(rk[2]      ) & 0xff] & 0xff];
					rk[3] =
						Td0[Te4[(rk[3] >> 24)       ] & 0xff] ^
						Td1[Te4[(rk[3] >> 16) & 0xff] & 0xff] ^
						Td2[Te4[(rk[3] >>  8) & 0xff] & 0xff] ^
						Td3[Te4[(rk[3]      ) & 0xff] & 0xff];
				}

				m_initialised = true;
			}

			void encrypt(void* ctxt, const void* ptxt) throw (cipher_not_initialised) {
				BOOST_CRYPTO_CHECK_STATE(rijndael_cipher::encrypt());

				uint32_t s0, s1, s2, s3, t0, t1, t2, t3;
				uint32_t *rk = m_enc_rk;

				using namespace detail::rijndael;
				/*
				* map byte array block to cipher state
				* and add initial round key:
				*/
				s0 = endian::read_be32(reinterpret_cast<const uint32_t*>(ptxt) + 0) ^ rk[0];
				s1 = endian::read_be32(reinterpret_cast<const uint32_t*>(ptxt) + 1) ^ rk[1];
				s2 = endian::read_be32(reinterpret_cast<const uint32_t*>(ptxt) + 2) ^ rk[2];
				s3 = endian::read_be32(reinterpret_cast<const uint32_t*>(ptxt) + 3) ^ rk[3];
				/*
				* Nr - 1 full rounds:
				*/
				;
				for (int r = rounds/2; ; ) {
					t0 =
						Te0[(s0 >> 24)       ] ^
						Te1[(s1 >> 16) & 0xff] ^
						Te2[(s2 >>  8) & 0xff] ^
						Te3[(s3      ) & 0xff] ^
						rk[4];
					t1 =
						Te0[(s1 >> 24)       ] ^
						Te1[(s2 >> 16) & 0xff] ^
						Te2[(s3 >>  8) & 0xff] ^
						Te3[(s0      ) & 0xff] ^
						rk[5];
					t2 =
						Te0[(s2 >> 24)       ] ^
						Te1[(s3 >> 16) & 0xff] ^
						Te2[(s0 >>  8) & 0xff] ^
						Te3[(s1      ) & 0xff] ^
						rk[6];
					t3 =
						Te0[(s3 >> 24)       ] ^
						Te1[(s0 >> 16) & 0xff] ^
						Te2[(s1 >>  8) & 0xff] ^
						Te3[(s2      ) & 0xff] ^
						rk[7];

					rk += 8;
					if (--r == 0) {
						break;
					}

					s0 =
						Te0[(t0 >> 24)       ] ^
						Te1[(t1 >> 16) & 0xff] ^
						Te2[(t2 >>  8) & 0xff] ^
						Te3[(t3      ) & 0xff] ^
						rk[0];
					s1 =
						Te0[(t1 >> 24)       ] ^
						Te1[(t2 >> 16) & 0xff] ^
						Te2[(t3 >>  8) & 0xff] ^
						Te3[(t0      ) & 0xff] ^
						rk[1];
					s2 =
						Te0[(t2 >> 24)       ] ^
						Te1[(t3 >> 16) & 0xff] ^
						Te2[(t0 >>  8) & 0xff] ^
						Te3[(t1      ) & 0xff] ^
						rk[2];
					s3 =
						Te0[(t3 >> 24)       ] ^
						Te1[(t0 >> 16) & 0xff] ^
						Te2[(t1 >>  8) & 0xff] ^
						Te3[(t2      ) & 0xff] ^
						rk[3];
				}
				/*
				* apply last round and
				* map cipher state to byte array block:
				*/
				s0 =
					(Te4[(t0 >> 24)       ] & 0xff000000) ^
					(Te4[(t1 >> 16) & 0xff] & 0x00ff0000) ^
					(Te4[(t2 >>  8) & 0xff] & 0x0000ff00) ^
					(Te4[(t3      ) & 0xff] & 0x000000ff) ^
					rk[0];
				endian::write_be32(reinterpret_cast<uint32_t*>(ctxt)+0, s0);
				s1 =
					(Te4[(t1 >> 24)       ] & 0xff000000) ^
					(Te4[(t2 >> 16) & 0xff] & 0x00ff0000) ^
					(Te4[(t3 >>  8) & 0xff] & 0x0000ff00) ^
					(Te4[(t0      ) & 0xff] & 0x000000ff) ^
					rk[1];
				endian::write_be32(reinterpret_cast<uint32_t*>(ctxt)+1, s1);
				s2 =
					(Te4[(t2 >> 24)       ] & 0xff000000) ^
					(Te4[(t3 >> 16) & 0xff] & 0x00ff0000) ^
					(Te4[(t0 >>  8) & 0xff] & 0x0000ff00) ^
					(Te4[(t1      ) & 0xff] & 0x000000ff) ^
					rk[2];
				endian::write_be32(reinterpret_cast<uint32_t*>(ctxt)+2, s2);
				s3 =
					(Te4[(t3 >> 24)       ] & 0xff000000) ^
					(Te4[(t0 >> 16) & 0xff] & 0x00ff0000) ^
					(Te4[(t1 >>  8) & 0xff] & 0x0000ff00) ^
					(Te4[(t2      ) & 0xff] & 0x000000ff) ^
					rk[3];
				endian::write_be32(reinterpret_cast<uint32_t*>(ctxt)+3, s3);
			}


			void decrypt(void* ptxt, const void* ctxt)  throw (cipher_not_initialised) {
				BOOST_CRYPTO_CHECK_STATE(rijndael_cipher::encrypt());

				uint32_t s0, s1, s2, s3, t0, t1, t2, t3;
				const uint32_t *rk = m_dec_rk;

				using namespace detail::rijndael;
				/*
				* add initial round key:
				*/		
				s0 = endian::read_be32(reinterpret_cast<const uint32_t*>(ctxt) + 0) ^ rk[0];
				s1 = endian::read_be32(reinterpret_cast<const uint32_t*>(ctxt) + 1) ^ rk[1];
				s2 = endian::read_be32(reinterpret_cast<const uint32_t*>(ctxt) + 2) ^ rk[2];
				s3 = endian::read_be32(reinterpret_cast<const uint32_t*>(ctxt) + 3) ^ rk[3];

				/*
				* Nr - 1 full rounds:
				*/
				for (int r = rounds / 2; ; ) {
					t0 =
						Td0[(s0 >> 24)       ] ^
						Td1[(s3 >> 16) & 0xff] ^
						Td2[(s2 >>  8) & 0xff] ^
						Td3[(s1      ) & 0xff] ^
						rk[4];
					t1 =
						Td0[(s1 >> 24)       ] ^
						Td1[(s0 >> 16) & 0xff] ^
						Td2[(s3 >>  8) & 0xff] ^
						Td3[(s2      ) & 0xff] ^
						rk[5];
					t2 =
						Td0[(s2 >> 24)       ] ^
						Td1[(s1 >> 16) & 0xff] ^
						Td2[(s0 >>  8) & 0xff] ^
						Td3[(s3      ) & 0xff] ^
						rk[6];
					t3 =
						Td0[(s3 >> 24)       ] ^
						Td1[(s2 >> 16) & 0xff] ^
						Td2[(s1 >>  8) & 0xff] ^
						Td3[(s0      ) & 0xff] ^
						rk[7];

					rk += 8;
					if (--r == 0) {
						break;
					}

					s0 =
						Td0[(t0 >> 24)       ] ^
						Td1[(t3 >> 16) & 0xff] ^
						Td2[(t2 >>  8) & 0xff] ^
						Td3[(t1      ) & 0xff] ^
						rk[0];
					s1 =
						Td0[(t1 >> 24)       ] ^
						Td1[(t0 >> 16) & 0xff] ^
						Td2[(t3 >>  8) & 0xff] ^
						Td3[(t2      ) & 0xff] ^
						rk[1];
					s2 =
						Td0[(t2 >> 24)       ] ^
						Td1[(t1 >> 16) & 0xff] ^
						Td2[(t0 >>  8) & 0xff] ^
						Td3[(t3      ) & 0xff] ^
						rk[2];
					s3 =
						Td0[(t3 >> 24)       ] ^
						Td1[(t2 >> 16) & 0xff] ^
						Td2[(t1 >>  8) & 0xff] ^
						Td3[(t0      ) & 0xff] ^
						rk[3];
				}
				/*
				* apply last round and
				* map cipher state to byte array block:
				*/
				s0 =
					(Td4[(t0 >> 24)       ] & 0xff000000) ^
					(Td4[(t3 >> 16) & 0xff] & 0x00ff0000) ^
					(Td4[(t2 >>  8) & 0xff] & 0x0000ff00) ^
					(Td4[(t1      ) & 0xff] & 0x000000ff) ^
					rk[0];
				endian::write_be32(reinterpret_cast<uint32_t*>(ptxt)+0, s0);
				s1 =
					(Td4[(t1 >> 24)       ] & 0xff000000) ^
					(Td4[(t0 >> 16) & 0xff] & 0x00ff0000) ^
					(Td4[(t3 >>  8) & 0xff] & 0x0000ff00) ^
					(Td4[(t2      ) & 0xff] & 0x000000ff) ^
					rk[1];
				endian::write_be32(reinterpret_cast<uint32_t*>(ptxt)+1, s1);
				s2 =
					(Td4[(t2 >> 24)       ] & 0xff000000) ^
					(Td4[(t1 >> 16) & 0xff] & 0x00ff0000) ^
					(Td4[(t0 >>  8) & 0xff] & 0x0000ff00) ^
					(Td4[(t3      ) & 0xff] & 0x000000ff) ^
					rk[2];
				endian::write_be32(reinterpret_cast<uint32_t*>(ptxt)+2, s2);
				s3 =
					(Td4[(t3 >> 24)       ] & 0xff000000) ^
					(Td4[(t2 >> 16) & 0xff] & 0x00ff0000) ^
					(Td4[(t1 >>  8) & 0xff] & 0x0000ff00) ^
					(Td4[(t0      ) & 0xff] & 0x000000ff) ^
					rk[3];
				endian::write_be32(reinterpret_cast<uint32_t*>(ptxt)+3, s3);
			}
		};


		// [NOTE] These typedefs are optomsied versions of the algorithm
		// other variants are supported however they are slower.
		typedef rijndael_cipher<128,128> aes128;
		typedef rijndael_cipher<192,128> aes192;
		typedef rijndael_cipher<256,128> aes256;

	} // namespace boost::crypto
} // namespace boost 

#endif /* BOOST_CRYPTO_RIJNDAEL_HPP_INCLUDED */
