#ifndef BOOST_CRYPTO_RC6_HPP_INCLUDED
#define BOOST_CRYPTO_RC6_HPP_INCLUDED
#         
#include "crypto.hpp"
#include "crypto_endian.hpp"
#include "crypto_rotation.hpp"
#include "rc5.hpp" // for magic constants
#
#include <boost/cstdint.hpp>
#include <boost/mpl/min.hpp>

namespace boost {
	namespace crypto {

		// this is a generic implementation of RC6
		// NR is the # of rounds
		// WT is the word type to be used supporting 8-bit, 16-bit, 32-bit and 64-bit
		// other wordsizes could be implemented but their corresponding type and 
		// rotation functions as well as wlog() functino needs to be updated
		template<size_t NR=20/* # of rounds */, typename WT=uint32_t>
		class rc6_cipher
		{
		public:
			typedef byte_t	value_type;
			typedef WT			word_type;
			typedef size_t	size_type;

			static constexpr size_t min_key_size = 0;
			static constexpr size_t max_key_size = 8*sizeof(word_type);
			static constexpr size_t block_size   = 4*sizeof(word_type);
			static constexpr size_t rounds       = NR;
			static constexpr char*  name() { return "RC6"; }
		private:
			BOOST_STATIC_ASSERT(sizeof(WT) == 1 || sizeof(WT) == 2 
				|| sizeof(WT) == 4 || sizeof(WT) == 8);

			// This implementation unrolls 4 rounds for efficiency
			// therefore, NR should be multiples of 4
			BOOST_STATIC_ASSERT((rounds % 4) == 0);

		private:
			static constexpr int wlog() { 
				return (sizeof(word_type) == 1) ? 3 : 
					((sizeof(word_type) == (2)) ? (4) :
					((sizeof(word_type) == (4)) ? (5) : 
					(6))); 
			}

			bool			m_initialised;
			word_type	m_S[(2*(rounds+2))];

		public:

			rc6_cipher()
				:
			m_initialised(false)
			{
			}

			rc6_cipher(const void* key, size_t key_size)
				:
			m_initialised(false)
			{
				setkey(key, key_size);
			}

			~rc6_cipher()
			{
				std::memset(m_S,0,sizeof(m_S));
			}

			constexpr void setkey(const void*key, size_t key_size) throw (invalid_key_size)
			{
				BOOST_CRYPTO_CHECK_KEYSIZE(key_size,rc6_cipher::setkey());

				m_initialised = true;

				word_type L[((2*(rounds+2)))];

				int c = key_size / sizeof(word_type) + ((key_size&(sizeof(word_type)-1))?(1):(0));

				std::memset(L,0,c*sizeof(word_type));
				std::memcpy(L,key,key_size);

				for(int i=0; i<c; i++) endian::ensure_le(L+i);
				
				m_S[0] = detail::rc5::pw<word_type>::value;
				for(int i = 1; i<((2*(rounds+2))); i++)
					m_S[i] = m_S[i-1] + detail::rc5::qw<word_type>::value;

				word_type a=0, b=0;
				for(int s=1, i=0, j=0; s <= (3*((2*(rounds+2)))); s++)
				{
					a = m_S[ i ] = rol<word_type>(m_S[i] + a + b, 3);
					b = L[ j ] = rol<word_type>(L[j] + a + b, a + b);
					i = ( i + 1 )  % 44;
					j = ( j + 1 )  % c;
				}
			}

			constexpr void encrypt(void* ctxt, const void* ptxt) throw(cipher_not_initialised)
			{
				BOOST_CRYPTO_CHECK_STATE(rc6_cipher::encrypt());

				register word_type a,b,c,d,t,u;

				a = endian::read_le(reinterpret_cast<const word_type*>(ptxt)+0);
				b = endian::read_le(reinterpret_cast<const word_type*>(ptxt)+1);
				c = endian::read_le(reinterpret_cast<const word_type*>(ptxt)+2);
				d = endian::read_le(reinterpret_cast<const word_type*>(ptxt)+3);

				b += m_S[ 0 ];
				d += m_S[ 1 ];
				for(int r = 1; r <= rounds; r+=4)
				{
					/* 1 round version
					t = rol<word_type>(b*((b<<1)+1), 5);
					u = rol<word_type>(d*((d<<1)+1), 5);
					a = rol<word_type>((a ^ t),u) + m_S[(r<<1)];
					c = rol<word_type>((c ^ u),t) + m_S[(r<<1)+1];
					//t = a; a = b; b = c; c = d; d = t;
					*/
					
					/* 4 rounds version */
					t = rol<word_type>(b * ((b<<1)+1), wlog());
					u = rol<word_type>(d * ((d<<1)+1), wlog());
					a = rol<word_type>(a^t, u) + m_S[(r<<1)];
					c = rol<word_type>(c^u, t) + m_S[(r<<1)+1];

					t = rol<word_type>(c * ((c<<1)+1), wlog());
					u = rol<word_type>(a * ((a<<1)+1), wlog());
					b = rol<word_type>(b^t, u) + m_S[(r<<1)+2];
					d = rol<word_type>(d^u, t) + m_S[(r<<1)+3];

					t = rol<word_type>(d * ((d<<1)+1), wlog());
					u = rol<word_type>(b * ((b<<1)+1), wlog());
					c = rol<word_type>(c^t, u) + m_S[(r<<1)+4];
					a = rol<word_type>(a^u, t) + m_S[(r<<1)+5];					

					t = rol<word_type>(a * ((a<<1)+1), wlog());
					u = rol<word_type>(c * ((c<<1)+1), wlog());
					d = rol<word_type>(d^t, u) + m_S[(r<<1)+6];
					b = rol<word_type>(b^u, t) + m_S[(r<<1)+7];
				}
				a += m_S[ 2*rounds+2 ];
				c += m_S[ 2*rounds+3 ];

				endian::write_le(reinterpret_cast<word_type*>(ctxt)+0,a);
				endian::write_le(reinterpret_cast<word_type*>(ctxt)+1,b);
				endian::write_le(reinterpret_cast<word_type*>(ctxt)+2,c);
				endian::write_le(reinterpret_cast<word_type*>(ctxt)+3,d);
			}

			constexpr void decrypt(void* ptxt, const void* ctxt) throw(cipher_not_initialised)
			{
				BOOST_CRYPTO_CHECK_STATE(rc6_cipher::encrypt());
				register word_type a,b,c,d,t,u;

				a = endian::read_le(reinterpret_cast<const word_type*>(ctxt)+0);
				b = endian::read_le(reinterpret_cast<const word_type*>(ctxt)+1);
				c = endian::read_le(reinterpret_cast<const word_type*>(ctxt)+2);
				d = endian::read_le(reinterpret_cast<const word_type*>(ctxt)+3);

				c -= m_S[ 2*rounds+3 ];
				a -= m_S[ 2*rounds+2 ];
				for(int r = rounds; r >= 1; r -= 4)
				{
					/* 1 round version 
					t = a; a = d; d = c; c = b; b = t;
					u = rol<word_type>(d*((d<<1)+1), wlog()) ;
					t = rol<word_type>(b*((b<<1)+1), wlog());
					c = ror<word_type>((c-m_S[(r<<1)+1]),t) ^ u;
					a = ror<word_type>((a-m_S[(r<<1)]), u) ^ t;
					*/

					/* 4 round version */
					u = rol<word_type>(c*((c<<1)+1), wlog()) ;
					t = rol<word_type>(a*((a<<1)+1), wlog());
					b = ror<word_type>((b-m_S[(r<<1)+1]),t) ^ u;
					d = ror<word_type>((d-m_S[(r<<1)]), u) ^ t;
					
					u = rol<word_type>(b*((b<<1)+1), wlog()) ;
					t = rol<word_type>(d*((d<<1)+1), wlog());
					a = ror<word_type>((a-m_S[(r<<1)-1]),t) ^ u;
					c = ror<word_type>((c-m_S[(r<<1)-2]), u) ^ t;
					
					u = rol<word_type>(a*((a<<1)+1), wlog()) ;
					t = rol<word_type>(c*((c<<1)+1), wlog());
					d = ror<word_type>((d-m_S[(r<<1)-3]),t) ^ u;
					b = ror<word_type>((b-m_S[(r<<1)-4]), u) ^ t;
					
					u = rol<word_type>(d*((d<<1)+1), wlog()) ;
					t = rol<word_type>(b*((b<<1)+1), wlog());
					c = ror<word_type>((c-m_S[(r<<1)-5]),t) ^ u;
					a = ror<word_type>((a-m_S[(r<<1)-6]), u) ^ t;
				}
				d -= m_S[ 1 ] ;
				b -= m_S[ 0 ];

				endian::write_le(reinterpret_cast<word_type*>(ptxt)+0,a);
				endian::write_le(reinterpret_cast<word_type*>(ptxt)+1,b);
				endian::write_le(reinterpret_cast<word_type*>(ptxt)+2,c);
				endian::write_le(reinterpret_cast<word_type*>(ptxt)+3,d);
				
			}
		};

		// recommended rounds
		typedef rc6_cipher<20,uint32_t> rc6;

	} // namespace boost::crypto
} // namespace boost 

#endif /* BOOST_CRYPTO_RC6_HPP_INCLUDED */

