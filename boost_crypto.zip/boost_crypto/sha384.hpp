#ifndef BOOST_CRYPTO_SHA384_HPP_INCLUDED
#define BOOST_CRYPTO_SHA384_HPP_INCLUDED
#
#include "sha2.hpp"

namespace boost {
	namespace crypto {

		typedef sha2_ctx<uint64_t, 48,
			UINT64_C(0xcbbb9d5dc1059ed8), UINT64_C(0x629a292a367cd507),
			UINT64_C(0x9159015a3070dd17), UINT64_C(0x152fecd8f70e5939),
			UINT64_C(0x67332667ffc00b31), UINT64_C(0x8eb44a8768581511),
			UINT64_C(0xdb0c2e0d64f98fa7), UINT64_C(0x47b5481dbefa4fa4)
		> sha384_ctx;

	} // namespace crypto
} // namespace boost

#endif /* BOOST_CRYPTO_SHA384_HPP_INCLUDED */
