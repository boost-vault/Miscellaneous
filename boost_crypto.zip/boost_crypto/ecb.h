#ifndef BOOST_CRYPTO_ECB_HPP_INCLUDED
#define BOOST_CRYPTO_ECB_HPP_INCLUDED
#
#include <stdexcept>
#include <exception>
#include <cassert>
#include <cmath>
#
#include "crypto.hpp"
#include "padding_traits.hpp"
#include "crypto_concept.hpp"


namespace boost { 
	namespace crypto {
		namespace detail {
		} // namespace boost::crypto::detail 
		
		template<BlockCipher CipherT, PaddingAlgorithm PaddingT>
		class ecb
		{
		public:
			typedef CipherT		block_cipher_type;
			typedef PaddingT	padding_type;
			static constexpr size_t block_size = block_cipher_type::block_size;

			// ecb could seek 
			typedef parallel_cryption_tag stream_category;
			typedef typename block_cipher_type::size_type size_type;

			static constexpr size_type	transform_size = block_size;
			static constexpr size_type stream_size     = size_type(-1); // there is no limit
			static constexpr size_type	min_key_size   = block_cipher_type::min_key_size;
			static constexpr size_type	max_key_size   = block_cipher_type::max_key_size;
			static constexpr size_type	min_iv_size    = size_type(0);
			static constexpr size_type	max_iv_size    = block_cipher_type::block_size;
			static constexpr size_type pre_data_size   = block_size;
			static constexpr size_type post_data_size  = size_type(0);

		private:
			bool							m_created;
			bool							m_have_iv;
			StreamDirection		m_direction;
			block_cipher_type m_cipher;
			size_t						m_buffer_pos;
			typename block_cipher_type::value_type m_buffer[block_size];
			typename block_cipher_type::value_type m_iv [block_size], 
				m_key[typename block_cipher_type::max_key_size];

		protected:
			template<StreamDirection Direction>
			constexpr void transform()
			{
				/* dummy */
				BOOST_STATIC_ASSERT(
					Direction == StreamDirection::Decryption
					Direction == StreamDirection::Encryption);
			}

			template<> constexpr void transform<Encryption>()
			{
				assert(m_buffer_pos == block_size);
				m_cipher.encrypt(m_buffer,m_buffer);
			}

			template<> constexpr void transform<Decryption>()
			{
				assert(m_buffer_pos == block_size);
				m_cipher.decrypt(m_buffer,m_buffer);
			}
			
			template<StreamDirection Direction>
			constexpr void transform_buffer(void *output, const void* input, size_t input_size)
			{
				/* dummy */
				BOOST_STATIC_ASSERT(
					Direction == StreamDirection::Decryption
					Direction == StreamDirection::Encryption);
			}

			template<>
			constexpr void transform_buffer<Encryption>(void *output, const void* input, size_t input_size)
			{
				byte_t *out = reinterpret_cast<byte_t *>(output);
				const byte_t *in = reinterpret_cast<const byte_t *>(input);
				size_t in_size = input_size;

				while(in_size)
				{
					size_t used_size = fill_buffer(out, in, in_size);

					if(m_buffer_pos == block_size)
					{
						// transform block
						transform<Encryption>();

						// copy to output
						memcpy(out, m_buffer, block_size);

						out += block_size;
						m_buffer_pos = 0;
					}

					in += used_size;
					in_size -= used_size;						
				}
			}

			
			template<>
			constexpr void transform_buffer<Decryption>(void *output, const void* input, size_t input_size)
			{
				byte_t *out = reinterpret_cast<byte_t *>(output);
				const byte_t *in = reinterpret_cast<const byte_t *>(input);
				size_t in_size = input_size;
				byte_t tempbuf[block_size];

				while(in_size)
				{
					size_t used_size = fill_buffer(out, in, in_size);

					if(m_buffer_pos == block_size)
					{
						// we have a complete data block in [m_buffer]
						// transform block
						transform<Decryption>();

						// copy to output
						memcpy(out, m_buffer, block_size);

						// restore origian 
						out += block_size;
						m_buffer_pos = 0;
					}

					in += used_size;
					in_size -= used_size;						
				}
			}
			constexpr size_t fill_buffer(void *output, const void* input, size_t input_size)
			{
				assert((0 <= m_buffer_pos && m_buffer_pos <= block_size));
				
				size_t used_bytes = min(input_size, block_size - m_buffer_pos);
				m_buffer_pos += used_bytes;
				std::memcpy(m_buffer, input, used_bytes);
				return used_bytes;
			}

		public:
			cbc() 
				:
			m_buffer_pos(0),
				m_created(false),
				m_have_iv(false),
				m_cipher()
			{
			}

			// create using new credentials			
			template<StreamDirection Direction>
			constexpr void create(
				const void *key, size_t key_size, 
				const void *iv, size_t iv_size) throw(std::length_error)
			{
				create<Direction>(false);
				setkey(key,key_size);
				setiv(iv, iv_size);
			}

			// create using new credentials
			template<StreamDirection Direction>
			constexpr void create(const void *iv, size_t iv_size) throw(std::length_error)
			{
				create<Direction>(false);
				setiv(iv, iv_size);
			}
			
			// create using previous credentials
			template<StreamDirection Direction>
			constexpr void create(bool useiv=true) throw()
			{
				m_buffer_pos = 0;
				m_created = true;
				m_direction = Direction;
				if(useiv == true && m_have_iv == true)
				{
					std::memcpy(m_pre_data, m_iv, block_size);
				}
				else
				{
					std::memset(m_pre_data, 0, block_size);
				}
			}

			template<StreamDirection Direction>
			constexpr size_t update(void *output, const void *input, size_t input_size) throw(bad_cipher_state)
			{
				/* dummy */
				BOOST_STATIC_ASSERT(
					Direction != StreamDirection::Decryption || 
					Direction != StreamDirection::Encryption);
				// Code should not reach here
				BOOST_STATIC_ASSERT(false);
			}
			
			template<>
			constexpr size_t update<Encryption>(void *output, const void *input, size_t input_size) throw(bad_cipher_state)
			{
				if(!m_created)
					throw bad_cipher_state("cbc update() : !created");

				if(m_direction != Encryption)
					throw bad_cipher_state("cbc update() : !for encryption");
				
				transform_buffer<Encryption>(output, input, input_size);
				return input_size - m_buffer_pos;
			}
			
			template<>
			constexpr size_t update<Decryption>(void *output, const void *input, size_t input_size) throw(bad_cipher_state)
			{
				if(!m_created)
					throw bad_cipher_state("cbc update() : !created");

				if(m_direction != Decryption)
					throw bad_cipher_state("cbc update() : !for decryption");
				
				transform_buffer<Decryption>(output, input, input_size);
				
				return input_size - m_buffer_pos;
			}
			
			template<StreamDirection Direction>
			constexpr size_t finalise(void *output)
			{
				/* dummy */
				BOOST_STATIC_ASSERT(
					Direction != StreamDirection::Decryption || 
					Direction != StreamDirection::Encryption);
				// Code should not reach here
				BOOST_STATIC_ASSERT(false);
			}

			template<>
			constexpr size_t finalise<Encryption>(void *output)
			{
				if(!m_created)
					throw bad_cipher_state("cbc update() : !created");

				if(m_direction != Encryption)
					throw bad_cipher_state("cbc update() : invalid direction");

				size_t outsize = 0;

				// pad the block if neccessary
				if((m_buffer_pos < block_size && m_buffer_pos != 0) || padding_type::allways_pad)
				{
					outsize = padding_type::output_size(m_buffer_pos);

					assert(outsize <= block_size);

					padding_type::pad(m_buffer, m_buffer, m_buffer_pos);
					m_buffer_pos = outsize ;
				}

				if(m_buffer_pos > 0)
				{
					// xor with previous ciphertext
					memxor(m_buffer, m_pre_data, block_size);

					// transform block
					transform<Encryption>();

					// copy to output
					std::memcpy(output, m_buffer, outsize);
				}
				
				m_created = false;
				m_direction = stream_dir_unknown;

				return 0;
			}
						
			template<>
			constexpr size_t finalise<Decryption>(void *output)
			{
				if(!m_created)
					throw bad_cipher_state("cbc update() : !created");

				if(m_direction != Decryption)
					throw bad_cipher_state("cbc update() : invalid direction");

				size_t outsize = 0;

				// unpad the block if neccessary
				try
				{
					outsize = padding_type::unpad(m_buffer, m_buffer, block_size);
					// transform
					std::memcpy(output, m_buffer, outsize);
				}
				catch(bad_padding)
				{
					// okay unpadding was not necessary
					;
				}

				m_created = false;
				m_direction = stream_dir_unknown;

				return outsize;
			}


			constexpr void setkey(const void* key, size_t key_size)
			{
				m_cipher.setkey(key, key_size);
			}

			constexpr void setiv(const void* iv, size_t iv_size) throw (std::length_error)
			{
				if(!(min_iv_size <= iv_size && iv_size <= max_iv_size))
					throw std::length_error(std::string("invalid iv length"));

				std::memcpy(m_pre_data, iv, iv_size);
				std::memset(m_pre_data+iv_size, 0, pre_data_size-iv_size);
				m_have_iv = true;
			}

			constexpr void encrypt(void *ctxt, const void *ptxt, size_t ptxt_size)
			{
				size_t offset;
				create<Encryption>();
				offset = update<Encryption>(ctxt, ptxt, ptxt_size);
				finalise<Encryption>(((byte_t*)ctxt) + offset);
			}

			constexpr void decrypt(void *ptxt, const void *ctxt, size_t ctxt_size)
			{
				size_t offset;
				create<Decryption>();
				offset = update<Decryption>(ptxt, ctxt, ctxt_size);
				finalise<Decryption>(((byte_t*)ptxt) + offset - block_size);
			}
			
			
			template<StreamDirection Direction>
			constexpr void transform_block(
				void *outblock,			/* output block */
				const void* inblock,/* input block to be transformed */
				const void* prblock,/* predata block */
				const void* poblock=nullptr/* post data block (cbc does required poblock */)
			{
				/* this is a dummy, specialised templates should be used */
				BOOST_STATIC_ASSERT(false);
			}

			template<>
			constexpr void transform_block<Encryption>(
				void *outblock,			/* output block */
				const void* inblock,/* input block to be transformed */
				const void* prblock,/* predata block */
				const void* poblock /* post data block (cbc does required poblock */)
			{
				/* Note CBC could not parallised encryption, so it it not
				supported via this method. */
				BOOST_STATIC_ASSERT(false);
			}

			template<>
			constexpr void transform_block<Decryption>(
				void *outblock,			/* output block */
				const void* inblock,/* input block to be transformed */
				const void* prblock,/* predata block */
				const void* poblock /* post data block (cbc does required poblock */)
			{
				// decrypt current block, write to [outblock]
				m_cipher.decrypt(outblock, inblock);

				// xor with previous data block
				memxor(outblock, prblock, block_size);
			}
		};

		/*
		create()	: void   # create a new transformation context 
		update()	: size_t # size of bytes written to output buffer
		finalise(): size_t # size of bytes written to output buffer		
		*/
	} // namepace boost::crypto
} // namespace boost 


#endif /* BOOST_CRYPTO_ECB_HPP_INCLUDED */
