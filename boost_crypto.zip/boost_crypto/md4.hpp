//          Copyright Kasra Nassiri 2008-*.
// Distributed under the Boost Software License, Version 1.0.
//    (See accompanying file LICENSE_1_0.txt or copy at
//          http://www.boost.org/LICENSE_1_0.txt)
#ifndef BOOST_CRYPTO_DETAIL_MD4_CTX_HPP
#define BOOST_CRYPTO_DETAIL_MD4_CTX_HPP
#
#include "crypto.hpp"
#
#// concepts and states
#include "hash_function.hpp"
#
#// input buffering
#include "digest_buffer.hpp"
#
#// detail::md5::padding[]
#include "md5.hpp"
#
#/* f, g and h are basic md4 functions: selection, majority, parity */
#define F(x, y, z) (((x) & (y)) | ((~x) & (z)))
#define G(x, y, z) (((x) & (y)) | ((x) & (z)) | ((y) & (z)))
#define H(x, y, z) ((x) ^ (y) ^ (z))
#
#/* rotate_left rotates x left n bits */
#define lshift(x, n) BOOST_ROL32(x,n)
#
#define ROUND1(a,b,c,d,k,s) (a = lshift(a + F(b,c,d) + k, s))
#define ROUND2(a,b,c,d,k,s) (a = lshift(a + G(b,c,d) + k + UINT32_C(0x5A827999),s))
#define ROUND3(a,b,c,d,k,s) (a = lshift(a + H(b,c,d) + k + UINT32_C(0x6ED9EBA1),s))

namespace boost {
	namespace crypto {
		namespace detail {
			namespace md4 {
				// same padding material as of md5
			} // namespace md4
		} // namespace detail

		// struct only holds the data, it would not do any buffering and etc.
		class md4_ctx
		{
		public:
			typedef uint8_t  char_type;
			typedef uint32_t word_type;
			typedef size_t   size_type;

			/* size of the digest */
			static constexpr size_type digest_size       = 16;

			/* size of the internal state */
			static constexpr size_type state_size        = 16;

			/* minimum required size of each input block */
			static constexpr size_type transform_size    = 64;

			md4_ctx() { create(); }
			md4_ctx& operator = (md4_ctx& rhs)
			{
				m_state = rhs.m_state;
				m_message_bits = rhs.m_message_bits;

				std::memcpy(m_buf, rhs.m_buf   , state_size);
				std::memcpy(m_buf, rhs.m_digest, digest_size);

				return (*this);
			}


			~md4_ctx()
			{
				std::memset(m_buf, 0, sizeof(m_buf));
				std::memset(m_digest, 0, sizeof(m_digest));
				std::memset(&m_message_bits, 0, sizeof(m_message_bits));
			}

			// create a new stream, destroying any previously created streams
			void create() throw()
			{
				m_message_bits = 0;

				/* load magic initialization constants. */					
				m_buf[0] = (uint32_t)UINT32_C(0x67452301);
				m_buf[1] = (uint32_t)UINT32_C(0xefcdab89);
				m_buf[2] = (uint32_t)UINT32_C(0x98badcfe);
				m_buf[3] = (uint32_t)UINT32_C(0x10325476);
			}

			/* transform using previously set buffer, or assign a new pointer */
			/* [buf] should point to memory of size at least [transform_size] */
			md4_ctx& transform(const void* input) throw(bad_hash_state)
			{
				if(m_state != hash_function_processing)
					if(m_state == hash_function_created)		
						m_state = hash_function_processing;
					else if(m_state != hash_function_finalising)
						throw bad_hash_state("md4_ctx::transform() : could not transform an empty stream");

				const uint32_t *in = reinterpret_cast<const uint32_t*>(input);
				register uint32_t a = m_buf[0], b = m_buf[1], c = m_buf[2], d = m_buf[3];

				ROUND1(a, b, c, d, in[ 0], 3);
				ROUND1(d, a, b, c, in[ 1], 7);
				ROUND1(c, d, a, b, in[ 2], 11);
				ROUND1(b, c, d, a, in[ 3], 19);
				ROUND1(a, b, c, d, in[ 4], 3);
				ROUND1(d, a, b, c, in[ 5], 7);
				ROUND1(c, d, a, b, in[ 6], 11);
				ROUND1(b, c, d, a, in[ 7], 19);
				ROUND1(a, b, c, d, in[ 8], 3);
				ROUND1(d, a, b, c, in[ 9], 7);
				ROUND1(c, d, a, b, in[10], 11);
				ROUND1(b, c, d, a, in[11], 19);
				ROUND1(a, b, c, d, in[12], 3);
				ROUND1(d, a, b, c, in[13], 7);
				ROUND1(c, d, a, b, in[14], 11);
				ROUND1(b, c, d, a, in[15], 19);

				ROUND2(a, b, c, d, in[ 0], 3);
				ROUND2(d, a, b, c, in[ 4], 5);
				ROUND2(c, d, a, b, in[ 8], 9);
				ROUND2(b, c, d, a, in[12], 13);
				ROUND2(a, b, c, d, in[ 1], 3);
				ROUND2(d, a, b, c, in[ 5], 5);
				ROUND2(c, d, a, b, in[ 9], 9);
				ROUND2(b, c, d, a, in[13], 13);
				ROUND2(a, b, c, d, in[ 2], 3);
				ROUND2(d, a, b, c, in[ 6], 5);
				ROUND2(c, d, a, b, in[10], 9);
				ROUND2(b, c, d, a, in[14], 13);
				ROUND2(a, b, c, d, in[ 3], 3);
				ROUND2(d, a, b, c, in[ 7], 5);
				ROUND2(c, d, a, b, in[11], 9);
				ROUND2(b, c, d, a, in[15], 13);

				ROUND3(a, b, c, d, in[ 0], 3);
				ROUND3(d, a, b, c, in[ 8], 9);
				ROUND3(c, d, a, b, in[ 4], 11);
				ROUND3(b, c, d, a, in[12], 15);
				ROUND3(a, b, c, d, in[ 2], 3);
				ROUND3(d, a, b, c, in[10], 9);
				ROUND3(c, d, a, b, in[ 6], 11);
				ROUND3(b, c, d, a, in[14], 15);
				ROUND3(a, b, c, d, in[ 1], 3);
				ROUND3(d, a, b, c, in[ 9], 9);
				ROUND3(c, d, a, b, in[ 5], 11);
				ROUND3(b, c, d, a, in[13], 15);
				ROUND3(a, b, c, d, in[ 3], 3);
				ROUND3(d, a, b, c, in[11], 9);
				ROUND3(c, d, a, b, in[ 7], 11);
				ROUND3(b, c, d, a, in[15], 15);

				m_buf[0] += a;
				m_buf[1] += b;
				m_buf[2] += c;
				m_buf[3] += d;

				m_message_bits += transform_size * 8;

				return (*this);
			}

			// [input] is and in/complete buffer with size of [input_size]
			// returns a const pointer to the digest
			md4_ctx& finalise(const void* input, size_type input_size) throw(bad_hash_state)
			{
				m_state = hash_function_finalising;

				uint8_t buf[56];
				uint32_t in[16];
				int mdi;
				unsigned int i;
				unsigned int padlen;

				/* save number of bits */				
				m_message_bits += input_size * 8;
				endian::write_le((uint64_t*)(in+14), m_message_bits);

				/* compute number of bytes mod 64 */
				mdi = (int)((m_message_bits >> 3) & 0x3f);

				/* pad out to 56 mod 64 */
				padlen = (mdi < 56) ? (56 - mdi) : (120 - mdi);
				if(mdi < 56)
				{
					std::memcpy(buf, input, input_size);
					std::memcpy(buf+input_size,detail::md5::padding,padlen);
				}
				else
				{
					std::memcpy(buf+input_size,detail::md5::padding,padlen & 63);
					transform(input);
					std::memcpy(buf,detail::md5::padding,padlen -= 64);
				}

				/* append length in bits and transform */
				for (i = 0; i < 14; i++)
					in[i] = endian::read_le32(reinterpret_cast<const uint32_t*>(buf)+i);

				transform (in);

				/* store buffer in digest */
				for (i = 0; i < 4; i++)				
					endian::write_le32(reinterpret_cast<uint32_t*>(m_digest)+i, m_buf[i]);

				// we don't need these anymore
				m_message_bits=0;
				memset(m_buf, 00, sizeof(m_buf));

				m_state = hash_function_finished;

				return (*this);
			}

			/* 
			* get the pointer to state buffer
			*/
			const word_type* operator () () const { return m_buf; }

			/*
			* return the digest
			*/
			const void *digest() const throw(bad_hash_state)
			{
				if(m_state == hash_function_finished)
					return m_digest; 
				else
					throw bad_hash_state("md5_ctx::digest() : digest is not computed");
			}

		private:				
			// state of the hash instance
			hash_function_state m_state;

			// current buffer
			word_type	m_buf[4];				
			uint64_t	m_message_bits; /* total _bits_ handled mod 2^64 */
			uint8_t		m_digest[16];		/* working digest */
		};

	} // namespace crypto
} // namespace boost

#endif /* BOOST_CRYPTO_DETAIL_MD4_CTX_HPP */
