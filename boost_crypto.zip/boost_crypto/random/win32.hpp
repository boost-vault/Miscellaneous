/****************************************************************************
*
*						  Win32 Randomness-Gathering Code
*	Copyright Peter Gutmann, Matt Thomlinson and Blake Coverett 1996-2007
*
***************************************************************************/
/* This module is part of the cryptlib continuously seeded pseudorandom number
generator.  For usage conditions, see random.c */

#ifndef _BOOST_CRYPTO_RANDOM_WIN32_RANDOM_DEVICE_HPP_INCLUDED
#define _BOOST_CRYPTO_RANDOM_WIN32_RANDOM_DEVICE_HPP_INCLUDED


/* since this module is only designed to be for windows
* it makes use of windows API function call for task like 
* threading and mutexs */

/* General includes */
#include "random/random.h"
#include "crypto_random.h"
#
#include <boost/thread.hpp>
#
#/* OS-specific includes */
#include <tlhelp32.h>
#include <winperf.h>
#include <winioctl.h>
#include <process.h>
#include <windows.h>


/* Some new CPU opcodes aren't supported by all compiler versions, if
they're not available we define them here.  BC++ can only hndl the
emit directive outside an asm block, so we have to terminate the current
block, emit the opcode, and then restart the asm block.  In addition
while the 16-bit versions of BC++ had built-in asm support, the 32-bit
versions removed it and generate a temporary asm file which is passed
to Tasm32.  This is only included with some high-end versions of BC++,
and it's not possible to order it separately, so if you're building with
BC++ and get error messages about a missing tasm32.exe, add BOOST_CRYPTO_NO_INLINE_ASM to
Project Options | Compiler | Defines */
#if defined( _MSC_VER )
#  if _MSC_VER <= 1100
#   define cpuid		__asm _emit 0x0F __asm _emit 0xA2
#   define rdtsc		__asm _emit 0x0F __asm _emit 0x31
#  endif /* VC++ 5.0 or earlier */
# define xstore_rng	__asm _emit 0x0F __asm _emit 0xA7 __asm _emit 0xC0
#elif defined __BORLANDC__
# define cpuid			} __emit__( 0x0F, 0xA2 ); __asm {
# define rdtsc			} __emit__( 0x0F, 0x31 ); __asm {
# define xstore_rng	} __emit__( 0x0F, 0xA7, 0xC0 ); __asm {
#endif 

#/* The number of bytes to read from the systemtem RNG on each slow poll */
#define SYSRNG_BYTES		64

#/* Intel Chipset CSP type and name */
#define PROV_INTEL_SEC	22
#define INTEL_DEF_PROV	"Intel Hardware Cryptographic Service Provider"

#/* A mapping from CryptoAPI to standard data types */
#define HCRYPTPROV					HANDLE
#define BusType							char
#define SMBType							char
#define SensorType					char

#define SH_MEM_MAX_SENSORS	0x80

#define DIGCF_PRESENT				0x02
#define DIGCF_ALLCLASSES		0x04

#define SPDRP_HARDWAREID		0x01

#define PERFORMANCE_BUFFER_SIZE		65536	/* Start at 64K */
#define PERFORMANCE_BUFFER_STEP		16384	/* Step by 16K */

namespace boost { 
	namespace crypto {

		template<size_t T, HashAlgorithm U>
		class crypto_random_pool;

		class win32_random 
		{
		private:
#			ifdef BOOST_MSVC
#			pragma region "Typedefs"
#			endif
			/* Type definitions for function pointers to call CryptoAPI functions */
			typedef BOOL ( WINAPI *CRYPTACQUIRECONTEXT )( HCRYPTPROV *phProv,
				LPCTSTR pszContainer, LPCTSTR pszProvider, DWORD dwProvType, DWORD dwFlags );
			typedef BOOL ( WINAPI *CRYPTGENRANDOM )( HCRYPTPROV hProv, DWORD dwLen,
				BYTE *pbBuffer );
			typedef BOOL ( WINAPI *CRYPTRELEASECONTEXT )( HCRYPTPROV hProv, DWORD dwFlags );
			/* Somewhat alternative functionality available as a direct call, for 
			Windows XP and newer.  This is the CryptoAPI RNG, which isn't anywhere
			near as good as the HW RNG, but we use it if it's present on the basis
			that at least it can't make things any worse.  This direct access version 
			is only available under Windows XP and newer, we don't go out of our way 
			to access the more general CryptoAPI one since the main purpose of using 
			it is to take advantage of any possible future hardware RNGs that may be 
			added, for example via TCPA devices */
			typedef BOOL ( WINAPI *RTLGENRANDOM )( PVOID RandomBuffer, 
				ULONG RandomBufferLength );
			/****************************************************************************
			*
			*							Hardware Monitoring Interface
			*
			****************************************************************************/
			/* These interfaces currently support data supplied by MBM, Everest, 
			SysTool, RivaTuner, HMonitor, and ATI Tray Tools.  Two notable omissions
			are SVPro and HWMonitor, unfortunately the authors haven't responded to 
			any requests for interfacing information */
			/* MBM data structures, originally by Alexander van Kaam, converted to C by
			Anders@Majland.org, finally updated by Chris Zahrt <techn0@iastate.edu>.
			The char[8] values below are actually (64-bit) doubles, but we overlay 
			them with char[8] since we don't care about the values */
			typedef struct {
				char /*double*/sdVersion[8]; /* Version number (example: 51090) */

				struct SharedIndex {
					SensorType iType;		          /* Type of sensor */
					int Count;				            /* Number of sensor for that type */
				}  sdIndex[10];	                /* Sensor index */

				struct SharedSensor {
					SensorType ssType;			      /* Type of sensor */
					unsigned char ssName[12];	    /* Name of sensor */
					char sspadding1[3];		        /* Padding of 3 bytes */
					char /*double*/ ssCurrent[8]; /* Current value */
					char /*double*/ ssLow [8];	  /* Lowest readout */
					char /*double*/ ssHigh[8];	  /* Highest readout */
					long ssCount;				          /* Total number of readout */
					char sspadding2[4];		        /* Padding of 4 bytes */
					BYTE /*long double*/ ssTotal[8];/* Total amout of all readouts */
					char sspadding3[6];		        /* Padding of 6 bytes */
					char /*double*/ ssAlarm1[8];  /* Temp & fan: high alarm; voltage: % off */
					char /*double*/ ssAlarm2[8];  /* Temp: low alarm */
				}  sdSensor[100];               /* Sensor info */

				struct SharedInfo{
					short siSMB_Base;		          /* SMBus base address */
					BusType siSMB_Type;	          /* SMBus/Isa bus used to access chip */
					SMBType siSMB_Code;		        /* SMBus sub type, Intel, AMD or ALi */
					char siSMB_Addr;			        /* Address of sensor chip on SMBus */
					unsigned char siSMB_Name[41];	/* Nice name for SMBus */
					short siISA_Base;			        /* ISA base address of sensor chip on ISA */
					int siChipType;				        /* Chip nr, connects with Chipinfo.ini */
					char siVoltageSubType;        /* Subvoltage option selected */
				} sdInfo;                       /* Misc.info */
				unsigned char sdStart[41];	    /* Start time */
				/* We don't use the next two fields both because they're not random and
				because it provides a nice safety margin in case of data size mis-
				estimates (we always under-estimate the buffer size) */
				/*	unsigned char sdCurrent[41];	/* Current time */
				/*	unsigned char sdPath[256];	/* MBM path */
			} SharedData;
			/* SysTool data structures, from forums.techpowerup.com.  This uses the
			standard shared memory interface, but it gets a bit tricky because it 
			uses the OLE 'VARIANT' data type which we can't access because it's 
			included via a complex nested inclusion framework in windows.h, and the 
			use of '#pragma once' when we included it for use in crypt.h means that 
			we can't re-include any of the necessary files.  Since we don't actually 
			care what's inside a VARIANT, and it has a fixed size of 16 bytes, we 
			just use it as an opaque blob */
			typedef BYTE VARIANT[16];	/* Kludge for OLE data type */
			typedef enum { 
				sUnknown, sNumber, sTemperature, sVoltage, sRPM, sBytes, 
				sBytesPerSecond, sMhz, sPercentage, sString, sPWM 
			} SYSTOOL_SENSOR_TYPE;
			typedef struct {
				WCHAR name[255];	  /* Sensor name */
				WCHAR section[64];	/* Section in which this sensor appears */
				SYSTOOL_SENSOR_TYPE sensorType;
				LONG updateInProgress;/* Nonzero when sensor is being updated */
				UINT32 timestamp;		  /* GetTickCount() of last update */
				VARIANT value;		    /* Sensor data */
				WCHAR unit[8];	 	  /* Unit for text output */
				BYTE nDecimals;	    /* Default number of decimals for formatted output */
			} SYSTOOL_SHMEM_SENSOR;
			typedef struct {
				UINT32 version;		  /* Version of shared memory structure */
				WORD nSensors;		/* Number of records with data in sensors */
				SYSTOOL_SHMEM_SENSOR sensors[SH_MEM_MAX_SENSORS];
			} SYSTOOL_SHMEM;
			/* RivaTuner data structures via the shared-memory interface, from the 
			RivaTuner sample source.  The DWORD values below are actually (32-bit) 
			floats, but we overlay them with DWORDs since we don't care about the 
			values.  The information is only accessible when the RivaTuner hardware 
			monitoring window is open.  This one is the easiest of the shared-mem 
			interfaces to monitor because for fowards-compatibility reasons it 
			stores a Windows-style indicator of the size of each struct entry in the 
			data header, so we can get the total size simply by multiplying out the 
			number of entries by the indicated size.  As a safety measure we limit 
			the maximum data size to 2K in case a value gets corrupted */
			typedef struct {
				DWORD dwSignature;	/* 'RTHM' if active */
				DWORD dwVersion;	  /* Must be 0x10001 or above */
				DWORD dwNumEntries;	/* No.of RTHM_SHARED_MEMORY_ENTRY entries */
				time_t time;		    /* Last polling_status time */
				DWORD dwEntrySize;	/* Size of entries in RTHM_SHARED_MEMORY_ENTRY array */
			} RTHM_SHARED_MEMORY_HEADER;
			typedef struct {
				char czSrc[32];	     /* Source description */
				char czDim[16];	     /* Source measurement units */
				DWORD /*float*/ data;	 /* Source data */
				DWORD /*float*/ offset;/* Source offset, e.g. temp.compensation */
				DWORD /*float*/ dataTransformed;/* Source data in transformed(?) form */
				DWORD flags;		/* Misc.flags */
			} RTHM_SHARED_MEMORY_ENTRY;
			/* Read data from HMonitor via the shared-memory interface.  The DWORD 
			values below are actually (32-bit) floats, but we overlay them with 
			DWORDs since we don't care about the values.  Like RivaTuner's data the 
			info structure contains a length value at the start, so it's fairly easy 
			to work with */
			typedef struct {
				WORD length;
				WORD version;	/* Single 'DWORD length' before version 4.1 */
				DWORD /*float*/ temp[3];
				DWORD /*float*/ voltage[7];
				int fan[3];
			} HMONITOR_DATA;
			/* Read data from ATI Tray Tools via the shared-memory interface.  This has
			an added twist in that just because it's available to be read doesn't 
			mean that it contains any data, so we check that at least the GPU speed 
			and temp-monitoring-supported flag have nonzero values */
			typedef struct {
				DWORD CurGPU;		    /* GPU speed */
				DWORD CurMEM;		    /* Video memory speed */
				DWORD isGameActive;
				DWORD is3DActive;	  /* Boolean: 3D mode active */
				DWORD isTempMonSupported;	/* Boolean: Temp monitoring available */
				DWORD GPUTemp;		  /* GPU temp */
				DWORD ENVTemp;		  /* Video card temp */
				DWORD FanDuty;		  /* Fan duty cycle */
				DWORD MAXGpuTemp, MINGpuTemp;	/* Min/max GPU temp */
				DWORD MAXEnvTemp, MINEnvTemp;	/* Min/max video card temp */
				DWORD CurD3DAA, CurD3DAF;	/* Direct3D info */
				DWORD CurOGLAA, CurOGLAF;	/* OpenGL info */
				DWORD IsActive;		  /* Another 3D boolean */
				DWORD CurFPS;		    /* FPS rate */
				DWORD FreeVideo;	  /* Available video memory */
				DWORD FreeTexture;	/* Available texture memory */
				DWORD Cur3DApi;		  /* API used (D3D, OpenGL, etc) */
				DWORD MemUsed;		  /* ? */
			} TRAY_TOOLS_DATA;
			/* Read PnP configuration data.  This is mostly static per machine, but
			differs somewhat across machines.  We have to define the values ourselves
			here due to a combination of some of the values and functions not
			existing at the time VC++ 6.0 was released and */
			typedef void * HDEVINFO;
			typedef struct _SP_DEVINFO_DATA {
				DWORD cbSize;
				GUID classGuid;
				DWORD devInst;
				ULONG *reserved;
			} SP_DEVINFO_DATA, *PSP_DEVINFO_DATA;
			typedef BOOL ( WINAPI *SETUPDIDESTROYDEVICEINFOLIST )( HDEVINFO DeviceInfoSet );
			typedef BOOL ( WINAPI *SETUPDIENUMDEVICEINFO )( HDEVINFO DeviceInfoSet,
				DWORD MemberIndex,
				PSP_DEVINFO_DATA DeviceInfoData );
			typedef HDEVINFO ( WINAPI *SETUPDIGETCLASSDEVS )( /*CONST LPGUID*/ void *ClassGuid,
				/*PCTSTR*/ void *Enumerator,
				HWND hwndParent, DWORD Flags );
			typedef BOOL ( WINAPI *SETUPDIGETDEVICEREGISTRYPROPERTY )( HDEVINFO DeviceInfoSet,
				PSP_DEVINFO_DATA DeviceInfoData,
				DWORD Property, PDWORD PropertyRegDataType,
				PBYTE PropertyBuffer,
				DWORD PropertyBufferSize, PDWORD RequiredSize );			
			/* Type definitions for function pointers to call NetAPI32 functions */
			typedef DWORD ( WINAPI *NETSTATISTICSGET )( LPWSTR szServer, LPWSTR szService,
				DWORD dwLevel, DWORD dwOptions,
				LPBYTE *lpBuffer );
			typedef DWORD ( WINAPI *NETAPIBUFFERSIZE )( LPVOID lpBuffer, LPDWORD cbBuffer );
			typedef DWORD ( WINAPI *NETAPIBUFFERFREE )( LPVOID lpBuffer );
			/* Type definitions for functions to call native NT functions */
			typedef DWORD ( WINAPI *NTQUERYSYSINFO )( DWORD systemtemInformationClass,
				PVOID systemtemInformation,
				ULONG systemtemInformationLength,
				PULONG returnLength );
			typedef DWORD ( WINAPI *NTQUERYINFOPROCESS )( HANDLE processHandle,
				DWORD processInformationClass,
				PVOID processInformation,
				ULONG processInformationLength,
				PULONG returnLength );
			typedef DWORD ( WINAPI *NTPOWERINFO )( DWORD powerInformationClass,
				PVOID inputBuffer, ULONG inputBufferLength,
				PVOID outputBuffer, ULONG outputBufferLength );
			/* Type definitions for function pointers to call Toolhelp32 functions */
			typedef BOOL		( WINAPI *MODULEWALK )	( HANDLE hSnapshot, LPMODULEENTRY32 lpme );
			typedef BOOL		( WINAPI *THREADWALK )	( HANDLE hSnapshot, LPTHREADENTRY32 lpte );
			typedef BOOL		( WINAPI *PROCESSWALK )	( HANDLE hSnapshot, LPPROCESSENTRY32 lppe );
			typedef BOOL		( WINAPI *HEAPLISTWALK )( HANDLE hSnapshot, LPHEAPLIST32 lphl );
			typedef BOOL		( WINAPI *HEAPFIRST )		( LPHEAPENTRY32 lphe, DWORD th32ProcessID, DWORD th32HeapID );
			typedef BOOL		( WINAPI *HEAPNEXT )		( LPHEAPENTRY32 lphe );
			typedef HANDLE	( WINAPI *CREATESNAPSHOT )( DWORD dwFlags, DWORD th32ProcessID );

#			ifdef BOOST_MSVC
#			pragma endregion
#			endif


#			ifdef BOOST_MSVC
#			pragma region "Instance Variables"
#			endif
			/* Global function pointers. These are necessary because the functions need
			to be dynamically linked since older versions of Win95 and NT don't contain
			them */
			CRYPTACQUIRECONTEXT pCryptAcquireContext;
			CRYPTGENRANDOM			pCryptGenRandom			;
			CRYPTRELEASECONTEXT pCryptReleaseContext;
			RTLGENRANDOM				pRtlGenRandom				;

			/* Handle to the RNG CSP */
			bool systerng_available;	/* Whether systemtem RNG is available */
			HCRYPTPROV hProv;						/* Handle to Intel RNG CSP */

			/* Global function pointers. These are necessary because the functions need to
			be dynamically linked since only the Win95 kernel currently contains them.
			Explicitly linking to them will make the program unloadable under NT */
			CREATESNAPSHOT	pCreateToolhelp32Snapshot;
			MODULEWALK			pModule32First					;
			MODULEWALK			pModule32Next						;
			PROCESSWALK			pProcess32First					;
			PROCESSWALK			pProcess32Next					;
			THREADWALK			pThread32First					;
			THREADWALK			pThread32Next						;
			HEAPLISTWALK		pHeap32ListFirst				;
			HEAPLISTWALK		pHeap32ListNext					;
			HEAPFIRST				pHeap32First						;
			HEAPNEXT				pHeap32Next							;
			bool						addedFixedItems						;
			bool						slow_poll_winnt_run_once	;
			bool						polling_status									;

			/* Global function pointers. These are necessary because the functions need to
			be dynamically linked since only the WinNT kernel currently contains them.
			Explicitly linking to them will make the program unloadable under Win95 */
			NETSTATISTICSGET		pNetStatisticsGet					;
			NETAPIBUFFERSIZE		pNetApiBufferSize					;
			NETAPIBUFFERFREE		pNetApiBufferFree					;
			NTQUERYSYSINFO			pNtQuerySystemInformation ;
			NTQUERYINFOPROCESS	pNtQueryInformationProcess;
			NTPOWERINFO					pNtPowerInformation				;

			boost::mutex _mutex;
			/* Handles to various randomness objects */
			HANDLE hAdvAPI32;	/* Handle to misc.library */
			HANDLE hNetAPI32;	/* Handle to networking library */
			HANDLE hNTAPI;		/* Handle to NT kernel library */
			boost::thread_group	_threadgroup;
#			ifdef BOOST_MSVC
#			pragma endregion
#			endif


#			ifdef BOOST_MSVC
#			pragma region "Hardware Interfaces"
#			endif
			/* Read data from MBM via the shared-memory interface */
			template<size_t PoolSizeT, HashAlgorithm DigestT> 
			crypto_random_pool<PoolSizeT,DigestT>& mbdata( crypto_random_pool<PoolSizeT,DigestT>& pool )
			{
				HANDLE hMBMData;
				const SharedData *mbmDataPtr;

				if(! (hMBMData = OpenFileMapping( FILE_MAP_READ, false, "$M$B$M$5$S$D$" )) )
					return pool;

				mbmDataPtr = ( SharedData * )
					MapViewOfFile( hMBMData, FILE_MAP_READ, 0, 0, 0 );

				if( mbmDataPtr != nullptr )
				{
					static const int quality = 20;
					pool.write(mbmDataPtr, sizeof(SharedData));
					UnmapViewOfFile( mbmDataPtr );
				}
				CloseHandle( hMBMData );

				return pool;
			}


			/* Read data from Everest via the shared-memory interface.  Everest returns 
			information as an enormous XML text string so we have to be careful about 
			handling of lengths.  In general the returned length is 1-3K, so we 
			hard-limit it at 2K to ensure there are no problems if the trailing null 
			gets lost */
			template<size_t PoolSizeT, HashAlgorithm DigestT> 
			crypto_random_pool<PoolSizeT,DigestT>& everest_data( crypto_random_pool<PoolSizeT,DigestT>& pool )
			{
				HANDLE hEverestData;
				const void *everestDataPtr;
				int length;

				if( ( hEverestData = OpenFileMapping( FILE_MAP_READ, false,
					"EVEREST_SensorValues" ) ) == nullptr )
					return pool;

				if( ( everestDataPtr = MapViewOfFile( hEverestData, 
					FILE_MAP_READ, 0, 0, 0 ) ) != nullptr && 
					( length = strlen( (const char*)everestDataPtr ) ) > 128 )
				{
					static const int quality = 40;
					pool.write(everestDataPtr, min( length, 2048 ));
					UnmapViewOfFile( everestDataPtr );
				}
				CloseHandle( hEverestData );

				return pool;
			}

			template<size_t PoolSizeT, HashAlgorithm DigestT> 
			crypto_random_pool<PoolSizeT,DigestT>& systetool_data( crypto_random_pool<PoolSizeT,DigestT>& pool )
			{
				HANDLE hSysToolData;
				const SYSTOOL_SHMEM *systemToolDataPtr;

				if( ( hSysToolData = OpenFileMapping( FILE_MAP_READ, false,
					"SysToolSensors" ) ) == nullptr )
					return pool;

				if( ( systemToolDataPtr = ( SYSTOOL_SHMEM * )
					MapViewOfFile( hSysToolData, FILE_MAP_READ, 0, 0, 0 ) ) != nullptr )
				{
					static const int quality = 40;
					pool.write(systemToolDataPtr, sizeof(SYSTOOL_SHMEM));
					UnmapViewOfFile( systemToolDataPtr );
				}
				CloseHandle( hSysToolData );

				return pool;
			}

			template<size_t PoolSizeT, HashAlgorithm DigestT> 
			crypto_random_pool<PoolSizeT,DigestT>& rivia_truner_data( crypto_random_pool<PoolSizeT,DigestT>& pool )
			{
				HANDLE hRivaTunerData;
				RTHM_SHARED_MEMORY_HEADER *rivaTunerHeaderPtr;

				if( ( hRivaTunerData = OpenFileMapping( FILE_MAP_READ, false,
					"RTHMSharedMemory" ) ) == nullptr )
					return pool;

				if( ( rivaTunerHeaderPtr = ( RTHM_SHARED_MEMORY_HEADER * ) 
					MapViewOfFile( hRivaTunerData, FILE_MAP_READ, 0, 0, 0 ) ) != nullptr && 
					( rivaTunerHeaderPtr->dwSignature == 'RTHM' ) && 
					( rivaTunerHeaderPtr->dwVersion >= 0x10001 ) )
				{
					const BYTE *entryPtr = ( ( BYTE * ) rivaTunerHeaderPtr ) + 
						sizeof( RTHM_SHARED_MEMORY_HEADER );

					const int entryTotalSize = rivaTunerHeaderPtr->dwNumEntries * 
						rivaTunerHeaderPtr->dwEntrySize;
					static const int quality = 5;

					pool.write(entryPtr, min ( entryTotalSize, 2048 ));

					UnmapViewOfFile( rivaTunerHeaderPtr );
				}
				CloseHandle( hRivaTunerData );

				return pool;
			}

			template<size_t PoolSizeT, HashAlgorithm DigestT> 
			crypto_random_pool<PoolSizeT,DigestT>& hmonitor_data( crypto_random_pool<PoolSizeT,DigestT>& pool )
			{
				HANDLE hHMonitorData;
				HMONITOR_DATA *hMonitorDataPtr;

				if( ( hHMonitorData = OpenFileMapping( FILE_MAP_READ, false,
					"Hmonitor_Counters_Block" ) ) == nullptr )
					return pool;
				if( ( hMonitorDataPtr = ( HMONITOR_DATA * ) 
					MapViewOfFile( hHMonitorData, FILE_MAP_READ, 0, 0, 0 ) ) != nullptr && 
					( hMonitorDataPtr->version >= 0x4100 ) && 
					( hMonitorDataPtr->length >= 48 && hMonitorDataPtr->length <= 1024 ) )
				{
					static const int quality = 40;

					pool.write(hMonitorDataPtr, hMonitorDataPtr->length);

					UnmapViewOfFile( hMonitorDataPtr );
				}
				CloseHandle( hHMonitorData );

				return pool;
			}

			template<size_t PoolSizeT, HashAlgorithm DigestT> 
			crypto_random_pool<PoolSizeT,DigestT>& ati_tray_tool_data( crypto_random_pool<PoolSizeT,DigestT>& pool )
			{
				HANDLE hTrayToolsData;
				TRAY_TOOLS_DATA *trayToolsDataPtr;

				if( ( hTrayToolsData = OpenFileMapping( FILE_MAP_READ, false,
					"ATITRAY_SMEM" ) ) == nullptr )
					return pool;

				if( ( trayToolsDataPtr = ( TRAY_TOOLS_DATA * ) 
					MapViewOfFile( hTrayToolsData, FILE_MAP_READ, 0, 0, 0 ) ) != nullptr && 
					( trayToolsDataPtr->CurGPU >= 100 ) && 
					( trayToolsDataPtr->isTempMonSupported != 0 ) )
				{
					static const int quality = 8;
					pool.write(trayToolsDataPtr, sizeof(TRAY_TOOLS_DATA));

					UnmapViewOfFile( trayToolsDataPtr );
				}
				CloseHandle( hTrayToolsData );

				return pool;
			}

			/* Read data from the systemtem RNG, in theory the PIII hardware RNG but in
			practice more likely the CryptoAPI software RNG */
			template<size_t PoolSizeT, HashAlgorithm DigestT> 
			crypto_random_pool<PoolSizeT,DigestT>& systerng( crypto_random_pool<PoolSizeT,DigestT>& pool )
			{
				BYTE buffer[SYSRNG_BYTES + 8];
				int quality = 0;

				if( !systerng_available )
					return pool;

				/* Read SYSRNG_BYTES bytes from the systemtem RNG.  Rather presciently, 
				the code up until late 2007 stated that "We don't rely on this for 
				all our randomness requirements (particularly the software RNG) in 
				case it's broken in some way", and in November 2007 an analysis paper
				by Leo Dorrendorf, Zvi Gutterman, and Benny Pinkas showed that the
				CryptoAPI RNG is indeed broken, being neither forwards- nor 
				backwards-secure, being reseeded far too infrequently, and (as far as
				their reverse-engineering was able to tell) using far less entropy
				sources than cryptlib's built-in mechanisms even though the CryptoAPI
				one is deeply embedded in the OS.

				The way the CryptoAPI RNG works is that a systemtem RNG is used to key 
				a set of eight RC4 ciphers, each of which is used in turn in a round-
				robin fashion to output 20 bytes of randomness which are then hashed 
				with SHA1, with the operation being approximately:

				output[ 0...19] = SHA1( RC4[i++ % 8] );
				output[20...39] = SHA1( RC4[i++ % 8] );
				[...]

				Each RC4 cipher is re-keyed every 16KB of output, so for 8 ciphers
				the rekey interval is every 128KB of output.  Furthermore, although
				the kernel RNG used to key the RC4 ciphers stores its state in-
				kernel, the RC4 cipher state is stored in user-space and per-process.
				This means that in most cases the RNG is never re-keyed.  Finally,
				the way the RNG works means that it's possible to recover earlier
				state in O( 2^23 ).  See "Cryptanalysis of the Random Number 
				Generator of the Windows Operating System" for details */
				if( hProv != nullptr )
				{
					if( pCryptGenRandom( hProv, SYSRNG_BYTES, buffer ) )
						quality = 70;
				}
				else
				{
					if( pRtlGenRandom( buffer, SYSRNG_BYTES ) )
						quality = 30;
				}
				if( quality > 0 )
				{
					pool.write( buffer, SYSRNG_BYTES );
					BOOST_CRYPTO_ZEROISE( buffer, SYSRNG_BYTES );
				}

				return pool;
			}


			template<size_t PoolSizeT, HashAlgorithm DigestT> 
			crypto_random_pool<PoolSizeT,DigestT>& pnp_data( crypto_random_pool<PoolSizeT,DigestT>& pool )
			{
				HANDLE hSetupAPI;
				HDEVINFO hDevInfo;
				SETUPDIDESTROYDEVICEINFOLIST pSetupDiDestroyDeviceInfoList = nullptr;
				SETUPDIENUMDEVICEINFO pSetupDiEnumDeviceInfo = nullptr;
				SETUPDIGETCLASSDEVS pSetupDiGetClassDevs = nullptr;
				SETUPDIGETDEVICEREGISTRYPROPERTY pSetupDiGetDeviceRegistryProperty = nullptr;

				if( ( hSetupAPI = LoadLibrary( "SetupAPI.dll" ) ) == nullptr )
					return pool;

				/* Get pointers to the PnP functions.  Although the get class-devs
				and get device registry functions look like standard functions,
				they're actually macros that are mapped to (depending on the build
				type) xxxA or xxxW, so we access them under the straight-ASCII-
				function name */
				pSetupDiDestroyDeviceInfoList = ( SETUPDIDESTROYDEVICEINFOLIST ) 
					GetProcAddress( (HMODULE)hSetupAPI, "SetupDiDestroyDeviceInfoList" );

				pSetupDiEnumDeviceInfo = ( SETUPDIENUMDEVICEINFO ) 
					GetProcAddress( (HMODULE)hSetupAPI, "SetupDiEnumDeviceInfo" );

				pSetupDiGetClassDevs = ( SETUPDIGETCLASSDEVS ) 
					GetProcAddress( (HMODULE)hSetupAPI, "SetupDiGetClassDevsA" );

				pSetupDiGetDeviceRegistryProperty = ( SETUPDIGETDEVICEREGISTRYPROPERTY ) 
					GetProcAddress( (HMODULE)hSetupAPI, "SetupDiGetDeviceRegistryPropertyA" );

				if( pSetupDiDestroyDeviceInfoList == nullptr || 
					pSetupDiEnumDeviceInfo == nullptr || pSetupDiGetClassDevs == nullptr || 
					pSetupDiGetDeviceRegistryProperty == nullptr )
				{
					FreeLibrary( (HMODULE)hSetupAPI );
					return pool;
				}

				/* Get info on all PnP devices */
				hDevInfo = pSetupDiGetClassDevs( nullptr, nullptr, nullptr,
					DIGCF_PRESENT | DIGCF_ALLCLASSES );
				if( hDevInfo != INVALID_HANDLE_VALUE )
				{
					SP_DEVINFO_DATA devInfoData;
					BYTE buffer[1024 + 8];
					BYTE pnpBuffer[512 + 8];
					DWORD cbPnPBuffer;
					int deviceCount, iterationCount, status;

					/* Enumerate all PnP devices */
					BOOST_CRYPTO_ZEROISE( &devInfoData, sizeof( devInfoData ) );

					devInfoData.cbSize = sizeof( SP_DEVINFO_DATA );

					for( deviceCount = 0, iterationCount = 0;
						pSetupDiEnumDeviceInfo( hDevInfo, deviceCount, 
						&devInfoData ) && 
						iterationCount < 100000; 
					deviceCount++, iterationCount++ )
					{
						if( pSetupDiGetDeviceRegistryProperty( hDevInfo, &devInfoData,
							SPDRP_HARDWAREID, nullptr,
							pnpBuffer, 512, &cbPnPBuffer ) )
							pool.write(pnpBuffer, cbPnPBuffer);
					}

					assert( iterationCount < 100000 );
					pSetupDiDestroyDeviceInfoList( hDevInfo );
					pool.flush();
				}

				FreeLibrary( (HMODULE)hSetupAPI );

				return pool;
			}

#			ifdef BOOST_MSVC
#			pragma endregion
#			endif

#			ifdef BOOST_MSVC
#			pragma region "Slow Poll Variants"
#			endif

			/* Since there are a significant number of ToolHelp data blocks, we use a
			larger-than-usual intermediate buffer to cut down on kernel traffic */
			template<size_t PoolSizeT, HashAlgorithm DigestT> 
			crypto_random_pool<PoolSizeT,DigestT>& slow_poll_win95( crypto_random_pool<PoolSizeT,DigestT>& pool  )
			{
				PROCESSENTRY32 pe32;
				THREADENTRY32 te32;
				MODULEENTRY32 me32;
				HEAPLIST32 hl32;
				HANDLE hSnapshot;
				RANDOM_STATE randomState;
				BYTE buffer[(PoolSize * 4) + 8];
				int listCount = 0, iterationCount, status;

				/* The following are fixed for the lifetime of the process so we only
				add them once */
				if( !addedFixedItems )
				{
					pnp_data();
					addedFixedItems = true;
				}

				/* Initialize the Toolhelp32 function pointers if necessary */
				if( pCreateToolhelp32Snapshot == nullptr )
				{
					HANDLE hKernel;

					/* Obtain the module hndl of the kernel to retrieve the addresses
					of the Toolhelp32 functions */
					if( ( hKernel = GetModuleHandle( "Kernel32.dll" ) ) == nullptr )
						return pool;

					/* Now get pointers to the functions */
					pCreateToolhelp32Snapshot = ( CREATESNAPSHOT ) GetProcAddress( (HMODULE)hKernel, "CreateToolhelp32Snapshot" );
					pModule32First	= ( MODULEWALK )	GetProcAddress( (HMODULE)hKernel, "Module32First"	);
					pModule32Next		= ( MODULEWALK )	GetProcAddress( (HMODULE)hKernel, "Module32Next"		);
					pProcess32First = ( PROCESSWALK ) GetProcAddress( (HMODULE)hKernel, "Process32First" );
					pProcess32Next	= ( PROCESSWALK ) GetProcAddress( (HMODULE)hKernel, "Process32Next"	);
					pThread32First	= ( THREADWALK )	GetProcAddress( (HMODULE)hKernel, "Thread32First"	);
					pThread32Next		= ( THREADWALK )	GetProcAddress( (HMODULE)hKernel, "Thread32Next"		);
					pHeap32ListFirst= ( HEAPLISTWALK )GetProcAddress( (HMODULE)hKernel, "Heap32ListFirst");
					pHeap32ListNext = ( HEAPLISTWALK )GetProcAddress( (HMODULE)hKernel, "Heap32ListNext" );
					pHeap32First		= ( HEAPFIRST )		GetProcAddress( (HMODULE)hKernel, "Heap32First"		);
					pHeap32Next			= ( HEAPNEXT )		GetProcAddress( (HMODULE)hKernel, "Heap32Next"			);

					/* Make sure we got valid pointers for every Toolhelp32 function */
					if( pModule32First	== nullptr || pModule32Next		== nullptr || 
						pProcess32First		== nullptr || pProcess32Next	== nullptr || 
						pThread32First		== nullptr || pThread32Next		== nullptr || 
						pHeap32ListFirst	== nullptr || pHeap32ListNext == nullptr || 
						pHeap32First			== nullptr || pHeap32Next			== nullptr || 
						pCreateToolhelp32Snapshot == nullptr )
					{
						/* Mark the main function as unavailable in case for future
						reference */
						pCreateToolhelp32Snapshot = nullptr;
						return pool;
					}
				}

				if( !polling() )		return pool;

				initRandomData( randomState, buffer, (PoolSize * 4) );

				/* Take a snapshot of everything we can get to that's currently in the systemtem */
				hSnapshot = pCreateToolhelp32Snapshot( TH32CS_SNAPALL, 0 );
				if( !hSnapshot )		return pool;

				/* Walk through the local heap.  We have to be careful to not spend
				excessive amounts of time on this if we're linked into a large
				application with a great many heaps and/or heap blocks, since the
				heap-traversal functions are rather slow.  Fortunately this is
				quite rare under Win95/98, since it implies a large/long-running
				server app that would be run under NT/Win2K/et al rather than 
				Win95 (the performance of the mapped ToolHelp32 helper functions 
				under these OSes is even worse than under Win95, fortunately we 
				don't have to use them there).

				Ideally in order to prevent excessive delays we'd count the number
				of heaps and ensure that no_heaps * no_heap_blocks doesn't exceed
				some maximum value, however this requires two passes of (slow) heap
				traversal rather than one, which doesn't help the situation much.
				To provide at least some protection, we limit the total number of
				heaps and heap entries traversed, although this leads to slightly
				suboptimal performance if we have a small number of deep heaps
				rather than the current large number of shallow heaps.

				There is however a second consideration that needs to be taken into
				account when doing this, which is that the heap-management functions
				aren't completely thread-safe, so that under (very rare) conditions
				of heavy allocation/deallocation this can cause problems when calling
				HeapNext().  By limiting the amount of time that we spend in each
				heap, we can reduce our exposure somewhat */
				hl32.dwSize = sizeof( HEAPLIST32 );
				if( pHeap32ListFirst( hSnapshot, &hl32 ) )
				{
					do
					{
						HEAPENTRY32 he32;
						int entryCount = 0;

						/* First add the information from the basic Heaplist32
						structure */
						if( !polling() )
						{
							CloseHandle( hSnapshot );
							return;
						}
						pool.write( &hl32, sizeof( HEAPLIST32 ) );

						/* Now walk through the heap blocks getting information
						on each of them */
						he32.dwSize = sizeof( HEAPENTRY32 );
						if( pHeap32First( &he32, hl32.th32ProcessID, hl32.th32HeapID ) )
						{
							do
							{
								if( !polling() )
								{
									CloseHandle( hSnapshot );
									return;
								}
								pool.write( &he32, sizeof( HEAPENTRY32 ) );
							}
							while( entryCount++ < 20 && pHeap32Next( &he32 ) );
						}
					}
					while( listCount++ < 20 && pHeap32ListNext( hSnapshot, &hl32 ) );
				}

				/* Walk through all processes */
				pe32.dwSize = sizeof( PROCESSENTRY32 );
				iterationCount = 0;
				if( pProcess32First( hSnapshot, &pe32 ) )
				{
					do
					{
						if( !polling() )
						{
							CloseHandle( hSnapshot );
							return pool;
						}
						pool.write( &pe32, sizeof( PROCESSENTRY32 ) );
					}
					while( pProcess32Next( hSnapshot, &pe32 ) && \
						iterationCount++ < FAILSAFE_ITERATIONS_LARGE );
				}

				/* Walk through all threads */
				te32.dwSize = sizeof( THREADENTRY32 );
				iterationCount = 0;
				if( pThread32First( hSnapshot, &te32 ) )
				{
					do
					{
						if( !polling() )
						{
							CloseHandle( hSnapshot );
							return pool;
						}
						pool.write( &te32, sizeof( THREADENTRY32 ) );
					}
					while( pThread32Next( hSnapshot, &te32 ) && \
						iterationCount++ < FAILSAFE_ITERATIONS_LARGE );
				}

				/* Walk through all modules associated with the process */
				me32.dwSize = sizeof( MODULEENTRY32 );
				iterationCount = 0;
				if( pModule32First( hSnapshot, &me32 ) )
				{
					do
					{
						if( !polling() )
						{
							CloseHandle( hSnapshot );
							return pool;
						}
						pool.write( &me32, sizeof( MODULEENTRY32 ) );
					}

					while( pModule32Next( hSnapshot, &me32 ) && 
						iterationCount++ < FAILSAFE_ITERATIONS_LARGE );
				}

				/* Clean up the snapshot */
				CloseHandle( hSnapshot );

				if( !polling() )	return pool;

				/* Flush any remaining data through */
				pool.flush();

				return pool;
			}


			/* When we query the performance counters, we allocate an initial buffer and
			then reallocate it as required until RegQueryValueEx() stops returning
			ERROR_MORE_DATA.  The following values define the initial buffer size and
			step size by which the buffer is increased */
			template<size_t PoolSizeT, HashAlgorithm DigestT> 
			crypto_random_pool<PoolSizeT,DigestT>& winreg_poll( crypto_random_pool<PoolSizeT,DigestT>& pool  )
			{
				static int cbPerfData = PERFORMANCE_BUFFER_SIZE;
				PPERF_DATA_BLOCK pPerfData;
				DWORD dwSize, dwStatus;
				int iterations = 0, status;

				/* Wait for any async keyset driver binding to complete.  You may be
				wondering what this call is doing here... the reason why it's 
				necessary is because RegQueryValueEx() will hang indefinitely if the 
				async driver bind is in progress.  The problem occurs in the dynamic 
				loading and linking of driver DLL's, which work as follows:

				hDriver = LoadLibrary( DRIVERNAME );
				pFunction1 = ( TYPE_FUNC1 ) GetProcAddress( (HMODULE)hDriver, NAME_FUNC1 );
				pFunction2 = ( TYPE_FUNC1 ) GetProcAddress( (HMODULE)hDriver, NAME_FUNC2 );

				If RegQueryValueEx() is called while the GetProcAddress()'s are in
				progress, it will hang indefinitely.  This is probably due to some
				synchronisation problem in the NT kernel where the GetProcAddress()
				calls affect something like a module reference count or function
				reference count while RegQueryValueEx() is trying to take a snapshot of
				the statistics, which include the reference counts.  Because of this,
				we have to wait until any async driver bind has completed before we can
				call RegQueryValueEx() */
#				if 1 == 1
				//if( !krnlWaitSemaphore( SEMAPHORE_DRIVERBIND ) )
				//{
				//	/* The kernel is shutting down, bail out */
				//	return pool;
				//}
#				endif

				/* Get information from the systemtem performance counters.  This can take a
				few seconds to do.  In some environments the call to RegQueryValueEx()
				can produce an access violation at some random time in the future, in
				some cases adding a short delay after the following code block makes
				the problem go away.  This problem is extremely difficult to
				reproduce, I haven't been able to get it to occur despite running it
				on a number of machines.  MS knowledge base article Q178887 covers
				this type of problem, it's typically caused by an external driver or
				other program that adds its own values under the
				HKEY_PERFORMANCE_DATA key.  The NT kernel, via Advapi32.dll, calls the
				required external module to map in the data inside an SEH try/except
				block, so problems in the module's collect function don't pop up until
				after it has finished, so the fault appears to occur in Advapi32.dll.
				There may be problems in the NT kernel as well though, a low-level
				memory checker indicated that ExpandEnvironmentStrings() in
				Kernel32.dll, called an interminable number of calls down inside
				RegQueryValueEx(), was overwriting memory (it wrote twice the
				allocated size of a buffer to a buffer allocated by the NT kernel).
				OTOH this could be coming from the external module calling back into
				the kernel, which eventually causes the problem described above.

				Possibly as an extension of the problem that the krnlWaitSemaphore()
				call above works around, running two instances of cryptlib (e.g. two
				applications that use it) under NT4 can result in one of them hanging
				in the RegQueryValueEx() call.  This happens only under NT4 and is
				hard to reproduce in any consistent manner.

				One workaround that helps a bit is to read the registry as a remote
				(rather than local) registry, it's possible that the use of a network
				RPC call isolates the calling app from the problem in that whatever
				service handles the RPC is taking the hit and not affecting the
				calling app.  Since this would require another round of extensive
				testing to verify and the NT native API call is working fine, we'll
				stick with the native API call for now.

				Some versions of NT4 had a problem where the amount of data returned
				was mis-reported and would never settle down, because of this the code
				below includes a safety-catch that bails out after 10 attempts have
				been made, this results in no data being returned but at does ensure
				that the thread will terminate.

				In addition to these problems the code in RegQueryValueEx() that
				estimates the amount of memory required to return the performance
				counter information isn't very accurate (it's much worse than the
				"slightly-inaccurate" level that the MS docs warn about, it's usually
				wildly off) since it always returns a worst-case estimate which is
				usually nowhere near the actual amount required.  For example it may
				report that 128K of memory is required, but only return 64K of data.

				Even worse than the registry-based performance counters is the
				performance data helper (PDH) shim that tries to make the counters
				look like the old Win16 API (which is also used by Win95).  Under NT
				this can consume tens of MB of memory and huge amounts of CPU time
				while it gathers its data, and even running once can still consume
				about 1/2MB of memory.

				"Windows NT is a thing of genuine beauty, if you're seriously into 
				genuine ugliness.  It's like a woman with a history of insanity in 
				the family, only worse" -- Hans Chloride, "Why I Love Windows NT" */
				pPerfData = ( PPERF_DATA_BLOCK ) malloc( cbPerfData );
				while( pPerfData != nullptr && iterations++ < 10 )
				{
					dwSize = cbPerfData;
					dwStatus = RegQueryValueEx( HKEY_PERFORMANCE_DATA, "Global", nullptr,
						nullptr, ( LPBYTE ) pPerfData, &dwSize );
					if( dwStatus == ERROR_SUCCESS )
					{
						if( !memcmp( pPerfData->Signature, L"PERF", 8 ) )
						{
							static const int quality = 100;
							pool.write( pPerfData, dwSize );
						}
						delete pPerfData;
						pPerfData = nullptr;
					}
					else
					{
						if( dwStatus == ERROR_MORE_DATA )
						{
							PPERF_DATA_BLOCK pTempPerfData;

							cbPerfData += PERFORMANCE_BUFFER_STEP;
							pTempPerfData = ( PPERF_DATA_BLOCK ) realloc( pPerfData, cbPerfData );
							if( pTempPerfData == nullptr )
							{
								/* The realloc failed, free the original block and force 
								a loop exit */
								delete pPerfData ;

								pPerfData = nullptr;
							}
							else
								pPerfData = pTempPerfData;
						}
					}
				}

				/* Although this isn't documented in the Win32 API docs, it's necessary to
				explicitly close the HKEY_PERFORMANCE_DATA key after use (it's
				implicitly opened on the first call to RegQueryValueEx()).  If this
				isn't done then any systemtem components that provide performance data
				can't be removed or changed while the hndl remains active */
				RegCloseKey( HKEY_PERFORMANCE_DATA );

				return pool;
			}

			/* Perform a thread-safe slow poll for Windows NT */
			template<size_t PoolSizeT, HashAlgorithm DigestT> 
			void safe_slow_poll( crypto_random_pool<PoolSizeT,DigestT>& pool )
			{
				/* If the poll performed any kind of active operation like the Unix one
				rather than just basic data reads it'd be a good idea to drop 
				privileges before we begin, something that can be performed by the
				following code.  Note though that this creates all sorts of 
				complications when we are running as a service and/or performing
				impersonation, which is why it's disabled by default */

#				ifdef BOOST_CRYPTO_WIN32_NO_SERVICE_OR_IMPERSONATION

				typedef BOOL ( WINAPI *CREATERESTRICTEDTOKEN )( HANDLE ExistingTokenHandle,
					DWORD Flags, DWORD DisableSidCount,
					PSID_AND_ATTRIBUTES SidsToDisable,
					DWORD DeletePrivilegeCount,
					PLUID_AND_ATTRIBUTES PrivilegesToDelete,
					DWORD RestrictedSidCount,
					PSID_AND_ATTRIBUTES SidsToRestrict,
					PHANDLE NewTokenHandle );

				static CREATERESTRICTEDTOKEN pCreateRestrictedToken = nullptr;
				static bool is_init = false;

				if( !is_init )
				{
					/* Since CreateRestrictedToken() is a Win2K function we can only use
					it on a post-NT4 systemtem, and have to bind it at runtime */
					if( detail::system_variables( detail::SYSVAR_TYPE::SYSVAR_OSVERSION ) > 4 )
					{
						const HINSTANCE hAdvAPI32 = GetModuleHandle( "AdvAPI32.dll" );

						pCreateRestrictedToken = ( CREATERESTRICTEDTOKEN ) \
							GetProcAddress( (HMODULE)hAdvAPI32, "CreateRestrictedToken" );
					}
					is_init = true;
				}

				if( pCreateRestrictedToken != nullptr )
				{
					HANDLE hToken, hNewToken;

					ImpersonateSelf( SecurityImpersonation );
					OpenThreadToken( GetCurrentThread(),
						TOKEN_ASSIGN_PRIMARY | TOKEN_DUPLICATE |
						TOKEN_QUERY | TOKEN_ADJUST_DEFAULT |
						TOKEN_IMPERSONATE, true, &hToken );

					CreateRestrictedToken( hToken, DISABLE_MAX_PRIVILEGE, 0, nullptr, 0, nullptr,
						0, nullptr, &hNewToken );					
					// XXX:TODO:
					// SetThreadToken( current thread pool thread, hNewToken );
				}

#				endif /* BOOST_CRYPTO_WIN32_NO_SERVICE_OR_IMPERSONATION */
				{
					static bool slow_poll_winnt_run_once = false;
					static int isWorkstation = (-1);
					HANDLE hDevice;
					LPBYTE lpBuffer;
					ULONG ulSize;
					DWORD dwType, dwSize, dwResult;
					void *buffer;
					int nDrive, noResults = 0, status;

					/* Find out whether this is an NT server or workstation if necessary */
					if( isWorkstation == (-1) )
					{
						HKEY hKey;

						if( RegOpenKeyEx( HKEY_LOCAL_MACHINE,
							"SYS\\CurrentControlSet\\Control\\ProductOptions",
							0, KEY_READ, &hKey ) == ERROR_SUCCESS )
						{
							BYTE szValue[32 + 8];
							dwSize = 32;

							isWorkstation = true;
							if( RegQueryValueEx( hKey, "ProductType", 0, nullptr, szValue, &dwSize ) == ERROR_SUCCESS &&
								stricmp( (const char*)szValue, "WinNT" ) )
							{
								/* Note: There are (at least) three cases for ProductType:
								WinNT = NT Workstation, ServerNT = NT Server, LanmanNT =
								NT Server acting as a Domain Controller */
								isWorkstation = false;
							}

							RegCloseKey( hKey );
						}

						return ;
					}

					/* The following are fixed for the lifetime of the process so we only
					add them once */
					if( !slow_poll_winnt_run_once )
					{
						pnp_data(pool);
						slow_poll_winnt_run_once = true;
					}

					/* Initialize the NetAPI32 function pointers if necessary */
					if( hNetAPI32 == nullptr )
					{
						/* Obtain a hndl to the module containing the Lan Manager functions */
						if( ( hNetAPI32 = LoadLibrary( "NetAPI32.dll" ) ) != nullptr )
						{
							/* Now get pointers to the functions */
							pNetStatisticsGet = ( NETSTATISTICSGET ) GetProcAddress( (HMODULE)hNetAPI32, "NetStatisticsGet" );
							pNetApiBufferSize = ( NETAPIBUFFERSIZE ) GetProcAddress( (HMODULE)hNetAPI32, "NetApiBufferSize" );
							pNetApiBufferFree = ( NETAPIBUFFERFREE ) GetProcAddress( (HMODULE)hNetAPI32, "NetApiBufferFree" );

							/* Make sure we got valid pointers for every NetAPI32 function */
							if( pNetStatisticsGet == nullptr ||
								pNetApiBufferSize		== nullptr ||
								pNetApiBufferFree		== nullptr )
							{
								/* Free the library reference and reset the static hndl */
								FreeLibrary( (HMODULE)(HMODULE) hNetAPI32 );
								hNetAPI32 = nullptr;
							}
						}
					}

					/* Initialize the NT kernel native API function pointers if necessary */
					if( hNTAPI == nullptr && 
						( hNTAPI = GetModuleHandle( "NTDll.dll" ) ) != nullptr )
					{
						/* Get a pointer to the NT native information query functions */
						pNtQuerySystemInformation	= ( NTQUERYSYSINFO )		GetProcAddress( (HMODULE)hNTAPI, "NtQuerySystemInformation" );
						pNtQueryInformationProcess= ( NTQUERYINFOPROCESS )GetProcAddress( (HMODULE)hNTAPI, "NtQueryInformationProcess" );

						if( pNtQuerySystemInformation == nullptr || 
							pNtQueryInformationProcess	== nullptr )
							hNTAPI = nullptr;

						pNtPowerInformation = ( NTPOWERINFO ) GetProcAddress( (HMODULE) hNTAPI, "NtPowerInformation" );
					}

					if( !polling() )	return ;

					/* Get network statistics.  Note: Both NT Workstation and NT Server by
					default will be running both the workstation and server services.  The
					heuristic below is probably useful though on the assumption that the
					majority of the network traffic will be via the appropriate service. In
					any case the network statistics return almost no randomness */
					if( hNetAPI32 != nullptr &&
						pNetStatisticsGet( nullptr,
						isWorkstation ? L"LanmanWorkstation" : L"LanmanServer",
						0, 0, &lpBuffer ) == 0 )
					{
						pNetApiBufferSize( lpBuffer, &dwSize );
						pool.write( lpBuffer, dwSize );
						pNetApiBufferFree( lpBuffer );
					}

					/* Get disk I/O statistics for all the hard drives */
					for( nDrive = 0; nDrive < 50; nDrive++ )
					{
						BYTE diskPerformance[256 + 8];
						char szDevice[32 + 8];

						/* Check whether we can access this device */
						sprintf_s( szDevice, 32, "\\\\.\\PhysicalDrive%d", nDrive );
						hDevice = CreateFile( szDevice, 0, FILE_SHARE_READ | FILE_SHARE_WRITE,
							nullptr, OPEN_EXISTING, 0, nullptr );
						if( hDevice == INVALID_HANDLE_VALUE )
							break;

						/* Note: This only works if the user has turned on the disk
						performance counters with 'diskperf -y'.  These counters were
						traditionally disabled under NT, although in newer installs of 
						Win2K and newer the physical disk object is enabled by default 
						while the logical disk object is disabled by default 
						('diskperf -yv' turns on the counters for logical drives in this 
						case, since they're already on for physical drives).

						In addition using the documented DISK_PERFORMANCE data structure 
						to contain the returned data returns ERROR_INSUFFICIENT_BUFFER 
						(which is wrong) and doesn't change dwSize (which is also wrong) 
						so we pass in a larger buffer and pre-set dwSize to a safe 
						value.  Finally, there's a bug in pre-SP4 Win2K in which enabling 
						diskperf, installing a file systemtem filter driver, and then 
						disabling diskperf, causes diskperf to corrupt the registry key 
						HKEY_LOCAL_MACHINE\SYS\CurrentControlSet\Control\Class\
						{71A27CDD-812A-11D0-BEC7-08002BE2092F}\Upper Filters, resulting 
						in a Stop 0x7B bugcheck */
						dwSize = sizeof( diskPerformance );
						if( DeviceIoControl( hDevice, IOCTL_DISK_PERFORMANCE, nullptr, 0,
							&diskPerformance, 256, &dwSize, nullptr ) )
						{
							if( !polling() )
							{
								CloseHandle( hDevice );
								return ;
							}
							pool.write( &diskPerformance, dwSize );
						}
						CloseHandle( hDevice );
					}
					if( !polling() )	return ;

					/* In theory we should be using the Win32 performance query API to obtain
					unpredictable data from the systemtem, however this is so unreliable (see
					the multiple sets of comments in winreg_poll()) that it's too risky
					to rely on it except as a fallback in emergencies.  Instead, we rely
					mostly on the NT native API function NtQuerySystemInformation(), which
					has the dual advantages that it doesn't have as many (known) problems
					as the Win32 equivalent and that it doesn't access the data indirectly
					via pseudo-registry keys, which means that it's much faster.  Note
					that the Win32 equivalent actually works almost all of the time, the
					problem is that on one or two systemtems it can fail in strange ways that
					are never the same and can't be reproduced on any other systemtem, which
					is why we use the native API here.  Microsoft officially documented
					this function in early 2003, so it'll be fairly safe to use */
					if( ( hNTAPI == nullptr ) ||
						( buffer = malloc(PERFORMANCE_BUFFER_SIZE ) ) == nullptr )
					{
						winreg_poll(pool);
						return ;
					}

					/* Clear the buffer before use.  We have to do this because even though 
					NtQuerySystemInformation() tells us that it's filled in ulSize bytes, 
					it doesn't necessarily mean that it actually has provided that much 
					data */
					BOOST_CRYPTO_ZEROISE( buffer, PERFORMANCE_BUFFER_SIZE );

					/* Scan the first 64 possible information types (we don't bother with
					increasing the buffer size as we do with the Win32 version of the
					performance data read, we may miss a few classes but it's no big deal).
					This scan typically yields around 20 pieces of data, there's nothing
					in the range 65...128 so chances are there won't be anything above
					there either */
					for( dwType = 0; dwType < 64; dwType++ )
					{
						/* Some information types are write-only (the IDs are shared with
						a set-information call), we skip these */
						if( dwType == 26 || dwType == 27 || dwType == 38 || 
							dwType == 38 || dwType == 46 || dwType == 47 || 
							dwType == 48 || dwType == 52 )
							continue;

						/* ID 53 = SystemSessionProcessInformation reads input from the
						output buffer, which has to contain a session ID and pointer
						to the actual buffer in which to store the session information.
						Because this isn't a standard query, we skip this */
						if( dwType == 53 )
							continue;

						/* Query the info for this ID.  Some results (for example for
						ID = 6, SystemCallCounts) are only available in checked builds
						of the kernel.  A smaller subcless of results require that
						certain systemtem config flags be set, for example
						SystemObjectInformation requires that the
						FLG_MAINTAIN_OBJECT_TYPELIST be set in NtGlobalFlags.  To avoid
						having to special-case all of these, we try reading each one and
						only use those for which we get a success status */
						dwResult = pNtQuerySystemInformation( dwType, buffer,
							PERFORMANCE_BUFFER_SIZE - 2048,
							&ulSize );

						if( dwResult != ERROR_SUCCESS )
							continue;

						/* Some calls (e.g. ID = 23, SystemProcessorStatistics, and ID = 24,
						SystemDpcInformation) incorrectly return a length of zero, so we
						manually adjust the length to the correct value */
						if( ulSize == 0 )
						{
							if( dwType == 23 )		ulSize = 6 * sizeof( ULONG );
							if( dwType == 24 )		ulSize = 5 * sizeof( ULONG );
						}

						/* If we got some data back, add it to the entropy pool.  Note that 
						just because NtQuerySystemInformation() tells us that it's 
						provided ulSize bytes doesn't necessarily mean that it has, see 
						the comment after the malloc() for details */
						if( ulSize > 0 && ulSize <= PERFORMANCE_BUFFER_SIZE - 2048 )
						{
							if( !polling() )
							{
								delete buffer ;
								return ;
							}
							pool.write( buffer, ulSize );
							noResults++;
						}
					}

					/* Finally do the same for the systemtem power status information.  There 
					are only a limited number of useful information types available so we
					restrict ourselves to the useful types.  In addition since this
					function doesn't return length information we have to hardcode in
					length data */
					if( pNtPowerInformation != nullptr )
					{
						static const struct { int type; int size; } powerInfo[] = {
							{ 0, 128 },	/* SystemPowerPolicyAc */
							{ 1, 128 },	/* SystemPowerPolicyDc */
							{ 4,  64 },	/* SystemPowerCapabilities */
							{ 5,  48 },	/* SystemBatteryState */
							{ 11, 48 },	/* ProcessorInformation */
							{ 12, 24 },	/* SystemPowerInformation */
							{ -1, -1 }
						};
						int i;

						for( i = 0; powerInfo[i].type != -1 &&
							i < 50; i++ )
						{
							/* Query the info for this ID */
							dwResult = pNtPowerInformation( powerInfo[i].type, nullptr, 0, buffer,
								PERFORMANCE_BUFFER_SIZE - 2048 );
							if( dwResult != ERROR_SUCCESS )
								continue;
							if( !polling() )
							{
								delete buffer ;
								return ;
							}
							pool.write( buffer, powerInfo[i].size );
							noResults++;
						}
						assert( i < 50 );
					}
					delete buffer;

					/* If we got enough data, we can leave now without having to try for a
					Win32-level performance information query */
					if( noResults > 15 )
					{
						static const int quality = 100;
						return ;
					}

					if( !polling() )	return ;

					/* We couldn't get enough results from the kernel, fall back to the
					somewhat troublesome registry poll */
					winreg_poll(pool);
				}
			}


#			ifdef BOOST_MSVC
#			pragma endregion
#			endif

		public:
			/* Try and connect to the systemtem RNG if there's one present */
			win32_random( void ) 
				: pCryptAcquireContext				( nullptr ),		pCryptGenRandom						( nullptr ),
				pCryptReleaseContext			( nullptr ),		pRtlGenRandom							( nullptr ),
				hProv											( nullptr ),		pCreateToolhelp32Snapshot	( nullptr ),
				pModule32First						( nullptr ),		pModule32Next							( nullptr ),
				pProcess32First						( nullptr ),		pProcess32Next						( nullptr ),
				pThread32First						( nullptr ),		pThread32Next							( nullptr ),
				pHeap32ListFirst					( nullptr ),		pHeap32ListNext						( nullptr ),
				pHeap32First							( nullptr ),		pHeap32Next								( nullptr ),
				pNetStatisticsGet					( nullptr ),		pNetApiBufferSize					( nullptr ),
				pNetApiBufferFree					( nullptr ),		pNtQuerySystemInformation	( nullptr ),
				pNtQueryInformationProcess( nullptr ),		pNtPowerInformation				( nullptr ),
				hAdvAPI32									( nullptr ),		hNetAPI32									( nullptr ),
				hNTAPI										( nullptr ),		systerng_available				(	false		),		
				addedFixedItems						( false   ),		slow_poll_winnt_run_once	( false   ),		
				polling_status						( true    ),		_mutex										(         ),
				_threadgroup							(					)
			{
				/* Reset the various module and object handles and status info and
				initialise the systemtem RNG interface if it's present */
				if( ( hAdvAPI32 = GetModuleHandle( "AdvAPI32.dll" ) ) == nullptr )
					return;

				/* Get pointers to the CSP functions.  Although the acquire context
				function looks like a standard function, it's actually a macro which
				is mapped to (depending on the build type) CryptAcquireContextA or
				CryptAcquireContextW, so we access it under the straight-ASCII-
				function name */
				pCryptAcquireContext = ( CRYPTACQUIRECONTEXT ) GetProcAddress( (HMODULE)hAdvAPI32,
					"CryptAcquireContextA" );

				pCryptGenRandom = ( CRYPTGENRANDOM ) GetProcAddress( (HMODULE)hAdvAPI32,
					"CryptGenRandom" );

				pCryptReleaseContext = ( CRYPTRELEASECONTEXT ) GetProcAddress( (HMODULE)hAdvAPI32,
					"CryptReleaseContext" );

				/* Get a pointer to the native randomness function if it's available.  
				This isn't exported by name, so we have to get it by ordinal */
				pRtlGenRandom = ( RTLGENRANDOM ) GetProcAddress( (HMODULE)hAdvAPI32,
					"SystemFunction036" );

				/* Try and connect to the PIII RNG CSP.  The AMD 768 southbridge (from 
				the 760 MP chipset) also has a hardware RNG, but there doesn't appear 
				to be any driver support for this as there is for the Intel RNG so we 
				can't do much with it.  OTOH the Intel RNG is also effectively dead 
				as well, mostly due to virtually nonexistant support/marketing by 
				Intel, it's included here mostly for form's sake */
				if( ( pCryptAcquireContext== nullptr || 
					pCryptGenRandom					== nullptr || 
					pCryptReleaseContext		== nullptr ||
					pCryptAcquireContext( &hProv, nullptr, INTEL_DEF_PROV, PROV_INTEL_SEC, 0 ) == false ) && 
					( pRtlGenRandom == nullptr ) )
				{
					hAdvAPI32 = nullptr;
					hProv				= nullptr;
				}
				else
				{
					/* Remember that we have a systemtem RNG available for use */
					systerng_available = true;
				}

				detail::init_system_variables();
			}

			/* Clean up the systemtem RNG access */
			~win32_random( void )
			{
				if( hNetAPI32 )
				{
					FreeLibrary( (HMODULE)(HMODULE)hNetAPI32 );
					hNetAPI32 = nullptr;
				}

				if( hProv != nullptr )
				{
					pCryptReleaseContext( hProv, 0 );
					hProv = nullptr;
				}

				_threadgroup.join_all();
			}			

			bool polling() const {
				return polling_status;
			}

			void polling(bool state) {
				polling_status = state;
			}


			/* Perform a generic slow poll.  This starts the OS-specific poll in a
			separate thread */
			template<size_t PoolSizeT, HashAlgorithm DigestT> 
			crypto_random_pool<PoolSizeT,DigestT>& slow_poll( crypto_random_pool<PoolSizeT,DigestT>& pool )
			{
				if( !polling() )		return pool;

				/* Read data from various hardware sources */
				ati_tray_tool_data(
					hmonitor_data(
					rivia_truner_data(
					systetool_data(
					everest_data(
					mbdata(
					systerng(pool)
					))))));

				_mutex.lock();
				{
					if( detail::system_variables( detail::SYSVAR_TYPE::SYSVAR_ISWIN95 ) == true )
						_threadgroup.create_thread(bind(&win32_random::safe_slow_poll<PoolSizeT, DigestT>, this, pool));
					else
						_threadgroup.create_thread(bind(&win32_random::safe_slow_poll<PoolSizeT, DigestT>, this, pool));
				}
				_mutex.unlock();

				return pool;
			}

			/* The shared Win32 fast poll routine */
			template<size_t PoolSizeT, HashAlgorithm DigestT> 
			crypto_random_pool<PoolSizeT,DigestT>& fast_poll( crypto_random_pool<PoolSizeT,DigestT>& pool )
			{
				static bool addedFixedItems = false;
				FILETIME  creationTime, exitTime, kernelTime, userTime;
				DWORD minimumWorkingSetSize, maximumWorkingSetSize;
				LARGE_INTEGER performanceCount;
				MEMORYSTATUS memoryStatus;
				HANDLE hndl;
				POINT point;
				int status;

				if( !polling() )	return pool;

				pool.write( GetActiveWindow() );
				pool.write( GetCapture() );
				pool.write( GetClipboardOwner() );
				pool.write( GetClipboardViewer() );
				pool.write( GetCurrentProcess() );
				pool.write( GetCurrentProcessId() );
				pool.write( GetCurrentThread() );
				pool.write( GetCurrentThreadId() );
				pool.write( GetDesktopWindow() );
				pool.write( GetFocus() );
				pool.write( GetInputState() );
				pool.write( GetMessagePos() );
				pool.write( GetMessageTime() );
				pool.write( GetOpenClipboardWindow() );
				pool.write( GetProcessHeap() );
				pool.write( GetProcessWindowStation() );
				pool.write( GetTickCount() );

				if( !polling() )	return pool;

				/* Calling the following function can cause problems in some cases in
				that a calling application eventually stops getting events from its
				event loop, so we can't (safely) use it as an entropy source */
				/*	pool.write( GetQueueStatus( QS_ALLEVENTS ) ); */

				/* Get multiword systemtem information: Current caret position, current
				mouse cursor position */
				GetCaretPos( &point );	pool.write( &point, sizeof( POINT ) );
				GetCursorPos( &point );	pool.write( &point, sizeof( POINT ) );

				/* Get percent of memory in use, bytes of physical memory, bytes of free
				physical memory, bytes in paging file, free bytes in paging file, user
				bytes of address space, and free user bytes */
				memoryStatus.dwLength = sizeof( MEMORYSTATUS );
				GlobalMemoryStatus( &memoryStatus );
				pool.write( &memoryStatus, sizeof( MEMORYSTATUS ) );

				/* Get thread and process creation time, exit time, time in kernel mode,
				and time in user mode in 100ns intervals */
				hndl = GetCurrentThread();
				GetThreadTimes( hndl, &creationTime, &exitTime, &kernelTime, &userTime );
				pool.write( &creationTime	, sizeof( FILETIME ) );
				pool.write( &exitTime			, sizeof( FILETIME ) );
				pool.write( &kernelTime		, sizeof( FILETIME ) );
				pool.write( &userTime			, sizeof( FILETIME ) );
				hndl = GetCurrentProcess();
				GetProcessTimes( hndl, &creationTime, &exitTime, &kernelTime, &userTime );
				pool.write( &creationTime	, sizeof( FILETIME ) );
				pool.write( &exitTime			, sizeof( FILETIME ) );
				pool.write( &kernelTime		, sizeof( FILETIME ) );
				pool.write( &userTime			, sizeof( FILETIME ) );

				/* Get the minimum and maximum working set size for the current process */
				GetProcessWorkingSetSize( hndl, &minimumWorkingSetSize,
					&maximumWorkingSetSize );
				pool.write( minimumWorkingSetSize );
				pool.write( maximumWorkingSetSize );

				/* The following are fixed for the lifetime of the process so we only
				add them once */
				if( !addedFixedItems )
				{
					STARTUPINFO startupInfo;

					/* Get name of desktop, console window title, new window position and
					size, window flags, and handles for stdin, stdout, and stderr */
					startupInfo.cb = sizeof( STARTUPINFO );
					GetStartupInfo( &startupInfo );
					pool.write( &startupInfo, sizeof( STARTUPINFO ) );

					/* Remember that we've got the fixed info */
					addedFixedItems = true;
				}

#ifndef BOOST_CRYPTO_NO_INLINE_ASM
				if( detail::system_variables( detail::SYSVAR_TYPE::SYSVAR_HWCAP ) & 
					detail::HWCAP_FLAG::HWCAP_FLAG_RDTSC )
				{							
					unsigned low_part, high_part;

					__asm
					{
						xor eax , eax
							xor edx , edx		/* Tell VC++ that EDX:EAX will be trashed */
							rdtsc
							mov [low_part ], eax
							mov [high_part], edx 
					}
					pool.write( low_part  );
					pool.write( high_part );							
					pool.write( &low_part  );
					pool.write( &high_part );
				}
#endif /* BOOST_CRYPTO_NO_INLINE_ASM */
				else
				{
					if( QueryPerformanceCounter( &performanceCount ) )
						pool.write( &performanceCount,
						sizeof( LARGE_INTEGER ) );
					else
					{
						/* Millisecond accuracy at best... */
						pool.write( GetTickCount()   );
						//pool.write( GetTickCount64() );						
					}
				}

#ifndef BOOST_CRYPTO_NO_INLINE_ASM
				if( detail::system_variables( detail::SYSVAR_TYPE::SYSVAR_HWCAP ) & 
					detail::HWCAP_FLAG::HWCAP_FLAG_XSTORE )
				{
					struct alignStruct {
						LONGLONG dummy1;		/* Force alignment of following member */
						BYTE buffer[64];
					};
					BYTE buffer [64 + sizeof(LONGLONG) + sizeof(void*)];
					struct alignStruct *rngBuffer = ( struct alignStruct * ) buffer;
					void *bufPtr = rngBuffer->buffer;	/* Get it into a form asm can hndl */
					int byteCount = 0;

					__asm {
						push es;
						xor  ecx, ecx;				/* Tell VC++ that ECX will be trashed */
						mov  eax, 0xC0000001;	/* Centaur extended feature flags */
						cpuid;
						and  edx, 01100b;
						cmp  edx, 01100b;		/* Check for RNG present + enabled flags */
						jne  _rng_disabled;	/* RNG was disabled after our initial check */
						push ds;
						pop  es;
						mov  edi, bufPtr;	 /* ES:EDI = buffer */
						xor  edx, edx;     /* Fetch 8 bytes */
						xstore_rng
							and  eax, 011111b;/* Get count of bytes returned */
						jz _rng_disabled;   /* Nothing read, exit */
						mov [byteCount], eax
_rng_disabled:
						pop es;
					}

					if( byteCount > 0 )
						pool.write( bufPtr, byteCount );
				}

				if( detail::system_variables( detail::SYSVAR_TYPE::SYSVAR_HWCAP ) &
					detail::HWCAP_FLAG::HWCAP_FLAG_TRNG )
				{
					unsigned long value = 0;

					__asm 
					{
						/* Tell VC++ that EDX:EAX will be trashed */
						xor eax, eax;
						xor edx, edx;			

						/* GLD_MSR_CTRL */
						mov ecx, 0x58002006;		
						rdmsr;

						/* Check whether TRNG is enabled */
						and eax, 0110000000000b;	
						cmp eax, 0010000000000b;	
						jne _trng_disabled;			/* TRNG isn't enabled */
_trng_disabled:
					}
					if( value )
						pool.write( value );
				}
#endif /* BOOST_CRYPTO_NO_INLINE_ASM */

				/* Flush any remaining data through.  Quality = int( 33 1/3 % ) */
				pool.flush();

				return pool;
			}
		}; // win32_random
	} // crypto
} // boost

#undef cpuid
#undef rdtsc
#undef xstore_rng
#undef addRandomHandle
#undef PoolSize	
#undef SYSRNG_BYTES		
#undef PROV_INTEL_SEC	
#undef INTEL_DEF_PROV	
#undef HCRYPTPROV					
#undef BusType						
#undef SMBType						
#undef SensorType					
#undef SH_MEM_MAX_SENSORS	
#undef DIGCF_PRESENT			
#undef DIGCF_ALLCLASSES		
#undef SPDRP_HARDWAREID
#undef PERFORMANCE_BUFFER_SIZE		
#undef PERFORMANCE_BUFFER_STEP		
#
#endif /*  _BOOST_CRYPTO_RANDOM_WIN32_RANDOM_DEVICE_HPP_INCLUDED */


