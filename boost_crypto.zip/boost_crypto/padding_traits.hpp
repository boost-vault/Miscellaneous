#ifndef BOOST_CRYPTO_PADDING_TRAITS_HPP_INCLUDED
#define BOOST_CRYPTO_PADDING_TRAITS_HPP_INCLUDED
#
#include <stdexcept>
#include <exception>
#
#include "crypto.hpp"

namespace boost { 
	namespace crypto {
		namespace detail {
			template<size_t B, size_t E>
			struct pow
			{
				static constexpr size_t value = B * pow<B,E-1>::value;
			};

			template<size_t B>
			struct pow<B,0>
			{
				static constexpr size_t value = B;
			};

		} // namespace boost::crypto::detail 


		template<
			class U, // class where this traits is used
			typename T,
			size_t B>
		class padding_traits
		{
			typedef U type;
			static constexpr size_t min_block_size	= sizeof(T) << 4;
			static constexpr size_t max_block_size	= detail::pow<256,sizeof(T)>::value;
			static constexpr bool   allways_pad			= true;
			static constexpr size_t block_size			= B;
			static constexpr char*	name()					{ return "unknown"; }
		};
		
		//static void pad(T* output, const T* input, size_t input_size) throw(length_error);
		//static void unpad(T* output, const T* input, size_t input_size) throw(bad_padding);


	} // namepace boost::crypto
} // namespace boost 


#endif /* BOOST_CRYPTO_PADDING_TRAITS_HPP_INCLUDED */
