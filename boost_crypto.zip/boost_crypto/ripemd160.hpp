#ifndef _BOOST_CRYPTO_RIPEMD160_HPP_INCLUDED
#define _BOOST_CRYPTO_RIPEMD160_HPP_INCLUDED
#
#include "crypto.hpp"
#include "crypto_endian.hpp"
#include "crypto_rotation.hpp"
#include "ripemd.hpp"
namespace boost {
	namespace crypto {
		
		typedef ripemd_ctx<uint32_t,0x67452301UL,0xefcdab89UL,
			0x98badcfeUL,0x10325476UL,0xc3d2e1f0UL>
			ripemd160_ctx;

		// same as ripemd160_ctx but with 64-bit integers
		// not a well known algorithm! 
		typedef ripemd_ctx<uint64_t,0x6745230167452301UL,0xefcdab89efcdab89UL,
			0x98badcfe98badcfeUL,0x1032547610325476UL,0xc3d2e1f0c3d2e1f0UL>
			ripemd160d_ctx;

	} // namespace crypto
} // namespace boost 
#
#endif /* _BOOST_CRYPTO_RIPEMD160_HPP_INCLUDED */