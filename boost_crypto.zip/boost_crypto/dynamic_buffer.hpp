#ifndef BOOST_CRYPTO_DYNAMIC_BUFFER_HPP_INCLUDED
#define BOOST_CRYPTO_DYNAMIC_BUFFER_HPP_INCLUDED
#
#include <cstddef> // size_t
#include <algorithm> // swap
#include "crypto.hpp"
#include "secure_allocator.hpp"

namespace boost { 
	namespace crypto { 
		namespace detail {
		} // namespace boost::crypto::detail

		
		template<typename T=byte_t, class SAlloc=secure_allocator<std::allocator<T> > >
		class dynamic_buffer
		{
		public:			
			typedef SAlloc allocator_type;
			typedef typename allocator_type::size_type       size_type;
			typedef typename allocator_type::difference_type difference_type;
			typedef typename allocator_type::pointer         pointer;
			typedef typename allocator_type::const_pointer   const_pointer;
			typedef typename allocator_type::reference       reference;
			typedef typename allocator_type::const_reference const_reference;
			typedef typename allocator_type::value_type      value_type;

		private:
			size_type m_size;
			pointer		m_pointer;
			allocator_type m_allocator;

		public:
			explicit dynamic_buffer(size_type my_size) : m_pointer(nullptr), m_size(my_size)
			{
				size(my_size);
			}

			allocator_type& get_allocator() const
			{
				return m_allocator;
			}

			pointer operator() () { return pointer; }
			operator pointer () { return pointer; }

			// get size
			size_type size() const
			{
				return m_size; 
			}

			// set size
			void size(size_type newsize)
			{
				m_allocator.deallocate(m_pointer, size());
				m_pointer = m_allocator.allocate(m_size = newsize);
			}
		};

	} // namespace boost::crypto
} // namespace boost


#endif /* BOOST_CRYPTO_DYNAMIC_BUFFER_HPP_INCLUDED */
