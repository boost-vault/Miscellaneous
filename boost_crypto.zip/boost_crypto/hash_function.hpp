//          Copyright Kasra Nassiri 2008-*.
// Distributed under the Boost Software License, Version 1.0.
//    (See accompanying file LICENSE_1_0.txt or copy at
//          http://www.boost.org/LICENSE_1_0.txt)

#ifndef BOOST_CRYPTO_HASH_FUNCTION_HPP_INCLUDED
#define BOOST_CRYPTO_HASH_FUNCTION_HPP_INCLUDED
#
#include <cstdio>
#include <cstring>
#include <ostream>
#include <stdexcept> // overflow_error
#include <sstream>
#include <string>
#
#include <boost/type_traits/is_arithmetic.hpp>
#
#include "crypto.hpp"
#include "large_counter.hpp"

namespace boost {
	namespace crypto {

		enum hash_function_state 
		{
			hash_function_created,		// ready to compute a new digest
			hash_function_processing,// data has been added since creation
			hash_function_finalising,// accepting no more data, finalising
			hash_function_finished,	// digest calculated 
		};
	} // namespace crypto
} // namespace boost

#endif /* BOOST_CRYPTO_HASH_FUNCTION_HPP_INCLUDED */

