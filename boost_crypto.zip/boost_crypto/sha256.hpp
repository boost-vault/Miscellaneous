#ifndef BOOST_CRYPTO_SHA256_HPP_INCLUDED
#define BOOST_CRYPTO_SHA256_HPP_INCLUDED
#
#include "sha2.hpp"

namespace boost {
	namespace crypto {

		typedef sha2_ctx<uint32_t, 32,
			0x6a09e667UL, 0xbb67ae85UL, 0x3c6ef372UL, 0xa54ff53aUL,
			0x510e527fUL, 0x9b05688cUL, 0x1f83d9abUL, 0x5be0cd19UL
		> sha256_ctx;

	} // namespace crypto
} // namespace boost

#endif /* BOOST_CRYPTO_SHA256_HPP_INCLUDED */
