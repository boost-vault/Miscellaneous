/* Copyright (C) 1990-2, RSA Data Security, Inc. Created 1990. All rights reserved.

License to copy and use this software is granted for
non-commercial Internet Privacy-Enhanced Mail provided that it is
identified as the "RSA Data Security, Inc. MD2 Message Digest
Algorithm" in all material mentioning or referencing this software
or this function.

RSA Data Security, Inc. makes no representations concerning either
the merchantability of this software or the suitability of this
software for any particular purpose. It is provided "as is"
without express or implied warranty of any kind.

These notices must be retained in any copies of any part of this
documentation and/or software.
*/

//          Copyright Kasra Nassiri 2008-*.
// Distributed under the Boost Software License, Version 1.0.
//    (See accompanying file LICENSE_1_0.txt or copy at
//          http://www.boost.org/LICENSE_1_0.txt)

#ifndef BOOST_CRYPTO_DETAIL_MD2_CTX_HPP
#define BOOST_CRYPTO_DETAIL_MD2_CTX_HPP
#
#include "crypto.hpp"
#
#// concepts and m_states
#include "hash_function.hpp"
#
#// input m_buffering
#include "digest_buffer.hpp"
#

/**
def md2_unrolled():

print("#define SSROUND(i) \\");
for i in range(0,16): 
print("x[", i+32, "] = m_buf[", i, "] ^ block[", i, "];\\");

print("\n\n#define ZZROUND() \\");
for i in range(0,16):
print("t = m_checksum[", i, "] ^= pi_subt[block[", i, "] ^ t];\\");

print("\n\n#define IIROUND(i) \\");
for j in range(0, 48):
print("t = x[", j, "] ^= pi_subt[t];\\");

print("t = (t + i) & 0xff;\n\n");

for i in range(0,18):	
print("IIROUND(", i,");");
*/

#define SSROUND() \
	x[ 32 ] = m_buf[ 0 ] ^ block[ 0 ];\
	x[ 33 ] = m_buf[ 1 ] ^ block[ 1 ];\
	x[ 34 ] = m_buf[ 2 ] ^ block[ 2 ];\
	x[ 35 ] = m_buf[ 3 ] ^ block[ 3 ];\
	x[ 36 ] = m_buf[ 4 ] ^ block[ 4 ];\
	x[ 37 ] = m_buf[ 5 ] ^ block[ 5 ];\
	x[ 38 ] = m_buf[ 6 ] ^ block[ 6 ];\
	x[ 39 ] = m_buf[ 7 ] ^ block[ 7 ];\
	x[ 40 ] = m_buf[ 8 ] ^ block[ 8 ];\
	x[ 41 ] = m_buf[ 9 ] ^ block[ 9 ];\
	x[ 42 ] = m_buf[ 10 ] ^ block[ 10 ];\
	x[ 43 ] = m_buf[ 11 ] ^ block[ 11 ];\
	x[ 44 ] = m_buf[ 12 ] ^ block[ 12 ];\
	x[ 45 ] = m_buf[ 13 ] ^ block[ 13 ];\
	x[ 46 ] = m_buf[ 14 ] ^ block[ 14 ];\
	x[ 47 ] = m_buf[ 15 ] ^ block[ 15 ];

#define ZZROUND() \
	t = m_checksum[ 0  ] ^= pi_subt[block[ 0  ] ^ t];\
	t = m_checksum[ 1  ] ^= pi_subt[block[ 1  ] ^ t];\
	t = m_checksum[ 2  ] ^= pi_subt[block[ 2  ] ^ t];\
	t = m_checksum[ 3  ] ^= pi_subt[block[ 3  ] ^ t];\
	t = m_checksum[ 4  ] ^= pi_subt[block[ 4  ] ^ t];\
	t = m_checksum[ 5  ] ^= pi_subt[block[ 5  ] ^ t];\
	t = m_checksum[ 6  ] ^= pi_subt[block[ 6  ] ^ t];\
	t = m_checksum[ 7  ] ^= pi_subt[block[ 7  ] ^ t];\
	t = m_checksum[ 8  ] ^= pi_subt[block[ 8  ] ^ t];\
	t = m_checksum[ 9  ] ^= pi_subt[block[ 9  ] ^ t];\
	t = m_checksum[ 10 ] ^= pi_subt[block[ 10 ] ^ t];\
	t = m_checksum[ 11 ] ^= pi_subt[block[ 11 ] ^ t];\
	t = m_checksum[ 12 ] ^= pi_subt[block[ 12 ] ^ t];\
	t = m_checksum[ 13 ] ^= pi_subt[block[ 13 ] ^ t];\
	t = m_checksum[ 14 ] ^= pi_subt[block[ 14 ] ^ t];\
	t = m_checksum[ 15 ] ^= pi_subt[block[ 15 ] ^ t];\

#define IIROUND(i) \
	t = x[ 0  ] ^= pi_subt[t];	t = x[ 1  ] ^= pi_subt[t];\
	t = x[ 2  ] ^= pi_subt[t];	t = x[ 3  ] ^= pi_subt[t];\
	t = x[ 4  ] ^= pi_subt[t];	t = x[ 5  ] ^= pi_subt[t];\
	t = x[ 6  ] ^= pi_subt[t];	t = x[ 7  ] ^= pi_subt[t];\
	t = x[ 8  ] ^= pi_subt[t];	t = x[ 9  ] ^= pi_subt[t];\
	t = x[ 10 ] ^= pi_subt[t];	t = x[ 11 ] ^= pi_subt[t];\
	t = x[ 12 ] ^= pi_subt[t];	t = x[ 13 ] ^= pi_subt[t];\
	t = x[ 14 ] ^= pi_subt[t];	t = x[ 15 ] ^= pi_subt[t];\
	t = x[ 16 ] ^= pi_subt[t];	t = x[ 17 ] ^= pi_subt[t];\
	t = x[ 18 ] ^= pi_subt[t];	t = x[ 19 ] ^= pi_subt[t];\
	t = x[ 20 ] ^= pi_subt[t];	t = x[ 21 ] ^= pi_subt[t];\
	t = x[ 22 ] ^= pi_subt[t];	t = x[ 23 ] ^= pi_subt[t];\
	t = x[ 24 ] ^= pi_subt[t];	t = x[ 25 ] ^= pi_subt[t];\
	t = x[ 26 ] ^= pi_subt[t];	t = x[ 27 ] ^= pi_subt[t];\
	t = x[ 28 ] ^= pi_subt[t];	t = x[ 29 ] ^= pi_subt[t];\
	t = x[ 30 ] ^= pi_subt[t];	t = x[ 31 ] ^= pi_subt[t];\
	t = x[ 32 ] ^= pi_subt[t];	t = x[ 33 ] ^= pi_subt[t];\
	t = x[ 34 ] ^= pi_subt[t];	t = x[ 35 ] ^= pi_subt[t];\
	t = x[ 36 ] ^= pi_subt[t];	t = x[ 37 ] ^= pi_subt[t];\
	t = x[ 38 ] ^= pi_subt[t];	t = x[ 39 ] ^= pi_subt[t];\
	t = x[ 40 ] ^= pi_subt[t];	t = x[ 41 ] ^= pi_subt[t];\
	t = x[ 42 ] ^= pi_subt[t];	t = x[ 43 ] ^= pi_subt[t];\
	t = x[ 44 ] ^= pi_subt[t];	t = x[ 45 ] ^= pi_subt[t];\
	t = x[ 46 ] ^= pi_subt[t];	t = x[ 47 ] ^= pi_subt[t];\
	t = (t + i) & 0xff;

namespace boost {
	namespace crypto {
		namespace detail {
			namespace md2 {

				/* Permutation of 0..255 constructed from the digits of pi. It gives a
				"random" nonlinear byte substitution operation.
				*/
				static constexpr uint8_t pi_subt[256] = 
				{
					0x29, 0x2E, 0x43, 0xC9, 0xA2, 0xD8, 0x7C, 0x01,
					0x3D, 0x36, 0x54, 0xA1, 0xEC, 0xF0, 0x06, 0x13,
					0x62, 0xA7, 0x05, 0xF3, 0xC0, 0xC7, 0x73, 0x8C,
					0x98, 0x93, 0x2B, 0xD9, 0xBC, 0x4C, 0x82, 0xCA,
					0x1E, 0x9B, 0x57, 0x3C, 0xFD, 0xD4, 0xE0, 0x16,
					0x67, 0x42, 0x6F, 0x18, 0x8A, 0x17, 0xE5, 0x12,
					0xBE, 0x4E, 0xC4, 0xD6, 0xDA, 0x9E, 0xDE, 0x49,
					0xA0, 0xFB, 0xF5, 0x8E, 0xBB, 0x2F, 0xEE, 0x7A,
					0xA9, 0x68, 0x79, 0x91, 0x15, 0xB2, 0x07, 0x3F,
					0x94, 0xC2, 0x10, 0x89, 0x0B, 0x22, 0x5F, 0x21,
					0x80, 0x7F, 0x5D, 0x9A, 0x5A, 0x90, 0x32, 0x27,
					0x35, 0x3E, 0xCC, 0xE7, 0xBF, 0xF7, 0x97, 0x03,
					0xFF, 0x19, 0x30, 0xB3, 0x48, 0xA5, 0xB5, 0xD1,
					0xD7, 0x5E, 0x92, 0x2A, 0xAC, 0x56, 0xAA, 0xC6,
					0x4F, 0xB8, 0x38, 0xD2, 0x96, 0xA4, 0x7D, 0xB6,
					0x76, 0xFC, 0x6B, 0xE2, 0x9C, 0x74, 0x04, 0xF1,
					0x45, 0x9D, 0x70, 0x59, 0x64, 0x71, 0x87, 0x20,
					0x86, 0x5B, 0xCF, 0x65, 0xE6, 0x2D, 0xA8, 0x02,
					0x1B, 0x60, 0x25, 0xAD, 0xAE, 0xB0, 0xB9, 0xF6,
					0x1C, 0x46, 0x61, 0x69, 0x34, 0x40, 0x7E, 0x0F,
					0x55, 0x47, 0xA3, 0x23, 0xDD, 0x51, 0xAF, 0x3A,
					0xC3, 0x5C, 0xF9, 0xCE, 0xBA, 0xC5, 0xEA, 0x26,
					0x2C, 0x53, 0x0D, 0x6E, 0x85, 0x28, 0x84, 0x09,
					0xD3, 0xDF, 0xCD, 0xF4, 0x41, 0x81, 0x4D, 0x52,
					0x6A, 0xDC, 0x37, 0xC8, 0x6C, 0xC1, 0xAB, 0xFA,
					0x24, 0xE1, 0x7B, 0x08, 0x0C, 0xBD, 0xB1, 0x4A,
					0x78, 0x88, 0x95, 0x8B, 0xE3, 0x63, 0xE8, 0x6D,
					0xE9, 0xCB, 0xD5, 0xFE, 0x3B, 0x00, 0x1D, 0x39,
					0xF2, 0xEF, 0xB7, 0x0E, 0x66, 0x58, 0xD0, 0xE4,
					0xA6, 0x77, 0x72, 0xF8, 0xEB, 0x75, 0x4B, 0x0A,
					0x31, 0x44, 0x50, 0xB4, 0x8F, 0xED, 0x1F, 0x1A,
					0xDB, 0x99, 0x8D, 0x33, 0x9F, 0x11, 0x83, 0x14,
				};

				static constexpr uint8_t *padding[] = {
					(uint8_t *)"",
					(uint8_t *)"\001",
					(uint8_t *)"\002\002",
					(uint8_t *)"\003\003\003",
					(uint8_t *)"\004\004\004\004",
					(uint8_t *)"\005\005\005\005\005",
					(uint8_t *)"\006\006\006\006\006\006",
					(uint8_t *)"\007\007\007\007\007\007\007",
					(uint8_t *)"\010\010\010\010\010\010\010\010",
					(uint8_t *)"\011\011\011\011\011\011\011\011\011",
					(uint8_t *)"\012\012\012\012\012\012\012\012\012\012",
					(uint8_t *)"\013\013\013\013\013\013\013\013\013\013\013",
					(uint8_t *)"\014\014\014\014\014\014\014\014\014\014\014\014",
					(uint8_t *)"\015\015\015\015\015\015\015\015\015\015\015\015\015",
					(uint8_t *)"\016\016\016\016\016\016\016\016\016\016\016\016\016\016",
					(uint8_t *)"\017\017\017\017\017\017\017\017\017\017\017\017\017\017\017",
					(uint8_t *)"\020\020\020\020\020\020\020\020\020\020\020\020\020\020\020\020"
				};


			} // namespace md2
		} // namespace detail

		// struct only holds the data, it would not do any m_buffering and etc.
		class md2_ctx
		{
		public:
			typedef uint8_t  char_type;
			typedef uint8_t  word_type;
			typedef size_t   size_type;

			/* size of the digest */
			static constexpr size_type digest_size     = 16;

			/* size of the internal m_buf */
			static constexpr size_type state_size      = 16;

			/* minimum required size of each input block */
			static constexpr size_type transform_size  = 16;

			md2_ctx() 
			{
				create(); 
			}

			md2_ctx& operator = (md2_ctx& rhs)
			{
				m_state = rhs.m_state;

				std::memcpy(m_buf   , rhs.m_buf   , sizeof(m_buf));
				std::memcpy(m_checksum, rhs.m_checksum, sizeof(m_checksum));

				return (*this);
			}


			~md2_ctx()
			{
				std::memset(m_buf   , 0, sizeof(m_buf));
				std::memset(m_checksum, 0, sizeof(m_checksum));
			}

			// create a new stream, destroying any previously created streams
			void create() throw()
			{
				m_state = hash_function_created;
				std::memset(m_buf   , 0, sizeof(m_buf));
				std::memset(m_checksum, 0, sizeof(m_checksum));
			}

			/* transform using previously set m_buffer, or assign a new pointer */
			/* [buf] should point to memory of size at least [transform_size] */
			md2_ctx& transform(const void* input) throw(bad_hash_state)
			{
				if(m_state != hash_function_processing)
					if(m_state == hash_function_created)		
						m_state = hash_function_processing;
					else if(m_state != hash_function_finalising)
						throw bad_hash_state("md2_ctx::transform() : could not transform an empty stream");

				uint8_t x[48];
				unsigned int i, t=0;
				const uint8_t *block = reinterpret_cast<const uint8_t*>(input);

				/* Form encryption block from m_buf, block, m_buf ^ block.
				*/
				std::memcpy (x   , m_buf, 16);
				std::memcpy (x+16, block  , 16);

				/* Encrypt block (18 rounds).
				for (i = 0; i < 16; i++)
				x[i+32] = m_buf[i] ^ block[i];

				t = 0;
				for (i = 0; i < 18; i++) 
				{
				for (j = 0; j < 48; j++)
				t = x[j] ^= pi_subt[t];
				t = (t + i) & 0xff;
				}

				t = m_checksum[15];
				for (i = 0; i < 16; i++)
				t = m_checksum[i] ^= pi_subt[block[i] ^ t];
				*/
				using namespace detail::md2;
				SSROUND(   );
				IIROUND( 0 );		IIROUND( 1 );		IIROUND( 2 );
				IIROUND( 3 );		IIROUND( 4 );		IIROUND( 5 );
				IIROUND( 6 );		IIROUND( 7 );		IIROUND( 8 );
				IIROUND( 9 );		IIROUND( 10 );	IIROUND( 11 );
				IIROUND( 12 );	IIROUND( 13 );	IIROUND( 14 );
				IIROUND( 15 );	IIROUND( 16 );	IIROUND( 17 );

				/* Save new m_buf */
				std::memcpy (m_buf, x, 16);

				/* Update m_checksum. */
				ZZROUND();

				/* Zeroize sensitive information. */
				memset (x, 0, sizeof(x));

				return (*this);
			}

			// [input] is and in/complete m_buffer with size of [input_size]
			// returns a const pointer to the digest
			md2_ctx& finalise(const void* input, size_type input_size) throw(bad_hash_state)
			{
				m_state = hash_function_finalising;

				size_type padLen;
				uint8_t buf[16];

				/* Pad out to multiple of 16.
				*/
				std::memcpy(buf           , input, input_size   );
				std::memset(buf+input_size, 00000, 16-input_size);
				if(input_size == 16)
				{
					transform(buf);
					input_size = 0;
				}

				using namespace detail::md2;

				padLen = 16 - (input_size & 15);
				std::memcpy(buf+input_size, padding[padLen], padLen);
				input_size += padLen;

				transform(buf);
				transform(m_checksum);

				/* Store m_buf in digest */
				for (int i = 0; i < 4; i++)				
					endian::write_be32(reinterpret_cast<uint32_t*>(m_digest)+i,
					reinterpret_cast<uint32_t*>(m_buf)[i]);
				
				// we don't need these anymore.
				memset(m_buf     , 00, sizeof(m_buf));
				memset(m_checksum, 00, sizeof(m_checksum));

				m_state = hash_function_finished;

				return (*this);
			}

			/* 
			* get the pointer to m_buf m_buffer
			*/
			const word_type* operator () () const { return m_buf; }

			/*
			* return the digest
			*/
			const void *digest() const throw(bad_hash_state)
			{
				if(m_state == hash_function_finished)
					return m_digest; 
				else
					throw bad_hash_state("md2_ctx::digest() : digest is not computed");
			}

		private:				
			// m_buf of the hash instance
			hash_function_state m_state;

			// current m_buffer			
			uint8_t		m_buf[16];    /* m_buf */
			uint8_t		m_checksum[16]; /* m_checksum */
			uint8_t		m_digest[16];		/* working digest */
		};

	} // namespace crypto
} // namespace boost

#endif /* BOOST_CRYPTO_DETAIL_MD4_CTX_HPP */
