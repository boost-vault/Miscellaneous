#ifndef BOOST_CRYPTO_STREAM_CIPHER_INCLUDED
#define BOOST_CRYPTO_STREAM_CIPHER_INCLUDED
#
#ifdef BOOST_MSVC 
#pragma once
#endif

namespace boost { 
	namespace crypto {
		namespace detail {
		} // namespace boost::crypto::detail 
		enum stream_ctx_state { stream_ctx_created, stream_ctx_updating, stream_ctx_finished, };

		template<typename ST>
		class stream_cipher_traits
		{
			typedef ST size_type;
			static constexpr size_type stream_size_min() { return size_type(0 ); }
			static constexpr size_type stream_size_max() { return size_type(stream_size_min()-1); }
		};

		struct parallel_encryption_tag { };
		struct parallel_decryption_tag { };
		struct parallel_cryption_tag : 
			parallel_decryption_tag, 
			parallel_encryption_tag { };
	} // namespace boost::crypto
} // namespace boost 

struct stream_cipher_ctx
{
	void transform_block();
};

template<class Context>
class stream_cipher
{
public:
	typedef Context context_type;
	typedef typename Context::traits_type traits_type;
	typedef typename traits_type::size_type  size_type;
	typedef typename traits_type::value_type value_type;
	static constexpr size_type min_key_size = traits_type::min_key_size;
	static constexpr size_type max_key_size = traits_type::max_key_size;
	static constexpr size_type min_iv_size  = traits_type::min_iv_size;
	static constexpr size_type max_iv_size  = traits_type::max_iv_size;


};

#endif /* BOOST_CRYPTO_STREAM_CIPHER_INCLUDED */
