/* mars.c optimized C code - copyright(c) 1998 IBM 
*
* This code implements both the NIST high level C API (version 5)
* and an underlying IBM defined low level (uint32_t oriented) C API.
*
*
* Revisions log:
*
*   Aug 1999, Shai - the "tweaked" key schedule
*   Apr 1998, Dave && Shai - new key scheduling, new sbox, NIST API
*   Mar 1998, Shai Halevi  - adapted to the latest variant of mars
*   Feb 1998, Dave Safford - created
*
*
* Compilation using pcg's version of gcc:
*    gcc -Wall -pedantic -c -O6 -fomit-frame-pointer -mcpu=pentiumpro 
*        -DINTEL_GCC tests.c mars-opt.c
* 
* Compilation using xlc on AIX:
*    xlc -c -O3 -DAIX_XLC mars-opt.c
*
* Compilation using Borland C++ 5.0 from a DOS command line:
*    bcc32 -Oi -6 -v -A -a4 -O2 -DKAT tests.c mars-opt.c
*
* Useful compilation defines:
*    NO_MIX     - do not execute the mixing phases (core only)
*    INTEL_GCC  - optimized for pentiumpro and djgpp/gcc compiler
*    AIX_XLC    - optimized for powerpc/AIX with xlc compiler
*    SWAP_BYTES - force endian conversion (eg __BYTE_ORDER not supported)
*    IVT        - add intermediate values test outputs (this slows
*                 down encryption and decryption significantly)
*/

#ifndef BOOST_CRYPTO_MARS_HPP_INCLUDED
#define BOOST_CRYPTO_MARS_HPP_INCLUDED
#
#include <boost/cstdint.hpp>         
#
#include "crypto.hpp"
#include "crypto_endian.hpp"
#include "crypto_rotation.hpp"
#include "block_cipher.hpp"

/*The low level mars routines are completely uint32_t oriented, and 
* endian neutral. The high level NIST routines provide BYTE oriented
* inputs and outputs, thus raising the endian issue when converting
* between BYTEs and uint32_ts. For these conversions, mars assumes 
* little endian order. On a big endian machine, we define BSWAP() 
* to do the conversions. BSWAP() is about the best you can do in C. 
* Real implementations will undoubtedly use inline ASM, as most risc 
* machines can do this in one instruction.
* 
* Make a best guess on platform endianness; This works on linux, AIX,
* and W95. For other platforms, you may have to manually define SWAP_BYTES
* on a big endian machine if this guessing doesn't work. 
*
* Some compiler optimizers will recognize certain rotation idioms,
* and reduce them to native rotation instructions. These idioms
* have been found to work for GCC on Intel, and XLC on RS6000.
* Nothing seems to work on Borland C++ 5.0, although we can leave
* out the mask on 'b'.
*/

/* use possible compile intrinsic functions */
#define LROTATE BOOST_ROL32
#define RROTATE BOOST_ROR32

#define MixForwardRound(d1,d2,d3,d4) \
	d2 ^= sp[d1&255];      \
	y = RROTATE(d1,8);     \
	z = RROTATE(d1,16);    \
	d1 = RROTATE(d1,24);   \
	d2 += sp[(y&255)+256]; \
	d3 += sp[z&255];       \
	d4 ^= sp[(d1&255)+256];

#define MixBackwardsRound(d1,d2,d3,d4) \
	d2 ^= sp[(d1&255)+256];\
	y = LROTATE(d1,8);     \
	z = LROTATE(d1,16);    \
	d1 = LROTATE(d1,24);   \
	d3 -= sp[y&255];       \
	d4 -= sp[(z&255)+256]; \
	d4 ^= sp[d1&255];      

#define CoreRound(d1,d2,d3,d4,i) \
	y = d1;            \
	d1 += m_ep[i];       \
	y = LROTATE(y,13); \
	z = d1;            \
	tmp = y;           \
	y *= m_ep[(i)+1];    \
	z &= 511;          \
	z = sp[z];         \
	y = LROTATE(y,5);  \
	z ^= y;            \
	d1 = LROTATE(d1,y);\
	y = LROTATE(y,5);  \
	d3 += d1;          \
	z ^= y;            \
	z = LROTATE(z,y);  \
	d2 += z;           \
	d4 ^= y;           \
	d1 = tmp;          

#define InvCoreRound(d1, d2, d3, d4, i) \
	y = d1;             \
	d1 = RROTATE(d1,13);\
	y *= m_ep[(i)+1];     \
	tmp = d1;           \
	d1 += m_ep[i];        \
	z = d1;             \
	y = LROTATE(y,5);   \
	z &= 511;           \
	z = sp[z];          \
	d1 = LROTATE(d1,y); \
	z ^= y;             \
	y = LROTATE(y,5);   \
	d3 -= d1;           \
	z ^= y;             \
	d1 = tmp;           \
	z = LROTATE(z,y);   \
	d4 ^= y;            \
	d2 -= z;  

/*
 * Description of the E-function: data word `in' and key words 
 * `key1', `key2' are used to produce three outputs `L', `M' and `R' */
#define E_FNC(in, L, M, R, key1, key2)\
		M = in + key1;        \
		R = rol(in,13) * key2;\
		L = S[M & 511];       \
		R = rol(R,5);         \
		L ^= R;               \
		M = rol(M,R);         \
		R = rol(R,5);         \
		L ^= R;               \
		L = rol(L,R);

namespace boost {
	namespace crypto {
		namespace detail {
			namespace mars {
				extern constexpr uint32_t S[512];
			} // namespace boost::crypto::detail::mars
		} // namespace boost::crypto::detail


		template<size_t ForwardRounds, size_t CoreRounds, size_t BackwardRounds>
		class mars_cipher
		{
		public:
			typedef size_t		size_type;
			typedef byte_t		value_type;
			typedef uint32_t	word_type;
			static constexpr size_t min_key_size = 16;
			static constexpr size_t max_key_size = 56;
			static constexpr size_t block_size = 16;
			static constexpr char*  name() { return "MARS"; }


		private:
			// NotImplemented

			static constexpr size_type mix_rounds_per_core  =  8;			
			static constexpr size_type fwd_rounds           = ForwardRounds;
			static constexpr size_type bwd_rounds           = BackwardRounds;
			static constexpr size_type full_core_rounds     = CoreRounds;
			static constexpr size_type key_setup_mix_rounds =  8;
			static constexpr size_type w = bistof<word_type>::value;
			static constexpr size_type subkey     = (2*(block_size+full_core_rounds));

			/* if multiplication subkey k has 10 0's or 10 1's, mask in a fixing value */
			static word_type fix_subkey(word_type k, word_type r) 
			{
				using detail::mars::S;

				/* the mask words come from S[265]..S[268], as chosen by index.c */
				word_type *B = &S[265]; 
				word_type m1, m2;
				int i;

				i = k & 3;            /* store the least two bits of k */
				k |= 3;               /* and then mask them away       */

				/* we look for 9 consequtive 1's in m1 */
				m1 = (~k) ^ (k<<1);   /* for i > 1, m1_i = 1 iff k_i = k_{i-1} */
				m2 = m1 & (m1 << 1);  /* m2_i = AND (m1_i, m1_{i-1})   */
				m2 &= m2 << 2;        /* m2_i = AND (m1_i...m1_{i-3})  */
				m2 &= m2 << 4;        /* m2_i = AND (m1_i...m1_{i-7})  */
				m2 &= m1 << 8;        /* m2_i = AND (m1_i...m1_{i-8})  */
				m2 &= 0xfffffe00;     /* mask out the low 9 bits of m2 */
				/* for i = 9...31, m2_i = 1 iff k_i = ... = k_{i-9} */

				/* if m2 is zero, k was good, so return */ 
				if (!m2)
					return(k);

				/* need to fix k: we copy each 1 in m2 to the nine bits to its right */
				m1 = m2 | (m2 >> 1);  /* m1_i = AND (m2_i, m2_{i+1})   */
				m1 |= m1 >> 2;        /* m1_i = AND (m2_i...m2_{i+3})  */
				m1 |= m2 >> 4;        /* m1_i = AND (m2_i...m2_{i+4})  */
				m1 |= m1 >> 5;        /* m1_i = AND (m2_i...m2_{i+9})  */
				/* m1_i = 1 iff k_i belongs to a sequence of ten 0's or ten 1's */

				/* we turn off the two lowest bits of M, and also every bit 
				* M_i such that k_i is not equal to both k_{i-1} and k_{i+1} 
				*/
				m1 &= ((~k)^(k<<1)) & ((~k)^(k>>1)) & 0x7ffffffc; 

				/* and finally pick a pattern, rotate it, 
				* and xor it into k under the control of the mask m1
				*/
				k ^= LROTATE(B[i], r) & m1;

				return(k);
			}

			int mars_setup(int n, word_type *kp, word_type *ep)
			{
				word_type T[15] = {0}; 
				int i,j,t;

				/* check key length */
				if ((n<4)||(n>14))
					return(BAD_KEY_MAT);

				/* initialize the T[] array with key data */
				for (i=0; i<n; i++)
					T[i] = kp[i];
				T[n] = n;
				for (i=n+1; i<15; i++)
					T[i] = 0;

				/* Four iterations, each one computing 10 words of the array */
				for (j=0; j<4; j++) {
					/* Linear transformation */
					for (i=0; i<15; i++) { 
						word_type w = T[(i+8)%15] ^ T[(i+13)%15]; /* T[i-7] ^ T[i-2] */
						T[i] ^= LROTATE(w,3) ^ (4*i+j);
					}

					/* Four stirring rounds */
					for (t=0; t<4; t++){
						/* stir with full type-1 s-box rounds */
						i = 0;
						for ( ; i<15; i++) {
							T[i] += S[ T[(i+14)%15]&511 ];   /* T[i] += S[ T[i-1] ] */
							T[i] = LROTATE(T[i],9);
						}
					}

					/* copy subkeys to mars_ctx, with swapping around */
					for (i=0; i<10; i++)
						ep[(10*j)+i] = T[(i*4)%15];
				}

				/* check and fix all multiplication subkeys */
				for (i=NUM_DATA+1;i<(EKEY_WORDS-NUM_DATA);i+=2)
					ep[i] = fix_subkey(ep[i], ep[i-1]);

				return(1);
			}

			/*
			 * One mixing round in forward mode:
			 * data[src] is used to modify data[dst1], data[dst2] and data[dst2] */
			void forward_mix_round(word_type data[], int src, int dst1, int dst2, int dst3)
			{
				int i0, i1, i2, i3;

				i0 = data[src] & 255;          /* lowest byte */
				i1 = (data[src] >> 8) & 255;   /* 2nd byte    */
				i2 = (data[src] >> 16) & 255;  /* 3rd byte    */
				i3 = (data[src] >> 24) & 255;  /* highest byte*/

				data[dst1] ^= S[i0];
				data[dst1] += S[i1+256];
				data[dst2] += S[i2]; 
				data[dst3] ^= S[i3+256]; 

				data[src] = ror(data[src],24);
			}

			/* 
			 * One mixing round in backwards mode:
			 * data[src] is used to modify data[dst1], data[dst2] and data[dst2] */
			void backwards_mix_round(word_type data[], int src, int dst1, int dst2, int dst3)
			{
				int i0, i1, i2, i3;

				i0 = data[src] & 255;          /* lowest byte */
				i1 = (data[src] >> 8) & 255;   /* 2nd byte    */
				i2 = (data[src] >> 16) & 255;  /* 3rd byte    */
				i3 = (data[src] >> 24) & 255;  /* highest byte*/

				data[dst1] ^= S[i0+256];
				data[dst2] -= S[i3];
				data[dst3] -= S[i2+256]; 
				data[dst3] ^= S[i1]; 

				data[src] = rol(data[src],24);
			}

			constexpr void setkey(const void* key, size_type key_size) 
				throw(invalid_key_size)
			{
				BOOST_CRYPTO_CHECK_KEYSIZE(key_size,boost::crypto::mars_cipher::setkey());


			}


			/* The basic mars encryption: */
			constexpr void encrypt(void* ctxt, const void* ptxt)
			{
				int i;
				word_type *key = m_key;
				word_type *out = reinterpret_cast<word_type*>(ctxt);
				
				/* first, add subkeys to all input data words */
				out[0] = endian::read_le32( reinterpret_cast<const word_type*>(ptxt) + 0 ); + key[0];
				out[1] = endian::read_le32( reinterpret_cast<const word_type*>(ptxt) + 1 ); + key[1];
				out[2] = endian::read_le32( reinterpret_cast<const word_type*>(ptxt) + 2 ); + key[2];
				out[3] = endian::read_le32( reinterpret_cast<const word_type*>(ptxt) + 3 ); + key[3];

				/* then do eight mixing rounds */
				for (i = 0; i < fwd_rounds/4; i++) {
					forward_mix_round(out, 0, 1, 2, 3);		out[0] += out[3];
					forward_mix_round(out, 1, 2, 3, 0);		out[1] += out[2];
					forward_mix_round(out, 2, 3, 0, 1);
					forward_mix_round(out, 3, 0, 1, 2);
				}

				/* then sixteen mars encrypting rounds  */
				for (i = 0; i < full_core_rounds; i++) {
					word_type L, M, R;
					int src = i & 3;
					int dst1 = (i+1) & 3; 
					int dst2 = (i+2) & 3; 
					int dst3 = (i+3) & 3;

					/* compute the E-function */
					E_FNC(out[src], L, M, R, key[2*i+4], key[2*i+5]); 

					out[dst2] += M;
					out[src] = rol(out[src],13);

					
					if (i < full_core_rounds / 2) { 
						/* do the first half of the rounds in forward mode */
						out[dst1] += L;
						out[dst3] ^= R;
					} else {        
						/* do the second half of the in backwards mode */
						out[dst3] += L;
						out[dst1] ^= R;
					}
				}

				/* then do eight inverse-mixing rounds */
				for (i = 0; i < bwd_rounds/4; i++) {
					backwards_mix_round(out, 0, 1, 2, 3);
					backwards_mix_round(out, 1, 2, 3, 0);			out[2] -= out[1];
					backwards_mix_round(out, 2, 3, 0, 1);			out[3] -= out[0];
					backwards_mix_round(out, 3, 0, 1, 2);
				}

				/* subtract final subkeys */
				out[0] -= key[2*full_core_rounds+4];
				out[1] -= key[2*full_core_rounds+5];
				out[2] -= key[2*full_core_rounds+6];
				out[3] -= key[2*full_core_rounds+7];

				/* ensure little endianess */
				endian::write_le32(out + 0, out[0]);
				endian::write_le32(out + 1, out[1]);
				endian::write_le32(out + 2, out[2]);
				endian::write_le32(out + 3, out[3]);
			}

			/* mars decryption is simply encryption in reverse */
			constexpr void decrypt(void* ptxt, const void* ctxt)
			{
				int i;
				word_type *key = m_key;
				word_type *out = reinterpret_cast<word_type*>(ctxt);
				
				/* first, add subkeys to all input data words */
				out[0] = endian::read_le32( reinterpret_cast<const word_type*>(ctxt) + 0 ); + key[2*full_core_rounds+4];
				out[1] = endian::read_le32( reinterpret_cast<const word_type*>(ctxt) + 1 ); + key[2*full_core_rounds+5];
				out[2] = endian::read_le32( reinterpret_cast<const word_type*>(ctxt) + 2 ); + key[2*full_core_rounds+6];
				out[3] = endian::read_le32( reinterpret_cast<const word_type*>(ctxt) + 3 ); + key[2*full_core_rounds+7];

				/* then do two mixing rounds */
				for (i = 0; i < bwd_rounds/4; i++) {
					forward_mix_round(out, 3, 2, 1, 0); 		out[3] += out[0];
					forward_mix_round(out, 2, 1, 0, 3); 		out[2] += out[1];
					forward_mix_round(out, 1, 0, 3, 2); 
					forward_mix_round(out, 0, 3, 2, 1); 
				}

				/* then sixteen mars decrypting rounds         */
				for (i = full_core_rounds - 1; i >= 0; i--) {
					word_type L, M, R;
					int src = i & 3;
					int dst1 = (i+3) & 3; 
					int dst2 = (i+2) & 3; 
					int dst3 = (i+1) & 3;

					out[src] = ror(out[src],13);
					E_FNC(out[src], L, M, R, key[2*i+4],key[2*i+5]); 
					out[dst2] -= M;

					if (i >= full_core_rounds/2) { 
						/* do the first half of rounds in forward mode */
						out[dst1] -= L;
						out[dst3] ^= R;
					} else {
						/* do the second half of rounds in backwards mode */
						out[dst3] -= L;
						out[dst1] ^= R;
					}
				}

				/* then do two inverse-mixing rounds */
				for (i = 0; i < fwd_rounds/4; i++) {
					backwards_mix_round(out, 3, 2, 1, 0);
					backwards_mix_round(out, 2, 1, 0, 3);		out[1] -= out[2];
					backwards_mix_round(out, 1, 0, 3, 2);		out[0] -= out[3];
					backwards_mix_round(out, 0, 3, 2, 1);
				}

				/* subtract final subkeys */
				out[3] -= key[3];
				out[2] -= key[2];
				out[1] -= key[1];
				out[0] -= key[0];
				
				endian::write_le32(out + 0, out[0]);
				endian::write_le32(out + 1, out[1]);
				endian::write_le32(out + 2, out[2]);
				endian::write_le32(out + 3, out[3]);
			}
		};

		template<>
		class mars_cipher<8,16,8>
		{
		public:
			typedef byte_t value_type;

			static constexpr size_t min_key_size = 16;
			static constexpr size_t max_key_size = 56;
			static constexpr size_t block_size = 16;
			static constexpr char*  name() { return "MARS"; }
		private:
			bool			m_initialise;
			uint32_t	m_ep[40];

			static constexpr uint32_t fix_subkey(uint32_t k, uint32_t r)
			{
				/* the mask words come from S[265]..S[268], as chosen by index.c */
				const uint32_t *B = &detail::mars::S[265]; 
				uint32_t m1, m2;
				int i;

				i = k & 3;            /* store the least two bits of k */
				k |= 3;               /* and then mask them away       */

				/* we look for 9 consequtive 1's in m1 */
				m1 = (~k) ^ (k<<1);   /* for i > 1, m1_i = 1 iff k_i = k_{i-1} */
				m2 = m1 & (m1 << 1);  /* m2_i = AND (m1_i, m1_{i-1})   */
				m2 &= m2 << 2;        /* m2_i = AND (m1_i...m1_{i-3})  */
				m2 &= m2 << 4;        /* m2_i = AND (m1_i...m1_{i-7})  */
				m2 &= m1 << 8;        /* m2_i = AND (m1_i...m1_{i-8})  */
				m2 &= 0xfffffe00;     /* mask out the low 9 bits of m2 */
				/* for i = 9...31, m2_i = 1 iff k_i = ... = k_{i-9} */

				/* if m2 is zero, k was good, so return */ 
				if (!m2)
					return(k);

				/* need to fix k: we copy each 1 in m2 to the nine bits to its right */
				m1 = m2 | (m2 >> 1);  /* m1_i = AND (m2_i, m2_{i+1})   */
				m1 |= m1 >> 2;        /* m1_i = AND (m2_i...m2_{i+3})  */
				m1 |= m2 >> 4;        /* m1_i = AND (m2_i...m2_{i+4})  */
				m1 |= m1 >> 5;        /* m1_i = AND (m2_i...m2_{i+9})  */
				/* m1_i = 1 iff k_i belongs to a sequence of ten 0's or ten 1's */

				/* we turn off the two lowest bits of M, and also every bit 
				* M_i such that k_i is not equal to both k_{i-1} and k_{i+1} 
				*/
				m1 &= ((~k)^(k<<1)) & ((~k)^(k>>1)) & 0x7ffffffc; 

				/* and finally pick a pattern, rotate it, 
				* and xor it into k under the control of the mask m1
				*/
				k ^= LROTATE(B[i], r) & m1;

				return(k);
			}

		public:

			mars_cipher()
				:
			m_initialise(false)
			{
			}

			mars_cipher(const void* key, size_t key_size)
			{
				setkey(key, key_size);
			}

			~mars_cipher() 
			{
				std::memset(m_ep,0, sizeof(m_ep));
			}

			constexpr void setkey(const void*key, size_t key_size)
				throw (invalid_key_size)
			{
				BOOST_CRYPTO_CHECK_KEYSIZE(key_size,boost::crypto::mars_cipher::setkey());

				using detail::mars::S;

				m_initialise = true;

				uint32_t T[15] = {0};
				int i,j,t,n = (key_size >> 2) + ((key_size & 3) ? (1) : (0));

				/* initialize the T[] array with key data */
				std::memcpy(T, key, key_size);
				for(i=0; i<n; i++) endian::ensure_le(T+i);
				T[n] = n;

				/* Four iterations, each one computing 10 words of the array */
				for (j=0; j<4; j++) {
					uint32_t w;

					/* Linear transformation */
					w = T[8] ^ T[13];	T[0] ^= LROTATE(w,3) ^ j;
					w = T[9] ^ T[14];	T[1] ^= LROTATE(w,3) ^ (4+j);
					for (i=2; i<7; i++) { 
						w = T[i+8] ^ T[i-2]; 
						T[i] ^= LROTATE(w,3) ^ ((i<<2)+j);
					}
					for (i=7; i<15; i++) { 
						w = T[i-7] ^ T[i-2]; 
						T[i] ^= LROTATE(w,3) ^ ((i<<2)+j);
					}

					/* Four stirring rounds */
					for (t=0; t<4; t++){
						/* stir with full type-1 s-box rounds */
						T[0] += S[ T[14]&511 ];
						T[0] = LROTATE(T[0],9);
						for (i=1; i<15; i++) {
							T[i] += S[ T[i-1]&511 ]; 
							T[i] = LROTATE(T[i],9);
						}
					}

					/* copy subkeys to mars_ctx, with swapping around */
#					define SWAP(i) (m_ep[(10*j)+i] = T[(i*4)%15])

					SWAP(0); SWAP(1); SWAP(2); SWAP(3); SWAP(4); 
					SWAP(5); SWAP(6); SWAP(7); SWAP(8); SWAP(9); 
#					undef SWAP
				}

				/* check and fix all multiplication subkeys */
				for (i=5;i<(40-4);i+=2)
					m_ep[i] = fix_subkey(m_ep[i], m_ep[i-1]);
			}

			constexpr void encrypt(void* ctxt, const void* ptxt)
			{
				register uint32_t a,b,c,d,y,z;
				uint32_t tmp;
				const uint32_t *sp = detail::mars::S;

				a = endian::read_le(reinterpret_cast<const uint32_t*>(ptxt)+0);
				b = endian::read_le(reinterpret_cast<const uint32_t*>(ptxt)+1);
				c = endian::read_le(reinterpret_cast<const uint32_t*>(ptxt)+2);
				d = endian::read_le(reinterpret_cast<const uint32_t*>(ptxt)+3);

				/* first, add subkeys to all input data words */
				a += m_ep[0];
				b += m_ep[1];
				c += m_ep[2];
				d += m_ep[3];

				/* then do eight mixing rounds */
				MixForwardRound(a,b,c,d);			a += d;
				MixForwardRound(b,c,d,a);			b += c;
				MixForwardRound(c,d,a,b);
				MixForwardRound(d,a,b,c);
				MixForwardRound(a,b,c,d);			a += d;
				MixForwardRound(b,c,d,a);			b += c;
				MixForwardRound(c,d,a,b);
				MixForwardRound(d,a,b,c);
				/* then sixteen mars encrypting rounds             *
				* (eight in forward- and eight in backwards-mode) */

				CoreRound(a,b,c,d, 4);
				CoreRound(b,c,d,a, 6);
				CoreRound(c,d,a,b, 8);
				CoreRound(d,a,b,c,10);
				CoreRound(a,b,c,d,12);
				CoreRound(b,c,d,a,14);
				CoreRound(c,d,a,b,16);
				CoreRound(d,a,b,c,18);
				CoreRound(a,d,c,b,20);
				CoreRound(b,a,d,c,22);
				CoreRound(c,b,a,d,24);
				CoreRound(d,c,b,a,26);
				CoreRound(a,d,c,b,28);
				CoreRound(b,a,d,c,30);
				CoreRound(c,b,a,d,32);
				CoreRound(d,c,b,a,34);

				/* then do eight inverse-mixing rounds */
				MixBackwardsRound(a,b,c,d);
				MixBackwardsRound(b,c,d,a);			c -= b;
				MixBackwardsRound(c,d,a,b);			d -= a;
				MixBackwardsRound(d,a,b,c);
				MixBackwardsRound(a,b,c,d);
				MixBackwardsRound(b,c,d,a);			c -= b;
				MixBackwardsRound(c,d,a,b);			d -= a;
				MixBackwardsRound(d,a,b,c);

				/* subtract final subkeys */
				a -= m_ep[2*16+4];
				b -= m_ep[2*16+5];
				c -= m_ep[2*16+6];
				d -= m_ep[2*16+7];

				endian::write_le(((uint32_t*)ctxt), a);
				endian::write_le(((uint32_t*)ctxt)+1, b);
				endian::write_le(((uint32_t*)ctxt)+2, c);
				endian::write_le(((uint32_t*)ctxt)+3, d);
			}

			constexpr void decrypt(void* ptxt, const void* ctxt)
			{
				register uint32_t a,b,c,d,y,z;
				uint32_t tmp;
				const uint32_t *sp = detail::mars::S;
				
				d = endian::read_le(((uint32_t*)ctxt)+0);
				c = endian::read_le(((uint32_t*)ctxt)+1);
				b = endian::read_le(((uint32_t*)ctxt)+2);
				a = endian::read_le(((uint32_t*)ctxt)+3);

				/* first, add subkeys to all input data words */
				a += m_ep[2*16+7];
				b += m_ep[2*16+6];
				c += m_ep[2*16+5];
				d += m_ep[2*16+4];
				

				/* then do eight mixing rounds */
				MixForwardRound(a,b,c,d);		a += d;
				MixForwardRound(b,c,d,a);		b += c;
				MixForwardRound(c,d,a,b);				
				MixForwardRound(d,a,b,c);
				MixForwardRound(a,b,c,d);		a += d;
				MixForwardRound(b,c,d,a);		b += c;
				MixForwardRound(c,d,a,b);				
				MixForwardRound(d,a,b,c);

				/* then sixteen mars decrypting rounds             *
				* (eight in forward- and eight in backwards-mode) */

				InvCoreRound(a,b,c,d,34);				
				InvCoreRound(b,c,d,a,32);				
				InvCoreRound(c,d,a,b,30);				
				InvCoreRound(d,a,b,c,28);				
				InvCoreRound(a,b,c,d,26);				
				InvCoreRound(b,c,d,a,24);				
				InvCoreRound(c,d,a,b,22);				
				InvCoreRound(d,a,b,c,20);		
				InvCoreRound(a,d,c,b,18);				
				InvCoreRound(b,a,d,c,16);				
				InvCoreRound(c,b,a,d,14);				
				InvCoreRound(d,c,b,a,12);				
				InvCoreRound(a,d,c,b,10);		
				InvCoreRound(b,a,d,c, 8);				
				InvCoreRound(c,b,a,d, 6);				
				InvCoreRound(d,c,b,a, 4);				

				/* then do eight inverse-mixing rounds */
				MixBackwardsRound(a,b,c,d);				
				MixBackwardsRound(b,c,d,a);			c -= b;
				MixBackwardsRound(c,d,a,b);			d -= a;
				MixBackwardsRound(d,a,b,c);				
				MixBackwardsRound(a,b,c,d);				
				MixBackwardsRound(b,c,d,a);			c -= b;
				MixBackwardsRound(c,d,a,b);			d -= a;
				MixBackwardsRound(d,a,b,c);				

				/* subtract final subkeys */
				a -= m_ep[3];
				b -= m_ep[2];
				c -= m_ep[1];
				d -= m_ep[0];				

				endian::write_le(((uint32_t*)ptxt)+0,d);
				endian::write_le(((uint32_t*)ptxt)+1,c);
				endian::write_le(((uint32_t*)ptxt)+2,b);
				endian::write_le(((uint32_t*)ptxt)+3,a);
			}
		};

		// AES Finalist variant fo the cipher
		typedef mars_cipher<8,16,8> mars;

	} // namespace boost::crypto
} // namespace boost 

#undef E_FNC
#undef LROTATE
#undef RROTATE
#undef MixForwardRound
#undef MixBackwardsRound
#undef CoreRound
#undef InvCoreRound
#
#endif /* BOOST_CRYPTO_MARS_HPP_INCLUDED */

