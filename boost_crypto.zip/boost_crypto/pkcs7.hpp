#ifndef BOOST_CRYPTO_PKCS7_HPP_INCLUDED
#define BOOST_CRYPTO_PKCS7_HPP_INCLUDED
#
#include <stdexcept>
#include <exception>
#include <cstring>
#include <string>
#include <cstdlib>
#
#include "crypto.hpp"
#include "padding_traits.hpp"

namespace boost { 
	namespace crypto {
		namespace detail {
		} // namespace boost::crypto::detail 

		/* 
		 * fill incomplete values with the margin.
		 */
		template<size_t B,typename T=byte_t>
		struct pkcs7_padding
		{
			static constexpr size_t min_block_size = 1;
			static constexpr size_t max_block_size = 256;
			static constexpr bool   allways_pad = false;
			static constexpr size_t padding_block_size = B;

			// return the size of string with input_size after the padding
			static constexpr size_t output_size(size_t input_size)
			{
				return input_size + (padding_block_size - (input_size % padding_block_size));
			}
			
			static constexpr size_t pad(T* output, const T* input, size_t input_size) throw(std::length_error)
			{
				if(input_size > max_block_size)
					throw std::length_error(std::string("boost::crypto::pkcs7_padding::pad() : invalid length"));
				
				T margin  = input_size % padding_block_size;
				T outsize =  output_size(input_size);

				if(input != output) memcpy(output, input, input_size);
				for(int i = input_size; i < outsize ; i++) output[i] = margin;
			}

			// return the size of string with input_size after the unpadding
			static size_t unpad(T* output, const T* input, size_t input_size) throw(bad_padding)
			{
				T margin = input[input_size-1] ;
				if(margin > padding_block_size)
					goto bad_padding_throw;

				for(size_t i = input_size-1; i >= 0; i--)
					if(margin != input[i]) 
						if(input_size - i == margin)
							break;
						else
							goto bad_padding_throw;
					else if(input_size - i == margin)
						break; // margin is found
				
				if(input != output) memcpy(output, input, input_size-margin);
				return input_size-margin;

bad_padding_throw:
				throw bad_padding("boost::crypto::pkcs7_padding::unpad() : invalid padding");
			}
		};

	} // namepace boost::crypto
} // namespace boost 


#endif /* BOOST_CRYPTO_PKCS7_HPP_INCLUDED */
