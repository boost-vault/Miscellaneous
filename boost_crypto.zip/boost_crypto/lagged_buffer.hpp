#ifndef BOOST_CRYPTO_LAGGED_BUFFER_HPP_INCLUDED
#define BOOST_CRYPTO_LAGGED_BUFFER_HPP_INCLUDED
#
#include <cstddef> // size_t
#include <algorithm> // swap
#include "crypto.hpp"
#include "secure_allocator.hpp"
#include "dynamic_buffer.hpp"
#include <boost/signal/signal.hpp>

namespace boost { 
	namespace crypto { 
		namespace detail {
		} // namespace boost::crypto::detail

		/** this class signals an event when ever 
		 * its buffer reaches a certain size.
		 * function pointers is used for maximum performance.
		 */
		template<size_t LGBS, class Alloc=secure_allocator<> >
		class lagged_buffer
		{
		public:
			typedef Alloc allocator_type;
			typedef typename allocator_type::size_type       size_type;
			typedef typename allocator_type::difference_type difference_type;
			typedef typename allocator_type::pointer         pointer;
			typedef typename allocator_type::const_pointer   const_pointer;
			typedef typename allocator_type::reference       reference;
			typedef typename allocator_type::const_reference const_reference;
			typedef typename allocator_type::value_type      value_type;
			typedef void (*signal_callback_t) ( pointer );

			static constexpr size_type buffer_size = LGBS;

		private:
			signal_callback_t m_signal;
			size_type m_pos;
			value_type m_buffer[buffer_size];

			void add_more(const_reference crefv)
			{
				if(m_pos == buffer_size)
				{
					 // signal the buffer_full event
					if(m_signal(m_buffer))
						m_pos = 0;
				}
				else if(m_pos > buffer_size)
				{
					throw overflow_error(string("lagged_buffer() : overflow error"));
				}

				m_buffer[m_pos++] = crefv;
			}

		public:
			lagged_buffer(signal_callback_t callback) 
				: m_pos(0), m_signal(callback) { }

			lagged_buffer& operator << (value_type value)
			{
				return (*this);
			}

			lagged_buffer& operator << (const_pointer pointer, size_type amount)
			{
				while(amount--) add_more(pointer++);
				return (*this);
			}

			
			template<typename T, class A>
			lagged_buffer& operator <<(dynamic_buffer<T,A>& buffer)
			{
				size_type size = buffer.size();
				for(size_type i = size_type(0); i < buffer.size(); i++)
					add_more(buffer() [i]);
			}

		};

	} // namespace boost::crypto
} // namespace boost


#endif /* BOOST_CRYPTO_LAGGED_BUFFER_HPP_INCLUDED */
