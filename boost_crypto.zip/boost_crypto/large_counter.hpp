//          Copyright Kevin Sopp 2008-*.
//          Copyright Kevin Sopp 2007.
// Distributed under the Boost Software License, Version 1.0.
//    (See accompanying file LICENSE_1_0.txt or copy at
//          http://www.boost.org/LICENSE_1_0.txt)

#ifndef BOOST_CRYPTO_LARGE_COUNTER_HPP_INCLUDED
#define BOOST_CRYPTO_LARGE_COUNTER_HPP_INCLUDED

#include <cstring> // memcpy, memset
#include <stdexcept>
#include <cmath>
#include <boost/detail/endian.hpp>
#define abs(x) (((unsigned)(x)<0)?(unsigned)(-x):(unsigned)(x))
namespace boost {
	namespace crypto {
		namespace detail {


			template<typename T>
			void native_to_big_endian(void* vdst, const void* vsrc, int n)
			{
#if defined(BOOST_BIG_ENDIAN)
				std::memcpy(vdst, vsrc, n);
#elif defined(BOOST_LITTLE_ENDIAN)
				T* dst = static_cast<T*>(vdst);
				const unsigned char* src = static_cast<const unsigned char*>(vsrc);
				const int size = sizeof(T);
				for (int i = 0; i < n / size; ++i)
				{
					dst[i] = (T)src[i * size] << 8 * (size - 1);
					for (int j = 1; j < size; ++j)
						dst[i] |= (T)src[i * size + j]
					<< 8 * (size - j - 1);
				}
#else
#error unsupported endianness
#endif
			}

			template<typename T>
			void native_to_little_endian(void* vdst, const void* vsrc, int n)
			{
#if defined(BOOST_LITTLE_ENDIAN)
				std::memcpy(vdst, vsrc, n);
#elif defined(BOOST_BIG_ENDIAN)
				T* dst = static_cast<T*>(vdst);
				const unsigned char* src = static_cast<const unsigned char*>(vsrc);
				const int size = sizeof(T);
				for (int i = 0; i < n / size; ++i)
				{
					dst[i] = (T)src[i * size];
					for (int j = 1; j < size; ++j)
						dst[i] |= (T)src[i * size + j] << 8 * j;
				}
#else
#error unsupported endianness
#endif

			}
			// bit count with little endian layout
			// this is used so that multiword bitcounts are handled correctly
			// and safely (resistant against timing attacks)
			// N > 0
			template<typename T, int N>
			struct large_counter
			{
				typedef T value_type;
				static const int elements = N;

				large_counter()
				{
					std::memset(m_data, 0, sizeof(m_data));
				}

				large_counter(const T& x)
				{
					m_data[0] = x;
					std::memset(m_data + 1, 0, sizeof(m_data) - sizeof(T));
				}

				large_counter(const large_counter& copy)
				{
					std::memcpy(m_data, copy.m_data, sizeof(m_data));
				}

				~large_counter()
				{
					std::memset(m_data, 0, sizeof(T) * N);
				}

				large_counter& operator = (const large_counter& rhs)
				{
					std::memcpy(m_data, rhs.m_data, sizeof(m_data));
					return *this;    
				}

				large_counter& operator += (large_counter& rhs)
				{
					T c=0, t=0;
					for(int i=0; i<N; i++)
					{
						t = m_data[i];
						m_data[i] += rhs.m_data[i];
						if(abs(m_data[i]) < abs(t)) 
							c = 1;
						else 
							c = 0;

						for(int j=i+1; j<N; j++)
						{
							/* carry 1 */
							t = m_data[j];
							m_data[j] += c;
							if(abs(m_data[j]) < abs(t)) 
								c = 1;
							else
								c = 0;
						}
					}

					// m_data mod 8 * N * sizeof(T)
					m_data[0] += c;

					if(c) 
						throw std::overflow_error("large_counter() : counter overflow");
					else
						return (*this);
				}
				
				large_counter& operator + (large_counter& rhs)
				{
					large_counter t(*this);
					return ((t += rhs));
				}

				large_counter& operator += (T x)
				{
					return (*this += large_counter(x));
				}

				large_counter& operator + (T x)
				{
					large_counter t(*this);
					return (t += x);
				}
				
				T&       operator [] (unsigned int n)       { return m_data[n]; }
				const T& operator [] (unsigned int n) const { return m_data[n]; }

				T*       data()       { return m_data; }
				const T* data() const { return m_data; }			

			protected:
				void add (T x, int index)
				{
				}

			private:

				T m_data[N];
			};

		} // namespace detail
	} // namespace crypto
} // namespace boost

#undef abs
#endif /* BOOST_CRYPTO_LARGE_COUNTER_HPP_INCLUDED */
