/*
**********************************************************************
** md5.c                                                            **
** rsa data security, inc. md5 message digest algorithm             **
** created: 2/17/90 rlr                                             **
** revised: 1/91 srd,aj,bsk,jt reference c version                  **
**********************************************************************
*
**********************************************************************
** copyright (c) 1990, rsa data security, inc. all rights reserved. **
**                                                                  **
** license to copy and use this software is granted provided that   **
** it is identified as the "rsa data security, inc. md5 message     **
** digest algorithm" in all material mentioning or referencing this **
** software or this function.                                       **
**                                                                  **
** license is also granted to make and use derivative works         **
** provided that such works are identified as "derived from the rsa **
** data security, inc. md5 message digest algorithm" in all         **
** material mentioning or referencing the derived work.             **
**                                                                  **
** rsa data security, inc. makes no representations concerning      **
** either the merchantability of this software or the suitability   **
** of this software for any particular purpose.  it is provided "as **
** is" without express or implied warranty of any kind.             **
**                                                                  **
** these notices must be retained in any copies of any part of this **
** documentation and/or software.                                   **
**********************************************************************
*/

/* -- include the following line if the md5.h header file is separate -- */


/* f, g and h are basic md5 functions: selection, majority, parity */
#define f(x, y, z) (((x) & (y)) | ((~x) & (z)))
#define g(x, y, z) (((x) & (z)) | ((y) & (~z)))
#define h(x, y, z) ((x) ^ (y) ^ (z))
#define i(x, y, z) ((y) ^ ((x) | (~z))) 

/* rotate_left rotates x left n bits */
#define rotate_left(x, n) BOOST_ROL32(x,n)

/* ff, gg, hh, and ii transformations for rounds 1, 2, 3, and 4 */
/* rotation is separate from addition to prevent recomputation */
#define ff(a, b, c, d, x, s, ac) \
{(a) += f ((b), (c), (d)) + (x) + (uint32_t)(ac); \
	(a) = rotate_left ((a), (s)); \
	(a) += (b); \
	}
#define gg(a, b, c, d, x, s, ac) \
{(a) += g ((b), (c), (d)) + (x) + (uint32_t)(ac); \
	(a) = rotate_left ((a), (s)); \
	(a) += (b); \
	}
#define hh(a, b, c, d, x, s, ac) \
{(a) += h ((b), (c), (d)) + (x) + (uint32_t)(ac); \
	(a) = rotate_left ((a), (s)); \
	(a) += (b); \
	}
#define ii(a, b, c, d, x, s, ac) \
{(a) += i ((b), (c), (d)) + (x) + (uint32_t)(ac); \
	(a) = rotate_left ((a), (s)); \
	(a) += (b); \
	}

//          Copyright Kasra Nassiri 2008-*.
// Distributed under the Boost Software License, Version 1.0.
//    (See accompanying file LICENSE_1_0.txt or copy at
//          http://www.boost.org/LICENSE_1_0.txt)

// Implements 'The MD5 Message-Digest Algorithm'
// RFC 1321 http://tools.ietf.org/html/rfc1321


#ifndef BOOST_CRYPTO_DETAIL_MD5_CTX_HPP
#define BOOST_CRYPTO_DETAIL_MD5_CTX_HPP
#
#include "crypto.hpp"
// concepts and states
#include "hash_function.hpp"
// input buffering
#include "digest_buffer.hpp"
#include "crypto_rotation.hpp"
#include "crypto_endian.hpp"
#
#define BOOST_TEST(x,i) (((x) & (i)) != 0)

namespace boost {
	namespace crypto {
		namespace detail {
			namespace md5 {
				static uint8_t padding[64] = {
					0x80, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
					0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
					0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
					0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
					0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
					0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
					0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00,
					0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00, 0x00
				};
			} // namespace md5
		} // namespace detail
	

		// struct only holds the data, it would not do any buffering and etc.
		class md5_ctx
		{
		public:
			typedef uint8_t  char_type;
			typedef uint32_t word_type;
			typedef size_t   size_type;

			/* size of the digest */
			static constexpr size_type digest_size       = 16;

			/* size of the internal state */
			static constexpr size_type state_size        = 16;

			/* minimum required size of each input block */
			static constexpr size_type transform_size    = 64;

			md5_ctx() { create(); }						
			//md5_ctx(const md5_ctx&)
			//md5_ctx& operator = (const md5_ctx&);

			~md5_ctx()
			{
				std::memset(m_buf, 0, sizeof(m_buf));
				std::memset(m_digest, 0, sizeof(m_digest));
				std::memset(&m_message_bits, 0, sizeof(m_message_bits));
			}

			md5_ctx& operator = (md5_ctx& rhs)
			{
				m_state = rhs.m_state;
				m_message_bits = rhs.m_message_bits;

				std::memcpy(m_buf, rhs.m_buf   , state_size);
				std::memcpy(m_buf, rhs.m_digest, digest_size);

				return (*this);
			}

			// create a new stream, destroying any previously created streams
			void create() throw()
			{
				m_message_bits = 0;
				/* load magic initialization constants. */					
				m_buf[0] = (uint32_t)UINT32_C(0x67452301);
				m_buf[1] = (uint32_t)UINT32_C(0xefcdab89);
				m_buf[2] = (uint32_t)UINT32_C(0x98badcfe);
				m_buf[3] = (uint32_t)UINT32_C(0x10325476);
			}

			/* transform using previously set buffer, or assign a new pointer */
			/* [buf] should point to memory of size at least [transform_size] */
			md5_ctx& transform(const void* input) throw(bad_hash_state)
			{
				if(m_state != hash_function_processing)
					if(m_state == hash_function_created)		
						m_state = hash_function_processing;
					else if(m_state != hash_function_finalising)
						throw bad_hash_state("md5_ctx::transform() : could not transform an empty stream");

				const uint32_t *in = reinterpret_cast<const uint32_t*>(input);
				register uint32_t a = m_buf[0], b = m_buf[1], c = m_buf[2], d = m_buf[3];

				/* round 1 */
#define s11 7
#define s12 12
#define s13 17
#define s14 22
				ff ( a, b, c, d, in[ 0], s11, 3614090360); /* 1 */
				ff ( d, a, b, c, in[ 1], s12, 3905402710); /* 2 */
				ff ( c, d, a, b, in[ 2], s13,  606105819); /* 3 */
				ff ( b, c, d, a, in[ 3], s14, 3250441966); /* 4 */
				ff ( a, b, c, d, in[ 4], s11, 4118548399); /* 5 */
				ff ( d, a, b, c, in[ 5], s12, 1200080426); /* 6 */
				ff ( c, d, a, b, in[ 6], s13, 2821735955); /* 7 */
				ff ( b, c, d, a, in[ 7], s14, 4249261313); /* 8 */
				ff ( a, b, c, d, in[ 8], s11, 1770035416); /* 9 */
				ff ( d, a, b, c, in[ 9], s12, 2336552879); /* 10 */
				ff ( c, d, a, b, in[10], s13, 4294925233); /* 11 */
				ff ( b, c, d, a, in[11], s14, 2304563134); /* 12 */
				ff ( a, b, c, d, in[12], s11, 1804603682); /* 13 */
				ff ( d, a, b, c, in[13], s12, 4254626195); /* 14 */
				ff ( c, d, a, b, in[14], s13, 2792965006); /* 15 */
				ff ( b, c, d, a, in[15], s14, 1236535329); /* 16 */

				/* round 2 */
#define s21 5
#define s22 9
#define s23 14
#define s24 20
				gg ( a, b, c, d, in[ 1], s21, 4129170786); /* 17 */
				gg ( d, a, b, c, in[ 6], s22, 3225465664); /* 18 */
				gg ( c, d, a, b, in[11], s23,  643717713); /* 19 */
				gg ( b, c, d, a, in[ 0], s24, 3921069994); /* 20 */
				gg ( a, b, c, d, in[ 5], s21, 3593408605); /* 21 */
				gg ( d, a, b, c, in[10], s22,   38016083); /* 22 */
				gg ( c, d, a, b, in[15], s23, 3634488961); /* 23 */
				gg ( b, c, d, a, in[ 4], s24, 3889429448); /* 24 */
				gg ( a, b, c, d, in[ 9], s21,  568446438); /* 25 */
				gg ( d, a, b, c, in[14], s22, 3275163606); /* 26 */
				gg ( c, d, a, b, in[ 3], s23, 4107603335); /* 27 */
				gg ( b, c, d, a, in[ 8], s24, 1163531501); /* 28 */
				gg ( a, b, c, d, in[13], s21, 2850285829); /* 29 */
				gg ( d, a, b, c, in[ 2], s22, 4243563512); /* 30 */
				gg ( c, d, a, b, in[ 7], s23, 1735328473); /* 31 */
				gg ( b, c, d, a, in[12], s24, 2368359562); /* 32 */

				/* round 3 */
#define s31 4
#define s32 11
#define s33 16
#define s34 23
				hh ( a, b, c, d, in[ 5], s31, 4294588738); /* 33 */
				hh ( d, a, b, c, in[ 8], s32, 2272392833); /* 34 */
				hh ( c, d, a, b, in[11], s33, 1839030562); /* 35 */
				hh ( b, c, d, a, in[14], s34, 4259657740); /* 36 */
				hh ( a, b, c, d, in[ 1], s31, 2763975236); /* 37 */
				hh ( d, a, b, c, in[ 4], s32, 1272893353); /* 38 */
				hh ( c, d, a, b, in[ 7], s33, 4139469664); /* 39 */
				hh ( b, c, d, a, in[10], s34, 3200236656); /* 40 */
				hh ( a, b, c, d, in[13], s31,  681279174); /* 41 */
				hh ( d, a, b, c, in[ 0], s32, 3936430074); /* 42 */
				hh ( c, d, a, b, in[ 3], s33, 3572445317); /* 43 */
				hh ( b, c, d, a, in[ 6], s34,   76029189); /* 44 */
				hh ( a, b, c, d, in[ 9], s31, 3654602809); /* 45 */
				hh ( d, a, b, c, in[12], s32, 3873151461); /* 46 */
				hh ( c, d, a, b, in[15], s33,  530742520); /* 47 */
				hh ( b, c, d, a, in[ 2], s34, 3299628645); /* 48 */

				/* round 4 */
#define s41 6
#define s42 10
#define s43 15
#define s44 21
				ii ( a, b, c, d, in[ 0], s41, 4096336452); /* 49 */
				ii ( d, a, b, c, in[ 7], s42, 1126891415); /* 50 */
				ii ( c, d, a, b, in[14], s43, 2878612391); /* 51 */
				ii ( b, c, d, a, in[ 5], s44, 4237533241); /* 52 */
				ii ( a, b, c, d, in[12], s41, 1700485571); /* 53 */
				ii ( d, a, b, c, in[ 3], s42, 2399980690); /* 54 */
				ii ( c, d, a, b, in[10], s43, 4293915773); /* 55 */
				ii ( b, c, d, a, in[ 1], s44, 2240044497); /* 56 */
				ii ( a, b, c, d, in[ 8], s41, 1873313359); /* 57 */
				ii ( d, a, b, c, in[15], s42, 4264355552); /* 58 */
				ii ( c, d, a, b, in[ 6], s43, 2734768916); /* 59 */
				ii ( b, c, d, a, in[13], s44, 1309151649); /* 60 */
				ii ( a, b, c, d, in[ 4], s41, 4149444226); /* 61 */
				ii ( d, a, b, c, in[11], s42, 3174756917); /* 62 */
				ii ( c, d, a, b, in[ 2], s43,  718787259); /* 63 */
				ii ( b, c, d, a, in[ 9], s44, 3951481745); /* 64 */

				m_buf[0] += a;
				m_buf[1] += b;
				m_buf[2] += c;
				m_buf[3] += d;

				m_message_bits += transform_size * 8;

				return (*this);
			}


			// [input] is and in/complete buffer with size of [input_size]
			// returns a const pointer to the digest
			md5_ctx& finalise(const void* input, size_type input_size) throw(bad_hash_state)
			{
				m_state = hash_function_finalising;

				uint8_t buf[56];
				uint32_t in[16];
				int i, mdi;
				unsigned int padlen;


				m_message_bits += input_size * 8;

				/* save number of bits */
				endian::write_le((uint64_t*)(in+14), m_message_bits);

				/* compute number of bytes mod 64 */
				mdi = (int)((m_message_bits >> 3) & 0x3f);

				/* pad out to 56 mod 64 */
				padlen = (mdi < 56) ? (56 - mdi) : (120 - mdi);
				if(mdi < 56)
				{
					std::memcpy(buf, input, input_size);
					std::memcpy(buf+input_size,detail::md5::padding,padlen);
				}
				else
				{
					std::memcpy(buf+input_size,detail::md5::padding,padlen & 63);
					transform(input);
					std::memcpy(buf,detail::md5::padding,padlen -= 64);
				}

				/* append length in bits and transform */
				for (i = 0; i < 14; i++)
					in[i] = endian::read_le32(reinterpret_cast<const uint32_t*>(buf)+i);

				transform (in);

				/* store buffer in digest */
				for (i = 0; i < 4; i++)				
					endian::write_le32(reinterpret_cast<uint32_t*>(m_digest)+i, m_buf[i]);
				
				// we don't need these anymore
				m_message_bits=0;
				memset(m_buf, 00, sizeof(m_buf));

				m_state = hash_function_finished;

				return (*this);
			}

			/* 
			 * get the pointer to state buffer
			 */
			const word_type* operator () () const { return m_buf; }

			/*
			 * return the digest
			 */
			const void *digest() const throw(bad_hash_state)
			{
				if(m_state == hash_function_finished)
					return m_digest; 
				else
					throw bad_hash_state("md5_ctx::digest() : digest is not computed");
			}

		private:				
			// state of the hash instance
			hash_function_state m_state;

			// current buffer
			word_type	m_buf[4];				
			uint64_t	m_message_bits; /* total _bits_ handled mod 2^64 */
			uint8_t		m_digest[16];		/* working digest */
		};

	} // namespace crypto
} // namespace boost

#endif

