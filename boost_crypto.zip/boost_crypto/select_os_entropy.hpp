#if defined(_WIN32) || defined(_MSC_VER)
#define __WIN32__
#elif defined(__linux__)
#define __UNIX__
#else
#error other platforms are not configured
#endif

#include "system_variables.hpp"

template<typename Source>
class crypto_osrandom
{
	Source source;
public:
};

#if defined(_DOS)
#include "random/dos.hpp"
#elif defined( __BEOS__ ) 
#include "random/beos.hpp"
#elif defined( __IBM4758__ ) 
#include "random/4758.hpp"
#elif defined( __MAC__ )  
#include "random/mac.hpp"
#elif defined( __MSDOS__ )  
#include "random/dos.hpp"
#elif defined( __MVS__ ) 
#include "random/mvs.hpp"
#elif defined( __OS2__ )  
#include "random/os2.hpp"
#elif defined( __PALMOS__ )  
#include "random/palmos.hpp"
#elif defined( __TANDEM_NSK__ )  
#include "random/tandem.hpp"
#elif defined( __TANDEM_OSS__ )  
#include "random/tandem.hpp"
#elif defined( __UNIX__ ) 
#include "random/unix.hpp"
#elif defined( __VMCMS__ )  
#include "random/vmcms.hpp"
#elif defined( __WIN16__ ) 
#include "random/win16.hpp"
#elif defined( __WIN32__ )  
#include "random/win32.hpp"
#elif defined( __WINCE__ ) 
#include "random/wince.hpp"
#elif defined( __XMK__ )
#include "random/xmk.hpp"
#else
#error other platforms are not implemented
#endif