eval '(exit $?0)' && eval 'exec perl -w -S $0 ${1+"$@"}'
    & eval 'exec perl -w -S $0 $argv:q'
    if 0;

# ******************************************************************
#      Author: Chad Elliott
#        Date: 2/14/2006
#         $Id: configure.pl,v 1.1 2005/12/21 12:28:51 elliott_c Exp $
# ******************************************************************

# ******************************************************************
# Pragma Section
# ******************************************************************

use strict;
use FileHandle;
use File::Basename;
use Getopt::Long;

# ************************************************************
# Data Section
# ************************************************************

my(%features) = ('bzip2'  => ['bzlib.h',  'BZIP2_ROOT'],
                 'python' => ['Python.h', 'PYTHON_INCLUDE'],
                 'zlib'   => ['zlib.h',   'ZLIB_ROOT'],
                );

my($gendesc) = "Configure boost for use with MPC.  For those familiar " .
               "with MPC, the following\ntable will help you choose the" .
               "right toolset:\n\n" .
               "MPC TYPE            BOOST TOOLSET\n" .
               "---------------------------------\n" .
               "bmake               borland\n" .
               "vc6                 msvc\n" .
               "vc7                 vc7\n" .
               "vc71                vc-7_1\n" .
               "vc8                 vc8\n" .
               "nmake (Intel/win32) intel-win32\n" .
               "make (aCC)          acc\n" .
               "     (macosx)       darwin\n" .
               "     (cygwin)       cygwin\n" .
               "     (Intel/linux)  intel-linux\n" .
               "     (mingw)        mingw\n" .
               "     (SGICC)        mipspro\n" .
               "     (cxx_tru64)    tru64cxx\n" .
               "     (xlC_r)        vacpp\n" .
               "\nMost other boost toolsets are supported";

# ************************************************************
# Subroutine Section
# ************************************************************

sub locate {
  my($dir)  = shift;
  my($file) = shift;

  if (-r "$dir/$file") {
    return $dir;
  }
  else {
    my($fh) = new FileHandle();
    if (opendir($fh, $dir)) {
      foreach my $entry (grep(!/^\.\.?$/, readdir($fh))) {
        my($full) = "$dir/$entry";
        if (-d $full) {
          my($loc) = locate($full, $file);
          return $loc if (defined $loc);
        }
      }
      closedir($fh);
    }

    return undef;
  }
}


sub search_for_python {
  my($feature) = shift;
  if (defined $features{$feature}) {
    print "Searching for $feature...";
    my(@dirs) = ();
    if ($^O eq 'MSWin32') {
      @dirs = reverse(sort(glob('c:/python*')));
    }
    else {
      @dirs = ('/usr/include', '/usr/local/include', '/opt');
    }

    foreach my $dir (@dirs) {
      my($loc) = locate($dir, $features{$feature}->[0]);
      if (defined $loc) {
        print "found.\n";
        $ENV{$features{$feature}->[1]} = $loc;
        return 1;
      }
    }
    print "not found.\n";
  }
  return undef;
  
}

sub search_for {
  my($feature) = shift;

  if ($feature eq 'python') {
    return search_for_python($feature);
  }
  elsif (defined $features{$feature}) {
    print "Searching for $feature...";
    my(@dirs) = ();
    if ($^O eq 'MSWin32') {
      @dirs = reverse(sort(glob('c:/$feature*')));
    }
    else {
      @dirs = ('/usr', '/usr/local', '/opt');;
    }
    foreach my $dir (@dirs) {
      if (-r "$dir/include/$features{$feature}->[0]") {
        print "found.\n";
        $ENV{$features{$feature}->[1]} = $dir if ($dir ne '/usr');
        return 1;
      }
    }
    print "not found.\n";
  }
  return undef;
}

sub get_default_type {
  if ($^O eq 'MSWin32') {
    $ENV{TOOLSET} = '-vc71';
    return 'vc71';
  }
  else {
    $ENV{TOOLSET} = '-gcc';
    return 'make';
  }
}

sub translate_toolset {
  my($toolset) = shift;
  my($type)    = 'make';
  my($add_opt) = '';

  if ($toolset eq 'acc') {
    $add_opt = '-value_template compilers=aCC';
    $ENV{TOOLSET} = '-acc';
  }
  elsif ($toolset eq 'borland' || $toolset eq 'bcb') {
    $type = 'bmake';
    $ENV{TOOLSET} = '-bcb';
  }
  elsif ($toolset eq 'darwin' || $toolset eq 'osx') {
    $add_opt = '-value_template platforms=macos';
    $ENV{TOOLSET} = '-osx';
  }
  elsif ($toolset eq 'dmc') {
    $add_opt = '-value_template compilers=dcm';
    $ENV{TOOLSET} = '-dmc';
  }
  elsif ($toolset eq 'cygwin') {
    $add_opt = '-value_template platforms=cygwin';
    $ENV{TOOLSET} = '-cygwin';
  }
  elsif ($toolset eq 'gcc' ||
         $toolset eq 'gcc-stlport' || $toolset eq 'gcc-nocygwin') {
    if ($^O eq 'cygwin') {
      $add_opt = '-value_template plaforms=cygwin';
    }
    elsif ($^O eq 'darwin') {
      $add_opt = '-value_template plaforms=macos';
    }
    elsif ($^O eq 'dec_osf') {
      $add_opt = '-value_template platforms=tru64';
    }
    elsif ($^O eq 'svr4') {
      $add_opt = '-value_template plaforms=unixware';
    }
    else {
      $add_opt = "-value_template platforms=$^O";
    }
    $ENV{TOOLSET} = '-gcc';
  }
  elsif ($toolset eq 'intel-linux' || $toolset eq 'il') {
    $add_opt = '-value_template compilers=Intel';
    $ENV{TOOLSET} = '-il';
  }
  elsif ($toolset eq 'intel-win32' || $toolset eq 'iw') {
    $type = 'nmake';
    $add_opt = '-value_template cc=icl.exe -value_template link=xilink.exe';
    $ENV{TOOLSET} = '-iw';
  }
  elsif ($toolset eq 'mingw' || $toolset eq 'mingw-stlport') {
    $add_opt = '-value_template platforms=mingw';
    $ENV{TOOLSET} = '-mingw';
  }
  elsif ($toolset eq 'mipspro' || $toolset eq 'mp') {
    $add_opt = '-value_template compilers=SGICC';
    $ENV{TOOLSET} = '-mp';
  }
  elsif ($toolset eq 'vc6' ||
         $toolset eq 'msvc' || $toolset eq 'msvc-stlport') {
    $type = 'vc6';
    $ENV{TOOLSET} = '-vc6';
  }
  elsif ($toolset eq 'sunpro' || $toolset eq 'sw') {
    $add_opt = '-value_template compilers=SunCC';
    $ENV{TOOLSET} = '-sw';
  }
  elsif ($toolset eq 'tru64cxx' ||
         $toolset eq 'tru64cxx65' || $toolset eq 'tru') {
    $add_opt = '-valute_template compiler=cxx_tru64';
    $ENV{TOOLSET} = '-tru';
  }
  elsif ($toolset eq 'vacpp' || $toolset eq 'xlc') {
    $add_opt = '-value_template compiler=xlC_r';
    $ENV{TOOLSET} = '-xlc';
  }
  elsif ($toolset eq 'vc7') {
    $type = 'vc7';
    $ENV{TOOLSET} = '-vc7';
  }
  elsif ($toolset eq 'vc7-stlport') {
    $type = 'vc7';
    $add_opt = '-value_template wchar_t=FALSE';
    $ENV{TOOLSET} = '-vc7';
  }
  elsif ($toolset eq 'vc-7_1') {
    $type = 'vc71';
    $ENV{TOOLSET} = '-vc71';
  }
  elsif ($toolset eq 'vc71-stlport') {
    $type = 'vc71';
    $add_opt = '-value_template wchar_t=FALSE';
    $ENV{TOOLSET} = '-vc71';
  }
  elsif ($toolset eq 'vc8') {
    $type = 'vc8';
    $ENV{TOOLSET} = '-vc8';
  }
  return $type, $add_opt;
}

sub processOptions {
  my($name)    = shift;
  my($options) = shift;
  my($desc)    = shift;
  my($general) = shift;

  if (defined $options) {
    my($result)  = GetOptions(%$options);
    my($usage)   = undef;

    ## Find the help option
    foreach my $key (keys %$options) {
      if ($key eq 'help') {
        $usage = $$options{$key};
        last;
      }
    }  

    ## Check for usage
    if ((defined $usage && defined $$usage) || !$result) {
      usageAndExit($name, $options, $desc, $general);
    }
  }  
}    

sub usageAndExit {
  my($name)    = shift;
  my($options) = shift;
  my($desc)    = shift;
  my($general) = shift;
  my($str)     = 'Usage: ' . basename($name);
  my($initial) = length($str);
  my($length)  = $initial;
  my($maxLine) = 78;

  print $str;

  foreach my $key (sort keys %$options) {
    my($opt, $type) = split(/=/, $key);
    my($arg) = uc($opt);
    $arg =~ s/^with\-//i;
    my($str) = " [--$opt" . (defined $type ? " <$arg>" : '') . ']';
    my($len) = length($str);
    if ($length + $len > $maxLine) {
      print "\n" . (' ' x $initial);
      $length = $initial;
    }
    print $str;
    $length += $len;
  }
  print "\n";

  if (defined $desc) {
    my($max) = 0;
    foreach my $key (sort keys %$desc) {
      my($len) = length($key);
      if ($len > $max) {
        $max = $len;
      }
    }  
    if ($max > 0) {
      print "\n";  
    }

    foreach my $key (sort keys %$desc) {
      my($len) = length($key);
     my($str) = "       $key" . ($len < $max ? ' ' x ($max - $len) : '') .
                 '  ';
      $length = length($str);

      print $str;

      $length++;
      if (length($$desc{$key}) + $length > $maxLine) {
        my($part) = $$desc{$key};
        while(length($part) + $length > $maxLine) {
          my(@words) = split(/\s+/, $part);
          $part = '';
          foreach my $word (@words) {
            if (length($word) + length($part) + $length > $maxLine) {
              my($space) = '         ' . (' ' x $max);
              $part =~ s/\s+$//;
              print "$part\n$space";
              $part = '';
              $length = length($space) + 1;
            }
            $part .= "$word ";
          }
        }  
        $part =~ s/\s+$//;
        print "$part.\n"; 
      }
      else {
        print "$$desc{$key}.\n";
      }
    }  
  }    

  if (defined $general) {
    print "\n$general.\n";
  }
   
  exit(0);
}

# ************************************************************
# Main Section
# ************************************************************

my($type)        = undef;
my($usage)       = undef;
my($add_mpc_opt) = '';

my(%options) = ('with-pyton-root=s' => \$ENV{$features{'python'}->[1]},
                'with-bzip2-root=s' => \$ENV{$features{'bzip2'}->[1]},
                'with-zlib-root=s'  => \$ENV{$features{'zlib'}->[1]},
                'with-toolset=s'    => \$type,
                'help'              => \$usage,
               );

my(%desc)    = ('with-pyton-root' => 'specify the root of the Python ' .
                                     'installation [automatically ' .
                                     'detected]',
                'with-bzip2-root' => 'specify the root of the Bzip2 ' .
                                     'installation [automatically ' .
                                     'detected]',
                'with-zlib-root'  => 'specify the root of the Zlib ' .
                                     'installation [automatically ' .
                                     'detected]',
                'with-toolset'    => 'use specific Boost.Build toolset ' .
                                     '[automatically detected]',
               );

processOptions($0, \%options, \%desc, $gendesc);

if (defined $type) {
  ($type, $add_mpc_opt) = translate_toolset($type);
}
else {
  $type = get_default_type();
}

$| = 1;

if (!defined $ENV{MPC_ROOT} || !-r "$ENV{MPC_ROOT}/mwc.pl") {
  print "This script is used to configure boost for use with MPC.\n",
        "You can download MPC from www.ociweb.com or you can check it\n",
        "out from :pserver:anonymous\@anoncvs.ociweb.com:/cvs using CVS.\n";
  exit(1);
}

my($mpc_features) = '';

foreach my $feature (keys %features) {
  if (defined $ENV{$features{$feature}->[1]} || search_for($feature)) {
    if ($mpc_features eq '') {
      $mpc_features .= '-features ';
    }
    else {
      $mpc_features .= ',';
    }
    $mpc_features .= "$feature=1";
  }
}

print "Running MPC...\n";
system("$^X $ENV{MPC_ROOT}/mwc.pl -type $type " .
       "$mpc_features $add_mpc_opt boost.mwc");

