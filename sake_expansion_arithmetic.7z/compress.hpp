/*******************************************************************************
 * expansion_arithmetic/compress.hpp
 *
 * Copyright 2009, Jeffrey Hellrung.
 * Distributed under the Boost Software License, Version 1.0.  (See accompanying
 * file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
 *
 * expansion_arithmetic::compress(
 *     const BidirectionalReadableRange& e,
 *     BidirectionalReadableWritableRange& h)
 *     -> boost::range_iterator< BidirectionalReadableWritableRange >::type
 * expansion_arithmetic::compress(BidirectionalReadableWritableRange& e)
 *     -> boost::range_iterator< BidirectionalReadableWritableRange >::type
 *
 * compress compresses the expansion in e, putting the result in h.
 * The result expansion will be nonadjacent.
 * h must have at least distance(e) valid elements.
 * h may be identical to e.
 * In the second variant, h is identical to e.
 ******************************************************************************/

#ifndef _SAKE_EXPANSION_ARITHMETIC_COMPRESS_HPP_
#define _SAKE_EXPANSION_ARITHMETIC_COMPRESS_HPP_

#include <cassert>

#include <boost/concept/assert.hpp>
#include <boost/mpl/assert.hpp>
#include <boost/range/distance.hpp>
#include <boost/range/iterator.hpp>
#include <boost/range/value_type.hpp>
#include <boost/type_traits/is_same.hpp>

#include <sake/core/range/concepts.hpp>
#include <sake/expansion_arithmetic/approximate.hpp>

namespace sake
{

namespace expansion_arithmetic
{

template< class BidirectionalReadableRange, class BidirectionalReadableWritableRange >
inline typename boost::range_iterator< BidirectionalReadableWritableRange >::type
compress(const BidirectionalReadableRange& e, BidirectionalReadableWritableRange& h)
{
    BOOST_CONCEPT_ASSERT((concepts::BidirectionalReadableRange< const BidirectionalReadableRange >));
    BOOST_CONCEPT_ASSERT((concepts::BidirectionalReadableWritableRange< BidirectionalReadableWritableRange >));
    typedef typename boost::range_value< BidirectionalReadableRange >::type e_value_type;
    typedef typename boost::range_value< BidirectionalReadableWritableRange >::type h_value_type;
    BOOST_MPL_ASSERT((boost::is_same< e_value_type, h_value_type >));
    typedef typename boost::range_iterator< BidirectionalReadableWritableRange >::type h_it_type;
    typedef h_value_type T;
    assert(boost::distance(e) <= boost::distance(h));
    T error;
#ifdef NDEBUG
    return approximate(e, h, error);
#else
    h_it_type h_end = approximate(e, h, error);
    assert(error == 0);
    return h_end;
#endif
}

template< class BidirectionalReadableWritableRange >
inline typename boost::range_iterator< BidirectionalReadableWritableRange >::type
compress(BidirectionalReadableWritableRange& e)
{
    BOOST_CONCEPT_ASSERT((concepts::BidirectionalReadableWritableRange< BidirectionalReadableWritableRange >));
    return compress(e,e);
}

} // expansion_arithmetic

} // namespace sake

#endif // #ifndef _SAKE_EXPANSION_ARITHMETIC_COMPRESS_HPP_
