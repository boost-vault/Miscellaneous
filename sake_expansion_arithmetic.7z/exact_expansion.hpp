/*******************************************************************************
 * expansion_arithmetic/exact_expansion.hpp
 *
 * Copyright 2009, Jeffrey Hellrung.
 * Distributed under the Boost Software License, Version 1.0.  (See accompanying
 * file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
 *
 * class exact_expansion< T, Allocator >
 *
 * An exact_expansion represents an arithmetic expansion of an arbitrary number
 * of components.
 *
 * TODO: When boost::container::vector::const_iterator does not have a
 * const-qualified value_type, switch it back in...
 ******************************************************************************/

#ifndef _SAKE_EXPANSION_ARITHMETIC_EXACT_EXPANSION_HPP_
#define _SAKE_EXPANSION_ARITHMETIC_EXACT_EXPANSION_HPP_

#include <limits>

#include <boost/concept/assert.hpp>
#include <boost/preprocessor/facilities/identity.hpp>
#include <boost/static_assert.hpp>
#include <boost/type_traits/is_convertible.hpp>
#include <boost/type_traits/is_same.hpp>
#include <boost/utility/enable_if.hpp>

// Make sure to add $(BOOST_SVN)/boost-sandbox/move to your include path.
//#include <boost-sandbox/move/boost/container/vector.hpp>
#include <vector>

#include <sake/boost_ext/move/movable.hpp>
#include <sake/boost_ext/move/move_fwd.hpp>
#include <sake/core/math/sign.hpp>
#include <sake/core/math/sign_t.hpp>
#include <sake/core/math/zero.hpp>
#include <sake/core/memory/new_delete_allocator.hpp>
#include <sake/core/memory/SakeAllocator.hpp>
#include <sake/core/range/singleton_range.hpp>
#include <sake/core/utility/call_traits.hpp>
#include <sake/expansion_arithmetic/compare.hpp>
#include <sake/expansion_arithmetic/compress.hpp>
#include <sake/expansion_arithmetic/equals.hpp>
#include <sake/expansion_arithmetic/expansion_fwd.hpp>

namespace sake
{

/*******************************************************************************
 * class exact_expansion< T, Allocator >
 ******************************************************************************/

template< class T, class Allocator /* = new_delete_allocator<> */ >
class exact_expansion
{
    BOOST_STATIC_ASSERT((std::numeric_limits<T>::is_iec559));
    BOOST_CONCEPT_ASSERT((concepts::SakeAllocator< Allocator >));
    typedef typename Allocator::template rebind<T>::other stl_allocator_type;
    //typedef boost::container::vector< T, stl_allocator_type > expansion_container_type;
    typedef std::vector< T, stl_allocator_type > expansion_container_type;
public:
    typedef T component_type;
    typedef typename expansion_container_type::size_type size_type;
    // typedef's to allow boost::range read access to the components.
    typedef typename expansion_container_type::value_type value_type;
    typedef typename expansion_container_type::const_iterator const_iterator;
    typedef typename expansion_container_type::const_pointer const_pointer;
    typedef typename expansion_container_type::const_reference const_reference;
    typedef typename expansion_container_type::difference_type difference_type;
    typedef const_iterator iterator;
    typedef const_reference reference;
    typedef const_pointer pointer;

    typedef Allocator allocator_type;
    //typedef typename expansion_container_type::stored_allocator_type stored_allocator_type;
    typedef allocator_type stored_allocator_type;

private:
    typedef typename call_traits< component_type >::param_type component_param_type;
    typedef typename call_traits< size_type >::param_type size_param_type;

    SAKE_BOOST_EXT_MOVABLE_COPYABLE_DEFINE_COPY_ASSIGN_FROM_SWAP( exact_expansion )
public:

    exact_expansion();
    //exact_expansion(const exact_expansion& other);
    exact_expansion(this_rvalue_param_type other);

    explicit exact_expansion(const allocator_type& alloc);
    explicit exact_expansion(component_param_type x, const allocator_type& alloc = allocator_type());
    template< class BidirectionalReadableExpansion >
    explicit exact_expansion(
        const BidirectionalReadableExpansion& source,
        typename boost::disable_if< boost::is_convertible< BidirectionalReadableExpansion, allocator_type > >::type* = 0,
        typename boost::disable_if< boost::is_convertible< BidirectionalReadableExpansion, component_type > >::type* = 0);
    template< class BidirectionalReadableExpansion >
    exact_expansion(
        const BidirectionalReadableExpansion& source,
        const allocator_type& alloc,
        typename boost::disable_if< boost::is_convertible< BidirectionalReadableExpansion, component_type > >::type* = 0);
    //~exact_expansion();

    //exact_expansion& operator=(const exact_expansion& other);
    exact_expansion& operator=(this_rvalue_param_type other);
    exact_expansion& operator=(component_param_type x);
    template< class BidirectionalReadableExpansion >
    void assign(const BidirectionalReadableExpansion& source);
    void swap(exact_expansion& other);

    const_iterator begin() const;
    const_iterator end() const;
    const_iterator cbegin() const;
    const_iterator cend() const;

    size_type size() const;
    size_type max_size() const;
    bool empty() const;

    sign_t sign() const;
    void compress() const;
    void clear();

#define SAKE_EXACT_EXPANSION_DECLARE_OP_ASSIGN( Op, Name ) \
    void assign_##Name(const exact_expansion& left, const exact_expansion& right); \
    void assign_##Name(const exact_expansion& left, component_param_type right); \
    void assign_##Name(component_param_type left, const exact_expansion& right); \
    void assign_##Name(component_param_type left, component_param_type right); \
    exact_expansion& operator Op##=(const exact_expansion& x); \
    exact_expansion& operator Op##=(component_param_type x);
    SAKE_EXACT_EXPANSION_DECLARE_OP_ASSIGN( +, add  )
    SAKE_EXACT_EXPANSION_DECLARE_OP_ASSIGN( -, sub  )
    SAKE_EXACT_EXPANSION_DECLARE_OP_ASSIGN( *, mult )
#undef SAKE_EXACT_EXPANSION_DECLARE_OP_ASSIGN

    void assign_negate(const exact_expansion& x);
    void assign_negate(component_param_type x);
    void assign_abs(const exact_expansion& x);
    void assign_abs(component_param_type x);

    exact_expansion& negate_ip();
    exact_expansion& abs_ip();

    exact_expansion negate_copy() const;
    exact_expansion abs_copy() const;
    exact_expansion operator-() const;

    bool equals(const exact_expansion& other) const;
    bool equals(component_param_type x) const;
    sign_t compare(const exact_expansion& other) const; 
    sign_t compare(component_param_type x) const;

    //const stored_allocator_type& get_stored_allocator() const;
    stored_allocator_type get_stored_allocator() const;
    allocator_type get_allocator() const;

    const_reference operator[](size_param_type i) const;

private:
    // mutable to allow compress be const
    mutable expansion_container_type m_expansion;
};

/*******************************************************************************
 * exact_expansion free arithmetic operators
 ******************************************************************************/

#define SAKE_EXACT_EXPANSION_DEFINE_BIN_OP( Op, Name ) \
template< class T, class Allocator > \
inline exact_expansion< T, Allocator > \
operator Op (const exact_expansion< T, Allocator >& left, const exact_expansion< T, Allocator >& right) \
{ \
    assert(left.get_stored_allocator() == right.get_stored_allocator()); \
    exact_expansion< T, Allocator > temp(left.get_stored_allocator()); \
    temp.assign_##Name(left, right); \
    return temp; \
} \
template< class T, class Allocator > \
inline exact_expansion< T, Allocator > \
operator Op (const exact_expansion< T, Allocator >& left, const T& right) \
{ \
    exact_expansion< T, Allocator > temp(left.get_stored_allocator()); \
    temp.assign_##Name(left, right); \
    return temp; \
} \
template< class T, class Allocator > \
inline exact_expansion< T, Allocator > \
operator Op (const T& left, const exact_expansion< T, Allocator >& right) \
{ \
    exact_expansion< T, Allocator > temp(right.get_stored_allocator()); \
    temp.assign_##Name(left, right); \
    return temp; \
}
SAKE_EXACT_EXPANSION_DEFINE_BIN_OP( +, add  )
SAKE_EXACT_EXPANSION_DEFINE_BIN_OP( -, sub  )
SAKE_EXACT_EXPANSION_DEFINE_BIN_OP( *, mult )
#undef SAKE_EXACT_EXPANSION_DEFINE_BIN_OP

/*******************************************************************************
 * exact_expansion free comparison operators
 ******************************************************************************/

template< class T, class Allocator >
inline bool operator==(const exact_expansion< T, Allocator >& left, const exact_expansion< T, Allocator >& right)
{ return left.equals(right); }
template< class T, class Allocator >
inline bool operator==(const exact_expansion< T, Allocator >& left, const T& right)
{ return left.equals(right); }
template< class T, class Allocator >
inline bool operator==(const T& left, const exact_expansion< T, Allocator >& right)
{ return right.equals(left); }
template< class T, class Allocator >
inline bool operator==(const exact_expansion< T, Allocator >& left, zero_t)
{ return left.empty(); }
template< class T, class Allocator >
inline bool operator==(zero_t, const exact_expansion< T, Allocator >& right)
{ return right.empty(); }

template< class T, class Allocator >
inline bool operator!=(const exact_expansion< T, Allocator >& left, const exact_expansion< T, Allocator >& right)
{ return !(left == right); }
template< class T, class Allocator >
inline bool operator!=(const exact_expansion< T, Allocator >& left, const T& right)
{ return !(left == right); }
template< class T, class Allocator >
inline bool operator!=(const T& left, const exact_expansion< T, Allocator >& right)
{ return !(left == right); }
template< class T, class Allocator >
inline bool operator!=(const exact_expansion< T, Allocator >& left, zero_t)
{ return !(left == zero); }
template< class T, class Allocator >
inline bool operator!=(zero_t, const exact_expansion< T, Allocator >& right)
{ return !(zero == right); }

#define SAKE_EXACT_EXPANSION_DEFINE_COMPARISON_OP( Op ) \
template< class T, class Allocator > \
inline bool operator Op (const exact_expansion< T, Allocator >& left, const exact_expansion< T, Allocator >& right) \
{ return left.compare(right) Op zero; } \
template< class T, class Allocator > \
inline bool operator Op (const exact_expansion< T, Allocator >& left, const T& right) \
{ return left.compare(right) Op zero; } \
template< class T, class Allocator > \
inline bool operator Op (const T& left, const exact_expansion< T, Allocator >& right) \
{ return zero Op right.compare(left); } \
template< class T, class Allocator > \
inline bool operator Op (const exact_expansion< T, Allocator >& left, zero_t) \
{ return left.sign() Op zero; } \
template< class T, class Allocator > \
inline bool operator Op (zero_t, const exact_expansion< T, Allocator >& right) \
{ return zero Op right.sign(); }
SAKE_EXACT_EXPANSION_DEFINE_COMPARISON_OP( <  )
SAKE_EXACT_EXPANSION_DEFINE_COMPARISON_OP( >  )
SAKE_EXACT_EXPANSION_DEFINE_COMPARISON_OP( <= )
SAKE_EXACT_EXPANSION_DEFINE_COMPARISON_OP( >= )
#undef SAKE_EXACT_EXPANSION_DEFINE_COMPARISON_OP

/*******************************************************************************
 * exact_expansion free functions
 ******************************************************************************/

template< class T, class Allocator >
inline void
swap(exact_expansion< T, Allocator >& x0, exact_expansion< T, Allocator >& x1)
{ x0.swap(x1); }

/*******************************************************************************
 * exact_expansion inline and template member functions
 ******************************************************************************/

template< class T, class Allocator >
exact_expansion< T, Allocator >::
exact_expansion()
{ }

template< class T, class Allocator >
exact_expansion< T, Allocator >::
exact_expansion(this_rvalue_param_type other)
//    : m_expansion(boost::move(other.m_expansion))
//{ }
    : m_expansion(other.get_stored_allocator())
{ swap(other); }

template< class T, class Allocator >
exact_expansion< T, Allocator >::
exact_expansion(const allocator_type& alloc)
    : m_expansion(alloc)
{ }

template< class T, class Allocator >
exact_expansion< T, Allocator >::
exact_expansion(component_param_type x, const allocator_type& alloc)
    : m_expansion(1, x, alloc)
{ }

template< class T, class Allocator >
template< class BidirectionalReadableExpansion >
exact_expansion< T, Allocator >::
exact_expansion(
    const BidirectionalReadableExpansion& source,
    typename boost::disable_if< boost::is_convertible< BidirectionalReadableExpansion, allocator_type > >::type*,
    typename boost::disable_if< boost::is_convertible< BidirectionalReadableExpansion, component_type > >::type*)
{ assign(source); }

template< class T, class Allocator >
template< class BidirectionalReadableExpansion >
exact_expansion< T, Allocator >::
exact_expansion(
    const BidirectionalReadableExpansion& source,
    const allocator_type& alloc,
    typename boost::disable_if< boost::is_convertible< BidirectionalReadableExpansion, component_type > >::type*)
    : m_expansion(alloc)
{ assign(source); }

template< class T, class Allocator >
inline exact_expansion< T, Allocator >&
exact_expansion< T, Allocator >::
operator=(this_rvalue_param_type other)
{
    //m_expansion = boost::move(other.m_expansion);
    assert(this != &static_cast< exact_expansion& >(other) || empty());
    clear();
    swap(other);
    return *this;
}

template< class T, class Allocator >
inline exact_expansion< T, Allocator >&
exact_expansion< T, Allocator >::
operator=(component_param_type x)
{ return operator=(exact_expansion(x, get_stored_allocator())); }

template< class T, class Allocator >
template< class BidirectionalReadableExpansion >
void
exact_expansion< T, Allocator >::
assign(const BidirectionalReadableExpansion& source)
{
    BOOST_CONCEPT_ASSERT((concepts::BidirectionalReadableRange< const BidirectionalReadableExpansion >));
    BOOST_MPL_ASSERT((boost::is_same< typename boost::range_value< BidirectionalReadableExpansion >::type, component_type >));
    m_expansion.resize(boost::distance(source));
    typename expansion_container_type::iterator e_it = expansion_arithmetic::compress(source, m_expansion);
    m_expansion.erase(e_it, m_expansion.end());
}

template< class T, class Allocator >
inline void
exact_expansion< T, Allocator >::
swap(exact_expansion& other)
{
    assert(get_allocator() == other.get_allocator());
    m_expansion.swap(other.m_expansion);
}

template< class T, class Allocator >
inline typename exact_expansion< T, Allocator >::const_iterator
exact_expansion< T, Allocator >::
begin() const
{ return m_expansion.begin(); }

template< class T, class Allocator >
inline typename exact_expansion< T, Allocator >::const_iterator
exact_expansion< T, Allocator >::
end() const
{ return m_expansion.end(); }

template< class T, class Allocator >
inline typename exact_expansion< T, Allocator >::const_iterator
exact_expansion< T, Allocator >::
cbegin() const
{ return begin(); }

template< class T, class Allocator >
inline typename exact_expansion< T, Allocator >::const_iterator
exact_expansion< T, Allocator >::
cend() const
{ return end(); }

template< class T, class Allocator >
inline typename exact_expansion< T, Allocator >::size_type
exact_expansion< T, Allocator >::
size() const
{ return m_expansion.size(); }

template< class T, class Allocator >
inline typename exact_expansion< T, Allocator >::size_type
exact_expansion< T, Allocator >::
max_size() const
{ return m_expansion.max_size(); }

template< class T, class Allocator >
inline bool
exact_expansion< T, Allocator >::
empty() const
{ return m_expansion.empty(); }

template< class T, class Allocator >
inline sign_t
exact_expansion< T, Allocator >::
sign() const
{ return empty() ? zero : adl::sign(m_expansion.back()); }

template< class T, class Allocator >
inline void
exact_expansion< T, Allocator >::
compress() const
{
    typedef typename expansion_container_type::iterator e_it_type;
    e_it_type e_it = expansion_arithmetic::compress(m_expansion);
    assert(e_it <= m_expansion.end());
    m_expansion.erase(e_it, m_expansion.end());
}

template< class T, class Allocator >
inline void
exact_expansion< T, Allocator >::
clear()
{ m_expansion.clear(); }

#define SAKE_EXACT_EXPANSION_DEFINE_OP_ASSIGN( Op, Name ) \
template< class T, class Allocator > \
inline exact_expansion< T, Allocator >& \
exact_expansion< T, Allocator >:: \
operator Op##=(const exact_expansion& x) \
{ \
    assign_##Name(*this, x); \
    return *this; \
}
SAKE_EXACT_EXPANSION_DEFINE_OP_ASSIGN( +, add  )
SAKE_EXACT_EXPANSION_DEFINE_OP_ASSIGN( -, sub  )
SAKE_EXACT_EXPANSION_DEFINE_OP_ASSIGN( *, mult )
#undef SAKE_EXACT_EXPANSION_DEFINE_OP_ASSIGN

template< class T, class Allocator >
inline void
exact_expansion< T, Allocator >::
assign_add(component_param_type left, const exact_expansion& right)
{ return assign_add(right, left); }

template< class T, class Allocator >
inline void
exact_expansion< T, Allocator >::
assign_sub(const exact_expansion& left, component_param_type right)
{ return assign_add(left, -right); }

template< class T, class Allocator >
inline void
exact_expansion< T, Allocator >::
assign_mult(component_param_type left, const exact_expansion& right)
{ return assign_mult(right, left); }

template< class T, class Allocator >
inline exact_expansion< T, Allocator >&
exact_expansion< T, Allocator >::
operator-=(component_param_type x)
{ return operator+=(-x); }

template< class T, class Allocator >
inline exact_expansion< T, Allocator >&
exact_expansion< T, Allocator >::
operator*=(component_param_type x)
{
    assign_mult(*this, x);
    return *this;
}

template< class T, class Allocator >
inline void
exact_expansion< T, Allocator >::
assign_abs(const exact_expansion& x)
{
    if(x >= zero)
        operator=(x);
    else
        assign_negate(x);
}

template< class T, class Allocator >
inline void
exact_expansion< T, Allocator >::
assign_negate(component_param_type x)
{ operator=(-x); }

template< class T, class Allocator >
inline void
exact_expansion< T, Allocator >::
assign_abs(component_param_type x)
{ operator=(adl::abs_copy(x)); }

template< class T, class Allocator >
inline exact_expansion< T, Allocator >&
exact_expansion< T, Allocator >::
negate_ip()
{
    assign_negate(*this);
    return *this;
}

template< class T, class Allocator >
inline exact_expansion< T, Allocator >&
exact_expansion< T, Allocator >::
abs_ip()
{
    assign_abs(*this);
    return *this;
}

template< class T, class Allocator >
inline exact_expansion< T, Allocator >
exact_expansion< T, Allocator >::
negate_copy() const
{
    exact_expansion temp(get_stored_allocator());
    temp.assign_negate(*this);
    return temp;
}

template< class T, class Allocator >
inline exact_expansion< T, Allocator >
exact_expansion< T, Allocator >::
abs_copy() const
{
    exact_expansion temp(get_stored_allocator());
    temp.assign_abs(*this);
    return temp;
}

template< class T, class Allocator >
inline exact_expansion< T, Allocator >
exact_expansion< T, Allocator >::
operator-() const
{ return negate_copy(); }

template< class T, class Allocator >
inline bool
exact_expansion< T, Allocator >::
equals(const exact_expansion< T, Allocator >& other) const
{ return expansion_arithmetic::equals(*this, other); }

template< class T, class Allocator >
inline bool
exact_expansion< T, Allocator >::
equals(component_param_type x) const
{ return expansion_arithmetic::equals(*this, make_singleton_range(x)); }

template< class T, class Allocator >
inline sign_t
exact_expansion< T, Allocator >::
compare(const exact_expansion< T, Allocator >& other) const
{ return expansion_arithmetic::compare(*this, other); }

template< class T, class Allocator >
inline sign_t
exact_expansion< T, Allocator >::
compare(component_param_type x) const
{ return expansion_arithmetic::compare(*this, make_singleton_range(x)); }

template< class T, class Allocator >
//inline const typename exact_expansion< T, Allocator >::stored_allocator_type&
inline typename exact_expansion< T, Allocator >::stored_allocator_type
exact_expansion< T, Allocator >::
get_stored_allocator() const
{
    //return m_expansion.get_stored_allocator();
    return m_expansion.get_allocator();
}

template< class T, class Allocator >
inline typename exact_expansion< T, Allocator >::allocator_type
exact_expansion< T, Allocator >::
get_allocator() const
{ return m_expansion.get_allocator(); }

template< class T, class Allocator >
inline typename exact_expansion< T, Allocator >::const_reference
exact_expansion< T, Allocator >::
operator[](size_param_type i) const
{ return m_expansion[i]; }

} // namespace sake

#endif // #ifndef _SAKE_EXPANSION_ARITHMETIC_EXACT_EXPANSION_HPP_
