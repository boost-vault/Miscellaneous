/*******************************************************************************
 * expansion_arithmetic/compare.hpp
 *
 * Copyright 2009, Jeffrey Hellrung.
 * Distributed under the Boost Software License, Version 1.0.  (See accompanying
 * file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
 *
 * expansion_arithmetic::compare(
 *     const BidirectionalReadableRange1& e,
 *     const BidirectionalReadableRange2& f)
 *     -> sign_t
 *
 * compare compares two expansions.
 ******************************************************************************/

#ifndef _SAKE_EXPANSION_ARITHMETIC_COMPARE_HPP_
#define _SAKE_EXPANSION_ARITHMETIC_COMPARE_HPP_

#include <stdexcept>

#include <boost/concept/assert.hpp>
#include <boost/math/special_functions/next.hpp>
#include <boost/mpl/assert.hpp>
#include <boost/range/begin.hpp>
#include <boost/range/end.hpp>
#include <boost/range/iterator.hpp>
#include <boost/range/value_type.hpp>
#include <boost/type_traits/is_same.hpp>

#include <sake/core/math/sign.hpp>
#include <sake/core/math/sign_t.hpp>
#include <sake/core/range/concepts.hpp>
#include <sake/expansion_arithmetic/two_sum.hpp>

namespace sake
{

namespace expansion_arithmetic
{

template< class BidirectionalReadableRange1, class BidirectionalReadableRange2 >
sign_t compare(const BidirectionalReadableRange1& e, const BidirectionalReadableRange2& f)
{
    BOOST_CONCEPT_ASSERT((concepts::BidirectionalReadableRange< const BidirectionalReadableRange1 >));
    BOOST_CONCEPT_ASSERT((concepts::BidirectionalReadableRange< const BidirectionalReadableRange2 >));
    typedef typename boost::range_value< BidirectionalReadableRange1 >::type e_value_type;
    typedef typename boost::range_value< BidirectionalReadableRange2 >::type f_value_type;
    BOOST_MPL_ASSERT((boost::is_same< e_value_type, f_value_type >));
    typedef typename boost::range_iterator< const BidirectionalReadableRange1 >::type e_it_type;
    typedef typename boost::range_iterator< const BidirectionalReadableRange2 >::type f_it_type;
    typedef e_value_type T;
    e_it_type e_begin = boost::begin(e), e_it = boost::end(e);
    f_it_type f_begin = boost::begin(f), f_it = boost::end(f);
    T e_x = 0, e_x_lo = 0, f_x = 0, f_x_lo = 0;
    T e_x_new, f_x_new;
    for(;;) {
        while(e_it != e_begin && e_x_lo == 0) {
            fast_two_sum(e_x, *(--e_it), e_x_new, e_x_lo);
            e_x = e_x_new;
        }
        while(f_it != f_begin && f_x_lo == 0) {
            fast_two_sum(f_x, *(--f_it), f_x_new, f_x_lo);
            f_x = f_x_new;
        }
        if(f_x == 0)
            return adl::sign(e_x);
        if(e_x == 0)
            return -adl::sign(f_x);
        if(e_x > 0) {
            if(f_x < 0 || boost::math::float_prior(e_x) > f_x)
                return sign_t(sign_t::positive_value);
            if(e_x < boost::math::float_prior(f_x))
                return sign_t(sign_t::negative_value);
        }
        else {
            if(f_x > 0 || boost::math::float_next(e_x) < f_x)
                return sign_t(sign_t::negative_value);
            if(e_x > boost::math::float_next(f_x))
                return sign_t(sign_t::positive_value);
        }
        assert((e_x - f_x) + f_x == e_x && e_x - (e_x - f_x) == f_x);
        e_x -= f_x;
        two_sum(e_x, e_x_lo, e_x_new, e_x_lo);
        e_x = e_x_new;
        f_x = f_x_lo;
        f_x_lo = 0;
    }
    throw std::runtime_error("sake::expansion_arithmetic::compare(...) : internal error");
}

} // expansion_arithmetic

} // namespace sake

#endif // #ifndef _SAKE_EXPANSION_ARITHMETIC_COMPARE_HPP_
