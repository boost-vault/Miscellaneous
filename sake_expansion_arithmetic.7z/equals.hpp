/*******************************************************************************
 * expansion_arithmetic/equals.hpp
 *
 * Copyright 2009, Jeffrey Hellrung.
 * Distributed under the Boost Software License, Version 1.0.  (See accompanying
 * file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
 *
 * expansion_arithmetic::equals(
 *     const SinglePassReadableRange1& e,
 *     const SinglePassReadableRange2& f)
 *     -> bool
 *
 * equals tests whether two expansions are equal.
 * This is basically just a fast_expansion_diff that returns early once a
 * non-zero component of the difference is found.
 ******************************************************************************/

#ifndef _SAKE_EXPANSION_ARITHMETIC_EQUALS_HPP_
#define _SAKE_EXPANSION_ARITHMETIC_EQUALS_HPP_

#include <boost/concept/assert.hpp>
#include <boost/mpl/assert.hpp>
#include <boost/range/begin.hpp>
#include <boost/range/end.hpp>
#include <boost/range/iterator.hpp>
#include <boost/range/value_type.hpp>
#include <boost/type_traits/is_same.hpp>

#include <sake/core/functional/equal_to_zero.hpp>
#include <sake/core/range/algorithm/satisfies_all.hpp>
#include <sake/core/range/concepts.hpp>
#include <sake/expansion_arithmetic/strongly_nonoverlapping_expansion.hpp>
#include <sake/expansion_arithmetic/two_diff.hpp>
#include <sake/expansion_arithmetic/two_sum.hpp>

namespace sake
{

namespace expansion_arithmetic
{

template< class SinglePassReadableRange1, class SinglePassReadableRange2 >
bool equals(const SinglePassReadableRange1& e, const SinglePassReadableRange2& f)
{
    BOOST_CONCEPT_ASSERT((concepts::SinglePassReadableRange< const SinglePassReadableRange1 >));
    BOOST_CONCEPT_ASSERT((concepts::SinglePassReadableRange< const SinglePassReadableRange2 >));
    typedef typename boost::range_value< SinglePassReadableRange1 >::type e_value_type;
    typedef typename boost::range_value< SinglePassReadableRange2 >::type f_value_type;
    BOOST_MPL_ASSERT((boost::is_same< e_value_type, f_value_type >));
    typedef typename boost::range_iterator< const SinglePassReadableRange1 >::type e_it_type;
    typedef typename boost::range_iterator< const SinglePassReadableRange2 >::type f_it_type;
    typedef e_value_type T;
    assert(strongly_nonoverlapping_expansion(e));
    assert(strongly_nonoverlapping_expansion(f));
    e_it_type e_it = boost::begin(e), e_end = boost::end(e);
    if(e_it == e_end)
        return range::satisfies_all(f, sake::functional::equal_to_zero< f_value_type >());
    f_it_type f_it = boost::begin(f), f_end = boost::end(f);
    if(f_it == f_end)
        return range::satisfies_all(e, sake::functional::equal_to_zero< e_value_type >());
    T e_x = *e_it, f_x = *f_it, q, q_new, z;
    if((e_x < f_x) == (e_x > -f_x)) {
        q = e_x;
        ++e_it;
    }
    else {
        q = -f_x;
        ++f_it;
    }
    if(e_it != e_end && f_it != f_end) {
        // start with using fast_two_diff, then continue with two_diff
        e_x = *e_it;
        f_x = *f_it;
        if((e_x < f_x) == (e_x > -f_x)) {
            fast_two_sum(e_x, q, q_new, z);
            ++e_it;
        }
        else {
            fast_two_diff_neg(f_x, q, q_new, z);
            ++f_it;
        }
        if(z != 0)
            return false;
        q = q_new;
        while(e_it != e_end && f_it != f_end) {
            e_x = *e_it;
            f_x = *f_it;
            if((e_x < f_x) == (e_x > -f_x)) {
                two_sum(q, e_x, q_new, z);
                ++e_it;
            }
            else {
                two_diff(q, f_x, q_new, z);
                ++f_it;
            }
            if(z != 0)
                return false;
            q = q_new;
        }
    }
    for(; e_it != e_end; ++e_it) {
        two_sum(q, *e_it, q_new, z);
        if(z != 0)
            return false;
        q = q_new;
    }
    for(; f_it != f_end; ++f_it) {
        two_diff(q, *f_it, q_new, z);
        if(z != 0)
            return false;
        q = q_new;
    }
    assert(z == 0);
    return q == 0;
}

} // expansion_arithmetic

} // namespace sake

#endif // #ifndef _SAKE_EXPANSION_ARITHMETIC_EQUALS_HPP_
