/*******************************************************************************
 * expansion_arithmetic/float_convert.hpp
 *
 * Copyright 2009, Jeffrey Hellrung.
 * Distributed under the Boost Software License, Version 1.0.  (See accompanying
 * file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
 *
 * expansion_arithmetic::float_convert< To >(const From& x)
 *     -> expansion_arithmetic::result_of::float_convert< From, To >::type
 * struct expansion_arithmetic::is_float_convertible< From, To >
 *
 * float_convert converts one floating point type into an expansion of
 * components of another floating point type.  This is intended to be overloaded
 * for user-defined types.
 ******************************************************************************/

#ifndef _SAKE_MATH_FLOAT_CONVERT_HPP_
#define _SAKE_MATH_FLOAT_CONVERT_HPP_

#include <cassert>

#include <limits>
#include <stdexcept>

#include <boost/mpl/assert.hpp>
#include <boost/mpl/not.hpp>
#include <boost/type_traits/is_convertible.hpp>
#include <boost/type_traits/is_same.hpp>
#include <boost/type_traits/is_void.hpp>
#include <boost/utility/enable_if.hpp>

#include <sake/boost_ext/array.hpp>
#include <sake/core/math/abs.hpp>
#include <sake/core/math/float_ulp.hpp>
#include <sake/expansion_arithmetic/two_product.hpp>

namespace sake
{

namespace expansion_arithmetic
{

namespace result_of
{

template< class From, class To, class Enable = void >
struct float_convert
{ typedef void type; };

template< class From, class To >
struct float_convert< From, To, typename boost::enable_if< boost::is_convertible< From, To > >::type >
{ typedef boost::array<To,1> type; };

template<>
struct float_convert< double, float >
{ typedef boost::array<float,2> type; };

} // namespace result_of

template< class To, class From >
inline typename boost::lazy_enable_if< boost::is_convertible< From, To >,
result_of::float_convert< From, To > >::type
float_convert(const From& x)
{
    typename result_of::float_convert< From, To >::type result;
    result.front() = static_cast< To >(x);
    return result;
}

template< class To >
typename boost::lazy_enable_if< boost::is_same< To, float >,
result_of::float_convert< double, float > >::type
float_convert(double x)
{
    BOOST_MPL_ASSERT_RELATION( std::numeric_limits< double >::digits / 2, <=, std::numeric_limits< float >::digits );
    double abs_x = adl::abs_copy(x);
    if(float_ulp(abs_x) < std::numeric_limits<float>::denorm_min())
        throw std::domain_error("float_convert< float >(double) : ulp of arg is less than float denorm min");
    if(abs_x > std::numeric_limits<float>::max())
        throw std::domain_error("float_convert< float >(double) : abs of arg is greater than float max");
    result_of::float_convert< double, float >::type result;
    double xhi, xlo;
    split(x, xhi, xlo);
    result[0] = static_cast< float >(xlo);
    result[1] = static_cast< float >(xhi);
    assert(static_cast< double >(result[0]) + static_cast< double >(result[1]) == x);
    return result;
}

template< class From, class To >
struct is_float_convertible
    : boost::mpl::not_< is_void< typename result_of::float_convert< From, To >::type > > { };

} // namespace expansion_arithmetic

} // namespace sake

#endif // #ifndef _SAKE_MATH_FLOAT_ULP_HPP_
