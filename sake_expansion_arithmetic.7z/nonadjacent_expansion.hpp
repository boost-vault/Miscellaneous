/*******************************************************************************
 * expansion_arithmetic/nonadjacent_expansion.hpp
 *
 * Copyright 2009, Jeffrey Hellrung.
 * Distributed under the Boost Software License, Version 1.0.  (See accompanying
 * file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
 *
 * expansion_arithmetic::sorted_and_nonadjacent(T a, T b) -> bool
 * struct expansion_arithmetic::functional::sorted_and_nonadjacent<T>
 * expansion_arithmetic::nonadjacent_expansion(const SinglePassReadableRange& e) -> bool
 *
 * nonadjacent_expansion returns whether the given expansion is nonadjacent.
 ******************************************************************************/

#ifndef _SAKE_EXPANSION_ARITHMETIC_IS_NONADJACENT_EXPANSION_HPP_
#define _SAKE_EXPANSION_ARITHMETIC_IS_NONADJACENT_EXPANSION_HPP_

#include <limits>

#include <boost/concept/assert.hpp>
#include <boost/range/end.hpp>
#include <boost/range/value_type.hpp>
#include <boost/static_assert.hpp>

#include <sake/core/functional/negate.hpp>
#include <sake/core/range/algorithm/find_adjacent.hpp>
#include <sake/core/range/concepts.hpp>
#include <sake/core/utility/call_traits.hpp>
#include <sake/expansion_arithmetic/nonoverlapping_expansion.hpp>

namespace sake
{

namespace expansion_arithmetic
{

template< class T >
inline bool sorted_and_nonadjacent(const T& a, const T& b)
{ return sorted_and_nonoverlapping(2 * a, b); }

namespace functional
{

template< class T >
struct sorted_and_nonadjacent
{
    typedef bool result_type;
private:
    typedef typename call_traits<T>::param_type T_param_type;
public:
    bool operator()(T_param_type a, T_param_type b) const
    { return sake::expansion_arithmetic::sorted_and_nonadjacent(a,b); }
};

} // namespace functional

template< class SinglePassReadableRange >
inline bool nonadjacent_expansion(const SinglePassReadableRange& e)
{
    BOOST_CONCEPT_ASSERT((concepts::SinglePassReadableRange< const SinglePassReadableRange >));
    typedef typename boost::range_value< SinglePassReadableRange >::type e_value_type;
    typedef e_value_type T;
    return range::find_adjacent(e, sake::functional::not_(functional::sorted_and_nonadjacent<T>())) == boost::end(e);
}

} // expansion_arithmetic

} // namespace sake

#endif // #ifndef _SAKE_EXPANSION_ARITHMETIC_IS_NONADJACENT_EXPANSION_HPP_
