/*******************************************************************************
 * expansion_arithmetic/expansion_diff.hpp
 *
 * Copyright 2009, Jeffrey Hellrung.
 * Distributed under the Boost Software License, Version 1.0.  (See accompanying
 * file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
 *
 * expansion_arithmetic::expansion_diff[_zeroelim,_unrolled{1,2}](
 *     const SinglePassReadableRange1& e,
 *     const SinglePassReadableRange2& f,
 *     ForwardReadableWritableIterator h_first)
 *     -> ForwardReadableWritableIterator
 * expansion_arithmetic::expansion_diff[_zeroelim,_unrolled{1,2}](
 *     ForwardReadableWritableRange& e,
 *     const SinglePassReadableRange& f)
 *     -> boost::range_iterator< ForwardReadableWritableRange >::type
 *
 * expansion_diff subtracts the expansion in f from the expansion in e, putting
 * the result in h.
 * Maintains nonoverlapping and nonadjacent.  Does not maintain strongly
 * nonoverlapping.
 * h must have at least size(e) + size(f) elements in general.
 * h may be identical to e, in which case the distance(f)-past-the-end elements
 * of e must be valid.  If _zeroelim2 is used, it's enough for the last
 * distance(f) elements of e to be 0.
 * Returns the iterator pointing to one-past-the-last element written to h.
 * In the second variants, h is identical to e.
 ******************************************************************************/

#ifndef _SAKE_EXPANSION_ARITHMETIC_EXPANSION_DIFF_HPP_
#define _SAKE_EXPANSION_ARITHMETIC_EXPANSION_DIFF_HPP_

#include <functional>

#include <boost/concept/assert.hpp>
#include <boost/mpl/assert.hpp>
#include <boost/range/begin.hpp>
#include <boost/range/iterator.hpp>
#include <boost/range/value_type.hpp>

#include <sake/core/iterator/transform_iterator.hpp>
#include <sake/core/range/concepts.hpp>
#include <sake/core/range/range_static_size.hpp>
#include <sake/core/range/static_size_iterator_range.hpp>
#include <sake/core/range/transform_range.hpp>
#include <sake/expansion_arithmetic/expansion_sum.hpp>

namespace sake
{

namespace expansion_arithmetic
{

template< class SinglePassReadableRange1, class SinglePassReadableRange2, class ForwardReadableWritableIterator >
inline ForwardReadableWritableIterator
expansion_diff(
    const SinglePassReadableRange1& e,
    const SinglePassReadableRange2& f,
    ForwardReadableWritableIterator h_first)
{
    BOOST_CONCEPT_ASSERT((concepts::SinglePassReadableRange< const SinglePassReadableRange2 >));
    typedef typename boost::range_value< SinglePassReadableRange2 >::type f_value_type;
    return expansion_sum(e, make_transform_range< std::negate< f_value_type > >(f), h_first);
}

template< class ForwardReadableWritableRange, class SinglePassReadableRange >
inline typename boost::range_iterator< ForwardReadableWritableRange >::type
expansion_diff(
    ForwardReadableWritableRange& e,
    const SinglePassReadableRange& f)
{
    BOOST_CONCEPT_ASSERT((concepts::ForwardReadableWritableRange< ForwardReadableWritableRange >));
    return expansion_diff(e, f, boost::begin(e));
}

template< class SinglePassReadableRange1, class SinglePassReadableRange2, class ForwardReadableWritableIterator >
inline ForwardReadableWritableIterator
expansion_diff_zeroelim(
    const SinglePassReadableRange1& e,
    const SinglePassReadableRange2& f,
    ForwardReadableWritableIterator h_first)
{
    BOOST_CONCEPT_ASSERT((concepts::SinglePassReadableRange< const SinglePassReadableRange2 >));
    typedef typename boost::range_value< SinglePassReadableRange2 >::type f_value_type;
    return expansion_sum_zeroelim(e, make_transform_range< std::negate< f_value_type > >(f), h_first);
}

template< class ForwardReadableWritableRange, class SinglePassReadableRange >
inline typename boost::range_iterator< ForwardReadableWritableRange >::type
expansion_diff_zeroelim(
    ForwardReadableWritableRange& e,
    const SinglePassReadableRange& f)
{
    BOOST_CONCEPT_ASSERT((concepts::ForwardReadableWritableRange< ForwardReadableWritableRange >));
    return expansion_diff_zeroelim(e, f, boost::begin(e));
}

template< class SinglePassReadableStaticSizeRange, class SinglePassReadableRange, class ForwardReadableWritableIterator >
inline ForwardReadableWritableIterator
expansion_diff_unrolled1(
    const SinglePassReadableStaticSizeRange& e,
    const SinglePassReadableRange& f,
    ForwardReadableWritableIterator h_first)
{
    BOOST_CONCEPT_ASSERT((concepts::SinglePassReadableRange< const SinglePassReadableRange >));
    typedef typename boost::range_value< SinglePassReadableRange >::type f_value_type;
    return expansion_sum_unrolled1(e, make_transform_range< std::negate< f_value_type > >(f), h_first);
}

template< class ForwardReadableWritableStaticSizeRange, class SinglePassReadableRange >
inline typename boost::range_iterator< ForwardReadableWritableStaticSizeRange >::type
expansion_diff_unrolled1(
    ForwardReadableWritableStaticSizeRange& e,
    const SinglePassReadableRange& f)
{
    BOOST_CONCEPT_ASSERT((concepts::ForwardReadableWritableRange< ForwardReadableWritableStaticSizeRange >));
    return expansion_diff_unrolled1(e, f, boost::begin(e));
}

template< class SinglePassReadableStaticSizeRange1, class SinglePassReadableStaticSizeRange2, class ForwardReadableWritableIterator >
inline ForwardReadableWritableIterator
expansion_diff_unrolled2(
    const SinglePassReadableStaticSizeRange1& e,
    const SinglePassReadableStaticSizeRange2& f,
    ForwardReadableWritableIterator h_first)
{
    BOOST_CONCEPT_ASSERT((concepts::SinglePassReadableRange< const SinglePassReadableStaticSizeRange2 >));
    BOOST_MPL_ASSERT((range_has_static_size< SinglePassReadableStaticSizeRange2 >));
    typedef range_static_size< SinglePassReadableStaticSizeRange2 > f_size_type;
    typedef typename boost::range_value< SinglePassReadableStaticSizeRange2 >::type f_value_type;
    return expansion_sum_unrolled2(e, make_transform_range< std::negate< f_value_type > >(f), h_first);
}

template< class ForwardReadableWritableStaticSizeRange, class SinglePassReadableStaticSizeRange >
inline typename boost::range_iterator< ForwardReadableWritableStaticSizeRange >::type
expansion_diff_unrolled2(
    ForwardReadableWritableStaticSizeRange& e,
    const SinglePassReadableStaticSizeRange& f)
{
    BOOST_CONCEPT_ASSERT((concepts::ForwardReadableWritableRange< ForwardReadableWritableStaticSizeRange >));
    return expansion_diff_unrolled2(e, f, boost::begin(e));
}

} // namespace expansion_arithmetic

} // namespace sake

#endif // #ifndef _SAKE_EXPANSION_ARITHMETIC_EXPANSION_DIFF_HPP_
