/*******************************************************************************
 * expansion_arithmetic/fast_expansion_sum.hpp
 *
 * Copyright 2009, Jeffrey Hellrung.
 * Distributed under the Boost Software License, Version 1.0.  (See accompanying
 * file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
 *
 * expansion_arithmetic::fast_expansion_sum[_zeroelim](
 *     const SinglePassReadableRange1& e,
 *     const SinglePassReadableRange2& f,
 *     IncrementableWritableIterator h_first)
 *     => IncrementableWritableIterator
 *
 * fast_expansion_sum adds the expansions in e and f, putting the result in h.
 * Maintains strongly nonoverlapping; does not maintain nonoverlapping or
 * nonadjacent.
 * e and f are assumed to be nonempty.
 * h must have at least distance(e) + distance(f) valid elements.
 * h cannot intersect neither e nor f.
 * Returns the iterator pointing to one-past-the-last element written to h.
 ******************************************************************************/

#ifndef _SAKE_EXPANSION_ARITHMETIC_FAST_EXPANSION_SUM_HPP_
#define _SAKE_EXPANSION_ARITHMETIC_FAST_EXPANSION_SUM_HPP_

#include <cassert>

#include <boost/concept/assert.hpp>
#include <boost/iterator/iterator_traits.hpp>
#include <boost/mpl/assert.hpp>
#include <boost/range/begin.hpp>
#include <boost/range/end.hpp>
#include <boost/range/iterator.hpp>
#include <boost/range/value_type.hpp>
#include <boost/type_traits/is_same.hpp>

#include <sake/core/functional/equal_to_zero.hpp>
#include <sake/core/iterator/concepts.hpp>
#include <sake/core/iterator/ofilter_iterator.hpp>
#include <sake/core/range/algorithm/copy.hpp>
#include <sake/core/range/concepts.hpp>
#include <sake/expansion_arithmetic/strongly_nonoverlapping_expansion.hpp>
#include <sake/expansion_arithmetic/two_sum.hpp>

namespace sake
{

namespace expansion_arithmetic
{

template< class SinglePassReadableRange1, class SinglePassReadableRange2, class IncrementableWritableIterator >
IncrementableWritableIterator
fast_expansion_sum(
    const SinglePassReadableRange1& e,
    const SinglePassReadableRange2& f,
    IncrementableWritableIterator h_first)
{
    BOOST_CONCEPT_ASSERT((concepts::SinglePassReadableRange< const SinglePassReadableRange1 >));
    BOOST_CONCEPT_ASSERT((concepts::SinglePassReadableRange< const SinglePassReadableRange2 >));
    typedef typename boost::range_value< SinglePassReadableRange1 >::type e_value_type;
    typedef typename boost::range_value< SinglePassReadableRange2 >::type f_value_type;
    BOOST_MPL_ASSERT((boost::is_same< e_value_type, f_value_type >));
    typedef e_value_type T;
    BOOST_CONCEPT_ASSERT((concepts::IncrementableWritableIterator< IncrementableWritableIterator, T >));
    typedef typename boost::range_iterator< const SinglePassReadableRange1 >::type e_it_type;
    typedef typename boost::range_iterator< const SinglePassReadableRange2 >::type f_it_type;
    typedef IncrementableWritableIterator h_it_type;
    assert(strongly_nonoverlapping_expansion(e));
    assert(strongly_nonoverlapping_expansion(f));
    e_it_type e_it = boost::begin(e);
    e_it_type e_end = boost::end(e);
    if(e_it == e_end)
        return range::copy(f, h_first);
    f_it_type f_it = boost::begin(f), f_end = boost::end(f);
    if(f_it == f_end)
        return range::copy(e, h_first);
    T e_x = *e_it, f_x = *f_it, q, q_new, h_x;
    if((e_x < f_x) == (e_x > -f_x)) {
        q = e_x;
        ++e_it;
    }
    else {
        q = f_x;
        ++f_it;
    }
    if(e_it != e_end && f_it != f_end) {
        // start with using fast_two_sum, then continue with two_sum
        e_x = *e_it;
        f_x = *f_it;
        if((e_x < f_x) == (e_x > -f_x)) {
            fast_two_sum(e_x, q, q_new, h_x);
            ++e_it;
        }
        else {
            fast_two_sum(f_x, q, q_new, h_x);
            ++f_it;
        }
        q = q_new;
        *h_first = h_x;
        ++h_first;
        while(e_it != e_end && f_it != f_end) {
            e_x = *e_it;
            f_x = *f_it;
            if((e_x < f_x) == (e_x > -f_x)) {
                two_sum(q, e_x, q_new, h_x);
                ++e_it;
            }
            else {
                two_sum(q, f_x, q_new, h_x);
                ++f_it;
            }
            q = q_new;
            *h_first = h_x;
            ++h_first;
        }
    }
    for(; e_it != e_end; ++e_it) {
        two_sum(q, *e_it, q_new, h_x);
        q = q_new;
        *h_first = h_x;
        ++h_first;
    }
    for(; f_it != f_end; ++f_it) {
        two_sum(q, *f_it, q_new, h_x);
        q = q_new;
        *h_first = h_x;
        ++h_first;
    }
    *h_first = q;
    return ++h_first;
}

template< class SinglePassReadableRange1, class SinglePassReadableRange2, class IncrementableWritableIterator >
IncrementableWritableIterator
fast_expansion_sum_zeroelim(
    const SinglePassReadableRange1& e,
    const SinglePassReadableRange2& f,
    IncrementableWritableIterator h_first)
{
    BOOST_CONCEPT_ASSERT((concepts::SinglePassReadableRange< const SinglePassReadableRange1 >));
    typedef typename boost::range_value< SinglePassReadableRange1 >::type e_value_type;
    typedef e_value_type T;
    BOOST_CONCEPT_ASSERT((concepts::IncrementableWritableIterator< IncrementableWritableIterator, T >));
    return fast_expansion_sum(e, f, make_ofilter_iterator< sake::functional::not_equal_to_zero<T> >(h_first)).base();
}

} // namespace expansion_arithmetic

} // namespace sake

#endif // #ifndef _SAKE_EXPANSION_ARITHMETIC_FAST_EXPANSION_SUM_HPP_
