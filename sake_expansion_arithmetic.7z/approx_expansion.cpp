/*******************************************************************************
 * expansion_arithmetic/approx_expansion.cpp
 *
 * Copyright 2009, Jeffrey Hellrung.
 * Distributed under the Boost Software License, Version 1.0.  (See accompanying
 * file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
 ******************************************************************************/

#include <sake/expansion_arithmetic/approx_expansion.ipp>

namespace sake
{

#define EXPLICIT_INSTANTIATION_HELPER( T, N ) \
    template class approx_expansion<T,N>; \
    template void approx_expansion<T,N>::assign_add(const approx_expansion<T,N>&, const approx_expansion<T,N>&); \
    template void approx_expansion<T,N>::assign_sub(const approx_expansion<T,N>&, const approx_expansion<T,N>&); \
    template void approx_expansion<T,N>::assign_mult(const approx_expansion<T,N>&, const approx_expansion<T,N>&); \
    template void approx_expansion<T,N>::assign_div(const approx_expansion<T,N>&, const approx_expansion<T,N>&); \
    template void approx_expansion<T,N>::assign_negate(const approx_expansion<T,N>&); \
    template void approx_expansion<T,N>::assign_abs(const approx_expansion<T,N>&);
EXPLICIT_INSTANTIATION_HELPER( float, 1 )
EXPLICIT_INSTANTIATION_HELPER( float, 2 )
EXPLICIT_INSTANTIATION_HELPER( float, 3 )
EXPLICIT_INSTANTIATION_HELPER( float, 4 )
EXPLICIT_INSTANTIATION_HELPER( double, 1 )
EXPLICIT_INSTANTIATION_HELPER( double, 2 )
EXPLICIT_INSTANTIATION_HELPER( double, 3 )
EXPLICIT_INSTANTIATION_HELPER( double, 4 )

} // namespace sake
