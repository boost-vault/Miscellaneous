/*******************************************************************************
 * expansion_arithmetic/expansion_sum.hpp
 *
 * Copyright 2009, Jeffrey Hellrung.
 * Distributed under the Boost Software License, Version 1.0.  (See accompanying
 * file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
 *
 * expansion_arithmetic::expansion_sum[_zeroelim,_unrolled{1,2}](
 *     const SinglePassReadableRange1& e,
 *     const SinglePassReadableRange2& f,
 *     ForwardReadableWritableIterator h_first)
 *     -> ForwardReadableWritableIterator
 * expansion_arithmetic::expansion_sum[_zeroelim,_unrolled{1,2}](
 *     ForwardReadableWritableRange& e,
 *     const SinglePassReadableRange& f)
 *     -> boost::range_iterator< ForwardReadableWritableRange >::type
 *
 * expansion_sum adds the expansions in e and f, putting the result in h.
 * Maintains nonoverlapping and nonadjacent; does not maintain strongly
 * nonoverlapping.
 * h must have at least size(e) + size(f) elements in general.
 * h may be identical to e, in which case the distance(f)-past-the-end elements
 * of e must be valid.  If _zeroelim2 is used, it's enough for the last
 * distance(f) elements of e to be 0.
 * Returns the iterator pointing to one-past-the-last element written to h.
 * In the second variants, h is identical to e.
 ******************************************************************************/

#ifndef _SAKE_EXPANSION_ARITHMETIC_EXPANSION_SUM_HPP_
#define _SAKE_EXPANSION_ARITHMETIC_EXPANSION_SUM_HPP_

#include <algorithm>
#include <iterator>

#include <cassert>

#include <boost/concept/assert.hpp>
#include <boost/iterator/iterator_traits.hpp>
#include <boost/mpl/assert.hpp>
#include <boost/next_prior.hpp>
#include <boost/range/begin.hpp>
#include <boost/range/end.hpp>
#include <boost/range/iterator.hpp>
#include <boost/range/iterator_range.hpp>
#include <boost/range/value_type.hpp>
#include <boost/type_traits/is_same.hpp>

#include <sake/core/functional/equal_to_zero.hpp>
#include <sake/core/iterator/concepts.hpp>
#include <sake/core/iterator/readable_ofilter_iterator.hpp>
#include <sake/core/range/algorithm/copy.hpp>
#include <sake/core/range/concepts.hpp>
#include <sake/core/range/range_static_size.hpp>
#include <sake/core/range/static_size_iterator_range.hpp>
#include <sake/expansion_arithmetic/grow_expansion.hpp>
#include <sake/expansion_arithmetic/nonadjacent_expansion.hpp>
#include <sake/expansion_arithmetic/nonoverlapping_expansion.hpp>

namespace sake
{

namespace expansion_arithmetic
{

/*******************************************************************************
 * expansion_sum(
 *     const SinglePassReadableRange1& e,
 *     const SinglePassReadableRange2& f,
 *     ForwardReadableWritableIterator h_first)
 *     -> ForwardReadableWritableIterator
 ******************************************************************************/

template< class SinglePassReadableRange1, class SinglePassReadableRange2, class ForwardReadableWritableIterator >
ForwardReadableWritableIterator
expansion_sum(
    const SinglePassReadableRange1& e,
    const SinglePassReadableRange2& f,
    ForwardReadableWritableIterator h_first)
{
    BOOST_CONCEPT_ASSERT((concepts::SinglePassReadableRange< const SinglePassReadableRange1 >));
    BOOST_CONCEPT_ASSERT((concepts::SinglePassReadableRange< const SinglePassReadableRange2 >));
    BOOST_CONCEPT_ASSERT((concepts::ForwardReadableWritableIterator< ForwardReadableWritableIterator >));
    typedef typename boost::range_value< SinglePassReadableRange1 >::type e_value_type;
    typedef typename boost::range_value< SinglePassReadableRange2 >::type f_value_type;
    typedef ForwardReadableWritableIterator h_it_type;
    typedef typename boost::iterator_value< h_it_type >::type h_value_type;
    BOOST_MPL_ASSERT((boost::is_same< e_value_type, h_value_type >));
    BOOST_MPL_ASSERT((boost::is_same< f_value_type, h_value_type >));
    typedef typename boost::range_iterator< const SinglePassReadableRange2 >::type f_it_type;
    assert(nonoverlapping_expansion(e));
    assert(nonoverlapping_expansion(f));
    f_it_type f_it = boost::begin(f), f_end = boost::end(f);
    if(f_it == f_end)
        return range::copy(e, h_first);
    h_it_type h_end = grow_expansion(e, *f_it, h_first);
    while(++f_it != f_end) {
        if(h_first != h_end)
            ++h_first;
        h_end = grow_expansion(boost::make_iterator_range(h_first, h_end), *f_it);
    }
    return h_end;
}

/*******************************************************************************
 * expansion_sum(
 *     ForwardReadableWritableRange& e,
 *     const SinglePassReadableRange& f)
 *     -> boost::range_iterator< ForwardReadableWritableRange >::type
 ******************************************************************************/

template< class ForwardReadableWritableRange, class SinglePassReadableRange >
inline typename boost::range_iterator< ForwardReadableWritableRange >::type
expansion_sum(
    ForwardReadableWritableRange& e,
    const SinglePassReadableRange& f)
{
    BOOST_CONCEPT_ASSERT((concepts::ForwardReadableWritableRange< ForwardReadableWritableRange >));
#ifdef SAKE_EXPANSION_ARITHMETIC_ASSERT_INVARIANTS
    bool nonoverlapping = nonoverlapping_expansion(e) && nonoverlapping_expansion(f);
    bool nonadjacent = nonadjacent_expansion(e) && nonadjacent_expansion(f);
    typedef typename boost::range_iterator< ForwardReadableWritableRange >::type e_it_type;
    e_it_type e_it = expansion_sum(e, f, boost::begin(e));
    assert(!nonoverlapping || nonoverlapping_expansion(e));
    assert(!nonadjacent || nonadjacent_expansion(e));
    return e_it;
#else
    return expansion_sum(e, f, boost::begin(e));
#endif
}

/*******************************************************************************
 * expansion_sum_zeroelim(
 *     const SinglePassReadableRange1& e,
 *     const SinglePassReadableRange2& f,
 *     ForwardReadableWritableIterator h_first)
 *     -> ForwardReadableWritableIterator
 ******************************************************************************/

template< class SinglePassReadableRange1, class SinglePassReadableRange2, class ForwardReadableWritableIterator >
ForwardReadableWritableIterator
expansion_sum_zeroelim(
    const SinglePassReadableRange1& e,
    const SinglePassReadableRange2& f,
    ForwardReadableWritableIterator h_first)
{
    BOOST_CONCEPT_ASSERT((concepts::ForwardReadableWritableIterator< ForwardReadableWritableIterator >));
    typedef ForwardReadableWritableIterator h_it_type;
    typedef typename boost::iterator_value< h_it_type >::type h_value_type;
    return expansion_sum(e, f, make_readable_ofilter_iterator< sake::functional::not_equal_to_zero< h_value_type > >(h_first)).base();
}

/*******************************************************************************
 * expansion_sum_zeroelim(
 *     ForwardReadableWritableRange& e,
 *     const SinglePassReadableRange& f)
 *     -> boost::range_iterator< ForwardReadableWritableRange >::type
 ******************************************************************************/

template< class ForwardReadableWritableRange, class SinglePassReadableRange >
inline typename boost::range_iterator< ForwardReadableWritableRange >::type
expansion_sum_zeroelim(
    ForwardReadableWritableRange& e,
    const SinglePassReadableRange& f)
{
    BOOST_CONCEPT_ASSERT((concepts::ForwardReadableWritableRange< ForwardReadableWritableRange >));
    return expansion_sum_zeroelim(e, f, boost::begin(e));
}

/*******************************************************************************
 * expansion_sum_unrolled1(
 *     const SinglePassReadableRange1& e,
 *     const SinglePassReadableRange2& f,
 *     ForwardReadableWritableIterator h_first)
 *     -> ForwardReadableWritableIterator
 ******************************************************************************/

namespace detail_expansion_sum
{

template< int EN >
struct expansion_sum_unrolled1_impl
{
    template< class ERange, class FRange, class HIt >
    static HIt apply(const ERange& e, const FRange& f, HIt h_first)
    {
        typedef typename boost::range_iterator< const FRange >::type f_it_type;
        f_it_type f_it = boost::begin(f), f_end = boost::end(f);
        if(f_it == f_end)
            return range::copy(e, h_first);
        grow_expansion_unrolled(e, *f_it, h_first);
        while(++f_it != f_end)
            grow_expansion_unrolled(make_static_size_iterator_range<EN>(++h_first), *f_it);
        return boost::next(h_first, EN + 1);
    }
};

template<>
struct expansion_sum_unrolled1_impl<0>
{
    template< class ERange, class FRange, class HIt >
    static HIt apply(const ERange&, const FRange& f, HIt& h_first)
    { return range::copy(f, h_first); }
};

} // namespace detail_expansion_sum

template< class SinglePassReadableStaticSizeRange, class SinglePassReadableRange, class ForwardReadableWritableIterator >
ForwardReadableWritableIterator
expansion_sum_unrolled1(
    const SinglePassReadableStaticSizeRange& e,
    const SinglePassReadableRange& f,
    ForwardReadableWritableIterator h_first)
{
    BOOST_CONCEPT_ASSERT((concepts::SinglePassReadableRange< const SinglePassReadableStaticSizeRange >));
    BOOST_MPL_ASSERT((range_has_static_size< SinglePassReadableStaticSizeRange >));
    typedef range_static_size< SinglePassReadableStaticSizeRange > e_size_type;
    BOOST_CONCEPT_ASSERT((concepts::SinglePassReadableRange< const SinglePassReadableRange >));
    BOOST_CONCEPT_ASSERT((concepts::ForwardReadableWritableIterator< ForwardReadableWritableIterator >));
    typedef typename boost::range_value< SinglePassReadableStaticSizeRange >::type e_value_type;
    typedef typename boost::range_value< SinglePassReadableRange >::type f_value_type;
    typedef ForwardReadableWritableIterator h_it_type;
    typedef typename boost::iterator_value< h_it_type >::type h_value_type;
    BOOST_MPL_ASSERT((boost::is_same< e_value_type, h_value_type >));
    BOOST_MPL_ASSERT((boost::is_same< f_value_type, h_value_type >));
    assert(nonoverlapping_expansion(e));
    assert(nonoverlapping_expansion(f));
    return detail_expansion_sum::expansion_sum_unrolled1_impl< e_size_type::value >::apply(e, f, h_first);
}

/*******************************************************************************
 * expansion_sum_unrolled1(
 *     ForwardReadableWritableRange& e,
 *     const SinglePassReadableRange& f)
 *     -> boost::range_iterator< ForwardReadableWritableRange >::type
 ******************************************************************************/

template< class ForwardReadableWritableStaticSizeRange, class SinglePassReadableRange >
inline typename boost::range_iterator< ForwardReadableWritableStaticSizeRange >::type
expansion_sum_unrolled1(
    ForwardReadableWritableStaticSizeRange& e,
    const SinglePassReadableRange& f)
{
    BOOST_CONCEPT_ASSERT((concepts::ForwardReadableWritableRange< ForwardReadableWritableStaticSizeRange >));
#ifdef SAKE_EXPANSION_ARITHMETIC_ASSERT_INVARIANTS
    bool nonoverlapping = nonoverlapping_expansion(e) && nonoverlapping_expansion(f);
    bool nonadjacent = nonadjacent_expansion(e) && nonadjacent_expansion(f);
    typedef typename boost::range_iterator< ForwardReadableWritableStaticSizeRange >::type e_it_type;
    e_it_type e_it = expansion_sum_unrolled1(e, f, boost::begin(e));
    assert(!nonoverlapping || nonoverlapping_expansion(e));
    assert(!nonadjacent || nonadjacent_expansion(e));
    return e_it;
#else
    return expansion_sum_unrolled1(e, f, boost::begin(e));
#endif
}

/*******************************************************************************
 * expansion_sum_unrolled2(
 *     const SinglePassReadableRange1& e,
 *     const SinglePassReadableRange2& f,
 *     ForwardReadableWritableIterator h_first)
 *     -> ForwardReadableWritableIterator
 ******************************************************************************/

namespace detail_expansion_sum
{

template< int FN >
struct expansion_sum_iteration
{
    template< int EN, class HIt, class FIt >
    static void apply(HIt& h_it, FIt& f_it)
    {
        grow_expansion_unrolled(make_static_size_iterator_range<EN>(h_it), *f_it);
        expansion_sum_iteration< FN-1 >::template apply<EN>(++h_it, ++f_it);
    }
};

template<>
struct expansion_sum_iteration<0>
{
    template< int EN, class HIt, class FIt >
    static void apply(HIt&, FIt&) { }
};

template< int EN, int FN >
struct expansion_sum_unrolled2_dispatch
{
    template< class ERange, class FRange, class HIt >
    static HIt apply(const ERange& e, const FRange& f, HIt h_first)
    {
        typedef typename boost::range_iterator< const FRange >::type f_it_type;
        f_it_type f_it = boost::begin(f);
        grow_expansion_unrolled(e, *f_it, h_first);
        expansion_sum_iteration< FN-1 >::template apply<EN>(++h_first, ++f_it);
        assert(f_it == boost::end(f));
        return boost::next(h_first, EN);
    }
};

template< int EN >
struct expansion_sum_unrolled2_dispatch< EN, 0 >
{
    template< class ERange, class FRange, class HIt >
    static HIt apply(const ERange& e, const FRange&, HIt h_first)
    { return range::copy(e, h_first); }
};

template< int FN >
struct expansion_sum_unrolled2_dispatch< 0, FN >
{
    template< class ERange, class FRange, class HIt >
    static HIt apply(const ERange&, const FRange& f, HIt h_first)
    { return range::copy(f, h_first); }
};

template<>
struct expansion_sum_unrolled2_dispatch<0,0>
{
    template< class ERange, class FRange, class HIt >
    static HIt apply(const ERange&, const FRange&, HIt h_first) { return h_first; }
};

} // namespace detail_expansion_sum

template< class SinglePassReadableStaticSizeRange1, class SinglePassReadableStaticSizeRange2, class ForwardReadableWritableIterator >
ForwardReadableWritableIterator
expansion_sum_unrolled2(
    const SinglePassReadableStaticSizeRange1& e,
    const SinglePassReadableStaticSizeRange2& f,
    ForwardReadableWritableIterator h_first)
{
    BOOST_CONCEPT_ASSERT((concepts::SinglePassReadableRange< const SinglePassReadableStaticSizeRange1 >));
    BOOST_MPL_ASSERT((range_has_static_size< SinglePassReadableStaticSizeRange1 >));
    typedef range_static_size< SinglePassReadableStaticSizeRange1 > e_size_type;
    BOOST_CONCEPT_ASSERT((concepts::SinglePassReadableRange< const SinglePassReadableStaticSizeRange2 >));
    BOOST_MPL_ASSERT((range_has_static_size< SinglePassReadableStaticSizeRange2 >));
    typedef range_static_size< SinglePassReadableStaticSizeRange2 > f_size_type;
    BOOST_CONCEPT_ASSERT((concepts::ForwardReadableWritableIterator< ForwardReadableWritableIterator >));
    typedef typename boost::range_value< SinglePassReadableStaticSizeRange1 >::type e_value_type;
    typedef typename boost::range_value< SinglePassReadableStaticSizeRange2 >::type f_value_type;
    typedef ForwardReadableWritableIterator h_it_type;
    typedef typename boost::iterator_value< h_it_type >::type h_value_type;
    BOOST_MPL_ASSERT((boost::is_same< e_value_type, h_value_type >));
    BOOST_MPL_ASSERT((boost::is_same< f_value_type, h_value_type >));
    assert(nonoverlapping_expansion(e));
    assert(nonoverlapping_expansion(f));
    return detail_expansion_sum::expansion_sum_unrolled2_dispatch< e_size_type::value, f_size_type::value >::apply(e, f, h_first);
}

/*******************************************************************************
 * expansion_sum_unrolled2(
 *     ForwardReadableWritableRange& e,
 *     const SinglePassReadableRange& f)
 *     -> boost::range_iterator< ForwardReadableWritableRange >::type
 ******************************************************************************/

namespace detail_expansion_sum
{

template< class ForwardReadableWritableStaticSizeRange, class SinglePassReadableStaticSizeRange >
inline typename boost::range_iterator< ForwardReadableWritableStaticSizeRange >::type
expansion_sum_unrolled2_impl(
    ForwardReadableWritableStaticSizeRange& e,
    const SinglePassReadableStaticSizeRange& f)
{
    BOOST_CONCEPT_ASSERT((concepts::ForwardReadableWritableRange< ForwardReadableWritableStaticSizeRange >));
#ifdef SAKE_EXPANSION_ARITHMETIC_ASSERT_INVARIANTS
    bool nonoverlapping = nonoverlapping_expansion(e) && nonoverlapping_expansion(f);
    bool nonadjacent = nonadjacent_expansion(e) && nonadjacent_expansion(f);
    typedef typename boost::range_iterator< ForwardReadableWritableStaticSizeRange >::type e_it_type;
    e_it_type e_it = expansion_sum_unrolled2(e, f, boost::begin(e));
    assert(!nonoverlapping || nonoverlapping_expansion(e));
    assert(!nonadjacent || nonadjacent_expansion(e));
    return e_it;
#else
    return expansion_sum_unrolled2(e, f, boost::begin(e));
#endif
}

} // namespace detail_expansion_sum

template< class ForwardReadableWritableStaticSizeRange, class SinglePassReadableStaticSizeRange >
inline typename boost::range_iterator< ForwardReadableWritableStaticSizeRange >::type
expansion_sum_unrolled2(
    ForwardReadableWritableStaticSizeRange& e,
    const SinglePassReadableStaticSizeRange& f)
{ return detail_expansion_sum::expansion_sum_unrolled2_impl(e, f); }

template< class ForwardReadableWritableStaticSizeRange, class SinglePassReadableStaticSizeRange >
inline typename boost::range_iterator< const ForwardReadableWritableStaticSizeRange >::type
expansion_sum_unrolled2(
    const ForwardReadableWritableStaticSizeRange& e, // const to grab rvalues
    const SinglePassReadableStaticSizeRange& f)
{ return detail_expansion_sum::expansion_sum_unrolled2_impl(e, f); }

} // namespace expansion_arithmetic

} // namespace sake

#endif // #ifndef _SAKE_EXPANSION_ARITHMETIC_EXPANSION_SUM_HPP_
