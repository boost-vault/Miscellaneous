/*******************************************************************************
 * expansion_arithmetic/approx_expansion.hpp
 *
 * Copyright 2009, Jeffrey Hellrung.
 * Distributed under the Boost Software License, Version 1.0.  (See accompanying
 * file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
 *
 * class approx_expansion<T,N>
 * struct ext::range_static_size< approx_expansion<T,N> >
 * swap(approx_expansion<T,N>& arg1, approx_expansion<T,N>& arg2) -> void
 *
 * An approx_expansion represents an approximate arithmetic expansion of some
 * constant number of components.
 ******************************************************************************/

#ifndef _SAKE_EXPANSION_ARITHMETIC_APPROX_EXPANSION_HPP_
#define _SAKE_EXPANSION_ARITHMETIC_APPROX_EXPANSION_HPP_

#include <cstddef>

#include <algorithm>
#include <limits>

#include <boost/concept/assert.hpp>
#include <boost/logic/tribool.hpp>
#include <boost/mpl/assert.hpp>
#include <boost/numeric/interval/hw_rounding.hpp>
#include <boost/preprocessor/facilities/identity.hpp>
#include <boost/range/difference_type.hpp>
#include <boost/range/iterator.hpp>
#include <boost/range/pointer.hpp>
#include <boost/range/reference.hpp>
#include <boost/range/value_type.hpp>
#include <boost/static_assert.hpp>
#include <boost/type_traits/is_convertible.hpp>
#include <boost/type_traits/is_same.hpp>
#include <boost/utility/enable_if.hpp>

#include <sake/boost_ext/array.hpp>
#include <sake/core/math/sign_t.hpp>
#include <sake/core/math/zero.hpp>
#include <sake/core/range/algorithm/fill.hpp>
#include <sake/core/range/algorithm/transform.hpp>
#include <sake/core/range/range_static_size.hpp>
#include <sake/core/utility/call_traits.hpp>
#include <sake/core/utility/minimal_initialization_tag.hpp>
#include <sake/expansion_arithmetic/abs.hpp>
#include <sake/expansion_arithmetic/expansion_fwd.hpp>
#include <sake/expansion_arithmetic/sign.hpp>
#include <sake/core/utility/swap.hpp>

namespace sake
{

/*******************************************************************************
 * class approx_expansion<T,N>
 ******************************************************************************/

template< class T, std::size_t N >
class approx_expansion
{
    BOOST_STATIC_ASSERT((std::numeric_limits<T>::is_iec559));
    BOOST_MPL_ASSERT_RELATION( N, >, 0 );
    typedef boost::array<T,N> expansion_container_type;
public:
    typedef T component_type;
    typedef std::size_t size_type;
    static const size_type static_size = N;

    // typedef's to allow boost::range read access to the components.
    typedef component_type value_type;
    typedef typename boost::range_iterator< const expansion_container_type >::type iterator;
    typedef typename boost::range_reference< const expansion_container_type >::type reference;
    typedef typename boost::range_pointer< const expansion_container_type >::type pointer;
    typedef typename boost::range_difference< expansion_container_type >::type difference_type;
    typedef iterator const_iterator;
    typedef reference const_reference;
    typedef pointer const_pointer;

private:
    typedef typename call_traits< component_type >::param_type component_param_type;
    typedef typename call_traits< size_type >::param_type size_param_type;
public:

    approx_expansion(component_param_type x = 0, component_param_type error = 0);
    approx_expansion(minimal_initialization_tag);
    approx_expansion(const approx_expansion& other);
    template< std::size_t N2 >
    explicit approx_expansion(const approx_expansion<T,N2>& other);
    template< class BidirectionalReadableExpansion >
    explicit approx_expansion(const BidirectionalReadableExpansion& source, component_param_type error = 0,
        typename boost::disable_if< boost::is_convertible< BidirectionalReadableExpansion, component_type > >::type* = 0);
    //~approx_expansion();

    approx_expansion& operator=(const approx_expansion& other);
    approx_expansion& operator=(component_param_type x);
    template< std::size_t N2 >
    approx_expansion& operator=(const approx_expansion<T,N2>& other);

    void assign(component_param_type x = 0, component_param_type error = 0);
    void assign(const approx_expansion& other);
    template< std::size_t N2 >
    void assign(const approx_expansion<T,N2>& other);
    template< class BidirectionalReadableExpansion >
    typename boost::disable_if< boost::is_convertible< BidirectionalReadableExpansion, component_type > >::type
    assign(const BidirectionalReadableExpansion& source, component_param_type error = 0);
    void swap(approx_expansion& other);

    const_iterator begin() const;
    const_iterator end() const;
    static size_type size();
    static size_type max_size();
    static bool empty();

    sign_t sign() const;
    sign_t compare(component_param_type x) const;
    template< std::size_t N2 >
    sign_t compare(const approx_expansion<T,N2>& other) const;

#define SAKE_APPROX_EXPANSION_DECLARE_OP_ASSIGN( Op, Name ) \
    template< std::size_t N2, std::size_t N3 > \
    void assign_##Name (const approx_expansion<T,N2>& left, const approx_expansion<T,N3>& right); \
    template< std::size_t N2 > \
    void assign_##Name (const approx_expansion<T,N2>& left, component_param_type right); \
    template< std::size_t N3 > \
    void assign_##Name (component_param_type left, const approx_expansion<T,N3>& right); \
    void assign_##Name (component_param_type left, component_param_type right); \
    template< std::size_t N2 > \
    approx_expansion& operator Op##=(const approx_expansion<T,N2>& arg); \
    approx_expansion& operator Op##=(component_param_type arg);
    SAKE_APPROX_EXPANSION_DECLARE_OP_ASSIGN( +, add  )
    SAKE_APPROX_EXPANSION_DECLARE_OP_ASSIGN( -, sub  )
    SAKE_APPROX_EXPANSION_DECLARE_OP_ASSIGN( *, mult )
    SAKE_APPROX_EXPANSION_DECLARE_OP_ASSIGN( /, div  )
#undef SAKE_APPROX_EXPANSION_DECLARE_OP_ASSIGN

    void assign_negate(const approx_expansion& arg);
    template< std::size_t N2 >
    void assign_negate(const approx_expansion<T,N2>& arg);
    void assign_negate(component_param_type arg);
    void assign_abs(const approx_expansion& arg);
    template< std::size_t N2 >
    void assign_abs(const approx_expansion<T,N2>& arg);
    void assign_abs(component_param_type arg);
    template< std::size_t N2 >
    void assign_invert(const approx_expansion<T,N2>& arg);
    void assign_invert(component_param_type arg);

    approx_expansion& negate_ip();
    approx_expansion& abs_ip();
    approx_expansion& invert_ip();

    approx_expansion negate_copy() const;
    approx_expansion abs_copy() const;
    approx_expansion invert_copy() const;
    approx_expansion operator-() const;

    component_type operator[](size_param_type i) const;
    component_type error() const;

private:
    expansion_container_type m_expansion;
    component_type m_error;
};

/*******************************************************************************
 * struct ext::range_static_size< approx_expansion<T,N> >
 ******************************************************************************/

namespace ext
{

template< class T, std::size_t N >
struct range_static_size< approx_expansion<T,N> >
    : boost::integral_constant< std::size_t, N >
{ };

} // namespace ext

/*******************************************************************************
 * approx_expansion free arithmetic operators
 ******************************************************************************/

#define SAKE_APPROX_EXPANSION_DEFINE_BIN_OP_HELPER( Op, Name, LeftType, RightType ) \
template< class T, std::size_t N > \
inline approx_expansion<T,N> \
operator Op (const LeftType() & left, const RightType() & right) \
{ \
    approx_expansion<T,N> temp((minimal_initialization_tag())); \
    temp.assign_##Name(left, right); \
    return temp; \
}
#define SAKE_approx_expansionTN() approx_expansion<T,N>
#define SAKE_APPROX_EXPANSION_DEFINE_BIN_OP( Op, Name ) \
SAKE_APPROX_EXPANSION_DEFINE_BIN_OP_HELPER( Op, Name, SAKE_approx_expansionTN, SAKE_approx_expansionTN ) \
SAKE_APPROX_EXPANSION_DEFINE_BIN_OP_HELPER( Op, Name, SAKE_approx_expansionTN, BOOST_PP_IDENTITY( T ) ) \
SAKE_APPROX_EXPANSION_DEFINE_BIN_OP_HELPER( Op, Name, BOOST_PP_IDENTITY( T ), SAKE_approx_expansionTN )
SAKE_APPROX_EXPANSION_DEFINE_BIN_OP( +, add  )
SAKE_APPROX_EXPANSION_DEFINE_BIN_OP( -, sub  )
SAKE_APPROX_EXPANSION_DEFINE_BIN_OP( *, mult )
SAKE_APPROX_EXPANSION_DEFINE_BIN_OP( /, div  )
#undef SAKE_approx_expansionTN
#undef SAKE_APPROX_EXPANSION_DEFINE_BIN_OP_HELPER
#undef SAKE_APPROX_EXPANSION_DEFINE_BIN_OP

/*******************************************************************************
 * approx_expansion free comparison operators
 ******************************************************************************/

template< class T, std::size_t N1, std::size_t N2 >
inline boost::logic::tribool operator==(const approx_expansion<T,N1>& left, const approx_expansion<T,N1>& right)
{ return left.compare(right) == zero; }
template< class T, std::size_t N1 >
inline boost::logic::tribool operator==(const approx_expansion<T,N1>& left, const T& right)
{ return left.compare(right) == zero; }
template< class T, std::size_t N2 >
inline boost::logic::tribool operator==(const T& left, const approx_expansion<T,N2>& right)
{ return right.compare(left) == zero; }
template< class T, std::size_t N1 >
inline boost::logic::tribool operator==(const approx_expansion<T,N1>& left, zero_t)
{ return left.sign() == zero; }
template< class T, std::size_t N2 >
inline boost::logic::tribool operator==(zero_t, const approx_expansion<T,N2>& right)
{ return zero == right.sign(); }

template< class T, std::size_t N1, std::size_t N2 >
inline boost::logic::tribool operator!=(const approx_expansion<T,N1>& left, const approx_expansion<T,N2>& right)
{ return !(left == right); }
template< class T, std::size_t N1 >
inline boost::logic::tribool operator!=(const approx_expansion<T,N1>& left, const T& right)
{ return !(left == right); }
template< class T, std::size_t N2 >
inline boost::logic::tribool operator!=(const T& left, const approx_expansion<T,N2>& right)
{ return !(left == right); }
template< class T, std::size_t N1 >
inline boost::logic::tribool operator!=(const approx_expansion<T,N1>& left, zero_t)
{ return !(left == zero); }
template< class T, std::size_t N2 >
inline boost::logic::tribool operator!=(zero_t, const approx_expansion<T,N2>& right)
{ return !(zero == right); }

#define SAKE_APPROX_EXPANSION_DEFINE_COMPARISON_OP( Op ) \
template< class T, std::size_t N1, std::size_t N2 > \
inline boost::logic::tribool operator Op (const approx_expansion<T,N1>& left, const approx_expansion<T,N2>& right) \
{ return left.compare(right) Op zero; } \
template< class T, std::size_t N1 > \
inline boost::logic::tribool operator Op (const approx_expansion<T,N1>& left, const T& right) \
{ return left.compare(right) Op zero; } \
template< class T, std::size_t N2 > \
inline boost::logic::tribool operator Op (const T& left, const approx_expansion<T,N2>& right) \
{ return zero Op right.compare(left); } \
template< class T, std::size_t N1 > \
inline boost::logic::tribool operator Op (const approx_expansion<T,N1>& left, zero_t) \
{ return left.sign() Op zero; } \
template< class T,std::size_t N2 > \
inline boost::logic::tribool operator Op (zero_t, const approx_expansion<T,N2>& right) \
{ return zero Op right.sign(); }
SAKE_APPROX_EXPANSION_DEFINE_COMPARISON_OP( <  )
SAKE_APPROX_EXPANSION_DEFINE_COMPARISON_OP( >  )
SAKE_APPROX_EXPANSION_DEFINE_COMPARISON_OP( <= )
SAKE_APPROX_EXPANSION_DEFINE_COMPARISON_OP( >= )
#undef SAKE_APPROX_EXPANSION_DEFINE_COMPARISON_OP

/*******************************************************************************
 * approx_expansion free functions
 ******************************************************************************/

template< class T, std::size_t N >
inline void swap(approx_expansion<T,N>& arg1, approx_expansion<T,N>& arg2)
{ arg1.swap(arg2); }

/*******************************************************************************
 * approx_expansion inline and template member functions
 ******************************************************************************/

template< class T, std::size_t N >
approx_expansion<T,N>::
approx_expansion(component_param_type x, component_param_type error)
{ assign(x, error); }

template< class T, std::size_t N >
approx_expansion<T,N>::
approx_expansion(minimal_initialization_tag) { }

template< class T, std::size_t N >
approx_expansion<T,N>::
approx_expansion(const approx_expansion& other)
{ assign(other); }

template< class T, std::size_t N >
template< std::size_t N2 >
approx_expansion<T,N>::
approx_expansion(const approx_expansion<T,N2>& other)
{ assign(other); }

template< class T, std::size_t N >
template< class BidirectionalReadableExpansion >
approx_expansion<T,N>::
approx_expansion(const BidirectionalReadableExpansion& source, component_param_type error,
    typename boost::disable_if< boost::is_convertible< BidirectionalReadableExpansion, component_type > >::type*)
{ assign(source, error); }

template< class T, std::size_t N >
inline approx_expansion<T,N>&
approx_expansion<T,N>::
operator=(const approx_expansion& other)
{
    assign(other);
    return *this;
}

template< class T, std::size_t N >
inline approx_expansion<T,N>&
approx_expansion<T,N>::
operator=(component_param_type x)
{
    assign(x);
    return *this;
}

template< class T, std::size_t N >
template< std::size_t N2 >
inline approx_expansion<T,N>&
approx_expansion<T,N>::
operator=(const approx_expansion<T,N2>& other)
{
    assign(other);
    return *this;
}

template< class T, std::size_t N >
void
approx_expansion<T,N>::
assign(component_param_type x, component_param_type error)
{
    range::fill(m_expansion, static_cast< component_type >(0));
    m_expansion.front() = x;
    m_error = error;
}

template< class T, std::size_t N >
inline void
approx_expansion<T,N>::
assign(const approx_expansion& other)
{
    m_expansion = other.m_expansion;
    m_error = other.error();
}

template< class T, std::size_t N >
template< std::size_t N2 >
inline void
approx_expansion<T,N>::
assign(const approx_expansion<T,N2>& other)
{ assign(other, other.error()); }

template< class T, std::size_t N >
template< class BidirectionalReadableExpansion >
typename boost::disable_if<
    boost::is_convertible<
        BidirectionalReadableExpansion,
        typename approx_expansion<T,N>::component_type
    >
>::type
approx_expansion<T,N>::
assign(const BidirectionalReadableExpansion& source, component_param_type error)
{
    BOOST_CONCEPT_ASSERT((concepts::BidirectionalReadableRange< const BidirectionalReadableExpansion >));
    BOOST_MPL_ASSERT((boost::is_same< typename boost::range_value< BidirectionalReadableExpansion >::type, component_type >));
    typename expansion_container_type::iterator e_it = expansion_arithmetic::approximate(source, m_expansion, m_error);
    std::fill(e_it, m_expansion.end(), static_cast< component_type >(0));
    boost::numeric::interval_lib::rounded_math< component_type > rnd;
    m_error = rnd.add_up(m_error, error);
}

template< class T, std::size_t N >
inline typename approx_expansion<T,N>::const_iterator
approx_expansion<T,N>::
begin() const
{ return m_expansion.begin(); }

template< class T, std::size_t N >
inline typename approx_expansion<T,N>::const_iterator
approx_expansion<T,N>::
end() const
{ return m_expansion.end(); }

template< class T, std::size_t N >
inline typename approx_expansion<T,N>::size_type
approx_expansion<T,N>::
size()
{ return N; }

template< class T, std::size_t N >
inline typename approx_expansion<T,N>::size_type
approx_expansion<T,N>::
max_size()
{ return N; }

template< class T, std::size_t N >
inline bool
approx_expansion<T,N>::
empty()
{ return false; }

template< class T, std::size_t N >
inline void
approx_expansion<T,N>::
swap(approx_expansion& other)
{
    m_expansion.swap(other.m_expansion);
    adl::swap(m_error, other.m_error);
}

template< class T, std::size_t N >
inline sign_t
approx_expansion<T,N>::
compare(component_param_type x) const
{ return (*this - x).sign(); }

template< class T, std::size_t N >
template< std::size_t N2 >
inline sign_t
approx_expansion<T,N>::
compare(const approx_expansion<T,N2>& other) const
{ return (*this - other).sign(); }

#define SAKE_APPROX_EXPANSION_DEFINE_OP_ASSIGN( Op, Name ) \
template< class T, std::size_t N > \
template< std::size_t N2 > \
inline void \
approx_expansion<T,N>:: \
assign_##Name(const approx_expansion<T,N2>& left, component_param_type right) \
{ assign_##Name(left, approx_expansion<T,1>(right)); } \
template< class T, std::size_t N > \
template< std::size_t N3 > \
inline void \
approx_expansion<T,N>:: \
assign_##Name(component_param_type left, const approx_expansion<T,N3>& right) \
{ assign_##Name(approx_expansion<T,1>(left), right); } \
template< class T, std::size_t N > \
inline void \
approx_expansion<T,N>:: \
assign_##Name(component_param_type left, component_param_type right) \
{ assign_##Name(approx_expansion<T,1>(left), approx_expansion<T,1>(right)); } \
template< class T, std::size_t N > \
template< std::size_t N2 > \
inline approx_expansion<T,N>& \
approx_expansion<T,N>:: \
operator Op##=(const approx_expansion<T,N2>& arg) \
{ \
    assign_##Name(*this, arg); \
    return *this; \
} \
template< class T, std::size_t N > \
inline approx_expansion<T,N>& \
approx_expansion<T,N>:: \
operator Op##=(component_param_type arg) \
{ \
    assign_##Name(*this, arg); \
    return *this; \
}
SAKE_APPROX_EXPANSION_DEFINE_OP_ASSIGN( +, add  )
SAKE_APPROX_EXPANSION_DEFINE_OP_ASSIGN( -, sub  )
SAKE_APPROX_EXPANSION_DEFINE_OP_ASSIGN( *, mult )
SAKE_APPROX_EXPANSION_DEFINE_OP_ASSIGN( /, div  )
#undef SAKE_APPROX_EXPANSION_DEFINE_OP_ASSIGN

template< class T, std::size_t N >
inline void
approx_expansion<T,N>::
assign_negate(const approx_expansion& arg)
{ range::transform(arg, m_expansion.begin(), std::negate< component_type >()); }

template< class T, std::size_t N >
inline void
approx_expansion<T,N>::
assign_negate(component_param_type arg)
{ assign(-arg); }

template< class T, std::size_t N >
template< std::size_t N2 >
inline void
approx_expansion<T,N>::
assign_abs(const approx_expansion<T,N2>& arg)
{
    if(expansion_arithmetic::sign(arg) < zero)
        assign_negate(arg);
    else
        assign(arg);
}

template< class T, std::size_t N >
inline void
approx_expansion<T,N>::
assign_abs(component_param_type arg)
{ assign(adl::abs_copy(arg)); }

template< class T, std::size_t N >
template< std::size_t N2 >
inline void
approx_expansion<T,N>::
assign_invert(const approx_expansion<T,N2>& arg)
{ assign_div(approx_expansion<T,1>(static_cast< component_type >(1)), arg); }

template< class T, std::size_t N >
inline void
approx_expansion<T,N>::
assign_invert(component_param_type arg)
{ assign_invert(approx_expansion<T,1>(arg)); }

template< class T, std::size_t N >
inline approx_expansion<T,N>&
approx_expansion<T,N>::
negate_ip()
{
    range::transform2(*this, m_expansion, std::negate< component_type >());
    return *this;
}

template< class T, std::size_t N >
inline approx_expansion<T,N>&
approx_expansion<T,N>::
abs_ip()
{
    expansion_arithmetic::abs(m_expansion);
    return *this;
}

template< class T, std::size_t N >
inline approx_expansion<T,N>
approx_expansion<T,N>::
abs_copy() const
{
    approx_expansion<T,N> temp((minimal_initialization_tag()));
    temp.assign_abs(*this);
    return temp;
}

template< class T, std::size_t N >
inline approx_expansion<T,N>&
approx_expansion<T,N>::
invert_ip()
{
    assign_invert(*this);
    return *this;
}

template< class T, std::size_t N >
inline approx_expansion<T,N>
approx_expansion<T,N>::
invert_copy() const
{
    approx_expansion<T,N> temp((minimal_initialization_tag()));
    temp.assign_negate(*this);
    return temp;
}

template< class T, std::size_t N >
inline approx_expansion<T,N>
approx_expansion<T,N>::
operator-() const
{ return negate_copy(); }

template< class T, std::size_t N >
inline typename approx_expansion<T,N>::component_type
approx_expansion<T,N>::
operator[](size_param_type i) const
{ return m_expansion[i]; }

template< class T, std::size_t N >
inline typename approx_expansion<T,N>::component_type
approx_expansion<T,N>::
error() const
{ return m_error; }

} // namespace sake

#endif // #ifndef _SAKE_EXPANSION_ARITHMETIC_APPROX_EXPANSION_HPP_
