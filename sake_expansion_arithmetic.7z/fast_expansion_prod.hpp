/*******************************************************************************
 * expansion_arithmetic/fast_expansion_prod.hpp
 *
 * Copyright 2009, Jeffrey Hellrung.
 * Distributed under the Boost Software License, Version 1.0.  (See accompanying
 * file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
 *
 * expansion_arithmetic::fast_expansion_prod[_zeroelim](
 *     const ForwardReadableRange1& e,
 *     const ForwardReadableRange2& f,
 *     IncrementableWritableIterator h_first,
 *     const Allocator& alloc)
 *     -> IncrementableWritableIterator
 * expansion_arithmetic::fast_expansion_prod[_zeroelim](
 *     const ForwardReadableRange1& e,
 *     const ForwardReadableRange2& f,
 *     IncrementableWritableIterator h_first)
 *     -> IncrementableWritableIterator
 *
 * fast_expansion_prod multiplies the expansions in e and f, putting the result
 * in h.
 * e and f are assumed to be nonempty.
 * h must have at least 2 * size(e) * size(f) elements in general.
 * Returns the iterator pointing to one-past-the-last element written to h.
 * Uses fast_expansion_sum (or a variant) to perform the intermediate additions.
 ******************************************************************************/

#ifndef _SAKE_EXPANSION_ARITHMETIC_FAST_EXPANSION_PROD_HPP_
#define _SAKE_EXPANSION_ARITHMETIC_FAST_EXPANSION_PROD_HPP_

#include <algorithm>
#include <iterator>

#include <cassert>

#include <boost/concept/assert.hpp>
#include <boost/iterator/iterator_traits.hpp>
#include <boost/mpl/assert.hpp>
#include <boost/next_prior.hpp>
#include <boost/range/begin.hpp>
#include <boost/range/difference_type.hpp>
#include <boost/range/distance.hpp>
#include <boost/range/empty.hpp>
#include <boost/range/end.hpp>
#include <boost/range/iterator.hpp>
#include <boost/range/iterator_range.hpp>
#include <boost/range/value_type.hpp>
#include <boost/type_traits/is_same.hpp>

#include <sake/core/data_structures/dynamic_array.hpp>
#include <sake/core/iterator/concepts.hpp>
#include <sake/core/memory/new_delete_allocator.hpp>
#include <sake/core/memory/SakeAllocator.hpp>
#include <sake/core/range/concepts.hpp>
#include <sake/expansion_arithmetic/fast_expansion_sum.hpp>
#include <sake/expansion_arithmetic/scale_expansion.hpp>

namespace sake
{

namespace expansion_arithmetic
{

namespace detail_fast_expansion_prod
{

template< bool ElimZeros >
struct fast_expansion_sum_dispatch
{
    template< class ERange, class FRange, class HIt >
    static HIt apply(const ERange& e, const FRange& f, HIt h_first)
    { return fast_expansion_sum(e, f, h_first); }
};

template<>
struct fast_expansion_sum_dispatch< true >
{
    template< class ERange, class FRange, class HIt >
    static HIt apply(const ERange& e, const FRange& f, HIt h_first)
    { return fast_expansion_sum_zeroelim(e, f, h_first); }
};

template< bool ElimZeros >
struct fast_expansion_prod_iteration
{
    template< class ERange, class FRange, class BufferIt, class HIt >
    static HIt apply(
        const ERange& e,
        const FRange& f,
        BufferIt buffer_first, // working buffer begin
        BufferIt buffer_last,  // working buffer end
        HIt h_first)           // destination
    {
        typedef typename boost::range_iterator< const ERange >::type e_it_type;
        typedef typename boost::range_iterator< const FRange >::type f_it_type;
        typedef typename boost::range_difference< ERange >::type e_difference_type;
        typedef typename boost::range_difference< FRange >::type f_difference_type;
        typedef typename boost::iterator_difference< BufferIt >::type buffer_difference_type;
        assert(!boost::empty(e));
        assert(!boost::empty(f));
        f_it_type f_begin = boost::begin(f);
        f_difference_type f_distance = boost::distance(f);
        if(f_distance == 1)
            return scale_expansion_zeroelim(e, *f_begin, h_first);
        e_difference_type e_distance = boost::distance(e);
        assert(f_distance <= e_distance);
        assert(2 * e_distance * f_distance <= std::distance(buffer_first, buffer_last));
        f_difference_type f_half_distance = f_distance / 2;
        f_it_type f_halfway = boost::next(f_begin, f_half_distance);
        f_it_type f_end = boost::end(f);
        BufferIt buffer_working1_begin = boost::next(buffer_first, 2 * e_distance * f_distance);
        BufferIt buffer_working1_end = buffer_last;
        BufferIt buffer_working2_begin = buffer_working1_begin; // If parallelized, separate these working areas.
        BufferIt buffer_working2_end = buffer_working1_end;
        BufferIt buffer_halfway = boost::next(buffer_first, 2 * e_distance * f_half_distance);
        BufferIt buffer_end1 = apply(
            e,
            boost::make_iterator_range(f_begin, f_halfway),
            buffer_working1_begin,
            buffer_working1_end,
            buffer_first);
        assert(std::distance(buffer_end1, buffer_halfway) >= 0);
        BufferIt buffer_end2 = apply(
            e,
            boost::make_iterator_range(f_halfway, f_end),
            buffer_working2_begin,
            buffer_working2_end,
            buffer_halfway);
        assert(std::distance(buffer_end2, buffer_working1_begin) >= 0);
        return fast_expansion_sum_dispatch< ElimZeros >::apply(
            boost::make_iterator_range(buffer_first, buffer_end1),
            boost::make_iterator_range(buffer_halfway, buffer_end2),
            h_first);
    }
};

template< bool ElimZeros >
struct fast_expansion_prod_impl
{
    template< class ForwardReadableRange1, class ForwardReadableRange2, class IncrementableWritableIterator, class Allocator >
    static IncrementableWritableIterator apply(
        const ForwardReadableRange1& e,
        const ForwardReadableRange2& f,
        IncrementableWritableIterator h_first,
        Allocator alloc)
    {
        BOOST_CONCEPT_ASSERT((concepts::ForwardReadableRange< const ForwardReadableRange1 >));
        BOOST_CONCEPT_ASSERT((concepts::ForwardReadableRange< const ForwardReadableRange2 >));
        BOOST_CONCEPT_ASSERT((concepts::SakeAllocator< Allocator >));
        typedef typename boost::range_value< ForwardReadableRange1 >::type e_value_type;
        typedef typename boost::range_value< ForwardReadableRange2 >::type f_value_type;
        typedef e_value_type T;
        BOOST_MPL_ASSERT((boost::is_same< f_value_type, T >));
        BOOST_CONCEPT_ASSERT((concepts::IncrementableWritableIterator< IncrementableWritableIterator, T >));
        typedef dynamic_array< T, Allocator > buffer_type;
        typedef typename buffer_type::iterator buffer_it_type;
        BOOST_CONCEPT_ASSERT((concepts::ForwardReadableWritableIterator< buffer_it_type >));
        typedef typename buffer_type::size_type buffer_size_type;
        typedef typename boost::range_difference< ForwardReadableRange1 >::type e_difference_type;
        typedef typename boost::range_difference< ForwardReadableRange2 >::type f_difference_type;
        e_difference_type e_distance = boost::distance(e);
        f_difference_type f_distance = boost::distance(f);
        if(e_distance == 0 || f_distance == 0)
            return h_first;
        // Let E = e_distance, F = f_distance, and assume E >= F > 1.
        // Let f = f1 + f2 be a splitting of f into 2 expansions of size floor(F/2) and ceil(F/2).
        // We need 2 * E * F total space to store the partial products e * f1 and e * f2, after which they will be added
        // and the result put in h.
        // If not parallelized, the working buffers used to compute the partial products may be the same, hence
        //     buffer_size(E,F) = 2 * E * F + buffer_size(E,ceil(F/2))
        // and so buffer_size(E,F) <= 5 * E * (F - 1) (this isn't tight, but it's simple).
        // If the working buffers need to be disjoint, then
        //     buffer_size(E,F) = 2 * E * F + buffer_size(E,floor(F/2)) + buffer_size(E,ceil(F/2))
        // and so buffer_size(E,F) <= 2 * E * F * ceil(log2(F))
        buffer_type buffer(alloc);
        buffer.resize_no_copy(static_cast< buffer_size_type >(5 * e_distance * (f_distance - 1)));
        return e_distance >= f_distance ?
               fast_expansion_prod_iteration< ElimZeros >::apply(e, f, buffer.begin(), buffer.end(), h_first) :
               fast_expansion_prod_iteration< ElimZeros >::apply(f, e, buffer.begin(), buffer.end(), h_first);
    }
};

} // namespace detail_fast_expansion_prod

template< class ForwardReadableRange1, class ForwardReadableRange2, class IncrementableWritableIterator >
inline IncrementableWritableIterator
fast_expansion_prod(
    const ForwardReadableRange1& e,
    const ForwardReadableRange2& f,
    IncrementableWritableIterator h_first)
{ return fast_expansion_prod(e, f, h_first, new_delete_allocator<>()); }

template< class ForwardReadableRange1, class ForwardReadableRange2, class IncrementableWritableIterator, class Allocator >
inline IncrementableWritableIterator
fast_expansion_prod(
    const ForwardReadableRange1& e,
    const ForwardReadableRange2& f,
    IncrementableWritableIterator h_first,
    Allocator alloc)
{ return detail_fast_expansion_prod::fast_expansion_prod_impl< false >::apply(e, f, h_first, alloc); }

template< class ForwardReadableRange1, class ForwardReadableRange2, class IncrementableWritableIterator >
inline IncrementableWritableIterator
fast_expansion_prod_zeroelim(
    const ForwardReadableRange1& e,
    const ForwardReadableRange2& f,
    IncrementableWritableIterator h_first)
{ return fast_expansion_prod_zeroelim(e, f, h_first, new_delete_allocator<>()); }

template< class ForwardReadableRange1, class ForwardReadableRange2, class IncrementableWritableIterator, class Allocator >
inline IncrementableWritableIterator
fast_expansion_prod_zeroelim(
    const ForwardReadableRange1& e,
    const ForwardReadableRange2& f,
    IncrementableWritableIterator h_first,
    Allocator alloc)
{ return detail_fast_expansion_prod::fast_expansion_prod_impl< true >::apply(e, f, h_first, alloc); }

} // namespace expansion_arithmetic

} // namespace sake

#endif // #ifndef _SAKE_EXPANSION_ARITHMETIC_FAST_EXPANSION_PROD_HPP_
