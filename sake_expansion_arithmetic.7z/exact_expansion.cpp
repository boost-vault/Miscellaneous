/*******************************************************************************
 * expansion_arithmetic/exact_expansion.cpp
 *
 * Copyright 2009, Jeffrey Hellrung.
 * Distributed under the Boost Software License, Version 1.0.  (See accompanying
 * file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
 ******************************************************************************/

#include <sake/expansion_arithmetic/exact_expansion.ipp>

namespace sake
{

template class exact_expansion< float >;
template class exact_expansion< double >;

} // namespace sake
