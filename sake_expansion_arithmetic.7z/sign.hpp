/*******************************************************************************
 * expansion_arithmetic/sign.hpp
 *
 * Copyright 2009, Jeffrey Hellrung.
 * Distributed under the Boost Software License, Version 1.0.  (See accompanying
 * file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
 *
 * expansion_arithmetic::sign(const BidirectionalReadableRange& e) -> sign_t
 *
 * sign returns the sign of the expansion in e.
 * If e is empty, returns 0 (same as if all components of e were 0).
 ******************************************************************************/

#ifndef _SAKE_EXPANSION_ARITHMETIC_SIGN_HPP_
#define _SAKE_EXPANSION_ARITHMETIC_SIGN_HPP_

#include <boost/concept/assert.hpp>
#include <boost/range/begin.hpp>
#include <boost/range/end.hpp>
#include <boost/range/iterator.hpp>
#include <boost/range/value_type.hpp>

#include <sake/core/math/sign.hpp>
#include <sake/core/math/sign_t.hpp>
#include <sake/core/range/concepts.hpp>

namespace sake
{

namespace expansion_arithmetic
{

template< class BidirectionalReadableRange >
sign_t sign(const BidirectionalReadableRange& e)
{
    BOOST_CONCEPT_ASSERT((concepts::BidirectionalReadableRange< BidirectionalReadableRange >));
    typedef typename boost::range_value< const BidirectionalReadableRange >::type e_value_type;
    typedef typename boost::range_iterator< const BidirectionalReadableRange >::type e_it_type;
    typedef e_value_type T;
    sign_t s = sign_t::zero_value;
    e_it_type e_begin = boost::begin(e), e_it = boost::end(e);
    while(e_it != e_begin && (s = adl::sign(*(--e_it))) == zero);
    return s;
}

} // expansion_arithmetic

} // namespace sake

#endif // #ifndef _SAKE_EXPANSION_ARITHMETIC_SIGN_HPP_
