/*******************************************************************************
 * expansion_arithmetic/rational_expansion.hpp
 *
 * Copyright 2009, Jeffrey Hellrung.
 * Distributed under the Boost Software License, Version 1.0.  (See accompanying
 * file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
 *
 * class rational_expansion< T, Allocator >
 ******************************************************************************/

#ifndef _SAKE_EXPANSION_ARITHMETIC_RATIONAL_EXPANSION_HPP_
#define _SAKE_EXPANSION_ARITHMETIC_RATIONAL_EXPANSION_HPP_

#include <cmath>

#include <memory>

#include <boost/concept/assert.hpp>
#include <boost/mpl/assert.hpp>
#include <boost/preprocessor/facilities/identity.hpp>
#include <boost/type_traits/is_convertible.hpp>
#include <boost/utility/enable_if.hpp>

#include <sake/boost_ext/move/movable.hpp>
#include <sake/boost_ext/move/move_fwd.hpp>
#include <sake/core/math/sign_t.hpp>
#include <sake/core/math/zero.hpp>
#include <sake/core/memory/new_delete_allocator.hpp>
#include <sake/core/memory/SakeAllocator.hpp>
#include <sake/core/utility/call_traits.hpp>
#include <sake/expansion_arithmetic/exact_expansion.hpp>
#include <sake/expansion_arithmetic/expansion_fwd.hpp>

namespace sake
{

/*******************************************************************************
 * class rational_expansion< T, Allocator >
 ******************************************************************************/

template< class T, class Allocator /* = new_delete_allocator<> */ >
class rational_expansion
{
    BOOST_STATIC_ASSERT((std::numeric_limits<T>::is_iec559));
    BOOST_CONCEPT_ASSERT((concepts::SakeAllocator< Allocator >));
public:
    typedef T component_type;
    typedef exact_expansion< T, Allocator > exact_expansion_type;
    typedef Allocator allocator_type;

private:
    typedef typename call_traits< component_type >::param_type component_param_type;

    typedef typename call_traits< exact_expansion_type >::const_lvalue_param_type exact_expansion_const_lvalue_param_type;
    typedef typename call_traits< exact_expansion_type >::lvalue_param_type       exact_expansion_lvalue_param_type;
    typedef typename call_traits< exact_expansion_type >::rvalue_param_type       exact_expansion_rvalue_param_type;

    SAKE_BOOST_EXT_MOVABLE_COPYABLE_DEFINE_COPY_ASSIGN_FROM_SWAP( rational_expansion )
public:

    rational_expansion();
    //rational_expansion(const rational_expansion& other);
    rational_expansion(this_rvalue_param_type other);

    explicit rational_expansion(const allocator_type& alloc);
    explicit rational_expansion(component_param_type x, const allocator_type& alloc = allocator_type());

    rational_expansion(exact_expansion_const_lvalue_param_type other);
    rational_expansion(exact_expansion_lvalue_param_type other);
    rational_expansion(exact_expansion_rvalue_param_type other);

    rational_expansion(
        exact_expansion_const_lvalue_param_type numerator,
        exact_expansion_const_lvalue_param_type denominator);
    rational_expansion(
        exact_expansion_lvalue_param_type numerator,
        exact_expansion_lvalue_param_type denominator);
    rational_expansion(
        exact_expansion_rvalue_param_type numerator,
        exact_expansion_rvalue_param_type denominator);

    template< class Allocator2 >
    explicit rational_expansion(
        const rational_expansion< T, Allocator2 >& other,
        const allocator_type& alloc = allocator_type());

    template< class BidirectionalReadableExpansion >
    explicit rational_expansion(
        const BidirectionalReadableExpansion& source,
        typename boost::disable_if< boost::is_convertible< BidirectionalReadableExpansion, allocator_type > >::type* = 0,
        typename boost::disable_if< boost::is_convertible< BidirectionalReadableExpansion, component_type > >::type* = 0,
        typename boost::disable_if< boost::is_convertible< BidirectionalReadableExpansion, exact_expansion_type > >::type* = 0);
    template< class BidirectionalReadableExpansion >
    rational_expansion(
        const BidirectionalReadableExpansion& source,
        const allocator_type& alloc,
        typename boost::disable_if< boost::is_convertible< BidirectionalReadableExpansion, component_type > >::type* = 0);
    template< class BidirectionalReadableExpansion1, class BidirectionalReadableExpansion2 >
    rational_expansion(
        const BidirectionalReadableExpansion1& numerator,
        const BidirectionalReadableExpansion2& denominator,
        typename boost::disable_if< boost::mpl::and_<
            boost::is_convertible< BidirectionalReadableExpansion1, exact_expansion_type >,
            boost::is_convertible< BidirectionalReadableExpansion2, exact_expansion_type >
        > >::type* = 0,
        typename boost::disable_if< boost::mpl::and_<
            boost::is_convertible< BidirectionalReadableExpansion1, component_type >,
            boost::is_convertible< BidirectionalReadableExpansion2, allocator_type >
        > >::type* = 0);
    template< class BidirectionalReadableExpansion1, class BidirectionalReadableExpansion2 >
    rational_expansion(
        const BidirectionalReadableExpansion1& numerator,
        const BidirectionalReadableExpansion2& denominator,
        const allocator_type& alloc);

    //~rational_expansion();

    //rational_expansion& operator=(const rational_expansion& other);
    rational_expansion& operator=(this_rvalue_param_type other);

    rational_expansion& operator=(component_param_type x);
    rational_expansion& operator=(exact_expansion_const_lvalue_param_type other);
    rational_expansion& operator=(exact_expansion_lvalue_param_type other);
    rational_expansion& operator=(exact_expansion_rvalue_param_type other);

    template< class BidirectionalReadableExpansion >
    void assign(const BidirectionalReadableExpansion& source);
    template< class BidirectionalReadableExpansion1, class BidirectionalReadableExpansion2 >
    void assign(
        const BidirectionalReadableExpansion1& numerator,
        const BidirectionalReadableExpansion2& denominator);

    void swap(rational_expansion& other);

    bool zero() const;
    sign_t sign() const;
    void compress() const;
    void clear();

#define SAKE_RATIONAL_EXPANSION_DECLARE_OP_ASSIGN( Op, Name ) \
    void assign_##Name(const rational_expansion& left, const rational_expansion& right); \
    void assign_##Name(const rational_expansion& left, const exact_expansion_type& right); \
    void assign_##Name(const rational_expansion& left, component_param_type right); \
    void assign_##Name(const exact_expansion_type& left, const rational_expansion& right); \
    void assign_##Name(component_param_type left, const rational_expansion& right); \
    void assign_##Name(const exact_expansion_type& left, const exact_expansion_type& right); \
    void assign_##Name(const exact_expansion_type& left, component_param_type right); \
    void assign_##Name(component_param_type left, const exact_expansion_type& right); \
    void assign_##Name(component_param_type left, component_param_type right); \
    rational_expansion& operator Op##=(const rational_expansion& x); \
    rational_expansion& operator Op##=(const exact_expansion_type& x); \
    rational_expansion& operator Op##=(component_param_type x);
    SAKE_RATIONAL_EXPANSION_DECLARE_OP_ASSIGN( +, add  )
    SAKE_RATIONAL_EXPANSION_DECLARE_OP_ASSIGN( -, sub  )
    SAKE_RATIONAL_EXPANSION_DECLARE_OP_ASSIGN( *, mult )
    SAKE_RATIONAL_EXPANSION_DECLARE_OP_ASSIGN( /, div  )
#undef SAKE_RATIONAL_EXPANSION_DECLARE_OP_ASSIGN

    void assign_negate(const rational_expansion& x);
    void assign_negate(const exact_expansion_type& x);
    void assign_negate(component_param_type x);
    void assign_invert(const rational_expansion& x);
    void assign_invert(const exact_expansion_type& x);
    void assign_invert(component_param_type x);

    rational_expansion& negate_ip();
    rational_expansion& invert_ip();

    rational_expansion negate_copy() const;
    rational_expansion invert_copy() const;
    rational_expansion operator-() const;

    bool equals(const rational_expansion& x) const;
    bool equals(const exact_expansion_type& x) const;
    bool equals(component_param_type x) const;

    sign_t compare(const rational_expansion& x) const;
    sign_t compare(const exact_expansion_type& x) const;
    sign_t compare(component_param_type x) const;

    allocator_type get_allocator() const;

    const exact_expansion_type& numerator() const;
    const exact_expansion_type& denominator() const;

private:
    mutable exact_expansion_type m_numerator;
    mutable exact_expansion_type m_denominator;
};

/*******************************************************************************
 * rational_expansion free arithmetic operators
 ******************************************************************************/

#define SAKE_RATIONAL_EXPANSION_DEFINE_BIN_OP_HELPER( Op, Name, LeftType, RightType ) \
template< class T, class Allocator > \
inline rational_expansion< T, Allocator > \
operator Op (const LeftType() & left, const RightType() & right) \
{ \
    assert(left.get_allocator() == right.get_allocator()); \
    rational_expansion< T, Allocator > temp(left.get_allocator()); \
    temp.assign_##Name(left, right); \
    return temp; \
}
#define SAKE_rational_expansionTAlloc() rational_expansion< T, Allocator >
#define SAKE_exact_expansionTAlloc() exact_expansion< T, Allocator >
#define SAKE_RATIONAL_EXPANSION_DEFINE_BIN_OP( Op, Name ) \
SAKE_RATIONAL_EXPANSION_DEFINE_BIN_OP_HELPER( Op, Name, SAKE_rational_expansionTAlloc, SAKE_rational_expansionTAlloc ) \
SAKE_RATIONAL_EXPANSION_DEFINE_BIN_OP_HELPER( Op, Name, SAKE_rational_expansionTAlloc, SAKE_exact_expansionTAlloc ) \
SAKE_RATIONAL_EXPANSION_DEFINE_BIN_OP_HELPER( Op, Name, SAKE_exact_expansionTAlloc, SAKE_rational_expansionTAlloc )
SAKE_RATIONAL_EXPANSION_DEFINE_BIN_OP( +, add  )
SAKE_RATIONAL_EXPANSION_DEFINE_BIN_OP( -, sub  )
SAKE_RATIONAL_EXPANSION_DEFINE_BIN_OP( *, mult )
SAKE_RATIONAL_EXPANSION_DEFINE_BIN_OP( /, div  )
#undef SAKE_rational_expansionTAlloc
#undef SAKE_exact_expansionTAlloc
#undef SAKE_RATIONAL_EXPANSION_DEFINE_BIN_OP_HELPER
#undef SAKE_RATIONAL_EXPANSION_DEFINE_BIN_OP
#define SAKE_RATIONAL_EXPANSION_DEFINE_BIN_OP( Op, Name ) \
template< class T, class Allocator > \
inline rational_expansion< T, Allocator > \
operator Op (const rational_expansion< T, Allocator >& left, const T& right) \
{ \
    rational_expansion< T, Allocator > temp(left.get_allocator()); \
    temp.assign_##Name(left, right); \
    return temp; \
} \
template< class T, class Allocator > \
inline rational_expansion< T, Allocator > \
operator Op (const T& left, const rational_expansion< T, Allocator >& right) \
{ \
    rational_expansion< T, Allocator > temp(right.get_allocator()); \
    temp.assign_##Name(left, right); \
    return temp; \
}
SAKE_RATIONAL_EXPANSION_DEFINE_BIN_OP( +, add  )
SAKE_RATIONAL_EXPANSION_DEFINE_BIN_OP( -, sub  )
SAKE_RATIONAL_EXPANSION_DEFINE_BIN_OP( *, mult )
SAKE_RATIONAL_EXPANSION_DEFINE_BIN_OP( /, div  )
#undef SAKE_RATIONAL_EXPANSION_DEFINE_BIN_OP

/*******************************************************************************
 * rational_expansion free comparison operators
 ******************************************************************************/

template< class T, class Allocator >
inline bool operator==(const rational_expansion< T, Allocator >& left, const rational_expansion< T, Allocator >& right)
{ return left.equals(right); }
template< class T, class Allocator >
inline bool operator==(const rational_expansion< T, Allocator >& left, const exact_expansion< T, Allocator >& right)
{ return left.equals(right); }
template< class T, class Allocator >
inline bool operator==(const rational_expansion< T, Allocator >& left, const T& right)
{ return left.equals(right); }
template< class T, class Allocator >
inline bool operator==(const exact_expansion< T, Allocator >& left, const rational_expansion< T, Allocator >& right)
{ return right.equals(right); }
template< class T, class Allocator >
inline bool operator==(const T& left, const rational_expansion< T, Allocator >& right)
{ return right.equals(right); }
template< class T, class Allocator >
inline bool operator==(const rational_expansion< T, Allocator >& left, zero_t)
{ return left.zero(); }
template< class T, class Allocator >
inline bool operator==(zero_t, const rational_expansion< T, Allocator >& right)
{ return right.zero(); }

template< class T, class Allocator >
inline bool operator!=(const rational_expansion< T, Allocator >& left, const rational_expansion< T, Allocator >& right)
{ return !(left == right); }
template< class T, class Allocator >
inline bool operator!=(const rational_expansion< T, Allocator >& left, const exact_expansion< T, Allocator >& right)
{ return !(left == right); }
template< class T, class Allocator >
inline bool operator!=(const rational_expansion< T, Allocator >& left, const T& right)
{ return !(left == right); }
template< class T, class Allocator >
inline bool operator!=(const exact_expansion< T, Allocator >& left, const rational_expansion< T, Allocator >& right)
{ return !(left == right); }
template< class T, class Allocator >
inline bool operator!=(const T& left, const rational_expansion< T, Allocator >& right)
{ return !(left == right); }
template< class T, class Allocator >
inline bool operator!=(const rational_expansion< T, Allocator >& left, zero_t)
{ return !(left == zero); }
template< class T, class Allocator >
inline bool operator!=(zero_t, const rational_expansion< T, Allocator >& right)
{ return !(zero == right); }

#define SAKE_RATIONAL_EXPANSION_DEFINE_COMPARISON_OP( Op ) \
template< class T, class Allocator > \
inline bool operator Op (const rational_expansion< T, Allocator >& left, const rational_expansion< T, Allocator >& right) \
{ return left.compare(right) Op zero; } \
template< class T, class Allocator > \
inline bool operator Op (const rational_expansion< T, Allocator >& left, const exact_expansion< T, Allocator >& right) \
{ return left.compare(right) Op zero; } \
template< class T, class Allocator > \
inline bool operator Op (const rational_expansion< T, Allocator >& left, const T& right) \
{ return left.compare(right) Op zero; } \
template< class T, class Allocator > \
inline bool operator Op (const exact_expansion< T, Allocator >& left, const rational_expansion< T, Allocator >& right) \
{ return left.compare(right) Op zero; } \
template< class T, class Allocator > \
inline bool operator Op (const T& left, const rational_expansion< T, Allocator >& right) \
{ return zero Op right.compare(left); } \
template< class T, class Allocator > \
inline bool operator Op (const rational_expansion< T, Allocator >& left, zero_t) \
{ return left.sign() Op zero; } \
template< class T, class Allocator > \
inline bool operator Op (zero_t, const rational_expansion< T, Allocator >& right) \
{ return zero Op right.sign(); }
SAKE_RATIONAL_EXPANSION_DEFINE_COMPARISON_OP( <  )
SAKE_RATIONAL_EXPANSION_DEFINE_COMPARISON_OP( >  )
SAKE_RATIONAL_EXPANSION_DEFINE_COMPARISON_OP( <= )
SAKE_RATIONAL_EXPANSION_DEFINE_COMPARISON_OP( >= )
#undef SAKE_RATIONAL_EXPANSION_DEFINE_COMPARISON_OP

/*******************************************************************************
 * rational_expansion free functions
 ******************************************************************************/

template< class T, class Allocator >
inline void
swap(rational_expansion< T, Allocator >& x0, rational_expansion< T, Allocator >& x1)
{ x0.swap(x1); }

/*******************************************************************************
 * rational_expansion inline and template member functions
 ******************************************************************************/

template< class T, class Allocator >
rational_expansion< T, Allocator >::
rational_expansion()
{ }

template< class T, class Allocator >
rational_expansion< T, Allocator >::
rational_expansion(this_rvalue_param_type other)
    : m_numerator(boost::move(other.m_numerator)),
      m_denominator(boost::move(other.m_denominator))
{ }

template< class T, class Allocator >
rational_expansion< T, Allocator >::
rational_expansion(const allocator_type& alloc)
    : m_numerator(alloc),
      m_denominator(alloc)
{ }

template< class T, class Allocator >
rational_expansion< T, Allocator >::
rational_expansion(component_param_type x, const allocator_type& alloc)
    : m_numerator(x, alloc),
      m_denominator(alloc)
{ }

template< class T, class Allocator >
rational_expansion< T, Allocator >::
rational_expansion(exact_expansion_const_lvalue_param_type other)
    : m_numerator(static_cast< const exact_expansion_type& >(other)),
      m_denominator(other.get_allocator())
{ }

template< class T, class Allocator >
rational_expansion< T, Allocator >::
rational_expansion(exact_expansion_lvalue_param_type other)
    : m_numerator(static_cast< const exact_expansion_type& >(other)),
      m_denominator(other.get_allocator())
{ }

template< class T, class Allocator >
rational_expansion< T, Allocator >::
rational_expansion(exact_expansion_rvalue_param_type other)
    : m_numerator(boost::move(static_cast< exact_expansion_type& >(other))),
      m_denominator(other.get_allocator())
{ }

template< class T, class Allocator >
rational_expansion< T, Allocator >::
rational_expansion(
    exact_expansion_const_lvalue_param_type numerator,
    exact_expansion_const_lvalue_param_type denominator)
    : m_numerator(static_cast< const exact_expansion_type& >(numerator)),
      m_denominator(static_cast< const exact_expansion_type& >(denominator), numerator.get_allocator())
{ }

template< class T, class Allocator >
rational_expansion< T, Allocator >::
rational_expansion(
    exact_expansion_lvalue_param_type numerator,
    exact_expansion_lvalue_param_type denominator)
    : m_numerator(static_cast< const exact_expansion_type& >(numerator)),
      m_denominator(static_cast< const exact_expansion_type& >(denominator), numerator.get_allocator())
{ }

template< class T, class Allocator >
rational_expansion< T, Allocator >::
rational_expansion(
    exact_expansion_rvalue_param_type numerator,
    exact_expansion_rvalue_param_type denominator)
    : m_numerator(boost::move(numerator)),
      m_denominator(boost::move(denominator))
{ assert(m_numerator.get_allocator() == m_denominator.get_allocator()); }

template< class T, class Allocator >
template< class Allocator2 >
rational_expansion< T, Allocator >::
rational_expansion(
    const rational_expansion< T, Allocator2 >& other,
    const allocator_type& alloc)
    : m_numerator(other.m_numerator, alloc),
      m_denominator(other.m_denominator, alloc)
{ }

template< class T, class Allocator >
template< class BidirectionalReadableExpansion >
rational_expansion< T, Allocator >::
rational_expansion(
    const BidirectionalReadableExpansion& source,
    typename boost::disable_if< boost::is_convertible< BidirectionalReadableExpansion, allocator_type > >::type*,
    typename boost::disable_if< boost::is_convertible< BidirectionalReadableExpansion, component_type > >::type*,
    typename boost::disable_if< boost::is_convertible< BidirectionalReadableExpansion, exact_expansion_type > >::type*)
    : m_numerator(source)
{ BOOST_MPL_ASSERT_NOT((boost::is_convertible< BidirectionalReadableExpansion, rational_expansion >)); }

template< class T, class Allocator >
template< class BidirectionalReadableExpansion >
rational_expansion< T, Allocator >::
rational_expansion(
    const BidirectionalReadableExpansion& source,
    const allocator_type& alloc,
    typename boost::disable_if< boost::is_convertible< BidirectionalReadableExpansion, component_type > >::type*)
    : m_numerator(source, alloc),
      m_denominator(alloc)
{ BOOST_MPL_ASSERT_NOT((boost::is_convertible< BidirectionalReadableExpansion, rational_expansion >)); }

template< class T, class Allocator >
template< class BidirectionalReadableExpansion1, class BidirectionalReadableExpansion2 >
rational_expansion< T, Allocator >::
rational_expansion(
    const BidirectionalReadableExpansion1& numerator,
    const BidirectionalReadableExpansion2& denominator,
    typename boost::disable_if< boost::mpl::and_<
        boost::is_convertible< BidirectionalReadableExpansion1, exact_expansion_type >,
        boost::is_convertible< BidirectionalReadableExpansion2, exact_expansion_type >
    > >::type*,
    typename boost::disable_if< boost::mpl::and_<
        boost::is_convertible< BidirectionalReadableExpansion1, component_type >,
        boost::is_convertible< BidirectionalReadableExpansion2, allocator_type >
    > >::type*)
    : m_numerator(numerator),
      m_denominator(denominator)
{ }

template< class T, class Allocator >
template< class BidirectionalReadableExpansion1, class BidirectionalReadableExpansion2 >
rational_expansion< T, Allocator >::
rational_expansion(
    const BidirectionalReadableExpansion1& numerator,
    const BidirectionalReadableExpansion2& denominator,
    const allocator_type& alloc)
    : m_numerator(numerator, alloc),
      m_denominator(denominator, alloc)
{ }

template< class T, class Allocator >
inline rational_expansion< T, Allocator >&
rational_expansion< T, Allocator >::
operator=(this_rvalue_param_type other)
{
    m_numerator = boost::move(other.m_numerator);
    m_denominator = boost::move(other.m_denominator);
    return *this;
}

template< class T, class Allocator >
inline rational_expansion< T, Allocator >&
rational_expansion< T, Allocator >::
operator=(component_param_type x)
{
    m_numerator = x;
    m_denominator.clear();
    return *this;
}

template< class T, class Allocator >
inline rational_expansion< T, Allocator >&
rational_expansion< T, Allocator >::
operator=(exact_expansion_const_lvalue_param_type other)
{
    m_numerator = static_cast< const exact_expansion_type& >(other);
    m_denominator.clear();
    return *this;
}

template< class T, class Allocator >
inline rational_expansion< T, Allocator >&
rational_expansion< T, Allocator >::
operator=(exact_expansion_lvalue_param_type other)
{
    m_numerator = static_cast< const exact_expansion_type& >(other);
    m_denominator.clear();
    return *this;
}

template< class T, class Allocator >
inline rational_expansion< T, Allocator >&
rational_expansion< T, Allocator >::
operator=(exact_expansion_rvalue_param_type other)
{
    m_numerator = boost::move(static_cast< exact_expansion_type& >(other));
    m_denominator.clear();
    return *this;
}

template< class T, class Allocator >
template< class BidirectionalReadableExpansion >
inline void
rational_expansion< T, Allocator >::
assign(const BidirectionalReadableExpansion& source)
{
    m_denominator.clear();
    m_numerator.assign(source);
}

template< class T, class Allocator >
template< class BidirectionalReadableExpansion1, class BidirectionalReadableExpansion2 >
inline void
rational_expansion< T, Allocator >::
assign(
    const BidirectionalReadableExpansion1& numerator,
    const BidirectionalReadableExpansion2& denominator)
{
    m_numerator.assign(numerator);
    m_denominator.assign(denominator);
}

template< class T, class Allocator >
inline void
rational_expansion< T, Allocator >::
swap(rational_expansion& other)
{
    assert(get_allocator() == other.get_allocator());
    m_numerator.swap(other.m_numerator);
    m_denominator.swap(other.m_denominator);
}

template< class T, class Allocator >
inline bool
rational_expansion< T, Allocator >::
zero() const
{ return m_numerator.empty(); }

template< class T, class Allocator >
inline sign_t
rational_expansion< T, Allocator >::
sign() const
{ return m_denominator.empty() ? m_numerator.sign() : m_numerator.sign() * m_denominator.sign(); }

template< class T, class Allocator >
inline void
rational_expansion< T, Allocator >::
compress() const
{
    if(zero())
        m_denominator.clear();
    else {
        m_numerator.compress();
        m_denominator.compress();
    }
}

template< class T, class Allocator >
inline void
rational_expansion< T, Allocator >::
clear()
{
    m_numerator.clear();
    m_denominator.clear();
}

template< class T, class Allocator >
inline void
rational_expansion< T, Allocator >::
assign_add(const exact_expansion_type& left, const rational_expansion& right)
{ assign_add(right, left); }

template< class T, class Allocator >
inline void
rational_expansion< T, Allocator >::
assign_add(component_param_type left, const rational_expansion& right)
{ assign_add(right, left); }

template< class T, class Allocator >
inline void rational_expansion< T, Allocator >::
assign_mult(const exact_expansion_type& left, const rational_expansion& right)
{ assign_mult(right, left); }

template< class T, class Allocator >
inline void rational_expansion< T, Allocator >::
assign_mult(component_param_type left, const rational_expansion& right)
{ assign_mult(right, left); }

template< class T, class Allocator >
inline void rational_expansion< T, Allocator >::
assign_mult(const rational_expansion& left, const exact_expansion_type& right)
{
    m_numerator.assign_mult(left.m_numerator, right);
    m_denominator = left.m_denominator;
}

template< class T, class Allocator >
inline void rational_expansion< T, Allocator >::
assign_mult(const rational_expansion& left, component_param_type right)
{
    m_numerator.assign_mult(left.m_numerator, right);
    m_denominator = left.m_denominator;
}

#define SAKE_RATIONAL_EXPANSION_DEFINE_OP_ASSIGN_HELPER( Op, Name, LeftArg, RightArg ) \
template< class T, class Allocator > \
inline void \
rational_expansion< T, Allocator >:: \
assign_##Name(LeftArg() left, RightArg() right) \
{ \
    m_numerator.assign_##Name(left, right); \
    m_denominator.clear(); \
}
#define SAKE_const_exact_expansion_type() const exact_expansion_type&
#define SAKE_RATIONAL_EXPANSION_DEFINE_OP_ASSIGN( Op, Name ) \
SAKE_RATIONAL_EXPANSION_DEFINE_OP_ASSIGN_HELPER( Op, Name, SAKE_const_exact_expansion_type, SAKE_const_exact_expansion_type ) \
SAKE_RATIONAL_EXPANSION_DEFINE_OP_ASSIGN_HELPER( Op, Name, SAKE_const_exact_expansion_type, BOOST_PP_IDENTITY( component_param_type ) ) \
SAKE_RATIONAL_EXPANSION_DEFINE_OP_ASSIGN_HELPER( Op, Name, BOOST_PP_IDENTITY( component_param_type ), SAKE_const_exact_expansion_type ) \
SAKE_RATIONAL_EXPANSION_DEFINE_OP_ASSIGN_HELPER( Op, Name, BOOST_PP_IDENTITY( component_param_type ), BOOST_PP_IDENTITY( component_param_type ) )
SAKE_RATIONAL_EXPANSION_DEFINE_OP_ASSIGN( +, add  )
SAKE_RATIONAL_EXPANSION_DEFINE_OP_ASSIGN( -, sub  )
SAKE_RATIONAL_EXPANSION_DEFINE_OP_ASSIGN( *, mult )
#undef SAKE_const_exact_expansion_type
#undef SAKE_RATIONAL_EXPANSION_DEFINE_OP_ASSIGN_HELPER
#undef SAKE_RATIONAL_EXPANSION_DEFINE_OP_ASSIGN

#define SAKE_RATIONAL_EXPANSION_DEFINE_OP_ASSIGN( Op, Name ) \
template< class T, class Allocator > \
inline rational_expansion< T, Allocator >& rational_expansion< T, Allocator >:: \
operator Op##=(const rational_expansion& right) \
{ \
    assign_##Name(*this, right); \
    return *this; \
} \
template< class T, class Allocator > \
inline rational_expansion< T, Allocator >& rational_expansion< T, Allocator >:: \
operator Op##=(const exact_expansion_type& right) \
{ \
    assign_##Name(*this, right); \
    return *this; \
} \
template< class T, class Allocator > \
inline rational_expansion< T, Allocator >& rational_expansion< T, Allocator >:: \
operator Op##=(component_param_type right) \
{ \
    assign_##Name(*this, right); \
    return *this; \
}
SAKE_RATIONAL_EXPANSION_DEFINE_OP_ASSIGN( +, add  )
SAKE_RATIONAL_EXPANSION_DEFINE_OP_ASSIGN( -, sub  )
SAKE_RATIONAL_EXPANSION_DEFINE_OP_ASSIGN( *, mult )
SAKE_RATIONAL_EXPANSION_DEFINE_OP_ASSIGN( /, div  )
#undef SAKE_RATIONAL_EXPANSION_DEFINE_OP_ASSIGN

template< class T, class Allocator >
inline void
rational_expansion< T, Allocator >::
assign_negate(const rational_expansion& x)
{
    m_numerator.assign_negate(x.m_numerator);
    m_denominator = x.m_denominator;
}

template< class T, class Allocator >
inline void
rational_expansion< T, Allocator >::
assign_negate(const exact_expansion_type& x)
{
    m_numerator.assign_negate(x);
    m_denominator.clear();
}

template< class T, class Allocator >
inline void
rational_expansion< T, Allocator >::
assign_negate(component_param_type x)
{
    m_numerator.assign_negate(x);
    m_denominator.clear();
}

template< class T, class Allocator >
inline rational_expansion< T, Allocator >&
rational_expansion< T, Allocator >::
negate_ip()
{
    m_numerator.negate_ip();
    return *this;
}

template< class T, class Allocator >
inline rational_expansion< T, Allocator >
rational_expansion< T, Allocator >::
negate_copy() const
{
    rational_expansion temp(get_allocator());
    temp.assign_negate(*this);
    return temp;
}

template< class T, class Allocator >
inline rational_expansion< T, Allocator >
rational_expansion< T, Allocator >::
invert_copy() const
{
    rational_expansion temp(get_allocator());
    temp.assign_invert(*this);
    return temp;
}

template< class T, class Allocator >
inline rational_expansion< T, Allocator >
rational_expansion< T, Allocator >::
operator-() const
{ return negate_copy(); }

template< class T, class Allocator >
inline typename rational_expansion< T, Allocator >::allocator_type
rational_expansion< T, Allocator >::
get_allocator() const
{
    assert(m_numerator.get_allocator() == m_denominator.get_allocator());
    return m_numerator.get_allocator();
}

template< class T, class Allocator >
inline const typename rational_expansion< T, Allocator >::exact_expansion_type&
rational_expansion< T, Allocator >::
numerator() const
{ return m_numerator; }

template< class T, class Allocator >
inline const typename rational_expansion< T, Allocator >::exact_expansion_type&
rational_expansion< T, Allocator >::
denominator() const
{ return m_denominator; }

} // namespace sake

#endif // #ifndef _SAKE_EXPANSION_ARITHMETIC_RATIONAL_EXPANSION_HPP_
