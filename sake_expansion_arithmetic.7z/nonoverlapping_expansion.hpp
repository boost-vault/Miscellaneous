/*******************************************************************************
 * expansion_arithmetic/nonoverlapping_expansion.hpp
 *
 * Copyright 2009, Jeffrey Hellrung.
 * Distributed under the Boost Software License, Version 1.0.  (See accompanying
 * file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
 *
 * expansion_arithmetic::sorted_and_nonoverlapping(T a, T b) -> bool
 * struct expansion_arithmetic::functional::sorted_and_nonoverlapping<T>
 * expansion_arithmetic::nonoverlapping_expansion(const SinglePassReadableRange& e) -> bool
 *
 * nonoverlapping_expansion returns whether the given expansion is
 * nonoverlapping.
 ******************************************************************************/

#ifndef _SAKE_EXPANSION_ARITHMETIC_IS_NONOVERLAPPING_EXPANSION_HPP_
#define _SAKE_EXPANSION_ARITHMETIC_IS_NONOVERLAPPING_EXPANSION_HPP_

#include <limits>

#include <boost/concept/assert.hpp>
#include <boost/range/end.hpp>
#include <boost/range/value_type.hpp>
#include <boost/static_assert.hpp>

#include <sake/core/functional/negate.hpp>
#include <sake/core/math/abs.hpp>
#include <sake/core/math/float_ufp.hpp>
#include <sake/core/math/zero.hpp>
#include <sake/core/range/algorithm/find_adjacent.hpp>
#include <sake/core/range/concepts.hpp>
#include <sake/core/utility/call_traits.hpp>

namespace sake
{

namespace expansion_arithmetic
{

template< class T >
inline bool sorted_and_nonoverlapping(T a, T b)
{
    BOOST_STATIC_ASSERT((std::numeric_limits<T>::is_iec559));
    adl::abs_ip(a);
    adl::abs_ip(b);
    if(a == zero || b == zero)
        return true;
    // a     =        1.xxxx * 2^p
    // a_ulp =        0.0001 * 2^p
    // eps   = 2^(-4)
    // a_ufp =        1.0000 * 2^p
    // u     = 1 0000 0      * 2^p
    T a_ufp = float_ufp(a);
    assert(a_ufp <= a && a < 2 * a_ufp);
    static const T up_shifter = 2 / std::numeric_limits<T>::epsilon();
    T u = up_shifter * a_ufp;
    if(b >= u)
        // If b >= u, then b = 1 xxxx 0 * 2^p and a and b are nonoverlapping.
        return true;
    // If b < u, then...
    // b     = 0 xxxx x.xxxx * 2^p (generally)
    // b     = 0 xxxx 0      * 2^p (if a and b are nonoverlapping)
    // ub    = 1 xxxx 0      * 2^p
    // z     =        x.xxxx * 2^p (generally)
    // z     =        0      * 2^p (if a and b are nonoverlapping *and* b > a)
    T ub,z;
    fast_two_sum(u, b, ub, z);
    assert((b > a) || z != zero);
    return z == zero;
}

namespace functional
{

template< class T >
struct sorted_and_nonoverlapping
{
    typedef bool result_type;
private:
    typedef typename call_traits<T>::param_type T_param_type;
public:
    bool operator()(T_param_type a, T_param_type b) const
    { return sake::expansion_arithmetic::sorted_and_nonoverlapping(a,b); }
};

} // namespace functional

template< class SinglePassReadableRange >
inline bool nonoverlapping_expansion(const SinglePassReadableRange& e)
{
    BOOST_CONCEPT_ASSERT((concepts::SinglePassReadableRange< const SinglePassReadableRange >));
    typedef typename boost::range_value< SinglePassReadableRange >::type e_value_type;
    typedef e_value_type T;
    return range::find_adjacent(e, sake::functional::not_(functional::sorted_and_nonoverlapping<T>())) == boost::end(e);
}

} // expansion_arithmetic

} // namespace sake

#endif // #ifndef _SAKE_EXPANSION_ARITHMETIC_IS_NONOVERLAPPING_EXPANSION_HPP_
