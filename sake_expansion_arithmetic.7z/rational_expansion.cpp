/*******************************************************************************
 * expansion_arithmetic/rational_expansion.cpp
 *
 * Copyright 2009, Jeffrey Hellrung.
 * Distributed under the Boost Software License, Version 1.0.  (See accompanying
 * file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
 ******************************************************************************/

#include "rational_expansion.ipp"

namespace sake
{

template class rational_expansion< float >;
template class rational_expansion< double >;

} // namespace sake
