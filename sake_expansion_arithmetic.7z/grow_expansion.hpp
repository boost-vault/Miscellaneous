/*******************************************************************************
 * expansion_arithmetic/grow_expansion.hpp
 *
 * Copyright 2009, Jeffrey Hellrung.
 * Distributed under the Boost Software License, Version 1.0.  (See accompanying
 * file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
 *
 * expansion_arithmetic::grow_expansion[_zeroelim,_unrolled](
 *     const SinglePassReadableRange& e,
 *     const T& b,
 *     IncrementableWritableIterator h_first)
 *     -> IncrementableWritableIterator
 * expansion_arithmetic::grow_expansion[_zeroelim,_unrolled](
 *     ForwardReadableWritableRange& e,
 *     const T& b)
 *     -> boost::range_iterator< ForwardReadableWritableRange >::type
 *
 * grow_expansion adds b to the expansion in e, putting the result in h.
 * Maintains nonoverlapping, strongly nonoverlapping, and nonadjacent.
 * h must have at least size(e) + 1 elements.
 * h may be identical to e, in which case one-past-the-last element of e must be
 * valid.  If _zeroelim is used, it's enough for the last element of e to be 0.
 * Returns the iterator pointing to one-past-the-last element written to h.
 * In the second variants, h is identical to e.
 ******************************************************************************/

#ifndef _SAKE_EXPANSION_ARITHMETIC_GROW_EXPANSION_HPP_
#define _SAKE_EXPANSION_ARITHMETIC_GROW_EXPANSION_HPP_

#include <cassert>

#include <boost/concept/assert.hpp>
#include <boost/mpl/assert.hpp>
#include <boost/range/begin.hpp>
#include <boost/range/end.hpp>
#include <boost/range/iterator.hpp>
#include <boost/range/value_type.hpp>
#include <boost/type_traits/is_same.hpp>

#include <sake/core/functional/equal_to_zero.hpp>
#include <sake/core/iterator/concepts.hpp>
#include <sake/core/iterator/ofilter_iterator.hpp>
#include <sake/core/range/concepts.hpp>
#include <sake/core/range/range_static_size.hpp>
#include <sake/core/range/static_size_iterator_range.hpp>
#include <sake/expansion_arithmetic/nonadjacent_expansion.hpp>
#include <sake/expansion_arithmetic/nonoverlapping_expansion.hpp>
#include <sake/expansion_arithmetic/strongly_nonoverlapping_expansion.hpp>
#include <sake/expansion_arithmetic/two_sum.hpp>

namespace sake
{

namespace expansion_arithmetic
{

/*******************************************************************************
 * grow_expansion(
 *     const SinglePassReadableRange& e,
 *     const T& b,
 *     IncrementableWritableIterator h_first)
 *     -> IncrementableWritableIterator
 ******************************************************************************/

template< class SinglePassReadableRange, class T, class IncrementableWritableIterator >
IncrementableWritableIterator
grow_expansion(
    const SinglePassReadableRange& e,
    const T& b,
    IncrementableWritableIterator h_first)
{
    BOOST_CONCEPT_ASSERT((concepts::SinglePassReadableRange< const SinglePassReadableRange >));
    BOOST_CONCEPT_ASSERT((concepts::IncrementableWritableIterator< IncrementableWritableIterator, T >));
    typedef typename boost::range_value< SinglePassReadableRange >::type e_value_type;
    BOOST_MPL_ASSERT((boost::is_same< e_value_type, T >));
    typedef typename boost::range_iterator< const SinglePassReadableRange >::type e_it_type;
    assert(nonoverlapping_expansion(e));
    T q = b, q_new, h_x;
    for(e_it_type e_it = boost::begin(e), e_end = boost::end(e); e_it != e_end; ++e_it) {
        two_sum(q, *e_it, q_new, h_x);
        q = q_new;
        *h_first = h_x;
        ++h_first;
    }
    *h_first = q;
    return ++h_first;
}

/*******************************************************************************
 * grow_expansion(
 *     ForwardReadableWritableRange& e,
 *     const T& b)
 *     -> boost::range_iterator< ForwardReadableWritableRange >::type
 ******************************************************************************/

template< class ForwardReadableWritableRange, class T >
inline typename boost::range_iterator< ForwardReadableWritableRange >::type
grow_expansion(ForwardReadableWritableRange& e, const T& b)
{
    BOOST_CONCEPT_ASSERT((concepts::ForwardReadableWritableRange< ForwardReadableWritableRange >));
#ifdef SAKE_EXPANSION_ARITHMETIC_ASSERT_INVARIANTS
    bool nonoverlapping = nonoverlapping_expansion(e);
    bool strongly_nonoverlapping = strongly_nonoverlapping_expansion(e);
    bool nonadjacent = nonadjacent_expansion(e);
    typedef typename boost::range_iterator< ForwardReadableWritableRange >::type e_it_type;
    e_it_type e_it = grow_expansion(e, b, boost::begin(e));
    assert(!nonoverlapping || nonoverlapping_expansion(e));
    assert(!strongly_nonoverlapping || strongly_nonoverlapping_expansion(e));
    assert(!nonadjacent || nonadjacent_expansion(e));
    return e_it;
#else
    return grow_expansion(e, b, boost::begin(e));
#endif
}

/*******************************************************************************
 * grow_expansion_zeroelim(
 *     const SinglePassReadableRange& e,
 *     const T& b,
 *     IncrementableWritableIterator h_first)
 *     -> IncrementableWritableIterator
 ******************************************************************************/

template< class SinglePassReadableRange, class T, class IncrementableWritableIterator >
inline IncrementableWritableIterator
grow_expansion_zeroelim(
    const SinglePassReadableRange& e,
    const T& b,
    IncrementableWritableIterator h_first)
{
    BOOST_CONCEPT_ASSERT((concepts::IncrementableWritableIterator< IncrementableWritableIterator, T >));
    return grow_expansion(e, b, make_ofilter_iterator< sake::functional::not_equal_to_zero<T> >(h_first)).base();
}

/*******************************************************************************
 * grow_expansion_zeroelim(
 *     ForwardReadableWritableRange& e,
 *     const T& b)
 *     -> boost::range_iterator< ForwardReadableWritableRange >::type
 ******************************************************************************/

template< class ForwardReadableWritableRange, class T >
inline typename boost::range_iterator< ForwardReadableWritableRange >::type
grow_expansion_zeroelim(ForwardReadableWritableRange& e, const T& b)
{
    BOOST_CONCEPT_ASSERT((concepts::ForwardReadableWritableRange< ForwardReadableWritableRange >));
    return grow_expansion_zeroelim(e, b, boost::begin(e));
}

/*******************************************************************************
 * grow_expansion_unrolled(
 *     const SinglePassReadableRange& e,
 *     const T& b,
 *     IncrementableWritableIterator h_first)
 *     -> IncrementableWritableIterator
 ******************************************************************************/

namespace detail_grow_expansion
{

template< int EN >
struct grow_expansion_iteration
{
    template< class EIt, class T, class HIt >
    static void apply(EIt& e_it, T& q, HIt& h_it)
    {
        {
            T q_new, h_x;
            two_sum(q, *e_it, q_new, h_x);
            *h_it = h_x;
            q = q_new;
        }
        grow_expansion_iteration< EN-1 >::apply(++e_it, q, ++h_it);
    }
};

template<>
struct grow_expansion_iteration<0>
{
    template< class EIt, class T, class HIt >
    static void apply(EIt&, T&, HIt&) { }
};

} // namespace detail_grow_expansion

template< class SinglePassReadableStaticSizeRange, class T, class IncrementableWritableIterator >
IncrementableWritableIterator
grow_expansion_unrolled(
    const SinglePassReadableStaticSizeRange& e,
    const T& b,
    IncrementableWritableIterator h_first)
{
    BOOST_CONCEPT_ASSERT((concepts::SinglePassReadableRange< const SinglePassReadableStaticSizeRange >));
    BOOST_MPL_ASSERT((range_has_static_size< SinglePassReadableStaticSizeRange >));
    typedef range_static_size< SinglePassReadableStaticSizeRange > e_size_type;
    BOOST_CONCEPT_ASSERT((concepts::IncrementableWritableIterator< IncrementableWritableIterator, T >));
    typedef typename boost::range_value< SinglePassReadableStaticSizeRange >::type e_value_type;
    BOOST_MPL_ASSERT((boost::is_same< e_value_type, T >));
    typedef typename boost::range_iterator< const SinglePassReadableStaticSizeRange >::type e_it_type;
    assert(nonoverlapping_expansion(e));
    e_it_type e_it = boost::begin(e);
    T q = b;
    detail_grow_expansion::grow_expansion_iteration< e_size_type::value >::apply(e_it, q, h_first);
    assert(e_it == boost::end(e));
    *h_first = q;
    return ++h_first;
}

/*******************************************************************************
 * grow_expansion_unrolled(
 *     ForwardReadableWritableRange& e,
 *     const T& b)
 *     -> boost::range_iterator< ForwardReadableWritableRange >::type
 ******************************************************************************/

namespace detail_grow_expansion
{

template< class ForwardReadableWritableStaticSizeRange, class T >
inline typename boost::range_iterator< ForwardReadableWritableStaticSizeRange >::type
grow_expansion_unrolled_impl(ForwardReadableWritableStaticSizeRange& e, const T& b)
{
    BOOST_CONCEPT_ASSERT((concepts::ForwardReadableWritableRange< ForwardReadableWritableStaticSizeRange >));
#ifdef SAKE_EXPANSION_ARITHMETIC_ASSERT_INVARIANTS
    bool nonoverlapping = nonoverlapping_expansion(e);
    bool strongly_nonoverlapping = strongly_nonoverlapping_expansion(e);
    bool nonadjacent = nonadjacent_expansion(e);
    typedef typename boost::range_iterator< ForwardReadableWritableStaticSizeRange >::type e_it_type;
    e_it_type e_it = grow_expansion_unrolled(e, b, boost::begin(e));
    assert(!nonoverlapping || nonoverlapping_expansion(e));
    assert(!strongly_nonoverlapping || strongly_nonoverlapping_expansion(e));
    assert(!nonadjacent || nonadjacent_expansion(e));
    return e_it;
#else
    return grow_expansion_unrolled(e, b, boost::begin(e));
#endif
}

} // namespace detail_grow_expansion

template< class ForwardReadableWritableStaticSizeRange, class T >
inline typename boost::range_iterator< ForwardReadableWritableStaticSizeRange >::type
grow_expansion_unrolled(ForwardReadableWritableStaticSizeRange& e, const T& b)
{ return detail_grow_expansion::grow_expansion_unrolled_impl(e, b); }

template< class ForwardReadableWritableStaticSizeRange, class T >
inline typename boost::range_iterator< const ForwardReadableWritableStaticSizeRange >::type
grow_expansion_unrolled(const ForwardReadableWritableStaticSizeRange& e, const T& b) // const to grab rvalues
{ return detail_grow_expansion::grow_expansion_unrolled_impl(e, b); }

} // namespace expansion_arithmetic

} // namespace sake

#endif // #ifndef _SAKE_EXPANSION_ARITHMETIC_GROW_EXPANSION_HPP_
