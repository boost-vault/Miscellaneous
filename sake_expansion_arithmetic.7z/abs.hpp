/*******************************************************************************
 * expansion_arithmetic/abs.hpp
 *
 * Copyright 2009, Jeffrey Hellrung.
 * Distributed under the Boost Software License, Version 1.0.  (See accompanying
 * file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
 *
 * expansion_arithmetic::abs(
 *     const BidirectionalReadableRange& e,
 *     IncrementableWritableIterator h_first)
 *     -> IncrementableWritableIterator
 * expansion_arithmetic::abs(BidirectionalReadableWritableRange& e)
 *     -> boost::range_iterator< BidirectionalReadableWritableRange >::type
 *
 * abs computes the absolute value of the expansion in e, putting the result in
 * h.
 * h may be identical to e.
 * In the second variant, h is identical to e.
 ******************************************************************************/

#ifndef _SAKE_EXPANSION_ARITHMETIC_ABS_HPP_
#define _SAKE_EXPANSION_ARITHMETIC_ABS_HPP_

#include <cassert>

#include <boost/concept/assert.hpp>
#include <boost/range/begin.hpp>
#include <boost/range/end.hpp>
#include <boost/range/iterator.hpp>
#include <boost/range/value_type.hpp>

#include <sake/core/math/sign.hpp>
#include <sake/core/math/sign_t.hpp>
#include <sake/core/range/concepts.hpp>
#include <sake/expansion_arithmetic/approximate.hpp>

namespace sake
{

namespace expansion_arithmetic
{

template< class BidirectionalReadableRange, class IncrementableWritableIterator >
IncrementableWritableIterator
abs(const BidirectionalReadableRange& e, IncrementableWritableIterator h_first)
{
    BOOST_CONCEPT_ASSERT((concepts::BidirectionalReadableRange< const BidirectionalReadableRange >));
    typedef typename boost::range_value< BidirectionalReadableRange >::type T;
    BOOST_CONCEPT_ASSERT((concepts::IncrementableWritableIterator< IncrementableWritableIterator, T >));
    typedef typename boost::range_iterator< const BidirectionalReadableRange >::type e_it_type;
    for(e_it_type e_it = boost::end(e), e_begin = boost::begin(e); e_it != e_begin;) {
        sign_t s = adl::sign(*(--e_it));
        assert(!indeterminate(s));
        if(s == zero)
            continue;
        if(s > zero) {
            *h_first = *e_begin;
            ++h_first;
            for(; e_begin != e_it; ++h_first)
                *h_first = *(++e_begin);
        }
        else {
            *h_first = -*e_begin;
            ++h_first;
            for(; e_begin != e_it; ++h_first)
                *h_first = -*(++e_begin);
        }
        break;
    }
    return h_first;
}

template< class BidirectionalReadableWritableRange >
inline typename boost::range_iterator< BidirectionalReadableWritableRange >::type
abs(BidirectionalReadableWritableRange& e)
{
    BOOST_CONCEPT_ASSERT((concepts::BidirectionalReadableWritableRange< BidirectionalReadableWritableRange >));
    return abs(e, boost::begin(e));
}

} // expansion_arithmetic

} // namespace sake

#endif // #ifndef _SAKE_EXPANSION_ARITHMETIC_ABS_HPP_
