/*******************************************************************************
 * expansion_arithmetic/two_diff.hpp
 *
 * Copyright 2009, Jeffrey Hellrung.
 * Distributed under the Boost Software License, Version 1.0.  (See accompanying
 * file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
 *
 * expansion_arithmetic::fast_two_diff(const T& a, const T& b, T& x, T& y) -> void
 * expansion_arithmetic::fast_two_diff_neg(const T& a, const T& b, T& x, T& y) -> void
 * expansion_arithmetic::two_diff(const T& a, const T& b, T& x, T& y) -> void
 *
 * These compute nonadjacent x and y such that |x| > |y| and x + y = a - b (for
 * fast_two_diff and two_diff) or x + y = b - a (for fast_two_diff_neg).
 * x must not reference neither a nor b.
 * y may reference either a or b.
 * For fast_two_diff[_neg], |a| >= |b| must hold.
 ******************************************************************************/

#ifndef _SAKE_EXPANSION_ARITHMETIC_TWO_DIFF_HPP_
#define _SAKE_EXPANSION_ARITHMETIC_TWO_DIFF_HPP_

#include <limits>

#include <cassert>

#include <boost/static_assert.hpp>

#include <sake/core/math/abs.hpp>

namespace sake
{

namespace expansion_arithmetic
{

#ifndef SAKE_EXPANSION_ARITHMETIC_VOLATILE
#define SAKE_EXPANSION_ARITHMETIC_VOLATILE volatile
#endif

template< class T >
inline void fast_two_diff(
    const T& a, const T& b,
    SAKE_EXPANSION_ARITHMETIC_VOLATILE T& x, T& y)
{
    BOOST_STATIC_ASSERT((std::numeric_limits<T>::is_iec559));
    assert(a == 0 || adl::abs_copy(a) >= adl::abs_copy(b));
    x = a - b; // subject to rounding
    T b_virtual = a - x;
    y = b_virtual - b;
}

template< class T >
inline void fast_two_diff_neg(
    const T& a, const T& b,
    SAKE_EXPANSION_ARITHMETIC_VOLATILE T& x, T& y)
{
    BOOST_STATIC_ASSERT((std::numeric_limits<T>::is_iec559));
    assert(a == 0 || adl::abs_copy(a) >= adl::abs_copy(b));
    x = b - a; // subject to rounding
    T b_virtual = x + a;
    y = b - b_virtual;
}

template< class T >
inline void two_diff(
    const T& a, const T& b,
    SAKE_EXPANSION_ARITHMETIC_VOLATILE T& x, T& y)
{
    BOOST_STATIC_ASSERT((std::numeric_limits<T>::is_iec559));
    x = a - b; // subject to rounding
    SAKE_EXPANSION_ARITHMETIC_VOLATILE T b_virtual = a - x; // subject to rounding
    T a_virtual = x + b_virtual;
    T b_roundoff = b_virtual - b;
    T a_roundoff = a - a_virtual;
    y = a_roundoff + b_roundoff;
}

} // namespace expansion_arithmetic

} // namespace sake

#endif // #ifndef _SAKE_EXPANSION_ARITHMETIC_TWO_DIFF_HPP_
