/*******************************************************************************
 * expansion_arithmetic/strongly_nonoverlapping_expansion.hpp
 *
 * Copyright 2009, Jeffrey Hellrung.
 * Distributed under the Boost Software License, Version 1.0.  (See accompanying
 * file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
 *
 * expansion_arithmetic::strongly_nonoverlapping_expansion(const SinglePassReadableRange& e) -> bool
 *
 * strongly_nonoverlapping_expansion returns whether the given expansion is
 * strongly nonoverlapping.
 ******************************************************************************/

#ifndef _SAKE_EXPANSION_ARITHMETIC_STRONGLY_NONOVERLAPPING_EXPANSION_HPP_
#define _SAKE_EXPANSION_ARITHMETIC_STRONGLY_NONOVERLAPPING_EXPANSION_HPP_

#include <boost/concept/assert.hpp>
#include <boost/range/begin.hpp>
#include <boost/range/end.hpp>
#include <boost/range/iterator.hpp>
#include <boost/range/value_type.hpp>

#include <sake/core/math/float_ufp.hpp>
#include <sake/core/range/concepts.hpp>
#include <sake/expansion_arithmetic/nonadjacent_expansion.hpp>

namespace sake
{

namespace expansion_arithmetic
{

template< class SinglePassReadableRange >
inline bool strongly_nonoverlapping_expansion(const SinglePassReadableRange& e)
{
    BOOST_CONCEPT_ASSERT((concepts::SinglePassReadableRange< const SinglePassReadableRange >));
    typedef typename boost::range_value< SinglePassReadableRange >::type e_value_type;
    typedef typename boost::range_iterator< const SinglePassReadableRange >::type e_it_type;
    typedef e_value_type T;
    e_it_type e_it = boost::begin(e);
    e_it_type e_end = boost::end(e);
    if(e_it == e_end)
        return true;
    T a = *e_it;
    bool last_pair_was_adjacent = false;
    while(++e_it != e_end) {
        T b = *e_it;
        if(sorted_and_nonadjacent(a,b))
            last_pair_was_adjacent = false;
        else {
            if(last_pair_was_adjacent || a != float_ufp(a) || b != float_ufp(b) || a >= b)
                return false;
            last_pair_was_adjacent = true;
        }
        a = b;
    }
    return true;
}

} // expansion_arithmetic

} // namespace sake

#endif // #ifndef _SAKE_EXPANSION_ARITHMETIC_STRONGLY_NONOVERLAPPING_EXPANSION_HPP_
