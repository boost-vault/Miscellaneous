/*******************************************************************************
 * expansion_arithmetic/expansion_prod.hpp
 *
 * Copyright 2009, Jeffrey Hellrung.
 * Distributed under the Boost Software License, Version 1.0.  (See accompanying
 * file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
 *
 * expansion_prod[_zeroelim,_unrolled](
 *     const ForwardReadableRange1& e,
 *     const ForwardReadableRange2& f,
 *     ForwardReadableWritableIterator h_first)
 *     -> ForwardReadableWritableIterator
 *
 * expansion_prod multiplies the expansions in e and f, putting the result in h.
 * h must have at least 2 * size(e) * size(f) elements in general.
 * Returns the iterator pointing to one-past-the-last element written to h.
 ******************************************************************************/

#ifndef _SAKE_EXPANSION_ARITHMETIC_EXPANSION_PROD_HPP_
#define _SAKE_EXPANSION_ARITHMETIC_EXPANSION_PROD_HPP_

#include <cassert>

#include <algorithm>
#include <iterator>
#include <memory>

#include <boost/concept/assert.hpp>
#include <boost/iterator/iterator_traits.hpp>
#include <boost/mpl/assert.hpp>
#include <boost/next_prior.hpp>
#include <boost/range/begin.hpp>
#include <boost/range/difference_type.hpp>
#include <boost/range/distance.hpp>
#include <boost/range/empty.hpp>
#include <boost/range/end.hpp>
#include <boost/range/iterator.hpp>
#include <boost/range/iterator_range.hpp>
#include <boost/range/value_type.hpp>
#include <boost/type_traits/is_same.hpp>
#include <boost/utility/enable_if.hpp>

#include <sake/core/functional/equal_to_zero.hpp>
#include <sake/core/iterator/concepts.hpp>
#include <sake/core/iterator/readable_ofilter_iterator.hpp>
#include <sake/core/range/concepts.hpp>
#include <sake/core/range/range_static_size.hpp>
#include <sake/core/range/static_size_iterator_range.hpp>
#include <sake/expansion_arithmetic/expansion_sum.hpp>
#include <sake/expansion_arithmetic/scale_expansion.hpp>

namespace sake
{

namespace expansion_arithmetic
{

namespace detail_expansion_prod
{

template< class ERange, class FRange, class HIt >
HIt expansion_prod_impl(const ERange& e, const FRange& f, HIt h_first)
{
    typedef typename boost::range_iterator< const ERange >::type e_it_type;
    typedef typename boost::range_iterator< const FRange >::type f_it_type;
    typedef typename boost::range_difference< ERange >::type e_distance_type;
    typedef typename boost::range_difference< FRange >::type f_distance_type;
    assert(!boost::empty(e));
    assert(!boost::empty(f));
    f_it_type f_begin = boost::begin(f);
    f_distance_type f_distance = boost::distance(f);
    if(f_distance == 1)
        return scale_expansion(e, *f_begin, h_first);
    assert(boost::distance(e) >= f_distance);
    f_distance_type f_half_distance = f_distance / 2;
    f_it_type f_halfway = boost::next(f_begin, f_half_distance);
    f_it_type f_end = boost::end(f);
    HIt h_halfway = expansion_prod_impl(e, boost::make_iterator_range(f_begin, f_halfway), h_first);
    HIt h_end = expansion_prod_impl(e, boost::make_iterator_range(f_halfway, f_end), h_halfway);
    return expansion_sum(
        boost::make_iterator_range(h_first, h_halfway),
        boost::make_iterator_range(h_halfway, h_end));
}

} // namespace detail_expansion_prod

template< class ForwardReadableRange1, class ForwardReadableRange2, class ForwardReadableWritableIterator >
inline ForwardReadableWritableIterator
expansion_prod(
    const ForwardReadableRange1& e,
    const ForwardReadableRange2& f,
    ForwardReadableWritableIterator h_first)
{
    BOOST_CONCEPT_ASSERT((concepts::ForwardReadableRange< const ForwardReadableRange1 >));
    BOOST_CONCEPT_ASSERT((concepts::ForwardReadableRange< const ForwardReadableRange2 >));
    BOOST_CONCEPT_ASSERT((concepts::ForwardReadableWritableIterator< ForwardReadableWritableIterator >));
    typedef typename boost::range_value< ForwardReadableRange1 >::type e_value_type;
    typedef typename boost::range_value< ForwardReadableRange2 >::type f_value_type;
    typedef ForwardReadableWritableIterator h_it_type;
    typedef typename boost::iterator_value< h_it_type >::type h_value_type;
    BOOST_MPL_ASSERT((boost::is_same< e_value_type, h_value_type >));
    BOOST_MPL_ASSERT((boost::is_same< f_value_type, h_value_type >));
    typedef typename boost::range_difference< const ForwardReadableRange1 >::type e_distance_type;
    typedef typename boost::range_difference< const ForwardReadableRange2 >::type f_distance_type;
    e_distance_type e_distance = boost::distance(e);
    f_distance_type f_distance = boost::distance(f);
    if(e_distance == 0 || f_distance == 0)
        return h_first;
    return e_distance >= f_distance ?
           detail_expansion_prod::expansion_prod_impl(e, f, h_first) :
           detail_expansion_prod::expansion_prod_impl(f, e, h_first);
}

template< class ForwardReadableRange1, class ForwardReadableRange2, class ForwardReadableWritableIterator >
inline ForwardReadableWritableIterator
expansion_prod_zeroelim(
    const ForwardReadableRange1& e,
    const ForwardReadableRange2& f,
    ForwardReadableWritableIterator h_first)
{
    BOOST_CONCEPT_ASSERT((concepts::ForwardReadableWritableIterator< ForwardReadableWritableIterator >));
    typedef ForwardReadableWritableIterator h_it_type;
    typedef typename boost::iterator_value< h_it_type >::type h_value_type;
    return expansion_prod(e, f, make_readable_ofilter_iterator< sake::functional::not_equal_to_zero< h_value_type > >(h_first)).base();
}

namespace detail_expansion_prod
{

template< int N >
struct expansion_prod_iteration
{
    template< class ERange, class FIt, class HIt >
    static void apply(const ERange& e, FIt f_first, HIt h_first)
    {
        typedef range_static_size< ERange > e_size_type;
        FIt f_halfway = boost::next(f_first, N/2);
        HIt h_halfway = boost::next(h_first, 2 * (N/2) * e_size_type::value);
        expansion_prod_iteration< N/2 >::apply(e, f_first, h_first);
        expansion_prod_iteration< (N+1)/2 >::apply(e, f_halfway, h_halfway);
        expansion_sum_unrolled2(
            make_static_size_iterator_range< 2 * (N/2) * e_size_type::value >(h_first),
            make_static_size_iterator_range< 2 * ((N+1)/2) * e_size_type::value >(h_halfway));
    }
};

template<>
struct expansion_prod_iteration<1>
{
    template< class ERange, class FIt, class HIt >
    static void apply(const ERange& e, FIt f_first, HIt h_first)
    { scale_expansion_unrolled(e, *f_first, h_first); }
};

template<>
struct expansion_prod_iteration<0>
{
    template< class ERange, class FIt, class HIt >
    static void apply(const ERange&, FIt, HIt) { }
};

template< int EN, int FN, class ERange, class FRange, class HIt >
inline typename boost::enable_if_c< (EN >= FN) >::type
expansion_prod_unrolled_impl(const ERange& e, const FRange& f, HIt h_first)
{ expansion_prod_iteration<FN>::apply(e, boost::begin(f), h_first); }

template< int EN, int FN, class ERange, class FRange, class HIt >
inline typename boost::enable_if_c< (EN < FN) >::type
expansion_prod_unrolled_impl(const ERange& e, const FRange& f, HIt h_first)
{ expansion_prod_iteration<EN>::apply(f, boost::begin(e), h_first); }

} // namespace detail_expansion_prod

template< class ForwardReadableStaticSizeRange1, class ForwardReadableStaticSizeRange2, class ForwardReadableWritableIterator >
ForwardReadableWritableIterator
expansion_prod_unrolled(
    const ForwardReadableStaticSizeRange1& e,
    const ForwardReadableStaticSizeRange2& f,
    ForwardReadableWritableIterator h_first)
{
    BOOST_CONCEPT_ASSERT((concepts::ForwardReadableRange< const ForwardReadableStaticSizeRange1 >));
    BOOST_MPL_ASSERT((range_has_static_size< ForwardReadableStaticSizeRange1 >));
    typedef range_static_size< ForwardReadableStaticSizeRange1 > e_size_type;
    BOOST_CONCEPT_ASSERT((concepts::ForwardReadableRange< const ForwardReadableStaticSizeRange2 >));
    BOOST_MPL_ASSERT((range_has_static_size< ForwardReadableStaticSizeRange2 >));
    typedef range_static_size< ForwardReadableStaticSizeRange2 > f_size_type;
    BOOST_CONCEPT_ASSERT((concepts::ForwardReadableWritableIterator< ForwardReadableWritableIterator >));
    typedef typename boost::range_value< ForwardReadableStaticSizeRange1 >::type e_value_type;
    typedef typename boost::range_value< ForwardReadableStaticSizeRange2 >::type f_value_type;
    typedef ForwardReadableWritableIterator h_it_type;
    typedef typename boost::iterator_value< h_it_type >::type h_value_type;
    BOOST_MPL_ASSERT((boost::is_same< e_value_type, h_value_type >));
    BOOST_MPL_ASSERT((boost::is_same< f_value_type, h_value_type >));
    detail_expansion_prod::expansion_prod_unrolled_impl< e_size_type::value, f_size_type::value >(e, f, h_first);
    return boost::next(h_first, 2 * e_size_type::value * f_size_type::value);
}

} // namespace expansion_arithmetic

} // namespace sake

#endif // #ifndef _SAKE_EXPANSION_ARITHMETIC_EXPANSION_PROD_HPP_
