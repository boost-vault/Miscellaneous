/*******************************************************************************
 * expansion_arithmetic/scale_expansion.hpp
 *
 * Copyright 2009, Jeffrey Hellrung.
 * Distributed under the Boost Software License, Version 1.0.  (See accompanying
 * file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
 *
 * scale_expansion[_zeroelim,_unrolled](
 *     const SinglePassReadableRange& e,
 *     const T& b,
 *     IncrementableWritableIterator h_first)
 *     -> IncrementableWritableIterator
 *
 * scale_expansion multiplies the expansion in e by b, putting the result in h.
 * It maintains nonoverlapping, strongly nonoverlapping, and nonadjacent.
 * h must have at least 2 * distance(e) elements.
 * h cannot intersect e.
 * Returns the iterator pointing to one-past-the-last element written to h.
 ******************************************************************************/

#ifndef _SAKE_EXPANSION_ARITHMETIC_SCALE_EXPANSION_HPP_
#define _SAKE_EXPANSION_ARITHMETIC_SCALE_EXPANSION_HPP_

#include <cassert>

#include <boost/concept/assert.hpp>
#include <boost/mpl/assert.hpp>
#include <boost/range/begin.hpp>
#include <boost/range/end.hpp>
#include <boost/range/iterator.hpp>
#include <boost/range/value_type.hpp>
#include <boost/type_traits/is_same.hpp>

#include <sake/core/iterator/concepts.hpp>
#include <sake/core/range/concepts.hpp>
#include <sake/expansion_arithmetic/nonoverlapping_expansion.hpp>
#include <sake/expansion_arithmetic/two_product.hpp>
#include <sake/expansion_arithmetic/two_sum.hpp>

namespace sake
{

namespace expansion_arithmetic
{

/*******************************************************************************
 * scale_expansion(
 *     const SinglePassReadableRange& e,
 *     const T& b,
 *     IncrementableWritableIterator h_first)
 *     -> IncrementableWritableIterator
 ******************************************************************************/

template< class SinglePassReadableRange, class T, class IncrementableWritableIterator >
IncrementableWritableIterator
scale_expansion(
    const SinglePassReadableRange& e,
    const T& b,
    IncrementableWritableIterator h_first)
{
    BOOST_CONCEPT_ASSERT((concepts::SinglePassReadableRange< const SinglePassReadableRange >));
    BOOST_CONCEPT_ASSERT((concepts::IncrementableWritableIterator< IncrementableWritableIterator, T >));
    typedef typename boost::range_value< SinglePassReadableRange >::type e_value_type;
    BOOST_MPL_ASSERT((boost::is_same< e_value_type, T >));
    typedef typename boost::range_iterator< const SinglePassReadableRange >::type e_it_type;
    assert(nonoverlapping_expansion(e));
    e_it_type e_it = boost::begin(e), e_end = boost::end(e);
    if(e_it == e_end)
        return h_first;
    T bhi, blo, q, h_x;
    split(b, bhi, blo);
    two_product_presplit1(b, bhi, blo, *e_it, q, h_x);
    *h_first = h_x;
    ++h_first;
    while(++e_it != e_end) {
        T thi, tlo, q2;
        two_product_presplit1(b, bhi, blo, *e_it, thi, tlo);
        two_sum(q, tlo, q2, h_x);
        *h_first = h_x;
        ++h_first;
        fast_two_sum(thi, q2, q, h_x);
        *h_first = h_x;
        ++h_first;
    }
    *h_first = q;
    return ++h_first;
}

/*******************************************************************************
 * scale_expansion_zeroelim(
 *     const SinglePassReadableRange& e,
 *     const T& b,
 *     IncrementableWritableIterator h_first)
 *     -> IncrementableWritableIterator
 ******************************************************************************/

template< class SinglePassReadableRange, class T, class IncrementableWritableIterator >
IncrementableWritableIterator
scale_expansion_zeroelim(
    const SinglePassReadableRange& e,
    const T& b,
    IncrementableWritableIterator h_first)
{
    BOOST_CONCEPT_ASSERT((concepts::IncrementableWritableIterator< IncrementableWritableIterator, T >));
    return scale_expansion(e, b, make_ofilter_iterator< sake::functional::not_equal_to_zero<T> >(h_first)).base();
}

/*******************************************************************************
 * scale_expansion_unrolled(
 *     const SinglePassReadableRange& e,
 *     const T& b,
 *     IncrementableWritableIterator h_first)
 *     -> IncrementableWritableIterator
 ******************************************************************************/

namespace detail_scale_expansion
{

template< int EN >
struct scale_expansion_iteration
{
    template< class EIt, class T, class HIt >
    static void apply(
        EIt& e_it,
        const T& b, const T& bhi, const T& blo,
        T& q,
        HIt& h_it)
    {
        {
            T h_x, thi, tlo, q2;
            two_product_presplit1(b, bhi, blo, *e_it, thi, tlo);
            two_sum(q, tlo, q2, h_x);
            *h_it = h_x;
            ++h_it;
            fast_two_sum(thi, q2, q, h_x);
            *h_it = h_x;
        }
        scale_expansion_iteration< EN-1 >::apply(
            ++e_it,
            b, bhi, blo,
            q,
            ++h_it);
    }
};

template<>
struct scale_expansion_iteration<0>
{
    template< class EIt, class T, class HIt >
    static void apply(EIt&, const T&, const T&, const T&, T&, HIt&) { }
};

template< int EN >
struct scale_expansion_unrolled_impl
{
    template< class ERange, class T, class HIt >
    static HIt apply(const ERange& e, const T& b, HIt h_first)
    {
        typedef typename boost::range_iterator< const ERange >::type e_it_type;
        e_it_type e_it = boost::begin(e);
        T bhi, blo, q, h_x;
        split(b, bhi, blo);
        two_product_presplit1(b, bhi, blo, *e_it, q, h_x);
        *h_first = h_x;
        scale_expansion_iteration< EN-1 >::apply(++e_it, b, bhi, blo, q, ++h_first);
        assert(e_it == boost::end(e));
        *h_first = q;
        return ++h_first;
    }
};

template<>
struct scale_expansion_unrolled_impl<0>
{
    template< class ERange, class T, class HIt >
    static HIt apply(const ERange&, const T&, HIt h_first) { return h_first; }
};

} // namespace detail_scale_expansion

template< class SinglePassReadableStaticSizeRange, class T, class IncrementableWritableIterator >
IncrementableWritableIterator
scale_expansion_unrolled(
    const SinglePassReadableStaticSizeRange& e,
    const T& b,
    IncrementableWritableIterator h_first)
{
    BOOST_CONCEPT_ASSERT((concepts::SinglePassReadableRange< const SinglePassReadableStaticSizeRange >));
    BOOST_MPL_ASSERT((range_has_static_size< SinglePassReadableStaticSizeRange >));
    typedef typename range_static_size< SinglePassReadableStaticSizeRange >::type e_size_type;
    BOOST_CONCEPT_ASSERT((concepts::IncrementableWritableIterator< IncrementableWritableIterator, T >));
    typedef typename boost::range_value< SinglePassReadableStaticSizeRange >::type e_value_type;
    BOOST_MPL_ASSERT((boost::is_same< e_value_type, T >));
    return detail_scale_expansion::scale_expansion_unrolled_impl< e_size_type::value >::apply(e, b, h_first);
}

} // namespace expansion_arithmetic

} // namespace sake

#endif // #ifndef _SAKE_EXPANSION_ARITHMETIC_SCALE_EXPANSION_HPP_
