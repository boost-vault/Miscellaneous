/*******************************************************************************
 * exact_arithmetic/truncate.hpp
 *
 * Copyright 2009, Jeffrey Hellrung.
 * Distributed under the Boost Software License, Version 1.0.  (See accompanying
 * file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
 *
 * truncate(
 *     const BidirectionalReadableRange& e,
 *     BidirectionalWritableRange& h,
 *     T& error)
 *     -> boost::range_iterator< BidirectionalWritableRange >::type
 * truncate(const BidirectionalReadableRange& e, T& error) -> T
 *
 * The first overload of truncate truncates the expansion in e with to an
 * expansion of size at most distance(h), and gives a bound on the truncation
 * error (which will be at most the ulp of the smallest component).  Zero
 * elements are automatically removed.
 * e and h are assumed to be nonempty.
 * Returns an iterator pointing to the first non-zero element of h.
 * The second overload of truncates returns the largest component of the
 * expansion in e and a corresponding truncation error.
 ******************************************************************************/

#ifndef _SAKE_EXPANSION_ARITHMETIC_TRUNCATE_HPP_
#define _SAKE_EXPANSION_ARITHMETIC_TRUNCATE_HPP_

#include <algorithm>

#include <boost/concept/assert.hpp>
#include <boost/mpl/assert.hpp>
#include <boost/range/begin.hpp>
#include <boost/range/end.hpp>
#include <boost/range/iterator.hpp>
#include <boost/range/value_type.hpp>
#include <boost/static_assert.hpp>
#include <boost/type_traits/is_same.hpp>

#include <sake/core/math/abs.hpp>
#include <sake/core/math/zero.hpp>
#include <sake/core/range/concepts.hpp>

namespace sake
{

namespace expansion_arithmetic
{

namespace detail_truncate
{

template< class BidirectionalReadableRange, class BidirectionalWritableRange, class T >
typename boost::range_iterator< BidirectionalWritableRange >::type
truncate_impl(const BidirectionalReadableRange& e, BidirectionalWritableRange& h, T& error)
{
    BOOST_STATIC_ASSERT((std::numeric_limits<T>::is_iec559));
    BOOST_CONCEPT_ASSERT((concepts::BidirectionalReadableRange< BidirectionalReadableRange >));
    BOOST_CONCEPT_ASSERT((concepts::BidirectionalWritableRange< BidirectionalWritableRange >));
    typedef typename boost::range_value< const BidirectionalReadableRange >::type e_value_type;
    typedef typename boost::range_value< BidirectionalWritableRange >::type h_value_type;
    BOOST_MPL_ASSERT((boost::is_same< e_value_type, T >));
    BOOST_MPL_ASSERT((boost::is_same< h_value_type, T >));
    typedef typename boost::range_iterator< const BidirectionalReadableRange >::type e_it_type;
    typedef typename boost::range_iterator< BidirectionalWritableRange >::type h_it_type;
    e_it_type e_it = boost::end(e), e_begin = boost::begin(e);
    h_it_type h_it = boost::end(h), h_begin = boost::begin(h);
    while(e_it != e_begin) {
        T e_x = *(--e_it);
        if(e_x == zero)
            continue;
        if(h_it != h_begin) {
            *(--h_it) = e_x;
            continue;
        }
        error = (e_it == e_begin ? adl::abs_copy(e_x) : 2 * adl::abs_copy(e_x));
        return h_it;
    }
    error = static_cast<T>(0);
    std::fill(h_begin, h_it, static_cast<T>(0));
    return h_it;
}

} // namespace detail_truncate

template< class BidirectionalReadableRange, class BidirectionalWritableRange, class T >
inline typename boost::range_iterator< BidirectionalWritableRange >::type
truncate(const BidirectionalReadableRange& e, BidirectionalWritableRange& h, T& error)
{ return detail_truncate::truncate_impl(e, h, error); }

template< class BidirectionalReadableRange, class BidirectionalWritableRange, class T >
inline typename boost::range_iterator< const BidirectionalWritableRange >::type
truncate(const BidirectionalReadableRange& e, const BidirectionalWritableRange& h, T& error) // const to grab rvalues
{ return detail_truncate::truncate_impl(e, h, error); }

template< class BidirectionalReadableRange, class T >
T truncate(const BidirectionalReadableRange& e, T& error)
{
    BOOST_STATIC_ASSERT((std::numeric_limits<T>::is_iec559));
    BOOST_CONCEPT_ASSERT((concepts::BidirectionalReadableRange< BidirectionalReadableRange >));
    typedef typename boost::range_value< const BidirectionalReadableRange >::type e_value_type;
    BOOST_MPL_ASSERT((boost::is_same< e_value_type, T >));
    typedef typename boost::range_iterator< const BidirectionalReadableRange >::type e_it_type;
    e_it_type e_it = boost::end(e), e_begin = boost::begin(e);
    while(e_it != e_begin && *(--e_it) == 0);
    T truncation = *e_it;
    if(e_it == e_begin)
        error = 0;
    else {
        while(e_it != e_begin && *(--e_it) == 0);
        error = adl::abs_copy(2 * (*e_it));
    }
    return truncation;
}

} // expansion_arithmetic

} // namespace sake

#endif // #ifndef _SAKE_EXPANSION_ARITHMETIC_TRUNCATE_HPP_
