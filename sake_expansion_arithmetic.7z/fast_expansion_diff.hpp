/*******************************************************************************
 * expansion_arithmetic/fast_expansion_diff.hpp
 *
 * Copyright 2009, Jeffrey Hellrung.
 * Distributed under the Boost Software License, Version 1.0.  (See accompanying
 * file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
 *
 * expansion_arithmetic::fast_expansion_diff[_zeroelim](
 *     const SinglePassReadableRange1& e,
 *     const SinglePassReadableRange2& f,
 *     IncrementableWritableIterator h_first)
 *     -> IncrementableWritableIterator
 *
 * fast_expansion_diff subtracts the expansions in e and f, putting the result
 * in h.
 * Maintains strongly nonoverlapping; does not maintain overlapping or
 * nonadjacent.
 * e and f are assumed to be nonempty.
 * h must have at least distance(e) + distance(f) valid elements.
 * h cannot intersect neither e nor f.
 * Returns the iterator pointing to one-past-the-last element written to h.
 ******************************************************************************/

#ifndef _SAKE_EXPANSION_ARITHMETIC_FAST_EXPANSION_DIFF_HPP_
#define _SAKE_EXPANSION_ARITHMETIC_FAST_EXPANSION_DIFF_HPP_

#include <functional>

#include <boost/concept/assert.hpp>
#include <boost/range/value_type.hpp>

#include <sake/core/range/concepts.hpp>
#include <sake/core/range/transform_range.hpp>
#include <sake/expansion_arithmetic/fast_expansion_sum.hpp>

namespace sake
{

namespace expansion_arithmetic
{

template< class SinglePassReadableRange1, class SinglePassReadableRange2, class IncrementableWritableIterator >
inline IncrementableWritableIterator
fast_expansion_diff(
    const SinglePassReadableRange1& e,
    const SinglePassReadableRange2& f,
    IncrementableWritableIterator h_first)
{
    BOOST_CONCEPT_ASSERT((concepts::SinglePassReadableRange< const SinglePassReadableRange2 >));
    typedef typename boost::range_value< SinglePassReadableRange2 >::type f_value_type;
    return fast_expansion_sum(e, make_transform_range< std::negate< f_value_type > >(f), h_first);
}

template< class SinglePassReadableRange1, class SinglePassReadableRange2, class IncrementableWritableIterator >
inline IncrementableWritableIterator
fast_expansion_diff_zeroelim(
    const SinglePassReadableRange1& e,
    const SinglePassReadableRange2& f,
    IncrementableWritableIterator h_first)
{
    BOOST_CONCEPT_ASSERT((concepts::SinglePassReadableRange< const SinglePassReadableRange2 >));
    typedef typename boost::range_value< SinglePassReadableRange2 >::type f_value_type;
    return fast_expansion_sum_zeroelim(e, make_transform_range< std::negate< f_value_type > >(f), h_first);
}

} // namespace expansion_arithmetic

} // namespace sake

#endif // #ifndef _SAKE_EXPANSION_ARITHMETIC_FAST_EXPANSION_DIFF_HPP_
