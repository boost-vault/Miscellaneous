/*******************************************************************************
 * expansion_arithmetic/approximate.hpp
 *
 * Copyright 2009, Jeffrey Hellrung.
 * Distributed under the Boost Software License, Version 1.0.  (See accompanying
 * file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
 *
 * expansion_arithmetic::approximate(
 *     const BidirectionalReadableRange& e,
 *     BidirectionalReadableWritableRange& h,
 *     T& error)
 *     -> boost::range_iterator< BidirectionalReadableWritableRange >::type
 * expansion_arithmetic::approximate(
 *     const BidirectionalReadableRange& e,
 *     T& error)
 *     -> T
 *
 * approximate approximates the expansion in e with an expansion of size at most
 * distance(h), and gives a bound on the error in the approximation (which will
 * be at most the ulp of the smallest component).
 * The result expansion will be nonadjacent.
 * If distance(e) <= distance(h), then this reduces to a compress.
 * h may be identical to e (but then, by above, this reduces to a compress).
 * Returns an iterator pointing to one-past-the-last element written to h.
 ******************************************************************************/

#ifndef _SAKE_EXPANSION_ARITHMETIC_APPROXIMATE_HPP_
#define _SAKE_EXPANSION_ARITHMETIC_APPROXIMATE_HPP_

#include <cassert>

#include <limits>

#include <boost/concept/assert.hpp>
#include <boost/math/special_functions/next.hpp>
#include <boost/mpl/assert.hpp>
#include <boost/range/begin.hpp>
#include <boost/range/distance.hpp>
#include <boost/range/empty.hpp>
#include <boost/range/end.hpp>
#include <boost/range/iterator.hpp>
#include <boost/range/iterator_range.hpp>
#include <boost/range/value_type.hpp>
#include <boost/static_assert.hpp>
#include <boost/type_traits/is_same.hpp>

#include <sake/core/math/abs.hpp>
#include <sake/core/math/float_ulp.hpp>
#include <sake/core/range/concepts.hpp>
#include <sake/core/range/numeric/accumulate.hpp>
#include <sake/expansion_arithmetic/nonoverlapping_expansion.hpp>
#include <sake/expansion_arithmetic/nonadjacent_expansion.hpp>
#include <sake/expansion_arithmetic/two_sum.hpp>

namespace sake
{

namespace expansion_arithmetic
{

template< class BidirectionalReadableRange, class BidirectionalReadableWritableRange, class T >
typename boost::range_iterator< BidirectionalReadableWritableRange >::type
approximate(
    const BidirectionalReadableRange& e,
    BidirectionalReadableWritableRange& h,
    T& error)
{
    BOOST_STATIC_ASSERT((std::numeric_limits<T>::is_iec559));
    BOOST_CONCEPT_ASSERT((concepts::BidirectionalReadableRange< const BidirectionalReadableRange >));
    BOOST_CONCEPT_ASSERT((concepts::BidirectionalReadableWritableRange< BidirectionalReadableWritableRange >));
    typedef typename boost::range_value< BidirectionalReadableRange >::type e_value_type;
    typedef typename boost::range_value< BidirectionalReadableWritableRange >::type h_value_type;
    BOOST_MPL_ASSERT((boost::is_same< e_value_type, T >));
    BOOST_MPL_ASSERT((boost::is_same< h_value_type, T >));
    typedef typename boost::range_iterator< const BidirectionalReadableRange >::type e_it_type;
    typedef typename boost::range_iterator< BidirectionalReadableWritableRange >::type h_it_type;
    assert(nonoverlapping_expansion(e));
    e_it_type e_it = boost::end(e), e_begin = boost::begin(e);
    h_it_type h_it = boost::end(h), h_begin = boost::begin(h);
    if(e_it == e_begin) {
        error = 0;
        return h_begin;
    }
    h_it_type h_end = h_it;
    T qhi = *(--e_it);
    for(;;) {
        if(e_it != e_begin) {
            T qhi_new, qlo;
            fast_two_sum(qhi, *(--e_it), qhi_new, qlo);
            if(qlo == 0) {
                qhi = qhi_new;
                continue;
            }
            assert(qhi_new != 0);
            if(h_it != h_begin) {
                *(--h_it) = qhi_new;
                qhi = qlo;
                continue;
            }
            error = boost::math::float_next(adl::abs_copy(qhi_new));
        }
        else if(h_it != h_begin) {
            error = 0;
            break;
        }
        else
            error = adl::abs_copy(qhi);
        if(h_it == h_end) {
            assert(h_begin == h_end);
            return h_it;
        }
        qhi = *h_it;
        ++h_it;
        break;
    }
    if(h_it != h_end) {
        do {
            T qhi_new, qlo;
            fast_two_sum(*h_it, qhi, qhi_new, qlo);
            qhi = qhi_new;
            assert(qlo != 0);
            *h_begin = qlo;
            ++h_begin;
        } while(++h_it != h_end);
    }
    else if(qhi == 0)
        return h_begin;
    assert(qhi != 0);
    *h_begin = qhi;
    ++h_begin;
    assert(nonadjacent_expansion(boost::make_iterator_range(boost::begin(h), h_begin)));
    return h_begin;
}

template< class BidirectionalReadableRange, class T >
inline T approximate(const BidirectionalReadableRange& e, T& error)
{
    BOOST_STATIC_ASSERT((std::numeric_limits<T>::is_iec559));
    BOOST_CONCEPT_ASSERT((concepts::BidirectionalReadableRange< const BidirectionalReadableRange >));
    typedef typename boost::range_value< BidirectionalReadableRange >::type e_value_type;
    BOOST_MPL_ASSERT((boost::is_same< e_value_type, T >));
    assert(!boost::empty(e));
    T approximation = range::accumulate(e);
    error = (boost::distance(e) <= 1 || approximation == 0 ? 0 : float_ulp(adl::abs_copy(approximation)));
    return approximation;
}

} // namespace expansion_arithmetic

} // namespace sake

#endif // #ifndef _SAKE_EXPANSION_ARITHMETIC_APPROXIMATE_HPP_
