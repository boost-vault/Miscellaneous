/*******************************************************************************
 * expansion_arithmetic/expansion_fwd.hpp
 *
 * Copyright 2009, Jeffrey Hellrung.
 * Distributed under the Boost Software License, Version 1.0.  (See accompanying
 * file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
 *
 ******************************************************************************/

#ifndef _SAKE_EXPANSION_ARITHMETIC_EXPANSION_FWD_HPP_
#define _SAKE_EXPANSION_ARITHMETIC_EXPANSION_FWD_HPP_

#include <cstddef>

#include <sake/core/memory/new_delete_allocator_fwd.hpp>

namespace sake
{

template< class T, std::size_t N > class approx_expansion;
template< class T, class Allocator = new_delete_allocator<> > class exact_expansion;
template< class T, class Allocator = new_delete_allocator<> > class rational_expansion;

} // namespace sake

#endif // #ifndef _SAKE_EXPANSION_ARITHMETIC_EXPANSION_FWD_HPP_
