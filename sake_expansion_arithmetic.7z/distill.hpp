/*******************************************************************************
 * expansion_arithmetic/distill.hpp
 *
 * Copyright 2009, Jeffrey Hellrung.
 * Distributed under the Boost Software License, Version 1.0.  (See accompanying
 * file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
 *
 * distill[_unrolled](
 *     const SinglePassReadableRange& e,
 *     ForwardReadableWritableIterator h_first)
 *     -> ForwardReadableWritableIterator
 * distill[_unrolled](ForwardReadableWritableRange& e)
 *     -> boost::range_iterator< ForwardReadableWritableRange >::type
 *
 * distill distills the range e (i.e., converts the sum of the numbers in e into
 * a nonadjacent expansion), putting the result in h.
 * h must have at least distance(e) valid elements.
 * h may be identical to e.
 * In the second variants, h is identical to e.
 * TODO: Consider using something faster than grow_expansion ?
 ******************************************************************************/

#ifndef _SAKE_EXPANSION_ARITHMETIC_DISTILL_HPP_
#define _SAKE_EXPANSION_ARITHMETIC_DISTILL_HPP_

#include <boost/concept/assert.hpp>
#include <boost/iterator/iterator_traits.hpp>
#include <boost/mpl/assert.hpp>
#include <boost/range/begin.hpp>
#include <boost/range/end.hpp>
#include <boost/range/iterator.hpp>
#include <boost/range/iterator_range.hpp>
#include <boost/range/value_type.hpp>
#include <boost/type_traits/is_same.hpp>

#include <sake/core/iterator/concepts.hpp>
#include <sake/core/range/concepts.hpp>
#include <sake/core/range/range_static_size.hpp>
#include <sake/expansion_arithmetic/grow_expansion.hpp>
#include <sake/expansion_arithmetic/nonadjacent_expansion.hpp>

namespace sake
{

namespace expansion_arithmetic
{

template< class SinglePassReadableRange, class ForwardReadableWritableIterator >
ForwardReadableWritableIterator
distill(
    const SinglePassReadableRange& e,
    ForwardReadableWritableIterator h_first)
{
    BOOST_CONCEPT_ASSERT((concepts::SinglePassReadableRange< const SinglePassReadableRange >));
    BOOST_CONCEPT_ASSERT((concepts::ForwardReadableWritableIterator< ForwardReadableWritableIterator >));
    typedef typename boost::range_value< SinglePassReadableRange >::type e_value_type;
    typedef typename boost::iterator_value< ForwardReadableWritableIterator >::type h_value_type;
    BOOST_MPL_ASSERT((boost::is_same< e_value_type, h_value_type >));
    typedef typename boost::range_iterator< const SinglePassReadableRange >::type e_it_type;
    typedef ForwardReadableWritableIterator h_it_type;
    h_it_type h_it = h_first;
    for(e_it_type e_it = boost::begin(e), e_end = boost::end(e); e_it != e_end; ++e_it)
        h_it = grow_expansion(boost::make_iterator_range(h_first, h_it), *e_it);
    assert(nonadjacent_expansion(boost::make_iterator_range(h_first, h_it)));
    return h_it;
}

template< class ForwardReadableWritableRange >
inline typename boost::range_iterator< ForwardReadableWritableRange >::type
distill(ForwardReadableWritableRange& e)
{
    BOOST_CONCEPT_ASSERT((concepts::ForwardReadableWritableRange< ForwardReadableWritableRange >));
    return distill(e, boost::begin(e));
}

namespace detail_distill
{

template< int EN, int HN >
struct distill_iteration
{
    template< class EIt, class HIt >
    static void apply(EIt e_it, HIt h_first)
    {
        grow_expansion_unrolled(make_static_size_iterator_range<HN>(h_first), *e_it);
        distill_iteration< EN-1, HN+1 >::apply(++e_it, h_first);
    }
};

template< int HN >
struct distill_iteration< 0, HN >
{
    template< class EIt, class HIt >
    static void apply(EIt, HIt) { }
};

} // namespace detail_distill

template< class SinglePassReadableStaticSizeRange, class ForwardReadableWritableIterator >
inline void distill_unrolled(
    const SinglePassReadableStaticSizeRange& e,
    ForwardReadableWritableIterator h_first)
{
    BOOST_CONCEPT_ASSERT((concepts::SinglePassReadableRange< const SinglePassReadableStaticSizeRange >));
    BOOST_MPL_ASSERT((range_has_static_size< SinglePassReadableStaticSizeRange >));
    typedef range_static_size< SinglePassReadableStaticSizeRange > e_size_type;
    BOOST_CONCEPT_ASSERT((concepts::ForwardReadableWritableIterator< ForwardReadableWritableIterator >));
    typedef typename boost::range_value< SinglePassReadableStaticSizeRange >::type e_value_type;
    typedef typename boost::iterator_value< ForwardReadableWritableIterator >::type h_value_type;
    BOOST_MPL_ASSERT((boost::is_same< e_value_type, h_value_type >));
    detail_distill::distill_iteration< e_size_type::value, 0 >::apply(boost::begin(e), h_first);
}

template< class ForwardReadableWritableStaticSizeRange >
inline void distill_unrolled(ForwardReadableWritableStaticSizeRange& e)
{
    BOOST_CONCEPT_ASSERT((concepts::ForwardReadableWritableRange< ForwardReadableWritableStaticSizeRange >));
    distill_unrolled(e, boost::begin(e));
}

} // expansion_arithmetic

} // namespace sake

#endif // #ifndef _SAKE_EXPANSION_ARITHMETIC_DISTILL_HPP_
