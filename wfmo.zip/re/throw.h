//Copyright (c) 2008-2011 Reverge Studios, Inc.
//Distributed under the Boost Software License, Version 1.0. (See accompanying
//file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)

#ifndef UUID_3923B94EEB2211DC9E29EAE455D89593
#define UUID_3923B94EEB2211DC9E29EAE455D89593

#include "boost/exception/exception.hpp"
#include "boost/current_function.hpp"

#define RE_THROW(x) throw boost::enable_current_exception(boost::enable_error_info(x)) <<\
    ::boost::throw_function(BOOST_CURRENT_FUNCTION) <<\
    ::boost::throw_file(__FILE__) <<\
    ::boost::throw_line((int)__LINE__)

#endif
