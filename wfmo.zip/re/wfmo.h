//Copyright (c) 2008-2011 Reverge Studios, Inc.
//Distributed under the Boost Software License, Version 1.0. (See accompanying
//file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)

#ifndef UUID_BE904D4022E511DD9A795E3856D89593
#define UUID_BE904D4022E511DD9A795E3856D89593

#include "boost/shared_ptr.hpp"
#include "boost/exception/exception.hpp"
#include <exception>

namespace
re
	{
	class event;
	void swap( event &, event & );
	event null_event();
	void set_event( event & );
	bool operator==( event const &, event const & );
	bool operator!=( event const &, event const & );
	bool operator<( event const &, event const & );

	class event_listener;
	void swap( event_listener &, event_listener & );
	void add_event( event_listener &, event const & );
	bool remove_event( event_listener &, event const & );
	event wait_any( event_listener & );
	event wait_any_timeout( event_listener &, float timeout_in_seconds );
	void copy_events_state( event_listener &, event_listener const & );

	class
	event_listener
		{
		public:

		event_listener();

		private:

		class pimpl;
		boost::shared_ptr<pimpl> impl_;
		friend class event;
		friend void swap( event_listener &, event_listener & );
		friend void add_event( event_listener &, event const & );
		friend bool remove_event( event_listener &, event const & );
		friend event wait_any( event_listener & );
		friend event wait_any_timeout( event_listener &, float );
		friend void copy_events_state( event_listener &, event_listener const & );

		event_listener( event_listener const & );
		event_listener & operator=( event_listener const & );
		};

	class
	event
		{
		public:

		event();

		private:

		class pimpl;
		boost::shared_ptr<pimpl> impl_;
		explicit event( boost::shared_ptr<pimpl> const & );
		friend class event_listener::pimpl;
		friend void swap( event &, event & );
		friend event null_event();
		friend void set_event( event & );
		friend bool operator==( event const &, event const & );
		friend bool operator<( event const &, event const & );
		};

	struct
	x_listener_is_empty:
		virtual std::exception,
		virtual boost::exception
		{
		x_listener_is_empty();
		};
	}

#endif
