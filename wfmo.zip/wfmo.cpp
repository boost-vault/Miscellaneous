//Copyright (c) 2008-2011 Reverge Studios, Inc.
//Distributed under the Boost Software License, Version 1.0. (See accompanying
//file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)

#include "re/wfmo.h"
#include "re/throw.h"
#include "boost/exception/info.hpp"
#include "boost/thread/condition_variable.hpp"
#include "boost/thread/mutex.hpp"
#include "boost/weak_ptr.hpp"
#include "boost/bind.hpp"
#include "boost/detail/atomic_count.hpp"
#include <set>
#include <assert.h>

namespace
	{
	typedef long event_state;
	typedef boost::detail::atomic_count atomic_event_state;

	struct
	wfmo
		{
		void
		notify()
			{
			m.lock();
			m.unlock();
			c.notify_all();
			}

		boost::mutex m;
		boost::condition_variable c;
		};

	class
	wait_list
		{
		wait_list( wait_list const & );
		wait_list & operator=( wait_list const & );

		typedef std::set< boost::weak_ptr<wfmo> > wfmo_set;
		wfmo_set list_;
		mutable boost::mutex m_;

		wfmo_set
		get() const
			{
			boost::mutex::scoped_lock lock(m_);
			return list_;
			}

		void
		do_notify( wfmo_set & s ) const
			{
			for( wfmo_set::iterator i=s.begin(),e=s.end(); i!=e; ++i )
				if( boost::shared_ptr<wfmo> p=i->lock() )
					p->notify();
			}

		public:

		wait_list()
			{
			}

		~wait_list()
			{
			do_notify(list_);
			}

		void
		insert( boost::weak_ptr<wfmo> const & p )
			{
			boost::mutex::scoped_lock lock(m_);
			list_.insert(p);
			}

		void
		erase( boost::weak_ptr<wfmo> const & p )
			{
			boost::mutex::scoped_lock lock(m_);
			list_.erase(p);
			}

		void
		notify() const
			{
			wfmo_set tmp(get());
			do_notify(tmp);
			}

		void
		purge()
			{
			boost::mutex::scoped_lock lock(m_);
			for( wfmo_set::iterator i=list_.begin(),e=list_.end(); i!=e; )
				{
				wfmo_set::iterator n=i; ++n;
				if( i->expired() )
					list_.erase(i);
				i=n;
				}
			}
		};
	}

namespace
re
	{
	class
	event::
	pimpl
		{
		pimpl( pimpl const & );
		pimpl & operator=( pimpl const & );

		atomic_event_state state_;
		wait_list listeners_;

		public:

		pimpl():
			state_(0)
			{
			}

		event_state
		get() const
			{
			return state_;
			}

		void
		set()
			{
			++state_;
			listeners_.notify();
			listeners_.purge();
			}

		bool
		check( event_state & s ) const
			{
			event_state tmp=s;
			s=state_;
			return s!=tmp;
			}

		void
		add( boost::weak_ptr<wfmo> const & p )
			{
			listeners_.insert(p);
			}

		void
		remove( boost::weak_ptr<wfmo> const & p )
			{
			listeners_.erase(p);
			}
		};

	class
	event_listener::
	pimpl
		{
		pimpl( pimpl const & );
		pimpl & operator=( pimpl const & );

		friend class event_listener;

		struct
		es
			{
			boost::weak_ptr<event::pimpl> e;
			mutable event_state s;
			es( boost::weak_ptr<event::pimpl> const & e, event_state s ):
				e(e),
				s(s)
				{
				}
			friend
			bool
			operator<( es const & a, es const & b )
				{
				return a.e<b.e;
				}
			};

		std::set<es> es_;
		std::set<es>::const_iterator pred_ptr_;
		wfmo mc_storage_;
		boost::weak_ptr<wfmo> mc_;

		boost::shared_ptr<event::pimpl>
		pred( bool & empty )
			{
			empty=true;
			if( !es_.empty() )
				{
				std::set<es>::const_iterator i=pred_ptr_;
				assert(i!=es_.end());
				do
					{
					if( ++i==es_.end() )
						i=es_.begin();
					es const & e=*i;
					if( boost::shared_ptr<event::pimpl> se=e.e.lock() )
						{
						empty=false;
						if( se->check(e.s) )
							{
							pred_ptr_=i;
							return se;
							}
						}
					} while( i!=pred_ptr_ );
				}
			return boost::shared_ptr<event::pimpl>();
			}

		void
		add( boost::weak_ptr<wfmo> const & wmc )
			{
			for( std::set<es>::iterator i=es_.begin(),end=es_.end(); i!=end; ++i )
				if( boost::shared_ptr<event::pimpl> se=i->e.lock() )
					se->add(wmc);
			}

		void
		purge_expired_events()
			{
			for( std::set<es>::iterator i=es_.begin(),end=es_.end(); i!=end; )
				if( i->e.expired() )
					{
					std::set<es>::iterator n=i; ++n;
					if( pred_ptr_==i )
						pred_ptr_=n;
					es_.erase(i);
					i=n;
					}
				else
					++i;
			if( pred_ptr_==es_.end() )
				pred_ptr_=es_.begin();
			}

		pimpl():
			pred_ptr_(es_.end())
			{
			}

		public:

		static
		boost::shared_ptr<pimpl>
		create_pimpl()
			{
			boost::shared_ptr<pimpl> p(new pimpl());
			p->mc_=boost::shared_ptr<wfmo>(p,&p->mc_storage_);
			return p;
			}

		void
		add_event( event const & e )
			{
			if( e.impl_ )
				(void) es_.insert(es(e.impl_,event_state(e.impl_->get())));
			}

		bool
		remove_event( event const & e )
			{
			if( e.impl_ )
				{
				std::set<es>::iterator i=es_.find(es(e.impl_,event_state(e.impl_->get())));
				if( i!=es_.end() )
					{
					if( boost::shared_ptr<event::pimpl> se=i->e.lock() )
						se->remove(mc_);
					if( pred_ptr_==i )
						++pred_ptr_;
					es_.erase(i);
					if( pred_ptr_==es_.end() )
						pred_ptr_=es_.begin();
					return true;
					}
				}
			return false;
			}

		event
		wait_any()
			{
			bool empty;
			if( pred_ptr_==es_.end() )
				pred_ptr_=es_.begin();
			if( boost::shared_ptr<event::pimpl> e=pred(empty) )
				return event(e);
			else
				if( empty )
					RE_THROW(x_listener_is_empty());
			add(mc_);
			purge_expired_events();
			boost::mutex::scoped_lock lock(mc_storage_.m);
			for(;;)
				{
				if( boost::shared_ptr<event::pimpl> e=pred(empty) )
					return event(e);
				else
					if( empty )
						RE_THROW(x_listener_is_empty());
				mc_storage_.c.wait(lock);
				}
			}

		event
		wait_any_timeout( unsigned timeout_in_milliseconds )
			{
			bool empty;
			if( pred_ptr_==es_.end() )
				pred_ptr_=es_.begin();
			if( boost::shared_ptr<event::pimpl> e=pred(empty) )
				return event(e);
			add(mc_);
			purge_expired_events();
			boost::mutex::scoped_lock lock(mc_storage_.m);
			for( boost::system_time now=boost::get_system_time(); ; )
				{
				if( boost::shared_ptr<event::pimpl> e=pred(empty) )
					return event(e);
				boost::system_time later=boost::get_system_time();
				unsigned ms = unsigned((later-now).total_milliseconds());
				if( ms>=timeout_in_milliseconds )
					return null_event();
				timeout_in_milliseconds-=ms;
				now=later;
				if( empty )
					{
					if( timeout_in_milliseconds )
						boost::this_thread::sleep(boost::posix_time::milliseconds(timeout_in_milliseconds));
					return null_event();
					}
				else
					if( !mc_storage_.c.timed_wait(lock,now+boost::posix_time::milliseconds(timeout_in_milliseconds)) )
						return null_event();
				}
			}

		void
		copy_events_state( pimpl const & x )
			{
			for( std::set<es>::const_iterator i=x.es_.begin(),end=x.es_.end(); i!=end; ++i )
				{
				std::set<es>::iterator j=es_.find(*i);
				if( j!=es_.end() )
					j->s = i->s;
				}
			}
		};

	event::
	event():
		impl_(new pimpl)
		{
		}

	void
	swap( event & a, event & b )
		{
		a.impl_.swap(b.impl_);
		}

	event::
	event( boost::shared_ptr<pimpl> const & impl ):
		impl_(impl)
		{
		}

	void
	set_event( event & e )
		{
		if( e.impl_ )
			e.impl_->set();
		}

	bool
	operator==( event const & e1, event const & e2 )
		{
		return e1.impl_==e2.impl_;
		}

	bool
	operator!=( event const & e1, event const & e2 )
		{
		return !(e1==e2);
		}

	bool
	operator<( event const & e1, event const & e2 )
		{
		return e1.impl_<e2.impl_;
		}

	event_listener::
	event_listener()
		{
		}

	void
	swap( event_listener & a, event_listener & b )
		{
		a.impl_.swap(b.impl_);
		}

	void
	add_event( event_listener & l, event const & e )
		{
		if( !l.impl_ )
			l.impl_ = event_listener::pimpl::create_pimpl();
		l.impl_->add_event(e);
		}

	bool
	remove_event( event_listener & l, event const & e )
		{
		if( l.impl_ )
			return l.impl_->remove_event(e);
		else
			return false;
		}

	event
	wait_any( event_listener & l )
		{
		if( l.impl_ )
			return l.impl_->wait_any();
		else
			RE_THROW(x_listener_is_empty());
		}

	event
	wait_any_timeout( event_listener & l, float timeout_in_seconds )
		{
		assert(timeout_in_seconds>=0);
		unsigned ms = (unsigned)(timeout_in_seconds*1000);
		if( l.impl_ )
			return l.impl_->wait_any_timeout(ms);
		else
			{
			if( ms )
				boost::this_thread::sleep(boost::posix_time::milliseconds(ms));
			return null_event();
			}
		}

	void
	copy_events_state( event_listener & dst, event_listener const & src )
		{
		if( dst.impl_ && src.impl_ )
			dst.impl_->copy_events_state( *src.impl_ );
		}

	event
	null_event()
		{
		return event( boost::shared_ptr<event::pimpl>() );
		}

	x_listener_is_empty::
	x_listener_is_empty()
		{
		}
	}
