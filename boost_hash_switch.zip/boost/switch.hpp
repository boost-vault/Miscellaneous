/* 
 * File:   switch.hpp
 * Author: Kasra Nassiri (c) - All rights reserved
 *
 * Created on 14 September 2008, 12:54
 */
#ifndef BOOST_SWITCH_HPP
#define	BOOST_SWITCH_HPP


#include <boost/cstdint.hpp>
#include <boost/functional/hash.hpp>
#include <boost/current_function.hpp>

#include <boost/preprocessor/cat.hpp>
#include <boost/preprocessor/slot/slot.hpp>
#include <boost/preprocessor/slot/counter.hpp>
#include <boost/preprocessor/logical/bool.hpp>
#include <boost/preprocessor/logical/compl.hpp>
#include <boost/preprocessor/arithmetic/sub.hpp>
#include <boost/preprocessor/arithmetic/add.hpp>

#include <boost/preprocessor/array/pop_front.hpp>
#include <boost/preprocessor/array/push_front.hpp>
#include <boost/preprocessor/array/elem.hpp>
#include <boost/preprocessor/array/insert.hpp>
#include <boost/preprocessor/comparison/equal.hpp>
#include <boost/preprocessor/slot/slot.hpp>

#include <boost/preprocessor/config/limits.hpp>


#include <map>
#include <list>
#include <algorithm>

#undef BOOST_SWITCH_NO_DUPLICATED_THROW // to prevent deuplicated exceptions
#undef BOOST_SWITCH_NO_DUPLICATED_DEFAULT_THROW
#undef BOOST_SWITCH_NO_THROW
#define BOOST_SWITCH_THROW

#if defined(BOOST_SWITCH_NO_THROW) && !defined(BOOST_SWITCH_THROW)
#  ifndef BOOST_SWITCH_NO_DUPLICATED_THROW
#    define BOOST_SWITCH_NO_DUPLICATED_THROW
#  endif
#  ifndef BOOST_SWITCH_NO_DUPLICATED_DEFAULT_THROW
#    define BOOST_SWITCH_NO_DUPLICATED_DEFAULT_THROW
#  endif
#elif !defined(BOOST_SWITCH_NO_THROW) && defined(BOOST_SWITCH_THROW)
#  ifdef BOOST_SWITCH_NO_DUPLICATED_THROW
#    undef BOOST_SWITCH_NO_DUPLICATED_THROW
#  endif
#  ifdef BOOST_SWITCH_NO_DUPLICATED_DEFAULT_THROW
#    undef BOOST_SWITCH_NO_DUPLICATED_DEFAULT_THROW
#  endif
#else
#  error BOOST ERROR ---> Only one of {BOOST_SWITCH_THROW, BOOST_SWITCH_NO_THROW} should be defined
#endif

namespace boost {
    
    #if defined(_DEBUG) || defined(DEBUG) || defined(_DEBUG_)
    #	define BOOST_DEBUG 1
    #else
    #	ifdef BOOST_DEBUG
    #	    undef BOOST_DEBUG
    #	endif
    #error
    #endif    
/*
 *This exception class holds the duplicates indexes, so they could be identified
 
class switch_exception : public std::exception
{
    using std::string;
    using std::pair;
public:
     const char *what() const
    {
	return msg.c_str();
    }

private:
    string msg;
    pair<string,string> duplicates;
}; */
    
class hash_switch
{
public:
	typedef std::size_t hash_t;
	
	hash_switch(const char *cstr) 
	: m_fallen( false ),
	  m_broken(false)
	{
	    m_obj = hash_switch::compute_hash(cstr);
	}
	
	template<typename T>
	hash_switch(const T &str)
	: m_fallen( false ),
	  m_broken(false)
	{
	    m_obj = hash_switch::compute_hash(str);
	}
	
	template<typename T>
	static hash_t compute_hash(const T &str)
	{
	    return checksum(str, sizeof(T));
	}	
	
	static hash_t compute_hash(const char *cstr)
	{
	    return checksum(cstr, strlen(cstr));
	}

	bool operator != (hash_t rhash)
	{
	    using std::list;
	    using std::find;

	    list <hash_t>::iterator i =
	    find(m_objects.begin(), m_objects.end(), rhash);
	    
#	    ifndef BOOST_SWITCH_NO_DUPLICATED_THROW
	    if(!(m_objects.end() == i)) /* throw exception or something */
		throw std::exception();
#	    endif
	    
	    m_objects.push_back(rhash);
	    	    
	    return this->m_obj != rhash;
	}

	bool fallen_() const { return m_fallen; }
	void fall_() { m_fallen = true; }
	
	bool broken_() const { return m_broken; }
	void break_() { m_broken = true; }

	bool has_default_() const { return m_default; }
	void default_() { m_default = true; }
private:
	static hash_t checksum(const void *buf, uint bytes)
	{
	    using boost::uint8_t;
	    using boost::uint32_t;

	    const uint8_t *buffer = (const uint8_t*)buf;
	    register uint32_t y, z, sum = 0;

	    uint32_t s[2] = {0x8f1bbcdc, 0x5a827999},
		   m[2] = {0}, p[4] = {0};

	    while(bytes >= 8)
	    {
		p[0] = (s[0] << 5 ) | (s[0] >> 27);
		p[1] = (s[0] << 7 ) | (s[0] >> 25);
		p[2] = (s[1] << 11) | (s[1] >> 21);
		p[3] = (s[1] << 13) | (s[1] >> 19);

		m[0] = (*((uint32_t *)buffer));
		m[1] = (*((uint32_t *)(buffer+4)));

		y = m[0] + p[0];    z = m[1] + p[1];
		y += ((z << 4 | z >> 28) + z) ^ (sum + p[(sum& 3)]);    sum += 0x9e3779b9;
		z += ((y << 4 | y >> 28) + y) ^ (sum + p[(sum>>11) &3]);
		y += ((z << 5 | z >> 27) + z) ^ (sum + p[(sum& 3)]);    sum += 0x9e3779b9;
		z += ((y << 5 | y >> 27) + y) ^ (sum + p[(sum>>11) &3]);
		y += ((z << 6 | z >> 26) + z) ^ (sum + p[(sum& 3)]);    sum += 0x9e3779b9;
		z += ((y << 6 | y >> 26) + y) ^ (sum + p[(sum>>11) &3]);
		y += ((z << 7 | z >> 25) + z) ^ (sum + p[(sum& 3)]);    sum += 0x9e3779b9;
		z += ((y << 7 | y >> 25) + y) ^ (sum + p[(sum>>11) &3]);

		s[0] ^= m[0] ^ p[0] ^ (y + p[2]);
		s[1] ^= m[1] ^ p[1] ^ (z + p[3]);

		bytes -= 8;
		buffer += 8;
	    } ;

		p[0] = (s[0] << 5 ) | (s[0] >> 27);
		p[1] = (s[0] << 7 ) | (s[0] >> 25);
		p[2] = (s[1] << 11) | (s[1] >> 21);
		p[3] = (s[1] << 13) | (s[1] >> 19);

		mempcpy(m, buffer, bytes);

		m[0] = (m[0]);
		m[1] ^= ((uint32_t)bytes) << 29;

		y = m[0] + p[0];    z = m[1] + p[1];
		y += ((z << 4 | z >> 28) + z) ^ (sum + p[(sum& 3)]);    sum += 0x9e3779b9;
		z += ((y << 4 | y >> 28) + y) ^ (sum + p[(sum>>11) &3]);
		y += ((z << 5 | z >> 27) + z) ^ (sum + p[(sum& 3)]);    sum += 0x9e3779b9;
		z += ((y << 5 | y >> 27) + y) ^ (sum + p[(sum>>11) &3]);
		y += ((z << 6 | z >> 26) + z) ^ (sum + p[(sum& 3)]);    sum += 0x9e3779b9;
		z += ((y << 6 | y >> 26) + y) ^ (sum + p[(sum>>11) &3]);
		y += ((z << 7 | z >> 25) + z) ^ (sum + p[(sum& 3)]);    sum += 0x9e3779b9;
		z += ((y << 7 | y >> 25) + y) ^ (sum + p[(sum>>11) &3]);

		s[0] ^= m[0] ^ p[0] ^ (y + p[2]);
		s[1] ^= m[0] ^ p[0] ^ (z + p[3]);
	    
	    return static_cast<hash_t>(s[0] ^ s[1]);
	}
	bool m_default; // current object has default
	bool m_fallen;  // matching obkject has been found
	bool m_broken;  // broken switch
	hash_t m_obj;	// current hash object
	std::list <hash_t> m_objects;
};

#define BOOST_SWITCH_SIGNITURE			BOOST_PP_CAT(BOOST_PP_CAT(BOOST_SWITCH_SIGNITURE, _), _UUID_)
#define BOOST_SWITCH_MAIN_OBJECT		BOOST_PP_CAT(BOOST_SWITCH_SIGNITURE, MAIN_OBJECT)
#define BOOST_SWITCH_JMP_SIGNITURE(COUNTER)	BOOST_PP_CAT(BOOST_SWITCH_SIGNITURE, COUNTER)
#define BOOST_SWITCH_JMP_SIGNITURE_FWD(COUNTER) BOOST_PP_CAT(BOOST_SWITCH_SIGNITURE, BOOST_PP_ADD(COUNTER, 1))
#define BOOST_BREAK				BOOST_SWITCH_MAIN_OBJECT.break_()

// TODO: FIXME: store the default jump, and jump to it at the end of the switch
#ifdef BOOST_SWITCH_NO_DUPLICATED_DEFAULT_THROW
#define BOOST_DEFAULT	\
    BOOST_SWITCH_JMP_SIGNITURE(BOOST_PP_COUNTER): \
    BOOST_SWITCH_MAIN_OBJECT.default_();
#else /* !BOOST_SWITCH_NO_DUPLICATED_DEFAULT_THROW */
    #define BOOST_DEFAULT	\
    BOOST_SWITCH_JMP_SIGNITURE(BOOST_PP_COUNTER): \
    if( BOOST_SWITCH_MAIN_OBJECT.has_default_() ) {\
        throw std::exception(); /* we already have a default object */ \
    } \
    BOOST_SWITCH_MAIN_OBJECT.default_(); /* Set has_default() flag */

#endif /* BOOST_SWITHC_NO_DUPLICATED_DEFAULT_THROW */

#define BOOST_SWITCH_END  \
    } while( false ); \
 } catch( std::exception &ex)  { \
     std::cerr << "BOOST_SWITCH: error @file:line["<<__FILE__<<":"<<__LINE__<< \
     "] @function[" << BOOST_CURRENT_FUNCTION << \
     "] contains duplicated values." << std::endl; \
 } catch( ... ) {  \
     /* for any other exceptions throw them back at programmer's face */ \
     throw; \
 }

#define BOOST_SWITCH(main_object)\
try { \
    do {\
	boost::hash_switch BOOST_SWITCH_MAIN_OBJECT( main_object );


#ifdef BOOST_DEBUG
#   define BOOST_CASE(object)  \
    BOOST_SWITCH_JMP_SIGNITURE(BOOST_PP_COUNTER):   \
    if ((BOOST_SWITCH_MAIN_OBJECT.broken_() || (!BOOST_SWITCH_MAIN_OBJECT.fallen_())) &&\
	(BOOST_SWITCH_MAIN_OBJECT.broken_() || (BOOST_SWITCH_MAIN_OBJECT != boost::hash_switch::compute_hash(object)))) {\
	goto BOOST_SWITCH_JMP_SIGNITURE_FWD(BOOST_PP_COUNTER); \
    } else { \
	BOOST_SWITCH_MAIN_OBJECT.fall_(); \
    }
#else /* !BOOST_DEBUG */
#   define BOOST_CASE(object)  \
    BOOST_SWITCH_JMP_SIGNITURE(BOOST_PP_COUNTER):  \
    if( ((!BOOST_SWITCH_MAIN_OBJECT.fallen_()) && \
	(BOOST_SWITCH_MAIN_OBJECT != boost::hash_switch::compute_hash(object))) ||\
	BOOST_SWITCH_MAIN_OBJECT.broken_() ) {	\
	goto BOOST_SWITCH_JMP_SIGNITURE_FWD(BOOST_PP_COUNTER); \
    } else { \
	BOOST_SWITCH_MAIN_OBJECT.fall_(); \
    }
#endif /* BOOST_DEBUG */

} // namespace boost

#endif	/* BOOST_SWITCH_HPP */
