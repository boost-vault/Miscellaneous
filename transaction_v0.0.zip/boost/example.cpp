#include <iostream>
#include <string>
#include "transaction.hpp"

int main()
{
    std::string name = "box";
    float weight = 120.5f;
    unsigned int count = 57;

    try
    {
        boost::transaction t;
        t.begin(name);
        t.begin(weight);
        t.begin(count);

        //throw std::exception("preved!");

        name = "ball";

        //throw std::exception("preved!");

        weight = 3.2f;

        //throw std::exception("preved!");

        count = 5;

        //throw std::exception("preved!");

        t.commit();
    }
    catch(std::exception& e)
    {
        std::cerr << e.what() << std::endl;
    }

    std::cout << "name: "   << name   << std::endl;
    std::cout << "weight: " << weight << std::endl;
    std::cout << "count: "  << count  << std::endl;

    return 0;
}