#if !defined (BOOST_TRANSACTION_HPP)
#define BOOST_TRANSACTION_HPP

// transaction.hpp
//
// Created: 02.05.2007
// Purpose: Provide transaction code behaviour
// Limitation #1: Must not be used for an entities having shared resources
// Limitation #2: Transaction entities must have public copy constructor and assign operator
// Limitation #3: Transaction entities copy constructor, assign operator and destructor must not generate any exceptions
// Consideration: It's possible to specify a set of types which are safe for transaction via "type list" tool

#include <stack>
#include <vector>
#include <boost/noncopyable.hpp>
#include <boost/shared_ptr.hpp>

namespace boost
{

class transaction : public noncopyable // transaction is noncopyable
{
public:

    transaction()
    : m_success(false) // initially transaction result is set to failure
    {
    }

    ~transaction() throw() // must not generate any exceptions
    {
        if (m_success) // in case of transaction success destructor cleanse transaction container
        {
            clear();
        }
        else // in case of transaction failure destructor reverts all changes
        {
            revert();
        }
    }

    // transaction object accepter
    template <class T>
    void begin(T& object)
    {
        m_owner_container.push(owner_interface_ptr(new owner<T>(object)));
    }

    // sets transaction result to success; must be the last instruction in the "try" block
    void commit() throw()
    {
        m_success = true;
    }

private:

    // transaction object owner interface
    class owner_interface : public noncopyable
    {
    public:

        owner_interface()
        {
        }

        virtual ~owner_interface()
        {
        }

        virtual void revert() const = 0;
    };

    typedef shared_ptr<owner_interface> owner_interface_ptr;

    // transaction object owner implementation
    template <class T>
    class owner : public owner_interface
    {
    public:

        owner(T& object)
        : m_reference(object)
        , m_value    (object)
        {
        }

        virtual void revert() const
        {
            m_reference = m_value;
        }

    private:

        T& m_reference;
        T m_value;
    };

    // stack-based transaction container typedef
    typedef std::stack<owner_interface_ptr, std::vector<owner_interface_ptr> > owner_container;

    // stack-based transaction container
    owner_container m_owner_container;

    // transaction result flag
    bool m_success;

    // stack-principle transaction container cleaning
    void clear()
    {
        while (!m_owner_container.empty())
        {
            m_owner_container.pop();
        }
    }

    // stack-principle transaction changes reverting
    void revert()
    {
        while (!m_owner_container.empty())
        {
            m_owner_container.top()->revert();
            m_owner_container.pop();
        }
    }
};

} // namespace boost

#endif  // BOOST_TRANSACTION_HPP