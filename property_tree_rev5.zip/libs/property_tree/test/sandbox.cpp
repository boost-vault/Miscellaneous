#include <boost/property_tree/ptree.hpp>
#include <iostream>

int main()
{

    boost::property_tree::ptree pt;
    pt.put("ala", 7);

}