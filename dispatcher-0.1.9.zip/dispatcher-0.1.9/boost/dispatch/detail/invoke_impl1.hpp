// Copyright 2006 (C) Dean Michael Berris <dean@orangeandbronze.com>
// Distributed under the Boost Software License, Version 1.0. (See accompanying
// file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)

#ifndef __INVOKE_IMPL1_HPP_
#define __INVOKE_IMPL1_HPP_

#include <boost/function.hpp>

namespace boost {
    namespace dispatch {
        namespace detail {

            template <typename ReturnType, typename DispatcherType,
                typename arg1_type
            >
            struct invoke_impl_1 {
                typedef typename DispatcherType::index_type index_type;
                typedef boost::function< void (typename DispatcherType::result_type) > aggregator_t;

                aggregator_t _aggregator;
                DispatcherType & _dispatcher;
                arg1_type _arg1;

                invoke_impl_1 (
                    DispatcherType & dispatcher,
                    aggregator_t aggregator
                    ) : _dispatcher(dispatcher), _aggregator(aggregator)
                { } ;

                invoke_impl_1<ReturnType, DispatcherType, arg1_type> & operator()
                    (const arg1_type & arg1) {
                        _arg1 = arg1;
                        return *this;
                };
            };

            template <typename DispatcherType,
                typename arg1_type
            >
            struct invoke_impl_1<void, DispatcherType, arg1_type> {
                typedef typename DispatcherType::index_type index_type;
                typedef boost::function<void (int)> aggregator_t;

                aggregator_t _aggregator;
                DispatcherType & _dispatcher;
                arg1_type _arg1;

                invoke_impl_1 (
                    DispatcherType & dispatcher,
                    aggregator_t aggregator
                    ) : _dispatcher(dispatcher), _aggregator(default_aggregator<void>())
                { } ;

                invoke_impl_1<void, DispatcherType, arg1_type> & operator()
                    (const arg1_type & arg1) {
                        _arg1 = arg1;
                        return *this;
                };
            };

            template <typename ReturnType, typename DispatcherType, 
                typename arg1_type
            >
            invoke_impl_1 <ReturnType, DispatcherType, arg1_type> & operator<<
                ( invoke_impl_1<ReturnType, DispatcherType, arg1_type> & invoker,
                const typename DispatcherType::index_type & index ) {
                    invoker._aggregator(invoker._dispatcher[index](invoker._arg1));
                    return invoker;
            };

            template <typename DispatcherType,
                typename arg1_type
            >
            invoke_impl_1 <void, DispatcherType, arg1_type> & operator<< 
                ( invoke_impl_1<void, DispatcherType, arg1_type> & invoker,
                const typename DispatcherType::index_type & index ) {
                    invoker._dispatcher[index](invoker._arg1);
                    return invoker;
            };

        }; // namespace detail
    }; // namespace dispatch
}; // namespace boost

#endif
