/*!
 * (C) 2008 Andrey Semashev
 *
 * Use, modification and distribution is subject to the Boost Software License, Version 1.0.
 * (See accompanying file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
 */

#include <iostream>
#include <string>
#include <boost/ref.hpp>
#include <boost/weak_ptr.hpp>
#include <boost/shared_ptr.hpp>
#include <boost/new_shared.hpp>

using boost::ref;
using boost::shared_ptr;
using boost::weak_ptr;
using boost::new_shared;
using boost::use_allocator;
using boost::use_deleter;


struct my_class
{
    int m_n;

    my_class() : m_n(0)
    {
        std::cout << "my_class(), this = " << this << std::endl;
    }
    my_class(int n) : m_n(n)
    {
        std::cout << "my_class(int n = " << n << "), this = " << this << std::endl;
    }
    my_class(std::string& s) : m_n(s.size())
    {
        std::cout << "my_class(string& s = " << s << "), this = " << this << std::endl;
        s = "dcba";
    }
    ~my_class()
    {
        std::cout << "~my_class(), m_n = " << m_n << ", this = " << this << std::endl;
    }
};

struct my_deleter
{
    template< typename T >
    void operator() (T* p) const
    {
        std::cout << "Calling my_deleter" << std::endl;
        p->~T();
    }
};

int main(int, char*[])
{
    shared_ptr< my_class > p1 = new_shared< my_class >();

    std::string s = "abcd";
    shared_ptr< my_class > p2 = new_shared< my_class >(boost::ref(s));
    std::cout << "check s: " << s << std::endl;
    
    weak_ptr< my_class > w1 = p1;
    std::cout << "constructed weak_ptr" << std::endl;
    
    p1 = p2;
    std::cout << "assigned p1 = p2" << std::endl;

    p2 = new_shared< my_class >(use_deleter(my_deleter()), 10);

    return 0;
}
