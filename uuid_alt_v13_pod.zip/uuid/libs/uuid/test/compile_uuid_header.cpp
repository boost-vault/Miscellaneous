//  (C) Copyright Andy Tompkins 2008. Permission to copy, use, modify, sell and
//  distribute this software is granted provided this copyright notice appears
//  in all copies. This software is provided "as is" without express or implied
//  warranty, and with no claim as to its suitability for any purpose.

// Distributed under the Boost Software License, Version 1.0. (See
// accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

//  libs/uuid/test/compile_uuid_header.cpp  -------------------------------//

// Purpose: to make sure that a translation unit consisting of just the contents 
// of the header file will compile successfully.

#include <boost/uuid/uuid.hpp>
