#include "..\..\..\boost\flags.hpp"
#include "..\..\..\boost\flags_no_default.hpp"

//--------------------------------------------------------------------------------------------------
//
//  test.cpp: Test file for flags and flags_no_default
//
//  (C) Copyright Iain Denniston 2007
//
//  Distributed under the Boost Software License, Version 1.0. (See
//  accompanying file LICENSE_1_0.txt or copy at
//  http://www.boost.org/LICENSE_1_0.txt)
//
//--------------------------------------------------------------------------------------------------

using boost::flags;
using boost::flags_no_default;

//--------------------------------------------------------------------------------------------------
//--------------------------------------------------------------------------------------------------

enum e_test_enum_foo
{
    test_enum_foo_1=1<<0,
    test_enum_foo_2=1<<1,
    test_enum_foo_3=1<<2,
};

//--------------------------------------------------------------------------------------------------

enum e_test_enum_bar
{
    test_enum_bar_1=1<<2,
    test_enum_bar_2=1<<3,
};

//--------------------------------------------------------------------------------------------------
//--------------------------------------------------------------------------------------------------

bool test_func_no_flags(unsigned int options)
{
    return options!=0;
}

//--------------------------------------------------------------------------------------------------
//--------------------------------------------------------------------------------------------------

bool test_func_flags_1(flags<e_test_enum_foo> options)
{
    return options.get()!=0;
}

//--------------------------------------------------------------------------------------------------

bool test_func_flags_2(flags<e_test_enum_bar> options)
{
    return options.get()!=0;
}

//--------------------------------------------------------------------------------------------------
//--------------------------------------------------------------------------------------------------

bool test_func_flags_no_default_1(flags_no_default<e_test_enum_foo> options)
{
    return options.get()!=0;
}

//--------------------------------------------------------------------------------------------------

bool test_func_flags_no_default_2(flags_no_default<e_test_enum_bar> options)
{
    return options.get()!=0;
}

//--------------------------------------------------------------------------------------------------
//--------------------------------------------------------------------------------------------------

int main(int argc, char* argv[])
{
    //Normal way of doing things
    test_func_no_flags(test_enum_foo_1 | test_enum_foo_2 | test_enum_foo_3 | test_enum_bar_1 | test_enum_bar_2);


    //test func 1
    test_func_flags_1(flags<e_test_enum_foo>());
    test_func_flags_1(test_enum_foo_1);
    test_func_flags_1(flags<e_test_enum_foo>(test_enum_foo_1) | test_enum_foo_2 | test_enum_foo_3);
    
    //Errors
//  test_func_flags_1(test_enum_bar_1);
//  test_func_flags_1(flags<e_test_enum_foo>(test_enum_foo_1) | test_enum_foo_2 | test_enum_foo_3 | test_enum_bar_1 | test_enum_bar_2);


    //test func 2
    test_func_flags_2(flags<e_test_enum_bar>());
    test_func_flags_2(test_enum_bar_1);
    test_func_flags_2(flags<e_test_enum_bar>(test_enum_bar_1) | test_enum_bar_2);

    //Errors
//  test_func_flags_2(test_enum_foo_1);
//  test_func_flags_2(flags<e_test_enum_bar>(test_enum_foo_1) | test_enum_foo_2 | test_enum_foo_3 | test_enum_bar_1 | test_enum_bar_2);


    //test func 3
    test_func_flags_no_default_1(test_enum_foo_1);
    test_func_flags_no_default_1(flags_no_default<e_test_enum_foo>(test_enum_foo_1) | test_enum_foo_2 | test_enum_foo_3);

    //Errors
//  test_func_flags_no_default_1(flags_no_default<e_test_enum_foo>());
//  test_func_flags_no_default_1(test_enum_bar_1);
//  test_func_flags_no_default_1(flags_no_default<e_test_enum_foo>(test_enum_foo_1) | test_enum_foo_2 | test_enum_foo_3 | test_enum_bar_1 | test_enum_bar_2);


    //test func 4
    test_func_flags_no_default_2(test_enum_bar_1);
    test_func_flags_no_default_2(flags_no_default<e_test_enum_bar>(test_enum_bar_1) | test_enum_bar_2);

    //Errors
//  test_func_flags_no_default_1(flags_no_default<e_test_enum_bar>());
//  test_func_flags_no_default_2(test_enum_foo_1);
//  test_func_flags_no_default_2(flags_no_default<e_test_enum_bar>(test_enum_bar_1) | test_enum_foo_2 | test_enum_foo_3 | test_enum_bar_1 | test_enum_bar_2);


    //flags combination tests
    {
        flags<e_test_enum_foo> options_1;
        flags<e_test_enum_foo> options_2(test_enum_foo_1);
        flags<e_test_enum_foo> options_3(test_enum_foo_2);

        options_1 = options_2 | options_3 & options_2 ^ test_enum_foo_1;
        options_1 = ~flags<e_test_enum_foo>(test_enum_foo_3);

        options_2 |= options_3;
        options_2 &= options_3;
        options_2 ^= options_3;

        options_2 |= test_enum_foo_1;
        options_2 &= test_enum_foo_1;
        options_2 ^= test_enum_foo_1;

        bool result = options_2 == options_3 && options_2 == test_enum_foo_1;

        //Errors
        //  options_2 |= test_enum_bar_1;
        //  options_2 &= test_enum_bar_1;
        //  options_2 ^= test_enum_bar_1;
    }


    //flags_no_default combination tests
   {
        flags_no_default<e_test_enum_foo> options_1(test_enum_foo_1);
        flags_no_default<e_test_enum_foo> options_2(test_enum_foo_1);
        flags_no_default<e_test_enum_foo> options_3(test_enum_foo_2);

        options_1 = options_2 | options_3 & options_2 ^ test_enum_foo_1;
        options_1 = ~flags_no_default<e_test_enum_foo>(test_enum_foo_3);

        options_2 |= options_3;
        options_2 &= options_3;
        options_2 ^= options_3;

        options_2 |= test_enum_foo_1;
        options_2 &= test_enum_foo_1;
        options_2 ^= test_enum_foo_1;

        bool result = options_2 == options_3 && options_2 == test_enum_foo_1;
 
        //Errors
        //flags_no_default<e_test_enum_foo> options_1;
        //  options_2 |= test_enum_bar_1;
        //  options_2 &= test_enum_bar_1;
        //  options_2 ^= test_enum_bar_1;
    }
}

//--------------------------------------------------------------------------------------------------
//--------------------------------------------------------------------------------------------------
