#ifndef BOOST_FLAGS_HPP
#define BOOST_FLAGS_HPP

//--------------------------------------------------------------------------------------------------
//
//  flags.hpp: enummeration flags type safety template
//
//  (C) Copyright Iain Denniston 2007
//
//  Distributed under the Boost Software License, Version 1.0. (See
//  accompanying file LICENSE_1_0.txt or copy at
//  http://www.boost.org/LICENSE_1_0.txt)
//
//--------------------------------------------------------------------------------------------------

namespace boost
{
    //--------------------------------------------------------------------------------------------------
    //
    // flags class template
    //      enum_type: named enum
    //      flag_type: storage type for the enum flags
    //      default_value: flag default value
    //
    //--------------------------------------------------------------------------------------------------

    template<typename enum_type,
             typename flag_type=unsigned int,
             flag_type default_value=0>
    class flags
    {
    public:
        //Construction
        flags() : m_flags(default_value)
        {
        }

        flags(enum_type e) : m_flags(e)
        {
        }

        //Copying
        flags(const flags& src) : m_flags(src.m_flags)
        {
        }

        const flags& operator=(enum_type e)
        {
            m_flags=e;
            return *this;
        }

        const flags& operator=(const flags& rhs)
        {
            m_flags=rhs.m_flags;
            return *this;
        }

        //(in)equality operators
        bool operator==(enum_type e) const
        {
            return m_flags==e;
        }

        bool operator!=(enum_type e) const
        {
            return !((*this)==e);
        }

        bool operator==(const flags& rhs) const
        {
            return m_flags==rhs.m_flags;
        }

        bool operator!=(const flags& rhs) const
        {
            return !((*this)==rhs);
        }

        //Bitwise operators
        const flags& operator|=(enum_type e)
        {
            m_flags|=e;
            return *this;
        }

        const flags& operator&=(enum_type e)
        {
            m_flags&=e;
            return *this;
        }

        const flags& operator^=(enum_type e)
        {
            m_flags^=e;
            return *this;
        }

        const flags& operator|=(const flags& rhs)
        {
            m_flags|=rhs.m_flags;
            return *this;
        }

        const flags& operator&=(const flags& rhs)
        {
            m_flags&=rhs.m_flags;
            return *this;
        }

        const flags& operator^=(const flags& rhs)
        {
            m_flags^=rhs.m_flags;
            return *this;
        }

        const flags operator~()            
        {
            flags temp(*this);
            temp.m_flags = ~temp.m_flags;
            return temp;
        }

        //conversion operator (converting directly to flag_type allows this template
        // to be used directly in current code with minimum changes)
        //As with all uses of conversion operator - potentially problematic
//      operator flag_type() const
//      {
//          return m_flags;
//      }

        //Occasionally useful auxiliary function
        void reset()
        {
            m_flags=default_value;
        }

        //Note get is not required if a conversion operator is defined
        flag_type get() const
        {
            return m_flags;
        }

    private: //Data
        flag_type m_flags;
    };

    //--------------------------------------------------------------------------------------------------
    // Non-member operators
    //--------------------------------------------------------------------------------------------------

    // lhs: enum_type
    // rhs: flag_type

    template<typename enum_type, typename flag_type, flag_type default_value>
    const flags<enum_type, flag_type, default_value> operator|(enum_type e, const flags<enum_type, flag_type, default_value>& rhs)
    {
        return flags<enum_type, flag_type, default_value>(e)|=rhs;
    }

    //--------------------------------------------------------------------------------------------------

    template<typename enum_type, typename flag_type, flag_type default_value>
    const flags<enum_type, flag_type, default_value> operator&(enum_type e, const flags<enum_type, flag_type, default_value>& rhs)
    {
        return flags<enum_type, flag_type, default_value>(e)&=rhs;
    }

    //--------------------------------------------------------------------------------------------------

    template<typename enum_type, typename flag_type, flag_type default_value>
    const flags<enum_type, flag_type, default_value> operator^(enum_type e, const flags<enum_type, flag_type, default_value>& rhs)
    {
        return flags<enum_type, flag_type, default_value>(e)^=rhs;
    }

    //--------------------------------------------------------------------------------------------------
    //
    //--------------------------------------------------------------------------------------------------

    // lhs: flag_type
    // rhs: enum_type

    template<typename enum_type, typename flag_type, flag_type default_value>
    const flags<enum_type, flag_type, default_value> operator|(const flags<enum_type, flag_type, default_value>& lhs, enum_type e)
    {
        return flags<enum_type, flag_type, default_value>(lhs)|=e;
    }

    //--------------------------------------------------------------------------------------------------

    template<typename enum_type, typename flag_type, flag_type default_value>
    const flags<enum_type, flag_type, default_value> operator&(const flags<enum_type, flag_type, default_value>& lhs, enum_type e)
    {
        return flags<enum_type, flag_type, default_value>(lhs)&=e;
    }

    //--------------------------------------------------------------------------------------------------

    template<typename enum_type, typename flag_type, flag_type default_value>
    const flags<enum_type, flag_type, default_value> operator^(const flags<enum_type, flag_type, default_value>& lhs, enum_type e)
    {
        return flags<enum_type, flag_type, default_value>(lhs)^=e;
    }

    //--------------------------------------------------------------------------------------------------
    //
    //--------------------------------------------------------------------------------------------------

    // lhs: flag_type
    // rhs: flag_type

    template<typename enum_type, typename flag_type, flag_type default_value>
    const flags<enum_type, flag_type, default_value> operator|(const flags<enum_type, flag_type, default_value>& lhs, const flags<enum_type, flag_type, default_value>& rhs)
    {
        return flags<enum_type, flag_type, default_value>(lhs)|=rhs;
    }

    //--------------------------------------------------------------------------------------------------

    template<typename enum_type, typename flag_type, flag_type default_value>
    const flags<enum_type, flag_type, default_value> operator&(const flags<enum_type, flag_type, default_value>& lhs, const flags<enum_type, flag_type, default_value>& rhs)
    {
        return flags<enum_type, flag_type, default_value>(lhs)&=rhs;
    }

    //--------------------------------------------------------------------------------------------------

    template<typename enum_type, typename flag_type, flag_type default_value>
    const flags<enum_type, flag_type, default_value> operator^(const flags<enum_type, flag_type, default_value>& lhs, const flags<enum_type, flag_type, default_value>& rhs)
    {
        return flags<enum_type, flag_type, default_value>(lhs)^=rhs;
    }

    //--------------------------------------------------------------------------------------------------
    //
    //--------------------------------------------------------------------------------------------------
}

#endif //BOOST_FLAGS_HPP

