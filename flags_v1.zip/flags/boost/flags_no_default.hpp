#ifndef BOOST_FLAGS_NO_DEFAULT_HPP
#define BOOST_FLAGS_NO_DEFAULT_HPP

//--------------------------------------------------------------------------------------------------
//
//  flags_no_default.hpp: enummeration flags type safety template, enforces the user to supply an
//                          enum
//
//  (C) Copyright Iain Denniston 2007
//
//  Distributed under the Boost Software License, Version 1.0. (See
//  accompanying file LICENSE_1_0.txt or copy at
//  http://www.boost.org/LICENSE_1_0.txt)
//
//--------------------------------------------------------------------------------------------------

namespace boost
{
    //--------------------------------------------------------------------------------------------------
    //
    // flags_no_default class template
    //      enum_type: named enum
    //      flag_type: storage type for the enum flags
    //
    //--------------------------------------------------------------------------------------------------

    template<typename enum_type,
             typename flag_type=unsigned int>
    class flags_no_default
    {
    public:
        //Construction
        flags_no_default(enum_type e) : m_flags(e)
        {
        }

        //Copying
        flags_no_default(const flags_no_default& src) : m_flags(src.m_flags)
        {
        }

        const flags_no_default& operator=(enum_type e)
        {
            m_flags=e;
            return *this;
        }

         const flags_no_default& operator=(const flags_no_default& rhs)
        {
            m_flags=rhs.m_flags;
            return *this;
        }

        //(in)equality operators
        bool operator==(enum_type e) const
        {
            return m_flags==e;
        }

        bool operator!=(enum_type e) const
        {
            return !((*this)==e);
        }

        bool operator==(const flags_no_default& rhs) const
        {
            return m_flags==rhs.m_flags;
        }

        bool operator!=(const flags_no_default& rhs) const
        {
            return !((*this)==rhs);
        }

        //Bitwise operators
        const flags_no_default& operator|=(enum_type e)
        {
            m_flags|=e;
            return *this;
        }

        const flags_no_default& operator&=(enum_type e)
        {
            m_flags&=e;
            return *this;
        }

        const flags_no_default& operator^=(enum_type e)
        {
            m_flags^=e;
            return *this;
        }

        const flags_no_default& operator|=(const flags_no_default& rhs)
        {
            m_flags|=rhs.m_flags;
            return *this;
        }

        const flags_no_default& operator&=(const flags_no_default& rhs)
        {
            m_flags&=rhs.m_flags;
            return *this;
        }

        const flags_no_default& operator^=(const flags_no_default& rhs)
        {
            m_flags^=rhs.m_flags;
            return *this;
        }

        const flags_no_default operator~()            
        {
            flags_no_default temp(*this);
            temp.m_flags = ~temp.m_flags;
            return temp;
        }

        //conversion operator (converting directly to flag_type allows this template
        // to be used directly in current code with minimum changes)
        //As with all uses of conversion operator - potentially problematic
//      operator flag_type() const
//      {
//          return m_flags;
//      }

        //Note get is not required if a conversion operator is defined
        flag_type get() const
        {
            return m_flags;
        }

    private: //Data
        flag_type m_flags;
    };

    //--------------------------------------------------------------------------------------------------
    // Non-member operators
    //--------------------------------------------------------------------------------------------------

    // lhs: enum_type
    // rhs: flag_type

    template<typename enum_type, typename flag_type>
    const flags_no_default<enum_type, flag_type> operator|(enum_type e, const flags_no_default<enum_type, flag_type>& rhs)
    {
        return flags_no_default<enum_type, flag_type>(e)|=rhs;
    }

    //--------------------------------------------------------------------------------------------------

    template<typename enum_type, typename flag_type>
    const flags_no_default<enum_type, flag_type> operator&(enum_type e, const flags_no_default<enum_type, flag_type>& rhs)
    {
        return flags_no_default<enum_type, flag_type>(e)&=rhs;
    }

    //--------------------------------------------------------------------------------------------------

    template<typename enum_type, typename flag_type>
    const flags_no_default<enum_type, flag_type> operator^(enum_type e, const flags_no_default<enum_type, flag_type>& rhs)
    {
        return flags_no_default<enum_type, flag_type>(e)^=rhs;
    }

    //--------------------------------------------------------------------------------------------------
    //
    //--------------------------------------------------------------------------------------------------

    // lhs: flag_type
    // rhs: enum_type

    template<typename enum_type, typename flag_type>
    const flags_no_default<enum_type, flag_type> operator|(const flags_no_default<enum_type, flag_type>& lhs, enum_type e)
    {
        return flags_no_default<enum_type, flag_type>(lhs)|=e;
    }

    //--------------------------------------------------------------------------------------------------

    template<typename enum_type, typename flag_type>
    const flags_no_default<enum_type, flag_type> operator&(const flags_no_default<enum_type, flag_type>& lhs, enum_type e)
    {
        return flags_no_default<enum_type, flag_type>(lhs)&=e;
    }

    //--------------------------------------------------------------------------------------------------

    template<typename enum_type, typename flag_type>
    const flags_no_default<enum_type, flag_type> operator^(const flags_no_default<enum_type, flag_type>& lhs, enum_type e)
    {
        return flags_no_default<enum_type, flag_type>(lhs)^=e;
    }

    //--------------------------------------------------------------------------------------------------
    //
    //--------------------------------------------------------------------------------------------------

    // lhs: flag_type
    // rhs: flag_type

    template<typename enum_type, typename flag_type>
    const flags_no_default<enum_type, flag_type> operator|(const flags_no_default<enum_type, flag_type>& lhs, const flags_no_default<enum_type, flag_type>& rhs)
    {
        return flags_no_default<enum_type, flag_type>(lhs)|=rhs;
    }

    //--------------------------------------------------------------------------------------------------

    template<typename enum_type, typename flag_type>
    const flags_no_default<enum_type, flag_type> operator&(const flags_no_default<enum_type, flag_type>& lhs, const flags_no_default<enum_type, flag_type>& rhs)
    {
        return flags_no_default<enum_type, flag_type>(lhs)&=rhs;
    }

    //--------------------------------------------------------------------------------------------------

    template<typename enum_type, typename flag_type>
    const flags_no_default<enum_type, flag_type> operator^(const flags_no_default<enum_type, flag_type>& lhs, const flags_no_default<enum_type, flag_type>& rhs)
    {
        return flags_no_default<enum_type, flag_type>(lhs)^=rhs;
    }

    //--------------------------------------------------------------------------------------------------
    //
    //--------------------------------------------------------------------------------------------------
}

#endif //BOOST_FLAGS_NO_DEFAULT_HPP

