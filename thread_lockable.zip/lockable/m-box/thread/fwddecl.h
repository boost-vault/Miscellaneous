#ifndef _MBOX_THREAD_FWDDECL_HPP_
#define _MBOX_THREAD_FWDDECL_HPP_

#include <tr1/type_traits>


namespace mbox
{

enum locking_policy;

template<typename T_mutex, locking_policy I_policy>
struct choose_lock;

template<typename T_mutex> 
struct lockable_base;
template<typename T_type, typename T_mutex> 
struct lockable;
template<typename T_type, typename T_mutex> 
struct safe_lockable;

template<locking_policy I_policy, typename T_type, typename T_mutex = typename T_type::mutex_type, typename T_islockable = typename std::tr1::is_base_of<lockable_base<T_mutex>, T_type>::type>
class lock_acquirer;
template<typename T_type, typename T_mutex = typename T_type::mutex_type, typename T_islockable = typename std::tr1::is_base_of<lockable_base<T_mutex>, T_type>::type>
class writelock_acquirer;
template<typename T_type, typename T_mutex = typename T_type::mutex_type, typename T_islockable = typename std::tr1::is_base_of<lockable_base<T_mutex>, T_type>::type>
class readlock_acquirer;

}


#endif	// end file guard
