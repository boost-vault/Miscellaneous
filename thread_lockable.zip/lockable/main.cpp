#include <iostream>
#include <boost/shared_ptr.hpp>
#include <boost/bind.hpp>
#include <boost/function.hpp>
#include <boost/thread/thread.hpp>
#include <boost/thread/mutex.hpp>
#include <boost/thread/xtime.hpp>
#include <m-box/thread/lockable.h>
#include <m-box/thread/lock_acquirer.h>


// specialize metafunction choose_lock for boost
namespace mbox {

    template<locking_policy I_policy>
    struct choose_lock<boost::mutex, I_policy>
    {
        typedef boost::mutex::scoped_lock type;
    };

}

typedef mbox::safe_lockable<int, boost::mutex> mutexlockable_int;
typedef boost::shared_ptr<mutexlockable_int> shared_writelockable_int;
typedef boost::shared_ptr<const mutexlockable_int> shared_readlockable_int;


namespace {
    volatile int g_bDoRun = 1;
}


void thread1_function(shared_writelockable_int pLockableInt)
{
    while (g_bDoRun)
    {
        {
            mbox::writelock_acquirer<mutexlockable_int> int_lock(*pLockableInt);
            int& i = access_acquiree(int_lock);
            ++i;
        }
        boost::xtime xt;
        boost::xtime_get(&xt, boost::TIME_UTC);
        xt.nsec += 1000*1000*100;
        boost::thread::sleep(xt);
    }
}

void thread2_function(shared_readlockable_int pLockableInt)
{
    while (g_bDoRun)
    {
        {
            mbox::readlock_acquirer<const mutexlockable_int> int_lock(*pLockableInt);
            const int& i = access_acquiree(int_lock);
            std::cout << "thread2: " << i << std::endl;
        }
        boost::xtime xt;
        boost::xtime_get(&xt, boost::TIME_UTC);
        xt.sec += 1;
        boost::thread::sleep(xt);
    }
}


int main()
{
    std::cout << "press <enter> to end the program" << std::endl;

    const shared_writelockable_int pLockableInt(new mutexlockable_int(10));
    boost::thread thread1(boost::bind(&thread1_function, pLockableInt));
    boost::thread thread2(boost::bind(&thread2_function, pLockableInt));

    std::cin.get();
    g_bDoRun = 0;
    thread1.join();
    thread2.join();

    return 0;
}
