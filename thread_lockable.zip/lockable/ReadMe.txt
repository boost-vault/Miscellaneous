compile with:

<compiler> -I<project-dir> -I<boost-include-dir> -L<boost-lib-dir> main.cpp
