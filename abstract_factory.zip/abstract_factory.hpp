/*=============================================================================
    Copyright (c) 2008 Stathi Triadis
  
    Use modification and distribution are subject to the Boost Software 
    License, Version 1.0. (See accompanying file LICENSE_1_0.txt or copy at
    http://www.boost.org/LICENSE_1_0.txt).
==============================================================================*/

#ifndef BOOST_ABSTRACT_FACTORY_HPP_INCLUDED
#   ifndef BOOST_PP_IS_ITERATING

#     include <boost/preprocessor/iteration/iterate.hpp>
#     include <boost/preprocessor/repetition/enum_params.hpp>
#     include <boost/preprocessor/repetition/enum_binary_params.hpp>
#     include <boost/preprocessor/iteration/local.hpp>
#     include <boost/type_traits/remove_cv.hpp>
#     include <boost/functional/factory.hpp>
#     include <boost/functional/forward_adapter.hpp>

#     ifndef BOOST_ABSTRACT_FACTORY_MAX_ARITY
#       define BOOST_ABSTRACT_FACTORY_MAX_ARITY 10
#     elif BOOST_ABSTRACT_FACTORY_MAX_ARITY < 3
#       undef  BOOST_ABSTRACT_FACTORY_MAX_ARITY
#       define BOOST_ABSTRACT_FACTORY_MAX_ARITY 3
#     endif

namespace boost
{

    template<typename BasePtr>
    struct abstract_factory
    {
    };

    template<typename AbstractFactory, typename DerivedPtr, typename Allocator = std::allocator<void> >
    struct concrete_factory
    {
    };

    //
    //  Implementation of abstract_factory for default constructor.
    //
    template<typename BasePtr>
    struct abstract_factory<BasePtr()>
    {
        typedef typename boost::remove_cv<BasePtr>::type abstract_ptr_type;
    
        abstract_ptr_type operator()() const
        {
            return do_create();
        }
    
    protected:
    
        virtual abstract_ptr_type do_create() const = 0;
    };
    
    //
    //  Implementation of concrete_factory for default constructor.
    //
    template<typename BasePtr, typename DerivedPtr, typename Allocator>
    struct concrete_factory<abstract_factory<BasePtr()>, DerivedPtr, Allocator>
        : public abstract_factory<BasePtr()>
    {
        typedef Allocator                                       allocator_type;
        typedef typename boost::remove_cv<BasePtr>::type        abstract_ptr_type;
        typedef typename boost::remove_cv<DerivedPtr>::type     derived_ptr_type;

    protected:
    
        abstract_ptr_type do_create() const
        {
            return m_factory();
        }

        boost::forward_adapter<boost::factory<derived_ptr_type, allocator_type> > m_factory;
    };


    // 
    //  Preprocessor iteration starts here
    //
#     define BOOST_PP_FILENAME_1 <boost/functional/abstract_factory_v3.hpp>
#     define BOOST_PP_ITERATION_LIMITS (1,BOOST_ABSTRACT_FACTORY_MAX_ARITY)
#     include BOOST_PP_ITERATE()

}

//
//  This defines the proprocessor iteration.
//  Partial template specialisation of the above stucts.
//
#     define BOOST_ABSTRACT_FACTORY_HPP_INCLUDED
#   else // defined(BOOST_PP_IS_ITERATING)
#     define N BOOST_PP_ITERATION()


    template<typename BasePtr, BOOST_PP_ENUM_PARAMS(N, typename Type)>
    struct abstract_factory<BasePtr(BOOST_PP_ENUM_PARAMS(N, Type))>
    {
        typedef typename boost::remove_cv<BasePtr>::type abstract_ptr_type;

        abstract_ptr_type operator()(
            BOOST_PP_ENUM_BINARY_PARAMS(N, Type, t)) const
        {
            return do_create(BOOST_PP_ENUM_PARAMS(N, t));
        }
    
    protected:
    
        virtual abstract_ptr_type do_create(
            BOOST_PP_ENUM_BINARY_PARAMS(N, Type, t)) const = 0;
    };


    template<typename BasePtr, typename DerivedPtr, BOOST_PP_ENUM_PARAMS(N, typename Type), typename Allocator>
    struct concrete_factory<abstract_factory<BasePtr(BOOST_PP_ENUM_PARAMS(N, Type))>, DerivedPtr, Allocator>
        : public abstract_factory<BasePtr(BOOST_PP_ENUM_PARAMS(N, Type))>
    {
        typedef Allocator                                       allocator_type;
        typedef typename boost::remove_cv<BasePtr>::type        abstract_ptr_type;
        typedef typename boost::remove_cv<DerivedPtr>::type     derived_ptr_type;

    protected:
    
        virtual abstract_ptr_type do_create(
            BOOST_PP_ENUM_BINARY_PARAMS(N, Type, t)) const
        {
            return m_factory(BOOST_PP_ENUM_PARAMS(N, t));
        }

        boost::forward_adapter<boost::factory<derived_ptr_type, allocator_type> > m_factory;
    };

#     undef N
#   endif // defined(BOOST_PP_IS_ITERATING)


#endif
