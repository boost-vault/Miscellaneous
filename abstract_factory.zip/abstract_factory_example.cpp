#include <string>
#include "abstract_factory.hpp"
#include <loki/AbstractFactory.h>

using namespace std;

using Loki::AbstractFactory;
using Loki::ConcreteFactory;

using boost::abstract_factory;
using boost::concrete_factory;

//
// Creation method for abstract factory. Basically copied from
// Loki::OpNewFactoryUnit except with the change to the
// DoCreate method, which creates one static instance of the
// concrete product.
//
template <class ConcreteProduct, class Base>
class StaticFactoryUnit : public Base
{
    typedef typename Base::ProductList BaseProductList;
    
protected:
    typedef typename BaseProductList::Tail ProductList;
    
public:
    typedef typename BaseProductList::Head AbstractProduct;
    ConcreteProduct* DoCreate(Loki::Type2Type<AbstractProduct>)
    {
        static ConcreteProduct* spTheProduct = new ConcreteProduct;
        return spTheProduct;
    }
};

//
// Some inheritance hierarchies.
// 
struct Bird
{
    Bird(const string& s, int i){}
    virtual ~Bird(){}
};
struct Sparrow : public Bird
{
    Sparrow(const string& s, int i) : Bird(s, i) {}
    virtual ~Sparrow(){}
};
struct Plane
{
    Plane(double d){}
    virtual ~Plane(){}
};
struct Jet : public Plane
{
    Jet(double d) : Plane(d) {}
    virtual ~Jet(){}
};

//
// The abstract_factory and concrete_factory types.
//
typedef abstract_factory<Bird*(const string&, int)> BirdFactory;
typedef concrete_factory<BirdFactory, Sparrow*>     SparrowFactory;

typedef abstract_factory<Plane*(double)>            PlaneFactory;
typedef concrete_factory<PlaneFactory, Jet*>        JetFactory;

//
// The abstract and concrete product lists to go into the Loki::AbstractFacory
// and Loki::ConcreteFactory.
//
typedef LOKI_TYPELIST_2(BirdFactory, PlaneFactory)  AbstractProducts;
typedef LOKI_TYPELIST_2(SparrowFactory, JetFactory) ConcreteProducts;

//
// The Loki AbstractFacory and ConcreteFactory typedefs
//
typedef AbstractFactory<AbstractProducts>           FactoryFactory; 
typedef ConcreteFactory<FactoryFactory, StaticFactoryUnit, ConcreteProducts>
                                                    ConcreteFactoryFactory;


int main(int agrc, char** args)
{
    FactoryFactory* p_factory_factory = new ConcreteFactoryFactory;

    Bird* bird = (*p_factory_factory->Create<BirdFactory>())("asdf", 1);
    assert(dynamic_cast<Sparrow*>(bird));

    Plane* plane = (*p_factory_factory->Create<PlaneFactory>())(3.14);
    assert(dynamic_cast<Jet*>(plane));
}



