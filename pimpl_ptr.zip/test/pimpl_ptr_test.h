#ifndef PIMPL_PTR_TEST__H
#define PIMPL_PTR_TEST__H


#include <boost/pimpl_ptr.hpp>




class CTest
{
public:

	CTest();
	~CTest();


	boost::pimpl_ptr<struct CMyValues1> m_ValuesWithDefaultConstructor;
	boost::pimpl_ptr<struct CMyValues2, boost::pimpls::manual_creation> m_ValuesWithNonDefaultConstructor;

	boost::pimpl_ptr<struct CMyValues1,boost::pimpls::lazy_creation> m_ValuesWithLazyCreator1;
	boost::pimpl_ptr<struct CMyValues2,boost::pimpls::manual_creation> m_ValuesWithLazyCreator2;
};



#endif
