#include "pimpl_ptr_test.h"

#include <vector>
#include <boost/config.hpp>
#include <boost/detail/lightweight_test.hpp>


static int g_valuesCount = 0;


struct CMyValues1
{
	CMyValues1()
	: _1(0)
	{
		++g_valuesCount;
	}
	CMyValues1( const CMyValues1& _copy)
	: _1(_copy._1)
	{
		++g_valuesCount;
	}
	~CMyValues1()
	{
		--g_valuesCount;
	}

	CMyValues1& operator = (const CMyValues1& _copy)
	{
		_1 = _copy._1;
		return *this;
	}

	bool operator == (const CMyValues1& rhs) const
	{
		return _1 == rhs._1;
	}

	bool operator < (const CMyValues1& rhs) const
	{
		return _1 < rhs._1;
	}

	void set( int _value)
	{
		_1 = _value;
	}

	int _1;
};


struct CMyValues2
{
	CMyValues2( int _i)
	: _1(_i)
	{
		++g_valuesCount;
	}

	CMyValues2( const CMyValues1& _copy)
	: _1(_copy._1)
	{
		++g_valuesCount;
	}

	CMyValues2& operator = (const CMyValues1& _copy)
	{
		_1 = _copy._1;
		return *this;
	}

	bool operator < (const CMyValues1& rhs) const
	{
		return _1 < rhs._1;
	}

	bool operator < (const CMyValues2& rhs) const
	{
		return _1 < rhs._1;
	}

	~CMyValues2()
	{
		--g_valuesCount;
	}

	int _1;
};



CTest::CTest()
: m_ValuesWithNonDefaultConstructor( new CMyValues2(234) )
{
}

CTest::~CTest()
{
}


int main(int argc, char* argv[])
{
	g_valuesCount = 0;
	BOOST_TEST( g_valuesCount == 0 );


	///
	/// Default construction
	///
	{
		boost::pimpl_ptr<CMyValues1> p1;
		BOOST_TEST( g_valuesCount == 1 );

		boost::pimpl_ptr<CMyValues1> p2;
		BOOST_TEST( g_valuesCount == 2 );

		BOOST_TEST( p1 == p2 );

		++p1->_1;
		BOOST_TEST( p1 != p2 );

		std::swap( p1, p2);
		boost::swap( p1, p2 );

		p1.swap( p2 );
		p1 = p2;
	}
	BOOST_TEST( g_valuesCount == 0 );


	///
	/// Manual creation
	///
	{
		boost::pimpl_ptr<CMyValues1, boost::pimpls::manual_creation> p1;
		BOOST_TEST( g_valuesCount == 0 );

		boost::pimpl_ptr<CMyValues1, boost::pimpls::manual_creation> p2;
		BOOST_TEST( g_valuesCount == 0 );

		p1.set( new CMyValues1 );
		p2.set( new CMyValues1 );
		BOOST_TEST( g_valuesCount == 2 );

		BOOST_TEST( p1 == p2 );
		++p1->_1;
		BOOST_TEST( p1 != p2 );

		p1.swap( p2 );
		p1 = p2;
	}
	BOOST_TEST( g_valuesCount == 0 );


	///
	/// Copy construction / assignment operator
	///
	{
		boost::pimpl_ptr<CMyValues1> p1( new CMyValues1 );
		BOOST_TEST( g_valuesCount == 1 );

		boost::pimpl_ptr<CMyValues1, boost::pimpls::lazy_creation> p2( p1 );
		BOOST_TEST( g_valuesCount == 2 );

		boost::pimpl_ptr<CMyValues1> p3( p2 );
		BOOST_TEST( g_valuesCount == 3 );

		boost::pimpl_ptr<CMyValues2, boost::pimpls::manual_creation> p4;
		BOOST_TEST( g_valuesCount == 3 );

		p4.set( new CMyValues2(200) );
		BOOST_TEST( g_valuesCount == 4 );

		/// p4 and p3 cannot be swapped since we only have conversions for CMyValues1 -> CMyValues2
		/// not the other way around.
		//p4.swap( p3 );

		p4 = p3;
	}
	BOOST_TEST( g_valuesCount == 0 );


	{
		CTest test;

		int oneParameter = test.m_ValuesWithDefaultConstructor->_1;
		oneParameter = test.m_ValuesWithNonDefaultConstructor->_1;
		oneParameter = test.m_ValuesWithLazyCreator1->_1;
		test.m_ValuesWithLazyCreator2.set( new CMyValues2(1234567) );
		oneParameter = test.m_ValuesWithLazyCreator2->_1;

		test.m_ValuesWithLazyCreator2 = test.m_ValuesWithDefaultConstructor;

		test.m_ValuesWithDefaultConstructor->set( 1 );
		test.m_ValuesWithLazyCreator1->set( 2 );
	}
	BOOST_TEST( g_valuesCount == 0 );


	{
		{
			boost::pimpl_ptr<CMyValues2> p1( new CMyValues2(2) );
			BOOST_TEST( g_valuesCount == 1 );

			boost::pimpl_ptr<CMyValues1, boost::pimpls::lazy_creation> p2;
			BOOST_TEST( g_valuesCount == 1 );

			p1 < p2;
		}

		typedef boost::pimpl_ptr<CMyValues1, boost::pimpls::lazy_creation> Ptr;
		std::vector<Ptr> values;

		{
			values.resize( 10 );
			BOOST_TEST( g_valuesCount == 10 );
		}

		/// use an algorithm that uses less
		std::sort( values.begin(), values.end() );
	}
	BOOST_TEST( g_valuesCount == 0 );


	return 0;
}
