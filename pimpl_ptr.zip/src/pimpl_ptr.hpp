/// Copyright Asger Mangaard 2005 - 2006
/// Distributed under the Boost Software License, Version 1.0. (See
/// accompanying file LICENSE_1_0.txt or copy at
/// http://www.boost.org/LICENSE_1_0.txt)

#ifndef BOOST_PIMPL_PTR_HPP
#define BOOST_PIMPL_PTR_HPP

/// MS compatible compilers support #pragma once
#if defined(_MSC_VER) && (_MSC_VER >= 1020)
    #pragma once
#endif

/// for std::bad_alloc exception
#include <new>

/// for std::swap
#include <algorithm>

/// for BOOST_ASSERT
#include <boost/assert.hpp>

/// for boost::checked_delete
#include <boost/checked_delete.hpp>

/// for boost::throw_exception
#include <boost/throw_exception.hpp>



///
///    \file
///    \brief
///    Implements the Pimpl Idiom
/// Takes advantage of the fact that templates are not validate checked until
/// the first time they're actually used. In our case it's in the .cpp file which is
/// why we get away with implementing the idiom in the .hpp file.
///


namespace boost
{
    namespace pimpls
    {
        namespace detail
        {
            ///
            /// \brief
            ///    Pimpl Policy : Default and base class for all other policies
            /// Can take a default created pimpl, or will create one itself the moment it's created.
            ///
            template <typename T>
            class base
            {
            public:
                void set( T* _pImpl);

            protected:
                base( T* _pDefault = 0);
                ~base();
                T* getNew() const;

            protected:
                /// Will be created by const functions
                mutable T* m_pImpl;
            };

            template <typename T>
            void base<T>::set( T* _pImpl)
            {
                boost::checked_delete( m_pImpl );
                m_pImpl = _pImpl;
            }

            template <typename T>
            inline base<T>::base( T* _pDefault)
            : m_pImpl(_pDefault)
            {
            }

            template <typename T>
            inline base<T>::~base()
            {
                set( 0 );
            }

            template <typename T>
            T* base<T>::getNew() const
            {
                T* p = new T;

                if ( !p )
                {
                    boost::checked_delete( p );
                    boost::throw_exception( std::bad_alloc() );
                }

                return p;
            }
        }   // namespace detail


        ///
        /// \brief
        /// Pimpl Policy : Default construction
        /// This is the classic pImpl idiom. The Type will be default-constructed as soon
        /// the pimpl_ptr is constructed.
        ///
        template <typename T>
        class default_construction : public detail::base<T>
        {
        public:
            T& get() const;

        protected:
            default_construction();
            default_construction( T* _pDefault);
            ~default_construction() {}
        };

        template <typename T>
        inline T& default_construction<T>::get() const
        {
            BOOST_ASSERT( this->m_pImpl );
            return *this->m_pImpl;
        }

        template <typename T>
        inline default_construction<T>::default_construction()
        : detail::base<T>(0)
        {
            this->set( this->getNew() );
        }

        template <typename T>
        inline default_construction<T>::default_construction( T* _pDefault)
        : detail::base<T>( _pDefault )
        {
        }



        ///
        /// \brief
        /// Pimpl Policy : Manual Creation
        /// Will wait to initialize untill someone calls the 'set' function. The pointer will still be deleted
        /// when the pimpl gets out of scope.
        /// Use in conjunction with non-default constructors.
        ///
        template <typename T>
        class manual_creation : public detail::base<T>
        {
        public:
            T& get() const;

        protected:
            manual_creation( T* _pDefault = 0);
            ~manual_creation() {}
        };

        template <typename T>
        inline T& manual_creation<T>::get() const
        {
            BOOST_ASSERT( this->m_pImpl );
            return *this->m_pImpl;
        }

        template <typename T>
        inline manual_creation<T>::manual_creation( T* _pDefault )
        : detail::base<T>( _pDefault )
        {
        }



        ///
        /// \brief
        /// Pimpl Policy : Lazy Creation
        /// The pimpl will first be created the moment it's asked for.
        ///
        template <typename T>
        class lazy_creation : public detail::base<T>
        {
        public:
            T& get() const;

        protected:
            lazy_creation();
            ~lazy_creation() {}
        };

        template <typename T>
        inline T& lazy_creation<T>::get() const
        {
            if ( !this->m_pImpl )
            {
                this->m_pImpl = this->getNew();
            }

            return *this->m_pImpl;
        }

        template <typename T>
        inline lazy_creation<T>::lazy_creation()
        : detail::base<T>()
        {
        }
    }   // namespace pimpls


    ///
    /// \brief
    /// Pointer for the Pimpl Idiom
    /// The actual pimpl_ptr implementation.
    ///
    template
    <
        typename T,
        template <typename> class Policy = pimpls::default_construction
    >
    class pimpl_ptr : public Policy<T>
    {
    public:

        pimpl_ptr() {}
        pimpl_ptr( T* _pDefault);
        pimpl_ptr( const pimpl_ptr<T,Policy>& _copy );
        template <typename T2, template <typename> class Policy2>
        pimpl_ptr( const pimpl_ptr<T2,Policy2>& _copy );
        ~pimpl_ptr() {}

        pimpl_ptr<T,Policy>& operator = (const pimpl_ptr<T,Policy>& _copy);

        template <typename T2, template <typename> class Policy2>
        pimpl_ptr<T,Policy>& operator = (const pimpl_ptr<T2,Policy2>& _copy);

        template <typename T2, template <typename> class Policy2>
        bool operator == (const pimpl_ptr<T2,Policy2>& _rhs) const;
        template <typename T2, template <typename> class Policy2>
        bool operator != (const pimpl_ptr<T2,Policy2>& _rhs) const;

        template <typename T2, template <typename> class Policy2>
        bool operator < (const pimpl_ptr<T2,Policy2>& _rhs) const;

        const T* operator -> () const;
        T* operator -> ();

        template <typename T2, template <typename> class Policy2>
        void swap( pimpl_ptr<T2,Policy2>& _rhs);
    };

    template <typename T, template <class> class Policy>
    inline pimpl_ptr<T,Policy>::pimpl_ptr( T* _pDefault)
    : Policy<T>( _pDefault )
    {
    }

    template <typename T, template <class> class Policy>
    inline pimpl_ptr<T,Policy>::pimpl_ptr( const pimpl_ptr<T,Policy>& _copy)
    {
        *this = _copy;
    }

    template <typename T, template <class> class Policy>
    template <typename T2, template <typename> class Policy2>
    inline pimpl_ptr<T,Policy>::pimpl_ptr( const pimpl_ptr<T2,Policy2>& _copy)
    {
        *this = _copy;
    }

    template <typename T, template <class> class Policy>
    inline pimpl_ptr<T,Policy>& pimpl_ptr<T,Policy>::operator = (const pimpl_ptr<T,Policy>& _copy)
    {
        this->get() = _copy.get();
        return *this;
    }

    template <typename T, template <class> class Policy>
    template <typename T2, template <typename> class Policy2>
    inline pimpl_ptr<T,Policy>& pimpl_ptr<T,Policy>::operator = (const pimpl_ptr<T2,Policy2>& _copy)
    {
        this->get() = _copy.get();
        return *this;
    }

    template <typename T, template <class> class Policy>
    template <typename T2, template <typename> class Policy2>
    inline bool pimpl_ptr<T,Policy>::operator == (const pimpl_ptr<T2,Policy2>& _rhs) const
    {
        return this->get() == _rhs.get();
    }

    template <typename T, template <class> class Policy>
    template <typename T2, template <typename> class Policy2>
    inline bool pimpl_ptr<T,Policy>::operator != (const pimpl_ptr<T2,Policy2>& _rhs) const
    {
        return !(*this == _rhs);
    }

    template <typename T, template <class> class Policy>
    template <typename T2, template <typename> class Policy2>
    inline bool pimpl_ptr<T,Policy>::operator < (const pimpl_ptr<T2,Policy2>& _rhs) const
    {
        /// Not using std::less since we want to allow two different types to be compared.
        return this->get() < _rhs.get();
    }

    template <typename T, template <class> class Policy>
    inline const T* pimpl_ptr<T,Policy>::operator -> () const
    {
        return &this->get();
    }

    template <typename T, template <class> class Policy>
    inline T* pimpl_ptr<T,Policy>::operator -> ()
    {
        return &this->get();
    }

    template <typename T, template <class> class Policy>
    template <typename T2, template <typename> class Policy2>
    inline void pimpl_ptr<T,Policy>::swap( pimpl_ptr<T2,Policy2>& _rhs)
    {
        std::swap( this->get(), _rhs.get() );
    }


    /// boost::swap for pimpl_ptr
    template <typename T, template <class> class Policy, typename T2, template <typename> class Policy2>
    inline void swap( pimpl_ptr<T,Policy>& _a, pimpl_ptr<T2,Policy2>& _b)
    {
        _a.swap( _b );
    }
}    // namespace boost



#endif    // BOOST_PIMPL_PTR_HPP
