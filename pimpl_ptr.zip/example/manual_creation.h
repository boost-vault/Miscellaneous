#ifndef MANUAL_CREATION__H
#define MANUAL_CREATION__H

///
/// boost::pimpl_ptr example : Manual Creation
///
/// In this example we're dealing with pimpled struct with a non-default constructor. For this
/// purpose, we use the manual_creation policy. This lets us specify the pimpl pointer ourselves.
///

#include <boost/pimpl_ptr.hpp>



class CGamePlayer
{
public:

	CGamePlayer();

	void		IncreaseLives();
	void		IncreaseEnemyKilled();


private:
	boost::pimpl_ptr<struct CGamePlayerValues, boost::pimpls::manual_creation> m_Values;
};



#endif
