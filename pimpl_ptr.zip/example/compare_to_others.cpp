#include "compare_to_others.h"

#include <boost/config.hpp>
#include <boost/detail/lightweight_test.hpp>


///
/// CValues is the pimpled
///
///
struct CValues
{
	CValues( int _default = 0)
	: m_AnInteger(_default)
	, m_pSomePointer( new int(_default) )
	{
		++m_valuesCount;
	}
	CValues( const CValues& _copy)
	: m_AnInteger(_copy.m_AnInteger)
	, m_pSomePointer( new int(*_copy.m_pSomePointer) )
	{
		++m_valuesCount;
	}
	~CValues()
	{
		delete m_pSomePointer;
		--m_valuesCount;
	}
	CValues& operator = ( const CValues& _copy)
	{
		m_AnInteger = _copy.m_AnInteger;
		*m_pSomePointer = *_copy.m_pSomePointer;
		return *this;
	}

	bool operator == (const CValues& rhs) const
	{
		return m_AnInteger == rhs.m_AnInteger  &&  *m_pSomePointer == *rhs.m_pSomePointer;
	}

	bool operator != (const CValues& rhs) const
	{
		return !(*this == rhs);
	}

	int			m_AnInteger;
	int*		m_pSomePointer;

	static int	m_valuesCount;
};

int CValues::m_valuesCount = 0;





TTest<raw_ptr>::TTest()
: m_pImpl( new CValues )
{
}

TTest<raw_ptr>::TTest( const TTest<raw_ptr>& _copy)
: m_pImpl( new CValues(*_copy.m_pImpl) )
{
}

TTest<raw_ptr>::~TTest()
{
	delete m_pImpl;
}

TTest<raw_ptr>& TTest<raw_ptr>::operator = (const TTest<raw_ptr>& _assigner)
{
	*m_pImpl = *_assigner.m_pImpl;

	return *this;
}

bool TTest<raw_ptr>::operator == (const TTest<raw_ptr>& _comparer) const
{
	return *m_pImpl == *_comparer.m_pImpl;
}

bool TTest<raw_ptr>::operator != (const TTest<raw_ptr>& _comparer) const
{
	return *m_pImpl != *_comparer.m_pImpl;
}




TTest<std::auto_ptr>::TTest()
: m_pImpl( new CValues )
{
}

bool TTest<std::auto_ptr>::operator == (const TTest<std::auto_ptr>& _comparer) const
{
	return *m_pImpl == *_comparer.m_pImpl;
}

bool TTest<std::auto_ptr>::operator != (const TTest<std::auto_ptr>& _comparer) const
{
	return *m_pImpl != *_comparer.m_pImpl;
}




TTest<boost::shared_ptr>::TTest()
: m_pImpl( new CValues )
{
}

TTest<boost::shared_ptr>::TTest( const TTest<boost::shared_ptr>& _copy)
: m_pImpl( new CValues )
{
	*this = _copy;
}

TTest<boost::shared_ptr>& TTest<boost::shared_ptr>::operator = (const TTest<boost::shared_ptr>& _assigner)
{
	*m_pImpl = *_assigner.m_pImpl;
	return *this;
}

bool TTest<boost::shared_ptr>::operator == (const TTest<boost::shared_ptr>& _comparer) const
{
	return *m_pImpl == *_comparer.m_pImpl;
}

bool TTest<boost::shared_ptr>::operator != (const TTest<boost::shared_ptr>& _comparer) const
{
	return *m_pImpl != *_comparer.m_pImpl;
}



TTest<boost::scoped_ptr>::TTest()
: m_pImpl( new CValues )
{
}

TTest<boost::scoped_ptr>::TTest( const TTest<boost::scoped_ptr>& _copy)
: m_pImpl( new CValues )
{
	*this = _copy;
}

TTest<boost::scoped_ptr>& TTest<boost::scoped_ptr>::operator = (const TTest<boost::scoped_ptr>& _assigner)
{
	*m_pImpl = *_assigner.m_pImpl;
	return *this;
}


bool TTest<boost::scoped_ptr>::operator == (const TTest<boost::scoped_ptr>& _comparer) const
{
	return *m_pImpl == *_comparer.m_pImpl;
}

bool TTest<boost::scoped_ptr>::operator != (const TTest<boost::scoped_ptr>& _comparer) const
{
	return *m_pImpl != *_comparer.m_pImpl;
}




bool TTest<pimpl_ptr_default>::operator == (const TTest<pimpl_ptr_default>& _rhs) const
{
	return m_pImpl == _rhs.m_pImpl;
}

bool TTest<pimpl_ptr_default>::operator != (const TTest<pimpl_ptr_default>& _rhs) const
{
	return m_pImpl != _rhs.m_pImpl;
}



/**
	required/pointer type		raw		auto_ptr	scoped_ptr	shared_ptr	pimpl_ptr

	default constructor			+		n/a			+			+			-
	copy constructor			+		n/a			+			+			-
	assignment op.				+		n/a			+			+			-
	== compare					+		n/a			+			+			+
	!= compare					+		n/a			+			+			+
	size						4		-			4			8			4

*/


template <template <typename> class T>
void DoTest()
{
	{
		/// Default construction
		TTest<T> ptr1;
		TTest<T> ptr2;

		BOOST_TEST( ptr1 == ptr2 );
		BOOST_TEST( CValues::m_valuesCount == 2 );

		ptr1.m_pImpl->m_AnInteger = 1;
		ptr2.m_pImpl->m_AnInteger = 2;

		BOOST_TEST( ptr1 != ptr2 );


		/// Copy construction
		TTest<T> ptr3( ptr1 );

		BOOST_TEST( ptr1 == ptr3 );
		BOOST_TEST( ptr3.m_pImpl->m_AnInteger == 1 );


		/// Value keeping through copy construction
		ptr1.m_pImpl->m_AnInteger = 1;
		ptr2.m_pImpl->m_AnInteger = 2;
		ptr3.m_pImpl->m_AnInteger = 3;

		BOOST_TEST( ptr1.m_pImpl->m_AnInteger == 1 );
		BOOST_TEST( ptr2.m_pImpl->m_AnInteger == 2 );
		BOOST_TEST( ptr3.m_pImpl->m_AnInteger == 3 );


		/// Assignment
		ptr1 = ptr2;
		BOOST_TEST( ptr1.m_pImpl->m_AnInteger == 2 );

		ptr1 = ptr3;
		BOOST_TEST( ptr1.m_pImpl->m_AnInteger == 3 );

		BOOST_TEST( ptr1 == ptr3 );


		/// Value keeping thorugh assignment
		ptr1.m_pImpl->m_AnInteger = 1;
		BOOST_TEST( ptr1.m_pImpl->m_AnInteger == 1 );
		BOOST_TEST( ptr3.m_pImpl->m_AnInteger == 3 );

		BOOST_TEST( ptr1 != ptr2 );


		/// Memory management
		BOOST_TEST( CValues::m_valuesCount == 3 );

		//ptr1.m_pImpl = new CValues( 1234 );

		BOOST_TEST( CValues::m_valuesCount == 3 );
	}
}


int main(int argc, char* argv[])
{
	{
		CValues ptr1;
		CValues ptr2;

		BOOST_TEST( ptr1 == ptr2 );

		ptr1.m_AnInteger = 1;
		ptr2.m_AnInteger = 2;
		BOOST_TEST( ptr1 != ptr2 );

		ptr1 = ptr2;

		BOOST_TEST( ptr1 == ptr2 );
	}

	DoTest<raw_ptr>();
	//DoTest<std::auto_ptr>();
	DoTest<boost::shared_ptr>();
	DoTest<boost::scoped_ptr>();
	DoTest<pimpl_ptr_default>();

	return 0;
}
