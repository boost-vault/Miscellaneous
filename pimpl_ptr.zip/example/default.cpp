#include "default.h"


struct CMyInteger
{
	CMyInteger()
	: m_Value(0)
	{
	}

	void operator ++ ()
	{
		++m_Value;
	}

	int			m_Value;
};

struct CGamePlayerValues
{
	CGamePlayerValues()
	: m_EnemiesKilled(0)
	{
	}

	CMyInteger	m_Lives;
	int			m_EnemiesKilled;
};



void CGamePlayer::IncreaseLives()
{
	++m_Values->m_Lives;
}


void CGamePlayer::IncreaseEnemyKilled()
{
	++m_Values->m_EnemiesKilled;
}


int main(int argc, char* argv[])
{
	CGamePlayer player;

	player.IncreaseEnemyKilled();
	player.IncreaseLives();

	return 0;
}
