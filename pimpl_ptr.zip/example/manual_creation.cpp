#include "manual_creation.h"


struct CMyInteger
{
	CMyInteger()
	: m_Value(0)
	{
	}

	void operator ++ ()
	{
		++m_Value;
	}

	int			m_Value;
};

struct CGamePlayerValues
{
	CGamePlayerValues( int _enemiesKilled)
	: m_EnemiesKilled(_enemiesKilled)
	{
	}

	CMyInteger	m_Lives;
	int			m_EnemiesKilled;
};



///
/// The constructor allocates the pimpl struct and passes its ownership to the pimpl_ptr
///
CGamePlayer::CGamePlayer()
: m_Values( new CGamePlayerValues(4) )
{
	/// We could also set a new pointer directly. Since the ownership is handled by pimpl_ptr we don't
	/// worry about memory leaking.
	m_Values.set( new CGamePlayerValues(6) );
}


void CGamePlayer::IncreaseLives()
{
	++m_Values->m_Lives;
}


void CGamePlayer::IncreaseEnemyKilled()
{
	++m_Values->m_EnemiesKilled;
}


int main(int argc, char* argv[])
{
	CGamePlayer player;

	player.IncreaseEnemyKilled();
	player.IncreaseLives();

	return 0;
}
