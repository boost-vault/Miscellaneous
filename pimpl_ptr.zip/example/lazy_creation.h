#ifndef LAZY_CREATION__H
#define LAZY_CREATION__H

///
/// boost::pimpl_ptr example : Lazy Creation
///
/// Like the default policy, the lazy creation policy will not require one to manually create the pimpled
/// struct. However, unlike the default behaviour where the struct will be created asap, the lazy policy
/// will wait with creating the struct until the get() function or the -> operator is called. This is
/// useful in situations where one is unsure if the pimpled struct will actually be used.
/// The downsides to this is; Only default pimpled constructors are supported and an extra 'validate' check
/// is performed each time the pImpl pointer is tried to be used.
///

#include <boost/pimpl_ptr.hpp>



class CGamePlayer
{
public:

	void		IncreaseLives();
	void		IncreaseEnemyKilled();


private:
	boost::pimpl_ptr<struct CGamePlayerValues, boost::pimpls::lazy_creation> m_Values;
};



#endif
