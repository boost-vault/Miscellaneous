#include "lazy_creation.h"


struct CMyInteger
{
	CMyInteger()
	: m_Value(0)
	{
	}

	void operator ++ ()
	{
		++m_Value;
	}

	int			m_Value;
};

struct CGamePlayerValues
{
	CGamePlayerValues()
	: m_EnemiesKilled(0)
	{
	}

	CMyInteger	m_Lives;
	int			m_EnemiesKilled;
};



void CGamePlayer::IncreaseLives()
{
	++m_Values->m_Lives;
}


void CGamePlayer::IncreaseEnemyKilled()
{
	++m_Values->m_EnemiesKilled;
}


int main(int argc, char* argv[])
{
	CGamePlayer player;

	/// Notice that the CGamePlayer::m_Values::m_pImpl isn't created yet.

	player.IncreaseEnemyKilled();

	/// The CGamePlayer::m_Values::m_pImpl is now created (and modified) since the call above forced
	/// the lazy policy to create a 'CGamePlayerValues'.

	player.IncreaseLives();

	return 0;
}
