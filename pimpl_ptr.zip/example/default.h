#ifndef DEFAULT__H
#define DEFAULT__H

///
/// boost::pimpl_ptr example : Default
///

#include <boost/pimpl_ptr.hpp>



class CGamePlayer
{
public:

	void		IncreaseLives();
	void		IncreaseEnemyKilled();


private:
	boost::pimpl_ptr<struct CGamePlayerValues> m_Values;
};



#endif
