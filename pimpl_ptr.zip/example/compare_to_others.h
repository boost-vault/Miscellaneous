#ifndef COMPARE_TO_OTHERS__H
#define COMPARE_TO_OTHERS__H

///
/// boost::pimpl_ptr example : Compare to other pimpl approaches.
///
/// Included are comparisons for:
/// raw pointer
/// std::auto_ptr
/// boost::shared_ptr
/// boost::scoped_ptr
///

#include <memory>
#include <boost/shared_ptr.hpp>
#include <boost/scoped_ptr.hpp>
#include <boost/pimpl_ptr.hpp>


/// Test for specialization
template <template <typename> class T>
class TTest {};




///
/// Typedef replacement
///
template <typename T>
struct raw_ptr {};

///
/// Raw Pointer
///
template <>
class TTest<raw_ptr>
{
public:
	TTest<raw_ptr>();
	TTest<raw_ptr>( const TTest<raw_ptr>& );
	~TTest<raw_ptr>();
	TTest<raw_ptr>& operator = (const TTest<raw_ptr>& );
	bool operator == (const TTest<raw_ptr>& ) const;
	bool operator != (const TTest<raw_ptr>& ) const;

public:
	struct CValues*	m_pImpl;
};




///
/// Std auto_ptr
///
template <>
class TTest<std::auto_ptr>
{
public:
	TTest<std::auto_ptr>();

	bool operator == (const TTest<std::auto_ptr>& ) const;
	bool operator != (const TTest<std::auto_ptr>& ) const;

public:
	std::auto_ptr<struct CValues> m_pImpl;
};




///
/// boost shared_ptr
///
template <>
class TTest<boost::shared_ptr>
{
public:
	TTest<boost::shared_ptr>();
	TTest<boost::shared_ptr>( const TTest<boost::shared_ptr>& );
	TTest<boost::shared_ptr>& operator = (const TTest<boost::shared_ptr>& );

	bool operator == (const TTest<boost::shared_ptr>& ) const;
	bool operator != (const TTest<boost::shared_ptr>& ) const;


public:
	boost::shared_ptr<struct CValues> m_pImpl;
};




///
/// boost scoped_ptr
///
template <>
class TTest<boost::scoped_ptr>
{
public:

	TTest<boost::scoped_ptr>();
	TTest<boost::scoped_ptr>( const TTest<boost::scoped_ptr>& );
	TTest<boost::scoped_ptr>& operator = (const TTest<boost::scoped_ptr>& );
	bool operator == (const TTest<boost::scoped_ptr>& ) const;
	bool operator != (const TTest<boost::scoped_ptr>& ) const;

public:
	boost::scoped_ptr<struct CValues> m_pImpl;
};




///
/// Typedef replacement
///
template <typename T>
struct pimpl_ptr_default : public boost::pimpl_ptr<T> {};


///
/// boost pimpl_ptr default
///
template <>
class TTest<pimpl_ptr_default>
{
public:

	bool operator == (const TTest<pimpl_ptr_default>& ) const;
	bool operator != (const TTest<pimpl_ptr_default>& ) const;

public:
	boost::pimpl_ptr<struct CValues> m_pImpl;
};



#endif
