
#include "matrix.h"
#include <iostream>
#include <cmath>



template<typename T,unsigned int M, unsigned int N, class Char, class Traits>
inline std::basic_ostream<Char, Traits>& operator<<(
	std::basic_ostream<Char, Traits>& os, matrix<T,M,N> const& mx
){
	os << "[(" << mx(0,0);
	for ( unsigned int n(1); n<N; ++n )
		os << ',' << mx(0,n);
	for ( unsigned int m(1); m<M; ++m ) {
		os << ")(" << mx(m,0);
		for ( unsigned int n(1); n<N; ++n )
			os << ',' << mx(m,n);
	}
	return os << ")]";
}


template<typename T, unsigned int M, unsigned int N>
bool gauss_jordan(matrix<T,M,N> &m, T eps)
{
	for ( unsigned int y(0); y < M; ++y ) {
		int maxrow = y;
		// Find max pivot
		for ( unsigned int y2(y+1); y2 < M; ++y2 )
			if ( std::abs(m(y2,y)) > std::abs(m(maxrow,y)) )
				maxrow = y2;
		// swap rows
		for ( unsigned int x(0); x < N; ++x )
			std::swap(m(y,x), m(maxrow,x));
		//singular ?
		if ( std::abs(m(y,y)) < eps )
			return false;
		// Eliminate column y
		for ( unsigned int y2(y+1); y2 < M; ++y2 ) {
			T c = m(y2,y) / m(y,y);
			for ( unsigned int x(y+1); x < N; ++x )
				m(y2,x) -= m(y,x) * c;
			m(y2,y) = T();
		}
	}
	// Backsubstitute
	for ( int y(M-1); y >= 0; --y ) {
		T c = m(y,y);
		for ( int y2(0); y2 < y; ++y2 ) {
			for ( int x(N-1); x > y ; --x )
				m(y2,x) -= m(y,x) * m(y2,y) / c;
			m(y2,y) = T();

		}
		// normalize row y
		for ( unsigned int x(y); x < N ; ++x )
			m(y,x) /= c;
	}
	return true;
}



template<typename T, unsigned int M, unsigned int N>
void gauss(matrix<T,M,N> &m, T eps)
{
	for ( unsigned int i=0, j=0; i<M && j<N; ++j ) {
		// Find max pivot
		unsigned int maxi = i;
		for ( unsigned int k = i+1; k<M; ++k )
			if ( std::abs(m(k,j)) > std::abs(m(maxi,j)) )
				maxi = k;
		if ( std::abs(m(maxi,j)) > eps ) {
			// swap rows
			for ( unsigned int k=0; k < N; ++k )
				std::swap(m(i,k), m(maxi,k));
			// normalize row i
			for ( unsigned int k = N; k-- > j; )
				m(i,k) /= m(i,j);
			// eliminate column j
			for ( unsigned int u = i+1; u < M; ++u ) {
				for ( unsigned int k(N); --k > j; )
					m(u,k) -= m(i,k)*m(u,j);
				m(u,j) = T();
			}
			++i;
		}
	}
	for ( int i = M-1; i >= 0; --i ) {
		for ( int k = 0; k < i; ++k ) {
			for ( int u = N-1; u > i ; --u )
				m(k,u) -= m(i,u) * m(k,i);
			m(k,i) = T();

		}
	}
}


int m1[][6] = { {2,-1,0,1,0,0}, {-1,2,-1,0,1,0}, {0,-1,2,0,0,1} };
int m2[][4] = { {2,1,-1,8}, {-3,-1,2,-11}, {-2,1,2,-3} };


int main(int argc, char *argv[])
{
	matrix<double,3,6> M1(mtrx(m1));
	matrix<double,3,6> M_1(mtrx(m1));
	matrix<double,3,4> M2(mtrx(m2));
	matrix<double,3,4> M_2(mtrx(m2));
	std::cout << M1 << std::endl;
	gauss_jordan(M1,1.0/10000000000.0);
	std::cout << M1 << std::endl;
	gauss(M_1,1.0/10000000000.0);
	std::cout << M_1 << std::endl;
	std::cout << std::endl;
	std::cout << M2 << std::endl;
	gauss_jordan(M2,1.0/10000000000.0);
	std::cout << M2 << std::endl;
	gauss(M_2,1.0/10000000000.0);
	std::cout << M_2 << std::endl;
	return 0;
}

