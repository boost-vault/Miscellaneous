
#include "matrix.h"
#include <boost/numeric/ublas/matrix.hpp>
#include <boost/numeric/ublas/io.hpp>
#include <iostream>
#include <complex>
#include <limits>


#define BOOST_AUTO_TEST_MAIN
#include <boost/test/auto_unit_test.hpp>
#include <boost/test/floating_point_comparison.hpp>

#ifndef EUCLID_TEST_LEVEL
#define EUCLID_TEST_LEVEL 3
#endif



template<typename T> struct type {};

template<> struct type<int> {
	static const char* name() { return "int"; }
	static int init() { return std::numeric_limits<int>::max()/2-rand(); }
	static void check_equal(int t1, int t2) { BOOST_CHECK_EQUAL(t1, t2); }
};

template<> struct type<unsigned int> {
	static const char* name() { return "unsigned int"; }
	static unsigned int init() { return rand(); }
	static void check_equal(unsigned int t1, unsigned int t2) {
		BOOST_CHECK_EQUAL(t1, t2); }
};

template<> struct type<float> {
	static const char* name() { return "float"; }
	static float init() {
		return float(rand())/std::numeric_limits<int>::max(); }
	static void check_equal(float t1, float t2) {
		BOOST_CHECK_CLOSE(t1, t2, 0.0001); }
};

template<> struct type<double> {
	static const char* name() { return "double"; }
	static double init() {
		return double(rand())/std::numeric_limits<int>::max(); }
	static void check_equal(double t1, double t2) {
		BOOST_CHECK_CLOSE(t1, t2, 0.00000001); }
};

template<> struct type< std::complex<double> > {
	static const char* name() { return "complex<double>"; }
	static std::complex<double> init() {
		double re = type<double>::init();
		double im = type<double>::init();
		return std::complex<double>(re, im);
	}
	static void check_equal(std::complex<double>t1,std::complex<double>t2){
		type<double>::check_equal(t1.real(), t2.real());
		type<double>::check_equal(t1.imag(), t2.imag());
	}
};



template<typename T,unsigned int M, unsigned int N, class Char, class Traits>
inline std::basic_ostream<Char, Traits>& operator<<(
	std::basic_ostream<Char, Traits>& os, matrix<T,M,N> const& mx
){
	os << "[(" << mx(0,0);
	for ( unsigned int n(1); n<N; ++n )
		os << ',' << mx(0,n);
	for ( unsigned int m(1); m<M; ++m ) {
		os << ")(" << mx(m,0);
		for ( unsigned int n(1); n<N; ++n )
			os << ',' << mx(m,n);
	}
	return os << ")]";
}


template<typename T, unsigned int M, unsigned int N> void
init(matrix<T,M,N>& m, boost::numeric::ublas::matrix<T>& u)
{
	BOOST_CHECK_EQUAL( M, u.size1() );
	BOOST_CHECK_EQUAL( N, u.size2() );

	for (unsigned i = 0; i < M; ++i)
		for (unsigned j = 0; j < N; ++j)
				u(i,j) = m(i,j) = type<T>::init();
}


template<typename T, unsigned int M, unsigned int N> void
check_equal(matrix<T,M,N> const& m, boost::numeric::ublas::matrix<T> const& u)
{
	BOOST_CHECK_EQUAL( M, u.size1() );
	BOOST_CHECK_EQUAL( N, u.size2() );

	for (unsigned i = 0; i < M; ++i)
		for (unsigned j = 0; j < N; ++j)
			type<T>::check_equal( m(i,j), u(i,j) );
}



template<typename T, unsigned int M, unsigned int N, unsigned int Q>
struct matrix_multiplication_test
{
	matrix_multiplication_test(
		matrix<T,M,N> const& m0,
		boost::numeric::ublas::matrix<T> const& u0
	) {
		matrix_multiplication_test<T,M,N,Q-1>(m0, u0);

		boost::numeric::ublas::matrix<T> u1(N,Q);
		matrix<T,N,Q> m1;
		init<T,N,Q>(m1, u1);

		BOOST_MESSAGE( (transpose(m0)|m1) << '\n' );
		check_equal<T,M,Q>(m0*m1, prod(u0,u1));
	}
};


template<typename T, unsigned int M, unsigned int N>
struct matrix_multiplication_test<T,M,N,0>
{
	matrix_multiplication_test(
		matrix<T,M,N> const&,
		boost::numeric::ublas::matrix<T> const&
	) {
		BOOST_MESSAGE(
			"test matrix with "
			"[T = " << type<T>::name() << "], "
			"[M = " << M << "] and "
			"[N = " << N << "]"
		);
	}
};



template<typename T, unsigned int M, unsigned int N> struct matrix_test
{
	matrix_test() {
		matrix_test<T,M,N-1>();

		T t1=type<T>::init();
		T t2=type<T>::init();
		boost::numeric::ublas::matrix<T> u1(M,N), u2(M,N);

		matrix<T,M,N> m0(0);
		matrix<T,M,N> m1(m0);

		BOOST_CHECK(m0 == m1);

		init<T,M,N>(m0, u1);
		init<T,M,N>(m1, u2);

		matrix<T,M,N> m2(m1);
		BOOST_CHECK(m1 == m2);
		BOOST_CHECK(! (m1 != m2) );

		swap(m0,m1);

		check_equal<T,M,N>(m1, u1);
		check_equal<T,M,N>(m2, u2);

		m0 = m1;
		BOOST_CHECK(m0 == m1);


		check_equal<T,M,N>(-m1, -u1);
		check_equal<T,M,N>(m1+m2, u1+u2);
		check_equal<T,M,N>(m1-m2, u1-u2);
		check_equal<T,M,N>(m1*t1, u1*t1);
		check_equal<T,M,N>(t2*m2, t2*u2);
		check_equal<T,M,N>(m1/t1, u1/t1);

		matrix_multiplication_test<T,M,N,M>(m1, u1);

		check_equal<T,N,M>(transpose(m1), trans(u1));
		check_equal<T,N,M>(transpose(m2), trans(u2));
	}
};


template<typename T, unsigned int M> struct matrix_test<T,M,0>
{
	matrix_test() {
		BOOST_MESSAGE(
			"test matrix with "
			"[T = " << type<T>::name() << "] and "
			"[M = " << M << "]"
		);
	}
};



template<int L, typename T, unsigned int M> struct matrices_test
{
	matrices_test() {
		matrices_test<L,T,M-1>();
		matrix_test<T,M,M>();
	}
};


template<int L, typename T> struct matrices_test<L,T,0>
{
	matrices_test() {
		BOOST_MESSAGE(
			"test matrices with "
			"[T = " << type<T>::name() << "]"
		);
	}
};


#if EUCLID_TEST_LEVEL < 3
template<typename T, unsigned int D> struct matrices_test<3,T,D> {};
#if EUCLID_TEST_LEVEL < 2
template<typename T, unsigned int D> struct matrices_test<2,T,D> {};
#endif
#endif


BOOST_AUTO_UNIT_TEST( matrices_tests )
{
	matrices_test<1,int,4>();
	matrices_test<2,unsigned int,4>();
	matrices_test<3,float,6>();
	matrices_test<2,double,4>();
	matrices_test<3,std::complex<double>,6>();
}

