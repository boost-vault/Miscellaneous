
#ifndef MATRIX_HEADERFILE
#define MATRIX_HEADERFILE

#include <algorithm>
#include <functional>


template<typename T, unsigned int M, unsigned int N> class matrix
{
	protected:
		T m[M][N];
	public:
		typedef T value_type;
		enum { rows = M, columns = N };
		T* data() { return &**m; }
		T const* data() const { return &**m; }

		matrix() {}
		matrix(T const& c) {
			std::fill(data(), data()+M*N, c); }
		matrix(matrix const& m) {
			std::copy(m.data(), m.data()+M*N, data()); }

		template<typename U> matrix(matrix<U,M,N> const& m) {
			std::copy(m.data(), m.data()+M*N, data()); }

		template<typename U> matrix& operator=(matrix<U,M,N> const& m){
			std::copy(m.data(),m.data()+M*N,data()); return *this;}

		template<class UnaryFunction>
		matrix& map(UnaryFunction);
		template<class BinaryFunction>
		matrix& join(matrix const&, BinaryFunction);

		matrix& operator+=(matrix const& m) {
			return join(m, std::plus<T>() ); }
		matrix& operator-=(matrix const& m) {
			return join(m, std::minus<T>() ); }
		matrix& operator*=(T const& c) {
			return map(std::bind2nd(std::multiplies<T>(), c)); }
		matrix& operator/=(T const& c) {
			return map(std::bind2nd(std::divides<T>(), c)); }
		matrix& operator%=(T const& c) {
			return map(std::bind2nd(std::modulus<T>(), c)); }

		T& operator()(unsigned int i, unsigned int j) {
			return m[i][j]; }
		T const& operator()(unsigned int i, unsigned int j) const {
			return m[i][j]; }

};


template<typename T, unsigned int M, unsigned int N>
	template<class UnaryFunction> matrix<T,M,N>& matrix<T,M,N>::map(
		UnaryFunction op) { std::transform(data(),
			data()+M*N, data(), op); return *this; }

template<typename T, unsigned int M, unsigned int N>
	template<class BinaryFunction> matrix<T,M,N>& matrix<T,M,N>::join(
		matrix const& m, BinaryFunction op) { std::transform(data(),
			data()+M*N, m.data(), data(), op); return *this; }


// global swap
template<typename T, unsigned int M, unsigned int N> inline
	void swap(matrix<T,M,N>& m1, matrix<T,M,N>& m2) {
		std::swap_ranges(m1.data(), m1.data()+M*N, m2.data()); }

// global converter; allows type deduction
template<typename T, unsigned int M, unsigned int N> inline
	matrix<T,M,N> mtrx(T (&a)[M][N]) { matrix<T,M,N> tmp;
		std::copy(&**a, &**a+M*N, tmp.data()); return tmp; }


template<typename T, unsigned int M, unsigned int N, class UnaryFunction>
	inline UnaryFunction foreach(matrix<T,M,N>& m, UnaryFunction op) {
		return std::for_each(m.data(), m.data()+M*N, op); }

template<typename T, unsigned int M, unsigned int N, class UnaryFunction>
	inline UnaryFunction foreach(matrix<T,M,N> const& m, UnaryFunction op){
		return std::for_each(m.data(), m.data()+M*N, op); }

template<typename T, unsigned int M, unsigned int N, class UnaryPredicate>
	inline bool forall(matrix<T,M,N> const& m, UnaryPredicate op) {
		const T *i=m.data(), *end=m.data()+M*N;
		for ( ; i != end; ++i ) if ( ! op(*i) ) return false;
		return true; }

template<typename T, unsigned int M, unsigned int N, class UnaryPredicate>
	inline bool forall(matrix<T,M,N> const& m1, matrix<T,M,N> const& m2,
		UnaryPredicate op ) {
		const T *i=m1.data(), *end=m1.data()+M*N, *j=m2.data();
		for ( ; i != end; ++i, ++j ) if ( ! op(*i, *j) ) return false;
		return true; }

/*
template<typename T, unsigned int M, unsigned int N> inline
	bool operator==(matrix<T,M,N> const& m1, matrix<T,M,N> const& m2) {
		return forall(m1, m2, std::equal_to<T>()); }

template<typename T, unsigned int M, unsigned int N> inline
	bool operator!=(matrix<T,M,N> const& m1, matrix<T,M,N> const& m2) {
		return ! forall(m1, m2, std::equal_to<T>()); }
*/

// unary and binary operators
template<typename T, unsigned int M, unsigned int N> inline
	bool operator==(matrix<T,M,N> const& m1, matrix<T,M,N> const& m2) {
		return std::equal(m1.data(), m1.data()+M*N, m2.data()); }

template<typename T, unsigned int M, unsigned int N> inline
	bool operator!=(matrix<T,M,N> const& m1, matrix<T,M,N> const& m2) {
		return ! std::equal(m1.data(), m1.data()+M*N, m2.data()); }


template<typename T, unsigned int M, unsigned int N> matrix<T,M,N> inline
	operator-(matrix<T,M,N> const& m) {
		matrix<T,M,N> tmp = T(); return tmp-=m; }

template<typename T, unsigned int M, unsigned int N> matrix<T,M,N> inline
	operator+(matrix<T,M,N> tmp, matrix<T,M,N> const& m) { return tmp+=m; }

template<typename T, unsigned int M, unsigned int N> matrix<T,M,N> inline
	operator-(matrix<T,M,N> tmp, matrix<T,M,N> const& m) { return tmp-=m; }

template<typename T, unsigned int M, unsigned int N> matrix<T,M,N> inline
	operator*(matrix<T,M,N> tmp, T const& c) { return tmp*=c; }

template<typename T, unsigned int M, unsigned int N> matrix<T,M,N> inline
	operator*(T const& c, matrix<T,M,N> tmp) { return tmp*=c; }

template<typename T, unsigned int M, unsigned int N> matrix<T,M,N> inline
	operator/(matrix<T,M,N> tmp, T const& c) { return tmp/=c; }

template<typename T, unsigned int M, unsigned int N> matrix<T,M,N> inline
	operator%(matrix<T,M,N> tmp, T const& c) { return tmp%=c; }


template<typename T, unsigned int M, unsigned int N, unsigned int Q> inline
matrix<T,M,Q> operator*(matrix<T,M,N> const& m1, matrix<T,N,Q> const& m2)
{
	matrix<T,M,Q> tmp;
	for ( unsigned int m=0; m<M; ++m )
		for ( unsigned int q=0; q<Q; ++q ) {
			T c = T();
			for ( unsigned int n=0; n<N; ++n )
				c+=m1(m,n)*m2(n,q);
			tmp(m,q) = c;
		}
	return tmp;
}


template<typename T, unsigned int M, unsigned int N, unsigned int Q> inline
matrix<T,M,N+Q> operator|(matrix<T,M,N> const& m1, matrix<T,M,Q> const& m2)
{
	matrix<T,M,N+Q> tmp;
	for ( unsigned int m=0; m<M; ++m ) {
		for ( unsigned int n=0; n<N; ++n )
			tmp(m,n) = m1(m,n);
		for ( unsigned int q=0; q<Q; ++q )
			tmp(m,q+N) = m1(m,q);
	}
	return tmp;
}


template<typename T, unsigned int M, unsigned int N> inline
matrix<T,N,M> transpose(matrix<T,M,N> const& m0)
{
	matrix<T,N,M> tmp;
	for ( unsigned int m(0); m<M; ++m )
		for ( unsigned int n(0); n<N; ++n )
			tmp(n,m) = m0(m,n);
	return tmp;
}


#endif	// MATRIX_HEADERFILE

