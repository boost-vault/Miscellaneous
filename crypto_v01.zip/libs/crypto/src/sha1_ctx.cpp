
//          Copyright Kevin Sopp 2007.
// Distributed under the Boost Software License, Version 1.0.
//    (See accompanying file LICENSE_1_0.txt or copy at
//          http://www.boost.org/LICENSE_1_0.txt)

#include <cstring>
#include <boost/crypto/detail/sha1_ctx.hpp>


namespace boost {
namespace crypto {
namespace detail {

const sha1_ctx::word_type sha1_ctx::init_values[5] =
{
  0x67452301, 0xefcdab89, 0x98badcfe, 0x10325476, 0xc3d2e1f0
};

sha1_ctx::sha1_ctx()
:
  bit_count(0)
{
  std::memcpy(H, init_values, sizeof(H));
}

sha1_ctx::sha1_ctx(const sha1_ctx& copy)
:
  bit_count(copy.bit_count)
{
  std::memcpy(H, copy.H, sizeof(H));
}

sha1_ctx& sha1_ctx::operator = (const sha1_ctx& rhs)
{
  bit_count = rhs.bit_count;
  std::memcpy(H, rhs.H, sizeof(H));
  return *this;
}

void sha1_ctx::reset()
{
  std::memcpy(H, init_values, sizeof(H));
  bit_count = 0;
}

void sha1_ctx::clear()
{
  reset();
}

// processes one chunk of 64 bytes 
void sha1_ctx::process_block(const void* msg)
{
  word_type W[80];
  native_to_big_endian<word_type>(W, msg, 16 * sizeof(word_type));
  
  for (int t = 16; t < 80; ++t)
    W[t] = rotate_left(W[t-3] ^ W[t-8] ^ W[t-14] ^ W[t-16], 1);

  word_type a = H0;
  word_type b = H1;
  word_type c = H2;
  word_type d = H3;
  word_type e = H4;

  static const word_type K[4] = { 0x5a827999,
                                  0x6ed9eba1,
                                  0x8f1bbcdc,
                                  0xca62c1d6 };

  for (int t = 0; t < 20; ++t)
  {
    word_type T = rotate_left(a, 5) + Ch(b,c,d) + e + K[0] + W[t];
    e = d;
    d = c;
    c = rotate_left(b, 30);
    b = a;
    a = T;
  }
  for (int t = 20; t < 40; ++t)
  {
    word_type T = rotate_left(a, 5) + Parity(b,c,d) + e + K[1] + W[t];
    e = d;
    d = c;
    c = rotate_left(b, 30);
    b = a;
    a = T;
  }
  for (int t = 40; t < 60; ++t)
  {
    word_type T = rotate_left(a, 5) + Maj(b,c,d) + e + K[2] + W[t];
    e = d;
    d = c;
    c = rotate_left(b, 30);
    b = a;
    a = T;
  }
  for (int t = 60; t < 80; ++t)
  {
    word_type T = rotate_left(a, 5) + Parity(b,c,d) + e + K[3] + W[t];
    e = d;
    d = c;
    c = rotate_left(b, 30);
    b = a;
    a = T;
  }

  H0 += a;
  H1 += b;
  H2 += c;
  H3 += d;
  H4 += e;
}

void sha1_ctx::store_msg_digest(void* digest) const
{
  native_to_big_endian<word_type>(digest, H, digest_length);
}

void sha1_ctx::store_bit_count(void* dst) const
{
  bit_count.store_as_big_endian(dst);
}


} // namespace detail
} // namespace crypto
} // namespace boost

