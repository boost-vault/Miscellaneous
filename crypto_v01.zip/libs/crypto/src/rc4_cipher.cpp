
//          Copyright Kevin Sopp 2007.
// Distributed under the Boost Software License, Version 1.0.
//    (See accompanying file LICENSE_1_0.txt or copy at
//          http://www.boost.org/LICENSE_1_0.txt)

#include <boost/crypto/rc4_cipher.hpp>

namespace boost {
namespace crypto {

rc4_cipher::~rc4_cipher()
{
  std::memset(state_, 0, sizeof(state_));
  x_ = 0;
  y_ = 0;
}

void rc4_cipher::set_key(const void* vkey, size_type key_len)
{
  x_ = 0;
  y_ = 0;
  const unsigned char* key = static_cast<const unsigned char*>(vkey);
  unsigned char index1 = 0;
  unsigned char index2 = 0;

  for (int i = 0; i < 256; ++i)
    state_[i] = i;

  for (int i = 0; i < 256; ++i)
  {
    index2 = (key[index1] + state_[i] + index2) % 256;
    std::swap(state_[i], state_[index2]);
    index1 = (index1 + 1) % key_len;
  }
}

void rc4_cipher::encrypt(const void* vin, void* vout, size_type len)
{
  const unsigned char* in = static_cast<const unsigned char*>(vin);
  unsigned char* out = static_cast<unsigned char*>(vout);
  unsigned char xor_index;
  unsigned char x = x_;
  unsigned char y = y_;

  for (size_type i = 0; i < len; ++i)
  {
    x = (x + 1) % 256;
    y = (state_[x] + y) % 256;
    std::swap(state_[x], state_[y]);

    xor_index = state_[x] + (state_[y]) % 256;

    out[i] = in[i] ^ state_[xor_index];
  }
  x_ = x;
  y_ = y;
}

void rc4_cipher::decrypt(const void* in, void* out, size_type len)
{
  encrypt(in, out, len);
}


} // namespace crypto
} // namespace boost

