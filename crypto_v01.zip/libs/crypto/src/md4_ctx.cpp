
//          Copyright Kevin Sopp 2007.
// Distributed under the Boost Software License, Version 1.0.
//    (See accompanying file LICENSE_1_0.txt or copy at
//          http://www.boost.org/LICENSE_1_0.txt)

#include <boost/crypto/detail/md4_ctx.hpp>


namespace boost {
namespace crypto {
namespace detail {

const md4_ctx::word_type md4_ctx::init_values[4] =
{
  0x67452301, 0xefcdab89, 0x98badcfe, 0x10325476
};

md4_ctx::md4_ctx()
{
  std::memcpy(state, init_values, sizeof(state));
}

md4_ctx::md4_ctx(const md4_ctx& copy)
:
  bit_count(copy.bit_count)
{
  std::memcpy(state, copy.state, sizeof(state));
}

md4_ctx& md4_ctx::operator = (const md4_ctx& rhs)
{
  std::memcpy(state, rhs.state, sizeof(state));
  bit_count = rhs.bit_count;
  return *this;
}

void md4_ctx::reset()
{
  std::memcpy(state, init_values, sizeof(state));
  bit_count = 0;
}

void md4_ctx::clear()
{
  reset();
}

// processes one chunk of 64 bytes 
void md4_ctx::process_block(const void* msg)
{
  word_type x[16];
  native_to_little_endian<word_type>(x, msg, sizeof(x));

  word_type a = A;
  word_type b = B;
  word_type c = C;
  word_type d = D;

  // round 1
  transform<aux_f>(a, b, c, d, x[ 0],  3, 0);
  transform<aux_f>(d, a, b, c, x[ 1],  7, 0);
  transform<aux_f>(c, d, a, b, x[ 2], 11, 0);
  transform<aux_f>(b, c, d, a, x[ 3], 19, 0);
  transform<aux_f>(a, b, c, d, x[ 4],  3, 0);
  transform<aux_f>(d, a, b, c, x[ 5],  7, 0);
  transform<aux_f>(c, d, a, b, x[ 6], 11, 0);
  transform<aux_f>(b, c, d, a, x[ 7], 19, 0);
  transform<aux_f>(a, b, c, d, x[ 8],  3, 0);
  transform<aux_f>(d, a, b, c, x[ 9],  7, 0);
  transform<aux_f>(c, d, a, b, x[10], 11, 0);
  transform<aux_f>(b, c, d, a, x[11], 19, 0);
  transform<aux_f>(a, b, c, d, x[12],  3, 0);
  transform<aux_f>(d, a, b, c, x[13],  7, 0);
  transform<aux_f>(c, d, a, b, x[14], 11, 0);
  transform<aux_f>(b, c, d, a, x[15], 19, 0);

  // round 2
  transform<aux_g>(a, b, c, d, x[ 0],  3, 0x5a827999);
  transform<aux_g>(d, a, b, c, x[ 4],  5, 0x5a827999);
  transform<aux_g>(c, d, a, b, x[ 8],  9, 0x5a827999);
  transform<aux_g>(b, c, d, a, x[12], 13, 0x5a827999);
  transform<aux_g>(a, b, c, d, x[ 1],  3, 0x5a827999);
  transform<aux_g>(d, a, b, c, x[ 5],  5, 0x5a827999);
  transform<aux_g>(c, d, a, b, x[ 9],  9, 0x5a827999);
  transform<aux_g>(b, c, d, a, x[13], 13, 0x5a827999);
  transform<aux_g>(a, b, c, d, x[ 2],  3, 0x5a827999);
  transform<aux_g>(d, a, b, c, x[ 6],  5, 0x5a827999);
  transform<aux_g>(c, d, a, b, x[10],  9, 0x5a827999);
  transform<aux_g>(b, c, d, a, x[14], 13, 0x5a827999);
  transform<aux_g>(a, b, c, d, x[ 3],  3, 0x5a827999);
  transform<aux_g>(d, a, b, c, x[ 7],  5, 0x5a827999);
  transform<aux_g>(c, d, a, b, x[11],  9, 0x5a827999);
  transform<aux_g>(b, c, d, a, x[15], 13, 0x5a827999);
  
  // round 3
  transform<aux_h>(a, b, c, d, x[ 0],  3, 0x6ed9eba1);
  transform<aux_h>(d, a, b, c, x[ 8],  9, 0x6ed9eba1);
  transform<aux_h>(c, d, a, b, x[ 4], 11, 0x6ed9eba1);
  transform<aux_h>(b, c, d, a, x[12], 15, 0x6ed9eba1);
  transform<aux_h>(a, b, c, d, x[ 2],  3, 0x6ed9eba1);
  transform<aux_h>(d, a, b, c, x[10],  9, 0x6ed9eba1);
  transform<aux_h>(c, d, a, b, x[ 6], 11, 0x6ed9eba1);
  transform<aux_h>(b, c, d, a, x[14], 15, 0x6ed9eba1);
  transform<aux_h>(a, b, c, d, x[ 1],  3, 0x6ed9eba1);
  transform<aux_h>(d, a, b, c, x[ 9],  9, 0x6ed9eba1);
  transform<aux_h>(c, d, a, b, x[ 5], 11, 0x6ed9eba1);
  transform<aux_h>(b, c, d, a, x[13], 15, 0x6ed9eba1);
  transform<aux_h>(a, b, c, d, x[ 3],  3, 0x6ed9eba1);
  transform<aux_h>(d, a, b, c, x[11],  9, 0x6ed9eba1);
  transform<aux_h>(c, d, a, b, x[ 7], 11, 0x6ed9eba1);
  transform<aux_h>(b, c, d, a, x[15], 15, 0x6ed9eba1);
  
  A += a;
  B += b;
  C += c;
  D += d;
}

void md4_ctx::store_msg_digest(void* digest) const
{
  native_to_little_endian<word_type>(digest, state, digest_length);
}

void md4_ctx::store_bit_count(void* dst) const
{
  bit_count.store_as_little_endian(dst);
}



} // namespace detail
} // namespace crypto
} // namespace boost


