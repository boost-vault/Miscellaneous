
//          Copyright Kevin Sopp 2007.
// Distributed under the Boost Software License, Version 1.0.
//    (See accompanying file LICENSE_1_0.txt or copy at
//          http://www.boost.org/LICENSE_1_0.txt)

#include <boost/crypto/detail/md_utils.hpp>
#include <boost/test/unit_test.hpp>


BOOST_AUTO_TEST_CASE(ctor)
{
  boost::crypto::detail::bit_count<unsigned char, 2> b;
  BOOST_CHECK_EQUAL(b[0], 0U);
  BOOST_CHECK_EQUAL(b[1], 0U);
}

BOOST_AUTO_TEST_CASE(add1)
{
  boost::crypto::detail::bit_count<unsigned char, 2> b;

  b.add(255U);
  BOOST_CHECK_EQUAL(b[0], 255U);
}

BOOST_AUTO_TEST_CASE(add2)
{
  boost::crypto::detail::bit_count<unsigned char, 2> b;

  b.add(255U);
  BOOST_CHECK_EQUAL(b[0], 255U);

  b.add(1U);
  BOOST_CHECK_EQUAL(b[0], 0U);
  BOOST_CHECK_EQUAL(b[1], 1U);
}

BOOST_AUTO_TEST_CASE(add3)
{
  boost::crypto::detail::bit_count<unsigned char, 2> b;

  b.add(255U);
  BOOST_CHECK_EQUAL(b[0], 255U);

  b.add(255U);
  BOOST_CHECK_EQUAL(b[0], 254U);
  BOOST_CHECK_EQUAL(b[1], 1U);
}

BOOST_AUTO_TEST_CASE(add4)
{
  boost::crypto::detail::bit_count<unsigned char, 2> b;

  b.add(255U);
  BOOST_CHECK_EQUAL(b[0], 255U);

  b.add(255U);
  BOOST_CHECK_EQUAL(b[0], 254U);
  BOOST_CHECK_EQUAL(b[1], 1U);

  b.add(255U);
  BOOST_CHECK_EQUAL(b[0], 253U);
  BOOST_CHECK_EQUAL(b[1], 2U);
}

BOOST_AUTO_TEST_CASE(overflow0)
{
  boost::crypto::detail::bit_count<unsigned char, 1> b;

  b.add(1U);
  BOOST_CHECK_THROW(b.add(255U), std::overflow_error);
  
  BOOST_CHECK_EQUAL(b[0], 1U);
}

BOOST_AUTO_TEST_CASE(overflow1)
{
  boost::crypto::detail::bit_count<unsigned char, 2> b;
  for (int i = 0; i < 257; ++i)
    b.add(255U);
  // now b == 65535 (= 2^16 - 1)
  BOOST_CHECK_EQUAL(b[0], 255U);
  BOOST_CHECK_EQUAL(b[1], 255U);

  BOOST_CHECK_THROW(b.add(1), std::overflow_error);
  BOOST_CHECK_EQUAL(b[0], 1U);
  BOOST_CHECK_EQUAL(b[1], 0U);

}

BOOST_AUTO_TEST_CASE(overflow2)
{
  boost::crypto::detail::bit_count<unsigned char, 3> b;
  for (int i = 0; i < 65793; ++i)
    b.add(255U);
  // now b == 16777215 (= 2^24 - 1)
  BOOST_CHECK_EQUAL(b[0], 255U);
  BOOST_CHECK_EQUAL(b[1], 255U);
  BOOST_CHECK_EQUAL(b[2], 255U);

  BOOST_CHECK_THROW(b.add(1), std::overflow_error);
  BOOST_CHECK_EQUAL(b[0], 1U);
  BOOST_CHECK_EQUAL(b[1], 0U);
  BOOST_CHECK_EQUAL(b[2], 0U);
}

#include <boost/cstdint.hpp>


BOOST_AUTO_TEST_CASE(bitcount_be_store)
{
  boost::crypto::detail::bit_count<boost::uint32_t, 2> b;
  b[0] = 0x00112233;
  b[1] = 0x44556677;
  
  unsigned char dst[8];
  b.store_as_big_endian(dst);
  BOOST_CHECK_EQUAL(dst[0], 0x44);
  BOOST_CHECK_EQUAL(dst[1], 0x55);
  BOOST_CHECK_EQUAL(dst[2], 0x66);
  BOOST_CHECK_EQUAL(dst[3], 0x77);
  BOOST_CHECK_EQUAL(dst[4], 0x00);
  BOOST_CHECK_EQUAL(dst[5], 0x11);
  BOOST_CHECK_EQUAL(dst[6], 0x22);
  BOOST_CHECK_EQUAL(dst[7], 0x33);
}

BOOST_AUTO_TEST_CASE(bitcount_le_store)
{
  boost::crypto::detail::bit_count<boost::uint32_t, 2> b;
  b[0] = 0x00112233;
  b[1] = 0x44556677;
  
  unsigned char dst[8];
  b.store_as_little_endian(dst);
  BOOST_CHECK_EQUAL(dst[0], 0x33);
  BOOST_CHECK_EQUAL(dst[1], 0x22);
  BOOST_CHECK_EQUAL(dst[2], 0x11);
  BOOST_CHECK_EQUAL(dst[3], 0x00);
  BOOST_CHECK_EQUAL(dst[4], 0x77);
  BOOST_CHECK_EQUAL(dst[5], 0x66);
  BOOST_CHECK_EQUAL(dst[6], 0x55);
  BOOST_CHECK_EQUAL(dst[7], 0x44);
}


// TODO put endian conversions into seperate file
BOOST_AUTO_TEST_CASE(native_to_big_endian)
{
  boost::uint32_t src[2];
  src[0] = 0x00112233;
  src[1] = 0x44556677;
  
  unsigned char dst[8];
  boost::crypto::detail::native_to_big_endian<boost::uint32_t>(dst, src, 8);
  BOOST_CHECK_EQUAL(dst[0], 0x00);
  BOOST_CHECK_EQUAL(dst[1], 0x11);
  BOOST_CHECK_EQUAL(dst[2], 0x22);
  BOOST_CHECK_EQUAL(dst[3], 0x33);
  BOOST_CHECK_EQUAL(dst[4], 0x44);
  BOOST_CHECK_EQUAL(dst[5], 0x55);
  BOOST_CHECK_EQUAL(dst[6], 0x66);
  BOOST_CHECK_EQUAL(dst[7], 0x77);
}

BOOST_AUTO_TEST_CASE(native_to_little_endian)
{
  boost::uint32_t src[2];
  src[0] = 0x00112233;
  src[1] = 0x44556677;
  
  unsigned char dst[8];
  boost::crypto::detail::native_to_little_endian<boost::uint32_t>(dst, src, 8);
  BOOST_CHECK_EQUAL(dst[0], 0x33);
  BOOST_CHECK_EQUAL(dst[1], 0x22);
  BOOST_CHECK_EQUAL(dst[2], 0x11);
  BOOST_CHECK_EQUAL(dst[3], 0x00);
  BOOST_CHECK_EQUAL(dst[4], 0x77);
  BOOST_CHECK_EQUAL(dst[5], 0x66);
  BOOST_CHECK_EQUAL(dst[6], 0x55);
  BOOST_CHECK_EQUAL(dst[7], 0x44);
}

// XXX 
/*BOOST_AUTO_TEST_CASE(big_endian_to_native)
{
  boost::uint32_t src[2];
  src[0] = 0x00112233;
  src[1] = 0x44556677;
  
  unsigned char dst[8];
  boost::crypto::detail::
  big_endian_to_native<boost::uint32_t>(dst, src, 8);
  #if defined(BOOST_LITTLE_ENDIAN)
    BOOST_CHECK_EQUAL(dst[0], 0x33);
    BOOST_CHECK_EQUAL(dst[1], 0x22);
    BOOST_CHECK_EQUAL(dst[2], 0x11);
    BOOST_CHECK_EQUAL(dst[3], 0x00);
    BOOST_CHECK_EQUAL(dst[4], 0x77);
    BOOST_CHECK_EQUAL(dst[5], 0x66);
    BOOST_CHECK_EQUAL(dst[6], 0x55);
    BOOST_CHECK_EQUAL(dst[7], 0x44);
  #elif defined(BOOST_BIG_ENDIAN)
    BOOST_CHECK_EQUAL(dst[0], 0x00);
    BOOST_CHECK_EQUAL(dst[1], 0x11);
    BOOST_CHECK_EQUAL(dst[2], 0x22);
    BOOST_CHECK_EQUAL(dst[3], 0x33);
    BOOST_CHECK_EQUAL(dst[4], 0x44);
    BOOST_CHECK_EQUAL(dst[5], 0x55);
    BOOST_CHECK_EQUAL(dst[6], 0x66);
    BOOST_CHECK_EQUAL(dst[7], 0x77);
  #else
    #error unsupported endianness
  #endif
}
*/
