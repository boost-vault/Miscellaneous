
//          Copyright Kevin Sopp 2007.
// Distributed under the Boost Software License, Version 1.0.
//    (See accompanying file LICENSE_1_0.txt or copy at
//          http://www.boost.org/LICENSE_1_0.txt)

#include <boost/crypto/hmac.hpp>
#include <boost/crypto/sha1.hpp>
#include <boost/crypto/detail/test_utils.hpp>
#include <boost/test/unit_test.hpp>


BOOST_AUTO_TEST_CASE(hmac_sample1_64byte_key)
{
  const char* const key = "000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f202122232425262728292a2b2c2d2e2f303132333435363738393a3b3c3d3e3f";
  const char* const text = "Sample #1";

  const byte_string keystr(key, 128);
  boost::crypto::hmac<boost::crypto::sha1> h;
  h.set_key(keystr.data(), keystr.size());
  h.compute(text, 9, false);
  BOOST_CHECK_EQUAL(h, "4f4ca3d5d68ba7cc0a1208c9c61e9c5da0403c0a");
}

BOOST_AUTO_TEST_CASE(hmac_sample2_20byte_key)
{
  const char* const key = "303132333435363738393a3b3c3d3e3f40414243";
  const char* const text = "Sample #2";

  const byte_string keystr(key, 40);
  boost::crypto::hmac<boost::crypto::sha1> h;
  h.set_key(keystr.data(), keystr.size());
  h.compute(text, 9, false);
  BOOST_CHECK_EQUAL(h, "0922d3405faa3d194f82a45830737d5cc6c75d24");
}

BOOST_AUTO_TEST_CASE(hmac_sample3_100byte_key)
{
  const char* const key = "505152535455565758595a5b5c5d5e5f606162636465666768696a6b6c6d6e6f707172737475767778797a7b7c7d7e7f808182838485868788898a8b8c8d8e8f909192939495969798999a9b9c9d9e9fa0a1a2a3a4a5a6a7a8a9aaabacadaeafb0b1b2b3";
  const char* const text = "Sample #3";

  const byte_string keystr(key, 200);
  boost::crypto::hmac<boost::crypto::sha1> h;
  h.set_key(keystr.data(), keystr.size());
  h.compute(text, 9, false);
  BOOST_CHECK_EQUAL(h, "bcf41eab8bb2d802f3d05caf7cb092ecf8d1a3aa");
}
