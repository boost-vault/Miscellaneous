
//          Copyright Kevin Sopp 2007.
// Distributed under the Boost Software License, Version 1.0.
//    (See accompanying file LICENSE_1_0.txt or copy at
//          http://www.boost.org/LICENSE_1_0.txt)

#include <boost/crypto/ripemd.hpp>
#include <boost/test/unit_test.hpp>

// the values are from the pdf
BOOST_AUTO_TEST_CASE(ripemd128_short_msg_test)
{
  static const char* const msg[7] = {
    "",
    "a",
    "abc",
    "message digest",
    "abcdefghijklmnopqrstuvwxyz",
    "abcdbcdecdefdefgefghfghighijhijkijkljklmklmnlmnomnopnopq",
    "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789"
  };

  static const char* const digest[7] = {
    "cdf26213a150dc3ecb610f18f6b38b46",
    "86be7afa339d0fc7cfc785e72f578d33",
    "c14a12199c66e4ba84636b0f69144c77",
    "9e327b3d6e523062afc1132d7df9d1b8",
    "fd2aa607f71dc8f510714922b371834e",
    "a1aa0689d0fafa2ddc22e88b49133a06",
    "d1e959eb179c911faea4624c60c5c702"
  };
  
  boost::crypto::ripemd128 m;
  for (int i = 0; i < 7; ++i)
  {
    m.input(msg[i]);
    BOOST_REQUIRE_EQUAL(m, digest[i]);
    m.reset();
  }

  // 8 times "1234567890"
  for (int i = 0; i < 8; ++i)
    m.input("1234567890");
  BOOST_REQUIRE_EQUAL(m, "3f45ef194732c2dbb2c4a2c769795fa3");
  m.reset();
  
  // 1 million times "a"
  for (int i = 0; i < 20000; ++i)
    // these are 50 "a"
    m.input("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
  BOOST_REQUIRE_EQUAL(m, "4a7f5723f954eba1216c9d8f6320431f");
}

