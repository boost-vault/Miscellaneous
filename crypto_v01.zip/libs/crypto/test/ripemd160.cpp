
//          Copyright Kevin Sopp 2007.
// Distributed under the Boost Software License, Version 1.0.
//    (See accompanying file LICENSE_1_0.txt or copy at
//          http://www.boost.org/LICENSE_1_0.txt)

#include <boost/crypto/ripemd.hpp>
#include <boost/test/unit_test.hpp>

// the values are from the pdf
BOOST_AUTO_TEST_CASE(ripemd160_short_msg_test)
{
  static const char* const msg[7] = {
    "",
    "a",
    "abc",
    "message digest",
    "abcdefghijklmnopqrstuvwxyz",
    "abcdbcdecdefdefgefghfghighijhijkijkljklmklmnlmnomnopnopq",
    "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789"
  };

  static const char* const digest[7] = {
    "9c1185a5c5e9fc54612808977ee8f548b2258d31",
    "0bdc9d2d256b3ee9daae347be6f4dc835a467ffe",
    "8eb208f7e05d987a9b044a8e98c6b087f15a0bfc",
    "5d0689ef49d2fae572b881b123a85ffa21595f36",
    "f71c27109c692c1b56bbdceb5b9d2865b3708dbc",
    "12a053384a9c0c88e405a06c27dcf49ada62eb2b",
    "b0e20b6e3116640286ed3a87a5713079b21f5189"
  };

  boost::crypto::ripemd160 m;
  for (int i = 0; i < 7; ++i)
  {
    m.input(msg[i]);
    BOOST_REQUIRE_EQUAL(m, digest[i]);
    m.reset();
  }

  // 8 times "1234567890"
  for (int i = 0; i < 8; ++i)
    m.input("1234567890");
  BOOST_REQUIRE_EQUAL(m, "9b752e45573d4b39f4dbd3323cab82bf63326bfb");
  m.reset();
  
  // 1 million times "a"
  for (int i = 0; i < 20000; ++i)
    // these are 50 "a"
    m.input("aaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaaa");
  BOOST_REQUIRE_EQUAL(m, "52783243c1697bdbe16d37f97f68f08325dc1528");
}

