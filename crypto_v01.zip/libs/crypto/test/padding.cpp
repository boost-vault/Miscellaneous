
//          Copyright Kevin Sopp 2007.
// Distributed under the Boost Software License, Version 1.0.
//    (See accompanying file LICENSE_1_0.txt or copy at
//          http://www.boost.org/LICENSE_1_0.txt)

#include <boost/crypto/block_cipher.hpp>
#include <boost/crypto/detail/test_utils.hpp>
#include <boost/test/unit_test.hpp>

static const int block_size = 4;

BOOST_AUTO_TEST_CASE(zero_padding_required_output_size)
{
  boost::crypto::zero_padding p;
  BOOST_REQUIRE_EQUAL(p.required_output_size(0, 4), 0U);
  BOOST_REQUIRE_EQUAL(p.required_output_size(1, 4), 4U);
  BOOST_REQUIRE_EQUAL(p.required_output_size(2, 4), 4U);
  BOOST_REQUIRE_EQUAL(p.required_output_size(3, 4), 4U);
  BOOST_REQUIRE_EQUAL(p.required_output_size(4, 4), 4U);
  BOOST_REQUIRE_EQUAL(p.required_output_size(5, 4), 8U);
}

BOOST_AUTO_TEST_CASE(zero_padding_pad1)
{
  boost::crypto::zero_padding p;
  unsigned char block[4] = {0xaa, 0xbb, 0xcc, 0xdd};
  p.pad(block, 4, 1);
  BOOST_CHECK_EQUAL(block[0], 0xaa);
  BOOST_CHECK_EQUAL(block[1], 0);
  BOOST_CHECK_EQUAL(block[2], 0);
  BOOST_CHECK_EQUAL(block[3], 0);
}

BOOST_AUTO_TEST_CASE(zero_padding_pad2)
{
  boost::crypto::zero_padding p;
  char block[16] = {0};
  block[0] = 'a';
  p.pad(block+1, 16, 1);
  BOOST_CHECK_EQUAL(block[0], 'a');
  for (int i = 1; i < 16; ++i)
    BOOST_CHECK_EQUAL(block[i], 0);
}

BOOST_AUTO_TEST_CASE(one_and_zeros_padding_required_output_size)
{
  boost::crypto::one_and_zeros_padding p;
  BOOST_REQUIRE_EQUAL(p.required_output_size(0, 4), 4U);
  BOOST_REQUIRE_EQUAL(p.required_output_size(1, 4), 4U);
  BOOST_REQUIRE_EQUAL(p.required_output_size(2, 4), 4U);
  BOOST_REQUIRE_EQUAL(p.required_output_size(3, 4), 4U);
  BOOST_REQUIRE_EQUAL(p.required_output_size(4, 4), 8U);
  BOOST_REQUIRE_EQUAL(p.required_output_size(5, 4), 8U);
}

BOOST_AUTO_TEST_CASE(one_and_zeros_padding_pad1)
{
  boost::crypto::one_and_zeros_padding p;
  unsigned char block[4] = {0xaa, 0xbb, 0xcc, 0xdd};
  p.pad(block, 4, 1);
  BOOST_CHECK_EQUAL(block[0], 0xaa);
  BOOST_CHECK_EQUAL(block[1], 0x80);
  BOOST_CHECK_EQUAL(block[2], 0);
  BOOST_CHECK_EQUAL(block[3], 0);
}

