
//          Copyright Kevin Sopp 2007.
// Distributed under the Boost Software License, Version 1.0.
//    (See accompanying file LICENSE_1_0.txt or copy at
//          http://www.boost.org/LICENSE_1_0.txt)

#include <boost/crypto/block_cipher.hpp>
#include <boost/crypto/cipher_block_chaining_mode.hpp>
#include <boost/crypto/detail/null_cipher.hpp>
#include <boost/crypto/detail/test_utils.hpp>
#include <boost/test/unit_test.hpp>

typedef boost::crypto::block_cipher<
  boost::crypto::detail::null_cipher,
  boost::crypto::cbc_mode,
  boost::crypto::zero_padding
> null_cipher;

const byte_string iv("012345678901234567890123456789ff", 32);

// TODO there should be seperate file to test the padding objs
BOOST_AUTO_TEST_CASE(required_output_size)
{
  null_cipher c;
  BOOST_CHECK_EQUAL(c.required_output_size(0), 0U);
  BOOST_CHECK_EQUAL(c.required_output_size(15), 16U);
  BOOST_CHECK_EQUAL(c.required_output_size(16), 16U);
}

BOOST_AUTO_TEST_CASE(msg_of_length_zero)
{
  null_cipher c;
  const byte_string plaintext("", 0);
  const unsigned int outsize = c.required_output_size(plaintext.size());
  byte_string ciphertext(outsize);
  byte_string out(plaintext.size());
  c.set_key(0, 0);
  c.encrypt(iv.data(), plaintext.data(), ciphertext.data(), plaintext.size());
  c.decrypt(iv.data(), ciphertext.data(), out.data(), plaintext.size());
  BOOST_CHECK_EQUAL(out, plaintext);
}

BOOST_AUTO_TEST_CASE(msg_shorter_than_block_size)
{
  null_cipher c;
  const byte_string plaintext("00102030", 8);
  const unsigned int outsize = c.required_output_size(plaintext.size());
  byte_string ciphertext(outsize);
  byte_string out(plaintext.size());
  c.set_key(0, 0);
  c.encrypt(iv.data(), plaintext.data(), ciphertext.data(), plaintext.size());
  c.decrypt(iv.data(), ciphertext.data(), out.data(), plaintext.size());
  BOOST_CHECK_EQUAL(out, plaintext);
}

BOOST_AUTO_TEST_CASE(msg_equal_to_block_size)
{
  null_cipher c;
  const byte_string plaintext("00102030405060708090a0b0c0d0e0f0", 32);
  const unsigned int outsize = c.required_output_size(plaintext.size());
  byte_string ciphertext(outsize);
  byte_string out(plaintext.size());
  c.set_key(0, 0);
  c.encrypt(iv.data(), plaintext.data(), ciphertext.data(), plaintext.size());
  c.decrypt(iv.data(), ciphertext.data(), out.data(), plaintext.size());
  BOOST_CHECK_EQUAL(out, plaintext);
}

BOOST_AUTO_TEST_CASE(msg_equal_to_2x_block_size)
{
  null_cipher c;
  const byte_string plaintext("00102030405060708090a0b0c0d0e0f0"
                              "00102030405060708090a0b0c0d0e0f0", 64);
  const unsigned int outsize = c.required_output_size(plaintext.size());
  byte_string ciphertext(outsize);
  byte_string out(plaintext.size());
  c.set_key(0, 0);
  c.encrypt(iv.data(), plaintext.data(), ciphertext.data(), plaintext.size());
  c.decrypt(iv.data(), ciphertext.data(), out.data(), plaintext.size());
  BOOST_CHECK_EQUAL(out, plaintext);
}

BOOST_AUTO_TEST_CASE(msg_greater_than_block_size_with_padding)
{
  null_cipher c;
  const byte_string plaintext("00102030405060708090a0b0c0d0e0f0"
                              "00102030405060708090a0b0c0d0e0f0ff", 66);
  const unsigned int outsize = c.required_output_size(plaintext.size());
  byte_string ciphertext(outsize);
  byte_string out(plaintext.size());
  c.set_key(0, 0);
  c.encrypt(iv.data(), plaintext.data(), ciphertext.data(), plaintext.size());
  c.decrypt(iv.data(), ciphertext.data(), out.data(), plaintext.size());
  BOOST_CHECK_EQUAL(out, plaintext);
}


typedef boost::crypto::block_cipher<
  boost::crypto::detail::null_cipher,
  boost::crypto::cbc_mode,
  boost::crypto::one_and_zeros_padding
> null_cipher2;

BOOST_AUTO_TEST_CASE(required_output_size2)
{
  null_cipher2 c;
  BOOST_CHECK_EQUAL(c.required_output_size(0), 16U);
  BOOST_CHECK_EQUAL(c.required_output_size(15), 16U);
  BOOST_CHECK_EQUAL(c.required_output_size(16), 32U);
}

BOOST_AUTO_TEST_CASE(msg_of_length_zero2)
{
  null_cipher2 c;
  const byte_string plaintext("", 0);
  const unsigned int outsize = c.required_output_size(plaintext.size());
  byte_string ciphertext(outsize);
  byte_string out(plaintext.size());
  c.set_key(0, 0);
  c.encrypt(iv.data(), plaintext.data(), ciphertext.data(), plaintext.size());
  c.decrypt(iv.data(), ciphertext.data(), out.data(), plaintext.size());
  BOOST_CHECK_EQUAL(out, plaintext);
}

BOOST_AUTO_TEST_CASE(msg_shorter_than_block_size2)
{
  null_cipher2 c;
  const byte_string plaintext("00102030", 8);
  const unsigned int outsize = c.required_output_size(plaintext.size());
  byte_string ciphertext(outsize);
  byte_string out(plaintext.size());
  c.set_key(0, 0);
  c.encrypt(iv.data(), plaintext.data(), ciphertext.data(), plaintext.size());
  c.decrypt(iv.data(), ciphertext.data(), out.data(), plaintext.size());
  BOOST_CHECK_EQUAL(out, plaintext);
}

BOOST_AUTO_TEST_CASE(msg_equal_to_block_size2)
{
  null_cipher2 c;
  const byte_string plaintext("00102030405060708090a0b0c0d0e0f0", 32);
  const unsigned int outsize = c.required_output_size(plaintext.size());
  byte_string ciphertext(outsize);
  byte_string out(plaintext.size());
  c.set_key(0, 0);
  c.encrypt(iv.data(), plaintext.data(), ciphertext.data(), plaintext.size());
  c.decrypt(iv.data(), ciphertext.data(), out.data(), plaintext.size());
  BOOST_CHECK_EQUAL(out, plaintext);
}

BOOST_AUTO_TEST_CASE(msg_equal_to_2x_block_size2)
{
  null_cipher2 c;
  const byte_string plaintext("00102030405060708090a0b0c0d0e0f0"
                              "00102030405060708090a0b0c0d0e0f0", 64);
  const unsigned int outsize = c.required_output_size(plaintext.size());
  byte_string ciphertext(outsize);
  byte_string out(plaintext.size());
  c.set_key(0, 0);
  c.encrypt(iv.data(), plaintext.data(), ciphertext.data(), plaintext.size());
  c.decrypt(iv.data(), ciphertext.data(), out.data(), plaintext.size());
  BOOST_CHECK_EQUAL(out, plaintext);
}

BOOST_AUTO_TEST_CASE(msg_greater_than_block_size_with_padding2)
{
  null_cipher2 c;
  const byte_string plaintext("00102030405060708090a0b0c0d0e0f0"
                              "00102030405060708090a0b0c0d0e0f0ff", 66);
  const unsigned int outsize = c.required_output_size(plaintext.size());
  byte_string ciphertext(outsize);
  byte_string out(plaintext.size());
  c.set_key(0, 0);
  c.encrypt(iv.data(), plaintext.data(), ciphertext.data(), plaintext.size());
  c.decrypt(iv.data(), ciphertext.data(), out.data(), plaintext.size());
  BOOST_CHECK_EQUAL(out, plaintext);
}

