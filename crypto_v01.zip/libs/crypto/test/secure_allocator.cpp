
//          Copyright Kevin Sopp 2007.
// Distributed under the Boost Software License, Version 1.0.
//    (See accompanying file LICENSE_1_0.txt or copy at
//          http://www.boost.org/LICENSE_1_0.txt)

#include <list>
#include <vector>
#include <boost/crypto/secure_allocator.hpp>
#include <boost/test/unit_test.hpp>

typedef boost::crypto::secure_allocator<
  std::allocator<int>
> int_alloc;

struct dummy
{
  dummy() : ptr(this) {};
  ~dummy() { ptr = 0; }

  dummy* ptr;
};

typedef boost::crypto::secure_allocator<
  std::allocator<dummy>
> dummy_alloc;


BOOST_AUTO_TEST_CASE(vector_int)
{
  std::vector<int, int_alloc> v;
  for (int i = 0; i < 64; ++i)
    v.push_back(i);
  v.reserve(512);
  v.resize(16);
}

BOOST_AUTO_TEST_CASE(vector_dummy)
{
  std::vector<dummy, dummy_alloc> v;
  for (int i = 0; i < 64; ++i)
    v.push_back(dummy());
  v.reserve(512);
  v.resize(16);
}

BOOST_AUTO_TEST_CASE(list_int)
{
  std::list<int, int_alloc> v;
  for (int i = 0; i < 64; ++i)
    v.push_back(i);
}

BOOST_AUTO_TEST_CASE(list_dummy)
{
  std::list<dummy, dummy_alloc> v;
  for (int i = 0; i < 64; ++i)
    v.push_back(dummy());
}
