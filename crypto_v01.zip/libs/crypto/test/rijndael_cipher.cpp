
//          Copyright Kevin Sopp 2007.
// Distributed under the Boost Software License, Version 1.0.
//    (See accompanying file LICENSE_1_0.txt or copy at
//          http://www.boost.org/LICENSE_1_0.txt)

#include <boost/crypto/rijndael_cipher.hpp>
#include <boost/crypto/detail/test_utils.hpp>
#include <boost/test/unit_test.hpp>

template<int K, int B>
struct cipher_fixture
{
  cipher_fixture(const char* ckey, unsigned long int key_len,
                 const char* cplaintext, unsigned long int pt_len,
                 const char* ccipher_text, unsigned long int out_len)
  :
    key(ckey, key_len),
    original_plaintext(cplaintext, pt_len),
    original_cipher_text(ccipher_text, out_len),
    cipher_text(out_len/2),
    plaintext(out_len/2)
  {
    c.set_key(key.data(), key.size());
  }

  void encrypt()
  {
    c.encrypt_block(original_plaintext.data(), cipher_text.data());
  }
  void decrypt()
  {
    c.decrypt_block(cipher_text.data(), plaintext.data());
  }

  const byte_string key, original_plaintext, original_cipher_text;
  byte_string cipher_text, plaintext;
  boost::crypto::rijndael_cipher<K, B> c;
};


// B = 128
BOOST_AUTO_TEST_CASE(rijndael_128_128_cipher)
{
  cipher_fixture<128, 128> f(
    "000102030405060708090a0b0c0d0e0f", 32,
    "00112233445566778899aabbccddeeff", 32,
    "69c4e0d86a7b0430d8cdb78070b4c55a", 32);

  f.encrypt();
  BOOST_CHECK_EQUAL(f.cipher_text, f.original_cipher_text);
  f.decrypt();
  BOOST_CHECK_EQUAL(f.plaintext, f.original_plaintext);
}

BOOST_AUTO_TEST_CASE(rijndael_160_128_cipher)
{
  cipher_fixture<160, 128> f(
    "2b7e151628aed2a6abf7158809cf4f3c762e7160", 40,
    "3243f6a8885a308d313198a2e0370734", 32,
    "231d844639b31b412211cfe93712b880", 32);

  f.encrypt();
  BOOST_CHECK_EQUAL(f.cipher_text, f.original_cipher_text);
  f.decrypt();
  BOOST_CHECK_EQUAL(f.plaintext, f.original_plaintext);
}

BOOST_AUTO_TEST_CASE(rijndael_192_128_cipher)
{
  cipher_fixture<192, 128> f(
    "000102030405060708090a0b0c0d0e0f1011121314151617", 48,
    "00112233445566778899aabbccddeeff", 32,
    "dda97ca4864cdfe06eaf70a0ec0d7191", 32);

  f.encrypt();
  BOOST_CHECK_EQUAL(f.cipher_text, f.original_cipher_text);
  f.decrypt();
  BOOST_CHECK_EQUAL(f.plaintext, f.original_plaintext);
}

BOOST_AUTO_TEST_CASE(rijndael_224_128_cipher)
{
  cipher_fixture<224, 128> f(
    "2b7e151628aed2a6abf7158809cf4f3c762e7160f38b4da56a784d90", 56,
    "3243f6a8885a308d313198a2e0370734", 32,
    "8faa8fe4dee9eb17caa4797502fc9d3f", 32);

  f.encrypt();
  BOOST_CHECK_EQUAL(f.cipher_text, f.original_cipher_text);
  f.decrypt();
  BOOST_CHECK_EQUAL(f.plaintext, f.original_plaintext);
}

BOOST_AUTO_TEST_CASE(rijndael_256_128_cipher)
{
  cipher_fixture<256, 128> f(
    "000102030405060708090a0b0c0d0e0f101112131415161718191a1b1c1d1e1f", 64,
    "00112233445566778899aabbccddeeff", 32,
    "8ea2b7ca516745bfeafc49904b496089", 32);

  f.encrypt();
  BOOST_CHECK_EQUAL(f.cipher_text, f.original_cipher_text);
  f.decrypt();
  BOOST_CHECK_EQUAL(f.plaintext, f.original_plaintext);
}


// B = 160
BOOST_AUTO_TEST_CASE(rijndael_128_160_cipher)
{
  cipher_fixture<128, 160> f(
    "2b7e151628aed2a6abf7158809cf4f3c", 32,
    "3243f6a8885a308d313198a2e03707344a409382", 40,
    "16e73aec921314c29df905432bc8968ab64b1f51", 40);

  f.encrypt();
  BOOST_CHECK_EQUAL(f.cipher_text, f.original_cipher_text);
  f.decrypt();
  BOOST_CHECK_EQUAL(f.plaintext, f.original_plaintext);
}

BOOST_AUTO_TEST_CASE(rijndael_160_160_cipher)
{
  cipher_fixture<160, 160> f(
    "2b7e151628aed2a6abf7158809cf4f3c762e7160", 40,
    "3243f6a8885a308d313198a2e03707344a409382", 40,
    "0553eb691670dd8a5a5b5addf1aa7450f7a0e587", 40);

  f.encrypt();
  BOOST_CHECK_EQUAL(f.cipher_text, f.original_cipher_text);
  f.decrypt();
  BOOST_CHECK_EQUAL(f.plaintext, f.original_plaintext);
}

BOOST_AUTO_TEST_CASE(rijndael_192_160_cipher)
{
  cipher_fixture<192, 160> f(
    "2b7e151628aed2a6abf7158809cf4f3c762e7160f38b4da5", 48,
    "3243f6a8885a308d313198a2e03707344a409382", 40,
    "73cd6f3423036790463aa9e19cfcde894ea16623", 40);

  f.encrypt();
  BOOST_CHECK_EQUAL(f.cipher_text, f.original_cipher_text);
  f.decrypt();
  BOOST_CHECK_EQUAL(f.plaintext, f.original_plaintext);
}

BOOST_AUTO_TEST_CASE(rijndael_224_160_cipher)
{
  cipher_fixture<224, 160> f(
    "2b7e151628aed2a6abf7158809cf4f3c762e7160f38b4da56a784d90", 56,
    "3243f6a8885a308d313198a2e03707344a409382", 40,
    "601b5dcd1cf4ece954c740445340bf0afdc048df", 40);

  f.encrypt();
  BOOST_CHECK_EQUAL(f.cipher_text, f.original_cipher_text);
  f.decrypt();
  BOOST_CHECK_EQUAL(f.plaintext, f.original_plaintext);
}

BOOST_AUTO_TEST_CASE(rijndael_256_160_cipher)
{
  cipher_fixture<256, 160> f(
    "2b7e151628aed2a6abf7158809cf4f3c762e7160f38b4da56a784d9045190cfe", 64,
    "3243f6a8885a308d313198a2e03707344a409382", 40,
    "579e930b36c1529aa3e86628bacfe146942882cf", 40);

  f.encrypt();
  BOOST_CHECK_EQUAL(f.cipher_text, f.original_cipher_text);
  f.decrypt();
  BOOST_CHECK_EQUAL(f.plaintext, f.original_plaintext);
}


// B = 192
BOOST_AUTO_TEST_CASE(rijndael_128_192_cipher)
{
  cipher_fixture<128, 192> f(
    "2b7e151628aed2a6abf7158809cf4f3c", 32,
    "3243f6a8885a308d313198a2e03707344a4093822299f31d", 48,
    "b24d275489e82bb8f7375e0d5fcdb1f481757c538b65148a", 48);

  f.encrypt();
  BOOST_CHECK_EQUAL(f.cipher_text, f.original_cipher_text);
  f.decrypt();
  BOOST_CHECK_EQUAL(f.plaintext, f.original_plaintext);
}

BOOST_AUTO_TEST_CASE(rijndael_160_192_cipher)
{
  cipher_fixture<160, 192> f(
    "2b7e151628aed2a6abf7158809cf4f3c762e7160", 40,
    "3243f6a8885a308d313198a2e03707344a4093822299f31d", 48,
    "738dae25620d3d3beff4a037a04290d73eb33521a63ea568", 48);

  f.encrypt();
  BOOST_CHECK_EQUAL(f.cipher_text, f.original_cipher_text);
  f.decrypt();
  BOOST_CHECK_EQUAL(f.plaintext, f.original_plaintext);
}

BOOST_AUTO_TEST_CASE(rijndael_192_192_cipher)
{
  cipher_fixture<192, 192> f(
    "2b7e151628aed2a6abf7158809cf4f3c762e7160f38b4da5", 48,
    "3243f6a8885a308d313198a2e03707344a4093822299f31d", 48,
    "725ae43b5f3161de806a7c93e0bca93c967ec1ae1b71e1cf", 48);

  f.encrypt();
  BOOST_CHECK_EQUAL(f.cipher_text, f.original_cipher_text);
  f.decrypt();
  BOOST_CHECK_EQUAL(f.plaintext, f.original_plaintext);
}

BOOST_AUTO_TEST_CASE(rijndael_224_192_cipher)
{
  cipher_fixture<224, 192> f(
    "2b7e151628aed2a6abf7158809cf4f3c762e7160f38b4da56a784d90", 56,
    "3243f6a8885a308d313198a2e03707344a4093822299f31d", 48,
    "bbfc14180afbf6a36382a061843f0b63e769acdc98769130", 48);

  f.encrypt();
  BOOST_CHECK_EQUAL(f.cipher_text, f.original_cipher_text);
  f.decrypt();
  BOOST_CHECK_EQUAL(f.plaintext, f.original_plaintext);
}

BOOST_AUTO_TEST_CASE(rijndael_256_192_cipher)
{
  cipher_fixture<256, 192> f(
    "2b7e151628aed2a6abf7158809cf4f3c762e7160f38b4da56a784d9045190cfe", 64,
    "3243f6a8885a308d313198a2e03707344a4093822299f31d", 48,
    "0ebacf199e3315c2e34b24fcc7c46ef4388aa475d66c194c", 48);

  f.encrypt();
  BOOST_CHECK_EQUAL(f.cipher_text, f.original_cipher_text);
  f.decrypt();
  BOOST_CHECK_EQUAL(f.plaintext, f.original_plaintext);
}


// B = 224
BOOST_AUTO_TEST_CASE(rijndael_128_224_cipher)
{
  cipher_fixture<128, 224> f(
    "2b7e151628aed2a6abf7158809cf4f3c", 32,
    "3243f6a8885a308d313198a2e03707344a4093822299f31d0082efa9", 56,
    "b0a8f78f6b3c66213f792ffd2a61631f79331407a5e5c8d3793aceb1", 56);

  f.encrypt();
  BOOST_CHECK_EQUAL(f.cipher_text, f.original_cipher_text);
  f.decrypt();
  BOOST_CHECK_EQUAL(f.plaintext, f.original_plaintext);
}

BOOST_AUTO_TEST_CASE(rijndael_160_224_cipher)
{
  cipher_fixture<160, 224> f(
    "2b7e151628aed2a6abf7158809cf4f3c762e7160", 40,
    "3243f6a8885a308d313198a2e03707344a4093822299f31d0082efa9", 56,
    "08b99944edfce33a2acb131183ab0168446b2d15e958480010f545e3", 56);

  f.encrypt();
  BOOST_CHECK_EQUAL(f.cipher_text, f.original_cipher_text);
  f.decrypt();
  BOOST_CHECK_EQUAL(f.plaintext, f.original_plaintext);
}

BOOST_AUTO_TEST_CASE(rijndael_192_224_cipher)
{
  cipher_fixture<192, 224> f(
    "2b7e151628aed2a6abf7158809cf4f3c762e7160f38b4da5", 48,
    "3243f6a8885a308d313198a2e03707344a4093822299f31d0082efa9", 56,
    "be4c597d8f7efe22a2f7e5b1938e2564d452a5bfe72399c7af1101e2", 56);

  f.encrypt();
  BOOST_CHECK_EQUAL(f.cipher_text, f.original_cipher_text);
  f.decrypt();
  BOOST_CHECK_EQUAL(f.plaintext, f.original_plaintext);
}

BOOST_AUTO_TEST_CASE(rijndael_224_224_cipher)
{
  cipher_fixture<224, 224> f(
    "2b7e151628aed2a6abf7158809cf4f3c762e7160f38b4da56a784d90", 56,
    "3243f6a8885a308d313198a2e03707344a4093822299f31d0082efa9", 56,
    "ef529598ecbce297811b49bbed2c33bbe1241d6e1a833dbe119569e8", 56);

  f.encrypt();
  BOOST_CHECK_EQUAL(f.cipher_text, f.original_cipher_text);
  f.decrypt();
  BOOST_CHECK_EQUAL(f.plaintext, f.original_plaintext);
}

BOOST_AUTO_TEST_CASE(rijndael_256_224_cipher)
{
  cipher_fixture<256, 224> f(
    "2b7e151628aed2a6abf7158809cf4f3c762e7160f38b4da56a784d9045190cfe", 64,
    "3243f6a8885a308d313198a2e03707344a4093822299f31d0082efa9", 56,
    "02fafc200176ed05deb8edb82a3555b0b10d47a388dfd59cab2f6c11", 56);

  f.encrypt();
  BOOST_CHECK_EQUAL(f.cipher_text, f.original_cipher_text);
  f.decrypt();
  BOOST_CHECK_EQUAL(f.plaintext, f.original_plaintext);
}


// B = 256
BOOST_AUTO_TEST_CASE(rijndael_128_256_cipher)
{
  cipher_fixture<128, 256> f(
    "2b7e151628aed2a6abf7158809cf4f3c", 32,
    "3243f6a8885a308d313198a2e03707344a4093822299f31d0082efa98ec4e6c8", 64,
    "7d15479076b69a46ffb3b3beae97ad8313f622f67fedb487de9f06b9ed9c8f19", 64);

  f.encrypt();
  BOOST_CHECK_EQUAL(f.cipher_text, f.original_cipher_text);
  f.decrypt();
  BOOST_CHECK_EQUAL(f.plaintext, f.original_plaintext);
}

BOOST_AUTO_TEST_CASE(rijndael_160_256_cipher)
{
  cipher_fixture<160, 256> f(
    "2b7e151628aed2a6abf7158809cf4f3c762e7160", 40,
    "3243f6a8885a308d313198a2e03707344a4093822299f31d0082efa98ec4e6c8", 64,
    "514f93fb296b5ad16aa7df8b577abcbd484decacccc7fb1f18dc567309ceeffd", 64);

  f.encrypt();
  BOOST_CHECK_EQUAL(f.cipher_text, f.original_cipher_text);
  f.decrypt();
  BOOST_CHECK_EQUAL(f.plaintext, f.original_plaintext);
}

BOOST_AUTO_TEST_CASE(rijndael_192_256_cipher)
{
  cipher_fixture<192, 256> f(
    "2b7e151628aed2a6abf7158809cf4f3c762e7160f38b4da5", 48,
    "3243f6a8885a308d313198a2e03707344a4093822299f31d0082efa98ec4e6c8", 64,
    "5d7101727bb25781bf6715b0e6955282b9610e23a43c2eb062699f0ebf5887b2", 64);

  f.encrypt();
  BOOST_CHECK_EQUAL(f.cipher_text, f.original_cipher_text);
  f.decrypt();
  BOOST_CHECK_EQUAL(f.plaintext, f.original_plaintext);
}

BOOST_AUTO_TEST_CASE(rijndael_224_256_cipher)
{
  cipher_fixture<224, 256> f(
    "2b7e151628aed2a6abf7158809cf4f3c762e7160f38b4da56a784d90", 56,
    "3243f6a8885a308d313198a2e03707344a4093822299f31d0082efa98ec4e6c8", 64,
    "d56c5a63627432579e1dd308b2c8f157b40a4bfb56fea1377b25d3ed3d6dbf80", 64);

  f.encrypt();
  BOOST_CHECK_EQUAL(f.cipher_text, f.original_cipher_text);
  f.decrypt();
  BOOST_CHECK_EQUAL(f.plaintext, f.original_plaintext);
}

BOOST_AUTO_TEST_CASE(rijndael_256_256_cipher)
{
  cipher_fixture<256, 256> f(
    "2b7e151628aed2a6abf7158809cf4f3c762e7160f38b4da56a784d9045190cfe", 64,
    "3243f6a8885a308d313198a2e03707344a4093822299f31d0082efa98ec4e6c8", 64,
    "a49406115dfb30a40418aafa4869b7c6a886ff31602a7dd19c889dc64f7e4e7a", 64);

  f.encrypt();
  BOOST_CHECK_EQUAL(f.cipher_text, f.original_cipher_text);
  f.decrypt();
  BOOST_CHECK_EQUAL(f.plaintext, f.original_plaintext);
}

