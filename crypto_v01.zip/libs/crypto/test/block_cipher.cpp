
//          Copyright Kevin Sopp 2007.
// Distributed under the Boost Software License, Version 1.0.
//    (See accompanying file LICENSE_1_0.txt or copy at
//          http://www.boost.org/LICENSE_1_0.txt)

#include <boost/crypto/block_cipher.hpp>
#include <boost/crypto/cipher_block_chaining_mode.hpp>
#include <boost/crypto/electronic_code_book_mode.hpp>
#include <boost/crypto/rijndael_cipher.hpp>
#include <boost/crypto/detail/test_utils.hpp>
#include <boost/test/unit_test.hpp>

typedef boost::crypto::block_cipher<
  boost::crypto::aes128_cipher,
  boost::crypto::ecb_mode,
  boost::crypto::zero_padding
> cipher_type;

const byte_string iv("012345678901234567890123456789ff", 32);
const byte_string key("abcdefabcdefabcdefabcdefabcdefab", 32);

BOOST_AUTO_TEST_CASE(cipher_test)
{
  cipher_type c;
  const byte_string plaintext("00102030405060708090a0b0c0d0e0f0"
                              "00102030405060708090a0b0c0d0e0f0ff", 66);
  const unsigned int outsize = c.required_output_size(plaintext.size());
  byte_string ciphertext(outsize);
  byte_string out(plaintext.size());
  c.set_key(key.data(), key.size());
  c.encrypt(/*iv.data(),*/ plaintext.data(), ciphertext.data(), plaintext.size());
  c.decrypt(/*iv.data(),*/ ciphertext.data(), out.data(), plaintext.size());
  BOOST_CHECK_EQUAL(out, plaintext);  
}

// should tough test be moved directly to test_rijndael.cpp?
BOOST_AUTO_TEST_CASE(tough_test)
{
  cipher_type c;
  const unsigned int k = cipher_type::key_length;
  const unsigned int b = cipher_type::block_size;
  byte_string s(k + b, 0);
  for (int i = 0; i < 1000; ++i)
  {
    const byte_string key(s.end() - k, s.end());
    const byte_string plaintext(s.end() - k - b, s.end() - k);
    byte_string out(c.required_output_size(plaintext.size()));
    c.set_key(key.data(), key.size());
    c.encrypt(plaintext.data(), out.data(), plaintext.size());
    c.encrypt(out.data(), out.data(), out.size());
    s += out;
    s.erase(s.begin(), s.end() - k - b);
  }
  const byte_string x(s.end() - b, s.end());
  BOOST_CHECK_EQUAL(x, byte_string("bd883f01035e58f42f9d812f2dacbcd8", 32));
}

