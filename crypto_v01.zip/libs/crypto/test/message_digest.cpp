
//          Copyright Kevin Sopp 2007.
// Distributed under the Boost Software License, Version 1.0.
//    (See accompanying file LICENSE_1_0.txt or copy at
//          http://www.boost.org/LICENSE_1_0.txt)

#include <boost/lambda/lambda.hpp>
#include <boost/crypto/message_digest.hpp>
#include <boost/crypto/detail/null_ctx.hpp>
#include <boost/test/unit_test.hpp>

typedef boost::crypto::message_digest<
  boost::crypto::detail::null_ctx
> md_null;

BOOST_AUTO_TEST_CASE(default_ctor)
{
  md_null m;
}

BOOST_AUTO_TEST_CASE(zero_digest)
{
  md_null m;
  boost::uint32_t digest =
    *reinterpret_cast<const boost::uint32_t*>(m.digest());
  BOOST_CHECK_EQUAL(digest, 0U);
}

BOOST_AUTO_TEST_CASE(ctor_string)
{
  md_null m("hello world");
}

BOOST_AUTO_TEST_CASE(ctor_wstring)
{
  md_null m(L"hello world");
}

BOOST_AUTO_TEST_CASE(ctor_other_string)
{
  typedef std::basic_string<unsigned int> string_type;
  string_type s;
  s.push_back(12);
  md_null m(s);
}

BOOST_AUTO_TEST_CASE(ctor_iterator)
{
  std::string s("hello world");
  md_null m(s.begin(), s.end());
}

BOOST_AUTO_TEST_CASE(ctor_void_ptr)
{
  const char s[] = "hello world";
  md_null m(s, sizeof(s));
}

BOOST_AUTO_TEST_CASE(to_string)
{
  md_null m("hello world");
  BOOST_CHECK_EQUAL(m.to_string(), "58000000");
}

BOOST_AUTO_TEST_CASE(output_op)
{
  md_null m("hello world");
  std::ostringstream os;
  os << m;
  BOOST_CHECK_EQUAL(os.str(), "58000000");
}

BOOST_AUTO_TEST_CASE(equal_op)
{
  using namespace boost::lambda;
  md_null x("a"), y("a"), z("bb");

  BOOST_CHECK_EQUAL(x, y);
  BOOST_CHECK_PREDICATE(_1 != _2, (x)(z));
  //BOOST_CHECK_NOT_EQUAL(x, z);
  BOOST_CHECK_EQUAL("08000000", x);
  BOOST_CHECK_PREDICATE(_1 != _2, ("08000000")(z));
  //BOOST_CHECK_NOT_EQUAL("08000000", z);
}

