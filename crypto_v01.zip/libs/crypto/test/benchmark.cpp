
//          Copyright Kevin Sopp 2007.
// Distributed under the Boost Software License, Version 1.0.
//    (See accompanying file LICENSE_1_0.txt or copy at
//          http://www.boost.org/LICENSE_1_0.txt)

#include <iostream>
#include <boost/timer.hpp>

#include <boost/crypto/md4.hpp>
#include <boost/crypto/md5.hpp>
#include <boost/crypto/ripemd.hpp>
#include <boost/crypto/sha1.hpp>
#include <boost/crypto/sha2.hpp>

#include <boost/crypto/block_cipher.hpp>
#include <boost/crypto/electronic_code_book_mode.hpp>
#include <boost/crypto/blowfish_cipher.hpp>
#include <boost/crypto/rijndael_cipher.hpp>


struct bench_ctx
{
  bench_ctx(int n, double s, double dd)
    : bytes(n), seconds(s), d(dd) {}
  const int bytes;
  const double seconds;
  const double d;
};

void bench_memcpy(const char* name, const bench_ctx& ctx)
{
  const char* const memory = new char[ctx.bytes];
  char* dst = new char[ctx.bytes];
  std::cout << name << ": " << ctx.bytes/1024.0/1024.0 << " MB blocks: ";
  std::cout.flush();
  int loops = 0;
  boost::timer t;
  for (; t.elapsed() < ctx.seconds; ++loops)
    std::memcpy(dst, memory, ctx.bytes);
  const double e = t.elapsed() - ctx.d * loops;
  const int mbytes = ctx.bytes*loops/1024/1024;
  std::cout << e << "s, " << mbytes/e << " MB/sec" << std::endl;
  delete[] dst;
  delete[] memory;
};

template<class C>
void bench_cipher(
    const char* name, const char* key, unsigned keylen, const bench_ctx& ctx)
{
  boost::crypto::block_cipher<
    C,
    boost::crypto::ecb_mode,
    boost::crypto::zero_padding
  > c;
  c.set_key(key, keylen);
  char* memory = new char[ctx.bytes];
  {
    std::cout << name << " - encrypt: " << ctx.bytes/1024.0/1024.0 << " MB blocks: ";
    std::cout.flush();
    int loops = 0;
    boost::timer t;
    for (; t.elapsed() < ctx.seconds; ++loops)
      c.encrypt(memory, memory, ctx.bytes);
    const double e = t.elapsed() - ctx.d * loops;
    const int mbytes = ctx.bytes*loops/1024/1024;
    std::cout << e << "s, " << mbytes/e << " MB/sec" << std::endl;
  }
  {
    std::cout << name << " - decrypt: " << ctx.bytes/1024.0/1024.0 << " MB blocks: ";
    std::cout.flush();
    int loops = 0;
    boost::timer t;
    for (; t.elapsed() < ctx.seconds; ++loops)
      c.decrypt(memory, memory, ctx.bytes);
    const double e = t.elapsed() - ctx.d * loops;
    const int mbytes = ctx.bytes*loops/1024/1024;
    std::cout << e << "s, " << mbytes/e << " MB/sec" << std::endl;
  }
  delete[] memory;
}

template<class MD>
void bench_hash(const char* name, const bench_ctx& ctx)
{
  MD md;
  const char* const memory = new char[ctx.bytes];
  std::cout << name << ": " << ctx.bytes/1024.0/1024.0 << " MB blocks: ";
  std::cout.flush();
  int loops = 0;
  boost::timer t;
  for (; t.elapsed() < ctx.seconds; ++loops)
    md.input(memory, ctx.bytes);
  const double e = t.elapsed() - ctx.d * loops;
  md.digest();
  const int mbytes = ctx.bytes*loops/1024/1024;
  std::cout << e << "s, " << mbytes/e << " MB/sec" << std::endl;
  delete[] memory;
}



int main(int, char**)
{
  // check how long a call for t.elapsed() takes
  double d = 0.0;
  unsigned long int i = 0;
  boost::timer t;
  for (; d < 1.0; ++i)
    d = t.elapsed();
  d /= (double)i;
  std::cout << "d = " << d << std::endl;

  bench_ctx ctx(10 * 1024 * 1024, 3.0, d);
 
  using namespace boost::crypto;
  bench_memcpy         ("memcpy   ", ctx);
  bench_hash<md4      >("md4      ", ctx);
  bench_hash<md5      >("md5      ", ctx);
  bench_hash<ripemd128>("ripemd128", ctx);
  bench_hash<ripemd256>("ripemd256", ctx);
  bench_hash<ripemd160>("ripemd160", ctx);
  bench_hash<ripemd320>("ripemd320", ctx);
  bench_hash<sha1     >("sha1     ", ctx);
  bench_hash<sha224   >("sha224   ", ctx);
  bench_hash<sha256   >("sha256   ", ctx);
  bench_hash<sha384   >("sha384   ", ctx);
  bench_hash<sha512   >("sha512   ", ctx);
  
  const char* key = "0123456789123456789012345678901";
  bench_cipher<blowfish_cipher          >("blowfish          ", key, 16, ctx);
  bench_cipher<rijndael_cipher<128,128> >("rijndael<128,128> ", key, 16, ctx);

  return 0;
}

