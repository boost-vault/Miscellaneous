
//          Copyright Kevin Sopp 2007.
// Distributed under the Boost Software License, Version 1.0.
//    (See accompanying file LICENSE_1_0.txt or copy at
//          http://www.boost.org/LICENSE_1_0.txt)

#include <boost/crypto/md5.hpp>
#include <boost/test/unit_test.hpp>


BOOST_AUTO_TEST_CASE(md5_default_ctor)
{
  boost::crypto::md5 m;
}

BOOST_AUTO_TEST_CASE(equal_op)
{
  boost::crypto::md5 x("hello world", 11);
  boost::crypto::md5 y("hello world", 11);
  BOOST_CHECK_EQUAL(x, y);
}

BOOST_AUTO_TEST_CASE(md5_ctor1)
{
  boost::crypto::md5 m("", 0);
  BOOST_CHECK_EQUAL(m, "d41d8cd98f00b204e9800998ecf8427e");
}

BOOST_AUTO_TEST_CASE(md5_ctor2)
{
  const char* a = "a";
  boost::crypto::md5 m(a, a+1);
  BOOST_CHECK_EQUAL(m, "0cc175b9c0f1b6a831c399e269772661");
}

BOOST_AUTO_TEST_CASE(md5_ctor3)
{
  const char* abc = "abc";
  boost::crypto::md5 m(abc, 3);
  BOOST_CHECK_EQUAL(m, "900150983cd24fb0d6963f7d28e17f72");
}

BOOST_AUTO_TEST_CASE(md5_ctor4)
{
	const std::string hi("hi");
	boost::crypto::md5 m(hi.begin(), hi.end());
	BOOST_CHECK_EQUAL(m, "49f68a5c8493ec2c0bf489821c21fc3b");
}

BOOST_AUTO_TEST_CASE(md5_input1)
{
  boost::crypto::md5 m;
  m.input("ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789", 62);
  BOOST_CHECK_EQUAL(m, "d174ab98d277d9f5a5611c2c9f419d9f");
  m.reset();
  m.input("1234567890123456789012345678901234567890"
            "1234567890123456789012345678901234567890", 80);
  BOOST_CHECK_EQUAL(m, "57edf4a22be3c955ac49da2e2107b67a");
}

BOOST_AUTO_TEST_CASE(md5_input2)
{
  boost::crypto::md5 m;
  m.input("1234567890", 10);
  m.input("123456789012345678901234567890", 30);
  m.input("1234567890123456789012345678901234567890", 40);
  BOOST_CHECK_EQUAL(m, "57edf4a22be3c955ac49da2e2107b67a");
}


