
//          Copyright Kevin Sopp 2007.
// Distributed under the Boost Software License, Version 1.0.
//    (See accompanying file LICENSE_1_0.txt or copy at
//          http://www.boost.org/LICENSE_1_0.txt)

#ifndef BOOST_CRYPTO_DETAIL_NULL_CIPHER_HPP
#define BOOST_CRYPTO_DETAIL_NULL_CIPHER_HPP

#include <cstring>

namespace boost {
namespace crypto {
namespace detail {

// this is used for testing only, it just copies the input to the output
struct null_cipher
{
  static const int block_size = 128;
  static const int key_length = 0;

  static void set_key(const void*, unsigned) { }

  static void encrypt_block(const void* in, void* out)
  {
    std::memcpy(out, in, block_size / 8);
  }
  static void decrypt_block(const void* in, void* out)
  {
    std::memcpy(out, in, block_size / 8);
  }
};

} // namespace detail
} // namespace crypto
} // namespace boost

#endif

