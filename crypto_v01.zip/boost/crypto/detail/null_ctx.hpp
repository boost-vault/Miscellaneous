
//          Copyright Kevin Sopp 2007.
// Distributed under the Boost Software License, Version 1.0.
//    (See accompanying file LICENSE_1_0.txt or copy at
//          http://www.boost.org/LICENSE_1_0.txt)

// The message digest produced by this class is just the number of bits
// processed. This class is only used for testing.

#ifndef BOOST_CRYPTO_DETAIL_NULL_CTX_HPP
#define BOOST_CRYPTO_DETAIL_NULL_CTX_HPP

#include <boost/cstdint.hpp>

namespace boost {
namespace crypto {
namespace detail {

struct null_ctx
{
  static const int digest_length = 4;
  static const int block_size = 64;
  static const int padding_size = 64;
  static const int input_length_size = 4;

  typedef boost::uint8_t  uint8_t;
  typedef boost::uint32_t uint32_t;
  typedef boost::uint8_t  element_type;
  typedef boost::uint32_t word_type;
  typedef boost::uint32_t size_type;

  null_ctx() : bit_count(0){}

  null_ctx(const null_ctx& copy)
  :
    bit_count(copy.bit_count)
  {}
  
  null_ctx& operator = (const null_ctx& rhs)
  {
    bit_count = rhs.bit_count;
    return *this;
  }

  void reset() { bit_count = 0; }

  void clear()
  {
    reset();
  }

  void process_block(const void*)
  {}

  void store_msg_digest(void* digest) const
  {
    *reinterpret_cast<word_type*>(digest) = bit_count;
  }
  void store_bit_count(void* dst) const
  {
    *reinterpret_cast<word_type*>(dst) = bit_count;
  }
  
  void add_to_bit_count(size_type x)
  {
    bit_count += x;
  }
  
  unsigned int bytes_in_buf() const
  {
    return bit_count / 8 % block_size;
  }
  
  unsigned int bits_in_buf() const
  {
    return bit_count % block_size;
  }

  word_type bit_count;
};


} // namespace detail
} // namespace crypto
} // namespace boost

#endif

