
//          Copyright Kevin Sopp 2007.
// Distributed under the Boost Software License, Version 1.0.
//    (See accompanying file LICENSE_1_0.txt or copy at
//          http://www.boost.org/LICENSE_1_0.txt)

// Based on Federal Information Processing Standard (FIPS) PUB 180-3


#ifndef BOOST_CRYPTO_DETAIL_SHA1_CTX_HPP
#define BOOST_CRYPTO_DETAIL_SHA1_CTX_HPP

#include <boost/cstdint.hpp>
#include <boost/crypto/detail/md_utils.hpp>

namespace boost {
namespace crypto {
namespace detail {

struct sha1_ctx
{
  static const int digest_length = 20;
  static const int block_size = 64;
  static const int padding_size = 64;
  static const int input_length_size = 8;

  typedef boost::uint8_t  uint8_t;
  typedef boost::uint8_t  element_type;
  typedef boost::uint32_t word_type;
  typedef boost::uint32_t size_type;

  sha1_ctx();

  sha1_ctx(const sha1_ctx&);
  
  sha1_ctx& operator = (const sha1_ctx&);

  void reset();
  void clear();

  void process_block(const void* msg);
  void store_msg_digest(void* digest) const;
  void store_bit_count(void* dst) const;
  
  void add_to_bit_count(size_type x)
  {
    bit_count.add(x);
  }
  
  unsigned int bytes_in_buf() const
  {
    return bit_count[0] / 8 % block_size;
  }
  
  unsigned int bits_in_buf() const
  {
    return bit_count[0] % block_size;
  }
  
  static word_type rotate_left(word_type x, word_type bits)
  {
    return (x << bits) | (x >> (32 - bits));
  }

  static word_type Ch(word_type x, word_type y, word_type z)
  {
    return (x & y) ^ (~x & z);
  }
  static word_type Parity(word_type x, word_type y, word_type z)
  {
    return x ^ y ^ z;
  }
  static uint32_t Maj(word_type x, word_type y, word_type z)
  {
    return (x & y) ^ (x & z) ^ (y & z);
  }

  union
  {
    struct
    {
      word_type H0, H1, H2, H3, H4;
    };
    word_type H[5];
  };
  bit_count<size_type, 2> bit_count;

  static const word_type init_values[5];
};


} // namespace detail
} // namespace crypto
} // namespace boost

#endif

