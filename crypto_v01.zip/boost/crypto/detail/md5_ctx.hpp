
//          Copyright Kevin Sopp 2007.
// Distributed under the Boost Software License, Version 1.0.
//    (See accompanying file LICENSE_1_0.txt or copy at
//          http://www.boost.org/LICENSE_1_0.txt)

// Implements 'The MD5 Message-Digest Algorithm'
// RFC 1321 http://tools.ietf.org/html/rfc1321


#ifndef BOOST_CRYPTO_DETAIL_MD5_CTX_HPP
#define BOOST_CRYPTO_DETAIL_MD5_CTX_HPP

#include <boost/cstdint.hpp>
#include <boost/crypto/detail/md_utils.hpp>

namespace boost {
namespace crypto {
namespace detail {

struct md5_ctx
{
  static const int digest_length = 16;
  static const int block_size = 64;
  static const int padding_size = 64;
  static const int input_length_size = 8;

  typedef boost::uint8_t  uint8_t;
  typedef boost::uint8_t  element_type;
  typedef boost::uint32_t word_type;
  typedef boost::uint32_t size_type;

  md5_ctx();

  md5_ctx(const md5_ctx&);
  
  md5_ctx& operator = (const md5_ctx&);

  void reset();
  void clear();

  void process_block(const void* msg);

  // auxiliary functions
  struct aux_f
  {
    word_type operator()(word_type x, word_type y, word_type z) const
    { return (x & y)|(~x & z); }
  };
  struct aux_g
  {
    word_type operator()(word_type x, word_type y, word_type z) const
    { return (x & z)|(y & ~z); }
  };
  struct aux_h
  {
    word_type operator()(word_type x, word_type y, word_type z) const
    { return x ^ y ^ z;        }
  };
  struct aux_i
  {
    word_type operator()(word_type x, word_type y, word_type z) const
    { return y ^ (x | ~z);     }
  };

  static word_type left_rotate(word_type x, word_type num_bits)
  {
    return (x << num_bits) | (x >> (32 - num_bits));
  }

  template<typename AuxFunctor>
  static void transform(word_type& a, word_type& b, word_type& c, word_type& d,
                        word_type k, word_type s, word_type i)
  {
    word_type T = b + left_rotate(a + AuxFunctor()(b,c,d) + k + i, s);
    a = d;
    d = c;
    c = b;
    b = T;
  }

  void store_msg_digest(void* digest) const;
  void store_bit_count(void* dst) const;
  
  void add_to_bit_count(size_type x)
  {
    bit_count.add(x);
  }
  
  unsigned int bytes_in_buf() const
  {
    return bit_count[0] / 8 % block_size;
  }
  
  unsigned int bits_in_buf() const
  {
    return bit_count[0] % block_size;
  }
  
  union
  {
    struct
    {
      word_type A, B, C, D;
    };
    word_type state[4];
  };
  bit_count<size_type, 2> bit_count;

  static const word_type init_values[4];
};


} // namespace detail
} // namespace crypto
} // namespace boost

#endif

