
//          Copyright Kevin Sopp 2007.
// Distributed under the Boost Software License, Version 1.0.
//    (See accompanying file LICENSE_1_0.txt or copy at
//          http://www.boost.org/LICENSE_1_0.txt)


#ifndef BOOST_CRYPTO_DETAIL_RIPEMD_CTX_HPP
#define BOOST_CRYPTO_DETAIL_RIPEMD_CTX_HPP

#include <cstring>
#include <boost/cstdint.hpp>
#include <boost/crypto/detail/md_utils.hpp>


namespace boost {
namespace crypto {
namespace detail {

struct ripemd128_base
{
  static const int digest_length = 16;
  static const int state_words = 4;

  typedef boost::uint32_t word_type;

  struct f1
  {
    word_type operator()(word_type x, word_type y, word_type z) const
    { return x ^ y ^ z;        }
  };
  struct f2
  {
    word_type operator()(word_type x, word_type y, word_type z) const
    { return (x & y) | (~x & z); }
  };
  struct f3
  {
    word_type operator()(word_type x, word_type y, word_type z) const
    { return (x | ~y) ^ z;        }
  };
  struct f4
  {
    word_type operator()(word_type x, word_type y, word_type z) const
    { return (x & z) | (y & ~z); }
  };

  static word_type rotate_left(word_type x, word_type num_bits)
  {
    return (x << num_bits) | (x >> (32 - num_bits));
  }

  template<class F>
  static void transform(word_type& a, word_type& b, word_type& c, word_type& d,
                        word_type x, word_type k, word_type s)
  {
    word_type T = rotate_left(a + F()(b, c, d) + x + k, s);
    a = d;
    d = c;
    c = b;
    b = T;
  }

  static void process_block(const void* msg, word_type* h);
  
  static const word_type init_values[4];
};


struct ripemd256_base : ripemd128_base
{
  static const int digest_length = 32;
  static const int state_words = 8;

  static void process_block(const void* msg, word_type* h);

  static const word_type init_values[8];
};


struct ripemd160_base : ripemd128_base
{
  static const int digest_length = 20;
  static const int state_words = 5;

  struct f5
  {
    word_type operator()(word_type x, word_type y, word_type z) const
    { return x ^ (y | ~z);     }
  };

  template<class F>
  static void transform(word_type& a, word_type& b, word_type& c, word_type& d,
                        word_type& e, word_type x, word_type k, word_type s)
  {
    word_type T = rotate_left(a + F()(b, c, d) + x + k, s) + e;
    a = e;
    e = d;
    d = rotate_left(c, 10);
    c = b;
    b = T;
  }

  static void process_block(const void* msg, word_type* h);

  static const word_type init_values[5];
};


struct ripemd320_base : ripemd160_base
{
  static const int digest_length = 40;
  static const int state_words = 10;

  static void process_block(const void* msg, word_type* h);

  static const word_type init_values[10];
};



template<class RipeMDBase>
struct ripemd_ctx
{
  static const int digest_length = RipeMDBase::digest_length;
  static const int block_size = 64;
  static const int padding_size = 64;
  static const int input_length_size = 8;

  typedef boost::uint8_t  uint8_t;
  typedef boost::uint8_t  element_type;
  typedef typename RipeMDBase::word_type word_type;
  typedef boost::uint32_t size_type;

  ripemd_ctx();

  ripemd_ctx(const ripemd_ctx&);
  
  ripemd_ctx& operator = (const ripemd_ctx&);

  void reset();
  void clear();

  void process_block(const void* msg)
  {
    RipeMDBase::process_block(msg, h);
  }

  void store_msg_digest(void* digest) const;
  void store_bit_count(void* dst) const;
  
  void add_to_bit_count(size_type x)
  {
    bit_count.add(x);
  }
  
  unsigned int bytes_in_buf() const
  {
    return bit_count[0] / 8 % block_size;
  }
  
  unsigned int bits_in_buf() const
  {
    return bit_count[0] % block_size;
  }
  
  word_type h[RipeMDBase::state_words];
  bit_count<size_type, 2> bit_count;
};


template<class RipeMDBase>
ripemd_ctx<RipeMDBase>::ripemd_ctx()
{
  std::memcpy(h, RipeMDBase::init_values, sizeof(RipeMDBase::init_values));
}

template<class RipeMDBase>
ripemd_ctx<RipeMDBase>::ripemd_ctx(const ripemd_ctx<RipeMDBase>& copy)
:
  bit_count(copy.bit_count)
{
  std::memcpy(h, copy.h, sizeof(h));
}

template<class RipeMDBase>
ripemd_ctx<RipeMDBase>&
ripemd_ctx<RipeMDBase>::operator = (const ripemd_ctx<RipeMDBase>& rhs)
{
  std::memcpy(h, rhs.h, sizeof(h));
  bit_count = rhs.bit_count;
  return *this;
}

template<class RipeMDBase>
void ripemd_ctx<RipeMDBase>::reset()
{
  std::memcpy(h, RipeMDBase::init_values, sizeof(RipeMDBase::init_values));
  bit_count = 0;
}

template<class RipeMDBase>
void ripemd_ctx<RipeMDBase>::clear()
{
  reset();
}

template<class RipeMDBase>
void ripemd_ctx<RipeMDBase>::store_msg_digest(void* digest) const
{
  native_to_little_endian<word_type>(digest, h, digest_length);
}

template<class RipeMDBase>
void ripemd_ctx<RipeMDBase>::store_bit_count(void* dst) const
{
  bit_count.store_as_little_endian(dst);
}


typedef ripemd_ctx<ripemd128_base> ripemd128_ctx;
typedef ripemd_ctx<ripemd160_base> ripemd160_ctx;

typedef ripemd_ctx<ripemd256_base> ripemd256_ctx;
typedef ripemd_ctx<ripemd320_base> ripemd320_ctx;
 


} // namespace detail
} // namespace crypto
} // namespace boost

#endif

