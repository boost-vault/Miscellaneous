
//          Copyright Kevin Sopp 2007.
// Distributed under the Boost Software License, Version 1.0.
//    (See accompanying file LICENSE_1_0.txt or copy at
//          http://www.boost.org/LICENSE_1_0.txt)

#ifndef BOOST_CRYPTO_RC4_CIPHER_HPP
#define BOOST_CRYPTO_RC4_CIPHER_HPP

#include <cstddef> // size_t
#include <algorithm> // swap

namespace boost {
namespace crypto {

struct rc4_cipher
{
  typedef std::size_t size_type;

  ~rc4_cipher();

  void set_key(const void* key, size_type len);

  void encrypt(const void* in, void* out, size_type len);
  void decrypt(const void* in, void* out, size_type len);

private:

  unsigned char state_[256];
  unsigned char x_, y_;
};


} // namespace crypto
} // namespace boost

#endif

