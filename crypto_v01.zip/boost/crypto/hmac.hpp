
//          Copyright Kevin Sopp 2007.
// Distributed under the Boost Software License, Version 1.0.
//    (See accompanying file LICENSE_1_0.txt or copy at
//          http://www.boost.org/LICENSE_1_0.txt)

#ifndef BOOST_CRYPTO_HMAC_HPP
#define BOOST_CRYPTO_HMAC_HPP

#include <cstring>
#include <ostream>
#include <string>
#include <boost/cstdint.hpp>

namespace boost {
namespace crypto {

template<class Hash>
struct hmac
{
  typedef Hash hash_function;
  typedef typename hash_function::size_type size_type;

  static const int length     = hash_function::digest_length;
  static const int block_size = hash_function::block_size;
  
  hmac()
    : key_was_set_(false)
  {}

  template<typename RandomAccessIterator>
  hmac(
      RandomAccessIterator first,
      RandomAccessIterator last, bool create_key = true)
    :
      key_was_set_(false)  {
    compute(first, last, create_key);
  }

  explicit hmac(const std::string& s, bool create_key = true)
    :
      key_was_set_(false)
  {
    compute(s, create_key);
  }

  explicit hmac(const std::wstring& s, bool create_key = true)
    :
      key_was_set_(false)
  {
    compute(s, create_key);
  }

  template<typename charT, class traits, class alloc>
  explicit hmac(
      const std::basic_string<charT, traits, alloc>& s,
      bool create_key = true)
    :
      key_was_set_(false)
  {
    compute(s, create_key);
  }

  const void* get() const
  {
    return hfinal_.digest();
  }

  std::string to_string() const
  {
    return hfinal_.to_string();
  }

  void set_key(const void* key, size_type keylen);
  
  void compute(const void* in, size_type len, bool create_key = true);
  
  template<typename RandomAccessIterator>
  void compute(
      RandomAccessIterator first,
      RandomAccessIterator last, bool create_key = true)
  {
    compute(&*first, last - first, create_key);
  }
  
  void compute(const std::string& s, bool create_key = true)
  {
    compute(s.begin(), s.end(), create_key);
  }

  void compute(const std::wstring& s, bool create_key = true)
  {
    compute(s.begin(), s.end(), create_key);
  }

  template<typename charT, class traits, class alloc>
  void compute(
      const std::basic_string<charT, traits, alloc>& s,
      bool create_key = true)
  {
    compute(s.begin(), s.end(), create_key);
  }

  void reset()
  {
    key_was_set_ = false;
  }

private:

  hash_function hi_, ho_, hfinal_;
  bool key_was_set_;
};


template<class Hash>
void hmac<Hash>::set_key(const void* key, size_type keylen)
{
  hi_.reset();
  ho_.reset();
  boost::uint8_t ipad[block_size];
  boost::uint8_t opad[block_size];
  if (keylen == (unsigned)block_size)
    std::memcpy(ipad, key, block_size);
  else if (keylen > (unsigned)block_size)
  {
    hfinal_.reset();
    hfinal_.input(key, keylen);
    std::memcpy(ipad, hfinal_.digest(), length);
    std::memset(ipad + length, 0, block_size - length);
  }
  else
  {
    std::memcpy(ipad, key, keylen);
    std::memset(ipad + keylen, 0, block_size - keylen);
  }
  
  std::memcpy(opad, ipad, block_size);
  for (int i = 0; i < block_size; ++i)
  {
    ipad[i] ^= 0x36;
    opad[i] ^= 0x5c;
  }
  // put the two hashes in their start state
  hi_.process_block(ipad);
  ho_.process_block(opad);
  key_was_set_ = true;
}

template<class Hash>
void hmac<Hash>::compute(const void* in, size_type len, bool create_key)
{
  if (!key_was_set_ || create_key)
  {
    boost::uint8_t key[block_size];
    hfinal_.reset();
    hfinal_.process_block(in);
    std::memcpy(key, hfinal_.digest(), length);
    set_key(key, length);
  }
  hash_function h1(hi_);
  h1.input(in, len);
  hfinal_ = ho_;
  hfinal_.input(h1.digest(), length);
}

template<class Hash>
inline bool operator == (const hmac<Hash>& lhs, const hmac<Hash>& rhs)
{
  return !std::memcmp(lhs.digest(), rhs.digest(), Hash::digest_length);
}

template<class Hash>
inline bool operator != (const hmac<Hash>& lhs, const hmac<Hash>& rhs)
{
  return std::memcmp(lhs.digest(), rhs.digest(), Hash::digest_length);
}

template<class Hash>
inline bool operator == (const hmac<Hash>& m, const std::string& digest)
{
  return m.to_string() == digest;
}

template<class Hash>
inline bool operator != (const hmac<Hash>& m, const std::string& digest)
{
  return m.to_string() != digest;
}

template<class Hash>
inline bool operator == (const std::string& digest, const hmac<Hash>& m)
{
  return digest == m.to_string();
}

template<class Hash>
inline bool operator != (const std::string& digest, const hmac<Hash>& m)
{
  return digest != m.to_string();
}

template<typename charT, class traits, class Hash>
inline std::basic_ostream<charT, traits>&
operator << (std::basic_ostream<charT, traits>& out, const hmac<Hash>& m)
{
  return out << m.to_string();
}


} // namespace crypto
} // namespace boost

#endif
