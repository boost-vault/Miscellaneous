
//          Copyright Kevin Sopp 2007.
// Distributed under the Boost Software License, Version 1.0.
//    (See accompanying file LICENSE_1_0.txt or copy at
//          http://www.boost.org/LICENSE_1_0.txt)


#ifndef BOOST_CRYPTO_BLOWFISH_CIPHER_HPP
#define BOOST_CRYPTO_BLOWFISH_CIPHER_HPP

#include <boost/cstdint.hpp>

namespace boost {
namespace crypto {

struct blowfish_cipher
{
  typedef unsigned int size_type;

  static const int block_size = 64;

  ~blowfish_cipher();

  void set_key(const void* key, size_type len);
  void encrypt_block(const void* in, void* out);
  void decrypt_block(const void* in, void* out);

private:

  typedef boost::uint8_t  uint8_t;
  typedef boost::uint32_t word_type;

  static const int rounds = 16;

  word_type F(word_type x) const
  {// TODO store_as_big_endian<word_type>(abcd, &x, 4);
    uint8_t a = x >> 24;
    uint8_t b = x >> 16;
    uint8_t c = x >>  8;
    uint8_t d = x;
    return ((S[0][a] + S[1][b]) ^ S[2][c]) + S[3][d];
  }

  word_type P[rounds + 2];
  word_type S[4][256];

  static const word_type P_iv[rounds + 2];
  static const word_type S_iv[4][256];
};


} // namespace crypto
} // namespace boost

#endif

