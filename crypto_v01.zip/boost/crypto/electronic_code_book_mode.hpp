
//          Copyright Kevin Sopp 2007.
// Distributed under the Boost Software License, Version 1.0.
//    (See accompanying file LICENSE_1_0.txt or copy at
//          http://www.boost.org/LICENSE_1_0.txt)


#ifndef BOOST_CRYPTO_ELECTRONIC_CODE_BOOK_MODE_HPP
#define BOOST_CRYPTO_ELECTRONIC_CODE_BOOK_MODE_HPP

#include <cstring>

namespace boost {
namespace crypto {
  
// Electronic Code Book Mode (ECB)
template<class Cipher, class Padding>
struct electronic_code_book_mode_impl
{
  typedef std::size_t size_type;
  typedef Cipher      cipher_type;
  typedef Padding     padding_strategy;

  void set_key(const void* key, size_type len)
  {
    c_.set_key(key, len);
  }
  
  void encrypt(const void* in, void* out, size_type inlen);
  
  void decrypt(const void* in, void* out, size_type inlen);

  size_type required_output_size(size_type inputlen) const
  {
    return pad_.required_output_size(inputlen, block_size);
  }
  
  cipher_type&       cipher()       { return c_; }
  const cipher_type& cipher() const { return c_; }
  
  static const unsigned int key_length = cipher_type::key_length / 8;
  static const unsigned int block_size = cipher_type::block_size / 8;

private:

  cipher_type      c_;
  padding_strategy pad_;
};


template<class Cipher, class Padding>
void electronic_code_book_mode_impl<Cipher, Padding>::encrypt(
    const void* vin, void* vout, size_type len)
{
  const unsigned char* in = static_cast<const unsigned char*>(vin);
  unsigned char* out = static_cast<unsigned char*>(vout);
  while (len >= block_size)
  {
    c_.encrypt_block(in, out);
    in  += block_size;
    out += block_size;
    len -= block_size;
  }
  const size_type rem = len % block_size;
  if (rem || pad_.always_pad())
  {
    unsigned char block[block_size];
    std::memcpy(block, in, rem);
    pad_.pad(block, block_size, rem);
    c_.encrypt_block(block, out);
  }
}

template<class Cipher, class Padding>
void electronic_code_book_mode_impl<Cipher, Padding>::decrypt(
    const void* vin, void* vout, size_type len)
{
  const unsigned char* in = static_cast<const unsigned char*>(vin);
  unsigned char* out = static_cast<unsigned char*>(vout);
  while (len >= block_size)
  {
    c_.decrypt_block(in, out);
    in  += block_size;
    out += block_size;
    len -= block_size;
  }
  const size_type rem = len % block_size;
  if (rem || pad_.always_pad())
  {
    unsigned char block[block_size];
    c_.decrypt_block(in, block);
    std::memcpy(out, block, rem);
  }
}


struct electronic_code_book_mode
{
  template<class Cipher, class Padding>
  struct bind
  {
    typedef electronic_code_book_mode_impl<Cipher, Padding> type;
  };
};

typedef electronic_code_book_mode ecb_mode;


} // namespace crypto
} // namespace boost

#endif

