
//          Copyright Kevin Sopp 2007.
// Distributed under the Boost Software License, Version 1.0.
//    (See accompanying file LICENSE_1_0.txt or copy at
//          http://www.boost.org/LICENSE_1_0.txt)


#ifndef BOOST_CRYPTO_CIPHER_BLOCK_CHAINING_MODE_HPP
#define BOOST_CRYPTO_CIPHER_BLOCK_CHAINING_MODE_HPP

#include <cstring>

namespace boost {
namespace crypto {
  
// Cipher Block Chaining Mode (CBC)
// xors previous cipher text with current plaintext before encryption
template<class Cipher, class Padding>
struct cipher_block_chaining_mode_impl
{
  typedef std::size_t size_type;
  typedef Cipher      cipher_type;
  typedef Padding     padding_strategy;

  void set_key(const void* key, size_type len)
  {
    c_.set_key(key, len);
  }
  void encrypt(const void* iv, const void* in, void* out, size_type inlen);
  void decrypt(const void* iv, const void* in, void* out, size_type inlen);

  size_type required_output_size(size_type inputlen) const
  {
    return pad_.required_output_size(inputlen, block_size);
  }

  static const unsigned int key_length = cipher_type::key_length / 8;
  static const unsigned int block_size = cipher_type::block_size / 8;

private:

  static void xor_combine(void* dst, const void* src1, const void* src2)
  {
    if (block_size % sizeof(int) == 0)
      for (unsigned int i = 0; i < block_size / sizeof(int); ++i)
        static_cast<int*>(dst)[i] = static_cast<const int*>(src1)[i]
                                  ^ static_cast<const int*>(src2)[i];
    else
      for (unsigned int i = 0; i < block_size; ++i)
        static_cast<char*>(dst)[i] = static_cast<const char*>(src1)[i]
                                   ^ static_cast<const char*>(src2)[i];
  }

  cipher_type      c_;
  padding_strategy pad_;
};

template<class Cipher, class Padding>
const unsigned int cipher_block_chaining_mode_impl<Cipher, Padding>::block_size;


template<class Cipher, class Padding>
void cipher_block_chaining_mode_impl<Cipher, Padding>::encrypt(
    const void* iv, const void* vin, void* vout, size_type len)
{
  const char* in = static_cast<const char*>(vin);
  char* out = static_cast<char*>(vout); 
  char block[block_size];
  const bool len_ge_block = len >= block_size;
  if (len_ge_block)
  {
    xor_combine(block, in, iv);
    c_.encrypt_block(block, out);
    in  += block_size;
    out += block_size;
    len -= block_size;
  
    while (len >= block_size)
    {
      xor_combine(block, block, in);
      c_.encrypt_block(block, out);
      in  += block_size;
      out += block_size;
      len -= block_size;
    }
  }
  
  const size_type rem = len % block_size;
  if (rem || pad_.always_pad())
  {
    char padbuffer[block_size];
    std::memcpy(padbuffer, in, rem);
    pad_.pad(padbuffer, block_size, rem);
    if (!len_ge_block)
    {
      xor_combine(block, padbuffer, iv);
      c_.encrypt_block(block, out);
    }
    else
    {
      xor_combine(block, block, padbuffer);
      c_.encrypt_block(block, out);
    }
  }
}

template<class Cipher, class Padding>
void cipher_block_chaining_mode_impl<Cipher, Padding>::decrypt(
    const void* iv, const void* vin, void* vout, size_type len)
{
  if (!len)
    return;
  const char* in = static_cast<const char*>(vin);
  char* out = static_cast<char*>(vout);
  const bool len_ge_block = len >= block_size;
  const size_type rem = len % block_size;
  if (len_ge_block || (!rem && pad_.always_pad())) // we have at least one block
  {
    const char* prev_block = in;
    c_.decrypt_block(in, out);
    xor_combine(out, out, iv);
    in  += block_size;
    out += block_size;
    len -= block_size;
    
    while (len >= block_size)
    {
      c_.decrypt_block(in, out);
      xor_combine(out, out, prev_block);
      prev_block = out;
      in  += block_size;
      out += block_size;
      len -= block_size;
    }
  }
  // handle last block
  if (!rem) // does last block consist only of padding?
    return;
  char tmp_out[block_size];
  const size_type bytes_to_copy = rem ? rem : block_size;
  c_.decrypt_block(in, tmp_out);
  xor_combine(tmp_out, tmp_out, iv);
  std::memcpy(out, tmp_out, bytes_to_copy);
}


struct cipher_block_chaining_mode
{
  template<class Cipher, class Padding>
  struct bind
  {
    typedef cipher_block_chaining_mode_impl<Cipher, Padding> type;
  };
};

typedef cipher_block_chaining_mode cbc_mode;


} // namespace crypto
} // namespace boost

#endif

