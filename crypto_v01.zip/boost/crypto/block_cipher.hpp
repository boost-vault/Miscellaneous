
//          Copyright Kevin Sopp 2007.
// Distributed under the Boost Software License, Version 1.0.
//    (See accompanying file LICENSE_1_0.txt or copy at
//          http://www.boost.org/LICENSE_1_0.txt)


#ifndef BOOST_CRYPTO_BLOCK_CIPHER_HPP
#define BOOST_CRYPTO_BLOCK_CIPHER_HPP

#include <limits>
#include <stdexcept>

namespace boost {
namespace crypto {


struct zero_padding
{
  typedef std::size_t size_type;

  static bool always_pad() { return false; }
  static size_type required_output_size(size_type len, size_type block_size)
  {
    if (len)
    {
      const size_type rem = len % block_size;
      if (rem)
      {
        if (std::numeric_limits<size_type>::max() - len < block_size)
          throw std::overflow_error("message length is too long");
        else
          return len - rem + block_size;
      }
    }
    return len;
  }

  static void pad(void* block, size_type block_size, size_type bytes_in_block)
  {
    char* ptr = static_cast<char*>(block);
    std::memset(ptr + bytes_in_block, 0, block_size - bytes_in_block);
  }
};


// 0x80 0x00 0x00 ....
struct one_and_zeros_padding
{
  typedef std::size_t size_type;

  static bool always_pad() { return true; }
  
  static size_type required_output_size(size_type len, size_type block_size)
  {
    if (len)
    {
      const size_type rem = len % block_size;
      if (rem)
      {
        if (std::numeric_limits<size_type>::max() - len < block_size)
          throw std::overflow_error("message length is too long");
        else
          return len - rem + block_size;
      }
    }
    return len + block_size;
  }

  static void pad(void* block, size_type block_size, size_type bytes_in_block)
  {
    unsigned char* ptr = static_cast<unsigned char*>(block);
    ptr += bytes_in_block;
    *ptr++ = 0x80;
    ++bytes_in_block;
    std::memset(ptr, 0, block_size - bytes_in_block);
  }
}; 


struct trailing_bit{};

struct pkcs7_padding
{
/*RFC 2315 (10.3.2)
Some content-encryption algorithms assume the
input length is a multiple of k octets, where k > 1, and
let the application define a method for handling inputs
whose lengths are not a multiple of k octets. For such
algorithms, the method shall be to pad the input at the
trailing end with k - (l mod k) octets all having value k -
(l mod k), where l is the length of the input. In other
words, the input is padded at the trailing end with one of
the following strings:

         01 -- if l mod k = k-1
        02 02 -- if l mod k = k-2
                    .
                    .
                    .
      k k ... k k -- if l mod k = 0

The padding can be removed unambiguously since all input is
padded and no padding string is a suffix of another. This
padding method is well-defined if and only if k < 256;
methods for larger k are an open issue for further study.*/
};


template<class Cipher, class Mode, class Padding>
struct block_cipher : Mode::template bind<Cipher, Padding>::type
{
  typedef std::size_t size_type;
  typedef Cipher      cipher_type;
  typedef Mode        mode_type;
  typedef Padding     padding_strategy;
};


} // namespace crypto
} // namespace boost

#endif

