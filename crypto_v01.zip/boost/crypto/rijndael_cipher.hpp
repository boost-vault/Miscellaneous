
//          Copyright Kevin Sopp 2007.
// Distributed under the Boost Software License, Version 1.0.
//    (See accompanying file LICENSE_1_0.txt or copy at
//          http://www.boost.org/LICENSE_1_0.txt)


#ifndef BOOST_CRYPTO_RIJNDAEL_CIPHER_HPP
#define BOOST_CRYPTO_RIJNDAEL_CIPHER_HPP

#include <cstring>
#include <boost/cstdint.hpp>
#include <boost/static_assert.hpp>

// Advanced Encryption Standard FIPS 197


namespace boost {
namespace crypto {

namespace detail {

struct rijndael_tables
{
  static const boost::uint8_t log_     [256];
  static const boost::uint8_t pow_     [256];
  static const boost::uint8_t sbox_    [256];
  static const boost::uint8_t inv_sbox_[256];
  static const boost::uint8_t mm_      [ 16]; // mix column matrix
  static const boost::uint8_t inv_mm_  [ 16];
  static const boost::uint32_t rcon_   [ 30];
};

} // namespace detail


template<
  int K, // key length in bits
  int B  // block size in bits
>
struct rijndael_cipher : private detail::rijndael_tables
{
  BOOST_STATIC_ASSERT(K >= 128 && K <= 256 && K % 32 == 0);
  BOOST_STATIC_ASSERT(B >= 128 && B <= 256 && B % 32 == 0);

  static const int key_length = K;
  static const int block_size = B;

  ~rijndael_cipher();

  void set_key(const void* key, unsigned int len = K / 8)
  {
    expand_key(key);
  }
  void encrypt_block(const void* in, void* out);
  void decrypt_block(const void* in, void* out);

private:

  typedef boost::uint32_t word_type;

  static const int Nk = K / 32;
  static const int Nb = B / 32;
  static const int Nr = (Nk > Nb ? Nk : Nb) + 6;
  static const int round_key_length = Nb * (Nr + 1);
  static const int shift_offsets[3];
  static const int inv_shift_offsets[3];

  word_type w_[round_key_length]; // the expanded key buffer

  void apply_round(int              round,
                   uint8_t*         state,
                   const word_type* w,
                   const uint8_t*   sbox,
                   const int*       offsets,
                   const uint8_t*   mm) const;
  
  void sub_bytes(uint8_t* state, const uint8_t* sbox) const;
  void shift_rows(uint8_t* state, const int* offsets) const;
  void mix_columns(uint8_t* state, const uint8_t* matrix) const;
  void add_round_key(uint8_t* state, const word_type* round_key) const;

  void expand_key(const void* key);

  uint8_t mul(uint8_t x, uint8_t y) const
  {
	  if (x && y) return pow_[(log_[x] + log_[y]) % 255];
	  else return 0;
  }

  static word_type sub_word(const uint8_t* sbox, word_type x)
  {
    uint8_t* y = reinterpret_cast<uint8_t*>(&x);
    for (int i = 0; i < 4; ++i)
      y[i] = sbox[y[i]];
    return x;
  }

  static word_type rotate_left(word_type x)
  {
    uint8_t c;
    c = reinterpret_cast<uint8_t*>(&x)[0];
    for (int i = 0; i < 3; i++)
        reinterpret_cast<uint8_t*>(&x)[i] = reinterpret_cast<uint8_t*>(&x)[i+1];
    reinterpret_cast<uint8_t*>(&x)[3] = c;
    return x;
  }
};


template<int K, int B>
const int rijndael_cipher<K, B>::shift_offsets[3] =
{
  1,
  Nb == 8 ? 3 : 2,
  Nb > 6 ? 4 : 3
};

template<int K, int B>
const int rijndael_cipher<K, B>::inv_shift_offsets[3] =
{
  Nb - 1,
  Nb == 8 ? 5 : Nb - 2,
  Nb == 8 ? 4 : Nb == 7 ? 3 : Nb - 3
};

template<int K, int B>
rijndael_cipher<K, B>::~rijndael_cipher()
{
  std::memset(w_, 0, sizeof(w_));
}

template<int K, int B>
void rijndael_cipher<K, B>::apply_round(int round,
                                        uint8_t* state,
                                        const word_type* w,
                                        const uint8_t* sbox,
                                        const int* offsets,
                                        const uint8_t* mm) const
{
  sub_bytes(state, sbox);         
  shift_rows(state, offsets);     
  mix_columns(state, mm); 
  add_round_key(state, w + round * Nb);
}

template<int K, int B>
void rijndael_cipher<K, B>::encrypt_block(const void* vin, void* vout)
{
  uint8_t state[4 * Nb];
  std::memcpy(state, vin, 4 * Nb);
  
  add_round_key(state, w_);

  for (int round = 1; round < Nr; ++round)
    apply_round(round, state, w_, sbox_, shift_offsets, mm_);

  sub_bytes(state, sbox_);
  shift_rows(state, shift_offsets);
  add_round_key(state, w_ + Nr * Nb);
  
  std::memcpy(vout, state, 4 * Nb);
}

template<int K, int B>
void rijndael_cipher<K, B>::decrypt_block(const void* vin, void* vout)
{
  uint8_t state[4 * Nb];
  std::memcpy(state, vin, 4 * Nb);

  word_type w[round_key_length];
  std::memcpy(w, w_, sizeof(w));

  for (int round = 1; round < Nr; ++round)
  {
    uint8_t* s = reinterpret_cast<uint8_t*>(w + round * Nb);
    mix_columns(s, inv_mm_);
  }

  add_round_key(state, w + Nr * Nb);

  for (int round = Nr - 1; round > 0; --round)
    apply_round(round, state, w, inv_sbox_, inv_shift_offsets, inv_mm_);

  sub_bytes(state, inv_sbox_);
  shift_rows(state, inv_shift_offsets);
  add_round_key(state, w);

  std::memcpy(vout, state, 4 * Nb);
}


template<int K, int B>
void rijndael_cipher<K, B>::sub_bytes(
    uint8_t* state, const uint8_t* sbox) const
{
  for (int i = 0; i < 4 * Nb; ++i)
    state[i] = sbox[state[i]];
}

template<int K, int B>
void rijndael_cipher<K, B>::shift_rows(
    uint8_t* state, const int* offset) const
{
  uint8_t tmp[Nb];
  // row 0 never gets shifted
  for (int row = 1; row < 4; ++row)
  {
    const int off = offset[row - 1];
    int i = 0;
    for (; i < off; ++i)
      tmp[i] = state[i * 4 + row];
    for (i = 0; i < Nb - 1; ++i)
      state[i * 4 + row] = state[(i + off) * 4 + row];
    for (i = 0; i < off; ++i)
      state[(Nb - 1 - i) * 4 + row] = tmp[off - 1 - i];
  }
}

template<int K, int B>
void rijndael_cipher<K, B>::mix_columns(uint8_t* state, const uint8_t* mm) const
{
  uint8_t tmp[4 * Nb] = {0};

  for (int col = 0; col < Nb; ++col)
    for (int row = 0; row < 4; ++row)
      for (int k = 0; k < 4; ++k)
        tmp[col * 4 + row] ^= mul(mm[row * 4 + k], state[col * 4 + k]);

  std::memcpy(state, tmp, 4 * Nb);
}

template<int K, int B>
void rijndael_cipher<K, B>::add_round_key(
    uint8_t* state, const word_type* round_key) const
{
  for (int i = 0; i < Nb * 4; ++i)
    state[i] ^= reinterpret_cast<const uint8_t*>(round_key)[i];
}

template<int K, int B>
void rijndael_cipher<K, B>::expand_key(const void* vkey)
{
  const uint8_t* key = static_cast<const uint8_t*>(vkey);

  // the first Nk words are the original key
  std::memcpy(w_, key, Nk * 4);

  for (int i = 0; i < Nk; ++i)
    w_[i] = key[4*i] | key[4*i+1] << 8 | key[4*i+2] << 16 | key[4*i+3] << 24;

  for (int i = Nk; i < round_key_length; ++i)
  {
    word_type tmp = w_[i - 1];
    if (i % Nk == 0)
      tmp = sub_word(sbox_, rotate_left(tmp)) ^ rcon_[i / Nk - 1];
    else if (Nk > 6 && i % Nk == 4)
      tmp = sub_word(sbox_, tmp);
    w_[i] = w_[i - Nk] ^ tmp;
  }
}


typedef rijndael_cipher<128, 128> aes128_cipher;
typedef rijndael_cipher<192, 128> aes192_cipher;
typedef rijndael_cipher<256, 128> aes256_cipher;


} // namespace crypto
} // namespace boost


#endif

