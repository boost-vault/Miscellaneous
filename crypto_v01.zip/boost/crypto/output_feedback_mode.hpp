
//          Copyright Kevin Sopp 2007.
// Distributed under the Boost Software License, Version 1.0.
//    (See accompanying file LICENSE_1_0.txt or copy at
//          http://www.boost.org/LICENSE_1_0.txt)


#ifndef BOOST_CRYPTO_OUTPUT_FEEDBACK_MODE_HPP
#define BOOST_CRYPTO_OUTPUT_FEEDBACK_MODE_HPP

#include <cstring>

namespace boost {
namespace crypto {
  
// Output Feedback Mode (OFB)
template<class Cipher>
struct output_feedback_mode
{
  typedef std::size_t size_type;

  ~output_feedback_mode()
  {
    std::memset(iv_, 0, bufsize * sizeof(int));
    std::memset(buf_, 0, bufsize * sizeof(int));
  }

  void encrypt(const void* key,
               const void* iv,
               const void* in, void* out, size_type len);

  void set_initialization_vector(const void* i)
  {
    std::memcpy(iv_, i, bufsize * sizeof(int));
  }

  void*       get_initialization_vector()       { return iv_; }
  const void* get_initialization_vector() const { return iv_; }

private:

  static const int bufsize = B / sizeof(int);
  const int iv_[bufsize];
  int buf_[bufsize];
};


template<class Cipher>
void output_feedback_mode::encrypt(
    const void* key, const void* iv, const void* in, void* out, size_type len)
{
  c_.encrypt(key, iv_, buf_);
  while (len > 0)
  {
    buf_[i] ^= in[i];
    std::memcpy(out, buf_, bufsize);
    c_.encrypt(key, buf_, buf_);
    in += block_size;
    out += block_size;
    len -= block_size;
  }
}

template<class Cipher>
void output_feedback_mode::decrypt(
    const void* key, const void* iv, const void* in, void* out, size_type len)
{
}


} // namespace crypto
} // namespace boost

#endif

