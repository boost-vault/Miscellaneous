// Test to show 1-bit errors in writing out a double
// as decimal digit string and reading back in.
// The strings output are correct,
// but a small, but significant, fraction are one bit greater when read back.

// All tests use 17 decimal digits,
// enough to ensure that all possibly significant digits are used.
// See for details:
// http://www2.open-std.org/JTC1/SC22/WG21/docs/papers/2005/n1822.pdf

// This causes trouble using Boost.lexical_cast and Boost.serialization,
// two very widely used features of Boost, both within Boost,
// and very commonly in user code.

// The original value causing trouble using serialization was 0.00019075645054089487;
// wrote 0.0019075645054089487  read  0.0019075645054089489
// a increase of just 1 bit.

// Althougth this test uses a std::stringstream, it is possible that
// the same behaviour will be found with ALL streams, including cout and cin?

// The wrong inputs are only found in a very narrow range of values:
// approximately 0.0001 to 0.004, with exponent values of 3f2 to 3f6
// and probably every third value of significand (tested using nextafter).

// The crude first test below creates a vaguely random selection of double values
// by using rand to fill both the significand and exponent.
// Only positive, finite, normalized values are used.

// A second test allows estimation of the range and frequency of errors
// using nextafter, showing that about 1/3 third of significand values 
// in the range 0.0001 to 0.003894 are input wrongly.

// The sample output below is with MSVC 8.0 and is similar in release and debug.

// Murphy's law, of course, applies as numbers in this range are very probable!

// It is, of course, not possible to test ALL values in the range of doubles
// within the lifetime of many in computing ;-)

// (Unlike floats where an exhaustive test is possible - see
// http://lab.msdn.microsoft.com/productfeedback/viewfeedback.aspx?feedbackid=7bf2f26d-171f-41fe-be05-4169a54eef9e
// aka http://tinyurl.com/mpk72
// happily for MSVC.net 8.0 final, ALL possible float values are now correct).

// Copyright Paul A. Bristow 1998-2006. pbristow@hetp.u-net.com

// Distributed under the Boost Software License, Version 1.0.
// (See accompanying file LICENSE_1_0.txt
// or copy at http://www.boost.org/LICENSE_1_0.txt)

#include <iostream>
	using std::cout;
	using std::endl;
	using std::ends;
	using std::hex;
	using std::dec;
	using std::showpoint;
	using std::scientific;
	using std::ios_base;
#include <string>
	using std::string;
#include <sstream>
#include <iomanip>
	using std::setw;
	using std::setprecision;
#include <limits>
	using std::numeric_limits;
#include <cassert>

#include <time.h> // Used as seed for rand().
// srand( (unsigned)time( NULL ) );

#define nextafter _nextafter
	// Used to provide  double successors, 1 bit greater.

union dull
{ // Used to enable output of double in hex.
	// Assume unsigned long long is big enough to hold a double.
	// How to check this is true? Better than nothing is:
	// assert(numeric_limits<double>::digits <= numeric_limits<unsigned long long>::digits);
	double d;
	unsigned long long u;
};

int main()
{
	assert(numeric_limits<double>::digits <= numeric_limits<unsigned long long>::digits);
	{ // Test 1
	int fail_count = 0;
	int test_count = 1000000; // Greater values will find the range of 'wrong' values more accurately.
	// but of course, may take much longer, 10000000?
  double output_value = 0.; // Current value to output to string as decimal digits.
	double wrongmax =numeric_limits<double>::min(); // To hold the range of 'wrong' values.
	double wrongmin = numeric_limits<double>::max();
	srand( (unsigned)time( NULL ) ); // 'random' seed for rand.
	cout.fill('0'); 	cout << showpoint << endl; // Show trailing zeros.
	std::cout << std::setprecision(2 + std::numeric_limits<double>::digits * 301/1000);
	// Show all potentially significant decimal digits max_digits10 (17 for double)

	for (int i = 0; i < test_count; i++)
	{
		dull z;
		do
		{ // Generate 52 random-ish significand bits.
			z.u = rand();
			z.u <<= 15;
			z.u += rand();
			z.u <<= 15;
			z.u += rand();
			z.u <<= 15;
			z.u += rand();
			z.u &= 0x000FFFFFFFFFFFFF; // Clear any excess significand bits.
			unsigned long long randexp = unsigned long long(((double) rand() / (double) 0x7FE) * 0x7FE + 1);
			// 11 exponent bits, range 1 to 0x7FE, for positive denormalized.
			//randexp = 0x3f2; // to test a particular exponent. 3f3, 3f4, 3f5 & 3f6 are wrongly read, covering a tenfold range. 
			randexp <<= 52;
			randexp &= 0x7FE0000000000000; // Normalized doubles only.
			// cout << hex << randexp << endl; // look random-ish.
			z.u += randexp;
			output_value = z.d;
		}
		while(!_finite(output_value)); // Reject any infinite or NaN.
		// cout << output_value << ' ' << hex << z.u << endl;

    std::stringstream stream;
		stream.precision(2 + std::numeric_limits<double>::digits * 301/1000);
		// 17 digits the maxiumum number that are significant.
		stream << output_value; //  << ends; // ends doesn't seem to have any effect.
		// stream << scientific << output_value; //  No 'wrong' values!
		double read_value;
		stream >> read_value;
		//cout << stream.str() << endl; // Output is as expected.

		if (read_value == output_value)
		{
			// std::cout << "Matched OK." << std::endl;
		}
		else
		{ // (read_value != output_value)
			cout << "Written  : " << showpoint << setw(21) << output_value << " == " << hex << z.u << std::endl;
			// cout << stream.str() << endl; == Written.
			z.d = read_value;
			cout << "Readback : " << showpoint << setw(21) << read_value << " == " << hex << z.u << std::endl;

			if(output_value > wrongmax)
			{ // Update the bounds of wrong values.
				wrongmax = output_value;
			}
			if(output_value < wrongmin)
			{
				wrongmin = output_value;
			}
			fail_count++;
		}
	} // for i

	std::cout << dec << "failed "<< fail_count << ", out of " << test_count << ", fraction " << double(fail_count)/test_count << endl;
	dull z; // Used to output double in hex.
	z.d = wrongmin;
	cout << "\n""wrong min " << wrongmin << " == " << hex << z.u;
	z.d = wrongmax;
	cout << "\n""wrong max " << wrongmax << " == " << hex << z.u << endl;

	cout << std::setprecision(2 + std::numeric_limits<double>::digits * 301/1000);
	} // test 1
	
	{ // Test 2
		// Start with a known 'wrong' value and try many successors in turn.

		int fail_count = 0;
		int test_count = 100; // Number of successors to try.
		double output_value = 0.00010000433948393407;
		// Seems to fail in range 0.0001 upto 0.00389.
		// Values can be chosen from the 1st test above.
		//output_value = 0.00016744234964967723;
		output_value = 0.0035648982583969379;
		cout << "\n""Initial output_value " << output_value << endl;
		for (int i = 0; i < test_count; i++)
		{
			std::stringstream stream;
			stream << std::setprecision(2 + std::numeric_limits<double>::digits * 301/1000);
			stream << output_value; // Write out.
			double read_value;
			stream >> read_value; // Read back.

			if (read_value == output_value)
			{
				// std::cout << "Matched OK." << std::endl;
			}
			else
			{ // (read_value != output_value)
				dull z; // Used to output double in hex.
				z.d = output_value;
				cout << "Written  : " << setw(22) << output_value << " == " << hex << z.u << endl;
				z.d = read_value;
				cout << "Readback : " << setw(22) << read_value << " == " << hex << z.u << endl;
				fail_count++;
		}
			output_value = nextafter(output_value, 999999.9);
			// Or can increment by a (much) bigger factor using some multiplier.
			// output_value *= 1.00001;
		} // for i
		cout << "Final output_value " << output_value<< endl;
		cout << dec << "failed "<< fail_count << ", out of " << test_count << endl;
	} // test 2
	return 0;
} // int main()

/*

Output is:

VS 8.0

------ Build started: Project: loopback, Configuration: Debug Win32 ------
Compiling...
loopback.cpp
Linking...
Autorun "j:\Cpp\Misc\debug\loopback.exe"
Written  : 0.00066175593541162531 == 3f45af360cde1014
Readback : 0.00066175593541162542 == 3f45af360cde1015
Written  : 0.00016941141438867686 == 3f263480f7ff24ec
Readback : 0.00016941141438867684 == 3f263480f7ff24eb
Written  : 0.0036031536309378063 == 3f6d845c603c244f
Readback : 0.0036031536309378059 == 3f6d845c603c244e
Written  : 0.00075035710771420843 == 3f4896739e754419
Readback : 0.00075035710771420854 == 3f4896739e75441a
Written  : 0.00088761636587447203 == 3f4d15dda1a441cf
Readback : 0.00088761636587447214 == 3f4d15dda1a441d0
Written  : 0.00090462587760668344 == 3f4da48d479b9957
Readback : 0.00090462587760668334 == 3f4da48d479b9956
Written  : 0.0032629130440311603 == 3f6abad31a0ab221
Readback : 0.0032629130440311608 == 3f6abad31a0ab222
Written  : 0.00093249086349645957 == 3f4e8e4ce19ac861
Readback : 0.00093249086349645968 == 3f4e8e4ce19ac862
Written  : 0.0032945183786353663 == 3f6afd1b162766f9
Readback : 0.0032945183786353667 == 3f6afd1b162766fa
failed 9, out of 10000, fraction 0.00089999999999999998
wrong min 0.00016941141438867686 == 3f263480f7ff24ec
wrong max 0.0036031536309378063 == 3f6d845c603c244f
Initial output_value 0.0035648982583969379
Written  : 00.0035648982583969379 == 3f6d34222dde445c
Readback : 00.0035648982583969383 == 3f6d34222dde445d
Written  : 00.0035648982583969392 == 3f6d34222dde445f
Readback : 00.0035648982583969388 == 3f6d34222dde445e
Written  : 00.0035648982583969401 == 3f6d34222dde4461
Readback : 00.0035648982583969405 == 3f6d34222dde4462
Written  : 00.0035648982583969414 == 3f6d34222dde4464
Readback : 00.0035648982583969418 == 3f6d34222dde4465
Written  : 00.0035648982583969427 == 3f6d34222dde4467
Readback : 00.0035648982583969422 == 3f6d34222dde4466
Written  : 00.0035648982583969435 == 3f6d34222dde4469
Readback : 00.0035648982583969440 == 3f6d34222dde446a
Written  : 00.0035648982583969448 == 3f6d34222dde446c
Readback : 00.0035648982583969444 == 3f6d34222dde446b
Written  : 00.0035648982583969461 == 3f6d34222dde446f
Readback : 00.0035648982583969457 == 3f6d34222dde446e
Written  : 00.0035648982583969470 == 3f6d34222dde4471
Readback : 00.0035648982583969474 == 3f6d34222dde4472
Written  : 00.0035648982583969483 == 3f6d34222dde4474
Readback : 00.0035648982583969479 == 3f6d34222dde4473
Written  : 00.0035648982583969496 == 3f6d34222dde4477
Readback : 00.0035648982583969492 == 3f6d34222dde4476
Written  : 00.0035648982583969505 == 3f6d34222dde4479
Readback : 00.0035648982583969509 == 3f6d34222dde447a
Written  : 00.0035648982583969518 == 3f6d34222dde447c
Readback : 00.0035648982583969522 == 3f6d34222dde447d
Written  : 00.0035648982583969531 == 3f6d34222dde447f
Readback : 00.0035648982583969526 == 3f6d34222dde447e
Written  : 00.0035648982583969539 == 3f6d34222dde4481
Readback : 00.0035648982583969544 == 3f6d34222dde4482
Written  : 00.0035648982583969552 == 3f6d34222dde4484
Readback : 00.0035648982583969548 == 3f6d34222dde4483
Written  : 00.0035648982583969565 == 3f6d34222dde4487
Readback : 00.0035648982583969561 == 3f6d34222dde4486
Written  : 00.0035648982583969574 == 3f6d34222dde4489
Readback : 00.0035648982583969578 == 3f6d34222dde448a
Written  : 00.0035648982583969587 == 3f6d34222dde448c
Readback : 00.0035648982583969583 == 3f6d34222dde448b
Written  : 00.0035648982583969600 == 3f6d34222dde448f
Readback : 00.0035648982583969596 == 3f6d34222dde448e
Written  : 00.0035648982583969609 == 3f6d34222dde4491
Readback : 00.0035648982583969613 == 3f6d34222dde4492
Written  : 00.0035648982583969622 == 3f6d34222dde4494
Readback : 00.0035648982583969626 == 3f6d34222dde4495
Written  : 00.0035648982583969635 == 3f6d34222dde4497
Readback : 00.0035648982583969631 == 3f6d34222dde4496
Written  : 00.0035648982583969644 == 3f6d34222dde4499
Readback : 00.0035648982583969648 == 3f6d34222dde449a
Written  : 00.0035648982583969657 == 3f6d34222dde449c
Readback : 00.0035648982583969661 == 3f6d34222dde449d
Written  : 00.0035648982583969670 == 3f6d34222dde449f
Readback : 00.0035648982583969665 == 3f6d34222dde449e
Written  : 00.0035648982583969678 == 3f6d34222dde44a1
Readback : 00.0035648982583969683 == 3f6d34222dde44a2
Written  : 00.0035648982583969691 == 3f6d34222dde44a4
Readback : 00.0035648982583969687 == 3f6d34222dde44a3
Written  : 00.0035648982583969704 == 3f6d34222dde44a7
Readback : 00.0035648982583969700 == 3f6d34222dde44a6
Written  : 00.0035648982583969713 == 3f6d34222dde44a9
Readback : 00.0035648982583969717 == 3f6d34222dde44aa
Written  : 00.0035648982583969726 == 3f6d34222dde44ac
Readback : 00.0035648982583969730 == 3f6d34222dde44ad
Written  : 00.0035648982583969739 == 3f6d34222dde44af
Readback : 00.0035648982583969735 == 3f6d34222dde44ae
Written  : 00.0035648982583969748 == 3f6d34222dde44b1
Readback : 00.0035648982583969752 == 3f6d34222dde44b2
Written  : 00.0035648982583969761 == 3f6d34222dde44b4
Readback : 00.0035648982583969765 == 3f6d34222dde44b5
Written  : 00.0035648982583969774 == 3f6d34222dde44b7
Readback : 00.0035648982583969769 == 3f6d34222dde44b6
Written  : 00.0035648982583969782 == 3f6d34222dde44b9
Readback : 00.0035648982583969787 == 3f6d34222dde44ba
Written  : 00.0035648982583969795 == 3f6d34222dde44bc
Readback : 00.0035648982583969791 == 3f6d34222dde44bb
Written  : 00.0035648982583969808 == 3f6d34222dde44bf
Readback : 00.0035648982583969804 == 3f6d34222dde44be
Final output_value 0.0035648982583969813
failed 38, out of 100
Build Time 0:03
Build log was saved at "file://j:\Cpp\Misc\loopback\Debug\BuildLog.htm"
loopback - 0 error(s), 0 warning(s)
========== Build: 1 succeeded, 0 failed, 0 up-to-date, 0 skipped ==========



------ Build started: Project: loopback, Configuration: Release Win32 ------
Compiling...
loopback.cpp
Linking...
Generating code
Finished generating code
Embedding manifest...
autorun "j:\Cpp\Misc\release\loopback.exe" 
Written  : 0.00020267796527185229 == 3f2a90be770550c7
Readback : 0.00020267796527185231 == 3f2a90be770550c8
Written  : 0.00023731105998203115 == 3f2f1ad67bb33f22
Readback : 0.00023731105998203117 == 3f2f1ad67bb33f23
Written  : 0.00051179139325349492 == 3f40c537a5f05eef
Readback : 0.00051179139325349481 == 3f40c537a5f05eee
Written  : 0.00021704936129525218 == 3f2c72f7d11749a9
Readback : 0.00021704936129525221 == 3f2c72f7d11749aa
Written  : 0.0032000608835790240 == 3f6a37039ae2c2c9
Readback : 0.0032000608835790244 == 3f6a37039ae2c2ca
Written  : 0.00022656739504339055 == 3f2db2571aa676f7
Readback : 0.00022656739504339052 == 3f2db2571aa676f6
Written  : 0.0031617082114865098 == 3f69e6952bc541c4
Readback : 0.0031617082114865102 == 3f69e6952bc541c5
Written  : 0.00020197485014907619 == 3f2a7926c083b2ec
Readback : 0.00020197485014907617 == 3f2a7926c083b2eb
failed 8, out of 10000, fraction 0.00080000000000000004
wrong min 0.00020197485014907619 == 3f2a7926c083b2ec
wrong max 0.0032000608835790240 == 3f6a37039ae2c2c9
Initial output_value 0.0035648982583969379
Written  : 00.0035648982583969379 == 3f6d34222dde445c
Readback : 00.0035648982583969383 == 3f6d34222dde445d
Written  : 00.0035648982583969392 == 3f6d34222dde445f
Readback : 00.0035648982583969388 == 3f6d34222dde445e
Written  : 00.0035648982583969401 == 3f6d34222dde4461
Readback : 00.0035648982583969405 == 3f6d34222dde4462
Written  : 00.0035648982583969414 == 3f6d34222dde4464
Readback : 00.0035648982583969418 == 3f6d34222dde4465
Written  : 00.0035648982583969427 == 3f6d34222dde4467
Readback : 00.0035648982583969422 == 3f6d34222dde4466
Written  : 00.0035648982583969435 == 3f6d34222dde4469
Readback : 00.0035648982583969440 == 3f6d34222dde446a
Written  : 00.0035648982583969448 == 3f6d34222dde446c
Readback : 00.0035648982583969444 == 3f6d34222dde446b
Written  : 00.0035648982583969461 == 3f6d34222dde446f
Readback : 00.0035648982583969457 == 3f6d34222dde446e
Written  : 00.0035648982583969470 == 3f6d34222dde4471
Readback : 00.0035648982583969474 == 3f6d34222dde4472
Written  : 00.0035648982583969483 == 3f6d34222dde4474
Readback : 00.0035648982583969479 == 3f6d34222dde4473
Written  : 00.0035648982583969496 == 3f6d34222dde4477
Readback : 00.0035648982583969492 == 3f6d34222dde4476
Written  : 00.0035648982583969505 == 3f6d34222dde4479
Readback : 00.0035648982583969509 == 3f6d34222dde447a
Written  : 00.0035648982583969518 == 3f6d34222dde447c
Readback : 00.0035648982583969522 == 3f6d34222dde447d
Written  : 00.0035648982583969531 == 3f6d34222dde447f
Readback : 00.0035648982583969526 == 3f6d34222dde447e
Written  : 00.0035648982583969539 == 3f6d34222dde4481
Readback : 00.0035648982583969544 == 3f6d34222dde4482
Written  : 00.0035648982583969552 == 3f6d34222dde4484
Readback : 00.0035648982583969548 == 3f6d34222dde4483
Written  : 00.0035648982583969565 == 3f6d34222dde4487
Readback : 00.0035648982583969561 == 3f6d34222dde4486
Written  : 00.0035648982583969574 == 3f6d34222dde4489
Readback : 00.0035648982583969578 == 3f6d34222dde448a
Written  : 00.0035648982583969587 == 3f6d34222dde448c
Readback : 00.0035648982583969583 == 3f6d34222dde448b
Written  : 00.0035648982583969600 == 3f6d34222dde448f
Readback : 00.0035648982583969596 == 3f6d34222dde448e
Written  : 00.0035648982583969609 == 3f6d34222dde4491
Readback : 00.0035648982583969613 == 3f6d34222dde4492
Written  : 00.0035648982583969622 == 3f6d34222dde4494
Readback : 00.0035648982583969626 == 3f6d34222dde4495
Written  : 00.0035648982583969635 == 3f6d34222dde4497
Readback : 00.0035648982583969631 == 3f6d34222dde4496
Written  : 00.0035648982583969644 == 3f6d34222dde4499
Readback : 00.0035648982583969648 == 3f6d34222dde449a
Written  : 00.0035648982583969657 == 3f6d34222dde449c
Readback : 00.0035648982583969661 == 3f6d34222dde449d
Written  : 00.0035648982583969670 == 3f6d34222dde449f
Readback : 00.0035648982583969665 == 3f6d34222dde449e
Written  : 00.0035648982583969678 == 3f6d34222dde44a1
Readback : 00.0035648982583969683 == 3f6d34222dde44a2
Written  : 00.0035648982583969691 == 3f6d34222dde44a4
Readback : 00.0035648982583969687 == 3f6d34222dde44a3
Written  : 00.0035648982583969704 == 3f6d34222dde44a7
Readback : 00.0035648982583969700 == 3f6d34222dde44a6
Written  : 00.0035648982583969713 == 3f6d34222dde44a9
Readback : 00.0035648982583969717 == 3f6d34222dde44aa
Written  : 00.0035648982583969726 == 3f6d34222dde44ac
Readback : 00.0035648982583969730 == 3f6d34222dde44ad
Written  : 00.0035648982583969739 == 3f6d34222dde44af
Readback : 00.0035648982583969735 == 3f6d34222dde44ae
Written  : 00.0035648982583969748 == 3f6d34222dde44b1
Readback : 00.0035648982583969752 == 3f6d34222dde44b2
Written  : 00.0035648982583969761 == 3f6d34222dde44b4
Readback : 00.0035648982583969765 == 3f6d34222dde44b5
Written  : 00.0035648982583969774 == 3f6d34222dde44b7
Readback : 00.0035648982583969769 == 3f6d34222dde44b6
Written  : 00.0035648982583969782 == 3f6d34222dde44b9
Readback : 00.0035648982583969787 == 3f6d34222dde44ba
Written  : 00.0035648982583969795 == 3f6d34222dde44bc
Readback : 00.0035648982583969791 == 3f6d34222dde44bb
Written  : 00.0035648982583969808 == 3f6d34222dde44bf
Readback : 00.0035648982583969804 == 3f6d34222dde44be
Final output_value 0.0035648982583969813
failed 38, out of 100
Build Time 0:03
Build log was saved at "file://j:\Cpp\Misc\loopback\Release\BuildLog.htm"
loopback - 0 error(s), 0 warning(s)
========== Build: 1 succeeded, 0 failed, 0 up-to-date, 0 skipped ==========

// Repeat with 1000000 tests

------ Build started: Project: loopback, Configuration: Release Win32 ------
Compiling...
loopback.cpp
Linking...
Generating code
Finished generating code
Embedding manifest...
autorun "j:\Cpp\Misc\release\loopback.exe" 
Written  : 0.0037070769205184550 == 3f6e5e4dc465715c
Readback : 0.0037070769205184554 == 3f6e5e4dc465715d
Written  : 0.00017890998774096103 == 3f27733917b161ab
Readback : 0.00017890998774096101 == 3f27733917b161aa
Written  : 0.00068440547105713754 == 3f466d358ec53a07
Readback : 0.00068440547105713743 == 3f466d358ec53a06
Written  : 0.00058788766002490663 == 3f43438f2302ff0f
Readback : 0.00058788766002490652 == 3f43438f2302ff0e
Written  : 0.00019424087875883440 == 3f2975a47191ccf0
Readback : 0.00019424087875883437 == 3f2975a47191ccef
Written  : 0.0037687704224550183 == 3f6edfaf36bd0abc
Readback : 0.0037687704224550187 == 3f6edfaf36bd0abd
Written  : 0.00016237444450371399 == 3f254861db922d5d
Readback : 0.00016237444450371402 == 3f254861db922d5e
Written  : 0.0036527382418432316 == 3f6dec58e9441e47
Readback : 0.0036527382418432312 == 3f6dec58e9441e46
Written  : 0.00053678827389111439 == 3f4196e80a6606ff
Readback : 0.00053678827389111428 == 3f4196e80a6606fe
Written  : 0.0032262590269420380 == 3f6a6df4a04ae1b9
Readback : 0.0032262590269420384 == 3f6a6df4a04ae1ba
Written  : 0.0031412092106440147 == 3f69bb97da8c2a4f
Readback : 0.0031412092106440142 == 3f69bb97da8c2a4e
Written  : 0.0036735500963593366 == 3f6e17fe30c54584
Readback : 0.0036735500963593370 == 3f6e17fe30c54585
Written  : 0.00024361944401334130 == 3f2fee8316e3d61f
Readback : 0.00024361944401334127 == 3f2fee8316e3d61e
Written  : 0.00020476585692420356 == 3f2ad6cd5151c164
Readback : 0.00020476585692420353 == 3f2ad6cd5151c163
Written  : 0.00064654093366210621 == 3f452f9415328379
Readback : 0.00064654093366210631 == 3f452f941532837a
Written  : 0.00074713755054455248 == 3f487b71ac2f979d
Readback : 0.00074713755054455259 == 3f487b71ac2f979e
Written  : 0.00019283753326406098 == 3f29468dcc30e243
Readback : 0.00019283753326406096 == 3f29468dcc30e242
Written  : 0.00077908935745798081 == 3f498779a7cd00a7
Readback : 0.00077908935745798070 == 3f498779a7cd00a6
Written  : 0.00023271326750800282 == 3f2e808fbf2026c9
Readback : 0.00023271326750800284 == 3f2e808fbf2026ca
Written  : 0.00089414137467625713 == 3f4d4c99fb2a8447
Readback : 0.00089414137467625702 == 3f4d4c99fb2a8446
Written  : 0.00093571131322208964 == 3f4ea950be908ae2
Readback : 0.00093571131322208974 == 3f4ea950be908ae3
Written  : 0.00079306128787561155 == 3f49fcae25c7748f
Readback : 0.00079306128787561166 == 3f49fcae25c77490
Written  : 0.00055196705308137664 == 3f42163c388190a1
Readback : 0.00055196705308137675 == 3f42163c388190a2
Written  : 0.00079807825922350087 == 3f4a26c402f21b9f
Readback : 0.00079807825922350076 == 3f4a26c402f21b9e
Written  : 0.0036978820342766418 == 3f6e4b054cda98ac
Readback : 0.0036978820342766414 == 3f6e4b054cda98ab
Written  : 0.00020214510265485891 == 3f2a7edd35bbe62f
Readback : 0.00020214510265485893 == 3f2a7edd35bbe630
Written  : 0.00020575279954514051 == 3f2af7eb17183dcc
Readback : 0.00020575279954514048 == 3f2af7eb17183dcb
Written  : 0.00073781800444076070 == 3f482d4419885539
Readback : 0.00073781800444076080 == 3f482d441988553a
Written  : 0.00019880543091439971 == 3f2a0ecda5e92a49
Readback : 0.00019880543091439974 == 3f2a0ecda5e92a4a
Written  : 0.00018983366259801111 == 3f28e1c2bebd58f0
Readback : 0.00018983366259801114 == 3f28e1c2bebd58f1
Written  : 0.00086822809037096936 == 3f4c7339a0765a5c
Readback : 0.00086822809037096947 == 3f4c7339a0765a5d
Written  : 0.0034440642894472480 == 3f6c36b9efa1c551
Readback : 0.0034440642894472484 == 3f6c36b9efa1c552
Written  : 0.00075524869559085545 == 3f48bf7c3955183d
Readback : 0.00075524869559085556 == 3f48bf7c3955183e
Written  : 0.00019138728632945941 == 3f2915e4457499b9
Readback : 0.00019138728632945939 == 3f2915e4457499b8
Written  : 0.00016875462364666040 == 3f261e772de184bd
Readback : 0.00016875462364666043 == 3f261e772de184be
Written  : 0.00020977067788245893 == 3f2b7ebc66ff1659
Readback : 0.00020977067788245895 == 3f2b7ebc66ff165a
Written  : 0.00023431430217343691 == 3f2eb64887967bc9
Readback : 0.00023431430217343694 == 3f2eb64887967bca
Written  : 0.0034952421918476371 == 3f6ca20ddcfa8d4f
Readback : 0.0034952421918476367 == 3f6ca20ddcfa8d4e
Written  : 0.00023864348473921014 == 3f2f478becba3ce9
Readback : 0.00023864348473921017 == 3f2f478becba3cea
Written  : 0.0037504774664916581 == 3f6eb9524203d28c
Readback : 0.0037504774664916577 == 3f6eb9524203d28b
Written  : 0.00080074165791402642 == 3f4a3d1b9ddc4d24
Readback : 0.00080074165791402631 == 3f4a3d1b9ddc4d23
Written  : 0.00023977135813711689 == 3f2f6d64488f0dff
Readback : 0.00023977135813711686 == 3f2f6d64488f0dfe
Written  : 0.00021490404905435254 == 3f2c2afbb99532f9
Readback : 0.00021490404905435257 == 3f2c2afbb99532fa
Written  : 0.00019570582723527381 == 3f29a6cc41566071
Readback : 0.00019570582723527378 == 3f29a6cc41566070
Written  : 0.0032527951195957740 == 3f6aa59b15189831
Readback : 0.0032527951195957744 == 3f6aa59b15189832
Written  : 0.00015539068262294421 == 3f245e0bccc8b13c
Readback : 0.00015539068262294419 == 3f245e0bccc8b13b
Written  : 0.0033099780704979602 == 3f6b1d86f2064641
Readback : 0.0033099780704979606 == 3f6b1d86f2064642
Written  : 0.0034963826216388560 == 3f6ca4722074aadc
Readback : 0.0034963826216388564 == 3f6ca4722074aadd
Written  : 0.00018656405865681463 == 3f28740d0fa2f1d9
Readback : 0.00018656405865681461 == 3f28740d0fa2f1d8
Written  : 0.00018090196547880850 == 3f27b6100d101e79
Readback : 0.00018090196547880852 == 3f27b6100d101e7a
Written  : 0.00018616488486649545 == 3f2866a82f30470c
Readback : 0.00018616488486649543 == 3f2866a82f30470b
Written  : 0.00053331413549686363 == 3f4179c3629e38bf
Readback : 0.00053331413549686352 == 3f4179c3629e38be
Written  : 0.00020831735762841862 == 3f2b4df879f5c4e1
Readback : 0.00020831735762841865 == 3f2b4df879f5c4e2
Written  : 0.00024137409538930188 == 3f2fa32bb10c84d1
Readback : 0.00024137409538930185 == 3f2fa32bb10c84d0
Written  : 0.00096415504376117780 == 3f4f97eb30cc11cc
Readback : 0.00096415504376117769 == 3f4f97eb30cc11cb
Written  : 0.00024150576946191949 == 3f2fa796c36590d1
Readback : 0.00024150576946191946 == 3f2fa796c36590d0
Written  : 0.00091818816580779361 == 3f4e165212655fd4
Readback : 0.00091818816580779372 == 3f4e165212655fd5
Written  : 0.00094083586128165645 == 3f4ed44da0a766f1
Readback : 0.00094083586128165635 == 3f4ed44da0a766f0
Written  : 0.00022132751774827958 == 3f2d0284e69f3fa4
Readback : 0.00022132751774827956 == 3f2d0284e69f3fa3
Written  : 0.00023299692460921611 == 3f2e8a1457b01131
Readback : 0.00023299692460921608 == 3f2e8a1457b01130
Written  : 0.00015410234981908967 == 3f2432d11afcc571
Readback : 0.00015410234981908969 == 3f2432d11afcc572
Written  : 0.00022382321556069088 == 3f2d5642c8267fcc
Readback : 0.00022382321556069085 == 3f2d5642c8267fcb
Written  : 0.00086499454936091950 == 3f4c5819a67e1ac7
Readback : 0.00086499454936091939 == 3f4c5819a67e1ac6
Written  : 0.0034636845006100450 == 3f6c5fdf74ebc8b9
Readback : 0.0034636845006100455 == 3f6c5fdf74ebc8ba
Written  : 0.00096413526289115218 == 3f4f97c0b6261ac9
Readback : 0.00096413526289115229 == 3f4f97c0b6261aca
Written  : 0.0032339998911519088 == 3f6a7e30789187ec
Readback : 0.0032339998911519092 == 3f6a7e30789187ed
Written  : 0.00022501865723349243 == 3f2d7e5f8c30854f
Readback : 0.00022501865723349246 == 3f2d7e5f8c308550
Written  : 0.00017199084003342074 == 3f268b0e10f9b4df
Readback : 0.00017199084003342071 == 3f268b0e10f9b4de
Written  : 0.00062347099473581021 == 3f446e0dc425840f
Readback : 0.00062347099473581010 == 3f446e0dc425840e
Written  : 0.0038499748235963954 == 3f6f89fb7ea60d09
Readback : 0.0038499748235963959 == 3f6f89fb7ea60d0a
Written  : 0.00023890882949625700 == 3f2f50733804dba9
Readback : 0.00023890882949625703 == 3f2f50733804dbaa
Written  : 0.00062926966107829238 == 3f449eb24eae5e0c
Readback : 0.00062926966107829227 == 3f449eb24eae5e0b
Written  : 0.00064305195210605573 == 3f45124f8d4d659f
Readback : 0.00064305195210605562 == 3f45124f8d4d659e
Written  : 0.00021765066985287107 == 3f2c87250497ca87
Readback : 0.00021765066985287109 == 3f2c87250497ca88
Written  : 0.00093488067623301698 == 3f4ea258f70cf724
Readback : 0.00093488067623301687 == 3f4ea258f70cf723
Written  : 0.00062141718369664392 == 3f445cd33d964ea1
Readback : 0.00062141718369664403 == 3f445cd33d964ea2
Written  : 0.00023727277995213463 == 3f2f198da906330c
Readback : 0.00023727277995213460 == 3f2f198da906330b
Written  : 0.00091347966165645578 == 3f4deed2a2dd3454
Readback : 0.00091347966165645589 == 3f4deed2a2dd3455
Written  : 0.00012470557213945744 == 3f20586cb53b491f
Readback : 0.00012470557213945741 == 3f20586cb53b491e
Written  : 0.0033035276436831520 == 3f6b0fffe61d1727
Readback : 0.0033035276436831516 == 3f6b0fffe61d1726
Written  : 0.00016596448357567817 == 3f25c0d80efa8527
Readback : 0.00016596448357567814 == 3f25c0d80efa8526
Written  : 0.0037233215500430722 == 3f6e805f09471509
Readback : 0.0037233215500430726 == 3f6e805f0947150a
Written  : 0.00091729358713105700 == 3f4e0ed0fa914631
Readback : 0.00091729358713105690 == 3f4e0ed0fa914630
Written  : 0.0037359583203499702 == 3f6e9adf59c38fa9
Readback : 0.0037359583203499707 == 3f6e9adf59c38faa
Written  : 0.00024286448769884558 == 3f2fd52e1065c184
Readback : 0.00024286448769884555 == 3f2fd52e1065c183
Written  : 0.00081926511619545865 == 3f4ad87e70be7c1c
Readback : 0.00081926511619545876 == 3f4ad87e70be7c1d
Written  : 0.00013961891881518427 == 3f224cd56163bdef
Readback : 0.00013961891881518425 == 3f224cd56163bdee
Written  : 0.00022691058044684338 == 3f2dbddb0b555a75
Readback : 0.00022691058044684340 == 3f2dbddb0b555a76
Written  : 0.00094500224329542451 == 3f4ef740dd638c74
Readback : 0.00094500224329542462 == 3f4ef740dd638c75
Written  : 0.0036594627341701639 == 3f6dfa73187441ef
Readback : 0.0036594627341701635 == 3f6dfa73187441ee
Written  : 0.00022110120817562132 == 3f2cfaecea9bdca1
Readback : 0.00022110120817562135 == 3f2cfaecea9bdca2
Written  : 0.00024054424265677529 == 3f2f87534f97657c
Readback : 0.00024054424265677532 == 3f2f87534f97657d
Written  : 0.0038139723306544154 == 3f6f3e7acdb24137
Readback : 0.0038139723306544150 == 3f6f3e7acdb24136
Written  : 0.0039054581881726152 == 3f6ffe56e6360a7c
Readback : 0.0039054581881726156 == 3f6ffe56e6360a7d
Written  : 0.00023017398065571152 == 3f2e2b5b7048ee47
Readback : 0.00023017398065571150 == 3f2e2b5b7048ee46
Written  : 0.00092546762734330526 == 3f4e536298b27622
Readback : 0.00092546762734330536 == 3f4e536298b27623
Written  : 0.00023254330464996125 == 3f2e7adbc6d92237
Readback : 0.00023254330464996122 == 3f2e7adbc6d92236
Written  : 0.00024269288263386376 == 3f2fcf6bfcde6ae4
Readback : 0.00024269288263386373 == 3f2fcf6bfcde6ae3
Written  : 0.00021763765884967961 == 3f2c86b541182689
Readback : 0.00021763765884967964 == 3f2c86b54118268a
Written  : 0.00022566498594704250 == 3f2d940f780fb567
Readback : 0.00022566498594704247 == 3f2d940f780fb566
Written  : 0.00070973004764130409 == 3f4741a5abfb582c
Readback : 0.00070973004764130398 == 3f4741a5abfb582b
Written  : 0.00018797219820268713 == 3f28a34ce33eb450
Readback : 0.00018797219820268715 == 3f28a34ce33eb451
Written  : 0.00087459028635887255 == 3f4ca89856b21d64
Readback : 0.00087459028635887245 == 3f4ca89856b21d63
Written  : 0.00023240385114682270 == 3f2e762de15a0991
Readback : 0.00023240385114682268 == 3f2e762de15a0990
Written  : 0.0033048005909493954 == 3f6b12ab4ea75afc
Readback : 0.0033048005909493950 == 3f6b12ab4ea75afb
Written  : 0.0038952244452137314 == 3f6fe8e0b349ea04
Readback : 0.0038952244452137310 == 3f6fe8e0b349ea03
Written  : 0.00086171412618126907 == 3f4c3c94fec70ed9
Readback : 0.00086171412618126918 == 3f4c3c94fec70eda
Written  : 0.00080158140479067255 == 3f4a4426f5969322
Readback : 0.00080158140479067266 == 3f4a4426f5969323
Written  : 0.0032712291052821359 == 3f6acc43c0cc104c
Readback : 0.0032712291052821355 == 3f6acc43c0cc104b
Written  : 0.0036384891780097167 == 3f6dce7700d84849
Readback : 0.0036384891780097172 == 3f6dce7700d8484a
Written  : 0.00015196951327508225 == 3f23eb402dd3aac1
Readback : 0.00015196951327508228 == 3f23eb402dd3aac2
Written  : 0.00089856644187106356 == 3f4d71b8bd95513c
Readback : 0.00089856644187106367 == 3f4d71b8bd95513d
Written  : 0.00020238137134431547 == 3f2a86cabe139fa7
Readback : 0.00020238137134431544 == 3f2a86cabe139fa6
Written  : 0.00092203300250024041 == 3f4e3692cbb89b0f
Readback : 0.00092203300250024052 == 3f4e3692cbb89b10
Written  : 0.00097432758199533255 == 3f4fed408cd557cf
Readback : 0.00097432758199533266 == 3f4fed408cd557d0
Written  : 0.00088235662088796956 == 3f4ce9be6a417799
Readback : 0.00088235662088796967 == 3f4ce9be6a41779a
Written  : 0.00066876560775178942 == 3f45ea0334fd694c
Readback : 0.00066876560775178931 == 3f45ea0334fd694b
Written  : 0.0036223524605245578 == 3f6dac9fab47fdff
Readback : 0.0036223524605245574 == 3f6dac9fab47fdfe
Written  : 0.00093887959817000365 == 3f4ec3e495a28184
Readback : 0.00093887959817000354 == 3f4ec3e495a28183
Written  : 0.0035643218044604107 == 3f6d32ecb2a478e1
Readback : 0.0035643218044604111 == 3f6d32ecb2a478e2
Written  : 0.00082712970656626482 == 3f4b1a778506372f
Readback : 0.00082712970656626493 == 3f4b1a7785063730
Written  : 0.00096413845498414348 == 3f4f97c79105413c
Readback : 0.00096413845498414359 == 3f4f97c79105413d
Written  : 0.0034754359465391789 == 3f6c78847759efbf
Readback : 0.0034754359465391784 == 3f6c78847759efbe
Written  : 0.00081128604421310945 == 3f4a958f83884859
Readback : 0.00081128604421310956 == 3f4a958f8388485a
Written  : 0.00071092096301970866 == 3f474ba324a28b79
Readback : 0.00071092096301970877 == 3f474ba324a28b7a
Written  : 0.00017506518845076686 == 3f26f23684a40d6b
Readback : 0.00017506518845076684 == 3f26f23684a40d6a
Written  : 0.00069388819043413562 == 3f46bcc18ae11fb0
Readback : 0.00069388819043413573 == 3f46bcc18ae11fb1
Written  : 0.00074580483003616022 == 3f487043ad568fbd
Readback : 0.00074580483003616033 == 3f487043ad568fbe
Written  : 0.00057670026447284052 == 3f42e5b66343c2cf
Readback : 0.00057670026447284042 == 3f42e5b66343c2ce
Written  : 0.0031417995844996755 == 3f69bcd4cee99309
Readback : 0.0031417995844996759 == 3f69bcd4cee9930a
Written  : 0.00015789997178752803 == 3f24b23e6e0303f0
Readback : 0.00015789997178752805 == 3f24b23e6e0303f1
Written  : 0.00083302830358780537 == 3f4b4bf2a907d8ef
Readback : 0.00083302830358780548 == 3f4b4bf2a907d8f0
Written  : 0.00065262587907447954 == 3f45629f6750a159
Readback : 0.00065262587907447965 == 3f45629f6750a15a
Written  : 0.0035087000316782082 == 3f6cbe46fc66a9a7
Readback : 0.0035087000316782078 == 3f6cbe46fc66a9a6
Written  : 0.00091129169138073451 == 3f4ddc78017c00d7
Readback : 0.00091129169138073440 == 3f4ddc78017c00d6
Written  : 0.00085928446816039151 == 3f4c28335827a327
Readback : 0.00085928446816039140 == 3f4c28335827a326
Written  : 0.0038868633268162316 == 3f6fd757dbed2341
Readback : 0.0038868633268162320 == 3f6fd757dbed2342
Written  : 0.00019318772371389062 == 3f29524de9224dd4
Readback : 0.00019318772371389065 == 3f29524de9224dd5
Written  : 0.00091954568807519092 == 3f4e21b55427ac9c
Readback : 0.00091954568807519103 == 3f4e21b55427ac9d
Written  : 0.0033772523550506810 == 3f6baa9c8d49fcc1
Readback : 0.0033772523550506814 == 3f6baa9c8d49fcc2
Written  : 0.0038058109635382624 == 3f6f2d5d33f0e2ef
Readback : 0.0038058109635382619 == 3f6f2d5d33f0e2ee
Written  : 0.00019026086985885726 == 3f28f0186d70f127
Readback : 0.00019026086985885724 == 3f28f0186d70f126
Written  : 0.0031775976744689901 == 3f6a07e7c2ef1fcc
Readback : 0.0031775976744689905 == 3f6a07e7c2ef1fcd
Written  : 0.0036840993564560432 == 3f6e2e1dc809c6a4
Readback : 0.0036840993564560428 == 3f6e2e1dc809c6a3
Written  : 0.00090592079080383339 == 3f4daf6a15aa9aa2
Readback : 0.00090592079080383350 == 3f4daf6a15aa9aa3
Written  : 0.00014922758982945395 == 3f238f3f3c67aa6f
Readback : 0.00014922758982945393 == 3f238f3f3c67aa6e
Written  : 0.00022517117774408979 == 3f2d837db056db79
Readback : 0.00022517117774408977 == 3f2d837db056db78
Written  : 0.0034042180686368242 == 3f6be329a8be716c
Readback : 0.0034042180686368246 == 3f6be329a8be716d
Written  : 0.00023127852451847107 == 3f2e506b65ed05e7
Readback : 0.00023127852451847105 == 3f2e506b65ed05e6
Written  : 0.00094705045945601605 == 3f4f086f6021995e
Readback : 0.00094705045945601594 == 3f4f086f6021995d
Written  : 0.00072702979798489878 == 3f47d2c49a4fe04c
Readback : 0.00072702979798489867 == 3f47d2c49a4fe04b
Written  : 0.00015247242765650161 == 3f23fc202e3f430f
Readback : 0.00015247242765650159 == 3f23fc202e3f430e
Written  : 0.00019126394513768326 == 3f2911c0c74e6f67
Readback : 0.00019126394513768323 == 3f2911c0c74e6f66
Written  : 0.0038430503597919438 == 3f6f7b75f3970a19
Readback : 0.0038430503597919443 == 3f6f7b75f3970a1a
Written  : 0.00068719244373039552 == 3f4684968933603d
Readback : 0.00068719244373039562 == 3f4684968933603e
Written  : 0.0033963663105006005 == 3f6bd2b24752a06c
Readback : 0.0033963663105006001 == 3f6bd2b24752a06b
Written  : 0.00023064140635060496 == 3f2e3b0a98421955
Readback : 0.00023064140635060498 == 3f2e3b0a98421956
Written  : 0.00081881361705149816 == 3f4ad4b4da76f81f
Readback : 0.00081881361705149805 == 3f4ad4b4da76f81e
Written  : 0.00020133998693176250 == 3f2a63d951891551
Readback : 0.00020133998693176247 == 3f2a63d951891550
Written  : 0.00054746020675264923 == 3f41f06dd788db3f
Readback : 0.00054746020675264912 == 3f41f06dd788db3e
Written  : 0.00013545478299288851 == 3f21c11bb9e08a5f
Readback : 0.00013545478299288848 == 3f21c11bb9e08a5e
Written  : 0.0033947603033006933 == 3f6bcf540f5fba4f
Readback : 0.0033947603033006929 == 3f6bcf540f5fba4e
Written  : 0.00019993962572900385 == 3f2a34dc4eaf379f
Readback : 0.00019993962572900382 == 3f2a34dc4eaf379e
Written  : 0.00094340525142312334 == 3f4ee9db59d28461
Readback : 0.00094340525142312345 == 3f4ee9db59d28462
Written  : 0.00083100684142711431 == 3f4b3afd9a748be1
Readback : 0.00083100684142711442 == 3f4b3afd9a748be2
Written  : 0.0032308014010754764 == 3f6a777b4b708f2f
Readback : 0.0032308014010754759 == 3f6a777b4b708f2e
Written  : 0.0037243732451976434 == 3f6e8293a928b981
Readback : 0.0037243732451976439 == 3f6e8293a928b982
Written  : 0.00022895501103439188 == 3f2e027491bd630b
Readback : 0.00022895501103439186 == 3f2e027491bd630a
Written  : 0.00017952796643758246 == 3f2787f57d37dc23
Readback : 0.00017952796643758243 == 3f2787f57d37dc22
Written  : 0.00096309384937832152 == 3f4f8f044b03f834
Readback : 0.00096309384937832163 == 3f4f8f044b03f835
Written  : 0.00087480997943627399 == 3f4caa70203e098f
Readback : 0.00087480997943627410 == 3f4caa70203e0990
Written  : 0.00064858914982625045 == 3f4540c297f11063
Readback : 0.00064858914982625034 == 3f4540c297f11062
Written  : 0.0031986770424148494 == 3f6a341ca9345427
Readback : 0.0031986770424148490 == 3f6a341ca9345426
Written  : 0.00022357008378447583 == 3f2d4dc4657cde97
Readback : 0.00022357008378447581 == 3f2d4dc4657cde96
Written  : 0.00018459177492616318 == 3f2831df45d8a410
Readback : 0.00018459177492616320 == 3f2831df45d8a411
Written  : 0.00066647336927980921 == 3f45d6c8a9902743
Readback : 0.00066647336927980910 == 3f45d6c8a9902742
Written  : 0.0037181620263130352 == 3f6e758d09bc5d07
Readback : 0.0037181620263130348 == 3f6e758d09bc5d06
Written  : 0.00090900606110825351 == 3f4dc94ba6f42539
Readback : 0.00090900606110825362 == 3f4dc94ba6f4253a
Written  : 0.0031754684571257876 == 3f6a0370a587dcec
Readback : 0.0031754684571257872 == 3f6a0370a587dceb
Written  : 0.00016896647404435002 == 3f262592f5d507b9
Readback : 0.00016896647404435005 == 3f262592f5d507ba
Written  : 0.00014458267277749212 == 3f22f363b3c99e34
Readback : 0.00014458267277749214 == 3f22f363b3c99e35
Written  : 0.00021135950394526903 == 3f2bb40c5075240c
Readback : 0.00021135950394526900 == 3f2bb40c5075240b
Written  : 0.00018967058336162668 == 3f28dc49e7b4d221
Readback : 0.00018967058336162671 == 3f28dc49e7b4d222
Written  : 0.0036239929297106374 == 3f6db01063a63c47
Readback : 0.0036239929297106370 == 3f6db01063a63c46
Written  : 0.00067771504015520171 == 3f463515f77c12c7
Readback : 0.00067771504015520160 == 3f463515f77c12c6
Written  : 0.0033455489823419264 == 3f6b681feeec21af
Readback : 0.0033455489823419260 == 3f6b681feeec21ae
Written  : 0.00093962262831593691 == 3f4eca203ac70451
Readback : 0.00093962262831593681 == 3f4eca203ac70450
Written  : 0.00083854563035261093 == 3f4b7a3b077f2969
Readback : 0.00083854563035261104 == 3f4b7a3b077f296a
Written  : 0.00077588973947017063 == 3f496ca28735b39d
Readback : 0.00077588973947017074 == 3f496ca28735b39e
Written  : 0.00081835898534529878 == 3f4ad0e48a0a8314
Readback : 0.00081835898534529888 == 3f4ad0e48a0a8315
Written  : 0.0037681544418041025 == 3f6ede6483009edf
Readback : 0.0037681544418041021 == 3f6ede6483009ede
Written  : 0.00076501527374288260 == 3f491169ca740979
Readback : 0.00076501527374288271 == 3f491169ca74097a
Written  : 0.00096421047320441767 == 3f4f98623974b129
Readback : 0.00096421047320441777 == 3f4f98623974b12a
Written  : 0.00066530027383838325 == 3f45ccf175862041
Readback : 0.00066530027383838336 == 3f45ccf175862042
Written  : 0.00024185062617614300 == 3f2fb3290f54c65c
Readback : 0.00024185062617614302 == 3f2fb3290f54c65d
Written  : 0.00080001435467229277 == 3f4a3701beacc97c
Readback : 0.00080001435467229288 == 3f4a3701beacc97d
Written  : 0.00012477869070735053 == 3f205ae0caa9acdf
Readback : 0.00012477869070735050 == 3f205ae0caa9acde
Written  : 0.00020912692613058974 == 3f2b69229dec5b8f
Readback : 0.00020912692613058977 == 3f2b69229dec5b90
Written  : 0.00019122147504388421 == 3f291053f6951bf4
Readback : 0.00019122147504388424 == 3f291053f6951bf5
Written  : 0.0033940904630077786 == 3f6bcdec71399f2c
Readback : 0.0033940904630077790 == 3f6bcdec71399f2d
Written  : 0.0034264230677707942 == 3f6c11bae0963471
Readback : 0.0034264230677707947 == 3f6c11bae0963472
Written  : 0.0033113389964352234 == 3f6b20619642d621
Readback : 0.0033113389964352239 == 3f6b20619642d622
Written  : 0.00017484060181316248 == 3f26eaad5566dfbd
Readback : 0.00017484060181316251 == 3f26eaad5566dfbe
Written  : 0.00077632894532927077 == 3f497051b72f2eac
Readback : 0.00077632894532927066 == 3f497051b72f2eab
Written  : 0.00066264965221552721 == 3f45b6b54ae0584c
Readback : 0.00066264965221552710 == 3f45b6b54ae0584b
Written  : 0.00050465497234688562 == 3f40895a4d0e20d1
Readback : 0.00050465497234688573 == 3f40895a4d0e20d2
Written  : 0.00017360493841373661 == 3f26c13710d9b907
Readback : 0.00017360493841373658 == 3f26c13710d9b906
Written  : 0.0031400160727721766 == 3f69b9174aed5449
Readback : 0.0031400160727721770 == 3f69b9174aed544a
Written  : 0.0036535232321864872 == 3f6dedfe59847107
Readback : 0.0036535232321864867 == 3f6dedfe59847106
Written  : 0.00019808040861522380 == 3f29f679c1039d5c
Readback : 0.00019808040861522382 == 3f29f679c1039d5d
Written  : 0.00018367776450785292 == 3f281333fbae39fd
Readback : 0.00018367776450785295 == 3f281333fbae39fe
Written  : 0.00083603729955151584 == 3f4b65306e0e4057
Readback : 0.00083603729955151573 == 3f4b65306e0e4056
Written  : 0.00049705190565451512 == 3f404992d6f00bc1
Readback : 0.00049705190565451523 == 3f404992d6f00bc2
Written  : 0.0034203245802455883 == 3f6c04f0c6d7f05c
Readback : 0.0034203245802455879 == 3f6c04f0c6d7f05b
Written  : 0.00018873958296711151 == 3f28bd0cac3017e1
Readback : 0.00018873958296711154 == 3f28bd0cac3017e2
Written  : 0.00023477315150108056 == 3f2ec5ae03ee1ba1
Readback : 0.00023477315150108058 == 3f2ec5ae03ee1ba2
Written  : 0.00063255553834108127 == 3f44ba42accf604c
Readback : 0.00063255553834108116 == 3f44ba42accf604b
Written  : 0.00065117522330827187 == 3f45567424dfa043
Readback : 0.00065117522330827176 == 3f45567424dfa042
Written  : 0.0037492041410139665 == 3f6eb6a6a57e6cd7
Readback : 0.0037492041410139660 == 3f6eb6a6a57e6cd6
Written  : 0.00078003539300179050 == 3f498f694057554c
Readback : 0.00078003539300179039 == 3f498f694057554b
Written  : 0.00094991252168114178 == 3f4f20719b7aae11
Readback : 0.00094991252168114167 == 3f4f20719b7aae10
Written  : 0.00018256900147736041 == 3f27edffc7fddb01
Readback : 0.00018256900147736044 == 3f27edffc7fddb02
Written  : 0.00084544783358284526 == 3f4bb42165d9e729
Readback : 0.00084544783358284537 == 3f4bb42165d9e72a
Written  : 0.00023350948485360913 == 3f2e9b473395c619
Readback : 0.00023350948485360916 == 3f2e9b473395c61a
Written  : 0.00078165534901287635 == 3f499d001493945c
Readback : 0.00078165534901287646 == 3f499d001493945d
Written  : 0.00091802536616421998 == 3f4e14f476586ec1
Readback : 0.00091802536616422009 == 3f4e14f476586ec2
Written  : 0.00095217480536452590 == 3f4f336bd3163a07
Readback : 0.00095217480536452580 == 3f4f336bd3163a06
Written  : 0.0037554056434221969 == 3f6ec3a80d7eaa87
Readback : 0.0037554056434221965 == 3f6ec3a80d7eaa86
Written  : 0.0034974691917738655 == 3f6ca6b979849924
Readback : 0.0034974691917738659 == 3f6ca6b979849925
Written  : 0.00019611011820558331 == 3f29b45d169547f7
Readback : 0.00019611011820558328 == 3f29b45d169547f6
Written  : 0.00018468796031314303 == 3f2835197fbfc2d0
Readback : 0.00018468796031314305 == 3f2835197fbfc2d1
Written  : 0.00021755175241670044 == 3f2c83d352d9b4d1
Readback : 0.00021755175241670041 == 3f2c83d352d9b4d0
Written  : 0.00017296978666733276 == 3f26abe72763ab54
Readback : 0.00017296978666733279 == 3f26abe72763ab55
Written  : 0.00023884673078447048 == 3f2f4e5dcb81f347
Readback : 0.00023884673078447050 == 3f2f4e5dcb81f348
Written  : 0.00024357399729653601 == 3f2fecfcb480ba4c
Readback : 0.00024357399729653598 == 3f2fecfcb480ba4b
Written  : 0.00024093099457965538 == 3f2f944d7c105e0c
Readback : 0.00024093099457965535 == 3f2f944d7c105e0b
Written  : 0.00076773904584701924 == 3f4928430c00d354
Readback : 0.00076773904584701935 == 3f4928430c00d355
Written  : 0.00086238078742652518 == 3f4c422ca3ac4c97
Readback : 0.00086238078742652507 == 3f4c422ca3ac4c96
Written  : 0.00019366319155536541 == 3f29624225f983fd
Readback : 0.00019366319155536543 == 3f29624225f983fe
Written  : 0.00053804269524181634 == 3f41a16de3d443b1
Readback : 0.00053804269524181645 == 3f41a16de3d443b2
Written  : 0.00093812749316571223 == 3f4ebd95738938f4
Readback : 0.00093812749316571234 == 3f4ebd95738938f5
Written  : 0.00020385015267466988 == 3f2ab8137a6121fc
Readback : 0.00020385015267466991 == 3f2ab8137a6121fd
Written  : 0.0032439401883271458 == 3f6a9309209c049f
Readback : 0.0032439401883271454 == 3f6a9309209c049e
Written  : 0.00015456536777670203 == 3f24425a663e713f
Readback : 0.00015456536777670200 == 3f24425a663e713e
Written  : 0.00068078022853604878 == 3f464ecc689e2134
Readback : 0.00068078022853604889 == 3f464ecc689e2135
Written  : 0.0037281563058486175 == 3f6e8a82ad0e4d99
Readback : 0.0037281563058486180 == 3f6e8a82ad0e4d9a
Written  : 0.0038502050536173313 == 3f6f8a771938c607
Readback : 0.0038502050536173308 == 3f6f8a771938c606
Written  : 0.0038298936867730716 == 3f6f5fde843817a4
Readback : 0.0038298936867730720 == 3f6f5fde843817a5
Written  : 0.00088805982785756046 == 3f4d1995f571f021
Readback : 0.00088805982785756057 == 3f4d1995f571f022
Written  : 0.00014067774557695781 == 3f22705ca20ff6ad
Readback : 0.00014067774557695783 == 3f22705ca20ff6ae
Written  : 0.00093123450306806493 == 3f4e83c2de279f17
Readback : 0.00093123450306806482 == 3f4e83c2de279f16
Written  : 0.0035584346149331804 == 3f6d2694097996b1
Readback : 0.0035584346149331808 == 3f6d2694097996b2
Written  : 0.00014283963346115651 == 3f22b8e71bcbace3
Readback : 0.00014283963346115649 == 3f22b8e71bcbace2
Written  : 0.00083516643929886164 == 3f4b5de245919594
Readback : 0.00083516643929886175 == 3f4b5de245919595
Written  : 0.00094859405539420960 == 3f4f156238f8f9d7
Readback : 0.00094859405539420949 == 3f4f156238f8f9d6
Written  : 0.00063140345492962511 == 3f44b0989841ac07
Readback : 0.00063140345492962500 == 3f44b0989841ac06
Written  : 0.00023181890056001248 == 3f2e628d31687054
Readback : 0.00023181890056001250 == 3f2e628d31687055
Written  : 0.00081977410896427229 == 3f4adcc37e7a5bd1
Readback : 0.00081977410896427218 == 3f4adcc37e7a5bd0
Written  : 0.00019264151211159395 == 3f293ff9fd1e3ba1
Readback : 0.00019264151211159398 == 3f293ff9fd1e3ba2
Written  : 0.00066736291569545784 == 3f45de3ef2e0779d
Readback : 0.00066736291569545795 == 3f45de3ef2e0779e
Written  : 0.00084196679028517615 == 3f4b96edea0f5537
Readback : 0.00084196679028517604 == 3f4b96edea0f5536
Written  : 0.00077242119595449462 == 3f494f89e33f0de1
Readback : 0.00077242119595449473 == 3f494f89e33f0de2
Written  : 0.0034655657422677584 == 3f6c63d170ce4211
Readback : 0.0034655657422677589 == 3f6c63d170ce4212
Written  : 0.00097491979155869693 == 3f4ff2384f7bdef4
Readback : 0.00097491979155869704 == 3f4ff2384f7bdef5
Written  : 0.0037095567227211686 == 3f6e638119d0d98c
Readback : 0.0037095567227211682 == 3f6e638119d0d98b
Written  : 0.00017589661579585529 == 3f270e1c6cb53e3f
Readback : 0.00017589661579585526 == 3f270e1c6cb53e3e
Written  : 0.00079805937525907799 == 3f4a269b75606284
Readback : 0.00079805937525907788 == 3f4a269b75606283
Written  : 0.00064974918466284342 == 3f454a7dbfd65eec
Readback : 0.00064974918466284331 == 3f454a7dbfd65eeb
Written  : 0.00082953855470822944 == 3f4b2eac7b4b8b89
Readback : 0.00082953855470822954 == 3f4b2eac7b4b8b8a
Written  : 0.00017083915124442467 == 3f266469228b95d9
Readback : 0.00017083915124442469 == 3f266469228b95da
Written  : 0.0037573090095867987 == 3f6ec7a5ea2605d4
Readback : 0.0037573090095867983 == 3f6ec7a5ea2605d3
Written  : 0.00018898167124811632 == 3f28c52c31f29bd9
Readback : 0.00018898167124811635 == 3f28c52c31f29bda
Written  : 0.00077828527666382746 == 3f4980bae7b59941
Readback : 0.00077828527666382757 == 3f4980bae7b59942
Written  : 0.0038632287434998917 == 3f6fa5c723879234
Readback : 0.0038632287434998921 == 3f6fa5c723879235
Written  : 0.00092084004045305369 == 3f4e2c90ede661a4
Readback : 0.00092084004045305359 == 3f4e2c90ede661a3
Written  : 0.00066764571043949003 == 3f45e09e3eee7661
Readback : 0.00066764571043949014 == 3f45e09e3eee7662
Written  : 0.00023765712904974380 == 3f2f267331a0cbc7
Readback : 0.00023765712904974382 == 3f2f267331a0cbc8
Written  : 0.0034576515422044454 == 3f6c5338896e71ec
Readback : 0.0034576515422044458 == 3f6c5338896e71ed
Written  : 0.00091703608674596597 == 3f4e0ca8003bd371
Readback : 0.00091703608674596586 == 3f4e0ca8003bd370
Written  : 0.0035699290551288623 == 3f6d3eaf114e62e7
Readback : 0.0035699290551288619 == 3f6d3eaf114e62e6
Written  : 0.00016214377226681211 == 3f2540a465f5285f
Readback : 0.00016214377226681209 == 3f2540a465f5285e
Written  : 0.00082065336938855161 == 3f4ae423b10214fc
Readback : 0.00082065336938855172 == 3f4ae423b10214fd
Written  : 0.00016806977579590142 == 3f26077c6187d543
Readback : 0.00016806977579590139 == 3f26077c6187d542
Written  : 0.0034263440143420167 == 3f6c11906f90f3ac
Readback : 0.0034263440143420163 == 3f6c11906f90f3ab
Written  : 0.00020685511318385846 == 3f2b1ce7e46bd037
Readback : 0.00020685511318385843 == 3f2b1ce7e46bd036
Written  : 0.00094630308745035925 == 3f4f022a6806a7e7
Readback : 0.00094630308745035914 == 3f4f022a6806a7e6
Written  : 0.00049901495725426434 == 3f405a0a75f7b4df
Readback : 0.00049901495725426423 == 3f405a0a75f7b4de
Written  : 0.00018981810811517701 == 3f28e13d2211f5e1
Readback : 0.00018981810811517704 == 3f28e13d2211f5e2
Written  : 0.00022040708812854417 == 3f2ce3a2787bb0e2
Readback : 0.00022040708812854420 == 3f2ce3a2787bb0e3
Written  : 0.00088383161470529151 == 3f4cf61df0aea81e
Readback : 0.00088383161470529140 == 3f4cf61df0aea81d
Written  : 0.00091924420716816429 == 3f4e1f2de7460841
Readback : 0.00091924420716816440 == 3f4e1f2de7460842
Written  : 0.00077833975848783923 == 3f49812fe768abcc
Readback : 0.00077833975848783912 == 3f49812fe768abcb
Written  : 0.00085206062070634545 == 3f4beb9a4004b15e
Readback : 0.00085206062070634534 == 3f4beb9a4004b15d
Written  : 0.0037053465124673268 == 3f6e5aacc2ecb4d7
Readback : 0.0037053465124673264 == 3f6e5aacc2ecb4d6
Written  : 0.0032214643335777044 == 3f6a63e67ea77fc9
Readback : 0.0032214643335777048 == 3f6a63e67ea77fca
Written  : 0.00055621737732027509 == 3f4239e3b8f7a4af
Readback : 0.00055621737732027498 == 3f4239e3b8f7a4ae
Written  : 0.0034774497409404245 == 3f6c7cbd9d2575d9
Readback : 0.0034774497409404250 == 3f6c7cbd9d2575da
Written  : 0.0035855649772535327 == 3f6d5f798a145f6c
Readback : 0.0035855649772535323 == 3f6d5f798a145f6b
Written  : 0.00083581517300894425 == 3f4b63536ab28d81
Readback : 0.00083581517300894436 == 3f4b63536ab28d82
Written  : 0.00023757331937064661 == 3f2f23a34631da1c
Readback : 0.00023757331937064664 == 3f2f23a34631da1d
Written  : 0.00020392665781849087 == 3f2abaa4a6f84884
Readback : 0.00020392665781849084 == 3f2abaa4a6f84883
Written  : 0.0034719885847231905 == 3f6c7149ad8d13f4
Readback : 0.0034719885847231901 == 3f6c7149ad8d13f3
Written  : 0.00019802614316341132 == 3f29f4a79e060b62
Readback : 0.00019802614316341135 == 3f29f4a79e060b63
Written  : 0.00088849244302999252 == 3f4d1d36fe26bb02
Readback : 0.00088849244302999263 == 3f4d1d36fe26bb03
Written  : 0.00019924763045223200 == 3f2a1da41cfa640b
Readback : 0.00019924763045223198 == 3f2a1da41cfa640a
Written  : 0.00019598391478348111 == 3f29b0210252afe4
Readback : 0.00019598391478348109 == 3f29b0210252afe3
Written  : 0.00016326636684508482 == 3f25664f698ab514
Readback : 0.00016326636684508485 == 3f25664f698ab515
Written  : 0.00090754569513847158 == 3f4dbd0b8a457a8c
Readback : 0.00090754569513847147 == 3f4dbd0b8a457a8b
Written  : 0.00089591579838574776 == 3f4d5b7c86eaab27
Readback : 0.00089591579838574765 == 3f4d5b7c86eaab26
Written  : 0.0035313592817288321 == 3f6cedcc1403b29f
Readback : 0.0035313592817288316 == 3f6cedcc1403b29e
Written  : 0.00020823640580055149 == 3f2b4b411b020ab9
Readback : 0.00020823640580055152 == 3f2b4b411b020aba
Written  : 0.00023425889633983332 == 3f2eb46c98df0981
Readback : 0.00023425889633983335 == 3f2eb46c98df0982
Written  : 0.00015255948214028039 == 3f23ff0bf914d9af
Readback : 0.00015255948214028036 == 3f23ff0bf914d9ae
Written  : 0.00019871341307086960 == 3f2a0bb738886f9c
Readback : 0.00019871341307086963 == 3f2a0bb738886f9d
Written  : 0.00078196043513568774 == 3f499f8f3f723c6f
Readback : 0.00078196043513568785 == 3f499f8f3f723c70
Written  : 0.0037625976559391215 == 3f6ed2bd3c2b210f
Readback : 0.0037625976559391211 == 3f6ed2bd3c2b210e
Written  : 0.0035151508014359570 == 3f6ccbce37721427
Readback : 0.0035151508014359565 == 3f6ccbce37721426
Written  : 0.00096725569172383217 == 3f4fb1edc80a9b89
Readback : 0.00096725569172383227 == 3f4fb1edc80a9b8a
Written  : 0.00017639536592640190 == 3f271ed8a7d800d4
Readback : 0.00017639536592640193 == 3f271ed8a7d800d5
Written  : 0.00018790731581742664 == 3f28a11f8d5ef1b0
Readback : 0.00018790731581742662 == 3f28a11f8d5ef1af
Written  : 0.00022021966148646005 == 3f2cdd587cf04281
Readback : 0.00022021966148646008 == 3f2cdd587cf04282
Written  : 0.0033384202556532485 == 3f6b592cba2fcc2c
Readback : 0.0033384202556532481 == 3f6b592cba2fcc2b
Written  : 0.00071988803506794965 == 3f4796dbc8a083f9
Readback : 0.00071988803506794975 == 3f4796dbc8a083fa
Written  : 0.00015932725627026015 == 3f24e222b5c816a1
Readback : 0.00015932725627026018 == 3f24e222b5c816a2
Written  : 0.00018153823070834291 == 3f27cb69871972f4
Readback : 0.00018153823070834289 == 3f27cb69871972f3
Written  : 0.00023264867585522607 == 3f2e7e64e8943abc
Readback : 0.00023264867585522610 == 3f2e7e64e8943abd
Written  : 0.00018929936448675871 == 3f28cfd528c48139
Readback : 0.00018929936448675873 == 3f28cfd528c4813a
Written  : 0.0032264004696450940 == 3f6a6e4090079347
Readback : 0.0032264004696450936 == 3f6a6e4090079346
Written  : 0.00065741870789770736 == 3f458ad3ecd35410
Readback : 0.00065741870789770747 == 3f458ad3ecd35411
Written  : 0.00052412301534474233 == 3f412ca99ae0d70f
Readback : 0.00052412301534474222 == 3f412ca99ae0d70e
Written  : 0.00093593197577407339 == 3f4eab2a9d15e1fe
Readback : 0.00093593197577407328 == 3f4eab2a9d15e1fd
Written  : 0.00082637014017823826 == 3f4b14185cfc868c
Readback : 0.00082637014017823815 == 3f4b14185cfc868b
Written  : 0.00076533894712619806 == 3f491420dfc70d63
Readback : 0.00076533894712619796 == 3f491420dfc70d62
Written  : 0.00021540502832331001 == 3f2c3bcb1aa552e2
Readback : 0.00021540502832331003 == 3f2c3bcb1aa552e3
Written  : 0.00096733128448385714 == 3f4fb2901d99ca94
Readback : 0.00096733128448385725 == 3f4fb2901d99ca95
Written  : 0.00016132284372302906 == 3f252518acffac3d
Readback : 0.00016132284372302909 == 3f252518acffac3e
Written  : 0.00020924253843049737 == 3f2b6d03b80f34a1
Readback : 0.00020924253843049740 == 3f2b6d03b80f34a2
Written  : 0.00020132307330723981 == 3f2a63480814f22f
Readback : 0.00020132307330723983 == 3f2a63480814f230
Written  : 0.0033068547907347933 == 3f6b16fa25b8f31c
Readback : 0.0033068547907347929 == 3f6b16fa25b8f31b
Written  : 0.00095405692653998612 == 3f4f4335a6253dc7
Readback : 0.00095405692653998601 == 3f4f4335a6253dc6
Written  : 0.00077286680350885590 == 3f495346d2970c14
Readback : 0.00077286680350885600 == 3f495346d2970c15
Written  : 0.0034892573424557278 == 3f6c9580c58aa6c4
Readback : 0.0034892573424557282 == 3f6c9580c58aa6c5
Written  : 0.00020590558168439115 == 3f2afd0b7a926a89
Readback : 0.00020590558168439118 == 3f2afd0b7a926a8a
Written  : 0.00059098239019297883 == 3f435d8504e9fcff
Readback : 0.00059098239019297872 == 3f435d8504e9fcfe
Written  : 0.00018511436625905252 == 3f2843684c572639
Readback : 0.00018511436625905250 == 3f2843684c572638
Written  : 0.00080943843935340966 == 3f4a860fd004daf9
Readback : 0.00080943843935340977 == 3f4a860fd004dafa
Written  : 0.00088447132426708850 == 3f4cfb7bb4bba931
Readback : 0.00088447132426708840 == 3f4cfb7bb4bba930
Written  : 0.00017208070291718430 == 3f268e11fb8bef7f
Readback : 0.00017208070291718428 == 3f268e11fb8bef7e
Written  : 0.00092849405645115894 == 3f4e6cc5cdb1c947
Readback : 0.00092849405645115883 == 3f4e6cc5cdb1c946
Written  : 0.0034592219358425898 == 3f6c5683a2b08911
Readback : 0.0034592219358425902 == 3f6c5683a2b08912
Written  : 0.00023203241680285787 == 3f2e69b74897673e
Readback : 0.00023203241680285784 == 3f2e69b74897673d
Written  : 0.00022196153569538186 == 3f2d17cb12d509c1
Readback : 0.00022196153569538189 == 3f2d17cb12d509c2
Written  : 0.00063431911958599133 == 3f44c90defda4b9d
Readback : 0.00063431911958599144 == 3f44c90defda4b9e
Written  : 0.0037638737077679740 == 3f6ed56a4f657ae9
Readback : 0.0037638737077679745 == 3f6ed56a4f657aea
Written  : 0.00061504945223238999 == 3f442768a43181c1
Readback : 0.00061504945223239010 == 3f442768a43181c2
Written  : 0.0035838478206341711 == 3f6d5bdfa5def13c
Readback : 0.0035838478206341707 == 3f6d5bdfa5def13b
Written  : 0.00083764524147593433 == 3f4b72ad757a1d7f
Readback : 0.00083764524147593423 == 3f4b72ad757a1d7e
Written  : 0.00079192578007443427 == 3f49f327a9c3827e
Readback : 0.00079192578007443416 == 3f49f327a9c3827d
Written  : 0.0034557490373110932 == 3f6c4f3b23266061
Readback : 0.0034557490373110936 == 3f6c4f3b23266062
Written  : 0.00021941537068616019 == 3f2cc25baec3b19c
Readback : 0.00021941537068616022 == 3f2cc25baec3b19d
Written  : 0.00020096821022925441 == 3f2a575fc7ebb924
Readback : 0.00020096821022925438 == 3f2a575fc7ebb923
Written  : 0.00051710656333360863 == 3f40f1cde397a09f
Readback : 0.00051710656333360853 == 3f40f1cde397a09e
Written  : 0.0031346363431720143 == 3f69adcf128556ff
Readback : 0.0031346363431720139 == 3f69adcf128556fe
Written  : 0.00016662035269668926 == 3f25d6d9ee6da4d0
Readback : 0.00016662035269668924 == 3f25d6d9ee6da4cf
Written  : 0.00019458251098454732 == 3f29811b0ac75a54
Readback : 0.00019458251098454735 == 3f29811b0ac75a55
Written  : 0.00096966886421624178 == 3f4fc62c07a6284f
Readback : 0.00096966886421624189 == 3f4fc62c07a62850
Written  : 0.00024358642683387180 == 3f2fed6779583124
Readback : 0.00024358642683387178 == 3f2fed6779583123
Written  : 0.00017919802894123991 == 3f277ce358fda974
Readback : 0.00017919802894123994 == 3f277ce358fda975
Written  : 0.0036033268793698313 == 3f6d84b963517021
Readback : 0.0036033268793698317 == 3f6d84b963517022
Written  : 0.00086500444855590059 == 3f4c582ee8a1f167
Readback : 0.00086500444855590049 == 3f4c582ee8a1f166
Written  : 0.00063009943619097761 == 3f44a5a83c5fa05f
Readback : 0.00063009943619097750 == 3f44a5a83c5fa05e
Written  : 0.0033443859976652504 == 3f6b65af8f8688a7
Readback : 0.0033443859976652500 == 3f6b65af8f8688a6
Written  : 0.0032794219525686206 == 3f6add7241277554
Readback : 0.0032794219525686210 == 3f6add7241277555
Written  : 0.00067709742851327877 == 3f462fe7a7e4cf63
Readback : 0.00067709742851327867 == 3f462fe7a7e4cf62
Written  : 0.00096332548831593338 == 3f4f90f5bbde411c
Readback : 0.00096332548831593349 == 3f4f90f5bbde411d
Written  : 0.00016061730434104826 == 3f250d6c237d7327
Readback : 0.00016061730434104824 == 3f250d6c237d7326
Written  : 0.00082084196225670053 == 3f4ae5b8b108aabf
Readback : 0.00082084196225670042 == 3f4ae5b8b108aabe
Written  : 0.0032398106134704512 == 3f6a8a601429b101
Readback : 0.0032398106134704516 == 3f6a8a601429b102
Written  : 0.0037269855474910784 == 3f6e880e2140a017
Readback : 0.0037269855474910780 == 3f6e880e2140a016
Written  : 0.00023530102823786988 == 3f2ed76471267ee4
Readback : 0.00023530102823786985 == 3f2ed76471267ee3
Written  : 0.00072044787389393165 == 3f479b8e0746c49d
Readback : 0.00072044787389393176 == 3f479b8e0746c49e
Written  : 0.00012371664495481333 == 3f20373de35ac0cf
Readback : 0.00012371664495481330 == 3f20373de35ac0ce
Written  : 0.00094744091229783224 == 3f4f0bb5ddd9e0a4
Readback : 0.00094744091229783214 == 3f4f0bb5ddd9e0a3
Written  : 0.00023207539747733348 == 3f2e6b287c1818ec
Readback : 0.00023207539747733345 == 3f2e6b287c1818eb
Written  : 0.00088022623879351622 == 3f4cd7df745041b4
Readback : 0.00088022623879351633 == 3f4cd7df745041b5
Written  : 0.00077384608048711504 == 3f495b7dcdcd5f1f
Readback : 0.00077384608048711493 == 3f495b7dcdcd5f1e
Written  : 0.00023775134692874246 == 3f2f299c84ef63c7
Readback : 0.00023775134692874248 == 3f2f299c84ef63c8
Written  : 0.00016120475224705650 == 3f2521224718c64c
Readback : 0.00016120475224705647 == 3f2521224718c64b
Written  : 0.00024022431919320313 == 3f2f7c9730747ae7
Readback : 0.00024022431919320316 == 3f2f7c9730747ae8
Written  : 0.00063641490397502479 == 3f44daa29981579d
Readback : 0.00063641490397502490 == 3f44daa29981579e
Written  : 0.00024341067457374322 == 3f2fe781c60989f4
Readback : 0.00024341067457374325 == 3f2fe781c60989f5
Written  : 0.00020408138273921188 == 3f2abfd5baab323f
Readback : 0.00020408138273921185 == 3f2abfd5baab323e
Written  : 0.0037103735187365501 == 3f6e65379d67c691
Readback : 0.0037103735187365506 == 3f6e65379d67c692
Written  : 0.00087355547234628419 == 3f4c9fea17ad1177
Readback : 0.00087355547234628408 == 3f4c9fea17ad1176
Written  : 0.00076546659259469317 == 3f491532fd9db030
Readback : 0.00076546659259469306 == 3f491532fd9db02f
Written  : 0.00085268387541926108 == 3f4bf0d4adeb981e
Readback : 0.00085268387541926097 == 3f4bf0d4adeb981d
Written  : 0.00015482349093086809 == 3f244b03a9100e9f
Readback : 0.00015482349093086807 == 3f244b03a9100e9e
Written  : 0.00018527407818129309 == 3f2848c4369255e1
Readback : 0.00018527407818129312 == 3f2848c4369255e2
Written  : 0.00021470145753582938 == 3f2c242f7a1f486f
Readback : 0.00021470145753582940 == 3f2c242f7a1f4870
Written  : 0.00020655987181552075 == 3f2b12ffc9c94274
Readback : 0.00020655987181552078 == 3f2b12ffc9c94275
Written  : 0.00049440575546990707 == 3f403360467d40d1
Readback : 0.00049440575546990718 == 3f403360467d40d2
Written  : 0.0032293864927778683 == 3f6a7483abec8b71
Readback : 0.0032293864927778687 == 3f6a7483abec8b72
Written  : 0.00090288905470774965 == 3f4d95fb7b1f15c4
Readback : 0.00090288905470774954 == 3f4d95fb7b1f15c3
Written  : 0.0038321207567506249 == 3f6f648a2a62d9b7
Readback : 0.0038321207567506245 == 3f6f648a2a62d9b6
Written  : 0.0033241770477678745 == 3f6b3b4df699d1e9
Readback : 0.0033241770477678749 == 3f6b3b4df699d1ea
Written  : 0.0034275999723808142 == 3f6c1432b91feab7
Readback : 0.0034275999723808138 == 3f6c1432b91feab6
Written  : 0.00015684815115953843 == 3f248ef35bfd7b27
Readback : 0.00015684815115953840 == 3f248ef35bfd7b26
Written  : 0.0032254957302272004 == 3f6a6c5ad59740b1
Readback : 0.0032254957302272009 == 3f6a6c5ad59740b2
Written  : 0.0032194224891415840 == 3f6a5f9e49b11c77
Readback : 0.0032194224891415836 == 3f6a5f9e49b11c76
Written  : 0.00019427976606761635 == 3f2976f27baa77d0
Readback : 0.00019427976606761633 == 3f2976f27baa77cf
Written  : 0.00022098234778023142 == 3f2cf6efe9d5d03e
Readback : 0.00022098234778023139 == 3f2cf6efe9d5d03d
Written  : 0.00057808658741247316 == 3f42f1577e5c5591
Readback : 0.00057808658741247327 == 3f42f1577e5c5592
Written  : 0.00022289558577200843 == 3f2d372280ac2b0f
Readback : 0.00022289558577200845 == 3f2d372280ac2b10
Written  : 0.00070590166145166275 == 3f472188466a8f61
Readback : 0.00070590166145166285 == 3f472188466a8f62
Written  : 0.00020536883896563106 == 3f2aeb08e4d9e414
Readback : 0.00020536883896563109 == 3f2aeb08e4d9e415
Written  : 0.00066021554908280702 == 3f45a24a18870c4c
Readback : 0.00066021554908280691 == 3f45a24a18870c4b
Written  : 0.00066786307330028748 == 3f45e271076d8d83
Readback : 0.00066786307330028737 == 3f45e271076d8d82
Written  : 0.00092755025222501515 == 3f4e64daffd57fe7
Readback : 0.00092755025222501504 == 3f4e64daffd57fe6
Written  : 0.00078432019852723428 == 3f49b35acd17133f
Readback : 0.00078432019852723417 == 3f49b35acd17133e
Written  : 0.00021545963613277760 == 3f2c3da02e7d1eb7
Readback : 0.00021545963613277757 == 3f2c3da02e7d1eb6
Written  : 0.00089111970490054907 == 3f4d3340fea3a4f4
Readback : 0.00089111970490054918 == 3f4d3340fea3a4f5
Written  : 0.00080545066962314999 == 3f4a649c246ce114
Readback : 0.00080545066962315010 == 3f4a649c246ce115
Written  : 0.00085015400317150342 == 3f4bdb9bd1f195bf
Readback : 0.00085015400317150331 == 3f4bdb9bd1f195be
Written  : 0.00094293842099203099 == 3f4ee5f0d7142847
Readback : 0.00094293842099203089 == 3f4ee5f0d7142846
Written  : 0.00023765538138906725 == 3f2f26642e7b4caf
Readback : 0.00023765538138906727 == 3f2f26642e7b4cb0
Written  : 0.00074440417148540806 == 3f486483c92815d0
Readback : 0.00074440417148540796 == 3f486483c92815cf
Written  : 0.0038237941003535082 == 3f6f5313d371eb1f
Readback : 0.0038237941003535078 == 3f6f5313d371eb1e
Written  : 0.00017649576718942588 == 3f272237188e5895
Readback : 0.00017649576718942590 == 3f272237188e5896
Written  : 0.00089807373682573670 == 3f4d6d96aa1ebcef
Readback : 0.00089807373682573681 == 3f4d6d96aa1ebcf0
Written  : 0.00023317792658603646 == 3f2e9027233e7cc2
Readback : 0.00023317792658603649 == 3f2e9027233e7cc3
Written  : 0.00084026880804534247 == 3f4b88af8673a071
Readback : 0.00084026880804534236 == 3f4b88af8673a070
Written  : 0.0035277038139131054 == 3f6ce6219057e914
Readback : 0.0035277038139131050 == 3f6ce6219057e913
Written  : 0.00072544190730801936 == 3f47c572a22e3ab4
Readback : 0.00072544190730801947 == 3f47c572a22e3ab5
Written  : 0.0031690668252247613 == 3f69f603cbf114df
Readback : 0.0031690668252247608 == 3f69f603cbf114de
Written  : 0.00076295283404397040 == 3f49001cbc3ced83
Readback : 0.00076295283404397029 == 3f49001cbc3ced82
Written  : 0.0033311011159623638 == 3f6b49d34b498b17
Readback : 0.0033311011159623634 == 3f6b49d34b498b16
Written  : 0.00066971047600893031 == 3f45f1f04bcebf7d
Readback : 0.00066971047600893042 == 3f45f1f04bcebf7e
Written  : 0.0035627820997158302 == 3f6d2fb2133bd4f9
Readback : 0.0035627820997158307 == 3f6d2fb2133bd4fa
Written  : 0.00022404635294088731 == 3f2d5dbf8470498f
Readback : 0.00022404635294088733 == 3f2d5dbf84704990
Written  : 0.00022453519557891880 == 3f2d6e26a4c498f7
Readback : 0.00022453519557891877 == 3f2d6e26a4c498f6
Written  : 0.00075813324252513780 == 3f48d7aebdc7ab2c
Readback : 0.00075813324252513770 == 3f48d7aebdc7ab2b
Written  : 0.00074462251264502020 == 3f486658ab7a7e5d
Readback : 0.00074462251264502031 == 3f486658ab7a7e5e
Written  : 0.0036703302556258480 == 3f6e113d8d3ad674
Readback : 0.0036703302556258476 == 3f6e113d8d3ad673
Written  : 0.00075781149505275969 == 3f48d4fbcb3c857f
Readback : 0.00075781149505275958 == 3f48d4fbcb3c857e
Written  : 0.00082364654836980424 == 3f4afd3f7e8e19f7
Readback : 0.00082364654836980414 == 3f4afd3f7e8e19f6
Written  : 0.00062737331636451138 == 3f448ec9f0264b3f
Readback : 0.00062737331636451127 == 3f448ec9f0264b3e
Written  : 0.00015941074282135428 == 3f24e4efdaa6235d
Readback : 0.00015941074282135431 == 3f24e4efdaa6235e
Written  : 0.00064340577808294833 == 3f4515476330b31f
Readback : 0.00064340577808294822 == 3f4515476330b31e
Written  : 0.0036072836014186742 == 3f6d8d05a30e41af
Readback : 0.0036072836014186737 == 3f6d8d05a30e41ae
Written  : 0.00019216386129215291 == 3f292ff2ffdbad4c
Readback : 0.00019216386129215288 == 3f292ff2ffdbad4b
Written  : 0.00023626396034692363 == 3f2ef7b3f7406f74
Readback : 0.00023626396034692366 == 3f2ef7b3f7406f75
Written  : 0.00015650964276067283 == 3f24839798261b61
Readback : 0.00015650964276067285 == 3f24839798261b62
Written  : 0.00018544461483707000 == 3f284e7d1ca4c2ff
Readback : 0.00018544461483706998 == 3f284e7d1ca4c2fe
Written  : 0.00022926384375401390 == 3f2e0cd16c128359
Readback : 0.00022926384375401393 == 3f2e0cd16c12835a
Written  : 0.00066230251147816465 == 3f45b3cbd03cdcd9
Readback : 0.00066230251147816476 == 3f45b3cbd03cdcda
Written  : 0.00020415350487048626 == 3f2ac24140e9a349
Readback : 0.00020415350487048629 == 3f2ac24140e9a34a
Written  : 0.00089875568129778739 == 3f4d734f210eeea7
Readback : 0.00089875568129778728 == 3f4d734f210eeea6
Written  : 0.00049832494059923193 == 3f405440a94cc101
Readback : 0.00049832494059923204 == 3f405440a94cc102
Written  : 0.00076868944075983100 == 3f49303c0121cce1
Readback : 0.00076868944075983111 == 3f49303c0121cce2
Written  : 0.00080294881756089946 == 3f4a4f9f74b566c7
Readback : 0.00080294881756089935 == 3f4a4f9f74b566c6
Written  : 0.00096227235294930348 == 3f4f88202493db4f
Readback : 0.00096227235294930359 == 3f4f88202493db50
Written  : 0.00083670250128078775 == 3f4b6ac4f092e0f1
Readback : 0.00083670250128078764 == 3f4b6ac4f092e0f0
Written  : 0.00021905631316784083 == 3f2cb64f66ee7af7
Readback : 0.00021905631316784081 == 3f2cb64f66ee7af6
Written  : 0.00064826217675530162 == 3f453e046c984c81
Readback : 0.00064826217675530173 == 3f453e046c984c82
Written  : 0.00017067643909220617 == 3f265ef372bd12a7
Readback : 0.00017067643909220615 == 3f265ef372bd12a6
Written  : 0.00020992702137190468 == 3f2b83fb61f73042
Readback : 0.00020992702137190470 == 3f2b83fb61f73043
Written  : 0.00023879624106543099 == 3f2f4cac1770f801
Readback : 0.00023879624106543101 == 3f2f4cac1770f802
Written  : 0.00081456087251418501 == 3f4ab108276e2bc2
Readback : 0.00081456087251418512 == 3f4ab108276e2bc3
Written  : 0.0038583486403003246 == 3f6f9b8b2740c401
Readback : 0.0038583486403003251 == 3f6f9b8b2740c402
Written  : 0.00016506510710660372 == 3f25a2aa7935257d
Readback : 0.00016506510710660374 == 3f25a2aa7935257e
Written  : 0.0032572080982153115 == 3f6aaedc48425d47
Readback : 0.0032572080982153110 == 3f6aaedc48425d46
Written  : 0.00021725284753612020 == 3f2c79cbc0111b34
Readback : 0.00021725284753612022 == 3f2c79cbc0111b35
Written  : 0.00017124867487481181 == 3f267226ea883c99
Readback : 0.00017124867487481183 == 3f267226ea883c9a
Written  : 0.00022602624787903825 == 3f2da02eaf737f9e
Readback : 0.00022602624787903823 == 3f2da02eaf737f9d
Written  : 0.00021744524520785232 == 3f2c80406f05723c
Readback : 0.00021744524520785234 == 3f2c80406f05723d
Written  : 0.00021978440987386260 == 3f2ccebdb48538b4
Readback : 0.00021978440987386263 == 3f2ccebdb48538b5
Written  : 0.00013142582988349150 == 3f2139eb484b44d1
Readback : 0.00013142582988349153 == 3f2139eb484b44d2
Written  : 0.0038668357767432907 == 3f6fad57a66757f9
Readback : 0.0038668357767432911 == 3f6fad57a66757fa
Written  : 0.00063651908208592009 == 3f44db82520702e1
Readback : 0.00063651908208592020 == 3f44db82520702e2
Written  : 0.0033778101672543772 == 3f6babc8066a1e2c
Readback : 0.0033778101672543768 == 3f6babc8066a1e2b
Written  : 0.00014566114630038628 == 3f231793b82518ed
Readback : 0.00014566114630038630 == 3f231793b82518ee
Written  : 0.00080095497997575331 == 3f4a3ee5b8e77ac4
Readback : 0.00080095497997575320 == 3f4a3ee5b8e77ac3
Written  : 0.0037638876803541294 == 3f6ed571cfc62684
Readback : 0.0037638876803541290 == 3f6ed571cfc62683
Written  : 0.00079653668810584057 == 3f4a19d58342e324
Readback : 0.00079653668810584046 == 3f4a19d58342e323
Written  : 0.00096494126959624288 == 3f4f9e839905606c
Readback : 0.00096494126959624277 == 3f4f9e839905606b
Written  : 0.0034916529917186304 == 3f6c9a86ed11b634
Readback : 0.0034916529917186300 == 3f6c9a86ed11b633
Written  : 0.00016187920409907930 == 3f2537c3c66774ac
Readback : 0.00016187920409907927 == 3f2537c3c66774ab
Written  : 0.00082388930449203343 == 3f4aff48cf2506df
Readback : 0.00082388930449203332 == 3f4aff48cf2506de
Written  : 0.00074408571935458752 == 3f4861d7ea3f0839
Readback : 0.00074408571935458763 == 3f4861d7ea3f083a
Written  : 0.0038669144345621059 == 3f6fad81e10d4efc
Readback : 0.0038669144345621063 == 3f6fad81e10d4efd
Written  : 0.0036902478431234324 == 3f6e3b02b99c76ef
Readback : 0.0036902478431234320 == 3f6e3b02b99c76ee
Written  : 0.00057457675660577145 == 3f42d3e630780c01
Readback : 0.00057457675660577156 == 3f42d3e630780c02
Written  : 0.00095813560280457149 == 3f4f656c8a228897
Readback : 0.00095813560280457138 == 3f4f656c8a228896
Written  : 0.00014588348127912706 == 3f231f098fef05ff
Readback : 0.00014588348127912704 == 3f231f098fef05fe
Written  : 0.00012516325965226436 == 3f2067c836b74d43
Readback : 0.00012516325965226434 == 3f2067c836b74d42
Written  : 0.00063673538526534896 == 3f44dd52d3f53514
Readback : 0.00063673538526534906 == 3f44dd52d3f53515
Written  : 0.00017440340962337640 == 3f26dc01e19bff6c
Readback : 0.00017440340962337637 == 3f26dc01e19bff6b
Written  : 0.00053375535300263603 == 3f417d76e481cd6f
Readback : 0.00053375535300263593 == 3f417d76e481cd6e
Written  : 0.00085950939999956629 == 3f4c2a1661bdbbe2
Readback : 0.00085950939999956640 == 3f4c2a1661bdbbe3
Written  : 0.00083530727495426712 == 3f4b5f10b6c9ff37
Readback : 0.00083530727495426701 == 3f4b5f10b6c9ff36
Written  : 0.0038254079339012999 == 3f6f56763f09f411
Readback : 0.0038254079339013003 == 3f6f56763f09f412
Written  : 0.00076638820000202504 == 3f491cee20a5721f
Readback : 0.00076638820000202493 == 3f491cee20a5721e
Written  : 0.00063970396016404954 == 3f44f639cb4471f4
Readback : 0.00063970396016404965 == 3f44f639cb4471f5
Written  : 0.00072320511144248164 == 3f47b2af26a62663
Readback : 0.00072320511144248153 == 3f47b2af26a62662
Written  : 0.00076731960769474200 == 3f4924be4f70c0ec
Readback : 0.00076731960769474189 == 3f4924be4f70c0eb
Written  : 0.00020926027260049698 == 3f2b6d9c0de9617e
Readback : 0.00020926027260049696 == 3f2b6d9c0de9617d
Written  : 0.00062563455439143762 == 3f448033f9a55b14
Readback : 0.00062563455439143773 == 3f448033f9a55b15
Written  : 0.0032818983072373628 == 3f6ae2a3bcbf8c19
Readback : 0.0032818983072373633 == 3f6ae2a3bcbf8c1a
Written  : 0.00075746212735091224 == 3f48d20d884fa6a7
Readback : 0.00075746212735091213 == 3f48d20d884fa6a6
Written  : 0.00021524340272342953 == 3f2c365ec031663c
Readback : 0.00021524340272342955 == 3f2c365ec031663d
Written  : 0.00078618108800528378 == 3f49c2f707e6529e
Readback : 0.00078618108800528367 == 3f49c2f707e6529d
Written  : 0.0036118782880369803 == 3f6d96a863f9dddc
Readback : 0.0036118782880369799 == 3f6d96a863f9dddb
Written  : 0.00024396488436645837 == 3f2ffa1a66428894
Readback : 0.00024396488436645840 == 3f2ffa1a66428895
Written  : 0.00091256694447280917 == 3f4de72a97493301
Readback : 0.00091256694447280928 == 3f4de72a97493302
Written  : 0.00076164104417588872 == 3f48f51bb021a4dd
Readback : 0.00076164104417588883 == 3f48f51bb021a4de
Written  : 0.0035936074212835792 == 3f6d70574b2ba127
Readback : 0.0035936074212835787 == 3f6d70574b2ba126
Written  : 0.00078106438812228750 == 3f49980b00641f30
Readback : 0.00078106438812228761 == 3f49980b00641f31
Written  : 0.00017078625870011428 == 3f2662a2ca9c3abf
Readback : 0.00017078625870011426 == 3f2662a2ca9c3abe
Written  : 0.00021827589379147698 == 3f2c9c1fa692e83f
Readback : 0.00021827589379147695 == 3f2c9c1fa692e83e
Written  : 0.00071417253046742260 == 3f4766e9d4be5aa1
Readback : 0.00071417253046742271 == 3f4766e9d4be5aa2
Written  : 0.00019400610657286114 == 3f296dc3c412a46c
Readback : 0.00019400610657286112 == 3f296dc3c412a46b
Written  : 0.00023755285206493728 == 3f2f22f3761d0e67
Readback : 0.00023755285206493730 == 3f2f22f3761d0e68
Written  : 0.00022876203956403624 == 3f2dfbfaf4fd2377
Readback : 0.00022876203956403621 == 3f2dfbfaf4fd2376
Written  : 0.00016971599883851184 == 3f263eb95448fddf
Readback : 0.00016971599883851182 == 3f263eb95448fdde
Written  : 0.00083581304495050277 == 3f4b634ed8c8f3df
Readback : 0.00083581304495050266 == 3f4b634ed8c8f3de
Written  : 0.00019339310328498371 == 3f2959321b9648d9
Readback : 0.00019339310328498368 == 3f2959321b9648d8
Written  : 0.00023854039429575116 == 3f2f44166271e4ff
Readback : 0.00023854039429575114 == 3f2f44166271e4fe
Written  : 0.00013420885051452852 == 3f21974d3f61e1b4
Readback : 0.00013420885051452854 == 3f21974d3f61e1b5
Written  : 0.00088804540216463012 == 3f4d1976fad625af
Readback : 0.00088804540216463022 == 3f4d1976fad625b0
Written  : 0.0035364905525979147 == 3f6cf88ee8833e7f
Readback : 0.0035364905525979142 == 3f6cf88ee8833e7e
Written  : 0.0036097539953335550 == 3f6d9233eb68f6b7
Readback : 0.0036097539953335546 == 3f6d9233eb68f6b6
Written  : 0.00019269117470355516 == 3f2941a496501074
Readback : 0.00019269117470355519 == 3f2941a496501075
Written  : 0.00022000281750653766 == 3f2cd611cffbdcdf
Readback : 0.00022000281750653763 == 3f2cd611cffbdcde
Written  : 0.0035593847370562360 == 3f6d28922143e564
Readback : 0.0035593847370562364 == 3f6d28922143e565
Written  : 0.0031407610707113345 == 3f69baa742aa06a7
Readback : 0.0031407610707113341 == 3f69baa742aa06a6
Written  : 0.0031460896567865227 == 3f69c5d405f533e9
Readback : 0.0031460896567865231 == 3f69c5d405f533ea
Written  : 0.00090475757704100456 == 3f4da5a81a233402
Readback : 0.00090475757704100467 == 3f4da5a81a233403
Written  : 0.00015830920030633543 == 3f24bff9ad0a9ddf
Readback : 0.00015830920030633541 == 3f24bff9ad0a9dde
Written  : 0.0032441308742493899 == 3f6a936f80487559
Readback : 0.0032441308742493903 == 3f6a936f8048755a
Written  : 0.00016433948519755089 == 3f258a516dc13e61
Readback : 0.00016433948519755092 == 3f258a516dc13e62
Written  : 0.00023955260814678673 == 3f2f660d3c3e2ff9
Readback : 0.00023955260814678675 == 3f2f660d3c3e2ffa
Written  : 0.00063771128985491427 == 3f44e582912e0467
Readback : 0.00063771128985491417 == 3f44e582912e0466
Written  : 0.00069493754655852898 == 3f46c58f04827610
Readback : 0.00069493754655852908 == 3f46c58f04827611
Written  : 0.00078831477425842173 == 3f49d4dd16528714
Readback : 0.00078831477425842184 == 3f49d4dd16528715
Written  : 0.00021809321612745446 == 3f2c95fe76247462
Readback : 0.00021809321612745449 == 3f2c95fe76247463
Written  : 0.00097481136614094028 == 3f4ff14f77fae6e7
Readback : 0.00097481136614094017 == 3f4ff14f77fae6e6
Written  : 0.00013469899408747593 == 3f21a7bf8c7f7131
Readback : 0.00013469899408747595 == 3f21a7bf8c7f7132
Written  : 0.00048884540014491700 == 3f4004bb80d2736f
Readback : 0.00048884540014491689 == 3f4004bb80d2736e
Written  : 0.00022297842108894245 == 3f2d39ea0d75fa54
Readback : 0.00022297842108894247 == 3f2d39ea0d75fa55
Written  : 0.00066804266387905783 == 3f45e3f2b2648a8c
Readback : 0.00066804266387905772 == 3f45e3f2b2648a8b
Written  : 0.00021332796031886430 == 3f2bf61939ccf7d9
Readback : 0.00021332796031886428 == 3f2bf61939ccf7d8
Written  : 0.00055813174847527288 == 3f4249f2cda3c70f
Readback : 0.00055813174847527277 == 3f4249f2cda3c70e
Written  : 0.0032285744185335512 == 3f6a72cfb14a2b3c
Readback : 0.0032285744185335508 == 3f6a72cfb14a2b3b
Written  : 0.00091127270416774514 == 3f4ddc4f3b275617
Readback : 0.00091127270416774503 == 3f4ddc4f3b275616
Written  : 0.00019166280567328961 == 3f291f22f6e66059
Readback : 0.00019166280567328963 == 3f291f22f6e6605a
Written  : 0.0032765220077726575 == 3f6ad75d5bc6b857
Readback : 0.0032765220077726571 == 3f6ad75d5bc6b856
Written  : 0.00023889850438181171 == 3f2f501a86da2979
Readback : 0.00023889850438181174 == 3f2f501a86da297a
Written  : 0.00013333160828283812 == 3f2179ddcb50698f
Readback : 0.00013333160828283810 == 3f2179ddcb50698e
Written  : 0.00017703556288020986 == 3f273453e7d55474
Readback : 0.00017703556288020984 == 3f273453e7d55473
Written  : 0.00016051772800082084 == 3f250a14c8cd5b5f
Readback : 0.00016051772800082081 == 3f250a14c8cd5b5e
Written  : 0.00090084538690401441 == 3f4d84d6bcdd5acc
Readback : 0.00090084538690401430 == 3f4d84d6bcdd5acb
Written  : 0.0034874261173245009 == 3f6c91a9a3e04184
Readback : 0.0034874261173245013 == 3f6c91a9a3e04185
Written  : 0.00080454880806018125 == 3f4a5d0b68c9a9ac
Readback : 0.00080454880806018114 == 3f4a5d0b68c9a9ab
Written  : 0.00083815507860830415 == 3f4b76f453679861
Readback : 0.00083815507860830426 == 3f4b76f453679862
Written  : 0.00087471355494553446 == 3f4ca9a10e51650c
Readback : 0.00087471355494553435 == 3f4ca9a10e51650b
Written  : 0.0038925814713968252 == 3f6fe355c3bbb814
Readback : 0.0038925814713968248 == 3f6fe355c3bbb813
Written  : 0.00024317222619800927 == 3f2fdf81848386ac
Readback : 0.00024317222619800924 == 3f2fdf81848386ab
Written  : 0.0033149855563787997 == 3f6b280751a4bc47
Readback : 0.0033149855563787993 == 3f6b280751a4bc46
Written  : 0.00023207428619937285 == 3f2e6b1ef05e389f
Readback : 0.00023207428619937282 == 3f2e6b1ef05e389e
Written  : 0.00074480654833208046 == 3f4867e3e22adbb4
Readback : 0.00074480654833208057 == 3f4867e3e22adbb5
Written  : 0.00020977283175748287 == 3f2b7ecee76aee84
Readback : 0.00020977283175748285 == 3f2b7ecee76aee83
Written  : 0.00019225085756738260 == 3f2932de4ab0c3ec
Readback : 0.00019225085756738262 == 3f2932de4ab0c3ed
Written  : 0.00069323957313937484 == 3f46b750a5c027c3
Readback : 0.00069323957313937473 == 3f46b750a5c027c2
Written  : 0.00089373337227852860 == 3f4d492dcd79d144
Readback : 0.00089373337227852850 == 3f4d492dcd79d143
Written  : 0.00095548644516875057 == 3f4f4f3384529c5c
Readback : 0.00095548644516875068 == 3f4f4f3384529c5d
Written  : 0.00022681550962862484 == 3f2dbaaa6464aa5e
Readback : 0.00022681550962862481 == 3f2dbaaa6464aa5d
Written  : 0.0035315581543119939 == 3f6cee36d8daa977
Readback : 0.0035315581543119935 == 3f6cee36d8daa976
Written  : 0.00067650850112826934 == 3f462af6f1a3d1f9
Readback : 0.00067650850112826945 == 3f462af6f1a3d1fa
Written  : 0.0032285701624095633 == 3f6a72cd68551e6c
Readback : 0.0032285701624095637 == 3f6a72cd68551e6d
Written  : 0.00024059449547189597 == 3f2f8902fab353f1
Readback : 0.00024059449547189594 == 3f2f8902fab353f0
Written  : 0.00066152064501565435 == 3f45ad3cc49ab321
Readback : 0.00066152064501565446 == 3f45ad3cc49ab322
Written  : 0.00084038432301184851 == 3f4b89a79779e157
Readback : 0.00084038432301184840 == 3f4b89a79779e156
Written  : 0.00023550451556525684 == 3f2ede386283f851
Readback : 0.00023550451556525681 == 3f2ede386283f850
Written  : 0.00079756124680664653 == 3f4a226dbc5d1c7e
Readback : 0.00079756124680664643 == 3f4a226dbc5d1c7d
Written  : 0.0038238875567612202 == 3f6f5345fffef104
Readback : 0.0038238875567612198 == 3f6f5345fffef103
Written  : 0.00073727473688253449 == 3f4828b57108aee7
Readback : 0.00073727473688253459 == 3f4828b57108aee8
Written  : 0.00090179780663025399 == 3f4d8cd40b257c57
Readback : 0.00090179780663025388 == 3f4d8cd40b257c56
Written  : 0.00050444534559341257 == 3f40879821875a31
Readback : 0.00050444534559341268 == 3f40879821875a32
Written  : 0.00013428063357894847 == 3f2199b5dc02a73f
Readback : 0.00013428063357894844 == 3f2199b5dc02a73e
Written  : 0.00087619832719288717 == 3f4cb615947e444f
Readback : 0.00087619832719288727 == 3f4cb615947e4450
Written  : 0.0032039415693260703 == 3f6a3f2708460b77
Readback : 0.0032039415693260699 == 3f6a3f2708460b76
Written  : 0.00093496712014266869 == 3f4ea3129a17b182
Readback : 0.00093496712014266880 == 3f4ea3129a17b183
Written  : 0.00018033389832528341 == 3f27a300642e807d
Readback : 0.00018033389832528343 == 3f27a300642e807e
Written  : 0.00093336218131983444 == 3f4e959c05a4cdc2
Readback : 0.00093336218131983455 == 3f4e959c05a4cdc3
Written  : 0.00078952780941916000 == 3f49df0a0f74562f
Readback : 0.00078952780941916011 == 3f49df0a0f745630
Written  : 0.0037296820380070430 == 3f6e8db5cc1645e7
Readback : 0.0037296820380070426 == 3f6e8db5cc1645e6
Written  : 0.00024392023567378909 == 3f2ff89adebf1334
Readback : 0.00024392023567378911 == 3f2ff89adebf1335
Written  : 0.00071951540651629339 == 3f4793bb91ea10e1
Readback : 0.00071951540651629350 == 3f4793bb91ea10e2
Written  : 0.00075459542221251554 == 3f48ba01547e9e23
Readback : 0.00075459542221251543 == 3f48ba01547e9e22
Written  : 0.0037460685585401217 == 3f6eb0133e51f33f
Readback : 0.0037460685585401212 == 3f6eb0133e51f33e
Written  : 0.00021757057534331980 == 3f2c847502e75eb4
Readback : 0.00021757057534331983 == 3f2c847502e75eb5
Written  : 0.0037950984617760382 == 3f6f16e5f8e8e1d1
Readback : 0.0037950984617760386 == 3f6f16e5f8e8e1d2
Written  : 0.00021670474915484416 == 3f2c67679efae589
Readback : 0.00021670474915484419 == 3f2c67679efae58a
Written  : 0.00088862772570332145 == 3f4d1e598296648f
Readback : 0.00088862772570332156 == 3f4d1e5982966490
Written  : 0.00022786849536491637 == 3f2dddff7883dd37
Readback : 0.00022786849536491634 == 3f2dddff7883dd36
Written  : 0.0035089267441422694 == 3f6cbec0b3865afc
Readback : 0.0035089267441422698 == 3f6cbec0b3865afd
Written  : 0.00021659914542298015 == 3f2c63dc7deaf671
Readback : 0.00021659914542298013 == 3f2c63dc7deaf670
Written  : 0.0032248448745816356 == 3f6a6afd68ac0b04
Readback : 0.0032248448745816360 == 3f6a6afd68ac0b05
Written  : 0.00064293322753727975 == 3f45115097c7c807
Readback : 0.00064293322753727965 == 3f45115097c7c806
Written  : 0.00078124183312623240 == 3f4999880fd04c59
Readback : 0.00078124183312623251 == 3f4999880fd04c5a
Written  : 0.0036049937112741614 == 3f6d883842f35e97
Readback : 0.0036049937112741610 == 3f6d883842f35e96
Written  : 0.00019749051610081970 == 3f29e2ae9da81b79
Readback : 0.00019749051610081972 == 3f29e2ae9da81b7a
Written  : 0.00021742225256652164 == 3f2c7f7aedab1481
Readback : 0.00021742225256652167 == 3f2c7f7aedab1482
Written  : 0.00064315951129779645 == 3f4513368897e45f
Readback : 0.00064315951129779634 == 3f4513368897e45e
Written  : 0.00084156422445420224 == 3f4b938d69276249
Readback : 0.00084156422445420234 == 3f4b938d6927624a
Written  : 0.00013303355851362748 == 3f216fdd90f0b7cd
Readback : 0.00013303355851362750 == 3f216fdd90f0b7ce
Written  : 0.00014477896760671692 == 3f22f9f9dcae9641
Readback : 0.00014477896760671695 == 3f22f9f9dcae9642
Written  : 0.00077153962282288996 == 3f494824b94ab5ec
Readback : 0.00077153962282288985 == 3f494824b94ab5eb
Written  : 0.0038511624837315409 == 3f6f8c791d6a2934
Readback : 0.0038511624837315405 == 3f6f8c791d6a2933
Written  : 0.0036245561496139121 == 3f6db13ec400e14f
Readback : 0.0036245561496139117 == 3f6db13ec400e14e
Written  : 0.00021510729510050105 == 3f2c31cd985d6957
Readback : 0.00021510729510050103 == 3f2c31cd985d6956
Written  : 0.00020501949928198338 == 3f2adf5016c340d5
Readback : 0.00020501949928198340 == 3f2adf5016c340d6
Written  : 0.00023863711169734138 == 3f2f47552e429d61
Readback : 0.00023863711169734141 == 3f2f47552e429d62
Written  : 0.00066863721682222871 == 3f45e8ef7d547514
Readback : 0.00066863721682222882 == 3f45e8ef7d547515
Written  : 0.00088913660205326055 == 3f4d229e5051c444
Readback : 0.00088913660205326044 == 3f4d229e5051c443
Written  : 0.0034612144496381047 == 3f6c5ab15bb34f17
Readback : 0.0034612144496381043 == 3f6c5ab15bb34f16
Written  : 0.0037038203847131498 == 3f6e57796d85f2c7
Readback : 0.0037038203847131494 == 3f6e57796d85f2c6
Written  : 0.0035829251954348639 == 3f6d59f0513aa1a1
Readback : 0.0035829251954348643 == 3f6d59f0513aa1a2
Written  : 0.00022579222976103810 == 3f2d98547c2adede
Readback : 0.00022579222976103807 == 3f2d98547c2adedd
Written  : 0.00096418964146659767 == 3f4f98357d163bb1
Readback : 0.00096418964146659757 == 3f4f98357d163bb0
Written  : 0.00016404041647126880 == 3f25804872abb6a1
Readback : 0.00016404041647126883 == 3f25804872abb6a2
Written  : 0.00081323241247940956 == 3f4aa5e34ecd7f07
Readback : 0.00081323241247940946 == 3f4aa5e34ecd7f06
Written  : 0.00016713608842523298 == 3f25e828114a0154
Readback : 0.00016713608842523300 == 3f25e828114a0155
Written  : 0.0037962648939582639 == 3f6f19583220cc44
Readback : 0.0037962648939582635 == 3f6f19583220cc43
Written  : 0.00015767848099247967 == 3f24aacfd69a4279
Readback : 0.00015767848099247970 == 3f24aacfd69a427a
Written  : 0.00080060096935352957 == 3f4a3bed7d81a81c
Readback : 0.00080060096935352968 == 3f4a3bed7d81a81d
Written  : 0.00016028734649729088 == 3f250259d284acf4
Readback : 0.00016028734649729091 == 3f250259d284acf5
Written  : 0.00093694759171980579 == 3f4eb3afa1db3802
Readback : 0.00093694759171980590 == 3f4eb3afa1db3803
Written  : 0.0031896592824891793 == 3f6a213349b7b239
Readback : 0.0031896592824891797 == 3f6a213349b7b23a
Written  : 0.00073529958546038300 == 3f481823d60e687d
Readback : 0.00073529958546038310 == 3f481823d60e687e
Written  : 0.00074934789346373717 == 3f488dfc590e7139
Readback : 0.00074934789346373727 == 3f488dfc590e713a
Written  : 0.0036327757726129129 == 3f6dc27ba462e829
Readback : 0.0036327757726129133 == 3f6dc27ba462e82a
Written  : 0.00013989004968174111 == 3f2255ee607870f1
Readback : 0.00013989004968174113 == 3f2255ee607870f2
Written  : 0.00057204690187084492 == 3f42bead5e1ebfdf
Readback : 0.00057204690187084481 == 3f42bead5e1ebfde
Written  : 0.00018431395776391296 == 3f28288cd77217ac
Readback : 0.00018431395776391293 == 3f28288cd77217ab
Written  : 0.00079121802487208258 == 3f49ed37c539f5d9
Readback : 0.00079121802487208269 == 3f49ed37c539f5da
Written  : 0.00079442413029444164 == 3f4a081cd452816c
Readback : 0.00079442413029444153 == 3f4a081cd452816b
Written  : 0.0035225834039031918 == 3f6cdb64908cdfd1
Readback : 0.0035225834039031923 == 3f6cdb64908cdfd2
Written  : 0.00021726283137854117 == 3f2c7a2182c4bb6c
Readback : 0.00021726283137854115 == 3f2c7a2182c4bb6b
Written  : 0.0038634457921403863 == 3f6fa63baa77b31c
Readback : 0.0038634457921403859 == 3f6fa63baa77b31b
Written  : 0.00016894205028963267 == 3f2624c1296d731d
Readback : 0.00016894205028963270 == 3f2624c1296d731e
Written  : 0.00075099906609939725 == 3f489bd636d006b0
Readback : 0.00075099906609939736 == 3f489bd636d006b1
Written  : 0.00022266520426936665 == 3f2d2f678a63fca4
Readback : 0.00022266520426936662 == 3f2d2f678a63fca3
Written  : 0.00091960325874362772 == 3f4e2230f5f6f3f7
Readback : 0.00091960325874362761 == 3f4e2230f5f6f3f6
Written  : 0.00079479453188516594 == 3f4a0b3842c01121
Readback : 0.00079479453188516604 == 3f4a0b3842c01122
Written  : 0.00076929815336449457 == 3f493557346ce930
Readback : 0.00076929815336449446 == 3f493557346ce92f
Written  : 0.00080884729816356547 == 3f4a811a58b68887
Readback : 0.00080884729816356536 == 3f4a811a58b68886
Written  : 0.00088204622777337529 == 3f4ce723d9d61dcc
Readback : 0.00088204622777337518 == 3f4ce723d9d61dcb
Written  : 0.00093393889681319558 == 3f4e9a728256d5c2
Readback : 0.00093393889681319569 == 3f4e9a728256d5c3
Written  : 0.00092726107329500046 == 3f4e626dfe09343e
Readback : 0.00092726107329500036 == 3f4e626dfe09343d
Written  : 0.00015859976463795391 == 3f24c9b99ac39134
Readback : 0.00015859976463795394 == 3f24c9b99ac39135
Written  : 0.00016214427955757620 == 3f2540a8c180783f
Readback : 0.00016214427955757617 == 3f2540a8c180783e
Written  : 0.00015681788746319347 == 3f248def656b0887
Readback : 0.00015681788746319350 == 3f248def656b0888
Written  : 0.00063469823557930200 == 3f44cc3c1512fd3f
Readback : 0.00063469823557930189 == 3f44cc3c1512fd3e
Written  : 0.00074017334022974314 == 3f484106251381f9
Readback : 0.00074017334022974304 == 3f484106251381f8
Written  : 0.00074049604848455209 == 3f4843bb27d0c2d4
Readback : 0.00074049604848455219 == 3f4843bb27d0c2d5
Written  : 0.00069159169584171972 == 3f46a97ddba02a63
Readback : 0.00069159169584171961 == 3f46a97ddba02a62
Written  : 0.00015643620326994659 == 3f248120c100392c
Readback : 0.00015643620326994656 == 3f248120c100392b
Written  : 0.00013918035042620721 == 3f223e1e1b4d9861
Readback : 0.00013918035042620724 == 3f223e1e1b4d9862
Written  : 0.00068698728841517056 == 3f4682ddf7df96a3
Readback : 0.00068698728841517045 == 3f4682ddf7df96a2
Written  : 0.00015991445851771031 == 3f24f5d6bd2df079
Readback : 0.00015991445851771033 == 3f24f5d6bd2df07a
Written  : 0.0037312264118698774 == 3f6e90f2ed36e844
Readback : 0.0037312264118698770 == 3f6e90f2ed36e843
Written  : 0.00064892738282709662 == 3f454398f18014fd
Readback : 0.00064892738282709673 == 3f454398f18014fe
Written  : 0.00017081228288131145 == 3f2663825663d27f
Readback : 0.00017081228288131142 == 3f2663825663d27e
Written  : 0.0034988534812150241 == 3f6ca9a0a8cf5fe4
Readback : 0.0034988534812150237 == 3f6ca9a0a8cf5fe3
Written  : 0.00070737113296649506 == 3f472ddbf0ecc46c
Readback : 0.00070737113296649495 == 3f472ddbf0ecc46b
Written  : 0.00019196117307364454 == 3f292925ebc08234
Readback : 0.00019196117307364457 == 3f292925ebc08235
Written  : 0.0033110990325678174 == 3f6b1fe0c1e0d677
Readback : 0.0033110990325678170 == 3f6b1fe0c1e0d676
Written  : 0.00093737371946124159 == 3f4eb742bc0f4459
Readback : 0.00093737371946124169 == 3f4eb742bc0f445a
Written  : 0.0036187325888720795 == 3f6da50843e8db89
Readback : 0.0036187325888720799 == 3f6da50843e8db8a
Written  : 0.00017107067204322679 == 3f266c2de22a7cb0
Readback : 0.00017107067204322681 == 3f266c2de22a7cb1
Written  : 0.00023989583971068416 == 3f2f7191926f189f
Readback : 0.00023989583971068413 == 3f2f7191926f189e
Written  : 0.0035721688407971482 == 3f6d43618b1abd11
Readback : 0.0035721688407971486 == 3f6d43618b1abd12
Written  : 0.00024231505381409641 == 3f2fc2be7681eda4
Readback : 0.00024231505381409638 == 3f2fc2be7681eda3
Written  : 0.0038043867343742388 == 3f6f2a6093600a29
Readback : 0.0038043867343742392 == 3f6f2a6093600a2a
Written  : 0.00021404961309872642 == 3f2c0e502d0bc724
Readback : 0.00021404961309872639 == 3f2c0e502d0bc723
Written  : 0.00068583170750754704 == 3f46792c608d0ee1
Readback : 0.00068583170750754715 == 3f46792c608d0ee2
Written  : 0.00083173744436003416 == 3f4b411e8faa4f82
Readback : 0.00083173744436003426 == 3f4b411e8faa4f83
Written  : 0.00090671488667082322 == 3f4db613647c7002
Readback : 0.00090671488667082333 == 3f4db613647c7003
Written  : 0.00014647793202811856 == 3f2332fbdaf47abd
Readback : 0.00014647793202811858 == 3f2332fbdaf47abe
Written  : 0.00087166812110475473 == 3f4c9015095bb0e9
Readback : 0.00087166812110475484 == 3f4c9015095bb0ea
Written  : 0.00074779527338081082 == 3f4880f61f2399e7
Readback : 0.00074779527338081071 == 3f4880f61f2399e6
Written  : 0.00015777580676036245 == 3f24ae13dc3ac187
Readback : 0.00015777580676036243 == 3f24ae13dc3ac186
Written  : 0.00022315755992322257 == 3f2d3fecd7ec644c
Readback : 0.00022315755992322259 == 3f2d3fecd7ec644d
Written  : 0.0031420791451470063 == 3f69bd6ae56f6954
Readback : 0.0031420791451470067 == 3f69bd6ae56f6955
Written  : 0.0031960902415968367 == 3f6a2eafe201d3fc
Readback : 0.0031960902415968371 == 3f6a2eafe201d3fd
Written  : 0.00020644629790966156 == 3f2b0f3032203f0c
Readback : 0.00020644629790966153 == 3f2b0f3032203f0b
Written  : 0.00019780295962365846 == 3f29ed2a7c3abc77
Readback : 0.00019780295962365844 == 3f29ed2a7c3abc76
Written  : 0.00080786916226343968 == 3f4a78e5d0d0adef
Readback : 0.00080786916226343979 == 3f4a78e5d0d0adf0
Written  : 0.00014643384007657047 == 3f2331811bba68c1
Readback : 0.00014643384007657049 == 3f2331811bba68c2
Written  : 0.00021369942156148966 == 3f2c02900db633b1
Readback : 0.00021369942156148963 == 3f2c02900db633b0
Written  : 0.00023634148773861677 == 3f2efa4debc9fa57
Readback : 0.00023634148773861674 == 3f2efa4debc9fa56
Written  : 0.0035586269180780910 == 3f6d26fb476afe37
Readback : 0.0035586269180780906 == 3f6d26fb476afe36
Written  : 0.0036637919375614374 == 3f6e038751a3396f
Readback : 0.0036637919375614369 == 3f6e038751a3396e
failed 704, out of 1000000, fraction 0.00070399999999999998
wrong min 0.00012371664495481333 == 3f20373de35ac0cf
wrong max 0.0039054581881726152 == 3f6ffe56e6360a7c
Initial output_value 0.0035648982583969379
Written  : 00.0035648982583969379 == 3f6d34222dde445c
Readback : 00.0035648982583969383 == 3f6d34222dde445d
Written  : 00.0035648982583969392 == 3f6d34222dde445f
Readback : 00.0035648982583969388 == 3f6d34222dde445e
Written  : 00.0035648982583969401 == 3f6d34222dde4461
Readback : 00.0035648982583969405 == 3f6d34222dde4462
Written  : 00.0035648982583969414 == 3f6d34222dde4464
Readback : 00.0035648982583969418 == 3f6d34222dde4465
Written  : 00.0035648982583969427 == 3f6d34222dde4467
Readback : 00.0035648982583969422 == 3f6d34222dde4466
Written  : 00.0035648982583969435 == 3f6d34222dde4469
Readback : 00.0035648982583969440 == 3f6d34222dde446a
Written  : 00.0035648982583969448 == 3f6d34222dde446c
Readback : 00.0035648982583969444 == 3f6d34222dde446b
Written  : 00.0035648982583969461 == 3f6d34222dde446f
Readback : 00.0035648982583969457 == 3f6d34222dde446e
Written  : 00.0035648982583969470 == 3f6d34222dde4471
Readback : 00.0035648982583969474 == 3f6d34222dde4472
Written  : 00.0035648982583969483 == 3f6d34222dde4474
Readback : 00.0035648982583969479 == 3f6d34222dde4473
Written  : 00.0035648982583969496 == 3f6d34222dde4477
Readback : 00.0035648982583969492 == 3f6d34222dde4476
Written  : 00.0035648982583969505 == 3f6d34222dde4479
Readback : 00.0035648982583969509 == 3f6d34222dde447a
Written  : 00.0035648982583969518 == 3f6d34222dde447c
Readback : 00.0035648982583969522 == 3f6d34222dde447d
Written  : 00.0035648982583969531 == 3f6d34222dde447f
Readback : 00.0035648982583969526 == 3f6d34222dde447e
Written  : 00.0035648982583969539 == 3f6d34222dde4481
Readback : 00.0035648982583969544 == 3f6d34222dde4482
Written  : 00.0035648982583969552 == 3f6d34222dde4484
Readback : 00.0035648982583969548 == 3f6d34222dde4483
Written  : 00.0035648982583969565 == 3f6d34222dde4487
Readback : 00.0035648982583969561 == 3f6d34222dde4486
Written  : 00.0035648982583969574 == 3f6d34222dde4489
Readback : 00.0035648982583969578 == 3f6d34222dde448a
Written  : 00.0035648982583969587 == 3f6d34222dde448c
Readback : 00.0035648982583969583 == 3f6d34222dde448b
Written  : 00.0035648982583969600 == 3f6d34222dde448f
Readback : 00.0035648982583969596 == 3f6d34222dde448e
Written  : 00.0035648982583969609 == 3f6d34222dde4491
Readback : 00.0035648982583969613 == 3f6d34222dde4492
Written  : 00.0035648982583969622 == 3f6d34222dde4494
Readback : 00.0035648982583969626 == 3f6d34222dde4495
Written  : 00.0035648982583969635 == 3f6d34222dde4497
Readback : 00.0035648982583969631 == 3f6d34222dde4496
Written  : 00.0035648982583969644 == 3f6d34222dde4499
Readback : 00.0035648982583969648 == 3f6d34222dde449a
Written  : 00.0035648982583969657 == 3f6d34222dde449c
Readback : 00.0035648982583969661 == 3f6d34222dde449d
Written  : 00.0035648982583969670 == 3f6d34222dde449f
Readback : 00.0035648982583969665 == 3f6d34222dde449e
Written  : 00.0035648982583969678 == 3f6d34222dde44a1
Readback : 00.0035648982583969683 == 3f6d34222dde44a2
Written  : 00.0035648982583969691 == 3f6d34222dde44a4
Readback : 00.0035648982583969687 == 3f6d34222dde44a3
Written  : 00.0035648982583969704 == 3f6d34222dde44a7
Readback : 00.0035648982583969700 == 3f6d34222dde44a6
Written  : 00.0035648982583969713 == 3f6d34222dde44a9
Readback : 00.0035648982583969717 == 3f6d34222dde44aa
Written  : 00.0035648982583969726 == 3f6d34222dde44ac
Readback : 00.0035648982583969730 == 3f6d34222dde44ad
Written  : 00.0035648982583969739 == 3f6d34222dde44af
Readback : 00.0035648982583969735 == 3f6d34222dde44ae
Written  : 00.0035648982583969748 == 3f6d34222dde44b1
Readback : 00.0035648982583969752 == 3f6d34222dde44b2
Written  : 00.0035648982583969761 == 3f6d34222dde44b4
Readback : 00.0035648982583969765 == 3f6d34222dde44b5
Written  : 00.0035648982583969774 == 3f6d34222dde44b7
Readback : 00.0035648982583969769 == 3f6d34222dde44b6
Written  : 00.0035648982583969782 == 3f6d34222dde44b9
Readback : 00.0035648982583969787 == 3f6d34222dde44ba
Written  : 00.0035648982583969795 == 3f6d34222dde44bc
Readback : 00.0035648982583969791 == 3f6d34222dde44bb
Written  : 00.0035648982583969808 == 3f6d34222dde44bf
Readback : 00.0035648982583969804 == 3f6d34222dde44be
Final output_value 0.0035648982583969813
failed 38, out of 100
Build Time 0:25
Build log was saved at "file://j:\Cpp\Misc\loopback\Release\BuildLog.htm"
loopback - 0 error(s), 0 warning(s)
========== Build: 1 succeeded, 0 failed, 0 up-to-date, 0 skipped ==========

if use stream << scientific << output_value;
the NO ERRORS.

------ Build started: Project: loopback, Configuration: Release Win32 ------
Compiling...
loopback.cpp
Linking...
Generating code
Finished generating code
Embedding manifest...
autorun "j:\Cpp\Misc\release\loopback.exe" 
failed 0, out of 1000000, fraction 0.00000000000000000
...
Build Time 0:28

*/
