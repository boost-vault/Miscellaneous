//////////////////////////////////////////////////////////////////
// optional.hpp header file
//
// Copyright 2010 - 2011. Tsoy Alexey.
// Distributed under the Boost Software License, Version 1.0. (See
// accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#ifndef BOOST_COMMAND_LINE_OPTIONAL_HPP
#define BOOST_COMMAND_LINE_OPTIONAL_HPP

// MS compatible compilers support #pragma once
#if defined(_MSC_VER) && (_MSC_VER >= 1020)
# pragma once
#endif

#include <boost/command_line/optional_fwd.hpp>

namespace boost
{

namespace command_line
{

template<
    typename T
  >
struct optional
{
  optional()
    : ptr_(0)
    { }

  template<
      typename U
    >
  explicit optional(U const& rh)
    : ptr_(new T(rh))
    { }

  optional(optional const& rh)
    : ptr_(rh.ptr_ ? new T(*rh.ptr_) : 0)
    { }

  template<
      typename U
    >
  optional& operator = (U const& rh)
  {
    optional(rh).swap(*this);
    return *this;
  }

  optional& operator = (optional const& rh)
  {
    optional(rh).swap(*this);
    return *this;
  }

  void swap(optional& rh) // throw()
  {
    T *  tmp(ptr_);
    ptr_ = rh.ptr_;
    rh.ptr_ = tmp ;
  }

  const T& operator*() const //throw() 
    { return *ptr_; }
  
  T& operator*() //throw() 
  { 
    return const_cast<T&>
      (static_cast<optional const*>
        (this)->operator*());
  }

  const T* operator->() const //throw() 
    { return &**this; }

  T* operator->() //throw()
    { return &**this; }

  ~optional()
    { delete ptr_; }

private:  
  struct dummy { void nonnull() {}; };
  typedef void (dummy::*safe_bool)();

public:
  bool operator ! () const 
    { return ptr_ == 0; }

  operator safe_bool () const 
    { return (!*this)?0:&dummy::nonnull; }

private:
  T * ptr_;
};

template<
    typename T
  >
bool operator == (bool lh, optional<T> const& rh)
  { return (lh && rh) || (!lh && !rh); }

template<
    typename T
  >
bool operator == ( optional<T> const& lh , bool rh)
  { return rh == lh; }


} // namespace command_line

} // namespace boost

#endif //BOOST_COMMAND_LINE_OPTIONAL_HPP
