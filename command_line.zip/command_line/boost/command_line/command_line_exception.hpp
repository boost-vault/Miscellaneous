//////////////////////////////////////////////////////////////////
// command_line_exception.hpp header file
//
// Copyright 2010 - 2011. Alexey Tsoy.
// Distributed under the Boost Software License, Version 1.0. (See
// accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#ifndef BOOST_COMMAND_LINE_EXCEPTION_HPP
#define BOOST_COMMAND_LINE_EXCEPTION_HPP

// MS compatible compilers support #pragma once
#if defined(_MSC_VER) && (_MSC_VER >= 1020)
# pragma once
#endif

#include <exception>
#include <cassert>

namespace boost
{

namespace command_line
{
//////////////////////////////////////////////////////////////////
// exceptions thrown by command_line
//
class command_line_exception : 
    public virtual std::exception
{
public:
    typedef enum {
        no_exception,             // initialized without code
        invalid_value,
        invalid_arg_count,
        already_exists,
        cmd_not_found,
    } exception_code;
    exception_code code;
    command_line_exception(exception_code c)
      : code(c)
      { }

    virtual const char *what( ) const throw( )
    {
        const char *msg = "unknown error";
        switch(code) {
        case no_exception:
            msg = "uninitialized exception";
            break;
        case invalid_value:
            msg = "invalid value";
            break;
        case invalid_arg_count:
            msg = "invalid argument count";
            break;
        case already_exists:
            msg = "command already exists";
            break;
        case cmd_not_found:
            msg = "command not found";
            break;
        default:
            assert(false);
            break;
        }
        return msg;
    }
protected:
    command_line_exception()
      : code(no_exception)
      { }
};

} // namespace command_line

} // namespace boost

#endif //BOOST_COMMAND_LINE_EXCEPTION_HPP
