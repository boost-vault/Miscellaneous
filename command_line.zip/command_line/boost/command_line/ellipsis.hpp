//////////////////////////////////////////////////////////////////
// ellipsis.hpp header file
//
// Copyright 2010 - 2011. Alexey Tsoy.
// Distributed under the Boost Software License, Version 1.0. (See
// accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#ifndef BOOST_COMMAND_LINE_ELLIPSIS_HPP
#define BOOST_COMMAND_LINE_ELLIPSIS_HPP

// MS compatible compilers support #pragma once
#if defined(_MSC_VER) && (_MSC_VER >= 1020)
# pragma once
#endif

#include <boost/command_line/ellipsis_fwd.hpp>
#include <vector>
#include <iosfwd>

namespace boost
{

namespace command_line
{

//namespace detail
//{

//template<
//    typename T
//  >
//struct get_default_allocator;
//
//template<
//    typename T
//  , typename A
//  >
//struct get_default_allocator<
//    std::vector<T,A>
//  >
//  { typedef result A; };
//}


/// This class is a kind of sequence container.
/**
 *  You can use this class just likes as std::vector.
 *  It is used to indicate option with variable amount of parameters.
 *
 *  @param T Type of the elements.
 *
 *  @param Alloc Type of the allocator object used to define the storage
 *  allocation model. By default, the allocator class template for type T
 *  is equal the default allocator class for std::vector<T>
 */

template<
    typename T
  , typename Alloc = typename std::vector<T>::allocator_type
  >
class ellipsis: std::vector<T,Alloc>
{
  typedef std::vector<T> supper_t;

public:
  typedef typename supper_t::allocator_type allocator_type;
  typedef typename supper_t::size_type size_type;
  typedef typename supper_t::difference_type difference_type;
  typedef typename supper_t::pointer pointer;
  typedef typename supper_t::const_pointer const_pointer;
  typedef typename supper_t::reference reference;
  typedef typename supper_t::const_reference const_reference;
  typedef typename supper_t::value_type value_type;
  typedef typename supper_t::iterator iterator;
  typedef typename supper_t::const_iterator const_iterator;
  typedef typename supper_t::reverse_iterator reverse_iterator;
  typedef typename supper_t::const_reverse_iterator const_reverse_iterator;

  using supper_t::reserve;
  using supper_t::capacity;
  using supper_t::begin;
  using supper_t::end;
  using supper_t::rbegin;
  using supper_t::rend;
  using supper_t::resize;
  using supper_t::size;
  using supper_t::max_size;
  using supper_t::empty;

  using supper_t::at;
  using supper_t::operator[];
  using supper_t::front;
  using supper_t::back;
  using supper_t::push_back;
  using supper_t::pop_back;

  using supper_t::assign;
  using supper_t::insert;
  using supper_t::erase;
  using supper_t::clear;
  using supper_t::get_allocator;
  

  explicit ellipsis(allocator_type const& a = allocator_type())
    : supper_t(a)
    { }

  explicit ellipsis(
      size_type s
    , value_type const& v = value_type()
    , const allocator_type& a = allocator_type()
    )
    : supper_t(s,v,a)
    { }

  template<
      typename Iter
    >
  ellipsis(
      Iter b
    , Iter e
    , const allocator_type& a = allocator_type()
    )
    : supper_t(b,e,a)
    { }

  ellipsis(const ellipsis& rh)
    : supper_t(rh)
    { }
 
  ellipsis& operator=(const ellipsis& rh)
  {
    static_cast<supper_t&>(*this) = rh;
    return *this;
  }

  void swap(ellipsis& rh)
    { supper_t::swap(rh); }
};

//template<
//    typename T
//  , typename Alloc
//  >
//std::ostream& operator << (std::ostream& os, ellipsis<T,Alloc> const& e)
//{
//  typedef typename ellipsis<T,Alloc>::const_iterator iter;
//
//  if(e.empty())
//    { return os; }
//
//  iter it(e.begin()),end(e.end());
//
//  for(os << *it;++it!=end;)
//    { os << ", " << *it; }
//
//  return os;
//}


} // namespace command_line

} // namespace boost

#endif //BOOST_COMMAND_LINE_ELLIPSIS_HPP
