//////////////////////////////////////////////////////////////////
// interpreter_fwd.hpp header file
//
// Copyright 2010 - 2011. Alexey Tsoy.
// Distributed under the Boost Software License, Version 1.0. (See
// accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#ifndef BOOST_COMMAND_LINE_INTERPRETER_FWD_HPP
#define BOOST_COMMAND_LINE_INTERPRETER_FWD_HPP

// MS compatible compilers support #pragma once
#if defined(_MSC_VER) && (_MSC_VER >= 1020)
# pragma once
#endif


namespace boost
{

namespace command_line
{

// forward declaration of interpreter
template<
    typename CharType
  , typename Context
  , typename TypeCast
  >
class interpreter;


} // namespace command_line

} // namespace boost

#endif //BOOST_COMMAND_LINE_INTERPRETER_FWD_HPP
