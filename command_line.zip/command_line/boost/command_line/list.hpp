//////////////////////////////////////////////////////////////////
// list.hpp header file
//
// Copyright 2010 - 2011. Alexey Tsoy.
// Distributed under the Boost Software License, Version 1.0. (See
// accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#ifndef BOOST_COMMAND_LINE_LIST_HPP
#define BOOST_COMMAND_LINE_LIST_HPP

// MS compatible compilers support #pragma once
#if defined(_MSC_VER) && (_MSC_VER >= 1020)
# pragma once
#endif

#include <boost/config.hpp>
#include <boost/command_line/list_fwd.hpp>
#include <boost/command_line/detail/list.hpp>

namespace boost
{

namespace command_line
{

template<
#define BOOST_COMMAND_LINE_ENUM_PARAMS(unused_1, i, unused_2)          \
  BOOST_PP_COMMA_IF(i) typename BOOST_PP_CAT(A,i)

    BOOST_PP_REPEAT_FROM_TO(0,BOOST_COMMAND_LINE_MAX_LIST_SIZE, 
      BOOST_COMMAND_LINE_ENUM_PARAMS, ~)

#undef BOOST_COMMAND_LINE_ENUM_PARAMS
  >
struct list : private detail::list<

#define BOOST_COMMAND_LINE_ENUM_PARAMS(unused_1, i, unused_2) \
  BOOST_PP_COMMA_IF(i) typename detail::impl_type<BOOST_PP_CAT(A,i)>::result
    BOOST_PP_REPEAT_FROM_TO(0,BOOST_COMMAND_LINE_MAX_LIST_SIZE, 
      BOOST_COMMAND_LINE_ENUM_PARAMS, ~)
  >
{
  typedef detail::list<
    BOOST_PP_REPEAT_FROM_TO(0,BOOST_COMMAND_LINE_MAX_LIST_SIZE,
      BOOST_COMMAND_LINE_ENUM_PARAMS, ~)
  > supper_t;

#undef BOOST_COMMAND_LINE_ENUM_PARAMS

  typedef list<
    BOOST_PP_ENUM_PARAMS(BOOST_COMMAND_LINE_MAX_LIST_SIZE, A)
  > self_t;

public:

  BOOST_STATIC_CONSTANT(size_t, max_size  = BOOST_COMMAND_LINE_MAX_LIST_SIZE);

  // Returns type of N-element in this collection
  template<
      size_t N
    >
  struct type_of
  {
    typedef typename detail::type_of<
        N
      , supper_t
      >::result result;
  };

  // Returns const reference on N-element this collection.

  template<
      size_t N
    >
  typename type_of<N>::result const& get() const
  {
    detail::get_t<N> accessor;
    return accessor(static_cast<supper_t const&>(*this));
  }
  
  // Returns const reference of N-element in this collection.
  template<
      size_t N
    >
  typename type_of<N>::result & get()
  {
    detail::get_t<N> accessor;
    return accessor(static_cast<supper_t &>(*this));
  }
};

} //namespace command_line

} //namespace boost

#endif //BOOST_COMMAND_LINE_LIST_HPP
