//////////////////////////////////////////////////////////////////
// gramma.hpp header file
//
// Copyright 2010 - 2011. Alexey Tsoy.
// Distributed under the Boost Software License, Version 1.0. (See
// accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#ifndef BOOST_COMMAND_LINE_GRAMMA_HPP
#define BOOST_COMMAND_LINE_GRAMMA_HPP

// MS compatible compilers support #pragma once
#if defined(_MSC_VER) && (_MSC_VER >= 1020)
# pragma once
#endif


#include <boost/spirit/include/classic_core.hpp>
#include <boost/spirit/include/classic_attribute.hpp>
#include <boost/spirit/include/classic_push_back_actor.hpp>
#include <boost/spirit/include/classic_core.hpp>
#include <boost/spirit/include/classic_attribute.hpp>
#include <boost/spirit/include/phoenix1_binders.hpp>
#include <vector>
#include <string>


namespace boost
{

namespace command_line
{

namespace detail
{

template<
    typename CharType
  , CharType CommandSeparator
  , CharType AttributBegin
  , CharType AttributEnd
  , CharType AttributSeparator
  >
struct gramma:
  //::boost::spirit::classic::
  BOOST_SPIRIT_CLASSIC_NS::grammar<
      gramma<
          CharType
        , CommandSeparator
        , AttributBegin
        , AttributEnd
        , AttributSeparator
        >
    >
{
  BOOST_STATIC_CONSTANT(CharType, command_separator  = CommandSeparator );
  BOOST_STATIC_CONSTANT(CharType, attribut_begin     = AttributBegin    );
  BOOST_STATIC_CONSTANT(CharType, attribut_end       = AttributEnd      );
  BOOST_STATIC_CONSTANT(CharType, attribut_separator = AttributSeparator);

  typedef CharType char_type;
  typedef std::basic_string<char_type> string_type;

  struct attribut
  {
    attribut(
        string_type const& name_
      , std::vector<string_type> const& args_
      )
      : name_(name_)
      , args_(args_)
      { }

    string_type name() const
      { return name_; }

    typedef typename std::vector<
        string_type
      >::const_iterator const_iterator;

    const_iterator arg_begin() const
      { return args_.begin(); }

    const_iterator arg_end() const
      { return args_.end(); }

  private:
    string_type name_;
    std::vector<string_type> args_;
  };

  typedef std::vector<attribut> result_type;

  result_type & result_;

  gramma(result_type & result)
    : result_(result)
    { }

  template <typename Scan> struct definition
  {
    struct push_back_impl 
    {
       template<typename T, typename A> struct result 
        { typedef void type; };

      template <typename T, typename A>
      typename result<T,A>::type operator() (T &v,const A &val) const
        { v.push_back(val); }
    };

    definition(gramma const&self)
    {
      using phoenix::arg1;
      using phoenix::arg2;
      using phoenix::construct_;
      using phoenix::var;
      using BOOST_SPIRIT_CLASSIC_NS::space_p;
      using BOOST_SPIRIT_CLASSIC_NS::anychar_p;
      using BOOST_SPIRIT_CLASSIC_NS::lexeme_d;
      using BOOST_SPIRIT_CLASSIC_NS::anychar_p;
      using BOOST_SPIRIT_CLASSIC_NS::eol_p;

      phoenix::function<push_back_impl> push_back;

      attr_name = lexeme_d
        [ +(anychar_p - space_p - attribut_begin) ];

      attr_value_1 = attribut_begin >> 
        lexeme_d[+(anychar_p - attribut_end)]
          [
            push_back(
                attr.value
              , construct_<string_type>(arg1,arg2)
            )
          ]
        >> attribut_end;

      attr_value_2 = lexeme_d
        [
          +(anychar_p - attribut_separator - command_separator - eol_p)
        ]
        [
          push_back(
              attr.value
            , construct_<string_type>(arg1,arg2)
            )
        ];

      attr_value = (attr_value_1||attr_value_2)
        >> *( attribut_separator >> attr_value);

      attr =
        (
          command_separator >> 
            attr_name[attr.name=construct_<string_type>(arg1,arg2)] >>
           !attr_value
        )
        [
          push_back(
              expresion.result_
            , construct_<attribut>(attr.name,attr.value)
            )
        ]
        ;

      expresion = (*attr)
        [var(self.result_) = expresion.result_]
      ;
    }

//    struct expresion_closure:
//      BOOST_SPIRIT_CLASSIC_NS::closure
//        <expresion_closure,result_type> 
//      { member1 result; };

//    struct attribut_closure:
//      BOOST_SPIRIT_CLASSIC_NS::closure
//        <attribut_closure,string_type,std::vector<string_type> >
//    {
//      member1 name ;
//      member2 value;
//    };

    struct expresion_closure:
      BOOST_SPIRIT_CLASSIC_NS::closure
        <expresion_closure,result_type> 
    { 
      typedef BOOST_SPIRIT_CLASSIC_NS::closure<
          expresion_closure
        , result_type
        > supper_t;

      typename supper_t::member1 result_; 
    };
 
    struct attribut_closure:
      BOOST_SPIRIT_CLASSIC_NS::closure
        <attribut_closure,string_type,std::vector<string_type> >
    {
      typedef BOOST_SPIRIT_CLASSIC_NS::closure<
          attribut_closure
        , string_type,std::vector<string_type> 
        > supper_t;

      typename supper_t::member1 name ;
      typename supper_t::member2 value;
    };
    
    BOOST_SPIRIT_CLASSIC_NS::rule<
        Scan
      , typename expresion_closure::context_t
      > expresion;

    BOOST_SPIRIT_CLASSIC_NS::rule<
        Scan
      , typename attribut_closure::context_t
      > attr;
    
    BOOST_SPIRIT_CLASSIC_NS::rule<Scan> 
      attr_name,attr_value, attr_value_1, attr_value_2;

    BOOST_SPIRIT_CLASSIC_NS::rule<
        Scan
      , typename expresion_closure::context_t
      > const& start() const
      { return expresion; }
  };
};

} // namespace detail

} // namespace command_line

} // namespace boost

#endif //BOOST_COMMAND_LINE_GRAMMA_HPP
