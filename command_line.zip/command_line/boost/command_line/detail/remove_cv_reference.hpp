//////////////////////////////////////////////////////////////////
// remove_cv_reference.hpp header file
//
// Copyright 2010 - 2011. Alexey Tsoy.
// Distributed under the Boost Software License, Version 1.0. (See
// accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)
#ifndef REMOVE_CV_REFERENCE_HPP
#define REMOVE_CV_REFERENCE_HPP

// MS compatible compilers support #pragma once
#if defined(_MSC_VER) && (_MSC_VER >= 1020)
# pragma once
#endif

#include <boost/type_traits/remove_cv.hpp>
#include <boost/type_traits/remove_reference.hpp>

namespace boost
{

namespace command_line
{

template<
    typename T
  >
struct remove_cv_reference
{
  typedef typename remove_cv<
    typename remove_reference<T>::type
  >::type type;
};

} // command_line

} // boost

#endif REMOVE_CV_REFERENCE_HPP
