//////////////////////////////////////////////////////////////////
// construct.hpp header file
//
// Copyright 2010 - 2011. Alexey Tsoy.
// Distributed under the Boost Software License, Version 1.0. (See
// accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)
#ifndef BOOST_COMMAND_LINE_CONSTRUCT_HPP
#define BOOST_COMMAND_LINE_CONSTRUCT_HPP

// MS compatible compilers support #pragma once
#if defined(_MSC_VER) && (_MSC_VER >= 1020)
# pragma once
#endif

#include <boost/command_line/command_line_exception.hpp>
#include <boost/command_line/ellipsis_fwd.hpp>
#include <boost/command_line/optional_fwd.hpp>
#include <boost/command_line/list_fwd.hpp>

namespace boost
{

namespace command_line
{

template<
    typename SourceType
  , typename Translator
  , typename R
  >
R construct(
    SourceType & arg
  , Translator& translator
  , R const* = 0
  )
{
  if(arg.empty())
  { 
    ::boost::command_line::throw_exception
      (command_line_exception(command_line_exception::invalid_arg_count));
  }

  R ret(translator.template cast<R>(arg.front()));
  arg.pop();
  return ret;
}

template<
    typename SourceType
  , typename Translator
  , typename P
  , typename Alloc
  >
ellipsis<P,Alloc> construct(
    SourceType & arg
  , Translator& translator
  , ellipsis<P,Alloc> const* = 0
  )
{
  ellipsis<P,Alloc> ret;
  while(!arg.empty())
    { ret.push_back(construct(arg,translator,static_cast<P const*>(0))); }
  return ret;
}

template<
    typename SourceType
  , typename Translator
  , typename T
  >
optional<T> construct(
    SourceType & arg
  , Translator& translator
  , optional<T> const* = 0
  )
{
  if(arg.empty())
    { return optional<T>(); }

  optional<T> ret(construct(arg,translator,static_cast<T const*>(0)));
  return ret;
}

namespace detail
{

template<
    typename T
  >
struct construct_impl_t
{
  template<
      size_t N
    , typename SourceType
    , typename Translator
    , typename List
    >
    void apply (
        SourceType & arg
      , Translator& translator
      , List & v
      ) const
    { v.template get<N>() = construct(arg,translator,static_cast<T*>(0)); }
};

template<>
struct construct_impl_t<na>
{
  template<
      size_t N
    , typename SourceType
    , typename Translator
    , typename List
    >
    void apply (
        SourceType & arg
      , Translator& translator
      , List & v
      ) const
      { }
};

template<
    size_t N
  , typename SourceType
  , typename Translator
  , typename List
  >
void construct_impl(
    SourceType & arg
  , Translator& translator
  , List & v
  )
{
  if(arg.empty())
    { return; }

  construct_impl_t<
      typename List::template type_of<N>::result
    > construct_impl_;

  construct_impl_.template apply<N>(arg,translator,v);
}

} // namespace detail

template<
    typename SourceType
  , typename Translator
  , BOOST_PP_ENUM_PARAMS(BOOST_COMMAND_LINE_MAX_LIST_SIZE,typename A)
  >
list<BOOST_PP_ENUM_PARAMS(BOOST_COMMAND_LINE_MAX_LIST_SIZE,A)> construct(
    SourceType & arg
  , Translator& translator
  , list<BOOST_PP_ENUM_PARAMS(BOOST_COMMAND_LINE_MAX_LIST_SIZE,A)> const* =0
  )
{
  typedef list<BOOST_PP_ENUM_PARAMS(BOOST_COMMAND_LINE_MAX_LIST_SIZE,A)> ret_t;
  list<BOOST_PP_ENUM_PARAMS(BOOST_COMMAND_LINE_MAX_LIST_SIZE,A)> ret;
  
#define BOOST_COMMAND_LINE_CONSTRUCT_EXECUTOR(unused_1, n, unused_2) \
  detail::construct_impl<n>(arg,translator,ret);

  BOOST_PP_REPEAT_FROM_TO(0,BOOST_COMMAND_LINE_MAX_LIST_SIZE, 
    BOOST_COMMAND_LINE_CONSTRUCT_EXECUTOR, ~)

#undef BOOST_COMMAND_LINE_CONSTRUCT_EXECUTOR

  return ret;
}

} // namespace command_line

} // namespace boost

#endif //BOOST_COMMAND_LINE_CONSTRUCT_HPP
