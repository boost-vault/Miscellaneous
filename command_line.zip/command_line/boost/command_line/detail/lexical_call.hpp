//////////////////////////////////////////////////////////////////
// lexical_call.hpp header file
//
// Copyright 2010 - 2011. Alexey Tsoy.
// Distributed under the Boost Software License, Version 1.0. (See
// accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#ifndef BOOST_LEXICAL_CALL_HPP
#define BOOST_LEXICAL_CALL_HPP

// MS compatible compilers support #pragma once
#if defined(_MSC_VER) && (_MSC_VER >= 1020)
# pragma once
#endif

#include <boost/command_line/detail/lexical_call_fwd.hpp>
#include <boost/command_line/detail/remove_cv_reference.hpp>
#include <boost/command_line/throw_exception.hpp>
#include <boost/command_line/command_line_exception.hpp>
#include <boost/command_line/detail/construct.hpp>
#include <boost/preprocessor/cat.hpp>
#include <boost/preprocessor/comma_if.hpp>
#include <boost/preprocessor/enum_params.hpp>
#include <boost/preprocessor/repeat_from_to.hpp>


#ifndef BOOST_COMMAND_LINE_MAX_FUNCTION_ARGS
# define BOOST_COMMAND_LINE_MAX_FUNCTION_ARGS 10
#endif //BOOST_COMMAND_LINE_MAX_FUNCTION_ARGS

namespace boost
{

namespace command_line
{

#define BOOST_COMMAND_LINE_LEXICAL_CALL_REMOVE_CVR(A) \
  typedef typename remove_cv_reference<A>::type

#define BOOST_COMMAND_LINE_ARG(i) BOOST_PP_CAT(ARG,i)
#define BOOST_COMMAND_LINE_ARG_(i) BOOST_PP_CAT(_, BOOST_COMMAND_LINE_ARG(i) )

#define BOOST_COMMAND_LINE_LEXICAL_CALL_HELP_EXECUTOR(unused_1, i, unused_2)   \
  BOOST_COMMAND_LINE_LEXICAL_CALL_REMOVE_CVR( BOOST_COMMAND_LINE_ARG(i) )      \
    BOOST_COMMAND_LINE_ARG_(i);                                                \
  BOOST_COMMAND_LINE_ARG_(i) BOOST_PP_CAT(arg,i)                               \
    (construct(arg,translator,                                                 \
      static_cast<BOOST_COMMAND_LINE_ARG_(i) const*>(0)));                     \
  
#define BOOST_COMMAND_LINE_LEXICAL_CALL_EXECUTOR(unused_1, n, unused_2)        \
  template<                                                                 \
      typename SourceType                                                   \
    , typename Fn                                                           \
    , typename R                                                            \
      BOOST_PP_COMMA_IF(n)                                                  \
      BOOST_PP_ENUM_PARAMS(n, typename ARG)                                 \
  >                                                                         \
  struct lexical_call<SourceType,Fn, R (BOOST_PP_ENUM_PARAMS(n, ARG)) >     \
  {                                                                         \
    typedef SourceType source_type;                                         \
    mutable Fn  fn_;                                                        \
                                                                            \
    explicit lexical_call(Fn const& fn)                                     \
      : fn_(fn)                                                             \
      { }                                                                   \
                                                                            \
    template<typename Translator>                                           \
    void invoke(source_type & arg,Translator& translator) const             \
    {                                                                       \
      BOOST_PP_REPEAT_FROM_TO(0,n,                                          \
        BOOST_COMMAND_LINE_LEXICAL_CALL_HELP_EXECUTOR, ~)                   \
      fn_(BOOST_PP_ENUM_PARAMS(n, arg));                                    \
    }                                                                       \
                                                                            \
    BOOST_STATIC_CONSTANT(std::size_t, arg_count = n);                      \
  };                                                                        \

BOOST_PP_REPEAT_FROM_TO(0,BOOST_PP_ADD(BOOST_COMMAND_LINE_MAX_FUNCTION_ARGS,1), 
  BOOST_COMMAND_LINE_LEXICAL_CALL_EXECUTOR, ~);

#undef BOOST_COMMAND_LINE_LEXICAL_CALL_REMOVE_CVR
#undef BOOST_COMMAND_LINE_ARG
#undef BOOST_COMMAND_LINE_ARG_
#undef BOOST_COMMAND_LINE_LEXICAL_CALL_EXECUTOR

namespace detail
{

template<
    typename FnSign
  >                
struct arg_count_t;

#define BOOST_COMMAND_LINE_ARG_COUNT_EXECUTOR(unused_1, n, unused_2)        \
  template<                                                                 \
      typename R                                                            \
      BOOST_PP_COMMA_IF(n)                                                  \
      BOOST_PP_ENUM_PARAMS(n, typename ARG)                                 \
  >                                                                         \
  struct arg_count_t<R (BOOST_PP_ENUM_PARAMS(n, ARG))>                      \
    { BOOST_STATIC_CONSTANT(std::size_t, arg_count = n); };

BOOST_PP_REPEAT_FROM_TO(0,BOOST_PP_ADD(BOOST_COMMAND_LINE_MAX_FUNCTION_ARGS,1), 
  BOOST_COMMAND_LINE_ARG_COUNT_EXECUTOR, ~);

#undef BOOST_COMMAND_LINE_ARG_COUNT_EXECUTOR

} // detail

} // namespace command_line

} // namespace boost


#endif //BOOST_LEXICAL_CALL_HPP
