//////////////////////////////////////////////////////////////////
// list.hpp header file
//
// Copyright 2010 - 2011. Alexey Tsoy.
// Distributed under the Boost Software License, Version 1.0. (See
// accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#ifndef BOOST_COMMAND_LINE_LIST_DETAIL_HPP
#define BOOST_COMMAND_LINE_LIST_DETAIL_HPP

// MS compatible compilers support #pragma once
#if defined(_MSC_VER) && (_MSC_VER >= 1020)
# pragma once
#endif

#include <boost/command_line/optional.hpp>
#include <boost/command_line/detail/na.hpp>

namespace boost
{

namespace command_line
{

namespace detail
{

template<
    BOOST_PP_ENUM_PARAMS(BOOST_COMMAND_LINE_MAX_LIST_SIZE, typename A)
  >
struct list
{
#define BOOST_COMMAND_LINE_DECLARE_FILEDS(unused_1, i, unused_2) \
  BOOST_PP_CAT(A,i)  BOOST_PP_CAT(a,i);

  BOOST_PP_REPEAT_FROM_TO(0,BOOST_COMMAND_LINE_MAX_LIST_SIZE, 
    BOOST_COMMAND_LINE_DECLARE_FILEDS, ~)

#undef BOOST_COMMAND_LINE_DECLARE_FILEDS

};
///////////////////////////////////////////////////////////////////////////////
//// result_type
///////////////////////////////////////////////////////////////////////////////
template<
    size_t n
  , typename Variant
  >
struct type_of;

#define BOOST_COMMAND_LINE_TYPE_OF_EXECUTOR(unused_1, i, unused_2)       \
  template<                                                              \
      BOOST_PP_ENUM_PARAMS(BOOST_COMMAND_LINE_MAX_LIST_SIZE, typename A) \
    >                                                                    \
  struct type_of<                                                        \
      i                                                                  \
    , list<BOOST_PP_ENUM_PARAMS(BOOST_COMMAND_LINE_MAX_LIST_SIZE, A)>    \
    >                                                                    \
    { typedef BOOST_PP_CAT(A,i) result; };

BOOST_PP_REPEAT_FROM_TO(0,BOOST_COMMAND_LINE_MAX_LIST_SIZE, 
  BOOST_COMMAND_LINE_TYPE_OF_EXECUTOR, ~)

#undef BOOST_COMMAND_LINE_TYPE_OF_EXECUTOR
///////////////////////////////////////////////////////////////////////////////
// get_t
///////////////////////////////////////////////////////////////////////////////
template<
    size_t n
  >
struct get_t;

#define BOOST_COMMAND_LINE_GET_T_EXECUTOR(unused_1, i, unused_2) \
  template<                                    \
    >                                          \
  struct get_t<i>                              \
  {                                            \
    template<typename Variant>                 \
    typename type_of<i,Variant>::result const& \
      operator() (Variant const& list)         \
        { return list.BOOST_PP_CAT(a,i); }     \
                                               \
    template<typename Variant>                 \
    typename type_of<i,Variant>::result &      \
      operator() (Variant & list)              \
        { return list.BOOST_PP_CAT(a,i); }     \
  };

BOOST_PP_REPEAT_FROM_TO(0,BOOST_COMMAND_LINE_MAX_LIST_SIZE,
  BOOST_COMMAND_LINE_GET_T_EXECUTOR, ~)

#undef BOOST_COMMAND_LINE_GET_T_EXECUTOR
//////////////////////////////////////////////////////////////////
// selector implementation type
//////////////////////////////////////////////////////////////////
template<
    typename T
  >
struct impl_type
  { typedef optional<T> result; };

template<
  >
struct impl_type<na>
  { typedef na result; };

} // namespace detail

} // namespace command_line

} // namespace boost

#endif //BOOST_COMMAND_LINE_LIST_DETAIL_HPP
