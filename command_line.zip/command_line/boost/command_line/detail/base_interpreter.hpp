//////////////////////////////////////////////////////////////////
// base_interpreter.hpp header file
//
// Copyright 2010 - 2011. Alexey Tsoy.
// Distributed under the Boost Software License, Version 1.0. (See
// accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#ifndef BOOST_COMMAND_LINE_BASE_INTERPRETER_HPP
#define BOOST_COMMAND_LINE_BASE_INTERPRETER_HPP

// MS compatible compilers support #pragma once
#if defined(_MSC_VER) && (_MSC_VER >= 1020)
# pragma once
#endif

#include <boost/command_line/throw_exception.hpp>
#include <boost/command_line/command_line_exception.hpp>
#include <boost/command_line/detail/lexical_call.hpp>
#include <boost/command_line/detail/remove_cv_reference.hpp>
#include <boost/preprocessor/cat.hpp>
#include <boost/preprocessor/comma_if.hpp>
#include <boost/preprocessor/enum_params.hpp>
#include <boost/preprocessor/repeat_from_to.hpp>
#include <boost/shared_ptr.hpp>
#include <boost/smart_ptr/make_shared.hpp>
#include <iosfwd>
#include <string>
#include <map>
#include <list>

#ifndef BOOST_COMMAND_LINE_MAX_FUNCTION_ARGS
# define BOOST_COMMAND_LINE_MAX_FUNCTION_ARGS 10
#endif //BOOST_COMMAND_LINE_MAX_FUNCTION_ARGS

namespace boost
{

namespace command_line
{

namespace detail
{

template<
    typename CharType
  , typename TypeCast
  >
class base_interpreter
{
public:
  typedef TypeCast type_cast_t;
  typedef std::basic_string<CharType> string_type;

  base_interpreter();
  base_interpreter(base_interpreter const&);
  base_interpreter& operator = (base_interpreter const&);
  base_interpreter& operator += (base_interpreter const&);

  void swap(base_interpreter&);

  void erase(string_type const& option_name);

  template<
      typename It
    >
  void invoke (string_type const& option_name
    , It cmd_args_begin, It cmd_args_end, type_cast_t & type_cast) const;

  struct proxy_t;

  template<
      typename FnSign
    , typename Functor
  >
  proxy_t add(
      Functor const& fn
    , string_type const& option_name
    , string_type const& help
    )
  { 
    add_<FnSign>(fn,option_name,help);
    return proxy_t(*this, option_name);
  }

  template<
    typename Functor
  >
  proxy_t add(
      Functor const& fn
    , string_type const& option_name
    , string_type const& help
    )
  { 
    auto_add_(fn,option_name,help, &Functor::operator()); 
    return proxy_t(*this, option_name);
  }

#define BOOST_COMMAND_LINE_AUTO_ADD_EXECUTOR(unused_1, n, unused_2) \
  template<                                                         \
      typename R                                                    \
      BOOST_PP_COMMA_IF(n)                                          \
      BOOST_PP_ENUM_PARAMS(n, typename ARG)                         \
  >                                                                 \
  proxy_t add( R (*fn) (BOOST_PP_ENUM_PARAMS(n, ARG))               \
    , string_type const& option_name                                \
    , string_type const& help                                       \
    )                                                               \
  {                                                                 \
    add_<R (BOOST_PP_ENUM_PARAMS(n, ARG))>(fn, option_name,help);   \
    return proxy_t(*this, option_name);                             \
  }

  BOOST_PP_REPEAT_FROM_TO(
      0
    , BOOST_PP_ADD(BOOST_COMMAND_LINE_MAX_FUNCTION_ARGS,1)
    , BOOST_COMMAND_LINE_AUTO_ADD_EXECUTOR
    , ~
    );

#undef BOOST_COMMAND_LINE_AUTO_ADD_EXECUTOR

  template<
      typename Visitor
    >
  void visit(Visitor& visitor) const;

  void set_synonym(string_type const& options,string_type const& synonym);

private:

  template<
      typename FnSign
    , typename Functor
    >
  void add_(
      Functor const& fn
    , string_type const& option_name
    , string_type const& help
    );

#define BOOST_COMMAND_LINE_VALUE_0(fn_spec) 
#define BOOST_COMMAND_LINE_VALUE_1(fn_spec) fn_spec

#define BOOST_COMMAND_LINE_VALUE(id) BOOST_PP_CAT(BOOST_COMMAND_LINE_VALUE_,id)

#define BOOST_COMMAND_LINE_AUTO_ADD_EXECUTOR_(unused_1, n, fn_spec)    \
  template<                                                            \
      typename Functor                                                 \
    , typename Fn                                                      \
    , typename R                                                       \
      BOOST_PP_COMMA_IF(n)                                             \
      BOOST_PP_ENUM_PARAMS(n, typename ARG)                            \
  >                                                                    \
  void auto_add_(                                                      \
      Functor const& fn                                                \
    , string_type const& option_name                                   \
    , string_type const& help                                          \
    , R (Fn::*)(BOOST_PP_ENUM_PARAMS(n,ARG))                           \
        BOOST_PP_CAT(BOOST_COMMAND_LINE_VALUE_,fn_spec))               \
    { add_<R (BOOST_PP_ENUM_PARAMS(n,ARG))>(fn, option_name,help); }   \


#define BOOST_COMMAND_LINE_REPEAT_CALL(fn_spec)            \
  BOOST_PP_REPEAT_FROM_TO(                                 \
      0                                                    \
    , BOOST_PP_ADD(BOOST_COMMAND_LINE_MAX_FUNCTION_ARGS,1) \
    , BOOST_COMMAND_LINE_AUTO_ADD_EXECUTOR_                \
    , fn_spec                                              \
    )

BOOST_COMMAND_LINE_REPEAT_CALL( 0(~) )
BOOST_COMMAND_LINE_REPEAT_CALL( 1(const) )
BOOST_COMMAND_LINE_REPEAT_CALL( 1(volatile) )
BOOST_COMMAND_LINE_REPEAT_CALL( 1(volatile const) )

#undef BOOST_COMMAND_LINE_REPEAT_CALL
#undef BOOST_COMMAND_LINE_AUTO_ADD_EXECUTOR_
#undef BOOST_COMMAND_LINE_VALUE
#undef BOOST_COMMAND_LINE_VALUE_1
#undef BOOST_COMMAND_LINE_VALUE_0

  struct base_arg_accessor_t;

  template<
      typename Iterator
    >
  struct arg_accessor_t;

  struct base_executor;

  template<
      typename Functor
    , typename FnSign
    >
  struct executor_t;

  typedef std::map<
      string_type
    , string_type
    > synonym_t;

  synonym_t synonym_;

  template<
      typename Iter
    >
  void erase_synonym(Iter,Iter);

  struct option_info_t
  {
    boost::shared_ptr<base_executor> function;
    std::list<string_type> synonyms;
    string_type help;
  };

  typedef std::map<
      string_type
    , option_info_t
    > storage_t;

  storage_t storage_;
};

} // namespace detail

} // namespace command_line

} // namespace boost

#include <boost/command_line/detail/base_interpreter.ipp>

#endif //BOOST_COMMAND_LINE_BASE_INTERPRETER_HPP
