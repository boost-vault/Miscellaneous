//////////////////////////////////////////////////////////////////
// list_fwd.hpp header file
//
// Copyright 2010 - 2011. Alexey Tsoy.
// Distributed under the Boost Software License, Version 1.0. (See
// accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#ifndef BOOST_COMMAND_LINE_LIST_FWD_HPP
#define BOOST_COMMAND_LINE_LIST_FWD_HPP

// MS compatible compilers support #pragma once
#if defined(_MSC_VER) && (_MSC_VER >= 1020)
# pragma once
#endif

#include <boost/preprocessor/repeat_from_to.hpp>
#include <boost/preprocessor/enum_params.hpp>
#include <boost/preprocessor/comma_if.hpp>
#include <boost/command_line/detail/na.hpp>

#ifndef BOOST_COMMAND_LINE_MAX_LIST_SIZE
# define BOOST_COMMAND_LINE_MAX_LIST_SIZE 10
#endif //BOOST_COMMAND_LINE_MAX_FUNCTION_ARGS

namespace boost
{

namespace command_line
{

template<
#define BOOST_COMMAND_LINE_ENUM_PARAMS(unused_1, i, unused_2)          \
  BOOST_PP_COMMA_IF(i) typename BOOST_PP_CAT(A,i) = detail::na

    BOOST_PP_REPEAT_FROM_TO(0,BOOST_COMMAND_LINE_MAX_LIST_SIZE, 
      BOOST_COMMAND_LINE_ENUM_PARAMS, ~)

#undef BOOST_COMMAND_LINE_ENUM_PARAMS
  >
struct list;

} // namespace command_line

} // namespace boost

#endif //BOOST_COMMAND_LINE_LIST_FWD_HPP
