// def_context.hpp header file
//
// Copyright 2010 - 2011. Alexey Tsoy.
// Distributed under the Boost Software License, Version 1.0. (See
// accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#ifndef BOOST_COMMAND_LINE_DEF_CONTEXT_HPP
#define BOOST_COMMAND_LINE_DEF_CONTEXT_HPP

// MS compatible compilers support #pragma once
#if defined(_MSC_VER) && (_MSC_VER >= 1020)
# pragma once
#endif

#include <boost/command_line/detail/gramma.hpp>
#include <string>

namespace boost
{

namespace command_line
{

// default context 

template<
    typename CharType
  , CharType CommandSeparator
  , CharType AttributBegin
  , CharType AttributEnd
  , CharType AttributSeparator
  >
struct default_context: boost::command_line::detail::gramma<
    CharType
  , CommandSeparator
  , AttributBegin
  , AttributEnd
  , AttributSeparator
  > ::result_type
{
  // Constructor
  explicit default_context(CharType const* str)
  {
    boost::command_line::detail::gramma<
        CharType
      , CommandSeparator
      , AttributBegin
      , AttributEnd
      , AttributSeparator
      > gramma(*this);

    using namespace BOOST_SPIRIT_CLASSIC_NS;

    if(parse(str,gramma,space_p).full)
      { return; }

    ::boost::command_line::throw_exception
      (command_line_exception(command_line_exception::invalid_value));
  }
};

} // namespace command_line

} // namespace boost

#endif //BOOST_COMMAND_LINE_DEF_CONTEXT_HPP
