//////////////////////////////////////////////////////////////////
// interpreter.hpp header file
//
// Copyright 2010 - 2011. Alexey Tsoy.
// Distributed under the Boost Software License, Version 1.0. (See
// accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#ifndef BOOST_COMMAND_LINE_INTERPRETER_HPP
#define BOOST_COMMAND_LINE_INTERPRETER_HPP

// MS compatible compilers support #pragma once
#if defined(_MSC_VER) && (_MSC_VER >= 1020)
# pragma once
#endif

#ifndef BOOST_COMMAND_LINE_MAX_FUNCTION_ARGS
# define BOOST_COMMAND_LINE_MAX_FUNCTION_ARGS 10
#endif //BOOST_COMMAND_LINE_MAX_FUNCTION_ARGS

#include <boost/command_line/interpreter_fwd.hpp>
#include <boost/command_line/detail/base_interpreter.hpp>
#include <boost/command_line/def_context.hpp>
#include <boost/lexical_cast.hpp>

#include <iomanip>

namespace boost
{

namespace command_line
{

// default strategy for types convertation
struct type_cast;

template<
    typename CharType = char
  , typename Context  = boost::command_line::default_context<CharType,'-','\"','\"',','>
  , typename TypeCast = type_cast
  >
class interpreter:
  detail::base_interpreter<CharType, TypeCast>
{
  typedef detail::base_interpreter<CharType, TypeCast> supper_t;

public:

  typedef typename supper_t::type_cast_t type_cast_t;
  typedef typename supper_t::string_type string_type;
  typedef Context  context_t;
  typedef CharType char_t;


  /// Registers options. 
  /**
   *  This function registrates command options. 
   *  The option parameters count and their types will be obtained 
   *  automatically from the handler�s signature.
   *
   *  @param handler This can either be a pointer to a function or an object 
   *       whose class overloads operator().
   *
   *  @param option_name Name of this option.
   *
   *  @param help_information Option's description.
   *
   *  @returns The proxy-object will be returned. The class of this object 
   *  overloads operator[]. Calls to that operator registrate synonym of this
   *  option. If synonym or option with this name already exists an exception
   *  will be thrown.
   *
   *  @throws If an option with this name already exists an exception will be 
   *  thrown.
   *   
   *  @code
   *   interpreter<> l;
   *   
   *   l.add(&some_fn, "option_name", "option_help_info");
   *     // where some_fn  is function.
   *
   *   l.add(object, "option_name", "option_help_info");
   *     // where object has only one non-template operator()
   *  @endcode
   */
  template<
    typename Handler
  >
  typename supper_t::proxy_t add(
      Handler const& handler
    , string_type const& option_name
    , string_type const& help_information
    )
    { return supper_t::add(handler,option_name,help_information); }

  /// Registers options. 
  /**
   * This function registrates command options. 
   *
   * @param handler This can either be a pointer to a function or an object 
   *      whose class overloads operator().
   *
   * @param option_name Name of this option.
   *
   * @param help_info Option's description.
   *
   * @returns The proxy-object will be returned. The class of this object 
   * overloads operator[]. Calls to that operator registrate synonym of this
   * option. If synonym or option with this name already exists an exception
   * will be thrown.
   *
   * @throws If an option with this name already exists an exception will be 
   * thrown.
   *  
   * @code
   * interpreter<> l;
   * l.add<void (A1,...,An)> (object, "option_name", "option_help_info");
   * @endcode
   */

  template<
      typename HndlSign
    , typename Handler
  >
  typename supper_t::proxy_t add(
      Handler const& handler
    , string_type const& option_name
    , string_type const& help_info
    )
    { return supper_t::template add<HndlSign>(handler,option_name,help_info); }

  /// Removes an option in a interpreter with name.
  /** 
   * This function removes an option by name.
   * @param option_name Name of the option.
   */

  void erase(string_type const& option_name)
    { supper_t::erase(option_name); }

  /// Visits all options.
  /** 
   * 
   * @param visitor An object or pointer to a function.
   *
   * @note The visitor taking (string_type command_name, iterator 
   * first_synonim, iterator last_synonim, string_type help_information).
   * 
   */
  template<
      typename Visitor
    >
  void visit(Visitor& visitor) const
    { supper_t::visit(visitor); }


  /// Invokes handler
  /** Invokes handler by option name with parameters [args_begin, args_end).
   *
   *  @param option_name Name of an option
   *
   *  @param args_begin Iterator referring to the first argument for 
   *  the option.
   *  @param args_end   Iterator referring to the past-the-end argument for the
   *  option.
   *
   *  @throws If option isn't found or handler of this options takes more
   *  required arguments or they can't be converted an exception will be 
   *  thrown.
   */
  
  template<
      typename It
    >
  void invoke (
      string_type const& option_name
    , It args_begin
    , It args_end
    ) const
  {
    type_cast_t type_cast;
    supper_t::invoke(option_name, args_begin, args_end, type_cast);
  }

  /// Swap two entries in the interpreter.
  /**
   * This function exchanges the content of the interpreter by the content
   * of interpreter, which is another interpreter of the same type.
   *
   * @param rh 
   */

  void swap(interpreter&rh)
    { supper_t::swap(rh); }


  interpreter()
    { }
  
  interpreter(interpreter const& rh)
    : supper_t(rh)
    { }

  interpreter& operator = (interpreter const& rh)
  {
    if(this != &rh)
      { interpreter(rh).swap(*this); }
    return *this;
  }
  

  /// adds options
  /** 
   *  This operator adds options to the container from anoter interpreter.
   *  @param rh 
   *  @returns Reference to itself
   *  @throws If an option with some name already exists an exception will be
   *  thrown.
   */
  interpreter & operator += (interpreter const& rh)
  {
    supper_t::operator += (rh);
    return *this;
  }
};

/// adds options
/** 
 *  This operator merges options of two different interpreter.
 *  @param lh 
 *  @param rh 
 *  @returns Temporary object will be returned.
 *  @throws If an option with some name already exists an exception will be
 *  thrown.
 */
template<
    typename CharType
  , typename Context
  , typename TypeCast
  >
interpreter<CharType,Context,TypeCast> operator + (
    interpreter<CharType,Context,TypeCast> const& lh
  , interpreter<CharType,Context,TypeCast> const& rh
  )
{
  interpreter<CharType,Context,TypeCast> ret(lh);
  return ret += rh;
}


/// Invokes all all requested options.
/**
  * This function parses a string and calles the appropriate handlers for all 
  * requested options.
  * 
  * @param interpreter command_line::interpreter
  *
  * @param str String data
  */
template<
    typename Line
  >
void invoke_all(Line& interpreter, typename Line::char_t const * str)
{
  typename Line::context_t context(str);
  for(typename Line::context_t::const_iterator it(context.begin())
    , end(context.end()); it != end; ++it)
    { interpreter.invoke(it->name(), it->arg_begin(), it->arg_end()); }
}

template<
    typename CharType
  , typename Context
  , typename TypeCast
  >
std::basic_ostream<CharType>& operator << (
    std::basic_ostream<CharType>& os
  , interpreter<CharType,Context,TypeCast> const& l
  ) ;

} // namespace command_line

} // namespace boost

#include <boost/command_line/interpreter.ipp>

#endif //BOOST_COMMAND_LINE_INTERPRETER_HPP
