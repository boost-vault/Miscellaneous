#ifndef SDFASDFASDFQWERSDFRGWERGWYWRTYWRYTWRTYRTYWRETYERYQERYYAERHEQWER
#define SDFASDFASDFQWERSDFRGWERGWYWRTYWRYTWRTYRTYWRETYERYQERYYAERHEQWER

#include <numeric>
#include <string>


namespace example
{

struct str_plus : std::binary_function <std::string,std::string,std::string> {
  std::string operator() (const std::string& x, const std::string& y) const
    { return x+" "+y;}
};

std::string accumulate(const char** b,const char** e)
  { return std::accumulate(b,e,std::string(),str_plus()); }


} // namespace example


#endif 
