//////////////////////////////////////////////////////////////////
// Copyright 2010 - 2011. Alexey Tsoy.
// Distributed under the Boost Software License, Version 1.0. (See
// accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)
#include <boost/command_line.hpp>
#include <boost/lambda/bind.hpp>
#include <boost/lambda/lambda.hpp>
#include <boost/shared_ptr.hpp>
#include <boost/smart_ptr/make_shared.hpp>
#include <fstream>
#include <iostream>
#include <string>

namespace bl = boost::lambda;


struct interpreter: boost::command_line::interpreter<>
{
  interpreter()
  {
    add<void ()>(
        std::cout << bl::var(*this) << "\n"
      , "help", "produce a help message.") ["?"] ["h"];
  }
};

struct user_t
{
  interpreter cli_;
  std::string user_name_;
  bool logout_request_;

  user_t(std::string const& user_name)
    : user_name_(user_name)
    , logout_request_(false)
  {
    std::cout << "hi, " << user_name_ << std::endl;

    cli_.add<void ()>(
      (bl::var(this)->* &user_t::logout)(), "logout", "");
  }
  ~user_t()
    { std::cout << "bye, " << user_name_ << std::endl; }

  void logout()
    { logout_request_ = true; }

  bool logout_request() const
    { return logout_request_; }
};

struct envirment_t
{
  boost::shared_ptr<user_t> user_;
  interpreter cli_;

  envirment_t()
  { 
    cli_.add<void (std::string const&)> (
        (bl::var(this)->* &envirment_t::login)(), "login", "[user name] ");

    cli_.add<void ()>(bl::bind(::exit,0)       , "-exit" , "program exit");
  }

  void login(std::string const& user_name)
    { user_ = boost::make_shared<user_t>(user_name); }

  typedef boost::command_line::interpreter<>::context_t context_t;

  void invoke_one(context_t::value_type const& v)
  {
    if(!user_)
    { 
      cli_.invoke(v.name(), v.arg_begin(), v.arg_end());
      return;
    }

    user_->cli_.invoke(v.name(), v.arg_begin(), v.arg_end()); 
    
    if(user_->logout_request())
      { user_.reset(); }
  }

  void invoke(std::string const& str)
  {
    context_t context(str.c_str());

    std::for_each(context.begin(),context.end(),
      (bl::var(this)->* &envirment_t::invoke_one)());
  }
};

int main(int argc, const char** argv)
{
  envirment_t e;

  for(std::string str;std::getline(std::cin,str);)
  {
    try { e.invoke(str); }
      
    catch(std::exception const& ex)
      { std::cerr << "\n\t"<< ex.what() << std::endl; }
  }
}
