//////////////////////////////////////////////////////////////////
// Copyright 2010 - 2011. Alexey Tsoy.
// Distributed under the Boost Software License, Version 1.0. (See
// accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)
#include <boost/command_line.hpp>
#include <boost/lambda/bind.hpp>
#include <boost/lambda/lambda.hpp>
#include <fstream>
#include <functional>
#include <iostream>
#include <stdexcept>
#include "shared.hpp"

struct foo 
{
  typedef void result_type;

  void operator() (std::string const& v) const
    { std::cout << "foo value with the value of " << v << std::endl; }

  void operator() () const
    { (*this)("false"); }
};

void execute(std::string const& fname, boost::command_line::interpreter<>& cli)
{
  std::ifstream file(fname.c_str());
  
  if(!file)
    { throw std::logic_error("can't open file"); }

  std::stringstream ss;
  ss << file.rdbuf();
  boost::command_line::invoke_all(cli, ss.str().c_str());
}

int main(int argc, const char** argv) try
{
  using namespace boost::lambda;

  boost::command_line::interpreter<> cli;

  cli.add<void (    void   )>(foo()        , "fno-foo", "foo value will be set to false");
  cli.add<void (std::string)>(foo()        , "foo"    , "set foo value"                 );
  cli.add<void (void) >( bind(foo(),"true"), "ffoo"   , "foo value will be set to true" );
  
  cli.add<void ()>(
    std::cout << var(cli)  << "\n"         , "help"   , "produce a help message."       ) ["?"] ["h"];

  cli.add<void (std::string)>(
                bind(&execute,_1,var(cli)) , "exec"   , "[name of script] script will be executed")["e"];
  
  boost::command_line::invoke_all(cli, example::accumulate(argv+1,argv+argc).c_str());
  //boost::command_line::invoke_all(cli, "-e res.ini");
}

catch(std::exception const& ex)
  { std::cerr << ex.what() << std::endl; }
