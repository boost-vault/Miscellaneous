//////////////////////////////////////////////////////////////////
// Copyright 2010 - 2011. Tsoy Alexey.
// Distributed under the Boost Software License, Version 1.0. (See
// accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)
#include <boost/command_line.hpp>

#include <iostream> 
#include <functional>
#include <algorithm>
#include "shared.hpp"

boost::command_line::interpreter<> cli;

struct help_t
{
  void operator() () const
    { std::cout << cli << std::endl; }
};

struct compression_t
{
  void operator() (
    std::string const& file
  , boost::command_line::optional<int> const& compression
  , boost::command_line::optional<std::string> password
  ) const
  {
    std::cout << "\ncompression \"" << file << "\". ";
    
    if(compression)
      { std::cout << "Compression level was set as " << *compression; }
    else
      { std::cout << "Compression level select by default"; }

    if(password)
      { std::cout << ", password is \"" << *password << "\""; }
    else
      { std::cout << ", password is empty"; }
  }
};

struct inc_path_t
{
  void operator() (boost::command_line::ellipsis<std::string> const& e) const
  {
    std::copy(e.begin(), e.end(),
      std::ostream_iterator<std::string>
        (std::cout << "\nInclude paths are: " , ", "));
  }
};

int main(int argc, const char** argv) try
{
  cli.add(inc_path_t   (), "include"    , "[<dir_name>] .. [<,dir_name>]"       )["I"];
  cli.add(help_t       (), "help"       , "Produce a help message"              )["h"]["?"];
  cli.add(compression_t(), "compression", "[file_name] [<,level>] [<,password>]")["c"];

  boost::command_line::invoke_all(cli,example::accumulate(argv+1,argv+argc).c_str());
  //boost::command_line::invoke_all(cli, "-?");
}

catch(std::exception const& ex)
  { std::cout << ex.what() << std::endl; }



