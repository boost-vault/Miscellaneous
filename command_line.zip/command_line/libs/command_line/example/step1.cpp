//////////////////////////////////////////////////////////////////
// Copyright 2010 - 2011. Alexey Tsoy.
// Distributed under the Boost Software License, Version 1.0. (See
// accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)

#include <boost/command_line.hpp>
#include <iostream> 
#include "shared.hpp"

boost::command_line::interpreter<> cli;

struct help_t
{
  void operator() () const
    { std::cout << cli << std::endl; }
};

void echo_t (std::string const& s)
  { std::cout << s << std::endl; }

int main(int argc, const char** argv) try
{
  cli.add(help_t(), "help", "produce a help message"               )["h"]["?"];
  cli.add(&echo_t , "echo", "[str]. The parameter will be printed.");

  boost::command_line::invoke_all(cli,example::accumulate(argv+1,argv+argc).c_str());
  //boost::command_line::invoke_all(cli," -help \n -h -? -echo \"hello world\"");
}

catch(std::exception const& ex)
  { std::cout << ex.what() << std::endl; }



