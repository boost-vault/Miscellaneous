//////////////////////////////////////////////////////////////////
// test_invoke.cpp source file
//
// Copyright 2011. Alexey Tsoy.
// Distributed under the Boost Software License, Version 1.0. (See
// accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)
#include <boost/command_line.hpp>
#include <boost/lambda/bind.hpp>
#include <boost/lambda/lambda.hpp>

#define BOOST_TEST_MAIN
#include <boost/test/unit_test.hpp>

using namespace boost;
using namespace boost::lambda;
using namespace boost::unit_test;

struct some_class
{
  typedef void result_type;

  typedef command_line::ellipsis<boost::command_line::list<int, unsigned int, int> > ellipsis;

  unsigned int result;

  some_class() 
    : result(0)
    { }

  void operator() (command_line::optional<int> const& o, ellipsis const& e)
  {
    if(o)
      { result += *o; }

    for(ellipsis::const_iterator it(e.begin());it!=e.end();++it)
    {
      if(it->get<0>())  { result += *it->get<0>(); }
      if(it->get<1>())  { result += *it->get<1>(); }
      if(it->get<2>())  { result += *it->get<2>(); }
    }
  }
};

template<
    typename CharType
  >
int test_fn(CharType const* options_name, CharType const* command)
{
  some_class obj;

  command_line::interpreter<
      CharType
    , boost::command_line::default_context<CharType,'/','\"','\"',','>
    , boost::command_line::type_cast
    > cli;

  cli.template
    add< void (command_line::optional<int> const&, some_class::ellipsis const&) >
      (bind(ref(obj),_1,_2), options_name, std::basic_string<CharType>() );

  boost::command_line::invoke_all(cli,command);

  return obj.result;
}


BOOST_AUTO_TEST_CASE(test_case_1)
{
  BOOST_CHECK((  1 == test_fn("accumulate", "/accumulate 1")));
  BOOST_CHECK((  3 == test_fn("accumulate", "/accumulate 1, 2")));
  BOOST_CHECK((  6 == test_fn("accumulate", "/accumulate 1, 2, 3")));
  BOOST_CHECK(( 10 == test_fn("accumulate", "/accumulate 1, 2, 3, 4")));
  BOOST_CHECK(( 15 == test_fn("accumulate", "/accumulate 1, 2, 3, 4, 5")));
  BOOST_CHECK(( 21 == test_fn("accumulate", "/accumulate 1, 2, 3, 4, 5, 6")));
  BOOST_CHECK(( 28 == test_fn("accumulate", "/accumulate 1, 2, 3, 4, 5, 6, 7")));
  BOOST_CHECK(( 36 == test_fn("accumulate", "/accumulate 1, 2, 3, 4, 5, 6, 7, 8")));
  BOOST_CHECK(( 45 == test_fn("accumulate", "/accumulate 1, 2, 3, 4, 5, 6, 7, 8, 9")));
  BOOST_CHECK(( 55 == test_fn("accumulate", "/accumulate 1, 2, 3, 4, 5, 6, 7, 8, 9, 10")));
}

BOOST_AUTO_TEST_CASE(test_case_2)
{
  BOOST_CHECK((  1 == test_fn(L"accumulate", L"/accumulate 1")));
  BOOST_CHECK((  3 == test_fn(L"accumulate", L"/accumulate 1, 2")));
  BOOST_CHECK((  6 == test_fn(L"accumulate", L"/accumulate 1, 2, 3")));
  BOOST_CHECK(( 10 == test_fn(L"accumulate", L"/accumulate 1, 2, 3, 4")));
  BOOST_CHECK(( 15 == test_fn(L"accumulate", L"/accumulate 1, 2, 3, 4, 5")));
  BOOST_CHECK(( 21 == test_fn(L"accumulate", L"/accumulate 1, 2, 3, 4, 5, 6")));
  BOOST_CHECK(( 28 == test_fn(L"accumulate", L"/accumulate 1, 2, 3, 4, 5, 6, 7")));
  BOOST_CHECK(( 36 == test_fn(L"accumulate", L"/accumulate 1, 2, 3, 4, 5, 6, 7, 8")));
  BOOST_CHECK(( 45 == test_fn(L"accumulate", L"/accumulate 1, 2, 3, 4, 5, 6, 7, 8, 9")));
  BOOST_CHECK(( 55 == test_fn(L"accumulate", L"/accumulate 1, 2, 3, 4, 5, 6, 7, 8, 9, 10")));
}
