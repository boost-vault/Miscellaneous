//////////////////////////////////////////////////////////////////
// test_list.cpp source file
//
// Copyright 2011. Alexey Tsoy.
// Distributed under the Boost Software License, Version 1.0. (See
// accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)
#include <boost/command_line/list.hpp>

#define BOOST_TEST_MAIN
#include <boost/test/unit_test.hpp>

BOOST_AUTO_TEST_CASE(test_case_1)
{
  boost::command_line::list<int,float> list;
  BOOST_CHECK(!list.get<0>());
  BOOST_CHECK(!list.get<1>());

  list.get<1>() = 123;


  BOOST_CHECK(123 == *list.get<1>());
  BOOST_CHECK(false == list.get<0>());
}
