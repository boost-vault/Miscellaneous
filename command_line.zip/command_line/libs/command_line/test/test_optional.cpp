//////////////////////////////////////////////////////////////////
// test_optional.cpp source file
//
// Copyright 2011. Alexey Tsoy.
// Distributed under the Boost Software License, Version 1.0. (See
// accompanying file LICENSE_1_0.txt or copy at
// http://www.boost.org/LICENSE_1_0.txt)
#include <boost/command_line/optional.hpp>

#define BOOST_TEST_MAIN
#include <boost/test/unit_test.hpp>

BOOST_AUTO_TEST_CASE(test_case_1)
{
  boost::command_line::optional<int> optional;
  BOOST_CHECK(! optional );
  BOOST_CHECK(false == optional);

  optional = 123;

  BOOST_CHECK(optional);
  
  BOOST_CHECK(false == !optional);
  BOOST_CHECK(optional == true);
  BOOST_CHECK(true == optional);
  BOOST_CHECK(false != optional);

  BOOST_CHECK(123 == * optional);

  optional = 124;
  BOOST_CHECK(124 == * optional);

  optional = boost::command_line::optional<int>();

  BOOST_CHECK(! optional );
}
