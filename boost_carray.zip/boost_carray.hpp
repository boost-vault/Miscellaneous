/* The following code declares class carray, 
 * a STL container (as wrapper) for arrays of constant size 
 * which is set at runtime. 
 * 
 * (C) Copyright Boris Schaeling 2005. 
 * Distributed under the Boost Software License, Version 1.0. (See 
 * accompanying file LICENSE_1_0.txt or copy at 
 * http://www.boost.org/LICENSE_1_0.txt) 
 * 
 * 03 Oct 2005 - Initial Revision (Boris Schaeling) 
 * 
 * Oct 03, 2005 
 */ 
#ifndef BOOST_CARRAY_HPP 
#define BOOST_CARRAY_HPP 

#include <cstddef> 
#include <iterator> 
#include <algorithm> 
#include <stdexcept> 
#include <limits> 
#include <boost/shared_array.hpp> 

namespace boost { 

	template <class T> 
	class carray { 
	protected: 
		// fixed-size array of elements of type T 
		boost::shared_array<T> elems; 

		// number of elements 
		std::size_t length; 

	public: 
		// type definitions 
		typedef T              value_type; 
		typedef T*             iterator; 
		typedef const T*       const_iterator; 
		typedef T&             reference; 
		typedef const T&       const_reference; 
		typedef std::size_t    size_type; 
		typedef std::ptrdiff_t difference_type; 

		// constructors 
		explicit carray() : elems(0), length(0) { } 
		explicit carray(size_type size) : elems(size > 0 ? new T[size] : 0), length(size) { } 

		// iterator support 
		iterator begin() { return elems.get(); } 
		const_iterator begin() const { return elems.get(); } 
		iterator end() { return elems.get() + length; } 
		const_iterator end() const { return elems.get() + length; } 

		// reverse iterator support 
		typedef std::reverse_iterator<iterator> reverse_iterator; 
		typedef std::reverse_iterator<const_iterator> const_reverse_iterator; 

		reverse_iterator rbegin() { return reverse_iterator(end()); } 
		const_reverse_iterator rbegin() const { return const_reverse_iterator(end()); } 
		reverse_iterator rend() { return reverse_iterator(begin()); } 
		const_reverse_iterator rend() const { return const_reverse_iterator(begin()); } 

		// operator[] 
		reference operator[](size_type i) { return elems.get()[i]; } 
		const_reference operator[](size_type i) const { return elems[i]; } 

		// at() with range check 
		reference at(size_type i) { rangecheck(i); return elems.get()[i]; } 
		const_reference at(size_type i) const { rangecheck(i); return elems[i]; } 

		// front() and back() 
		reference front() { return elems.get()[0]; } 
		const_reference front() const { return elems[0]; } 
		reference back() { return elems.get()[length - 1]; } 
		const_reference back() const { return elems[length - 1]; } 

		// size is constant after instantiation 
		size_type size() const { return length; } 
		bool empty() const { return !length; } 
		size_type max_size() const { return (std::numeric_limits<size_type>::max)(); } 

		// swap 
		void swap(carray<T>& y) { 
			std::swap_ranges(begin(), end(), y.begin()); 
		} 

		// direct access to data (read-only) 
		const T* data() const { return elems.get(); } 

		// use carray as C array (read/write access) 
		T* data() { return elems.get(); } 

		// assignment with type conversion 
		template <class T2> 
		carray<T> &operator=(carray<T2>& rhs) { 
			std::copy(rhs.begin(), rhs.end(), begin()); 
			return *this; 
		} 

		// assign one value to all elements 
		void assign(const T &value) { 
			std::fill_n(begin(), length, value); 
		} 

	protected: 
		void rangecheck(size_type i) const { 
			if (i >= length) 
				throw std::out_of_range("carray<>: index out of range"); 
		} 
	}; 

	// comparisons 
	template <class T> 
	bool operator==(const carray<T> &x, const carray<T> &y) { 
		return std::equal(x.begin(), x.end(), y.begin()); 
	} 

	template <class T> 
	bool operator<(const carray<T> &x, const carray<T> &y) { 
		return std::lexicographical_compare(x.begin(), x.end(), y.begin(), y.end()); 
	} 

	template <class T> 
	bool operator!=(const carray<T> &x, const carray<T> &y) { 
		return !(x == y); 
	} 

	template <class T> 
	bool operator>(const carray<T> &x, const carray<T> &y) { 
		return y < x; 
	} 

	template <class T> 
	bool operator<=(const carray<T> &x, const carray<T> &y) { 
		return !(y < x); 
	} 

	template <class T> 
	bool operator>=(const carray<T> &x, const carray<T> &y) { 
		return !(x < y); 
	} 

	// global swap 
	template <class T> 
	inline void swap(carray<T> &x, carray<T> &y) { 
		x.swap(y); 
	} 
} 

#endif /*BOOST_CARRAY_HPP*/ 
