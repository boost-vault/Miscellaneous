// Copyright 2006 (C) Dean Michael Berris <dean@orangeandbronze.com>
// Distributed under the Boost Software License, Version 1.0. (See accompanying
// file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)

#define BOOST_AUTO_TEST_MAIN
#include <boost/test/auto_unit_test.hpp>
#include <boost/bind.hpp>
#include <string>

#include <boost/dispatch.hpp>

void void_function() {
};

void function (int) {
};

int function_returns_int (int i) {
    return 2;
};

BOOST_AUTO_TEST_CASE ( dispatch_invoker ) {
    typedef boost::dispatch::dispatcher < void (void) > void_dispatcher;
    void_dispatcher d;
    d[0] = void_function;
    d[1] = void_function;
    invoke_(d)() << 0 << 1;
};

BOOST_AUTO_TEST_CASE ( dispatch_arg1_invoker ) {
    typedef boost::dispatch::dispatcher < void (int) > void_int_dispatcher;
    void_int_dispatcher d1;
    d1[0] = function ;
    d1[1] = function ;
    invoke_(d1)(0) << 0 << 1;
};

struct int_aggregator {
    mutable std::vector<int> & _v;
    explicit int_aggregator (std::vector<int> & v) : _v(v) { };
    void operator() (int i) const {
        _v.push_back(i);
    };
};

BOOST_AUTO_TEST_CASE ( dispatch_arg1_accumulator_invoker ) {
    typedef boost::dispatch::dispatcher < int (int) > int_int_dispatcher;
    int_int_dispatcher d;
    d[0] = function_returns_int;
    d[1] = function_returns_int;
    std::vector<int> v;
    int_aggregator a(v);
    boost::dispatch::invoke_(d, a)(1) << 0 << 1;
    BOOST_REQUIRE_EQUAL (v[0], 2);
    BOOST_REQUIRE_EQUAL (v[1], 2);
};

int function_2args_returns_int (int a, int b) {
    return a+b;
};

BOOST_AUTO_TEST_CASE ( dispatch_arg2_accumulator_invoker ) {
    typedef boost::dispatch::dispatcher < int (int, int) > int_int_int_dispatcher;
    int_int_int_dispatcher d;
    d[0] = function_2args_returns_int;
    d[1] = function_2args_returns_int;
    std::vector<int> v;
    int_aggregator a(v);
    boost::dispatch::invoke_(d, a)(1, 2) << 0 << 1;
    BOOST_REQUIRE_EQUAL (v[0], 3);
    BOOST_REQUIRE_EQUAL (v[1], 3);
};

int int_function_3args(int i, int j, int k) {
    return i + j + k;
};

BOOST_AUTO_TEST_CASE ( dispatch_arg3_accumulator_invoker ) {
    typedef boost::dispatch::dispatcher < int (int, int, int) > int_int_int_int_dispatcher;
    int_int_int_int_dispatcher d;
    d[0] = int_function_3args;
    d[1] = int_function_3args;
    std::vector<int> v;
    int_aggregator a(v);
    boost::dispatch::invoke_(d, a)(1, 2, 3) << 0 << 1;
    BOOST_REQUIRE_EQUAL (v[0], 6);
    BOOST_REQUIRE_EQUAL (v[1], 6);
};

int int_function_4args(int i, int j, int k, int l) {
    return i + j + k + l;
};

BOOST_AUTO_TEST_CASE ( dispatch_arg4_accumulator_invoker ) {
    typedef boost::dispatch::dispatcher < int (int, int, int, int) > int_int_int_int_int_dispatcher;
    int_int_int_int_int_dispatcher d;
    d[0] = int_function_4args;
    d[1] = int_function_4args;
    std::vector<int> v;
    int_aggregator a(v);
    boost::dispatch::invoke_(d, a)(1, 2, 3, 4) << 0 << 1;
    BOOST_REQUIRE_EQUAL (v[0], 10);
    BOOST_REQUIRE_EQUAL (v[1], 10);
};

typedef boost::dispatch::dispatcher < int (int, int, int, int, int) > int_int_int_int_int_int_dispatcher;
int int_function_5args(int i, int j, int k, int l, int m) {
    return i + j + k + l + m;
};

BOOST_AUTO_TEST_CASE ( dispatch_arg5_accumulator_invoker ) {
    int_int_int_int_int_int_dispatcher d;
    d[0] = int_function_5args;
    d[1] = int_function_5args;
    std::vector<int> v;
    int_aggregator a(v);
    boost::dispatch::invoke_(d, a)(1, 2, 3, 4, 5) << 0 << 1;
    BOOST_REQUIRE_EQUAL (v[0], 15);
    BOOST_REQUIRE_EQUAL (v[1], 15);
};

typedef boost::dispatch::dispatcher < int (int, int, int, int, int, int) > int_int_int_int_int_int_int_dispatcher;
int int_function_6args(int i, int j, int k, int l, int m, int n) {
    return i + j + k + l + m + n;
};

BOOST_AUTO_TEST_CASE ( dispatch_arg6_accumulator_invoker ) {
    int_int_int_int_int_int_int_dispatcher d;
    d[0] = int_function_6args;
    d[1] = int_function_6args;
    std::vector<int> v;
    int_aggregator a(v);
    boost::dispatch::invoke_(d, a)
        (1, 2, 3, 4, 5, 6) 
        << 0 
        << 1;
    BOOST_REQUIRE_EQUAL (v[0], 21);
    BOOST_REQUIRE_EQUAL (v[1], 21);
};
