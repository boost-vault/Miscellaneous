// Copyright 2006 (C) Dean Michael Berris <dean@orangeandbronze.com>
// Distributed under the Boost Software License, Version 1.0. (See accompanying
// file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)

#ifndef __DISPATCH_HPP_
#define __DISPATCH_HPP_

#include <map>
#include <vector>
#include <boost/noncopyable.hpp>
#include <boost/function.hpp>
#include <boost/dispatch/functor0.hpp>
#include <boost/dispatch/functor1.hpp>
#include <boost/dispatch/functor2.hpp>
#include <boost/dispatch/functor3.hpp>
#include <boost/dispatch/functor4.hpp>
#include <boost/dispatch/functor5.hpp>
#include <boost/dispatch/functor6.hpp>
#include <boost/dispatch/dispatch_helper.hpp>
#include <boost/dispatch/dispatch_exceptions.hpp>
#include <boost/dispatch/detail/default_routing.hpp>
#include <boost/dispatch/detail/always_true.hpp>

// deprecated ?
#include <boost/dispatch/invoke.hpp>

namespace boost {
    namespace dispatch {
        namespace detail {
            template <typename Signature, 
                typename IndexType = int, 
				typename DecisionStrategy = boost::dispatch::detail::always_true<IndexType>,
				typename RoutingStrategy = boost::dispatch::detail::default_routing<IndexType>
            >
            class registry_impl : boost::noncopyable
            {
            public:
                typedef typename boost::function_traits<Signature>::result_type result_type;
                typedef IndexType index_type;
                typedef typename std::map<IndexType, functor<Signature> >::iterator iterator;
                typedef Signature signature;

                iterator begin() const {
                    return _map.begin();
                };

                iterator end() const {
                    return _map.end();
                };

                functor<Signature> & operator[] (const IndexType & index) {
                    if (_index_validator(index)) 
                        return _map[_router(index)];

                    throw invalid_index<IndexType>(index);
                };

                void unset (IndexType index) {
                    _map.erase(index);
                };

                DecisionStrategy _index_validator;
                RoutingStrategy _router;

            private:
                std::map<IndexType, functor<Signature> > _map;
            };

        }; // namespace detail

        template <typename Signature, 
            typename IndexType = int, 
			typename DecisionStrategy = boost::dispatch::detail::always_true<IndexType>,
			typename RoutingStrategy = boost::dispatch::detail::default_routing<IndexType>
        >
		struct dispatcher : public boost::dispatch::detail::registry_impl <Signature,
            IndexType, 
            DecisionStrategy,
            RoutingStrategy
        > {
			typedef boost::dispatch::detail::registry_impl <Signature, 
                IndexType, 
                DecisionStrategy, 
                RoutingStrategy> base_type;

            //typedef invoke_<base_type> invoke_ ;
        };

    }; // namespace dispatch
}; // namespace boost

#endif


#ifndef BOOST_DISPATCH
#define BOOST_DISPATCH(C,A) \
    try { C ; } \
    catch (boost::dispatch::unregistered_handler &) { A ; } ;
#endif
