// Copyright 2006 (C) Dean Michael Berris <dean@orangeandbronze.com>
// Distributed under the Boost Software License, Version 1.0. (See accompanying
// file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)

#ifndef __INVOKE_HPP__
#define __INVOKE_HPP__

#include <boost/type_traits/function_traits.hpp>
#include <boost/dispatch/detail/invoke_impl0.hpp>
#include <boost/dispatch/detail/invoke_impl1.hpp>
#include <boost/dispatch/detail/invoke_impl2.hpp>
#include <boost/dispatch/detail/invoke_impl3.hpp>
#include <boost/dispatch/detail/invoke_impl4.hpp>
#include <boost/dispatch/detail/invoke_impl5.hpp>
#include <boost/dispatch/detail/invoke_impl6.hpp>
#include <boost/dispatch/detail/default_aggregator.hpp>

#include <boost/dispatch/alt.hpp>

namespace boost {
    namespace dispatch {
        namespace detail {

            template <  int Arity, typename T, typename Signature >
            struct get_real_invoke_impl;

            template < typename T, typename Signature >
            struct get_real_invoke_impl <0, T, Signature> {
                typedef invoke_impl_0<
                    typename T::result_type,
                    T
                > type;
            };

            template < typename T, typename Signature >
            struct get_real_invoke_impl <1, T, Signature> {
                typedef boost::function_traits<Signature> traits;
                typedef invoke_impl_1<
                    typename T::result_type,
                    T,
                    typename traits::arg1_type
                > type;
            };

            template < typename T, typename Signature >
            struct get_real_invoke_impl <2, T, Signature> {
                typedef boost::function_traits<Signature> traits;
                typedef invoke_impl_2<
                    typename T::result_type,
                    T,
                    typename traits::arg1_type,
                    typename traits::arg2_type
                > type;
            };

            template < typename T, typename Signature >
            struct get_real_invoke_impl <3, T, Signature> {
                typedef boost::function_traits<Signature> traits;
                typedef invoke_impl_3<
                    typename T::result_type,
                    T,
                    typename traits::arg1_type,
                    typename traits::arg2_type,
                    typename traits::arg3_type
                > type;
            };

            template < typename T, typename Signature >
            struct get_real_invoke_impl <4, T, Signature> {
                typedef boost::function_traits<Signature> traits;
                typedef invoke_impl_4<
                    typename T::result_type,
                    T,
                    typename traits::arg1_type,
                    typename traits::arg2_type,
                    typename traits::arg3_type,
                    typename traits::arg4_type
                > type;
            };

            template < typename T, typename Signature >
            struct get_real_invoke_impl <5, T, Signature> {
                typedef boost::function_traits<Signature> traits;
                typedef invoke_impl_5<
                    typename T::result_type,
                    T,
                    typename traits::arg1_type,
                    typename traits::arg2_type,
                    typename traits::arg3_type,
                    typename traits::arg4_type,
                    typename traits::arg5_type
                > type;
            };

            template < typename T, typename Signature >
            struct get_real_invoke_impl <6, T, Signature> {
                typedef boost::function_traits<Signature> traits;
                typedef invoke_impl_6<
                    typename T::result_type,
                    T,
                    typename traits::arg1_type,
                    typename traits::arg2_type,
                    typename traits::arg3_type,
                    typename traits::arg4_type,
                    typename traits::arg5_type,
                    typename traits::arg6_type
                > type;
            };

            template <typename T>
            struct get_invoke_impl {
                typedef typename get_real_invoke_impl<
                    boost::function_traits<typename T::signature>::arity,
                    T,
                    typename T::signature
                >::type type;
            };

        }; // namespace detail

        /*
        template <typename T>
        struct invoke_ : detail::get_invoke_impl<T>::type {
            typedef typename detail::get_invoke_impl<T>::type base_type ;
            invoke_ (T & dispatcher, 
                boost::function< void (typename T::index_type) > f 
                = detail::default_aggregator<typename T::result_type>())
                : base_type (dispatcher, f)
            { };
        };*/

        template <typename DispatcherType> 
            typename detail::get_invoke_impl<DispatcherType>::type 
            invoke_(DispatcherType & dispatcher) { 
                return typename detail::get_invoke_impl<DispatcherType>::type (dispatcher, detail::default_aggregator<typename DispatcherType::result_type>());
            };

        template <typename DispatcherType, typename AggregatorType>
            typename detail::get_invoke_impl<DispatcherType>::type
            invoke_(DispatcherType & dispatcher, 
                    AggregatorType aggregator) {
                return typename detail::get_invoke_impl<DispatcherType>::type(dispatcher, boost::function<void(typename DispatcherType::result_type)>(aggregator));
            };

    }; // namespace dispatch
}; // namespace boost

#endif
