// Copyright 2006 (C) Dean Michael Berris <dean@orangeandbronze.com>
// Distributed under the Boost Software License, Version 1.0. (See accompanying
// file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)

#ifndef __INVOKE_IMPL0_HPP_
#define __INVOKE_IMPL0_HPP_

#include <boost/function.hpp>
#include <boost/dispatch/detail/default_aggregator.hpp>
#include <boost/dispatch/dispatch_exceptions.hpp>

#include <boost/fusion/tuple.hpp>

namespace boost { namespace dispatch { namespace detail {

    using namespace boost::fusion ;

    template <typename ReturnType, typename DispatcherType>
        struct invoke_impl_0_callable {
            typedef boost::function<void (typename DispatcherType::result_type) > aggregator_t;

            DispatcherType & _dispatcher;
            const aggregator_t _aggregator;
            
            invoke_impl_0_callable (
                    DispatcherType & dispatcher,
                    aggregator_t const & aggregator
                    ) 
                : _dispatcher(dispatcher),
                _aggregator(aggregator)
            { };
        };

    template <typename DispatcherType>
        struct invoke_impl_0_callable <void, DispatcherType> {
            typedef boost::function<void(int)> aggregator_t;
            DispatcherType & _dispatcher;
            const aggregator_t _aggregator;

            invoke_impl_0_callable (
                    DispatcherType & dispatcher,
                    aggregator_t const & aggregator
                    )
                : _dispatcher(dispatcher),
                _aggregator(aggregator)
            { };
        };

    template <typename ReturnType, typename DispatcherType>
    struct invoke_impl_0 {
        typedef typename DispatcherType::index_type index_type;
        typedef boost::function<void ( typename DispatcherType::result_type )> aggregator_t;
        invoke_impl_0 (
            DispatcherType & dispatcher, 
            aggregator_t aggregator
            ) 
            : _dispatcher(dispatcher), _aggregator(aggregator)
        { };

        invoke_impl_0_callable<ReturnType, DispatcherType>
            operator() () const {
                return invoke_impl_0_callable<ReturnType, DispatcherType>(_dispatcher, _aggregator);
            };

        DispatcherType & _dispatcher;
        aggregator_t _aggregator;
    };

    template <typename DispatcherType>
    struct invoke_impl_0 <void, DispatcherType> {
        typedef typename DispatcherType::index_type index_type;
        typedef boost::function<void ( int )> aggregator_t;
        invoke_impl_0 (
            DispatcherType & dispatcher, 
            aggregator_t aggregator
            ) 
            : _dispatcher(dispatcher), _aggregator(default_aggregator<void>())
        { };

        invoke_impl_0_callable<void, DispatcherType>
            operator() () const {
                return invoke_impl_0_callable<void, DispatcherType> (_dispatcher, _aggregator);
            };

        DispatcherType & _dispatcher;
        aggregator_t _aggregator;
    };

    template <typename ReturnType, typename DispatcherType>
    invoke_impl_0_callable<ReturnType, DispatcherType> operator << 
        (
        invoke_impl_0_callable<ReturnType, DispatcherType> const & invoker, 
        typename DispatcherType::index_type const & index
        ) 
    {
        invoker._aggregator(
            (invoker._dispatcher[index]())
            );
        return invoker;
    };

    template <typename DispatcherType>
    invoke_impl_0_callable<void, DispatcherType> operator <<
        (
        invoke_impl_0_callable<void, DispatcherType> const & invoker,
        typename DispatcherType::index_type const & index
        )
    {
        invoker._dispatcher[index]();
        return invoker;
    };

    template <typename DispatcherType>
        invoke_impl_0_callable<void, DispatcherType> operator<< (
         invoke_impl_0_callable<void, DispatcherType> const & invoker,
         tuple<
            typename DispatcherType::index_type,
            typename DispatcherType::index_type
            > const & alternator) {

            try {
                invoker._dispatcher[get<0>(alternator)]();
            } catch (unregistered_handler &) {
                invoker._dispatcher[get<1>(alternator)]();
            };

            return invoker;
        };

    template <typename DispatcherType>
        invoke_impl_0_callable<void, DispatcherType> operator<< (
         invoke_impl_0_callable<void, DispatcherType> const & invoker,
         tuple<
            typename DispatcherType::index_type,
            typename DispatcherType::index_type,
            typename DispatcherType::index_type
            > const & alternator) {
            try {
                invoker._dispatcher[get<0>(alternator)]();
            } catch (unregistered_handler &) {
                try {
                    invoker._dispatcher[get<1>(alternator)]();
                } catch (unregistered_handler &) {
                    invoker._dispatcher[get<2>(alternator)]();
                };
            };

            return invoker;
        };

    template <typename DispatcherType>
        invoke_impl_0_callable<void, DispatcherType> operator<< (
         invoke_impl_0_callable<void, DispatcherType> const & invoker,
         tuple<
            typename DispatcherType::index_type,
            typename DispatcherType::index_type,
            typename DispatcherType::index_type,
            typename DispatcherType::index_type
            > const & alternator) {
            try {
                invoker._dispatcher[get<0>(alternator)]();
            } catch (unregistered_handler &) {
                try {
                    invoker._dispatcher[get<1>(alternator)]();
                } catch (unregistered_handler &) {
                    try {
                        invoker._dispatcher[get<2>(alternator)]();
                    } catch (unregistered_handler &) {
                        invoker._dispatcher[get<3>(alternator)]();
                    };
                };
            };

            return invoker;
        };

    template <typename DispatcherType>
        invoke_impl_0_callable<void, DispatcherType> operator<< (
         invoke_impl_0_callable<void, DispatcherType> const & invoker,
         tuple<
            typename DispatcherType::index_type,
            typename DispatcherType::index_type,
            typename DispatcherType::index_type,
            typename DispatcherType::index_type,
            typename DispatcherType::index_type
            > const & alternator) {
            try {
                invoker._dispatcher[get<0>(alternator)]();
            } catch (unregistered_handler &) {
                try {
                    invoker._dispatcher[get<1>(alternator)]();
                } catch (unregistered_handler &) {
                    try {
                        invoker._dispatcher[get<2>(alternator)]();
                    } catch (unregistered_handler &) {
                        try {
                            invoker._dispatcher[get<3>(alternator)]();
                        } catch (unregistered_handler &) {
                            invoker._dispatcher[get<4>(alternator)]();
                        };
                    };
                };
            };

            return invoker;
        };

    template <typename DispatcherType>
        invoke_impl_0_callable<void, DispatcherType> operator<< (
         invoke_impl_0_callable<void, DispatcherType> const & invoker,
         tuple<
            typename DispatcherType::index_type,
            typename DispatcherType::index_type,
            typename DispatcherType::index_type,
            typename DispatcherType::index_type,
            typename DispatcherType::index_type,
            typename DispatcherType::index_type
            > const & alternator) {
            try {
                invoker._dispatcher[get<0>(alternator)]();
            } catch (unregistered_handler &) {
                try {
                    invoker._dispatcher[get<1>(alternator)]();
                } catch (unregistered_handler &) {
                    try {
                        invoker._dispatcher[get<2>(alternator)]();
                    } catch (unregistered_handler &) {
                        try {
                            invoker._dispatcher[get<3>(alternator)]();
                        } catch (unregistered_handler &) {
                            try {
                                invoker._dispatcher[get<4>(alternator)]();
                            } catch (unregistered_handler &) {
                                invoker._dispatcher[get<5>(alternator)]();
                            };
                        };
                    };
                };
            };

            return invoker;
        };

    template <typename DispatcherType>
        invoke_impl_0_callable<void, DispatcherType> operator<< (
         invoke_impl_0_callable<void, DispatcherType> const & invoker,
         tuple<
            typename DispatcherType::index_type,
            typename DispatcherType::index_type,
            typename DispatcherType::index_type,
            typename DispatcherType::index_type,
            typename DispatcherType::index_type,
            typename DispatcherType::index_type,
            typename DispatcherType::index_type
            > const & alternator) {
            try {
                invoker._dispatcher[get<0>(alternator)]();
            } catch (unregistered_handler &) {
                try {
                    invoker._dispatcher[get<1>(alternator)]();
                } catch (unregistered_handler &) {
                    try {
                        invoker._dispatcher[get<2>(alternator)]();
                    } catch (unregistered_handler &) {
                        try {
                            invoker._dispatcher[get<3>(alternator)]();
                        } catch (unregistered_handler &) {
                            try {
                                invoker._dispatcher[get<4>(alternator)]();
                            } catch (unregistered_handler &) {
                                try {
                                    invoker._dispatcher[get<5>(alternator)]();
                                } catch (unregistered_handler &) {
                                    invoker._dispatcher[get<6>(alternator)]();
                                };
                            };
                        };
                    };
                };
            };

            return invoker;
        };

    template <typename DispatcherType>
        invoke_impl_0_callable<void, DispatcherType> operator<< (
         invoke_impl_0_callable<void, DispatcherType> const & invoker,
         tuple<
            typename DispatcherType::index_type,
            typename DispatcherType::index_type,
            typename DispatcherType::index_type,
            typename DispatcherType::index_type,
            typename DispatcherType::index_type,
            typename DispatcherType::index_type,
            typename DispatcherType::index_type,
            typename DispatcherType::index_type
            > const & alternator) {
            try {
                invoker._dispatcher[get<0>(alternator)]();
            } catch (unregistered_handler &) {
                try {
                    invoker._dispatcher[get<1>(alternator)]();
                } catch (unregistered_handler &) {
                    try {
                        invoker._dispatcher[get<2>(alternator)]();
                    } catch (unregistered_handler &) {
                        try {
                            invoker._dispatcher[get<3>(alternator)]();
                        } catch (unregistered_handler &) {
                            try {
                                invoker._dispatcher[get<4>(alternator)]();
                            } catch (unregistered_handler &) {
                                try {
                                    invoker._dispatcher[get<5>(alternator)]();
                                } catch (unregistered_handler &) {
                                    try {
                                        invoker._dispatcher[get<6>(alternator)]();
                                    } catch (unregistered_handler &) {
                                        invoker._dispatcher[get<7>(alternator)]();
                                    };
                                };
                            };
                        };
                    };
                };
            };

            return invoker;
        };

    template <typename DispatcherType>
        invoke_impl_0_callable<void, DispatcherType> operator<< (
         invoke_impl_0_callable<void, DispatcherType> const & invoker,
         tuple<
            typename DispatcherType::index_type,
            typename DispatcherType::index_type,
            typename DispatcherType::index_type,
            typename DispatcherType::index_type,
            typename DispatcherType::index_type,
            typename DispatcherType::index_type,
            typename DispatcherType::index_type,
            typename DispatcherType::index_type,
            typename DispatcherType::index_type
            > const & alternator) {
            try {
                invoker._dispatcher[get<0>(alternator)]();
            } catch (unregistered_handler &) {
                try {
                    invoker._dispatcher[get<1>(alternator)]();
                } catch (unregistered_handler &) {
                    try {
                        invoker._dispatcher[get<2>(alternator)]();
                    } catch (unregistered_handler &) {
                        try {
                            invoker._dispatcher[get<3>(alternator)]();
                        } catch (unregistered_handler &) {
                            try {
                                invoker._dispatcher[get<4>(alternator)]();
                            } catch (unregistered_handler &) {
                                try {
                                    invoker._dispatcher[get<5>(alternator)]();
                                } catch (unregistered_handler &) {
                                    try {
                                        invoker._dispatcher[get<6>(alternator)]();
                                    } catch (unregistered_handler &) {
                                        try {
                                            invoker._dispatcher[get<7>(alternator)]();
                                        } catch (unregistered_handler &) {
                                            invoker._dispatcher[get<8>(alternator)]();
                                        };
                                    };
                                };
                            };
                        };
                    };
                };
            };

            return invoker;
        };

    template <typename DispatcherType>
        invoke_impl_0_callable<void, DispatcherType> operator<< (
         invoke_impl_0_callable<void, DispatcherType> const & invoker,
         tuple<
            typename DispatcherType::index_type,
            typename DispatcherType::index_type,
            typename DispatcherType::index_type,
            typename DispatcherType::index_type,
            typename DispatcherType::index_type,
            typename DispatcherType::index_type,
            typename DispatcherType::index_type,
            typename DispatcherType::index_type,
            typename DispatcherType::index_type,
            typename DispatcherType::index_type
            > const & alternator) {
            try {
                invoker._dispatcher[get<0>(alternator)]();
            } catch (unregistered_handler &) {
                try {
                    invoker._dispatcher[get<1>(alternator)]();
                } catch (unregistered_handler &) {
                    try {
                        invoker._dispatcher[get<2>(alternator)]();
                    } catch (unregistered_handler &) {
                        try {
                            invoker._dispatcher[get<3>(alternator)]();
                        } catch (unregistered_handler &) {
                            try {
                                invoker._dispatcher[get<4>(alternator)]();
                            } catch (unregistered_handler &) {
                                try {
                                    invoker._dispatcher[get<5>(alternator)]();
                                } catch (unregistered_handler &) {
                                    try {
                                        invoker._dispatcher[get<6>(alternator)]();
                                    } catch (unregistered_handler &) {
                                        try {
                                            invoker._dispatcher[get<7>(alternator)]();
                                        } catch (unregistered_handler &) {
                                            try {
                                                invoker._dispatcher[get<8>(alternator)]();
                                            } catch (unregistered_handler &) {
                                                invoker._dispatcher[get<9>(alternator)]();
                                            };
                                        };
                                    };
                                };
                            };
                        };
                    };
                };
            };

            return invoker;
        };

    template <typename ReturnType, typename DispatcherType>
        invoke_impl_0_callable<ReturnType, DispatcherType> operator<< (
         invoke_impl_0_callable<ReturnType, DispatcherType> const & invoker,
         tuple<
            typename DispatcherType::index_type,
            typename DispatcherType::index_type
            > const & alternator) {

            try {
                invoker._aggregator(invoker._dispatcher[get<0>(alternator)]());
            } catch (unregistered_handler &) {
                invoker._aggregator(invoker._dispatcher[get<1>(alternator)]());
            };

            return invoker;
        };

    template <typename ReturnType, typename DispatcherType>
        invoke_impl_0_callable<ReturnType, DispatcherType> operator<< (
         invoke_impl_0_callable<ReturnType, DispatcherType> const & invoker,
         tuple<
            typename DispatcherType::index_type,
            typename DispatcherType::index_type,
            typename DispatcherType::index_type
            > const & alternator) {
            try {
                invoker._aggregator(invoker._dispatcher[get<0>(alternator)]());
            } catch (unregistered_handler &) {
                try {
                    invoker._aggregator(invoker._dispatcher[get<1>(alternator)]());
                } catch (unregistered_handler &) {
                    invoker._aggregator(invoker._dispatcher[get<2>(alternator)]());
                };
            };

            return invoker;
        };

    template <typename ReturnType, typename DispatcherType>
        invoke_impl_0_callable<ReturnType, DispatcherType> operator<< (
         invoke_impl_0_callable<ReturnType, DispatcherType> const & invoker,
         tuple<
            typename DispatcherType::index_type,
            typename DispatcherType::index_type,
            typename DispatcherType::index_type,
            typename DispatcherType::index_type
            > const & alternator) {
            try {
                invoker._aggregator(invoker._dispatcher[get<0>(alternator)]());
            } catch (unregistered_handler &) {
                try {
                    invoker._aggregator(invoker._dispatcher[get<1>(alternator)]());
                } catch (unregistered_handler &) {
                    try {
                        invoker._aggregator(invoker._dispatcher[get<2>(alternator)]());
                    } catch (unregistered_handler &) {
                        invoker._aggregator(invoker._dispatcher[get<3>(alternator)]());
                    };
                };
            };

            return invoker;
        };

    template <typename ReturnType, typename DispatcherType>
        invoke_impl_0_callable<ReturnType, DispatcherType> operator<< (
         invoke_impl_0_callable<ReturnType, DispatcherType> const & invoker,
         tuple<
            typename DispatcherType::index_type,
            typename DispatcherType::index_type,
            typename DispatcherType::index_type,
            typename DispatcherType::index_type,
            typename DispatcherType::index_type
            > const & alternator) {
            try {
                invoker._aggregator(invoker._dispatcher[get<0>(alternator)]());
            } catch (unregistered_handler &) {
                try {
                    invoker._aggregator(invoker._dispatcher[get<1>(alternator)]());
                } catch (unregistered_handler &) {
                    try {
                        invoker._aggregator(invoker._dispatcher[get<2>(alternator)]());
                    } catch (unregistered_handler &) {
                        try {
                            invoker._aggregator(invoker._dispatcher[get<3>(alternator)]());
                        } catch (unregistered_handler &) {
                            invoker._aggregator(invoker._dispatcher[get<4>(alternator)]());
                        };
                    };
                };
            };

            return invoker;
        };

    template <typename ReturnType, typename DispatcherType>
        invoke_impl_0_callable<ReturnType, DispatcherType> operator<< (
         invoke_impl_0_callable<ReturnType, DispatcherType> const & invoker,
         tuple<
            typename DispatcherType::index_type,
            typename DispatcherType::index_type,
            typename DispatcherType::index_type,
            typename DispatcherType::index_type,
            typename DispatcherType::index_type,
            typename DispatcherType::index_type
            > const & alternator) {
            try {
                invoker._aggregator(invoker._dispatcher[get<0>(alternator)]());
            } catch (unregistered_handler &) {
                try {
                    invoker._aggregator(invoker._dispatcher[get<1>(alternator)]());
                } catch (unregistered_handler &) {
                    try {
                        invoker._aggregator(invoker._dispatcher[get<2>(alternator)]());
                    } catch (unregistered_handler &) {
                        try {
                            invoker._aggregator(invoker._dispatcher[get<3>(alternator)]());
                        } catch (unregistered_handler &) {
                            try {
                                invoker._aggregator(invoker._dispatcher[get<4>(alternator)]());
                            } catch (unregistered_handler &) {
                                invoker._aggregator(invoker._dispatcher[get<5>(alternator)]());
                            };
                        };
                    };
                };
            };

            return invoker;
        };

    template <typename ReturnType, typename DispatcherType>
        invoke_impl_0_callable<ReturnType, DispatcherType> operator<< (
         invoke_impl_0_callable<ReturnType, DispatcherType> const & invoker,
         tuple<
            typename DispatcherType::index_type,
            typename DispatcherType::index_type,
            typename DispatcherType::index_type,
            typename DispatcherType::index_type,
            typename DispatcherType::index_type,
            typename DispatcherType::index_type,
            typename DispatcherType::index_type
            > const & alternator) {
            try {
                invoker._aggregator(invoker._dispatcher[get<0>(alternator)]());
            } catch (unregistered_handler &) {
                try {
                    invoker._aggregator(invoker._dispatcher[get<1>(alternator)]());
                } catch (unregistered_handler &) {
                    try {
                        invoker._aggregator(invoker._dispatcher[get<2>(alternator)]());
                    } catch (unregistered_handler &) {
                        try {
                            invoker._aggregator(invoker._dispatcher[get<3>(alternator)]());
                        } catch (unregistered_handler &) {
                            try {
                                invoker._aggregator(invoker._dispatcher[get<4>(alternator)]());
                            } catch (unregistered_handler &) {
                                try {
                                    invoker._aggregator(invoker._dispatcher[get<5>(alternator)]());
                                } catch (unregistered_handler &) {
                                    invoker._aggregator(invoker._dispatcher[get<6>(alternator)]());
                                };
                            };
                        };
                    };
                };
            };

            return invoker;
        };

    template <typename ReturnType, typename DispatcherType>
        invoke_impl_0_callable<ReturnType, DispatcherType> operator<< (
         invoke_impl_0_callable<ReturnType, DispatcherType> const & invoker,
         tuple<
            typename DispatcherType::index_type,
            typename DispatcherType::index_type,
            typename DispatcherType::index_type,
            typename DispatcherType::index_type,
            typename DispatcherType::index_type,
            typename DispatcherType::index_type,
            typename DispatcherType::index_type,
            typename DispatcherType::index_type
            > const & alternator) {
            try {
                invoker._aggregator(invoker._dispatcher[get<0>(alternator)]());
            } catch (unregistered_handler &) {
                try {
                    invoker._aggregator(invoker._dispatcher[get<1>(alternator)]());
                } catch (unregistered_handler &) {
                    try {
                        invoker._aggregator(invoker._dispatcher[get<2>(alternator)]());
                    } catch (unregistered_handler &) {
                        try {
                            invoker._aggregator(invoker._dispatcher[get<3>(alternator)]());
                        } catch (unregistered_handler &) {
                            try {
                                invoker._aggregator(invoker._dispatcher[get<4>(alternator)]());
                            } catch (unregistered_handler &) {
                                try {
                                    invoker._aggregator(invoker._dispatcher[get<5>(alternator)]());
                                } catch (unregistered_handler &) {
                                    try {
                                        invoker._aggregator(invoker._dispatcher[get<6>(alternator)]());
                                    } catch (unregistered_handler &) {
                                        invoker._aggregator(invoker._dispatcher[get<7>(alternator)]());
                                    };
                                };
                            };
                        };
                    };
                };
            };

            return invoker;
        };

    template <typename ReturnType, typename DispatcherType>
        invoke_impl_0_callable<ReturnType, DispatcherType> operator<< (
         invoke_impl_0_callable<ReturnType, DispatcherType> const & invoker,
         tuple<
            typename DispatcherType::index_type,
            typename DispatcherType::index_type,
            typename DispatcherType::index_type,
            typename DispatcherType::index_type,
            typename DispatcherType::index_type,
            typename DispatcherType::index_type,
            typename DispatcherType::index_type,
            typename DispatcherType::index_type,
            typename DispatcherType::index_type
            > const & alternator) {
            try {
                invoker._aggregator(invoker._dispatcher[get<0>(alternator)]());
            } catch (unregistered_handler &) {
                try {
                    invoker._aggregator(invoker._dispatcher[get<1>(alternator)]());
                } catch (unregistered_handler &) {
                    try {
                        invoker._aggregator(invoker._dispatcher[get<2>(alternator)]());
                    } catch (unregistered_handler &) {
                        try {
                            invoker._aggregator(invoker._dispatcher[get<3>(alternator)]());
                        } catch (unregistered_handler &) {
                            try {
                                invoker._aggregator(invoker._dispatcher[get<4>(alternator)]());
                            } catch (unregistered_handler &) {
                                try {
                                    invoker._aggregator(invoker._dispatcher[get<5>(alternator)]());
                                } catch (unregistered_handler &) {
                                    try {
                                        invoker._aggregator(invoker._dispatcher[get<6>(alternator)]());
                                    } catch (unregistered_handler &) {
                                        try {
                                            invoker._aggregator(invoker._dispatcher[get<7>(alternator)]());
                                        } catch (unregistered_handler &) {
                                            invoker._aggregator(invoker._dispatcher[get<8>(alternator)]());
                                        };
                                    };
                                };
                            };
                        };
                    };
                };
            };

            return invoker;
        };

    template <typename ReturnType, typename DispatcherType>
        invoke_impl_0_callable<ReturnType, DispatcherType> operator<< (
         invoke_impl_0_callable<ReturnType, DispatcherType> const & invoker,
         tuple<
            typename DispatcherType::index_type,
            typename DispatcherType::index_type,
            typename DispatcherType::index_type,
            typename DispatcherType::index_type,
            typename DispatcherType::index_type,
            typename DispatcherType::index_type,
            typename DispatcherType::index_type,
            typename DispatcherType::index_type,
            typename DispatcherType::index_type,
            typename DispatcherType::index_type
            > const & alternator) {
            try {
                invoker._aggregator(invoker._dispatcher[get<0>(alternator)]());
            } catch (unregistered_handler &) {
                try {
                    invoker._aggregator(invoker._dispatcher[get<1>(alternator)]());
                } catch (unregistered_handler &) {
                    try {
                        invoker._aggregator(invoker._dispatcher[get<2>(alternator)]());
                    } catch (unregistered_handler &) {
                        try {
                            invoker._aggregator(invoker._dispatcher[get<3>(alternator)]());
                        } catch (unregistered_handler &) {
                            try {
                                invoker._aggregator(invoker._dispatcher[get<4>(alternator)]());
                            } catch (unregistered_handler &) {
                                try {
                                    invoker._aggregator(invoker._dispatcher[get<5>(alternator)]());
                                } catch (unregistered_handler &) {
                                    try {
                                        invoker._aggregator(invoker._dispatcher[get<6>(alternator)]());
                                    } catch (unregistered_handler &) {
                                        try {
                                            invoker._aggregator(invoker._dispatcher[get<7>(alternator)]());
                                        } catch (unregistered_handler &) {
                                            try {
                                                invoker._aggregator(invoker._dispatcher[get<8>(alternator)]());
                                            } catch (unregistered_handler &) {
                                                invoker._aggregator(invoker._dispatcher[get<9>(alternator)]());
                                            };
                                        };
                                    };
                                };
                            };
                        };
                    };
                };
            };

            return invoker;
        };

}; // namespace detail

}; // namespace dispatch

}; // namespace boost

#endif
