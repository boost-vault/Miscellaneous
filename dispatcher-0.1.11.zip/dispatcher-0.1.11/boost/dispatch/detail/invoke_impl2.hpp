// Copyright 2006 (C) Dean Michael Berris <dean@orangeandbronze.com>
// Distributed under the Boost Software License, Version 1.0. (See accompanying
// file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)

#ifndef __INVOKE_IMPL2_HPP_
#define __INVOKE_IMPL2_HPP_

#include <boost/function.hpp>
#include <boost/dispatch/dispatch_exceptions.hpp>

#include <boost/fusion/tuple.hpp>

namespace boost {
	namespace dispatch {
		namespace detail {

			template <typename ReturnType, typename DispatcherType,
				typename arg1_type,
				typename arg2_type
			>
			struct invoke_impl_2_callable {
				typedef boost::function< void (typename DispatcherType::result_type) > aggregator_t;

				DispatcherType & _dispatcher;
				const aggregator_t _aggregator;
				const arg1_type & _arg1;
				const arg2_type & _arg2;

				invoke_impl_2_callable (
					DispatcherType & dispatcher,
					const aggregator_t & aggregator,
					const arg1_type & arg1,
					const arg2_type & arg2)
					: _dispatcher(dispatcher),
					_aggregator(aggregator),
					_arg1(arg1),
					_arg2(arg2)
				{ /*...*/ };

			};

			template <typename DispatcherType,
				typename arg1_type,
				typename arg2_type
			>
			struct invoke_impl_2_callable <
				void,
				DispatcherType,
				arg1_type,
				arg2_type
			>
			{
				typedef boost::function< void ( int ) > aggregator_t;

				DispatcherType & _dispatcher;
				const aggregator_t _aggregator;
				const arg1_type & _arg1;
				const arg2_type & _arg2;

				invoke_impl_2_callable (
					DispatcherType & dispatcher,
					const aggregator_t & aggregator,
					const arg1_type & arg1,
					const arg2_type & arg2)
					: _dispatcher(dispatcher),
					_aggregator(aggregator),
					_arg1(arg1),
					_arg2(arg2)
				{ /*...*/ };

			};

			template <typename ReturnType, typename DispatcherType,
				typename arg1_type,
				typename arg2_type
			>
			struct invoke_impl_2 {
				typedef boost::function< void (typename DispatcherType::result_type) > aggregator_t;

				DispatcherType & _dispatcher;
				aggregator_t _aggregator;

				invoke_impl_2 (
					DispatcherType & dispatcher,
					aggregator_t aggregator
					) : _dispatcher(dispatcher), _aggregator(aggregator)
				{ } ;

				invoke_impl_2_callable <ReturnType, DispatcherType, 
					arg1_type, 
					arg2_type
				> operator () (const arg1_type & arg1, 
				const arg2_type & arg2) {
					return 
						invoke_impl_2_callable <ReturnType, DispatcherType, 
						arg1_type, 
						arg2_type
						> (_dispatcher, _aggregator,
						arg1,
						arg2
						)
						;
				};
			};

			template <typename DispatcherType,
				typename arg1_type,
				typename arg2_type
			>
			struct invoke_impl_2<void, DispatcherType, 
				arg1_type, 
				arg2_type
			> {
				typedef boost::function<void (int)> aggregator_t;

				aggregator_t _aggregator;
				DispatcherType & _dispatcher;

				invoke_impl_2 (
					DispatcherType & dispatcher,
					aggregator_t aggregator
					) : _dispatcher(dispatcher), _aggregator(default_aggregator<void>())
				{ } ;

				invoke_impl_2_callable<void, DispatcherType, 
					arg1_type, 
					arg2_type
				> operator()
				(const arg1_type & arg1, const arg2_type & arg2) {
					return 
						invoke_impl_2_callable<void, DispatcherType, 
						arg1_type, 
						arg2_type
						> ( _dispatcher, _aggregator,
						arg1,
						arg2
						)
						;
				};
			};

			template <typename ReturnType, typename DispatcherType, 
				typename arg1_type,
				typename arg2_type
			>
			inline invoke_impl_2_callable <ReturnType, DispatcherType, 
			arg1_type, 
			arg2_type
			> const & operator<<
			( const invoke_impl_2_callable<ReturnType, DispatcherType, 
			arg1_type,
			arg2_type
			> & invoker,
			const typename DispatcherType::index_type & index 
			) {
				invoker._aggregator(
					invoker._dispatcher[index](
					invoker._arg1,
					invoker._arg2
					)
					);
				return invoker;
			};

			template <typename DispatcherType,
				typename arg1_type,
				typename arg2_type
			>
			inline invoke_impl_2_callable <void, DispatcherType, 
			arg1_type,
			arg2_type
			> const & operator<< 
			( const invoke_impl_2_callable <void, DispatcherType, 
			arg1_type,
			arg2_type
			> & invoker,
			const typename DispatcherType::index_type & index ) {
				invoker._dispatcher[index](
					invoker._arg1,
					invoker._arg2
					);
				return invoker;
			};

			template <typename DispatcherType, typename arg1_type, typename arg2_type>
			invoke_impl_2_callable<void, DispatcherType, arg1_type, arg2_type> operator<< (
				invoke_impl_2_callable<void, DispatcherType, arg1_type, arg2_type> const & invoker,
				tuple<
				typename DispatcherType::index_type,
				typename DispatcherType::index_type
				> const & alternator) {

					try {
						invoker._dispatcher[get<0>(alternator)](invoker._arg1, invoker._arg2);
					} catch (unregistered_handler &) {
						invoker._dispatcher[get<1>(alternator)](invoker._arg1, invoker._arg2);
					};

					return invoker;
			};

			template <typename DispatcherType, typename arg1_type, typename arg2_type>
			invoke_impl_2_callable<void, DispatcherType, arg1_type, arg2_type> operator<< (
				invoke_impl_2_callable<void, DispatcherType, arg1_type, arg2_type> const & invoker,
				tuple<
				typename DispatcherType::index_type,
				typename DispatcherType::index_type,
				typename DispatcherType::index_type
				> const & alternator) {
					try {
						invoker._dispatcher[get<0>(alternator)](invoker._arg1, invoker._arg2);
					} catch (unregistered_handler &) {
						try {
							invoker._dispatcher[get<1>(alternator)](invoker._arg1, invoker._arg2);
						} catch (unregistered_handler &) {
							invoker._dispatcher[get<2>(alternator)](invoker._arg1, invoker._arg2);
						};
					};

					return invoker;
			};

			template <typename DispatcherType, typename arg1_type, typename arg2_type>
			invoke_impl_2_callable<void, DispatcherType, arg1_type, arg2_type> operator<< (
				invoke_impl_2_callable<void, DispatcherType, arg1_type, arg2_type> const & invoker,
				tuple<
				typename DispatcherType::index_type,
				typename DispatcherType::index_type,
				typename DispatcherType::index_type,
				typename DispatcherType::index_type
				> const & alternator) {
					try {
						invoker._dispatcher[get<0>(alternator)](invoker._arg1, invoker._arg2);
					} catch (unregistered_handler &) {
						try {
							invoker._dispatcher[get<1>(alternator)](invoker._arg1, invoker._arg2);
						} catch (unregistered_handler &) {
							try {
								invoker._dispatcher[get<2>(alternator)](invoker._arg1, invoker._arg2);
							} catch (unregistered_handler &) {
								invoker._dispatcher[get<3>(alternator)](invoker._arg1, invoker._arg2);
							};
						};
					};

					return invoker;
			};

			template <typename DispatcherType, typename arg1_type, typename arg2_type>
			invoke_impl_2_callable<void, DispatcherType, arg1_type, arg2_type> operator<< (
				invoke_impl_2_callable<void, DispatcherType, arg1_type, arg2_type> const & invoker,
				tuple<
				typename DispatcherType::index_type,
				typename DispatcherType::index_type,
				typename DispatcherType::index_type,
				typename DispatcherType::index_type,
				typename DispatcherType::index_type
				> const & alternator) {
					try {
						invoker._dispatcher[get<0>(alternator)](invoker._arg1, invoker._arg2);
					} catch (unregistered_handler &) {
						try {
							invoker._dispatcher[get<1>(alternator)](invoker._arg1, invoker._arg2);
						} catch (unregistered_handler &) {
							try {
								invoker._dispatcher[get<2>(alternator)](invoker._arg1, invoker._arg2);
							} catch (unregistered_handler &) {
								try {
									invoker._dispatcher[get<3>(alternator)](invoker._arg1, invoker._arg2);
								} catch (unregistered_handler &) {
									invoker._dispatcher[get<4>(alternator)](invoker._arg1, invoker._arg2);
								};
							};
						};
					};

					return invoker;
			};

			template <typename DispatcherType, typename arg1_type, typename arg2_type>
			invoke_impl_2_callable<void, DispatcherType, arg1_type, arg2_type> operator<< (
				invoke_impl_2_callable<void, DispatcherType, arg1_type, arg2_type> const & invoker,
				tuple<
				typename DispatcherType::index_type,
				typename DispatcherType::index_type,
				typename DispatcherType::index_type,
				typename DispatcherType::index_type,
				typename DispatcherType::index_type,
				typename DispatcherType::index_type
				> const & alternator) {
					try {
						invoker._dispatcher[get<0>(alternator)](invoker._arg1, invoker._arg2);
					} catch (unregistered_handler &) {
						try {
							invoker._dispatcher[get<1>(alternator)](invoker._arg1, invoker._arg2);
						} catch (unregistered_handler &) {
							try {
								invoker._dispatcher[get<2>(alternator)](invoker._arg1, invoker._arg2);
							} catch (unregistered_handler &) {
								try {
									invoker._dispatcher[get<3>(alternator)](invoker._arg1, invoker._arg2);
								} catch (unregistered_handler &) {
									try {
										invoker._dispatcher[get<4>(alternator)](invoker._arg1, invoker._arg2);
									} catch (unregistered_handler &) {
										invoker._dispatcher[get<5>(alternator)](invoker._arg1, invoker._arg2);
									};
								};
							};
						};
					};

					return invoker;
			};

			template <typename DispatcherType, typename arg1_type, typename arg2_type>
			invoke_impl_2_callable<void, DispatcherType, arg1_type, arg2_type> operator<< (
				invoke_impl_2_callable<void, DispatcherType, arg1_type, arg2_type> const & invoker,
				tuple<
				typename DispatcherType::index_type,
				typename DispatcherType::index_type,
				typename DispatcherType::index_type,
				typename DispatcherType::index_type,
				typename DispatcherType::index_type,
				typename DispatcherType::index_type,
				typename DispatcherType::index_type
				> const & alternator) {
					try {
						invoker._dispatcher[get<0>(alternator)](invoker._arg1, invoker._arg2);
					} catch (unregistered_handler &) {
						try {
							invoker._dispatcher[get<1>(alternator)](invoker._arg1, invoker._arg2);
						} catch (unregistered_handler &) {
							try {
								invoker._dispatcher[get<2>(alternator)](invoker._arg1, invoker._arg2);
							} catch (unregistered_handler &) {
								try {
									invoker._dispatcher[get<3>(alternator)](invoker._arg1, invoker._arg2);
								} catch (unregistered_handler &) {
									try {
										invoker._dispatcher[get<4>(alternator)](invoker._arg1, invoker._arg2);
									} catch (unregistered_handler &) {
										try {
											invoker._dispatcher[get<5>(alternator)](invoker._arg1, invoker._arg2);
										} catch (unregistered_handler &) {
											invoker._dispatcher[get<6>(alternator)](invoker._arg1, invoker._arg2);
										};
									};
								};
							};
						};
					};

					return invoker;
			};

			template <typename DispatcherType, typename arg1_type, typename arg2_type>
			invoke_impl_2_callable<void, DispatcherType, arg1_type, arg2_type> operator<< (
				invoke_impl_2_callable<void, DispatcherType, arg1_type, arg2_type> const & invoker,
				tuple<
				typename DispatcherType::index_type,
				typename DispatcherType::index_type,
				typename DispatcherType::index_type,
				typename DispatcherType::index_type,
				typename DispatcherType::index_type,
				typename DispatcherType::index_type,
				typename DispatcherType::index_type,
				typename DispatcherType::index_type
				> const & alternator) {
					try {
						invoker._dispatcher[get<0>(alternator)](invoker._arg1, invoker._arg2);
					} catch (unregistered_handler &) {
						try {
							invoker._dispatcher[get<1>(alternator)](invoker._arg1, invoker._arg2);
						} catch (unregistered_handler &) {
							try {
								invoker._dispatcher[get<2>(alternator)](invoker._arg1, invoker._arg2);
							} catch (unregistered_handler &) {
								try {
									invoker._dispatcher[get<3>(alternator)](invoker._arg1, invoker._arg2);
								} catch (unregistered_handler &) {
									try {
										invoker._dispatcher[get<4>(alternator)](invoker._arg1, invoker._arg2);
									} catch (unregistered_handler &) {
										try {
											invoker._dispatcher[get<5>(alternator)](invoker._arg1, invoker._arg2);
										} catch (unregistered_handler &) {
											try {
												invoker._dispatcher[get<6>(alternator)](invoker._arg1, invoker._arg2);
											} catch (unregistered_handler &) {
												invoker._dispatcher[get<7>(alternator)](invoker._arg1, invoker._arg2);
											};
										};
									};
								};
							};
						};
					};

					return invoker;
			};

			template <typename DispatcherType, typename arg1_type, typename arg2_type>
			invoke_impl_2_callable<void, DispatcherType, arg1_type, arg2_type> operator<< (
				invoke_impl_2_callable<void, DispatcherType, arg1_type, arg2_type> const & invoker,
				tuple<
				typename DispatcherType::index_type,
				typename DispatcherType::index_type,
				typename DispatcherType::index_type,
				typename DispatcherType::index_type,
				typename DispatcherType::index_type,
				typename DispatcherType::index_type,
				typename DispatcherType::index_type,
				typename DispatcherType::index_type,
				typename DispatcherType::index_type
				> const & alternator) {
					try {
						invoker._dispatcher[get<0>(alternator)](invoker._arg1, invoker._arg2);
					} catch (unregistered_handler &) {
						try {
							invoker._dispatcher[get<1>(alternator)](invoker._arg1, invoker._arg2);
						} catch (unregistered_handler &) {
							try {
								invoker._dispatcher[get<2>(alternator)](invoker._arg1, invoker._arg2);
							} catch (unregistered_handler &) {
								try {
									invoker._dispatcher[get<3>(alternator)](invoker._arg1, invoker._arg2);
								} catch (unregistered_handler &) {
									try {
										invoker._dispatcher[get<4>(alternator)](invoker._arg1, invoker._arg2);
									} catch (unregistered_handler &) {
										try {
											invoker._dispatcher[get<5>(alternator)](invoker._arg1, invoker._arg2);
										} catch (unregistered_handler &) {
											try {
												invoker._dispatcher[get<6>(alternator)](invoker._arg1, invoker._arg2);
											} catch (unregistered_handler &) {
												try {
													invoker._dispatcher[get<7>(alternator)](invoker._arg1, invoker._arg2);
												} catch (unregistered_handler &) {
													invoker._dispatcher[get<8>(alternator)](invoker._arg1, invoker._arg2);
												};
											};
										};
									};
								};
							};
						};
					};

					return invoker;
			};

			template <typename DispatcherType, typename arg1_type, typename arg2_type>
			invoke_impl_2_callable<void, DispatcherType, arg1_type, arg2_type> operator<< (
				invoke_impl_2_callable<void, DispatcherType, arg1_type, arg2_type> const & invoker,
				tuple<
				typename DispatcherType::index_type,
				typename DispatcherType::index_type,
				typename DispatcherType::index_type,
				typename DispatcherType::index_type,
				typename DispatcherType::index_type,
				typename DispatcherType::index_type,
				typename DispatcherType::index_type,
				typename DispatcherType::index_type,
				typename DispatcherType::index_type,
				typename DispatcherType::index_type
				> const & alternator) {
					try {
						invoker._dispatcher[get<0>(alternator)](invoker._arg1, invoker._arg2);
					} catch (unregistered_handler &) {
						try {
							invoker._dispatcher[get<1>(alternator)](invoker._arg1, invoker._arg2);
						} catch (unregistered_handler &) {
							try {
								invoker._dispatcher[get<2>(alternator)](invoker._arg1, invoker._arg2);
							} catch (unregistered_handler &) {
								try {
									invoker._dispatcher[get<3>(alternator)](invoker._arg1, invoker._arg2);
								} catch (unregistered_handler &) {
									try {
										invoker._dispatcher[get<4>(alternator)](invoker._arg1, invoker._arg2);
									} catch (unregistered_handler &) {
										try {
											invoker._dispatcher[get<5>(alternator)](invoker._arg1, invoker._arg2);
										} catch (unregistered_handler &) {
											try {
												invoker._dispatcher[get<6>(alternator)](invoker._arg1, invoker._arg2);
											} catch (unregistered_handler &) {
												try {
													invoker._dispatcher[get<7>(alternator)](invoker._arg1, invoker._arg2);
												} catch (unregistered_handler &) {
													try {
														invoker._dispatcher[get<8>(alternator)](invoker._arg1, invoker._arg2);
													} catch (unregistered_handler &) {
														invoker._dispatcher[get<9>(alternator)](invoker._arg1, invoker._arg2);
													};
												};
											};
										};
									};
								};
							};
						};
					};

					return invoker;
			};

		template <typename ReturnType, typename DispatcherType, typename arg1_type, typename arg2_type>
        invoke_impl_2_callable<ReturnType, DispatcherType, arg1_type, arg2_type> operator<< (
         invoke_impl_2_callable<ReturnType, DispatcherType, arg1_type, arg2_type> const & invoker,
         tuple<
            typename DispatcherType::index_type,
            typename DispatcherType::index_type
            > const & alternator) {

            try {
                invoker._aggregator(invoker._dispatcher[get<0>(alternator)](invoker._arg1, invoker._arg2));
            } catch (unregistered_handler &) {
                invoker._aggregator(invoker._dispatcher[get<1>(alternator)](invoker._arg1, invoker._arg2));
            };

            return invoker;
        };

    template <typename ReturnType, typename DispatcherType, typename arg1_type, typename arg2_type>
        invoke_impl_2_callable<ReturnType, DispatcherType, arg1_type, arg2_type> operator<< (
         invoke_impl_2_callable<ReturnType, DispatcherType, arg1_type, arg2_type> const & invoker,
         tuple<
            typename DispatcherType::index_type,
            typename DispatcherType::index_type,
            typename DispatcherType::index_type
            > const & alternator) {
            try {
                invoker._aggregator(invoker._dispatcher[get<0>(alternator)](invoker._arg1, invoker._arg2));
            } catch (unregistered_handler &) {
                try {
                    invoker._aggregator(invoker._dispatcher[get<1>(alternator)](invoker._arg1, invoker._arg2));
                } catch (unregistered_handler &) {
                    invoker._aggregator(invoker._dispatcher[get<2>(alternator)](invoker._arg1, invoker._arg2));
                };
            };

            return invoker;
        };

    template <typename ReturnType, typename DispatcherType, typename arg1_type, typename arg2_type>
        invoke_impl_2_callable<ReturnType, DispatcherType, arg1_type, arg2_type> operator<< (
         invoke_impl_2_callable<ReturnType, DispatcherType, arg1_type, arg2_type> const & invoker,
         tuple<
            typename DispatcherType::index_type,
            typename DispatcherType::index_type,
            typename DispatcherType::index_type,
            typename DispatcherType::index_type
            > const & alternator) {
            try {
                invoker._aggregator(invoker._dispatcher[get<0>(alternator)](invoker._arg1, invoker._arg2));
            } catch (unregistered_handler &) {
                try {
                    invoker._aggregator(invoker._dispatcher[get<1>(alternator)](invoker._arg1, invoker._arg2));
                } catch (unregistered_handler &) {
                    try {
                        invoker._aggregator(invoker._dispatcher[get<2>(alternator)](invoker._arg1, invoker._arg2));
                    } catch (unregistered_handler &) {
                        invoker._aggregator(invoker._dispatcher[get<3>(alternator)](invoker._arg1, invoker._arg2));
                    };
                };
            };

            return invoker;
        };

    template <typename ReturnType, typename DispatcherType, typename arg1_type, typename arg2_type>
        invoke_impl_2_callable<ReturnType, DispatcherType, arg1_type, arg2_type> operator<< (
         invoke_impl_2_callable<ReturnType, DispatcherType, arg1_type, arg2_type> const & invoker,
         tuple<
            typename DispatcherType::index_type,
            typename DispatcherType::index_type,
            typename DispatcherType::index_type,
            typename DispatcherType::index_type,
            typename DispatcherType::index_type
            > const & alternator) {
            try {
                invoker._aggregator(invoker._dispatcher[get<0>(alternator)](invoker._arg1, invoker._arg2));
            } catch (unregistered_handler &) {
                try {
                    invoker._aggregator(invoker._dispatcher[get<1>(alternator)](invoker._arg1, invoker._arg2));
                } catch (unregistered_handler &) {
                    try {
                        invoker._aggregator(invoker._dispatcher[get<2>(alternator)](invoker._arg1, invoker._arg2));
                    } catch (unregistered_handler &) {
                        try {
                            invoker._aggregator(invoker._dispatcher[get<3>(alternator)](invoker._arg1, invoker._arg2));
                        } catch (unregistered_handler &) {
                            invoker._aggregator(invoker._dispatcher[get<4>(alternator)](invoker._arg1, invoker._arg2));
                        };
                    };
                };
            };

            return invoker;
        };

    template <typename ReturnType, typename DispatcherType, typename arg1_type, typename arg2_type>
        invoke_impl_2_callable<ReturnType, DispatcherType, arg1_type, arg2_type> operator<< (
         invoke_impl_2_callable<ReturnType, DispatcherType, arg1_type, arg2_type> const & invoker,
         tuple<
            typename DispatcherType::index_type,
            typename DispatcherType::index_type,
            typename DispatcherType::index_type,
            typename DispatcherType::index_type,
            typename DispatcherType::index_type,
            typename DispatcherType::index_type
            > const & alternator) {
            try {
                invoker._aggregator(invoker._dispatcher[get<0>(alternator)](invoker._arg1, invoker._arg2));
            } catch (unregistered_handler &) {
                try {
                    invoker._aggregator(invoker._dispatcher[get<1>(alternator)](invoker._arg1, invoker._arg2));
                } catch (unregistered_handler &) {
                    try {
                        invoker._aggregator(invoker._dispatcher[get<2>(alternator)](invoker._arg1, invoker._arg2));
                    } catch (unregistered_handler &) {
                        try {
                            invoker._aggregator(invoker._dispatcher[get<3>(alternator)](invoker._arg1, invoker._arg2));
                        } catch (unregistered_handler &) {
                            try {
                                invoker._aggregator(invoker._dispatcher[get<4>(alternator)](invoker._arg1, invoker._arg2));
                            } catch (unregistered_handler &) {
                                invoker._aggregator(invoker._dispatcher[get<5>(alternator)](invoker._arg1, invoker._arg2));
                            };
                        };
                    };
                };
            };

            return invoker;
        };

    template <typename ReturnType, typename DispatcherType, typename arg1_type, typename arg2_type>
        invoke_impl_2_callable<ReturnType, DispatcherType, arg1_type, arg2_type> operator<< (
         invoke_impl_2_callable<ReturnType, DispatcherType, arg1_type, arg2_type> const & invoker,
         tuple<
            typename DispatcherType::index_type,
            typename DispatcherType::index_type,
            typename DispatcherType::index_type,
            typename DispatcherType::index_type,
            typename DispatcherType::index_type,
            typename DispatcherType::index_type,
            typename DispatcherType::index_type
            > const & alternator) {
            try {
                invoker._aggregator(invoker._dispatcher[get<0>(alternator)](invoker._arg1, invoker._arg2));
            } catch (unregistered_handler &) {
                try {
                    invoker._aggregator(invoker._dispatcher[get<1>(alternator)](invoker._arg1, invoker._arg2));
                } catch (unregistered_handler &) {
                    try {
                        invoker._aggregator(invoker._dispatcher[get<2>(alternator)](invoker._arg1, invoker._arg2));
                    } catch (unregistered_handler &) {
                        try {
                            invoker._aggregator(invoker._dispatcher[get<3>(alternator)](invoker._arg1, invoker._arg2));
                        } catch (unregistered_handler &) {
                            try {
                                invoker._aggregator(invoker._dispatcher[get<4>(alternator)](invoker._arg1, invoker._arg2));
                            } catch (unregistered_handler &) {
                                try {
                                    invoker._aggregator(invoker._dispatcher[get<5>(alternator)](invoker._arg1, invoker._arg2));
                                } catch (unregistered_handler &) {
                                    invoker._aggregator(invoker._dispatcher[get<6>(alternator)](invoker._arg1, invoker._arg2));
                                };
                            };
                        };
                    };
                };
            };

            return invoker;
        };

    template <typename ReturnType, typename DispatcherType, typename arg1_type, typename arg2_type>
        invoke_impl_2_callable<ReturnType, DispatcherType, arg1_type, arg2_type> operator<< (
         invoke_impl_2_callable<ReturnType, DispatcherType, arg1_type, arg2_type> const & invoker,
         tuple<
            typename DispatcherType::index_type,
            typename DispatcherType::index_type,
            typename DispatcherType::index_type,
            typename DispatcherType::index_type,
            typename DispatcherType::index_type,
            typename DispatcherType::index_type,
            typename DispatcherType::index_type,
            typename DispatcherType::index_type
            > const & alternator) {
            try {
                invoker._aggregator(invoker._dispatcher[get<0>(alternator)](invoker._arg1, invoker._arg2));
            } catch (unregistered_handler &) {
                try {
                    invoker._aggregator(invoker._dispatcher[get<1>(alternator)](invoker._arg1, invoker._arg2));
                } catch (unregistered_handler &) {
                    try {
                        invoker._aggregator(invoker._dispatcher[get<2>(alternator)](invoker._arg1, invoker._arg2));
                    } catch (unregistered_handler &) {
                        try {
                            invoker._aggregator(invoker._dispatcher[get<3>(alternator)](invoker._arg1, invoker._arg2));
                        } catch (unregistered_handler &) {
                            try {
                                invoker._aggregator(invoker._dispatcher[get<4>(alternator)](invoker._arg1, invoker._arg2));
                            } catch (unregistered_handler &) {
                                try {
                                    invoker._aggregator(invoker._dispatcher[get<5>(alternator)](invoker._arg1, invoker._arg2));
                                } catch (unregistered_handler &) {
                                    try {
                                        invoker._aggregator(invoker._dispatcher[get<6>(alternator)](invoker._arg1, invoker._arg2));
                                    } catch (unregistered_handler &) {
                                        invoker._aggregator(invoker._dispatcher[get<7>(alternator)](invoker._arg1, invoker._arg2));
                                    };
                                };
                            };
                        };
                    };
                };
            };

            return invoker;
        };

    template <typename ReturnType, typename DispatcherType, typename arg1_type, typename arg2_type>
        invoke_impl_2_callable<ReturnType, DispatcherType, arg1_type, arg2_type> operator<< (
         invoke_impl_2_callable<ReturnType, DispatcherType, arg1_type, arg2_type> const & invoker,
         tuple<
            typename DispatcherType::index_type,
            typename DispatcherType::index_type,
            typename DispatcherType::index_type,
            typename DispatcherType::index_type,
            typename DispatcherType::index_type,
            typename DispatcherType::index_type,
            typename DispatcherType::index_type,
            typename DispatcherType::index_type,
            typename DispatcherType::index_type
            > const & alternator) {
            try {
                invoker._aggregator(invoker._dispatcher[get<0>(alternator)](invoker._arg1, invoker._arg2));
            } catch (unregistered_handler &) {
                try {
                    invoker._aggregator(invoker._dispatcher[get<1>(alternator)](invoker._arg1, invoker._arg2));
                } catch (unregistered_handler &) {
                    try {
                        invoker._aggregator(invoker._dispatcher[get<2>(alternator)](invoker._arg1, invoker._arg2));
                    } catch (unregistered_handler &) {
                        try {
                            invoker._aggregator(invoker._dispatcher[get<3>(alternator)](invoker._arg1, invoker._arg2));
                        } catch (unregistered_handler &) {
                            try {
                                invoker._aggregator(invoker._dispatcher[get<4>(alternator)](invoker._arg1, invoker._arg2));
                            } catch (unregistered_handler &) {
                                try {
                                    invoker._aggregator(invoker._dispatcher[get<5>(alternator)](invoker._arg1, invoker._arg2));
                                } catch (unregistered_handler &) {
                                    try {
                                        invoker._aggregator(invoker._dispatcher[get<6>(alternator)](invoker._arg1, invoker._arg2));
                                    } catch (unregistered_handler &) {
                                        try {
                                            invoker._aggregator(invoker._dispatcher[get<7>(alternator)](invoker._arg1, invoker._arg2));
                                        } catch (unregistered_handler &) {
                                            invoker._aggregator(invoker._dispatcher[get<8>(alternator)](invoker._arg1, invoker._arg2));
                                        };
                                    };
                                };
                            };
                        };
                    };
                };
            };

            return invoker;
        };

    template <typename ReturnType, typename DispatcherType, typename arg1_type, typename arg2_type>
        invoke_impl_2_callable<ReturnType, DispatcherType, arg1_type, arg2_type> operator<< (
         invoke_impl_2_callable<ReturnType, DispatcherType, arg1_type, arg2_type> const & invoker,
         tuple<
            typename DispatcherType::index_type,
            typename DispatcherType::index_type,
            typename DispatcherType::index_type,
            typename DispatcherType::index_type,
            typename DispatcherType::index_type,
            typename DispatcherType::index_type,
            typename DispatcherType::index_type,
            typename DispatcherType::index_type,
            typename DispatcherType::index_type,
            typename DispatcherType::index_type
            > const & alternator) {
            try {
                invoker._aggregator(invoker._dispatcher[get<0>(alternator)](invoker._arg1, invoker._arg2));
            } catch (unregistered_handler &) {
                try {
                    invoker._aggregator(invoker._dispatcher[get<1>(alternator)](invoker._arg1, invoker._arg2));
                } catch (unregistered_handler &) {
                    try {
                        invoker._aggregator(invoker._dispatcher[get<2>(alternator)](invoker._arg1, invoker._arg2));
                    } catch (unregistered_handler &) {
                        try {
                            invoker._aggregator(invoker._dispatcher[get<3>(alternator)](invoker._arg1, invoker._arg2));
                        } catch (unregistered_handler &) {
                            try {
                                invoker._aggregator(invoker._dispatcher[get<4>(alternator)](invoker._arg1, invoker._arg2));
                            } catch (unregistered_handler &) {
                                try {
                                    invoker._aggregator(invoker._dispatcher[get<5>(alternator)](invoker._arg1, invoker._arg2));
                                } catch (unregistered_handler &) {
                                    try {
                                        invoker._aggregator(invoker._dispatcher[get<6>(alternator)](invoker._arg1, invoker._arg2));
                                    } catch (unregistered_handler &) {
                                        try {
                                            invoker._aggregator(invoker._dispatcher[get<7>(alternator)](invoker._arg1, invoker._arg2));
                                        } catch (unregistered_handler &) {
                                            try {
                                                invoker._aggregator(invoker._dispatcher[get<8>(alternator)](invoker._arg1, invoker._arg2));
                                            } catch (unregistered_handler &) {
                                                invoker._aggregator(invoker._dispatcher[get<9>(alternator)](invoker._arg1, invoker._arg2));
                                            };
                                        };
                                    };
                                };
                            };
                        };
                    };
                };
            };

            return invoker;
        };


		}; // namespace detail
	}; // namespace dispatch
}; // namespace boost

#endif
