// Copyright 2006 (C) Dean Michael Berris <dean@orangeandbronze.com>
// Distributed under the Boost Software License, Version 1.0. (See accompanying
// file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)

#ifndef __INVOKE_IMPL4_HPP_
#define __INVOKE_IMPL4_HPP_

#include <boost/function.hpp>
#include <boost/dispatch/dispatch_exceptions.hpp>

#include <boost/fusion/tuple.hpp>

namespace boost {
    namespace dispatch {
        namespace detail {

            template <typename ReturnType, typename DispatcherType,
                typename arg1_type,
                typename arg2_type,
                typename arg3_type,
                typename arg4_type
            >
            struct invoke_impl_4_callable {
                typedef boost::function< void (typename DispatcherType::result_type) > aggregator_t;

                DispatcherType & _dispatcher;
                const aggregator_t _aggregator;
                const arg1_type & _arg1;
                const arg2_type & _arg2;
                const arg3_type & _arg3;
                const arg4_type & _arg4;

                invoke_impl_4_callable (
                    DispatcherType & dispatcher,
                    const aggregator_t & aggregator,
                    const arg1_type & arg1,
                    const arg2_type & arg2,
                    const arg3_type & arg3,
                    const arg4_type & arg4)
                    : _dispatcher(dispatcher),
                    _aggregator(aggregator),
                    _arg1(arg1),
                    _arg2(arg2),
                    _arg3(arg3),
                    _arg4(arg4)
                { /*...*/ };

            };

            template <typename DispatcherType,
                typename arg1_type,
                typename arg2_type,
                typename arg3_type,
                typename arg4_type
            >
            struct invoke_impl_4_callable <
                void,
                DispatcherType,
                arg1_type,
                arg2_type,
                arg3_type,
                arg4_type
            >
            {
                typedef boost::function< void ( int ) > aggregator_t;

                DispatcherType & _dispatcher;
                const aggregator_t _aggregator;
                const arg1_type & _arg1;
                const arg2_type & _arg2;
                const arg3_type & _arg3;
                const arg4_type & _arg4;

                invoke_impl_4_callable (
                    DispatcherType & dispatcher,
                    const aggregator_t & aggregator,
                    const arg1_type & arg1,
                    const arg2_type & arg2,
                    const arg3_type & arg3,
                    const arg4_type & arg4)
                    : _dispatcher(dispatcher),
                    _aggregator(aggregator),
                    _arg1(arg1),
                    _arg2(arg2),
                    _arg3(arg3),
                    _arg4(arg4)
                { /*...*/ };

            };

            template <typename ReturnType, typename DispatcherType,
                typename arg1_type,
                typename arg2_type,
                typename arg3_type,
                typename arg4_type
            >
            struct invoke_impl_4 {
                typedef boost::function< void (typename DispatcherType::result_type) > aggregator_t;

                DispatcherType & _dispatcher;
                aggregator_t _aggregator;

                invoke_impl_4 (
                    DispatcherType & dispatcher,
                    aggregator_t aggregator
                    ) : _dispatcher(dispatcher), _aggregator(aggregator)
                { } ;

                invoke_impl_4_callable <ReturnType, DispatcherType, 
                    arg1_type, 
                    arg2_type,
                    arg3_type,
                    arg4_type
                > operator()
                    (const arg1_type & arg1, 
                    const arg2_type & arg2,
                    const arg3_type & arg3,
                    const arg4_type & arg4) {
                        return 
                            invoke_impl_4_callable <ReturnType, DispatcherType, 
                                arg1_type, 
                                arg2_type, 
                                arg3_type, 
                                arg4_type
                            > (_dispatcher, _aggregator,
                            arg1,
                            arg2,
                            arg3,
                            arg4
                            )
                            ;
                };
            };

            template <typename DispatcherType,
                typename arg1_type,
                typename arg2_type,
                typename arg3_type,
                typename arg4_type
            >
            struct invoke_impl_4<void, DispatcherType, 
                arg1_type, 
                arg2_type,
                arg3_type,
                arg4_type
            > {
                typedef typename DispatcherType::index_type index_type;
                typedef boost::function<void (int)> aggregator_t;

                DispatcherType & _dispatcher;
                aggregator_t _aggregator;

                invoke_impl_4 (
                    DispatcherType & dispatcher,
                    aggregator_t aggregator
                    ) : _dispatcher(dispatcher), _aggregator(default_aggregator<void>())
                { } ;

                invoke_impl_4_callable<void, DispatcherType, 
                    arg1_type, 
                    arg2_type,
                    arg3_type,
                    arg4_type
                > operator()
                    (const arg1_type & arg1, 
                    const arg2_type & arg2,
                    const arg3_type & arg3,
                    const arg4_type & arg4) {
                        return 
                            invoke_impl_4_callable<void, DispatcherType, 
                            arg1_type, 
                            arg2_type,
                            arg3_type,
                            arg4_type
                            > ( _dispatcher, _aggregator,
                            arg1,
                            arg2,
                            arg3,
                            arg4
                            )
                            ;
                };
            };

            template <typename ReturnType, typename DispatcherType, 
                typename arg1_type,
                typename arg2_type,
                typename arg3_type,
                typename arg4_type
            >
            inline invoke_impl_4_callable <ReturnType, DispatcherType, 
                arg1_type, 
                arg2_type,
                arg3_type,
                arg4_type
            > const & operator<<
                ( const invoke_impl_4_callable<ReturnType, DispatcherType, 
                    arg1_type,
                    arg2_type,
                    arg3_type,
                    arg4_type
                  > & invoker,
                  const typename DispatcherType::index_type & index 
                ) {
                    invoker._aggregator(
                        invoker._dispatcher[index](
                            invoker._arg1,
                            invoker._arg2,
                            invoker._arg3,
                            invoker._arg4
                         )
                    );
                    return invoker;
            };

            template <typename DispatcherType,
                typename arg1_type,
                typename arg2_type,
                typename arg3_type,
                typename arg4_type
            >
            inline invoke_impl_4_callable <void, DispatcherType, 
                arg1_type,
                arg2_type,
                arg3_type,
                arg4_type
            > const & operator<< 
                ( const invoke_impl_4_callable <void, DispatcherType, 
                    arg1_type,
                    arg2_type,
                    arg3_type,
                    arg4_type
                  > & invoker,
                  const typename DispatcherType::index_type & index ) {
                    invoker._dispatcher[index](
                        invoker._arg1,
                        invoker._arg2,
                        invoker._arg3,
                        invoker._arg4
                    );
                    return invoker;
            };

			template <typename DispatcherType, typename arg1_type, typename arg2_type, typename arg3_type, typename arg4_type>
			invoke_impl_4_callable<void, DispatcherType, arg1_type, arg2_type, arg3_type, arg4_type> operator<< (
				invoke_impl_4_callable<void, DispatcherType, arg1_type, arg2_type, arg3_type, arg4_type> const & invoker,
				tuple<
				typename DispatcherType::index_type,
				typename DispatcherType::index_type
				> const & alternator) {

					try {
						invoker._dispatcher[get<0>(alternator)](invoker._arg1, invoker._arg2, invoker._arg3, invoker._arg4);
					} catch (unregistered_handler &) {
						invoker._dispatcher[get<1>(alternator)](invoker._arg1, invoker._arg2, invoker._arg3, invoker._arg4);
					};

					return invoker;
			};

			template <typename DispatcherType, typename arg1_type, typename arg2_type, typename arg3_type, typename arg4_type>
			invoke_impl_4_callable<void, DispatcherType, arg1_type, arg2_type, arg3_type, arg4_type> operator<< (
				invoke_impl_4_callable<void, DispatcherType, arg1_type, arg2_type, arg3_type, arg4_type> const & invoker,
				tuple<
				typename DispatcherType::index_type,
				typename DispatcherType::index_type,
				typename DispatcherType::index_type
				> const & alternator) {
					try {
						invoker._dispatcher[get<0>(alternator)](invoker._arg1, invoker._arg2, invoker._arg3, invoker._arg4);
					} catch (unregistered_handler &) {
						try {
							invoker._dispatcher[get<1>(alternator)](invoker._arg1, invoker._arg2, invoker._arg3, invoker._arg4);
						} catch (unregistered_handler &) {
							invoker._dispatcher[get<2>(alternator)](invoker._arg1, invoker._arg2, invoker._arg3, invoker._arg4);
						};
					};

					return invoker;
			};

			template <typename DispatcherType, typename arg1_type, typename arg2_type, typename arg3_type, typename arg4_type>
			invoke_impl_4_callable<void, DispatcherType, arg1_type, arg2_type, arg3_type, arg4_type> operator<< (
				invoke_impl_4_callable<void, DispatcherType, arg1_type, arg2_type, arg3_type, arg4_type> const & invoker,
				tuple<
				typename DispatcherType::index_type,
				typename DispatcherType::index_type,
				typename DispatcherType::index_type,
				typename DispatcherType::index_type
				> const & alternator) {
					try {
						invoker._dispatcher[get<0>(alternator)](invoker._arg1, invoker._arg2, invoker._arg3, invoker._arg4);
					} catch (unregistered_handler &) {
						try {
							invoker._dispatcher[get<1>(alternator)](invoker._arg1, invoker._arg2, invoker._arg3, invoker._arg4);
						} catch (unregistered_handler &) {
							try {
								invoker._dispatcher[get<2>(alternator)](invoker._arg1, invoker._arg2, invoker._arg3, invoker._arg4);
							} catch (unregistered_handler &) {
								invoker._dispatcher[get<3>(alternator)](invoker._arg1, invoker._arg2, invoker._arg3, invoker._arg4);
							};
						};
					};

					return invoker;
			};

			template <typename DispatcherType, typename arg1_type, typename arg2_type, typename arg3_type, typename arg4_type>
			invoke_impl_4_callable<void, DispatcherType, arg1_type, arg2_type, arg3_type, arg4_type> operator<< (
				invoke_impl_4_callable<void, DispatcherType, arg1_type, arg2_type, arg3_type, arg4_type> const & invoker,
				tuple<
				typename DispatcherType::index_type,
				typename DispatcherType::index_type,
				typename DispatcherType::index_type,
				typename DispatcherType::index_type,
				typename DispatcherType::index_type
				> const & alternator) {
					try {
						invoker._dispatcher[get<0>(alternator)](invoker._arg1, invoker._arg2, invoker._arg3, invoker._arg4);
					} catch (unregistered_handler &) {
						try {
							invoker._dispatcher[get<1>(alternator)](invoker._arg1, invoker._arg2, invoker._arg3, invoker._arg4);
						} catch (unregistered_handler &) {
							try {
								invoker._dispatcher[get<2>(alternator)](invoker._arg1, invoker._arg2, invoker._arg3, invoker._arg4);
							} catch (unregistered_handler &) {
								try {
									invoker._dispatcher[get<3>(alternator)](invoker._arg1, invoker._arg2, invoker._arg3, invoker._arg4);
								} catch (unregistered_handler &) {
									invoker._dispatcher[get<4>(alternator)](invoker._arg1, invoker._arg2, invoker._arg3, invoker._arg4);
								};
							};
						};
					};

					return invoker;
			};

			template <typename DispatcherType, typename arg1_type, typename arg2_type, typename arg3_type, typename arg4_type>
			invoke_impl_4_callable<void, DispatcherType, arg1_type, arg2_type, arg3_type, arg4_type> operator<< (
				invoke_impl_4_callable<void, DispatcherType, arg1_type, arg2_type, arg3_type, arg4_type> const & invoker,
				tuple<
				typename DispatcherType::index_type,
				typename DispatcherType::index_type,
				typename DispatcherType::index_type,
				typename DispatcherType::index_type,
				typename DispatcherType::index_type,
				typename DispatcherType::index_type
				> const & alternator) {
					try {
						invoker._dispatcher[get<0>(alternator)](invoker._arg1, invoker._arg2, invoker._arg3, invoker._arg4);
					} catch (unregistered_handler &) {
						try {
							invoker._dispatcher[get<1>(alternator)](invoker._arg1, invoker._arg2, invoker._arg3, invoker._arg4);
						} catch (unregistered_handler &) {
							try {
								invoker._dispatcher[get<2>(alternator)](invoker._arg1, invoker._arg2, invoker._arg3, invoker._arg4);
							} catch (unregistered_handler &) {
								try {
									invoker._dispatcher[get<3>(alternator)](invoker._arg1, invoker._arg2, invoker._arg3, invoker._arg4);
								} catch (unregistered_handler &) {
									try {
										invoker._dispatcher[get<4>(alternator)](invoker._arg1, invoker._arg2, invoker._arg3, invoker._arg4);
									} catch (unregistered_handler &) {
										invoker._dispatcher[get<5>(alternator)](invoker._arg1, invoker._arg2, invoker._arg3, invoker._arg4);
									};
								};
							};
						};
					};

					return invoker;
			};

			template <typename DispatcherType, typename arg1_type, typename arg2_type, typename arg3_type, typename arg4_type>
			invoke_impl_4_callable<void, DispatcherType, arg1_type, arg2_type, arg3_type, arg4_type> operator<< (
				invoke_impl_4_callable<void, DispatcherType, arg1_type, arg2_type, arg3_type, arg4_type> const & invoker,
				tuple<
				typename DispatcherType::index_type,
				typename DispatcherType::index_type,
				typename DispatcherType::index_type,
				typename DispatcherType::index_type,
				typename DispatcherType::index_type,
				typename DispatcherType::index_type,
				typename DispatcherType::index_type
				> const & alternator) {
					try {
						invoker._dispatcher[get<0>(alternator)](invoker._arg1, invoker._arg2, invoker._arg3, invoker._arg4);
					} catch (unregistered_handler &) {
						try {
							invoker._dispatcher[get<1>(alternator)](invoker._arg1, invoker._arg2, invoker._arg3, invoker._arg4);
						} catch (unregistered_handler &) {
							try {
								invoker._dispatcher[get<2>(alternator)](invoker._arg1, invoker._arg2, invoker._arg3, invoker._arg4);
							} catch (unregistered_handler &) {
								try {
									invoker._dispatcher[get<3>(alternator)](invoker._arg1, invoker._arg2, invoker._arg3, invoker._arg4);
								} catch (unregistered_handler &) {
									try {
										invoker._dispatcher[get<4>(alternator)](invoker._arg1, invoker._arg2, invoker._arg3, invoker._arg4);
									} catch (unregistered_handler &) {
										try {
											invoker._dispatcher[get<5>(alternator)](invoker._arg1, invoker._arg2, invoker._arg3, invoker._arg4);
										} catch (unregistered_handler &) {
											invoker._dispatcher[get<6>(alternator)](invoker._arg1, invoker._arg2, invoker._arg3, invoker._arg4);
										};
									};
								};
							};
						};
					};

					return invoker;
			};

			template <typename DispatcherType, typename arg1_type, typename arg2_type, typename arg3_type, typename arg4_type>
			invoke_impl_4_callable<void, DispatcherType, arg1_type, arg2_type, arg3_type, arg4_type> operator<< (
				invoke_impl_4_callable<void, DispatcherType, arg1_type, arg2_type, arg3_type, arg4_type> const & invoker,
				tuple<
				typename DispatcherType::index_type,
				typename DispatcherType::index_type,
				typename DispatcherType::index_type,
				typename DispatcherType::index_type,
				typename DispatcherType::index_type,
				typename DispatcherType::index_type,
				typename DispatcherType::index_type,
				typename DispatcherType::index_type
				> const & alternator) {
					try {
						invoker._dispatcher[get<0>(alternator)](invoker._arg1, invoker._arg2, invoker._arg3, invoker._arg4);
					} catch (unregistered_handler &) {
						try {
							invoker._dispatcher[get<1>(alternator)](invoker._arg1, invoker._arg2, invoker._arg3, invoker._arg4);
						} catch (unregistered_handler &) {
							try {
								invoker._dispatcher[get<2>(alternator)](invoker._arg1, invoker._arg2, invoker._arg3, invoker._arg4);
							} catch (unregistered_handler &) {
								try {
									invoker._dispatcher[get<3>(alternator)](invoker._arg1, invoker._arg2, invoker._arg3, invoker._arg4);
								} catch (unregistered_handler &) {
									try {
										invoker._dispatcher[get<4>(alternator)](invoker._arg1, invoker._arg2, invoker._arg3, invoker._arg4);
									} catch (unregistered_handler &) {
										try {
											invoker._dispatcher[get<5>(alternator)](invoker._arg1, invoker._arg2, invoker._arg3, invoker._arg4);
										} catch (unregistered_handler &) {
											try {
												invoker._dispatcher[get<6>(alternator)](invoker._arg1, invoker._arg2, invoker._arg3, invoker._arg4);
											} catch (unregistered_handler &) {
												invoker._dispatcher[get<7>(alternator)](invoker._arg1, invoker._arg2, invoker._arg3, invoker._arg4);
											};
										};
									};
								};
							};
						};
					};

					return invoker;
			};

			template <typename DispatcherType, typename arg1_type, typename arg2_type, typename arg3_type, typename arg4_type>
			invoke_impl_4_callable<void, DispatcherType, arg1_type, arg2_type, arg3_type, arg4_type> operator<< (
				invoke_impl_4_callable<void, DispatcherType, arg1_type, arg2_type, arg3_type, arg4_type> const & invoker,
				tuple<
				typename DispatcherType::index_type,
				typename DispatcherType::index_type,
				typename DispatcherType::index_type,
				typename DispatcherType::index_type,
				typename DispatcherType::index_type,
				typename DispatcherType::index_type,
				typename DispatcherType::index_type,
				typename DispatcherType::index_type,
				typename DispatcherType::index_type
				> const & alternator) {
					try {
						invoker._dispatcher[get<0>(alternator)](invoker._arg1, invoker._arg2, invoker._arg3, invoker._arg4);
					} catch (unregistered_handler &) {
						try {
							invoker._dispatcher[get<1>(alternator)](invoker._arg1, invoker._arg2, invoker._arg3, invoker._arg4);
						} catch (unregistered_handler &) {
							try {
								invoker._dispatcher[get<2>(alternator)](invoker._arg1, invoker._arg2, invoker._arg3, invoker._arg4);
							} catch (unregistered_handler &) {
								try {
									invoker._dispatcher[get<3>(alternator)](invoker._arg1, invoker._arg2, invoker._arg3, invoker._arg4);
								} catch (unregistered_handler &) {
									try {
										invoker._dispatcher[get<4>(alternator)](invoker._arg1, invoker._arg2, invoker._arg3, invoker._arg4);
									} catch (unregistered_handler &) {
										try {
											invoker._dispatcher[get<5>(alternator)](invoker._arg1, invoker._arg2, invoker._arg3, invoker._arg4);
										} catch (unregistered_handler &) {
											try {
												invoker._dispatcher[get<6>(alternator)](invoker._arg1, invoker._arg2, invoker._arg3, invoker._arg4);
											} catch (unregistered_handler &) {
												try {
													invoker._dispatcher[get<7>(alternator)](invoker._arg1, invoker._arg2, invoker._arg3, invoker._arg4);
												} catch (unregistered_handler &) {
													invoker._dispatcher[get<8>(alternator)](invoker._arg1, invoker._arg2, invoker._arg3, invoker._arg4);
												};
											};
										};
									};
								};
							};
						};
					};

					return invoker;
			};

			template <typename DispatcherType, typename arg1_type, typename arg2_type, typename arg3_type, typename arg4_type>
			invoke_impl_4_callable<void, DispatcherType, arg1_type, arg2_type, arg3_type, arg4_type> operator<< (
				invoke_impl_4_callable<void, DispatcherType, arg1_type, arg2_type, arg3_type, arg4_type> const & invoker,
				tuple<
				typename DispatcherType::index_type,
				typename DispatcherType::index_type,
				typename DispatcherType::index_type,
				typename DispatcherType::index_type,
				typename DispatcherType::index_type,
				typename DispatcherType::index_type,
				typename DispatcherType::index_type,
				typename DispatcherType::index_type,
				typename DispatcherType::index_type,
				typename DispatcherType::index_type
				> const & alternator) {
					try {
						invoker._dispatcher[get<0>(alternator)](invoker._arg1, invoker._arg2, invoker._arg3, invoker._arg4);
					} catch (unregistered_handler &) {
						try {
							invoker._dispatcher[get<1>(alternator)](invoker._arg1, invoker._arg2, invoker._arg3, invoker._arg4);
						} catch (unregistered_handler &) {
							try {
								invoker._dispatcher[get<2>(alternator)](invoker._arg1, invoker._arg2, invoker._arg3, invoker._arg4);
							} catch (unregistered_handler &) {
								try {
									invoker._dispatcher[get<3>(alternator)](invoker._arg1, invoker._arg2, invoker._arg3, invoker._arg4);
								} catch (unregistered_handler &) {
									try {
										invoker._dispatcher[get<4>(alternator)](invoker._arg1, invoker._arg2, invoker._arg3, invoker._arg4);
									} catch (unregistered_handler &) {
										try {
											invoker._dispatcher[get<5>(alternator)](invoker._arg1, invoker._arg2, invoker._arg3, invoker._arg4);
										} catch (unregistered_handler &) {
											try {
												invoker._dispatcher[get<6>(alternator)](invoker._arg1, invoker._arg2, invoker._arg3, invoker._arg4);
											} catch (unregistered_handler &) {
												try {
													invoker._dispatcher[get<7>(alternator)](invoker._arg1, invoker._arg2, invoker._arg3, invoker._arg4);
												} catch (unregistered_handler &) {
													try {
														invoker._dispatcher[get<8>(alternator)](invoker._arg1, invoker._arg2, invoker._arg3, invoker._arg4);
													} catch (unregistered_handler &) {
														invoker._dispatcher[get<9>(alternator)](invoker._arg1, invoker._arg2, invoker._arg3, invoker._arg4);
													};
												};
											};
										};
									};
								};
							};
						};
					};

					return invoker;
			};

		template <typename ReturnType, typename DispatcherType, typename arg1_type, typename arg2_type, typename arg3_type, typename arg4_type>
        invoke_impl_4_callable<ReturnType, DispatcherType, arg1_type, arg2_type, arg3_type, arg4_type> operator<< (
         invoke_impl_4_callable<ReturnType, DispatcherType, arg1_type, arg2_type, arg3_type, arg4_type> const & invoker,
         tuple<
            typename DispatcherType::index_type,
            typename DispatcherType::index_type
            > const & alternator) {

            try {
                invoker._aggregator(invoker._dispatcher[get<0>(alternator)](invoker._arg1, invoker._arg2, invoker._arg3, invoker._arg4));
            } catch (unregistered_handler &) {
                invoker._aggregator(invoker._dispatcher[get<1>(alternator)](invoker._arg1, invoker._arg2, invoker._arg3, invoker._arg4));
            };

            return invoker;
        };

    template <typename ReturnType, typename DispatcherType, typename arg1_type, typename arg2_type, typename arg3_type, typename arg4_type>
        invoke_impl_4_callable<ReturnType, DispatcherType, arg1_type, arg2_type, arg3_type, arg4_type> operator<< (
         invoke_impl_4_callable<ReturnType, DispatcherType, arg1_type, arg2_type, arg3_type, arg4_type> const & invoker,
         tuple<
            typename DispatcherType::index_type,
            typename DispatcherType::index_type,
            typename DispatcherType::index_type
            > const & alternator) {
            try {
                invoker._aggregator(invoker._dispatcher[get<0>(alternator)](invoker._arg1, invoker._arg2, invoker._arg3, invoker._arg4));
            } catch (unregistered_handler &) {
                try {
                    invoker._aggregator(invoker._dispatcher[get<1>(alternator)](invoker._arg1, invoker._arg2, invoker._arg3, invoker._arg4));
                } catch (unregistered_handler &) {
                    invoker._aggregator(invoker._dispatcher[get<2>(alternator)](invoker._arg1, invoker._arg2, invoker._arg3, invoker._arg4));
                };
            };

            return invoker;
        };

    template <typename ReturnType, typename DispatcherType, typename arg1_type, typename arg2_type, typename arg3_type, typename arg4_type>
        invoke_impl_4_callable<ReturnType, DispatcherType, arg1_type, arg2_type, arg3_type, arg4_type> operator<< (
         invoke_impl_4_callable<ReturnType, DispatcherType, arg1_type, arg2_type, arg3_type, arg4_type> const & invoker,
         tuple<
            typename DispatcherType::index_type,
            typename DispatcherType::index_type,
            typename DispatcherType::index_type,
            typename DispatcherType::index_type
            > const & alternator) {
            try {
                invoker._aggregator(invoker._dispatcher[get<0>(alternator)](invoker._arg1, invoker._arg2, invoker._arg3, invoker._arg4));
            } catch (unregistered_handler &) {
                try {
                    invoker._aggregator(invoker._dispatcher[get<1>(alternator)](invoker._arg1, invoker._arg2, invoker._arg3, invoker._arg4));
                } catch (unregistered_handler &) {
                    try {
                        invoker._aggregator(invoker._dispatcher[get<2>(alternator)](invoker._arg1, invoker._arg2, invoker._arg3, invoker._arg4));
                    } catch (unregistered_handler &) {
                        invoker._aggregator(invoker._dispatcher[get<3>(alternator)](invoker._arg1, invoker._arg2, invoker._arg3, invoker._arg4));
                    };
                };
            };

            return invoker;
        };

    template <typename ReturnType, typename DispatcherType, typename arg1_type, typename arg2_type, typename arg3_type, typename arg4_type>
        invoke_impl_4_callable<ReturnType, DispatcherType, arg1_type, arg2_type, arg3_type, arg4_type> operator<< (
         invoke_impl_4_callable<ReturnType, DispatcherType, arg1_type, arg2_type, arg3_type, arg4_type> const & invoker,
         tuple<
            typename DispatcherType::index_type,
            typename DispatcherType::index_type,
            typename DispatcherType::index_type,
            typename DispatcherType::index_type,
            typename DispatcherType::index_type
            > const & alternator) {
            try {
                invoker._aggregator(invoker._dispatcher[get<0>(alternator)](invoker._arg1, invoker._arg2, invoker._arg3, invoker._arg4));
            } catch (unregistered_handler &) {
                try {
                    invoker._aggregator(invoker._dispatcher[get<1>(alternator)](invoker._arg1, invoker._arg2, invoker._arg3, invoker._arg4));
                } catch (unregistered_handler &) {
                    try {
                        invoker._aggregator(invoker._dispatcher[get<2>(alternator)](invoker._arg1, invoker._arg2, invoker._arg3, invoker._arg4));
                    } catch (unregistered_handler &) {
                        try {
                            invoker._aggregator(invoker._dispatcher[get<3>(alternator)](invoker._arg1, invoker._arg2, invoker._arg3, invoker._arg4));
                        } catch (unregistered_handler &) {
                            invoker._aggregator(invoker._dispatcher[get<4>(alternator)](invoker._arg1, invoker._arg2, invoker._arg3, invoker._arg4));
                        };
                    };
                };
            };

            return invoker;
        };

    template <typename ReturnType, typename DispatcherType, typename arg1_type, typename arg2_type, typename arg3_type, typename arg4_type>
        invoke_impl_4_callable<ReturnType, DispatcherType, arg1_type, arg2_type, arg3_type, arg4_type> operator<< (
         invoke_impl_4_callable<ReturnType, DispatcherType, arg1_type, arg2_type, arg3_type, arg4_type> const & invoker,
         tuple<
            typename DispatcherType::index_type,
            typename DispatcherType::index_type,
            typename DispatcherType::index_type,
            typename DispatcherType::index_type,
            typename DispatcherType::index_type,
            typename DispatcherType::index_type
            > const & alternator) {
            try {
                invoker._aggregator(invoker._dispatcher[get<0>(alternator)](invoker._arg1, invoker._arg2, invoker._arg3, invoker._arg4));
            } catch (unregistered_handler &) {
                try {
                    invoker._aggregator(invoker._dispatcher[get<1>(alternator)](invoker._arg1, invoker._arg2, invoker._arg3, invoker._arg4));
                } catch (unregistered_handler &) {
                    try {
                        invoker._aggregator(invoker._dispatcher[get<2>(alternator)](invoker._arg1, invoker._arg2, invoker._arg3, invoker._arg4));
                    } catch (unregistered_handler &) {
                        try {
                            invoker._aggregator(invoker._dispatcher[get<3>(alternator)](invoker._arg1, invoker._arg2, invoker._arg3, invoker._arg4));
                        } catch (unregistered_handler &) {
                            try {
                                invoker._aggregator(invoker._dispatcher[get<4>(alternator)](invoker._arg1, invoker._arg2, invoker._arg3, invoker._arg4));
                            } catch (unregistered_handler &) {
                                invoker._aggregator(invoker._dispatcher[get<5>(alternator)](invoker._arg1, invoker._arg2, invoker._arg3, invoker._arg4));
                            };
                        };
                    };
                };
            };

            return invoker;
        };

    template <typename ReturnType, typename DispatcherType, typename arg1_type, typename arg2_type, typename arg3_type, typename arg4_type>
        invoke_impl_4_callable<ReturnType, DispatcherType, arg1_type, arg2_type, arg3_type, arg4_type> operator<< (
         invoke_impl_4_callable<ReturnType, DispatcherType, arg1_type, arg2_type, arg3_type, arg4_type> const & invoker,
         tuple<
            typename DispatcherType::index_type,
            typename DispatcherType::index_type,
            typename DispatcherType::index_type,
            typename DispatcherType::index_type,
            typename DispatcherType::index_type,
            typename DispatcherType::index_type,
            typename DispatcherType::index_type
            > const & alternator) {
            try {
                invoker._aggregator(invoker._dispatcher[get<0>(alternator)](invoker._arg1, invoker._arg2, invoker._arg3, invoker._arg4));
            } catch (unregistered_handler &) {
                try {
                    invoker._aggregator(invoker._dispatcher[get<1>(alternator)](invoker._arg1, invoker._arg2, invoker._arg3, invoker._arg4));
                } catch (unregistered_handler &) {
                    try {
                        invoker._aggregator(invoker._dispatcher[get<2>(alternator)](invoker._arg1, invoker._arg2, invoker._arg3, invoker._arg4));
                    } catch (unregistered_handler &) {
                        try {
                            invoker._aggregator(invoker._dispatcher[get<3>(alternator)](invoker._arg1, invoker._arg2, invoker._arg3, invoker._arg4));
                        } catch (unregistered_handler &) {
                            try {
                                invoker._aggregator(invoker._dispatcher[get<4>(alternator)](invoker._arg1, invoker._arg2, invoker._arg3, invoker._arg4));
                            } catch (unregistered_handler &) {
                                try {
                                    invoker._aggregator(invoker._dispatcher[get<5>(alternator)](invoker._arg1, invoker._arg2, invoker._arg3, invoker._arg4));
                                } catch (unregistered_handler &) {
                                    invoker._aggregator(invoker._dispatcher[get<6>(alternator)](invoker._arg1, invoker._arg2, invoker._arg3, invoker._arg4));
                                };
                            };
                        };
                    };
                };
            };

            return invoker;
        };

    template <typename ReturnType, typename DispatcherType, typename arg1_type, typename arg2_type, typename arg3_type, typename arg4_type>
        invoke_impl_4_callable<ReturnType, DispatcherType, arg1_type, arg2_type, arg3_type, arg4_type> operator<< (
         invoke_impl_4_callable<ReturnType, DispatcherType, arg1_type, arg2_type, arg3_type, arg4_type> const & invoker,
         tuple<
            typename DispatcherType::index_type,
            typename DispatcherType::index_type,
            typename DispatcherType::index_type,
            typename DispatcherType::index_type,
            typename DispatcherType::index_type,
            typename DispatcherType::index_type,
            typename DispatcherType::index_type,
            typename DispatcherType::index_type
            > const & alternator) {
            try {
                invoker._aggregator(invoker._dispatcher[get<0>(alternator)](invoker._arg1, invoker._arg2, invoker._arg3, invoker._arg4));
            } catch (unregistered_handler &) {
                try {
                    invoker._aggregator(invoker._dispatcher[get<1>(alternator)](invoker._arg1, invoker._arg2, invoker._arg3, invoker._arg4));
                } catch (unregistered_handler &) {
                    try {
                        invoker._aggregator(invoker._dispatcher[get<2>(alternator)](invoker._arg1, invoker._arg2, invoker._arg3, invoker._arg4));
                    } catch (unregistered_handler &) {
                        try {
                            invoker._aggregator(invoker._dispatcher[get<3>(alternator)](invoker._arg1, invoker._arg2, invoker._arg3, invoker._arg4));
                        } catch (unregistered_handler &) {
                            try {
                                invoker._aggregator(invoker._dispatcher[get<4>(alternator)](invoker._arg1, invoker._arg2, invoker._arg3, invoker._arg4));
                            } catch (unregistered_handler &) {
                                try {
                                    invoker._aggregator(invoker._dispatcher[get<5>(alternator)](invoker._arg1, invoker._arg2, invoker._arg3, invoker._arg4));
                                } catch (unregistered_handler &) {
                                    try {
                                        invoker._aggregator(invoker._dispatcher[get<6>(alternator)](invoker._arg1, invoker._arg2, invoker._arg3, invoker._arg4));
                                    } catch (unregistered_handler &) {
                                        invoker._aggregator(invoker._dispatcher[get<7>(alternator)](invoker._arg1, invoker._arg2, invoker._arg3, invoker._arg4));
                                    };
                                };
                            };
                        };
                    };
                };
            };

            return invoker;
        };

    template <typename ReturnType, typename DispatcherType, typename arg1_type, typename arg2_type, typename arg3_type, typename arg4_type>
        invoke_impl_4_callable<ReturnType, DispatcherType, arg1_type, arg2_type, arg3_type, arg4_type> operator<< (
         invoke_impl_4_callable<ReturnType, DispatcherType, arg1_type, arg2_type, arg3_type, arg4_type> const & invoker,
         tuple<
            typename DispatcherType::index_type,
            typename DispatcherType::index_type,
            typename DispatcherType::index_type,
            typename DispatcherType::index_type,
            typename DispatcherType::index_type,
            typename DispatcherType::index_type,
            typename DispatcherType::index_type,
            typename DispatcherType::index_type,
            typename DispatcherType::index_type
            > const & alternator) {
            try {
                invoker._aggregator(invoker._dispatcher[get<0>(alternator)](invoker._arg1, invoker._arg2, invoker._arg3, invoker._arg4));
            } catch (unregistered_handler &) {
                try {
                    invoker._aggregator(invoker._dispatcher[get<1>(alternator)](invoker._arg1, invoker._arg2, invoker._arg3, invoker._arg4));
                } catch (unregistered_handler &) {
                    try {
                        invoker._aggregator(invoker._dispatcher[get<2>(alternator)](invoker._arg1, invoker._arg2, invoker._arg3, invoker._arg4));
                    } catch (unregistered_handler &) {
                        try {
                            invoker._aggregator(invoker._dispatcher[get<3>(alternator)](invoker._arg1, invoker._arg2, invoker._arg3, invoker._arg4));
                        } catch (unregistered_handler &) {
                            try {
                                invoker._aggregator(invoker._dispatcher[get<4>(alternator)](invoker._arg1, invoker._arg2, invoker._arg3, invoker._arg4));
                            } catch (unregistered_handler &) {
                                try {
                                    invoker._aggregator(invoker._dispatcher[get<5>(alternator)](invoker._arg1, invoker._arg2, invoker._arg3, invoker._arg4));
                                } catch (unregistered_handler &) {
                                    try {
                                        invoker._aggregator(invoker._dispatcher[get<6>(alternator)](invoker._arg1, invoker._arg2, invoker._arg3, invoker._arg4));
                                    } catch (unregistered_handler &) {
                                        try {
                                            invoker._aggregator(invoker._dispatcher[get<7>(alternator)](invoker._arg1, invoker._arg2, invoker._arg3, invoker._arg4));
                                        } catch (unregistered_handler &) {
                                            invoker._aggregator(invoker._dispatcher[get<8>(alternator)](invoker._arg1, invoker._arg2, invoker._arg3, invoker._arg4));
                                        };
                                    };
                                };
                            };
                        };
                    };
                };
            };

            return invoker;
        };

    template <typename ReturnType, typename DispatcherType, typename arg1_type, typename arg2_type, typename arg3_type, typename arg4_type>
        invoke_impl_4_callable<ReturnType, DispatcherType, arg1_type, arg2_type, arg3_type, arg4_type> operator<< (
         invoke_impl_4_callable<ReturnType, DispatcherType, arg1_type, arg2_type, arg3_type, arg4_type> const & invoker,
         tuple<
            typename DispatcherType::index_type,
            typename DispatcherType::index_type,
            typename DispatcherType::index_type,
            typename DispatcherType::index_type,
            typename DispatcherType::index_type,
            typename DispatcherType::index_type,
            typename DispatcherType::index_type,
            typename DispatcherType::index_type,
            typename DispatcherType::index_type,
            typename DispatcherType::index_type
            > const & alternator) {
            try {
                invoker._aggregator(invoker._dispatcher[get<0>(alternator)](invoker._arg1, invoker._arg2, invoker._arg3, invoker._arg4));
            } catch (unregistered_handler &) {
                try {
                    invoker._aggregator(invoker._dispatcher[get<1>(alternator)](invoker._arg1, invoker._arg2, invoker._arg3, invoker._arg4));
                } catch (unregistered_handler &) {
                    try {
                        invoker._aggregator(invoker._dispatcher[get<2>(alternator)](invoker._arg1, invoker._arg2, invoker._arg3, invoker._arg4));
                    } catch (unregistered_handler &) {
                        try {
                            invoker._aggregator(invoker._dispatcher[get<3>(alternator)](invoker._arg1, invoker._arg2, invoker._arg3, invoker._arg4));
                        } catch (unregistered_handler &) {
                            try {
                                invoker._aggregator(invoker._dispatcher[get<4>(alternator)](invoker._arg1, invoker._arg2, invoker._arg3, invoker._arg4));
                            } catch (unregistered_handler &) {
                                try {
                                    invoker._aggregator(invoker._dispatcher[get<5>(alternator)](invoker._arg1, invoker._arg2, invoker._arg3, invoker._arg4));
                                } catch (unregistered_handler &) {
                                    try {
                                        invoker._aggregator(invoker._dispatcher[get<6>(alternator)](invoker._arg1, invoker._arg2, invoker._arg3, invoker._arg4));
                                    } catch (unregistered_handler &) {
                                        try {
                                            invoker._aggregator(invoker._dispatcher[get<7>(alternator)](invoker._arg1, invoker._arg2, invoker._arg3, invoker._arg4));
                                        } catch (unregistered_handler &) {
                                            try {
                                                invoker._aggregator(invoker._dispatcher[get<8>(alternator)](invoker._arg1, invoker._arg2, invoker._arg3, invoker._arg4));
                                            } catch (unregistered_handler &) {
                                                invoker._aggregator(invoker._dispatcher[get<9>(alternator)](invoker._arg1, invoker._arg2, invoker._arg3, invoker._arg4));
                                            };
                                        };
                                    };
                                };
                            };
                        };
                    };
                };
            };

            return invoker;
        };

        }; // namespace detail
    }; // namespace dispatch
}; // namespace boost

#endif
