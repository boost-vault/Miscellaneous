// Copyright 2006 (C) Dean Michael Berris <dean@orangeandbronze.com>
// Distributed under the Boost Software License, Version 1.0. (See accompanying
// file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)

#ifndef __FUNCTOR3_HPP_
#define __FUNCTOR3_HPP_

#include <boost/static_assert.hpp>
#include <boost/type_traits/is_same.hpp>
#include <boost/function.hpp>
#include "dispatch_exceptions.hpp"

namespace boost {
    namespace dispatch {
        namespace detail {

            template <typename return_type, 
                typename arg1_type, 
                typename arg2_type, 
                typename arg3_type
            >
            class functor_impl_3 {

                BOOST_STATIC_ASSERT((!boost::is_same<arg1_type, void>::value));
                BOOST_STATIC_ASSERT((!boost::is_same<arg2_type, void>::value));
                BOOST_STATIC_ASSERT((!boost::is_same<arg3_type, void>::value));

            public:

                typedef boost::function<return_type (arg1_type, arg2_type, arg3_type)> wrapped_function_type;

                functor_impl_3 () : _wrapped_function(default_function) { };

                return_type operator() (const arg1_type & arg1, const arg2_type & arg2, const arg3_type & arg3) {
                    return _wrapped_function(arg1, arg2, arg3);
                };

            protected:
                wrapped_function_type _wrapped_function;

                static return_type default_function (arg1_type, arg2_type, arg3_type) {
                    throw unregistered_handler();
                };
            };

            template <typename arg1_type, 
                typename arg2_type, 
                typename arg3_type
            >
            class functor_impl_3<void, arg1_type, arg2_type, arg3_type> {

                BOOST_STATIC_ASSERT((!boost::is_same<arg1_type, void>::value));
                BOOST_STATIC_ASSERT((!boost::is_same<arg2_type, void>::value));
                BOOST_STATIC_ASSERT((!boost::is_same<arg3_type, void>::value));

            public:

                typedef boost::function<void (arg1_type, arg2_type, arg3_type)> wrapped_function_type;

                functor_impl_3 () : _wrapped_function(default_function) { };

                void operator() (const arg1_type & arg1, const arg2_type & arg2, const arg3_type & arg3) {
                    _wrapped_function(arg1, arg2, arg3);
                };

            protected:

                wrapped_function_type _wrapped_function;

                static void default_function (arg1_type, arg2_type, arg3_type) {
                    throw unregistered_handler();
                };
            };

        }; // namespace detail
    }; // namespace dispatch
}; // namespace boost

#endif
