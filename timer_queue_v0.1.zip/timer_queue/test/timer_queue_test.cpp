
//==============================================================================================
//      LICENSE INFO
//==============================================================================================
//          Copyright John Q. Smith 2009-2011
// Distributed under the Boost Software License, Version 1.0.
//    See accompanying file LICENSE_1_0.txt or copy at:
//          http://www.boost.org/LICENSE_1_0.txt
//==============================================================================================

//==============================================================================================
//       DESCRIPTION - timer_queue_test.cpp
//==============================================================================================
// timer_queue_test.cpp is a test file included with the Timer Queue library.
// The purpose of this file is to test the main functions of the library - adding
// timers, deleting timers, timers firing within specified windows of time.
//
// See http://www.boost.org/libs/timer_queue for library home page.
//----------------------------------------------------------------------------------------------
// Timer Queue is a library that allows you to specify some arbitrary future time
// at which to be handed back a value that you supply at timer creation. The Timer
// Queue library is thread safe (meaning it can be called by multiple threads within
// the same program) without corrupting its state. The underlying container mechanism 
// for the Timer Queue is a bi-index multi-map so it can maintain many outstanding
// timers.
// 
// The creation of timers is in units of boost::system_time, the value handed back is 
// of type void*. In addition, you can specify a non-unique timer id that can be used 
// to find and delete timers before they fire (thereby avoiding context switches for 
// obsolete timers).
//==============================================================================================


#include "../timer_queue.hpp"

using namespace boost;

//******************************************************************************************
//      CLASS TO HELP WITH TESTING
//******************************************************************************************

typedef struct test_timer_info  
{
    long                    data;
    long                    offset_time;
    boost::system_time      expected_time;
} test_timer_info;

class timer_queue_test
{
public:
    timer_queue                                                    *m_timer_queue_ptr;
    long                                                            m_cur_test_timer_cnt;
    long                                                            m_max_test_timer_cnt;
    long                                                            m_timer_tolerance;
    bool                                                            m_timer_test_ok;
	bool                                                            m_verbose;
    boost::function<void(void* y, long x)>                          m_orig_callback_func;    // boost function pointer.
    std::queue<test_timer_info*>                                    m_test_timers;

public:
    timer_queue_test(timer_queue *timer_queue_ptr);
    ~timer_queue_test();
    
    void                                test_timer_callback(void *data_ptr, long event_type);
    void                                test_timers(long max_timer_tests, long ms_interval, long ms_tolerance);
    bool                                test_timers_done();
    bool                                get_timer_test_ok();
	void                                set_verbose(bool verbose_on);

};


//******************************************************************************************
//      MAIN
//          - Creates a TimerQueue object, inits it to create the timer thread.
//          - Calls a test routine to put 120 timers into TimerQueue
//          - Waits until timer test is done - prints result.
//******************************************************************************************

int main(int argc, char **argv)
{
    
    timer_queue *timer_queue_ptr = new timer_queue;
    timer_queue_test *timer_queue_test_ptr = new timer_queue_test(timer_queue_ptr);
   
    //---------------------------------------------------------------------------
    //      TIMER TEST
    //---------------------------------------------------------------------------
    if (timer_queue_test_ptr != NULL && timer_queue_ptr != NULL) {
            // there's only one param possible... "-v" for verbose
        timer_queue_test_ptr->set_verbose( (argc==2) && ( ! strcmp(argv[1],"-v")) );
        timer_queue_ptr->init(); // starts the timer thread.
        printf("Timer Test: STARTING: (~30 seconds).\n");
        timer_queue_test_ptr->test_timers(100, 250, 10);  // # of timers, interval between timers, accuracy tolerance in ms.  
            // The timer fires and is resolved in its own thread, so putting this
            // one to sleep doesn't hurt the timer test.
        while (! timer_queue_test_ptr->test_timers_done() )
            sleep (1);
        
        if (timer_queue_test_ptr->get_timer_test_ok()) {
            printf("Timer Test: DONE: All Ok.\n");
            return 0;
        }
        else {
            printf("Timer Test: ERROR: Timer test failed.\n");
            return -1;
        }
    }
    return 0;
}


//******************************************************************************************
//      TimerTestQueue
//          - Two main things this class does
//              1. TestTimers() - set the TimerQueue callback, fill up TimerQueue with 
//                      timers for testing.
//              2. TestTimerCallback() - callback to receive timer event. Monitors
//                      what timer fired when and indicates anything unexpected.
//******************************************************************************************


timer_queue_test::timer_queue_test(timer_queue *timer_queue_ptr)
{
    m_timer_queue_ptr = timer_queue_ptr;
    m_cur_test_timer_cnt = 0;
    m_max_test_timer_cnt = 0;
	m_verbose = false;
}

timer_queue_test::~timer_queue_test()
{
}

bool timer_queue_test::test_timers_done()
{
    return (m_cur_test_timer_cnt==0);
}

bool timer_queue_test::get_timer_test_ok()
{
    return m_timer_test_ok;
}

void timer_queue_test::set_verbose(bool verbose_on)
{
    m_verbose = verbose_on;
}

    //=======================================================================================
    // The timer callback is called in exactly two cases:
    // 1. a timer fired (lEventType=TIMER_EVENT_FIRED) and is passing back data (pData)
    // 2. a timer was deleted - callback is called to give parent routine an opportunity
    //          to cleanup whatever is in pData if needed (lEventType=TIMER_DELETE_DATA)
    //=======================================================================================
void timer_queue_test::test_timer_callback(void *data_ptr, long event_type)
{
    if (data_ptr==NULL) return; // nothing to process.

        // If we're being called only to delete some data then do it and return.
        // Note: we malloc'd stuff below that we passed to the timer when created - so need to free it when timer deleted.
        //       If you just pass the timer a value when created, then no need to free anything here.
    if (event_type==TIMER_DELETE_DATA) {
        free (data_ptr); 
        return;
    }

    //=================================================================
    // If here then timer fired normally and we got callback'd
    // So do whatever you want to do as a result of the timer firing.
    //=================================================================

    test_timer_info *test_timer_ptr = (test_timer_info *) data_ptr;
    test_timer_info *tmp_queue_data_ptr = m_test_timers.front();
    m_test_timers.pop();
    
        // See if the timer fired when it was supposed to.
    boost::system_time curtime = boost::get_system_time();
    boost::posix_time::milliseconds ms_tolerance(m_timer_tolerance);
    std::string tmpstr1 = boost::posix_time::to_simple_string(test_timer_ptr->expected_time);
    std::string tmpstr2 = boost::posix_time::to_simple_string(curtime);
    if ( (curtime > (test_timer_ptr->expected_time + ms_tolerance) ) || (curtime < (test_timer_ptr->expected_time - ms_tolerance) ) ) {
        m_timer_test_ok = false;
        if (m_verbose) {
            printf("Timer Test: ERROR: Timer:%ld: expected at:%s: delivered at:%s:  outside of %ld ms tolerance window.\n",
                                tmp_queue_data_ptr->data, tmpstr1.c_str(), tmpstr2.c_str(), m_timer_tolerance);
        }
    }
    else if (m_verbose) {
        printf("TestTimerCallback: The timer looks good. TimerNum:%ld: TimerTime:%s:  CurrentTime:%s:.\n", 
                                test_timer_ptr->data, tmpstr1.c_str(), tmpstr2.c_str());
    }

        // See if we're done yet... if so, set the TimerQueue callback back to the original one.
    if (--m_cur_test_timer_cnt == 0)
        m_timer_queue_ptr->set_callback_func( m_orig_callback_func );

        // We're done with the test data we were passed to the timer when we created it... so free it.
    free (data_ptr);
}

void timer_queue_test::test_timers(long max_timer_tests, long ms_interval, long ms_tolerance)
{
    std::string err_mssg;
    
    m_timer_test_ok = true;
    m_cur_test_timer_cnt = max_timer_tests; // we'll be counting down to zero so we know when we're done.
    m_max_test_timer_cnt = max_timer_tests;
    m_timer_tolerance = ms_tolerance;
    
    if (m_verbose) {
	    printf("Timer Test: Here's what we're testing....\n");
	    printf("Timer Test:      Num timers to start = %ld\n", m_max_test_timer_cnt);
	    printf("Timer Test:      One timer will be inserted out of sequence to test correct ordering.\n");
	    printf("Timer Test:      Twenty extra timers will be inserted and deleted in two groups to test timer deletion.\n");
	    printf("Timer Test:      All timers are put on the timing queue at the same time with different\n");
	    printf("Timer Test:      finish times (with a %ld ms tolerance).\n", m_timer_tolerance);
	    printf("Timer Test:\n");
    }

        // Save the original callback.
    m_timer_queue_ptr->get_callback_func(m_orig_callback_func);
        // Set the callback to our test callback.
    boost::function<void(void* x, long y)> timer_callback_func = boost::bind(&timer_queue_test::test_timer_callback, this, _1, _2);
    m_timer_queue_ptr->set_callback_func( timer_callback_func );
    
        // Empty out anything still on the queue.
    while ( ! m_test_timers.empty() )
        m_test_timers.pop();
        
        // Let's set max_timer_tests timers (total # of timers to create for this test) at intervals of lInterval ms.
    long tmp_id = 0;
    bool timer_inserted = false;
    test_timer_info *first_test_info_ptr = NULL;
    boost::system_time curtime = boost::get_system_time();
    for (long i=1; i<=m_max_test_timer_cnt+20; i++) {
        
            // Certain ranges we'll use for deletion tests.
        if (i>50 && i<=60)
             tmp_id = 4444;
        else if (i>100 && i<=110)
             tmp_id = 8888;
        else tmp_id = 0;

            // Allocate a test timer info struct and fill it.
        test_timer_info *test_info_ptr = (test_timer_info*) malloc(sizeof(test_timer_info));
        memset((void*)test_info_ptr, 0, sizeof(test_timer_info));
        test_info_ptr->data = i; // keep a count... make sure the timers arrive in order and around the time expected.
        test_info_ptr->offset_time = i * ms_interval; // Set "n" timers in increments of lInterval ms.
        test_info_ptr->expected_time = curtime + boost::posix_time::milliseconds(test_info_ptr->offset_time);

            // Don't put the one's we're going to delete ( tmpId > 0 ) into our the test queue
            // because we're going to delete them from TimerQueue anyway - so don't need to track them.
        if (tmp_id == 0)
            m_test_timers.push(test_info_ptr);

            // Don't put first one in the TimerQueue *yet*. Wait till all are done then insert
            // it so we can test that inserting a timer earlier than existing timers causes
            // the timer loop to re-wait on the newer (earlier) timer.
        if (i == 1) {
            first_test_info_ptr = test_info_ptr; // save ptr to first one... add later to test sorting and thread wake up.
            timer_inserted = true;
        }
        else timer_inserted = m_timer_queue_ptr->new_timer(test_info_ptr->offset_time, (void*) test_info_ptr, tmp_id);

            // At a fairly random point, insert the first timer we created... the result
            // is that it should get inserted to the beginning of the timer list.
        if (i == 30 && timer_inserted)
            timer_inserted = m_timer_queue_ptr->new_timer(first_test_info_ptr->offset_time, (void*) first_test_info_ptr);  // now insert the first one (out of order)
        
            // If any trouble with insertion then bail.
        if ( ! timer_inserted ) {
            if (m_verbose) {
                printf("Timer Test: ERROR: Problem inserting timer number :%ld:. Stopping test.\n", i);
                printf("Timer Test: ERROR: Timer test failed.\n\n");
            }
                // Set the callback back to the original callback.
            m_timer_queue_ptr->set_callback_func( m_orig_callback_func );
            m_cur_test_timer_cnt=0; // so we'll exit the test.
            break;
        }
    }

        // Delete some extra timers we inserted to test deletion by id.
    int delete_cnt = m_timer_queue_ptr->delete_timers_by_id(4444); // we inserted some with id=4444, so test deleting them now.
    if (delete_cnt != 10) {
        m_timer_test_ok = false;
        if (m_verbose) {
            printf("Timer Test: Test1 for deleting timers DID NOT PASS! Deleted :%d: instead of 10.\n", delete_cnt);
        }
        else if (m_verbose) {
            printf("Timer Test: Just deleted 10 deletion test timers with id:4444:. This is good.\n");
        }
    }

        // Delete some extra timers we inserted to test deletion by id.
    delete_cnt =  m_timer_queue_ptr->delete_timers_by_id(8888); // we inserted some with id=8888, so test deleting them now.
    if (delete_cnt != 10) {
        m_timer_test_ok = false;
        if (m_verbose) {
            printf("Timer Test: Test2 for deleting timers DID NOT PASS! Deleted :%d: instead of 10.\n", delete_cnt);
        }
        else if (m_verbose) {
            printf("Timer Test: Just deleted 10 deletion test timers with id:8888:. This is good.\n");
        }
    }

}




