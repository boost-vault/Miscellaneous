
//==============================================================================================
//      LICENSE INFO
//==============================================================================================
//          Copyright John Q. Smith 2009-2011
// Distributed under the Boost Software License, Version 1.0.
//    See accompanying file LICENSE_1_0.txt or copy at:
//          http://www.boost.org/LICENSE_1_0.txt
//==============================================================================================

//==============================================================================================
//       DESCRIPTION - timer_queue.hpp
//==============================================================================================
// Timer Queue is a library that allows you to specify some arbitrary future time
// at which to be handed back a value that you supply at timer creation. The Timer
// Queue library is thread safe (meaning it can be called by multiple threads within
// the same program) without corrupting its state. The underlying container mechanism 
// for the Timer Queue is a bi-index multi-map so it can maintain many outstanding
// timers.
// 
// The creation of timers is in units of boost::system_time, the value handed back is 
// of type void*. In addition, you can specify a non-unique timer id that can be used 
// to find and delete timers before they fire (thereby avoiding context switches for 
// obsolete timers).
//
// See http://www.boost.org/libs/timer_queue for library home page.
//==============================================================================================


#ifndef BOOST_TIMER_QUEUE_H
    #define BOOST_TIMER_QUEUE_H
    
    
//**********************************************************************************************
//  DEFINES
//**********************************************************************************************

#define     TIMER_EVENT_FIRED       1
#define     TIMER_DELETE_DATA       2

    // When a timer goes off, use this to set a "window" of time around the current time
    // such that any timers within that window will get called now as opposed to re-waiting.
#define     TIMER_CLOSE_ENOUGH      20          // # of ms +/- current time for "done" window.

//**********************************************************************************************
//  INCLUDES
//**********************************************************************************************

//------------- queues, maps, etc -------------------------
#include <utility>
#include <queue>
#include <map>
#include <stdarg.h>
#include <sys/time.h>
//------------- boost includes -------------------------
#include <boost/date_time/posix_time/posix_time.hpp>
#include <boost/asio.hpp>
#include <boost/thread.hpp>
#include <boost/multi_index_container.hpp>
#include <boost/multi_index/member.hpp>
#include <boost/multi_index/ordered_index.hpp>
#include <boost/tuple/tuple.hpp>

#include "details/timer_bimultimap.hpp"

//using boost::multi_index_container;
//using namespace boost::multi_index;


namespace boost {  

    struct timer_queue_event {
        boost::system_time                  absolute_time;
        void                                *data_ptr;
        long                                data_len;
        long                                timer_id;
    
        timer_queue_event(boost::system_time time_, void* data_, long len_, long id_):absolute_time(time_),data_ptr(data_),data_len(len_),timer_id(id_){}
    };

    typedef timer_queue_event* timer_event_ptr;
    typedef concurrent_bimultimap<boost::system_time,long,void*> timer_bimultimap;

    class timer_queue
    {
    private:
        bool                                                            m_inited;
        bool                                                            m_stop_timer_thread;
        boost::condition_variable                                       m_timer_cond;
        mutable boost::mutex                                            m_timer_mutex;
        boost::function<void(void* y, long x)>                          m_callback_func;    // boost function pointer.
//      boost::function2<void, void*>                                   m_callback_func;    // same as above but maybe better for cross-platform.
        timer_bimultimap                                                m_timeline_bimimap;

    
    public:

        timer_queue()
        {
            m_inited = false;
            m_stop_timer_thread = false;
        }

        ~timer_queue()
        {
                // Timer thread checks this to see if it should exit.
                // We only set it here and only read it in the Timer Thread... so I don't mutex it since no one else writes to it.
            m_stop_timer_thread = true;
            m_timer_cond.notify_all(); // causes any currrent waits to exit so timer_loop will see m_stop_timer_thread bool.
            boost::system_time tmp_time;
            m_timeline_bimimap.insert(tmp_time, 0, NULL);  // push this so wakes up any waits on the Vector.
            m_inited = false; // We are no longer a usable timer.
    
            printf("timer_queue: deconstructor: Waiting for timer queue thread to exit.\n");
            sleep (5);
        }

        bool init()
        {
            if (m_inited)  // don't start another thread if already have one.
                 return false;

                // Create the timer thread.
            boost::thread* tmp_timer_thread = new boost::thread( boost::bind( &timer_queue::timer_loop, this ) );
            if (tmp_timer_thread == NULL) {
                printf("timer_queue:init: ERROR: Could not start timer queue thread !! Critical Error.\n");
                return false;
            }

            m_inited = true; // so if accidentally call this method again, don't start two threads.
            return m_inited;
        }

        void uninit()
        {
        }

        void get_callback_func(boost::function<void(void* y, long x)> & callback_func) 
        {
            callback_func = m_callback_func; 
        }

            // note: id param has default value of 0
        bool new_timer(long ms_offset, void *new_timer_data_ptr, long id=0)
        {
            if (ms_offset < 0)
                 return false;

                // Determine the absolute time for this timer.
            boost::system_time absolute_time = boost::get_system_time() + boost::posix_time::milliseconds(ms_offset);
                // Acquire the lock so we can operate on m_timeline_bimimap.
            boost::mutex::scoped_lock timer_lock(m_timer_mutex);
                // Find the next timer that will fire to see if the new timer is sooner.
            bool reset_timer = false;
                // compare the new time to the current waiting time (if any). 
                // If shorter then wake up the timer so that it will read in the new (earlier) time.
            void *cur_timer_data_ptr = NULL;
            boost::system_time cur_timer;
			long timer_id = 0;
            if ( m_timeline_bimimap.front(cur_timer, timer_id, cur_timer_data_ptr) )
                reset_timer = (absolute_time < cur_timer);

                // Add this AFTER do the time comparison above.
            m_timeline_bimimap.insert( absolute_time, id, new_timer_data_ptr );
                // If need to reset the timer because our new timer event is
                // EARLIER than the existing one, then do it now. Make sure this
                // is *after* the insert above so that the TimerLoop will pick
                // up the new (earlier) time. Don't just compare the map begin()
                // with the iterator returned from inserting... times could be equal
                // and no sense waking up the timer to replace it with the same time.
            if (reset_timer)
                m_timer_cond.notify_all();  // wakes up our "wait" in TimerLoop ahead of time.

            return true;
        }

        int delete_timers_by_id(long id)
        {
            int                   num_deleted = 0;
            boost::system_time    cur_timer;
			long                  timer_id = 0;
            void                  *data_ptr = NULL;
			bool                  reset_timer = false;

                // Acquire the lock so we can operate on m_timeline_bimimap.
            boost::mutex::scoped_lock timer_lock(m_timer_mutex);

                // see if the first timer matches the id. If so, then we need
                // to wake everyone up when we're done so we can figure out a
                // new time to wait on.
			if ( m_timeline_bimimap.front(cur_timer, timer_id, data_ptr) )
				reset_timer = (timer_id == id);
			
                // Erase an entry and pass the data back to the calling routine via
                // the callback so it can delete or free the mem if needed.
            while ( m_timeline_bimimap.erase_key2(id, data_ptr) ) {
                if ( ! m_callback_func.empty()) {
                    m_callback_func(data_ptr, TIMER_DELETE_DATA);
                    data_ptr = NULL;
                }
                num_deleted++;
            }

                // we deleted the first timer, so wake up and figure out if have a new wakeup time.
			if (reset_timer)
                m_timer_cond.notify_all();  // wakes up our "wait" in TimerLoop ahead of time.

            return num_deleted;
        }

        bool set_callback_func( boost::function<void(void* y, long x)>  callback_func)
        {
            if ( callback_func.empty() )
                return false;
    
            m_callback_func = callback_func;
            return true;
        }

        void timer_loop()
        {
            void                                *data_ptr = NULL;
            boost::system_time                  cur_timer;
			long                                timer_id = 0;
            boost::unique_lock<boost::mutex>    timer_lock(m_timer_mutex);
    
                // m_stop_timer_thread gets set by uninit().
            while ( true ) {

                    // This takes care of these cases:
                    // no TimerEvents, TimerEvent==NULL, TimerEvent with future time, TimerEvent with past time. 
                bool timer_fired = false;
        
                if (m_timeline_bimimap.front(cur_timer, timer_id, data_ptr)) {
                    if (cur_timer <=  boost::get_system_time() )
                         timer_fired = true;
                    else timer_fired =  ( ! m_timer_cond.timed_wait(timer_lock, cur_timer) );
                }
                else m_timer_cond.wait(timer_lock);  // there's nothing in m_timeline_bimimap... wait for something to be inserted.
        
                // On exit from the "waits" on the condition vars above, "timerLock" is locked.
            
                if ( m_stop_timer_thread )
                    break; // Cause thread to exit by exiting this while loop.
            
                if ( timer_fired ) {
                    if ( m_timeline_bimimap.try_pop(cur_timer, data_ptr) ) {
                            // Callback - let the originator know timer expiration... pass back whatever they gave us.
                        if ( ! m_callback_func.empty()) {
                            m_callback_func(data_ptr, TIMER_EVENT_FIRED);
                        }

                            // Look for any other Timer Events within the TIMER_CLOSE_ENOUGH window of time.
                        data_ptr = NULL;
                        bool done = false;
                        boost::system_time close_enough_time = boost::get_system_time() + boost::posix_time::milliseconds(TIMER_CLOSE_ENOUGH);
                        while ( ! done && m_timeline_bimimap.front(cur_timer, timer_id, data_ptr) ) {
                            if (cur_timer <= close_enough_time) {
                                m_callback_func(data_ptr, TIMER_EVENT_FIRED);
                                data_ptr = NULL;
                                m_timeline_bimimap.erase_front();
                            }
                            else done = true; // don't walk the entire map... if hit an element outside our time window, then stop.
                        }
                    }
                }
        
            } // end while.

            //--------------------------------------
            // If here, we're exiting the thread.
            //--------------------------------------
    
                // Release anything in m_bimTimeline.
            while ( m_timeline_bimimap.try_pop(cur_timer, data_ptr) )
                ; 
    
                // Unlock our mutex before we exit thread.
            timer_lock.unlock();
        }

    };

};  // end of "namespace boost" declaration above.


#endif







