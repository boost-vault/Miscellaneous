
//==============================================================================================
//      LICENSE INFO
//==============================================================================================
//          Copyright John Q. Smith 2009-2011
// Distributed under the Boost Software License, Version 1.0.
//    See accompanying file LICENSE_1_0.txt or copy at:
//          http://www.boost.org/LICENSE_1_0.txt
//==============================================================================================

//==============================================================================================
//       DESCRIPTION - timer_bimimap.hpp
//==============================================================================================
// Provides the basic bi-index multi-map for use by timer_queue.hpp
//
// See http://www.boost.org/libs/timer_queue for library home page.
//==============================================================================================


#ifndef BOOST_TIMER_BIMIMAP_H
    #define BOOST_TIMER_BIMIMAP_H
    

//**********************************************************************************************
//  INCLUDES
//**********************************************************************************************

//------------- queues, maps, etc -------------------------
#include <utility>
#include <queue>
#include <map>
#include <stdarg.h>
#include <sys/time.h>
//------------- boost includes -------------------------
#include <boost/asio.hpp>
#include <boost/thread.hpp>
#include <boost/multi_index_container.hpp>
#include <boost/multi_index/member.hpp>
#include <boost/multi_index/ordered_index.hpp>
#include <boost/tuple/tuple.hpp>


using boost::multi_index_container;
using namespace boost::multi_index;


namespace boost {  // set our namespace so no conflict with other timer_queue libs.

    //**********************************************************************************************
    //**********************************************************************************************
    //  BI-MULTI-MAP
    //      A map container that keeps two indexes... one on Key1 and Key2. This is
    //      primarly for use with Timers where Key1=boost::system_time and Key2=long.
    //      Key1 is pretty obvious... Key2 is so can find and delete timers when they
    //      are no longer needed before they fire and cause an unnecessary context switch.
    //**********************************************************************************************
    //**********************************************************************************************


    template <typename T1, typename T2, typename T3>
    struct bimultimap_triple
    {
        typedef T1  first_type;
        typedef T2  second_type;
        typedef T3  third_type;

        bimultimap_triple():first(T1()),second(T2()),third(T3()){}
        bimultimap_triple(const T1& f,const T2& s, const T3& t):first(f),second(s),third(t){}

        T1      first;
        T2      second;
        T3      third;
    };

        // for use below.
    struct index1{};
    struct index2{};


    template<typename Key1,typename Key2, typename Data>
    struct bimultimap
    {
        typedef bimultimap_triple<Key1,Key2,Data> value_type;

    #if defined(BOOST_NO_POINTER_TO_MEMBER_TEMPLATE_PARAMETERS) ||\
        defined(BOOST_MSVC)&&(BOOST_MSVC<1300) ||\
        defined(BOOST_INTEL_CXX_VERSION)&&defined(_MSC_VER)&&\
               (BOOST_INTEL_CXX_VERSION<=700)

    /* see Compiler specifics: Use of member_offset for info on member<> and
     * member_offset<>
     */

        BOOST_STATIC_CONSTANT(unsigned,key1_offset=offsetof(value_type,first));
        BOOST_STATIC_CONSTANT(unsigned,key2_offset=offsetof(value_type,second));

        typedef boost::multi_index_container<
          value_type,
          indexed_by<
            ordered_non_unique<
              tag<index1>,member_offset<value_type,Key1,key1_offset> >,
            ordered_non_unique<
              tag<index2>,member_offset<value_type,Key2,key2_offset> >
          >
        > bimimap;

    #else

        typedef boost::multi_index_container<
          value_type,
          indexed_by<
            ordered_non_unique<
              tag<index1>,member<value_type,Key1,&value_type::first> >,
            ordered_non_unique<
              tag<index2>,member<value_type,Key2,&value_type::second> >
          >
        > bimimap;

    #endif

    };


    //**********************************************************************************************
    // Thread Safe Bi-Multi-Map
    //**********************************************************************************************

    template<typename Key1, typename Key2, typename Data>
    class concurrent_bimultimap
    {
    private:
        typename bimultimap<Key1, Key2, Data>::bimimap the_bimultimap;
        mutable boost::mutex the_mutex;
        boost::condition_variable the_condition_variable;

    public:
    
        typedef typename bimultimap<Key1,Key2,Data>::bimimap bimimap_type;
        typedef typename bimultimap<Key1,Key2,Data>::bimimap::value_type bimimap_value_type;
        typedef typename bimultimap<Key1,Key2,Data>::bimimap::iterator bimimap_iter;
        typedef typename bimultimap<Key1,Key2,Data>::bimimap::template index<index2>::type::iterator bimimap_key2_iter;

        void insert(Key1 const& key1, Key2 const& key2, Data const& data)
        {
            boost::mutex::scoped_lock lock(the_mutex);
        
            the_bimultimap.insert( bimimap_value_type(key1,key2,data) );
            lock.unlock();
                // Note: because we unlock above and notify below, if there are multiple threads pushing then another
                // thread could grab the queue mutex before the pop routine woken up by notify could do the pop.
                // Thus, we could get a bunch of pushes before a pop in a burst situation.
            the_condition_variable.notify_one();
        }

        long size()
        {
            boost::mutex::scoped_lock lock(the_mutex);
            return the_bimultimap.size();
        }

        bool empty() const
        {
            boost::mutex::scoped_lock lock(the_mutex);
            return the_bimultimap.empty();
        }

        bool try_pop(Key1& key1, Data& data)
        {
            boost::mutex::scoped_lock lock(the_mutex);
            if (the_bimultimap.empty())
                return false;
        
            bimimap_iter first_iter = the_bimultimap.begin();
            if (first_iter != the_bimultimap.end()) {
                key1 = first_iter->first;
                data = first_iter->third;
                the_bimultimap.erase(first_iter);
            }
            // NOTE: The iterator created above is no longer valid beause we used erase.
        
            return true;
        }

        void wait_and_pop(Key1& key1, Data& data, bool pop_it)
        {
            boost::mutex::scoped_lock lock(the_mutex);
            while(the_bimultimap.empty())
                the_condition_variable.wait(lock);

            bimimap_iter first_iter = the_bimultimap.begin();
        
            if (first_iter != the_bimultimap.end()) {
                key1 = first_iter->first;
                data = first_iter->third;
                if (pop_it)
                    the_bimultimap.erase(first_iter);
            }
            // NOTE: The iterator created above is no longer valid beause we used erase.
        }

        void wait_and_peek(Key1& key1, Data& data)
        {
            // This routine assumes someone else will do the pop.
    
            boost::mutex::scoped_lock lock(the_mutex);
            while(the_bimultimap.empty())
                the_condition_variable.wait(lock);

            bimimap_iter first_iter = the_bimultimap.begin();
            if (first_iter != the_bimultimap.end()) {
                key1 = first_iter->first;
                data = first_iter->third;
            }
            // NOTE: The iterator created above is no longer valid beause we used erase.
        }

        bool front(Key1& key1, Key2& key2, Data& data)
        {
            boost::mutex::scoped_lock lock(the_mutex);

            bimimap_iter first_iter = the_bimultimap.begin();

            if (first_iter != the_bimultimap.end()) {
                key1 = first_iter->first;
				key2 = first_iter->second;
                data = first_iter->third;
                return true;
            }
        
            return false;
        }

        bool find(Key1& key1, Data& data)
        {
            boost::mutex::scoped_lock lock(the_mutex);
        
            bimimap_iter found_it_iter = the_bimultimap.find(key1);
            if (found_it_iter != the_bimultimap.end()) {
                data = found_it_iter->third;
                return true;
            }
        
            return false;
        }
    
        bool find_key2(Key2& key2, Data& data)
        {
            boost::mutex::scoped_lock lock(the_mutex);

            bimimap_key2_iter found_it_iter = the_bimultimap.get<index2>().find(key2);
            if (found_it_iter != the_bimultimap.get<index2>().end()) {
                data = found_it_iter->third;
                return true;
            }
            else return false;
        }
    
        bool erase_key2(Key2& key2, Data& data) 
        {
            boost::mutex::scoped_lock lock(the_mutex);

                // See if there is a node that has id = key2.
            bimimap_key2_iter found_it_iter = the_bimultimap.get<index2>().find(key2);
                // If so, pass back the data and erase the node.
            if (found_it_iter != the_bimultimap.get<index2>().end() ) {
                data = found_it_iter->third; // pass the data back so originator can delete or whatever.
                the_bimultimap.get<index2>().erase(found_it_iter);  // delete the node.
                    // NOTE: The iterator created above is no longer valid beause we used erase.
                return true;
            }
        
            return false;
        }

        void erase_front()
        {
            boost::mutex::scoped_lock lock(the_mutex);
            if(the_bimultimap.empty())
                return;

            bimimap_iter first_iter = the_bimultimap.begin();

            if (first_iter != the_bimultimap.end())
                the_bimultimap.erase(first_iter);

            // NOTE: The iterator created above is no longer valid beause we used erase.
        }

        void clear()
        {
            boost::mutex::scoped_lock lock(the_mutex);
            the_bimultimap.clean();
        }

    };


};  // end of "namespace boost" declaration above.


#endif





