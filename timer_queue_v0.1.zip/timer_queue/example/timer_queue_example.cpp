

//==============================================================================================
//      LICENSE INFO
//==============================================================================================
//          Copyright John Q. Smith 2009-2011
// Distributed under the Boost Software License, Version 1.0.
//    See accompanying file LICENSE_1_0.txt or copy at:
//          http://www.boost.org/LICENSE_1_0.txt
//==============================================================================================

//==============================================================================================
//       DESCRIPTION - example.cpp
//==============================================================================================
// example.cpp is an example file included with the Timer Queue library.
// The purpose of this file is to show the basic functions of the library - adding
// timers, deleting timers, timers firing within specified windows of time.
//
// See http://www.boost.org/libs/timer_queue for library home page.
//==============================================================================================

#include "../timer_queue.hpp"

using namespace boost;


//---------------------------------------
// example_callback_data struct
//    only used to pass example data
//---------------------------------------
typedef struct example_callback_data
{
	long data1;
	long data2;
} example_callback_data;


//---------------------------------------
// example class
//    instantiates a timer_queue
//    sets the callback function then
//    sets a few timers and deletes one
//    of them.
//---------------------------------------
class example
{
private:
    timer_queue     *timer_queue_ptr;

public:
    example();
    ~example();
    
	bool            init();
    void            timer_callback(void *data_ptr, long event_type);
    bool            set_some_timers();
	void            delete_a_timer();
};

example::example()
{
        // allocate a new timer queue.
	timer_queue_ptr = new timer_queue;
}

example::~example()
{
        // our example is done, delete the time queue.
	delete timer_queue_ptr;
	timer_queue_ptr = NULL;
}

bool example::init()
{
    if (timer_queue_ptr==NULL)
        return false;

        // creates the timer thread... only call once in your program.
    if ( ! timer_queue_ptr->init() )
		return false;

        // set the timer callback to our example callback... required once but can change it at any time.
    boost::function<void(void* x, long y)> example_callback_func = boost::bind(&example::timer_callback, this, _1, _2);
    timer_queue_ptr->set_callback_func( example_callback_func );

        // everything inited ok.
	return true;
}

    // This will be called when the timer expires or is deleted so you can handle (or clean up any mem).
void example::timer_callback(void *data_ptr, long event_type)
{
	// data_ptr = whatever value you passed in when you created the timer.
	// event_type = TIMER_EVENT_FIRED or TIMER_DELETE_DATA
	//            TIMER_EVENT_FIRED = the timer went off and you are being notified.
	//            TIMER_DELETE_DATA = the timer was deleted, cleanup mem if needed.
	
	if (event_type==TIMER_EVENT_FIRED) {
		printf("A timer fired with id: %ld\n", ((example_callback_data *)data_ptr)->data1);
		free (data_ptr);  // we malloc'd it when created timer, so free it.
	}
	else if (event_type==TIMER_DELETE_DATA) {
		printf("We deleted timer with id: %ld\n", ((example_callback_data *)data_ptr)->data1);
		free (data_ptr); // we malloc'd it when created timer, so free it.
	}
}

bool example::set_some_timers()
{
       // set a timer for 1000ms from now.
	void *tmp_ptr1 = malloc( sizeof(example_callback_data) );
	((example_callback_data *)tmp_ptr1)->data1 = 1234; // not required... just so we can print it out in the callback for example.
    if ( ! timer_queue_ptr->new_timer(1000, tmp_ptr1, 1234) )
		return false;

       // set another timer for 2000ms from now.
	void *tmp_ptr2 = malloc( sizeof(example_callback_data) );
	((example_callback_data *)tmp_ptr2)->data1 = 5678; // not required... just so we can print it out in the callback for example.
    if ( ! timer_queue_ptr->new_timer(2000, tmp_ptr2, 5678) )
	    return false;
	
	return true;
}

void example::delete_a_timer()
{
        // delete the first timer so never fires.
	timer_queue_ptr->delete_timers_by_id(1234);
}

//------------------------------------------------
// main
//    instantiates the example class
//    sets timers, waits for them to fire.
//------------------------------------------------
int main(int argc, char **argv)
{
	example *example_ptr = new example;
	
	if (example_ptr==NULL)
		return -1;
		
    if ( ! example_ptr->init() )
		return -1;
		
	example_ptr->set_some_timers();
	example_ptr->delete_a_timer();
	
	sleep(2); // wait for timer to expire.
	
	printf("timer example done.\n");
	return 0;
}





