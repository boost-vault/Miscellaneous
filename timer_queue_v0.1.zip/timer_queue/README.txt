
//==============================================================================================
//      LICENSE INFO
//==============================================================================================
//          Copyright John Q. Smith 2009-2011
// Distributed under the Boost Software License, Version 1.0.
//    See accompanying file LICENSE_1_0.txt or copy at:
//          http://www.boost.org/LICENSE_1_0.txt
//==============================================================================================


timer_queue v0.1
	- Written and tested on *nix.
	- Compiled with gcc 4.0.1 and boost 1.38.0
	- Not tested on Windows at all yet.
        - example and test dirs have working code
	- documention is almost non-existent in v0.1 but short desciption
	    can be found in doc/index.html and in the header file itself.
