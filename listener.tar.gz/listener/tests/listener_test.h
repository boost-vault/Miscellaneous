#include <cppunit/TestFixture.h>
#include <cppunit/TestSuite.h>
#include <cppunit/TestCaller.h>
#include <cppunit/Test.h>

#include "listener.h"

// test Classes
class Intlistener : public listener::listener<int, int> {
	public:
		Intlistener(listener::listener_registry<int, int> & registry) : listener::listener<int, int>(registry, 0) {
		};
		
		~Intlistener() { };

		int handle(const int & num) {
			return num;
		};
};

class IntDoublerlistener : public listener::listener<int, int> {
	public:
		IntDoublerlistener(listener::listener_registry<int, int> & registry) : listener::listener<int, int>(registry, 1) {
		};

		~IntDoublerlistener() { };

		int handle(const int & num) {
			return num * 2;
		};
};

template <typename _ReturnType, typename _InputType>
class int_hash : public listener::default_hash<> {
	public:
		int operator() (const int & num) {
			return (num % 2);
		};
};

class FunctoredIntlistener : public listener::listener<int, int, int_hash> {
	public:
		FunctoredIntlistener(listener::listener_registry<int, int, int_hash> & registry) : listener::listener<int, int, int_hash>(registry, 0) { };
		~FunctoredIntlistener() { };

		int handle(const int & num) {
			return num;
		};
};

class FunctoredIntDoublerlistener : public listener::listener<int, int, int_hash> {
	public:
		FunctoredIntDoublerlistener(listener::listener_registry<int, int, int_hash> & registry) : listener::listener<int, int, int_hash>(registry, 1) {
		};

		~FunctoredIntDoublerlistener() { };

		int handle(const int & num) {
			return num * 2;
		}
};

class listenerTest : public CppUnit::TestFixture {
	public:
		void setUp();
		void tearDown();

		void testHandle();
		void testlistenerFunctor();
		void testTypedefDefault();
		void testTypedefFunctor();
		static CppUnit::Test * suite();
};
