#include "listener_test.h"

void listenerTest::setUp() {
};

void listenerTest::tearDown() {
};

void listenerTest::testHandle() {
	//Initialize a listener Registry
	//to which the listeners should register themselves.
	listener::listener_registry<int, int> registry;

	//Instantiate a listener and register it to the
	//already defined registry.
	Intlistener int_listener(registry);
	IntDoublerlistener other_int_listener(registry);

	CPPUNIT_ASSERT(registry.handle(0) == 0);
	CPPUNIT_ASSERT(registry.handle(1) == 2);
	CPPUNIT_ASSERT(registry.handle(1, 2) == 4);
};

void listenerTest::testlistenerFunctor() {
	// Initialize a listener Registry
	// to which the listeners should register themselves.
	listener::listener_registry<int, int, int_hash> registry;

	// Instantiate a listener and register it to the
	// already defined registry.
	FunctoredIntlistener int_listener(registry);
	FunctoredIntDoublerlistener other_int_listener(registry);

	CPPUNIT_ASSERT(registry.handle(0) == 0);
	CPPUNIT_ASSERT(registry.handle(1) == 2);
	CPPUNIT_ASSERT(registry.handle(1, 2) == 4);

	// the int_hash returns (int % 2) to find
	// out which handler to use.
	CPPUNIT_ASSERT(registry.handle(2) == 2);
	CPPUNIT_ASSERT(registry.handle(3) == 6);
	CPPUNIT_ASSERT(registry.handle(4) == 4);
};

CppUnit::Test * listenerTest::suite() {
	CppUnit::TestSuite * suiteOfTests = new CppUnit::TestSuite("listenerTest");
	suiteOfTests->addTest(new CppUnit::TestCaller<listenerTest>("testHandle", & listenerTest::testHandle));
	suiteOfTests->addTest(new CppUnit::TestCaller<listenerTest>("testlistenerFunctor", & listenerTest::testlistenerFunctor));
	return suiteOfTests;
};
