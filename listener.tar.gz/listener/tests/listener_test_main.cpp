#include "listener_test.h"
#include <cppunit/ui/text/TestRunner.h>

int main(int argc, char ** argv) {
	CppUnit::TextUi::TestRunner runner;
	runner.addTest(listenerTest::suite());
	runner.run();
	return EXIT_SUCCESS;
};

