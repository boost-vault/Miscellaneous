
// Copyright Dean Michael Berris 2006. Use, modification, and distribution are
// subject to the Boost Software License, Version 1.0 (See accompanying file
// LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)


#ifndef __LISTENER_H_
#define __LISTENER_H_

#include <map>

namespace listener {
	/** @author Dean Michael C. Berris <mikhailberis@free.net.ph>
	 * @brief Default hash functor.
	 *
	 * This hash functor does basically nothing --
	 * it returns whatever it gets through the
	 * conversion operator.
	 * 
	 */
	template <typename _ReturnType = int, typename _InputType = int>
	class default_hash {
		public:
			_ReturnType operator() (const _InputType & input) {
				return input;
			};
	};

	template <typename _ReturnType, typename _InputType, template <typename _ReturnType, typename _InputType> class _ComparatorFunctor>
	class listener;

	/** @author Dean Michael C. Berris <mikhailberis@free.net.ph>
	 * @brief Generic (simple) listener registry.
	 * @version 1.0.1
	 *
	 * Changes:
	 * 	1.0 -> 1.0.1
	 *	 	A hash function should be a function which takes
	 * 		in a value and returns a value of the same type.
	 * 	
	 */
	template < typename _ReturnType, typename _InputType, template < typename _ReturnType = _InputType, typename _InputType = _InputType >  class _ComparatorFunctor = default_hash >
	class listener_registry {
		public:
			/** Default constructor.
			 */
			listener_registry() { };

			/** Default destructor.
			 */
			virtual ~listener_registry() { };

			/** Registers a listener to the
			 * registry.
			 */
			virtual void register_listener(const _InputType & id, listener<_ReturnType, _InputType, _ComparatorFunctor> * listener) {
				_registry[functor(id)] = listener;
			};

			/** Calls the handle method of the
			 * registered listener.
			 */
			virtual _ReturnType handle(const _InputType & input) {
				return _registry[functor(input)]->handle(input);
			};

			virtual _ReturnType handle(const _InputType & id, const _InputType & input) {
				return _registry[functor(id)]->handle(input);
			};
			
		protected:
			std::map<_InputType, listener<_ReturnType, _InputType, _ComparatorFunctor> * > _registry;
			_ComparatorFunctor<_ReturnType, _InputType> functor;
	};

	template <typename _ReturnType, typename _InputType, template <typename _ReturnType = _ReturnType, typename _InputType = _InputType> class _ComparatorFunctor = default_hash>
	class listener {
		public:
			listener(listener_registry<_ReturnType, _InputType, _ComparatorFunctor> & registry, const _InputType & id) {
				registry.register_listener(id, this);
			};

			virtual ~listener() { };

			virtual _ReturnType handle(const _InputType &) { _ReturnType temp; return temp; };
	};

};

#endif
