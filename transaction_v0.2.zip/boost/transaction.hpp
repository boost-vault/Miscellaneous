// Library: boost::transaction
// File: transaction.hpp
// Author: DEN
// e-mail: MrMoidodir@mail.ru
// Library purpose: Provide transaction code behaviour

#if !defined (BOOST_TRANSACTION_HPP)
#define BOOST_TRANSACTION_HPP

#include <stack>
#include <vector>
#include <boost/noncopyable.hpp>
#include <boost/shared_ptr.hpp>
#include <boost/logic/tribool.hpp>

namespace boost
{

class transaction : private noncopyable // transaction is noncopyable
{
public:

    transaction()
    : m_success(false)
    {

    }

    ~transaction() // must not generate any exceptions
    {
        if (m_success) // in case of transaction success destructor cleanse transaction container
        {
            clear();
        }
        else if (!m_success) // in case of transaction failure destructor reverts all changes
        {
            roll_back();
        }
    }

    // transaction object accepter
    template <typename T>
    void begin(T& object)
    {
        m_owner_container.push(owner_interface_ptr(new owner<T>(object)));
    }

    // transaction array accepter
    template <typename T, std::size_t size>
    void begin(T (&object)[size])
    {
        for(std::size_t n = 0; n != size; ++n)
        {
            begin(object[n]);
        }
    }

    void commit()
    {
        m_success = true;
    }

    // stack-principle transaction changes reverting
    void roll_back() // must not generate any exceptions
    {
        while (!m_owner_container.empty())
        {
            m_owner_container.top()->roll_back();
            m_owner_container.pop();
        }
        m_success = tribool::indeterminate_value;
    }

private:

    // transaction object owner interface
    class owner_interface : private noncopyable
    {
    public:

        virtual ~owner_interface()
        {
        }

        virtual void roll_back() const = 0;
    };

    typedef shared_ptr<owner_interface> owner_interface_ptr;

    // transaction object owner implementation
    template <typename T>
    class owner : public owner_interface
    {
    public:

        owner(T& object)
        : m_reference(object)
        , m_value    (object)
        {
        }

        virtual void roll_back() const
        {
            m_reference = m_value;
        }

    private:

        T& m_reference;
        T  m_value;
    };

    // stack-based transaction container typedef
    typedef std::stack<owner_interface_ptr, std::vector<owner_interface_ptr> > owner_container;

    tribool m_success;

    // stack-based transaction container
    owner_container m_owner_container;

    // stack-principle transaction container cleaning
    void clear() // must not generate any exceptions
    {
        while (!m_owner_container.empty())
        {
            m_owner_container.pop();
        }
    }
};

} // namespace boost

#endif  // BOOST_TRANSACTION_HPP