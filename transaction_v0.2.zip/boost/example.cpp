// Library: boost::transaction
// File: example.cpp
// Author: DEN
// e-mail: MrMoidodir@mail.ru
// Library purpose: Provide transaction code behaviour

#include <iostream>
#include <string>
#include "transaction.hpp"

class shape
{
public:

    shape(const std::string& name, float weight);

    void show_info();

    void simple_test();
    void advanced_test();
    void more_advanced_test();

private:

    std::string m_name;
    float       m_weight;
    float       m_transform[2][2];
};

shape::shape(const std::string& name, float weight)
: m_name  (name)
, m_weight(weight)
{
    m_transform[0][0] = 1.0f;
    m_transform[0][1] = 0.0f;
    m_transform[1][0] = 0.0f;
    m_transform[1][1] = 1.0f;
}

void shape::show_info()
{
    std::cout << std::endl;
    std::cout << "I am " << m_name << std::endl;
    std::cout << "My weight is " << m_weight << std::endl;
    std::cout << "My transform matrix is [[" << m_transform[0][0] << ", "
                                             << m_transform[0][1] << "], ["
                                             << m_transform[1][0] << ", "
                                             << m_transform[1][1] << "]]" << std::endl;
}

void shape::simple_test()
{
    boost::transaction t;
    t.begin(m_name);
    t.begin(m_weight);

    m_name = "sphere";
    //throw std::runtime_error("Error!");
    m_weight = 100.0f;
    //throw std::runtime_error("Error!");

    t.commit();
}

void shape::advanced_test()
{
    boost::transaction t;
    t.begin(m_name);
    t.begin(m_weight);
    t.begin(m_transform);

    m_name = "cone";
    //throw std::runtime_error("Error!");
    m_weight = 75.0f;
    //throw std::runtime_error("Error!");
    m_transform[0][0] = 2.0f;
    m_transform[0][1] = 0.5f;
    m_transform[1][0] = 0.5f;
    m_transform[1][1] = 1.0f;
    //throw std::runtime_error("Error!");

    t.commit();
}

void shape::more_advanced_test()
{
    boost::transaction t;
    t.begin(*this);

    m_name = "pyramid";
    m_weight = 125.0f;
    m_transform[0][0] = 3.0f;
    m_transform[0][1] = 1.5f;
    m_transform[1][0] = 2.5f;
    m_transform[1][1] = 6.0f;

    t.roll_back();
}

int main()
{
    shape s("box", 50.0f);

    try
    {
        s.simple_test();
    }
    catch(const std::exception& e)
    {
        std::cerr << "We've got an exception: " << e.what() << std::endl;
    }

    try
    {
        s.advanced_test();
    }
    catch(const std::exception& e)
    {
        std::cerr << "We've got an exception: " << e.what() << std::endl;
    }

    try
    {
        s.more_advanced_test();
    }
    catch(const std::exception& e)
    {
        std::cerr << "We've got an exception: " << e.what() << std::endl;
    }

    s.show_info();

    return 0;
}