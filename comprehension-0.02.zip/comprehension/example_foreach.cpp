/* Test/example program for the comprehension library.
 *
 * Copyright (c) 2010-2011 Brent Spillner
 * Distributed under the Boost Software License, Version 1.0. (See accompanying 
 * file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
 */

#include "comprehension.hpp"
#include <iostream>
#include <vector>
#include <boost/foreach.hpp>
#include <boost/ref.hpp>
#include <boost/lambda/bind.hpp>

using namespace comprehension;


// Demonstrate use of comprehension_variable<>, range(), and BOOST_FOREACH
void basics(int max)
{
  comprehender _;
  comprehension_variable<int> i;

  std::cout << "(i)[i << 0.." << max << " by 2, i % 3 == 0]:\n";
  BOOST_FOREACH(int j, (_(i)[i <<= range(0, max + 1, 2), i % 3 == 0])) {
      std::cout << j << std::endl; 
  }
}


int stateful_iota(void)
{
  static int next = 0;
  return next++;
}


// Demonstrate use of generator functions, explicit limits on sequence length,
// the substitution of boost::ref() for comprehension_variable<>s, and sending
// the comprehension values directly to an ostream
void generators(int max)
{
 using boost::ref;
  comprehender _;
  int i, count = 0;

  std::cout << "Even numbers less than " << max << ":\n";
  std::cout << _(ref(i))(max + 1 >> 1)[i <<= call(stateful_iota), ref(i) % val_(2) == 0, ref(count) += val_(1)];
  std::cout << "Obtained a total of " << count << " results.\n";
}


int main(int argc, const char *argv[])
{
  basics(30);
  generators(15);
  return 0;
}

