#ifndef __COMPREHENSION_ITERATOR_ASSIGN_H__
#define __COMPREHENSION_ITERATOR_ASSIGN_H__

/* Copy the sequence values from a comprehension to the provided
 * output_iterator (may be an insert_iterator, front_insert_iterator, etc.)
 *
 * Copyright (c) 2010-2011 Brent Spillner
 * Distributed under the Boost Software License, Version 1.0. (See accompanying 
 * file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
 */

#include <boost/config.hpp>
#include "comprehender.hpp"

namespace comprehension {

// Replace the values after the iterator with the supplied sequence
// WARNING: user MUST ensure that the iterator is pointing into sufficient
// space to store the entire sequence, as there's no way to check the amount
// of space remaining from this code without loss of generality
// TODO: come up with a better means to identify iterators?  Turns out that
// it's easier to identify all of the things that aren't iterators, but this
// means that the return value type specification may need to be updated when
// support is added for new kinds of output sink
template < class Iterator, class Comprehension >
typename meta::return_first<Iterator,
                  typename meta::not_expr<Iterator>::type,
                  typename meta::not_container<Iterator>::type,
                  typename meta::is_comprehension<Comprehension>::type>
             ::type operator<<=(Iterator const &dest, Comprehension source)
{
  std::copy(source.begin(), source.end(), dest);
  return dest;
}


} // end namespace comprehension

/* end of __COMPREHENSION_ITERATOR_ASSIGN_H__ */
#endif
