/* Declarations of the operators supported 'natively' within a comprehension expression
 * (It is also possible to use operators defined over another family of types, e.g.
 *  those from Boost.Phoenix, when those types are implicitly convertible to
 *  boost::function objects.)
 *
 * These declarations are used to generate operator definitions in at least two places:
 * definitions of the implementing expression types in expressions.hpp, and of the
 * associated operator overloads in operators.hpp.
 *
 * Because this header will be #included'd in different contexts by at least two others,
 * it intentionally does NOT have any #include guards.
 *
 * (C) 2010-2011 by Brent Spillner
 * Distributed under the Boost Software License, Version 1.0. (See accompanying 
 * file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
 */

// Simple arithmetic and logical operations
_COMPREHENSION_BINARY_OPERATOR(and, &&)
_COMPREHENSION_BINARY_OPERATOR(or, ||)
_COMPREHENSION_BINARY_OPERATOR(add, +)
_COMPREHENSION_BINARY_OPERATOR(sub, -)
_COMPREHENSION_BINARY_OPERATOR(mul, *)
_COMPREHENSION_BINARY_OPERATOR(div, /)
_COMPREHENSION_BINARY_OPERATOR(mod, %)
_COMPREHENSION_BINARY_OPERATOR(shl, <<)
_COMPREHENSION_BINARY_OPERATOR(shr, >>)
_COMPREHENSION_BINARY_OPERATOR(bitand, &)
_COMPREHENSION_BINARY_OPERATOR(bitor, |)
_COMPREHENSION_BINARY_OPERATOR(bitxor, ^)
_COMPREHENSION_PROBLEMATIC_UNARY_OPERATOR(complement, ~)
_COMPREHENSION_UNARY_OPERATOR(not, !)
_COMPREHENSION_UNARY_OPERATOR(negate, -)
_COMPREHENSION_UNARY_OPERATOR(promote, +)
_COMPREHENSION_BINARY_OPERATOR_(eq, ==, bool)
_COMPREHENSION_BINARY_OPERATOR_(ne, !=, bool)
_COMPREHENSION_BINARY_OPERATOR_(gt, >, bool)
_COMPREHENSION_BINARY_OPERATOR_(lt, <, bool)
_COMPREHENSION_BINARY_OPERATOR_(ge, >=, bool)
_COMPREHENSION_BINARY_OPERATOR_(le, <=, bool)

// Note that remove_pointer is only a dependency when decltype is not available
_COMPREHENSION_UNARY_OPERATOR_(dereference, *,
                           typename boost::remove_pointer<SubExpr>::type)

// addressof must be an lvalue operator to ensure that a given named object always
// has the same address (i.e. reference semantics are required.)  Note that this
// will complicate taking the address of a const object (WART, could be avoided by
// implementing a new CONST_LVALUE_OPERATOR() macro pair)
_COMPREHENSION_LVALUE_OPERATOR_(addressof, &, typename SubExpr::evaluates_to *)

_COMPREHENSION_LVALUE_OPERATOR(preincrement, ++)
_COMPREHENSION_LVALUE_OPERATOR(predecrement, --)
_COMPREHENSION_POSTFIX_OPERATOR(postincrement, ++)
_COMPREHENSION_POSTFIX_OPERATOR(postdecrement, --)

// To minimize the risk of confusion, the shift-assign operators are not supported
_COMPREHENSION_ASSIGNMENT_OPERATOR(add_assign, +=)
_COMPREHENSION_ASSIGNMENT_OPERATOR(sub_assign, -=)
_COMPREHENSION_ASSIGNMENT_OPERATOR(mul_assign, *=)
_COMPREHENSION_ASSIGNMENT_OPERATOR(div_assign, /=)
_COMPREHENSION_ASSIGNMENT_OPERATOR(mod_assign, %=)
_COMPREHENSION_ASSIGNMENT_OPERATOR(bitand_assign, &=)
_COMPREHENSION_ASSIGNMENT_OPERATOR(bitor_assign, |=)
_COMPREHENSION_ASSIGNMENT_OPERATOR(bitxor_assign, ^=)

/* End of supported_operators.hpp - #include guards intentionally not provided */

