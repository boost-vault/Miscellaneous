#ifndef __COMPREHENDER_H__
#define __COMPREHENDER_H__

/* Type providing the value generation backend for an arbitrary comprehension.
 * User code should explicitly instantiate only the 'comprehender' type.
 *
 * Copyright (c) 2010-2011 Brent Spillner
 * Distributed under the Boost Software License, Version 1.0. (See accompanying 
 * file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
 */

#include <boost/config.hpp>
#include <boost/range/iterator.hpp>
#include "tuples.hpp"

// The following are needed only for the corresponding cast operators and
// not really a dependency...
#include <vector>
#include <list>
#include <deque>

namespace comprehension {

// Iterator adapter for the sequence of comprehension results...
// Points to the end of the sequence iff 'succeeded' is false
// WART: this design requires that value_type be default constructible
template <class Comprehension>
struct comprehension_iterator {
  typedef typename Comprehension::output_type value_type;
  typedef std::input_iterator_tag iterator_category;
  typedef value_type &reference;
  typedef value_type *pointer;
  typedef void difference_type;
  Comprehension comprehension;
  bool succeeded;
  value_type value;
  size_t sequence_num;

  // Create an iterator pointing to the beginning (if at_end == false) or
  // end (if at_end == true) of the given sequence
  comprehension_iterator(Comprehension const &comp, bool at_end = false)
          : comprehension(comp), sequence_num(0) {
       succeeded = !at_end && comprehension.generate_first(value);
  }

  // Value extraction/assignment
  value_type const & operator*() const { return value; }
  value_type       & operator*()       { return value; }

  // Preincrement advance
  comprehension_iterator<Comprehension> & operator++() {
      if (succeeded && (succeeded = comprehension.generate_next(value))) // NOLINT
          sequence_num++;
      return *this;
  }

  // Post-increment version
  comprehension_iterator<Comprehension> operator++(int _unused) {
      comprehension_iterator<Comprehension> rv(*this);
      if (succeeded && (succeeded = comprehension.generate_next(value))) // NOLINT
          sequence_num++;
      return rv;
  }

  // Iterators are equivalent if they both point to the end of the sequence,
  // or both point to the n'th value for some n
  bool operator==(comprehension_iterator<Comprehension> const &other) const {
      return succeeded == other.succeeded
                 && (!succeeded || sequence_num == other.sequence_num);
  }

  bool operator!=(comprehension_iterator<Comprehension> const &other) const {
      return !(*this == other);
  }
};


// Workhorse comprehension engine... generates a sequence of output values
// for use in an appropriate collection assignment operator
template <class ReturnValue, class Criteria>
struct concrete_comprehension {
  ReturnValue rvspec;
  Criteria filter;
  size_t limit;
  size_t remaining;
  typedef concrete_comprehension<ReturnValue, Criteria> compr_self_type;
  typedef typename ReturnValue::evaluates_to output_type;

  concrete_comprehension(ReturnValue const &rv, Criteria const &crit,
                        size_t max_items)
          : rvspec(rv), filter(crit), limit(max_items) { remaining = 0; }

  bool generate_first(output_type &rv) {
      if (!limit || !filter.evaluate())
          return false;
      rv = rvspec.evaluate();
      remaining = (limit == ~0) ? limit : limit - 1;
      return true;
  }

  bool generate_next(output_type &rv) {
      if (!remaining || !filter.next())
          return false;
      rv = rvspec.evaluate();
      if (remaining != ~0)
          remaining--;
      return true;
  }

  // Iterator-style access
  comprehension_iterator<compr_self_type> begin(void) const {
      return comprehension_iterator<compr_self_type>(*this);
  }

  comprehension_iterator<compr_self_type> end(void) const {
      return comprehension_iterator<compr_self_type>(*this, true);
  }

  // Create containers filled with the value sequence represented by the comprehension.
  // Useful for casting to container types to support assignment via operator=.
  // Inefficient unless the compiler provides reasonable copy ellision
  operator std::vector<output_type> () const {
      return std::vector<output_type>(begin(), end());
  }

  operator std::list<output_type> () const {
      return std::list<output_type>(begin(), end());
  }

  operator std::deque<output_type> () const {
      return std::deque<output_type>(begin(), end());
  }
};


// Intermediate comprehension type: provides an optional operator() to limit
// the maximum number of values that will be generated, and an operator[] that
// returns a concrete_comprehension to actually evaluate the provided criteria
template <class ReturnValue>
struct meta_comprehender {
  ReturnValue rvspec;
  size_t limit;
  typedef typename ReturnValue::evaluates_to output_type;

  meta_comprehender(ReturnValue const &rv, size_t max_items = ~0)
          : rvspec(rv), limit(max_items) { /* nothing */ }

  // Limit the number of items that may be returned
  meta_comprehender<ReturnValue> & operator() (size_t new_limit) {
      limit = new_limit;
      return *this;
  }

  // Return a comprehension engine to process the given criteria
  template <class Criteria>
  concrete_comprehension<ReturnValue, Criteria> operator[](Criteria const &crit) const {
      return concrete_comprehension<ReturnValue, Criteria>(rvspec, crit, limit);
  }
};


// The basic comprehension type: provides an operator() (would be nice if it
// could be static...) that takes a return value tuple specification and
// returns an appropriate meta_comprehender
struct comprehender {
  template <class Expr>
      meta_comprehender<typename meta::to_expr<Expr>::type>
      operator()(Expr const &e) const {
      return meta_comprehender<typename meta::to_expr<Expr>::type>(e);
  }

  template <class Expr1, class Expr2>
      meta_comprehender< expr_tuple2<Expr1, Expr2> >
      operator()(Expr1 const &e1, Expr2 const &e2) const {
          return meta_comprehender< expr_tuple2<Expr1, Expr2> >
                     (make_tuple(e1, e2));
  }

  template <class Expr1, class Expr2, class Expr3>
      meta_comprehender< expr_tuple3<Expr1, Expr2, Expr3> >
      operator()(Expr1 const &e1, Expr2 const &e2, Expr3 const &e3) const {
          return meta_comprehender< expr_tuple3<Expr1, Expr2, Expr3> >
                     (make_tuple(e1, e2, e3));
  }
};

} // end namespace comprehension


// Adapt concrete_comprehension<> to function as a boost::range
namespace boost {
 using comprehension::concrete_comprehension;
 using comprehension::comprehension_iterator;

// specialize range_mutable_iterator and range_const_iterator in namespace boost
template < class RetVal, class Crit >
struct range_mutable_iterator< concrete_comprehension<RetVal, Crit> > {
    typedef comprehension_iterator< concrete_comprehension<RetVal, Crit> > type;
};

template < class RetVal, class Crit >
struct range_const_iterator< concrete_comprehension<RetVal, Crit> > {
    typedef comprehension_iterator< concrete_comprehension<RetVal, Crit> > type;
};

} // end namespace boost

/* end of __COMPREHENDER_H__ */
#endif
