#ifndef __COMPREHENSION_WORKAROUNDS_H__
#define __COMPREHENSION_WORKAROUNDS_H__

/* Support for buggy or less-than-fully-functional compilers.
 *
 * Copyright (c) 2010-2011 Brent Spillner
 * Distributed under the Boost Software License, Version 1.0. (See accompanying 
 * file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
 */

#include <boost/config.hpp>

// Depend on the Boost.Typeof library if necessary, unless explicitly overridden
// (e.g. via -DCOMPREHENSION_USE_BOOST_TYPEOF=0 in the compilation command.)
// NOTE: BOOST_TYPEOF() doesn't work well with the Intel C++ compiler unless
// -std=c++0x is passed as a compilation option.
#if !defined(BOOST_HAS_DECLTYPE) && !defined(COMPREHENSION_USE_BOOST_TYPEOF)
  #define COMPREHENSION_USE_BOOST_TYPEOF 1
#endif

// GCC issue # C++/47068 (ICE on decltype(~ expr))
#if defined(BOOST_HAS_DECLTYPE) && (__GNUC__ < 4 || (__GNUC__ == 4 && __GNUC_MINOR__ < 6))
  #define WORKAROUND_DECLTYPE_UNARY_OP_BUGS 1
#endif

/* end of __COMPREHENSION_WORKAROUNDS_H__ */
#endif
