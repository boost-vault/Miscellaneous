#ifndef __COMPREHENSION_IOSTREAM_SUPPORT_H__
#define __COMPREHENSION_IOSTREAM_SUPPORT_H__

/* Overload the << and >> operators to work properly with iostreams,
 * for people who like that kind of thing.
 *
 * Copyright (c) 2010-2011 Brent Spillner
 * Distributed under the Boost Software License, Version 1.0. (See accompanying 
 * file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
 */

#include <boost/config.hpp>
#include <iostream>
#include "expressions.hpp"

#define _COMPREHENSION_OUTPUT_SEPARATOR        ' '


// Copy the output of a comprehension expression to an ostream
template < class Expression >
typename comprehension::meta::return_first<std::ostream,
                            typename comprehension::meta::is_expr<Expression>::type>
             ::type & operator<<(std::ostream &stream, Expression const &expr)
{
  return stream << expr.evaluate();
}


// Read a value from an istream into a comprehension_variable<> or similar type
template < class Variable >
typename comprehension::meta::return_first<std::istream,
                 typename comprehension::meta::assignable_expr<Variable>::type>
             ::type & operator>>(std::istream &stream, Variable &var)
{
  return stream >> var.access();
}


// Write the sequence of values represented by a comprehension to an ostream,
// with spaces a separators
// WART: this requires the output values to be of a default-constructible type
template < class Comprehension >
typename comprehension::meta::return_first<std::ostream,
                 typename comprehension::meta::is_comprehension<Comprehension>::type>
             ::type & operator<<(std::ostream &stream, Comprehension source)
{
  typename Comprehension::output_type result;

  if (source.generate_first(result)) {
      stream << result;
      while (source.generate_next(result))
          stream << _COMPREHENSION_OUTPUT_SEPARATOR << result;
  }

  return stream;
}


/* end of __COMPREHENSION_IOSTREAM_SUPPORT_H__ */
#endif
