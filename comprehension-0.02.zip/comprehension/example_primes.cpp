/* Test/example program for the comprehension library.
 *
 * Copyright (c) 2010-2011 Brent Spillner
 * Distributed under the Boost Software License, Version 1.0. (See accompanying 
 * file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
 */

#include "comprehension.hpp"
#include <iostream>
#include <vector>
#include <boost/foreach.hpp>
#include <boost/ref.hpp>
#include <boost/lambda/bind.hpp>

using namespace comprehension;


// Compute x^n modulo m
unsigned long expmod(unsigned long _x, unsigned long n, unsigned long m)
{
  // If you don't have long long support, you may have to content yourself
  // with five Mersenne primes on a 32-bit machine
  unsigned long long t = 1, x = _x;

  while (n > 0) {
      while (!(n & 1)) {
          n >>= 1;
          x *= x;
          x %= m;
      }
      n--;
      t *= x;
      t %= m;
  }

  return t;
}


// Test integers for primality quickly but with high confidence (Miller-Rabin method)
bool is_prime(unsigned long n)
{
#define MILLER_ITERATIONS 6
  unsigned long a, d, la;
  int i, j, s;

  if (!(n & 1))
      return (n == 2);
  if (n == 3)
       return true;

  s = 0;
  d = n - 1;
  while (!(d & 1))
      s++, d >>= 1;

  for (i = 0; i < MILLER_ITERATIONS; i++) {
      a = expmod(random() % n, d, n);
      if (a == 1)
          continue;
      for (j = 1; j <= s && a != 1; j++) {
          la = a;
          a = expmod(a, 2, n);
      }
      if (la != (n - 1))
          return false;
  }

  return true;
}


// Demonstrate assignment of value sequences to collections (two of many ways) and
// the use of function objects as test predicates within the comprehension
void primes(int sqrt_max)
{
 using boost::ref;
 using boost::lambda::bind;
  comprehender _;
  comprehension_variable<unsigned long> i, j, p, m;
  std::vector<unsigned long> nonprimes, primes, mersenne_primes;

  std::cout << "Primes < " << sqrt_max * sqrt_max << ":\n";
  nonprimes += _(j)[i <<= range(2, sqrt_max), j <<= range(2 * i, sqrt_max * sqrt_max, i)];
  boost::function<std::vector<unsigned long>::const_iterator ()> is_composite
       = bind(std::find<std::vector<unsigned long>::const_iterator, unsigned long>, nonprimes.begin(), nonprimes.end(), ref(p));
  primes = _(p)[p <<= range(2, sqrt_max * sqrt_max), call(is_composite) == nonprimes.end()];
  BOOST_FOREACH(unsigned long x, primes) { std::cout << x << std::endl; }

  std::cout << "First eight Mersenne primes:\n";
  mersenne_primes += _(m)(8)[p <<= primes, m = (1 << p) - 1, apply(is_prime, m)];
  BOOST_FOREACH(unsigned long x, mersenne_primes) { std::cout << x << std::endl; }
}


int main(int argc, const char *argv[])
{
  primes(7);
  return 0;
}

