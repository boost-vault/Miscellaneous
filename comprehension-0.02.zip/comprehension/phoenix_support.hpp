#ifndef __COMPREHENSION_PHOENIX_SUPPORT_H__
#define __COMPREHENSION_PHOENIX_SUPPORT_H__

/* Allow interoperability with function objects creted via the Phoenix library
 * by providing traits specializations suitable for use with functor.hpp
 *
 * Copyright (c) 2010-2011 Brent Spillner
 * Distributed under the Boost Software License, Version 1.0. (See accompanying 
 * file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
 */

#include <boost/config.hpp>
#include <boost/spirit/home/phoenix.hpp>
#include "functor.hpp"

namespace comprehension {

namespace meta {

// Minimize operator overload ambiguity by favoring the Phoenix definition
// when the LHS of a binary operator is a Boost.Phoenix actor
template <class Nested>
struct override_ok< boost::phoenix::actor<Nested> > { };


// Metafunction for which ::result_type is the return value of a Phoenix expression
// iff that expression supports nullary invocation (not_nullary == false)
template <class PhoenixExpr, bool not_nullary> struct phx_nullary_result { };

template <class PhoenixExpr> struct phx_nullary_result<PhoenixExpr, false> {
  typedef typename boost::phoenix::actor<PhoenixExpr>::nullary_result result_type;
};

template <typename PhoenixExpr>
struct nullary_traits<boost::phoenix::actor<PhoenixExpr> > 
    : public meta::phx_nullary_result<PhoenixExpr,
                                      PhoenixExpr::no_nullary::value> { };

// Deduce the return type of a potentially polymorphic Phoenix function object
template <typename PhoenixExpr, typename ArgType>
struct unary_traits<boost::phoenix::actor<PhoenixExpr>, ArgType> {
  typedef ArgType argument_type;
  typedef typename boost::phoenix::eval_result< PhoenixExpr,
               boost::phoenix::basic_environment<argument_type> >::type result_type;
};


// Allow use of boost::phoenix::ref() as an argument to apply()
template <class Value>
struct to_expr< boost::phoenix::actor<boost::phoenix::reference<Value> > > {
  typedef nullary_functor<Value> type;
};

} // end namespace meta

} // end namespace comprehension

/* end of __COMPREHENSION_PHOENIX_SUPPORT_H__ */
#endif
