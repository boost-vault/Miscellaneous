/******************************************************************************
 *                         Copyright 2008 Joel FALCOU
 *          Distributed under the Boost Software License, Version 1.0.
 *                 See accompanying file LICENSE.txt or copy at
 *                     http://www.boost.org/LICENSE_1_0.txt
 ******************************************************************************/
#ifndef BOOST_IDENTIFICATION_DETAILS_REGISTER_REGISTER_CUSTOM_HPP_INCLUDED
#define BOOST_IDENTIFICATION_DETAILS_REGISTER_REGISTER_CUSTOM_HPP_INCLUDED

#include <boost/preprocessor/cat.hpp>
#include <boost/preprocessor/seq/size.hpp>
#include <boost/preprocessor/stringize.hpp>
#include <boost/preprocessor/control/if.hpp>
#include <boost/preprocessor/seq/for_each.hpp>
#include <boost/preprocessor/repetition/enum.hpp>
#include <boost/preprocessor/comparison/equal.hpp>
#include <boost/preprocessor/repetition/enum_params.hpp>
#include <boost/preprocessor/repetition/repeat_from_to.hpp>

////////////////////////////////////////////////////////////////////////////////
// internal SHORT_SEQ selector
////////////////////////////////////////////////////////////////////////////////
#define BOOST_ID_SHORT_SEQ_class(n)     build<BOOST_PP_CAT(T,n)>(os,base); base.clear();
#define BOOST_ID_SHORT_SEQ_typename(n)  build<BOOST_PP_CAT(T,n)>(os,base); base.clear();

#define BOOST_ID_SHORT_SEQ_size_t(n) os << BOOST_PP_CAT(T,n);
#define BOOST_ID_SHORT_SEQ_long(n)   os << BOOST_PP_CAT(T,n);
#define BOOST_ID_SHORT_SEQ_int(n)    os << BOOST_PP_CAT(T,n);
#define BOOST_ID_SHORT_SEQ_bool(n)   os << BOOST_PP_CAT(T,n);

////////////////////////////////////////////////////////////////////////////////
// SHORT_SEQ macro/
////////////////////////////////////////////////////////////////////////////////
#define BOOST_ID_SHORT_SEQ(n,L)                           \
BOOST_PP_CAT(BOOST_ID_SHORT_SEQ_,BOOST_PP_SEQ_HEAD(L))(n) \
/**/

////////////////////////////////////////////////////////////////////////////////
// Iterate over argument macros
////////////////////////////////////////////////////////////////////////////////
#define BOOST_ID_TPL_STRING(z, n, text)                       \
os << ","; BOOST_ID_SHORT_SEQ(n,(BOOST_PP_SEQ_ELEM(n,text)))  \
/**/

////////////////////////////////////////////////////////////////////////////////
// Generates all strings needed for N template arguments
////////////////////////////////////////////////////////////////////////////////
#define BOOST_ID_LONG_SEQ(n,L) BOOST_ID_SHORT_SEQ(n,L)                        \
                               BOOST_PP_REPEAT_FROM_TO(1                      \
                                                      ,BOOST_PP_SEQ_SIZE(L)   \
                                                      ,BOOST_ID_TPL_STRING,L  \
                                                      )                       \
/**/

////////////////////////////////////////////////////////////////////////////////
// Generates template arguments and template parameters
////////////////////////////////////////////////////////////////////////////////
#define BOOST_ID_DECL(z, n, text)      BOOST_PP_CAT(text,n)
#define BOOST_ID_LIST_DECL(z, n, text) BOOST_PP_SEQ_ELEM(n,text) T##n

////////////////////////////////////////////////////////////////////////////////
/// @brief Register a complex template type into the identification system
/// For registering a template type whose arguments are either types or integral
/// values, BOOST_ID_REGISTER_CUSTOM_ID use the fully qualified type name followed
/// by a Boost::Preprocessor sequence of its template arguments type.
////////////////////////////////////////////////////////////////////////////////
#define BOOST_ID_REGISTER_CUSTOM_TEMPLATE(Type,Seq)             \
namespace boost                                                 \
{                                                               \
  namespace identification                                      \
  {                                                             \
    template<BOOST_PP_ENUM( BOOST_PP_SEQ_SIZE(Seq)              \
                          , BOOST_ID_LIST_DECL                  \
                          , Seq                                 \
                          )                                     \
            >                                                   \
    struct type_name< Type<BOOST_PP_ENUM(BOOST_PP_SEQ_SIZE(Seq) \
                                  ,BOOST_ID_DECL                \
                                  ,T                            \
                                  )                             \
                          >                                     \
                    >                                           \
    {                                                           \
      static string_t Name()                                    \
      {                                                         \
        string_t base;                                          \
        std::ostringstream os;                                  \
        os << string_t(BOOST_PP_STRINGIZE(Type));               \
        os << "<";                                              \
        BOOST_PP_IF( BOOST_PP_EQUAL(BOOST_PP_SEQ_SIZE(Seq),1)   \
                                   ,BOOST_ID_SHORT_SEQ          \
                                   ,BOOST_ID_LONG_SEQ           \
                                   )(0,Seq)                     \
        os << ">";                                              \
        return os.str();                                        \
      }                                                         \
    };                                                          \
  }                                                             \
}                                                               \
/**/

#endif
