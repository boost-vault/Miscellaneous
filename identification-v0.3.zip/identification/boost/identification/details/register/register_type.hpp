/******************************************************************************
 *                         Copyright 2008 Joel FALCOU
 *          Distributed under the Boost Software License, Version 1.0.
 *                 See accompanying file LICENSE.txt or copy at
 *                     http://www.boost.org/LICENSE_1_0.txt
 ******************************************************************************/
#ifndef BOOST_IDENTIFICATION_DETAILS_REGISTER_REGISTER_TYPE_HPP_INCLUDED
#define BOOST_IDENTIFICATION_DETAILS_REGISTER_REGISTER_TYPE_HPP_INCLUDED

////////////////////////////////////////////////////////////////////////////////
/// @file
/// @brief Concrete type registration
////////////////////////////////////////////////////////////////////////////////
#include <boost/preprocessor/stringize.hpp>
#include <boost/identification/details/config.hpp>

namespace boost
{
  namespace identification
  {
    template<class T> struct type_name
    {
      static string_t Name() { return string_t("?"); }
    };
  }
}

////////////////////////////////////////////////////////////////////////////////
/// @brief Register concrete fully-qualified type in the identification system
////////////////////////////////////////////////////////////////////////////////
#define BOOST_ID_REGISTER(T)                                              \
namespace boost                                                           \
{                                                                         \
  namespace identification                                                \
  {                                                                       \
    template<> struct type_name<T>                                        \
    {                                                                     \
      static string_t Name() { return string_t(BOOST_PP_STRINGIZE(T)); }  \
    };                                                                    \
  }                                                                       \
}                                                                         \
/**/

#endif
