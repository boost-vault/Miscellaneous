/******************************************************************************
 *                         Copyright 2008 Joel FALCOU
 *          Distributed under the Boost Software License, Version 1.0.
 *                 See accompanying file LICENSE.txt or copy at
 *                     http://www.boost.org/LICENSE_1_0.txt
 ******************************************************************************/
#ifndef BOOST_IDENTIFICATION_DETAILS_REGISTER_REGISTER_TEMPLATE_HPP_INCLUDED
#define BOOST_IDENTIFICATION_DETAILS_REGISTER_REGISTER_TEMPLATE_HPP_INCLUDED

#include <boost/preprocessor/stringize.hpp>
#include <boost/preprocessor/repetition/enum_params.hpp>
#include <boost/preprocessor/repetition/repeat_from_to.hpp>

////////////////////////////////////////////////////////////////////////////////
// Generates string from the Nth template parameters
////////////////////////////////////////////////////////////////////////////////
#define BOOST_ID_MACRO1(z,n,t)                              \
os << ","; build<BOOST_PP_CAT(A,n)>(os,base); base.clear(); \
/**/

////////////////////////////////////////////////////////////////////////////////
/// This macro registers any tempalte class which template arguments are all
/// class or typename.
////////////////////////////////////////////////////////////////////////////////
#define BOOST_ID_REGISTER_TEMPLATE(Type,n)              \
namespace boost                                         \
{                                                       \
  namespace identification                              \
  {                                                     \
    template< BOOST_PP_ENUM_PARAMS(n,class A) >         \
    struct type_name< Type<BOOST_PP_ENUM_PARAMS(n,A)> > \
    {                                                   \
      static string_t Name()                            \
      {                                                 \
        string_t base;                                  \
        std::ostringstream os;                          \
        os << string_t(BOOST_PP_STRINGIZE(Type));       \
        os << "< ";                                     \
        build<A0>(os,base); base.clear();               \
        BOOST_PP_REPEAT_FROM_TO(1,n,BOOST_ID_MACRO1,~)  \
        os << " >";                                     \
        return os.str();                                \
      }                                                 \
    };                                                  \
  }                                                     \
}                                                       \
/**/

#endif
