/******************************************************************************
 *                         Copyright 2008 Joel FALCOU
 *          Distributed under the Boost Software License, Version 1.0.
 *                 See accompanying file LICENSE.txt or copy at
 *                     http://www.boost.org/LICENSE_1_0.txt
 ******************************************************************************/
#ifndef BOOST_IDENTIFICATION_DETAILS_CONFIG_HPP_INCLUDED
#define BOOST_IDENTIFICATION_DETAILS_CONFIG_HPP_INCLUDED

////////////////////////////////////////////////////////////////////////////////
/// @file
/// @brief Configuration header for identification display
////////////////////////////////////////////////////////////////////////////////
#include <sstream>
#include <string>

namespace boost
{
  namespace identification
  {
    ////////////////////////////////////////////////////////////////////////////
    /// Inner types used for string and string streams manipulations
    /// Those *may* change to accomodate exotic platform so they are actually
    /// typedef'ed here for later editing purpose
    /// TODO : make this user-definable
    ////////////////////////////////////////////////////////////////////////////
    typedef std::ostringstream  stream_t;
    typedef std::string         string_t;
  }
}

#endif
