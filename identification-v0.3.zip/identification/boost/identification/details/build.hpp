/******************************************************************************
 *                         Copyright 2008 Joel FALCOU
 *          Distributed under the Boost Software License, Version 1.0.
 *                 See accompanying file LICENSE.txt or copy at
 *                     http://www.boost.org/LICENSE_1_0.txt
 ******************************************************************************/
#ifndef BOOST_IDENTIFICATION_DETAILS_BUILD_HPP_INCLUDED
#define BOOST_IDENTIFICATION_DETAILS_BUILD_HPP_INCLUDED

#include <boost/type_traits/is_array.hpp>
#include <boost/type_traits/is_reference.hpp>
#include <boost/type_traits/is_function.hpp>
#include <boost/type_traits/is_member_function_pointer.hpp>
#include <boost/type_traits/is_member_object_pointer.hpp>
#include <boost/type_traits/is_pointer.hpp>

namespace boost
{
  namespace identification
  {
    template<class T,class Stream> static inline
    void build( Stream& os, string_t& ptrstr );
  }
}

#include <boost/identification/details/builtin.hpp>
#include <boost/identification/details/build/fundamental.hpp>
#include <boost/identification/details/build/array.hpp>
#include <boost/identification/details/build/reference.hpp>
#include <boost/identification/details/build/pointer.hpp>
#include <boost/identification/details/build/function.hpp>
#include <boost/identification/details/build/member_object.hpp>
#include <boost/identification/details/build/member_function.hpp>

namespace boost
{
  namespace identification
  {
    ////////////////////////////////////////////////////////////////////////////
    /// @brief Main type string building function
    /// build split up types into independant traits and use tag dispatch to
    /// call the appropriate overload
    ////////////////////////////////////////////////////////////////////////////
    template<class T,class Stream> static inline
    void build( Stream& os, string_t& ptrstr )
    {
      build<T>( os,
                typename boost::is_array<T>::type(),
                typename boost::is_reference<T>::type(),
                typename boost::is_function<T>::type(),
                typename boost::is_member_function_pointer<T>::type(),
                typename boost::is_member_object_pointer<T>::type(),
                typename boost::is_pointer<T>::type(),
                ptrstr
              );
    }
  }
}

#endif
