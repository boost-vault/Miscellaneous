/******************************************************************************
 *                         Copyright 2008 Joel FALCOU
 *          Distributed under the Boost Software License, Version 1.0.
 *                 See accompanying file LICENSE.txt or copy at
 *                     http://www.boost.org/LICENSE_1_0.txt
 ******************************************************************************/
#ifndef BOOST_IDENTIFICATION_DETAILS_BUILTIN_HPP_INCLUDED
#define BOOST_IDENTIFICATION_DETAILS_BUILTIN_HPP_INCLUDED

////////////////////////////////////////////////////////////////////////////////
/// @file
/// @brief Register built-in types into boost::identification
////////////////////////////////////////////////////////////////////////////////
#include <boost/identification/details/register/register_type.hpp>

BOOST_ID_REGISTER(void)
BOOST_ID_REGISTER(bool)

BOOST_ID_REGISTER(char)
BOOST_ID_REGISTER(signed char)
BOOST_ID_REGISTER(signed short)
BOOST_ID_REGISTER(signed int)
BOOST_ID_REGISTER(signed long)

BOOST_ID_REGISTER(unsigned char)
BOOST_ID_REGISTER(unsigned short)
BOOST_ID_REGISTER(unsigned int)
BOOST_ID_REGISTER(unsigned long)

BOOST_ID_REGISTER(float)
BOOST_ID_REGISTER(double)
BOOST_ID_REGISTER(long double)

#if defined(BOOST_HAS_LONG_LONG)
BOOST_ID_REGISTER(long long)
#endif

#endif
