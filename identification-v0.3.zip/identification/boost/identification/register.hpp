/******************************************************************************
 *                         Copyright 2008 Joel FALCOU
 *          Distributed under the Boost Software License, Version 1.0.
 *                 See accompanying file LICENSE.txt or copy at
 *                     http://www.boost.org/LICENSE_1_0.txt
 ******************************************************************************/
#ifndef BOOST_IDENTIFICATION_REGISTER_HPP_INCLUDED
#define BOOST_IDENTIFICATION_REGISTER_HPP_INCLUDED

////////////////////////////////////////////////////////////////////////////////
/// @brief Type registration
////////////////////////////////////////////////////////////////////////////////
#include <boost/identification/details/register/register_type.hpp>
#include <boost/identification/details/register/register_template.hpp>
#include <boost/identification/details/register/register_custom.hpp>

#endif

