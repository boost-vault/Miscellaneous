/******************************************************************************
 *                         Copyright 2008 Joel FALCOU
 *          Distributed under the Boost Software License, Version 1.0.
 *                 See accompanying file LICENSE.txt or copy at
 *                     http://www.boost.org/LICENSE_1_0.txt
 ******************************************************************************/
#ifndef BOOST_IDENTIFICATION_TYPE_ID_HPP_INCLUDED
#define BOOST_IDENTIFICATION_TYPE_ID_HPP_INCLUDED

////////////////////////////////////////////////////////////////////////////////
/// @file
/// @brief Type identification function
////////////////////////////////////////////////////////////////////////////////
#include <boost/identification/details/config.hpp>
#include <boost/identification/details/build.hpp>
#include <boost/identification/details/builtin.hpp>

namespace boost
{
  namespace identification
  {
    ////////////////////////////////////////////////////////////////////////////
    /// Return a string containing the human readable, fully qualified name of
    /// any type T passed as template argument.
    ////////////////////////////////////////////////////////////////////////////
    template<class T>
    inline identification::string_t type_id()
    {
      string_t base;
      stream_t str;
      build<T>(str,base);
      return str.str();
    }

    ////////////////////////////////////////////////////////////////////////////
    /// Return a string containing the human readable fully qualified name of
    /// its argument type
    ////////////////////////////////////////////////////////////////////////////
    template<class T>
    inline identification::string_t type_id(const T&) { return type_id<T>(); }
  }

  using identification::type_id;
}
#endif
