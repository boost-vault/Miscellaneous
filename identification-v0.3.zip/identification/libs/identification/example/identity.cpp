#include <vector>
#include <iostream>
#include <iterator>
#include <algorithm>
#include <boost/identification.hpp>

using namespace std;
//----------------------------------------------------------------------------//
// In this sample, we instanciate various template class that add the type ID
// of their tempalte argument into a global vector of strings. At the end of
// the programms, the instanciated list is displayed.
//----------------------------------------------------------------------------//
vector<string> list_of_types;

//----------------------------------------------------------------------------//
// some_class is only here to build some identity<T>
//----------------------------------------------------------------------------//
template<class T> class some_class
{
  public:
  some_class()
  {
    list_of_types.push_back(mName.name());
  }

  private:

  // identity<T> caches the string describing its template parameters
  // so it can be retrieved without recomputing from scratch
  boost::identity<T> mName;
};

template<class T> static inline void g()
{
  some_class<T*> x;
}

static inline void f()
{
  some_class<volatile long**[]> x;
  g<void>();
}

int main(int, char* [])
{
  some_class<int**> a;
  some_class<const double&> b;
  some_class<long(int,char,short)> c;

  f();
  g<long*>();

  copy( list_of_types.begin()
      , list_of_types.end()
      , ostream_iterator<string>(cout, "\n")
      );

  return 0;
}
