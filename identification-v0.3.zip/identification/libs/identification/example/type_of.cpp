#include <iostream>
#include <boost/identification.hpp>

using namespace std;

int main(int, char* [])
{
  // type_of returns a sring containing a type identification
  cout <<"type_of<T> sample : " << endl;
  cout << boost::type_of<void>() << endl;
  cout << boost::type_of<volatile bool**&>() << endl;
  cout << boost::type_of<const int*[][4]>() << endl;
  cout << endl;
  // type_of can also takes an instance of a given type
  float tab[4][4];

  cout <<"type_of(t) sample : " << endl;
  cout << boost::type_of(tab) << endl;
  cout << boost::type_of(tab[1]) << endl;
  cout << boost::type_of(tab[1][1]) << endl;
  cout << boost::type_of(&tab[0][0]) << endl;
  cout << endl;

  cout << "main is of type : " << boost::type_of(main) << endl;

  return 0;
}

