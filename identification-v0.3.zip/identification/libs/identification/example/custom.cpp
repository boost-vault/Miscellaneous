#include <iostream>
#include <vector>
#include <list>
#include <boost/array.hpp>
#include <boost/mpl/int.hpp>
#include <boost/identification.hpp>

using namespace std;

//----------------------------------------------------------------------------//
// In this sample, we register some external type into boost/identification.
// All registration are done at global scope with fully-qualified type names
//----------------------------------------------------------------------------//
struct foo
{
  void bar( const int&, const string& ) {}
};

enum direction { up,down,left,right,forward,backward };
//----------------------------------------------------------------------------//
// Registration of a custom, non-template type
//----------------------------------------------------------------------------//
BOOST_IDENTIFICATION_TYPE_ID(foo)
BOOST_IDENTIFICATION_TYPE_ID(string)
BOOST_IDENTIFICATION_TYPE_ID(direction)

//----------------------------------------------------------------------------//
// Registration of a custom template type
//----------------------------------------------------------------------------//
BOOST_IDENTIFICATION_TEMPLATE_TYPE_ID(vector,2)
BOOST_IDENTIFICATION_TEMPLATE_TYPE_ID(allocator,1)
BOOST_IDENTIFICATION_TEMPLATE_TYPE_ID(boost::identity,1)

//----------------------------------------------------------------------------//
// Registration of a custom template type with non-type arguments
//----------------------------------------------------------------------------//
BOOST_IDENTIFICATION_CUSTOM_TEMPLATE_TYPE_ID( boost::array,(class)(size_t))
BOOST_IDENTIFICATION_CUSTOM_TEMPLATE_TYPE_ID( boost::mpl::int_, (int) )

int main(int, char* [])
{
  cout << boost::type_of<foo>() << endl;
  cout << boost::type_of(&foo::bar) << endl;
  cout << boost::type_of(forward) << endl;

  // type identitifcation is recursively defined on tempalte types
  vector< string* > v;
  cout << boost::type_of(v) << endl;

  // Complex types description
  boost::identity< boost::identity< boost::array<boost::mpl::int_<4>,5> > > x;
  cout << x.name() << endl;

  // A unregistered type appears as "?"
  cout << boost::type_of< list<int> >() << endl;

  return 0;
}
