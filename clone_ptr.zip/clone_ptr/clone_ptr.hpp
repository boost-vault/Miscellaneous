#ifndef BOOST_CLONE_PTR_CLONE_PTR_HPP_INCLUDED
#define BOOST_CLONE_PTR_CLONE_PTR_HPP_INCLUDED

#include <boost/config.hpp>
#include <boost/ptr_container/clone_allocator.hpp>

namespace boost
{

template <class T>
class clone_ptr
{
private:
    T* ptr_;

public:
    explicit clone_ptr( T* ptr = 0 ) throw();

    clone_ptr( const clone_ptr& ptr );

    template <class V>
    clone_ptr( const clone_ptr<V>& ptr );

    ~clone_ptr();

    const clone_ptr& operator =(const clone_ptr& ptr);

    template <class V>
    const clone_ptr& operator =( const clone_ptr<V>& ptr );

    #ifndef BOOST_NO_RVALUE_REFERENCES

    template <class V>
    clone_ptr( clone_ptr<V>&& ptr ) throw();

    template <class V>
    const clone_ptr& operator =( clone_ptr<V>&& ptr ) throw();

    #endif

public:
    T& operator *() const throw();

    T* operator->() const throw();

    T* get() const throw();

    T* release() throw();

    void reset(T* ptr = 0) throw();
};


template <class T>
inline
clone_ptr<T>::clone_ptr(T* ptr) throw():
    ptr_( ptr )
{
}

template <class T>
inline
clone_ptr<T>::clone_ptr(const clone_ptr& ptr):
    ptr_( new_clone<T>( ptr.ptr_ ) )
{
}

template <class T>
template <class V>
inline
clone_ptr<T>::clone_ptr(const clone_ptr<V>& ptr ):
    ptr_( new_clone<T>( ptr.get() ) )
{
}

template <class T>
inline
clone_ptr<T>::~clone_ptr()
{
    if(ptr_ != 0)
        delete_clone( ptr_ );
}

template <class T>
inline
const clone_ptr<T>& clone_ptr<T>::operator =(const clone_ptr& ptr)
{
    if(this != &ptr)
    {
        ptr_ = new_clone<T>( ptr.get() );
    }
    return *this;
}

template <class T>
template <class V>
inline
const clone_ptr<T>& clone_ptr<T>::operator =( const clone_ptr<V>& ptr )
{
    ptr_ = new_clone<T>( ptr.get() );

    return *this;
}

#ifndef BOOST_NO_RVALUE_REFERENCES

template <class T>
template <class V>
inline
clone_ptr<T>::clone_ptr(clone_ptr<V>&& ptr) throw():
    ptr_( ptr.release() )
{
}

template <class T>
template <class V>
const clone_ptr<T>& clone_ptr<T>::operator =( clone_ptr<V>&& ptr ) throw()
{
    ptr_ = ptr.release();
    return *this;
}

#endif

template <class T>
inline
T& clone_ptr<T>::operator *() const throw()
{
    BOOST_ASSERT( ptr_ != 0 );
	return *ptr_;
}

template <class T>
inline
T* clone_ptr<T>::operator ->() const throw()
{
	BOOST_ASSERT( ptr_ != 0 );
	return ptr_;
}

template <class T>
inline
T* clone_ptr<T>::get() const throw()
{
    return ptr_;
}

template <class T>
inline
T* clone_ptr<T>::release() throw()
{
    T* temp = ptr_;
    ptr_ = 0;
    return temp;
}

template <class T>
inline
void clone_ptr<T>::reset(T* ptr) throw()
{
    if(ptr_ != ptr)
    {
        if( ptr_ )
            delete_clone( ptr_ );

        ptr_ = ptr;
    }
}

} //namespace boost
#endif // BOOST_CLONE_PTR_CLONE_PTR_HPP_INCLUDED
