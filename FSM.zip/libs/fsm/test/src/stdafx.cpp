/*!
* (C) 2006 Andrey Semashev
*
* \file   stdafx.cpp
* \author Andrey Semashev
* \date   11.04.2006
*
* \brief  Precompiled headers and main function support
*/

#include "stdafx.hpp"

#define BOOST_AUTO_TEST_MAIN
#include <boost/test/auto_unit_test.hpp>
