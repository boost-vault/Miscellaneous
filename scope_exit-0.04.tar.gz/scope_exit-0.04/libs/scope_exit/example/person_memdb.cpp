#include <algorithm>
#include <climits>
#include <exception>
#include <iostream>
#include <ostream>
#include <stdexcept>
#include <string>
#include <vector>

#include <boost/lambda/lambda.hpp>
#include <boost/lexical_cast.hpp>
#include <boost/scope_exit.hpp>
#include <boost/typeof/std/vector.hpp>

template<class ForwardIter, class Compare>
ForwardIter unary_lower_bound(ForwardIter begin, ForwardIter end, Compare cmp)
{
    typename std::iterator_traits<ForwardIter>::difference_type size =
        std::distance(begin, end);
    while(size > 0)
    {
        ForwardIter middle(begin);
        std::advance(middle, size / 2);
        if(!cmp(*middle))
            size /= 2;
        else
        {
            begin = ++middle;
            size -= 1 + size / 2;
        }
    }
    return begin;
}

class World;

class Person
{
    friend class World;
  public:

    Person(std::string const& firstName, std::string const& lastName)
        : m_id(ULONG_MAX), m_firstName(firstName), m_lastName(lastName)
    {}

    mutable unsigned long m_id; // under control of World.
    std::string m_firstName;
    std::string m_lastName;
    char dummy[10240]; // For stress test
};

BOOST_TYPEOF_REGISTER_TYPE(Person)

std::ostream& operator<<(std::ostream& out, Person const& person)
{
    return out << person.m_id << ": "
               << person.m_firstName << ' '
               << person.m_lastName;
}

class World
{
  public:

    typedef std::vector<Person> persons_vector;
    typedef std::vector<persons_vector::size_type> persons_idx_vector;

  private:

    unsigned long      m_nextId; // auto increment
    persons_vector     m_persons;
    persons_idx_vector m_persons_idx_firstName;
    persons_idx_vector m_persons_idx_lastName;

  private:

    persons_idx_vector::iterator findFirstNameIdxPos(Person const& person);
    persons_idx_vector::iterator findLastNameIdxPos(Person const& person);

  public:

    World() : m_nextId(0) {}

    void addPerson(Person const& person);
    void checkInvariants() const;
    void dump() const;
};

BOOST_TYPEOF_REGISTER_TYPE(World::persons_vector::iterator)
BOOST_TYPEOF_REGISTER_TYPE(World::persons_idx_vector::iterator)


World::persons_idx_vector::iterator World::findFirstNameIdxPos(
        Person const& person)
{
    using namespace boost::lambda;
    return unary_lower_bound(
            m_persons_idx_firstName.begin()
          , m_persons_idx_firstName.end()
          , (&var(m_persons)[_1]->*&Person::m_firstName) < person.m_firstName
          );
}


World::persons_idx_vector::iterator World::findLastNameIdxPos(
        Person const& person)
{
    using namespace boost::lambda;
    return unary_lower_bound(
            m_persons_idx_lastName.begin()
          , m_persons_idx_lastName.end()
          , (&var(m_persons)[_1]->*&Person::m_lastName) < person.m_lastName
          );
}

void World::addPerson(Person const& person)
{
    bool commit = false;
    unsigned long const old_id = person.m_id;
    persons_vector::size_type const pos = m_persons.size();


    // Step 1: auto increment.
    person.m_id = m_nextId++;

    BOOST_SCOPE_EXIT( (commit)(person)(old_id)(m_nextId) )
    {
        if(!commit)
        {
            --m_nextId;
            person.m_id = old_id;
        }
    } BOOST_SCOPE_EXIT_END


    // Step 2: append the person to the m_persons.
    m_persons.push_back(person);

    BOOST_SCOPE_EXIT( (commit)(m_persons) )
    {
        if(!commit)
            m_persons.pop_back();
    } BOOST_SCOPE_EXIT_END


    // Step 3: update 'last name' index.
    persons_idx_vector::iterator const lastNameIdxPos =
        m_persons_idx_lastName.insert(findLastNameIdxPos(person), pos);

    BOOST_SCOPE_EXIT( (commit)(m_persons_idx_lastName)(lastNameIdxPos) )
    {
        if(!commit)
            m_persons_idx_lastName.erase(lastNameIdxPos);
    } BOOST_SCOPE_EXIT_END


    // Step 4: update 'first name' index.
    persons_idx_vector::iterator const firstNameIdxPos =
        m_persons_idx_firstName.insert(findFirstNameIdxPos(person), pos);

    BOOST_SCOPE_EXIT( (commit)(m_persons_idx_firstName)(firstNameIdxPos) )
    {
        if(!commit)
            m_persons_idx_firstName.erase(firstNameIdxPos);
    } BOOST_SCOPE_EXIT_END

    // Step 5: commit.
    commit = true;
}

void World::checkInvariants() const
{
    if(m_persons.size() != m_persons_idx_lastName.size())
        throw std::logic_error("World::checkInvariants");
}

void World::dump() const
{
    using namespace boost::lambda;
    std::for_each(m_persons.begin(), m_persons.end(), std::cout << _1 << '\n');

    std::cout << "first name index: ";
    std::for_each(
            m_persons_idx_firstName.begin()
          , m_persons_idx_firstName.end()
          , std::cout << _1 << ' '
          );
    std::cout << '\n';

    std::cout << "last name index: ";
    std::for_each(
            m_persons_idx_lastName.begin()
          , m_persons_idx_lastName.end()
          , std::cout << _1 << ' '
          );
    std::cout << '\n';
}

int main(int argc, char* argv[])
{
    World world;
    Person author("Alexander", "Nasonov");
    world.addPerson(author);

    Person acknowledge1("Maxim", "Yegorushkin");
    world.addPerson(acknowledge1);

    Person acknowledge2("Andrei", "Alexandrescu");
    world.addPerson(acknowledge2);

    Person acknowledge3("Pavel", "Vozenilek");
    world.addPerson(acknowledge3);

    Person acknowledge4("Maxim", "Yanchenko");
    world.addPerson(acknowledge4);

    Person acknowledge5("Steven", "Watanabe");
    world.addPerson(acknowledge5);

    Person acknowledge6("Jody", "Hagins");
    world.addPerson(acknowledge6);

    world.dump();
    world.checkInvariants();


    // stress test
    bool stop = (argc == 1);
    unsigned long id = 4;

    while(!stop)
    {
        std::string s = boost::lexical_cast<std::string>(id);
        Person person(s, s);
        ++id;

        try
        {
            world.addPerson(person);
        }
        catch(std::bad_alloc const& ex)
        {
            std::cerr << ex.what() << '\n';
            stop = true;
        }

        world.checkInvariants();
    }
}

