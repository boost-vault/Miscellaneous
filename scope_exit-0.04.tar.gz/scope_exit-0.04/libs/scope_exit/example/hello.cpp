#include <iostream>
#include <ostream>
#include <string>

#include <boost/scope_exit.hpp>
#include <boost/typeof/std/string.hpp>

int main()
{
    try
    {
        std::string hello("Hello"), world("World");

        BOOST_SCOPE_EXIT( (hello)(world) )
        {
            std::clog << world << ", " << hello << "!\n";
        }
        BOOST_SCOPE_EXIT_END

        std::cout << hello << ", " << world << "!\n";
        // other code
    } catch(...) {} /*
    ^ "World, Hello\n" is printed at this point */
}

