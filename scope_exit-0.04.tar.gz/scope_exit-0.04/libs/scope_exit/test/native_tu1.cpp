#include "tu_test.hpp"

int tu1()
{
    return inline_f() + template_f(1);
}

