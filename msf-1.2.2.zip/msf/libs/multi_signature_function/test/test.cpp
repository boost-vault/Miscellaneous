/*
 Author: Marco Costalba (C) 2007-2008

 This is an annotated test of multi-signature function library (MSF).

 Not only all the features are tested under different conditions,
 but each test case is also a documented example of how to use
 the library.

 To read this test source code is an efficent and easy way to learn MSF.

 To compile:

    (gcc)  g++ -I<boost_dir> -o test test.cpp
*/
#include <boost/multi_signature_function.hpp>

#include <cassert>
#include <iostream>
#include <string>
#include <boost/bind.hpp>
#include <boost/mpl/vector.hpp>
#include <boost/ref.hpp>

#define COMPILER_SUPPORTS_RESULT_OF 0 // Set to 1 if boost::result_of works with your compiler

#if COMPILER_SUPPORTS_RESULT_OF
#include <boost/utility/result_of.hpp>
#endif

using std::string;

int foo1(char) { return -1; }

double foo2(int, char) { return 123.456; }

char foo3(string) { return 'x'; }

void foo4(string s1, string s2, string s3) { std::cout << s1 + s2 + s3; }

int foo5() { return 7; }

int foo6() { return 9; }

template<typename T>
T fooT(T t) { return t; }

struct foo1_t
{
    int operator()(char) { return 123; }

    char foo3(string) { return 'y'; }
    int foo1(char) { return 8; }

    static char foo3_s(string) { return 's'; }
};

struct foo1_c_t
{
    int operator()(char) const { return 7; }
};

struct foo1_v_t
{
    int operator()(char) volatile { return 7; }
};

struct foo1_cv_t
{
    int operator()(char) const volatile { return 7; }
};

struct poly_t
{
    int call_cnt;

    poly_t() : call_cnt(0) {}

    template<class T> T operator()(T t) { call_cnt++; return t; }
};

namespace msf = boost::multi_signature_function;

int main(int, char**)
{
    /* Define a single function signature */
    msf::function<int()> f_one_sig;

    f_one_sig = foo5;

    assert( f_one_sig() == 7 );

    /* Define a multi signature function using a mpl sequence of signatures */
    typedef boost::mpl::vector
    <
        double(int, char)
      , double(double)
      , void(string, string, string)
      , char(string)
      , int()
      , int(char)
    > Signatures;

    /* Any boost::mpl sequence can be used as Signatures parameter */
    msf::function<Signatures> f(foo4, &foo1, fooT<double>);

    /* It is possible to get a reference to the underlying boost::function
     * object corresponding to a given signature with get<signature>()
     *
     * We use this to check if a given signature slot is empty
     */
    assert( f.get<int(char)>().empty() == false );
    assert( f.get<int()>().empty() == true );

    typedef int (Fun)();
    Fun* foo5_ptr(foo5);
    Fun& foo5_ref(foo5);

    /* Assign functions in any order as pointers, references or plain types */
    f = &foo2;
    f = foo5_ptr;
    f = foo5_ref;
    f = foo3;

    assert( f('x') == -1 );

    /* Assign functors as well as references or plain types */
    foo1_t functor;
    foo1_t& functor_ref(functor);

    f = functor;
    f = functor_ref;

    /* Works also with const objects */
    const foo1_t const_functor(functor);

    f = const_functor;

    /* Implicit conversions are supported at invocation time */
    f("\nHello", " World", " I'm Marco\n");

    assert( f('x') == 123 );
    assert( f(123, 'x') > 123.455 && f(123, 'x') < 123.457 );
    assert( f("hello") == 'x' );
    assert( f() == 7 );
    assert( f(3.0) > 2.9 && f(3.0) < 3.1 );

    /* Try with static member function */
    f = foo1_t::foo3_s;

    assert( f("hello") == 's' );

    /* Test with functors with const members */
    foo1_c_t functor_const;
    foo1_c_t& functor_const_ref(functor_const);
    const foo1_c_t const_functor_const(functor_const);

    f = functor_const;
    f = functor_const_ref;
    f = const_functor_const;

    assert( f('x') == 7 );

    /* Test with different cv qualified members */
    foo1_v_t functor_volatile;
    foo1_cv_t functor_const_volatile;

    f = functor_volatile;
    f = functor_const_volatile;

    assert( f('x') == 7 );

    /* The same as above but with const objects */
    const foo1_v_t c_functor_volatile(functor_volatile);
    const foo1_cv_t c_functor_const_volatile(functor_const_volatile);

    f = c_functor_volatile;
    f = c_functor_const_volatile;

    assert( f('x') == 7 );

    /* Passing a boost::function object is supported... */
    boost::function<char(string)> boost_fun1 = foo3;
    boost::function<int(char)> boost_fun2 = foo1;

    f = boost_fun1;
    f = boost_fun2;

    assert( f("hello") == 'x' );
    assert( f('x') == -1 );

    /* ...so it's easy to also pass pointers to member function using boost::bind */
    boost_fun1 = boost::bind(&foo1_t::foo3, functor, _1);
    boost_fun2 = boost::bind(&foo1_t::foo1, functor, _1);

    f = boost_fun1; // overwrites foo3()
    f = boost_fun2; // overwrites foo1()

    assert( f("hello") == 'y' );
    assert( f('x') == 8 );

    /* Use of boost::ref() is supported as is in boost::function */
    f = boost::ref(functor);

    assert( f('x') == 123 );

    /* Also boost::cref() when operator() is const qualified */
    f = boost::cref(functor_const);
    f = boost::cref(const_functor_const);

    assert( f('x') == 7 );

    /* In case the assigned object is a polymorphic function object
     * then all the internal boost::functions are bounded in one go
     */
    poly_t poly_obj;

    msf::function<boost::mpl::vector<char(char), string(string)> > fp(poly_obj);

    assert( fp('x') == 'x' );
    assert( fp("hello") == "hello" );
    assert( fp("hello") == "hello" );

    /* By default boost::function makes a copy of the functor, so
     * we end up with a different copy of poly_obj for each signature
     * and the variable poly_obj::call_cnt is updated indipendently
     * by the two calls. Below we retrieve the object wrapped by
     * each of the two underlying boost::function and verify that
     * poly_t::call_cnt is duplicated.
     */
    assert( fp.get<char(char)>().target<poly_t>()->call_cnt == 1 );
    assert( fp.get<string(string)>().target<poly_t>()->call_cnt == 2 );

    /* In some cases it is expensive (or semantically incorrect) to
     * clone a polymorphic function object. In such cases, it is possible
     * to request to keep only a reference to the actual function object.
     * This is done using the ref() function to wrap a reference to a
     * polymorphic function object
     */
    poly_t external_poly_obj;

    fp = boost::ref(external_poly_obj);

    external_poly_obj('x');
    external_poly_obj("hello");

    assert( fp.get<char(char)>().target<poly_t>()->call_cnt == 2 );
    assert( fp.get<string(string)>().target<poly_t>()->call_cnt == 2 );

    /* A special case is when we need to have only a single copy of the
     * polymorphic object for all the signatures. In this case we have to
     * set to poly_single_copy the Tag template parameter of msf::function
     * that normally defaults to poly_multi_copy
     */
    poly_t* poly_obj_ptr = new poly_t();

    msf::function<
                  boost::mpl::vector<char(char), string(string)>,
                  msf::poly_single_copy
                  >
    fp_si(*poly_obj_ptr);  // work both as c'tor argument...

    fp_si = *poly_obj_ptr; //... and as assignment

    delete poly_obj_ptr; // delete now, a copy has already been made

    assert( fp_si('x') == 'x' );
    assert( fp_si("hello") == "hello" );
    assert( fp_si("hello") == "hello" );

    /* Only one poly_t::call_cnt shared across the signature's slots */
    assert( fp_si.get<char(char)>().target<poly_t>()->call_cnt == 3 );
    assert( fp_si.get<string(string)>().target<poly_t>()->call_cnt == 3 );

    /* Of course it works also for normal cases */
    fp_si = fooT<char>;

    assert( fp_si('x') == 'x' );

    /* Multi-signature functions can be compared against anything
     * for which boost::function::operator==() is defined
     */
    f = foo1;
    f = foo2;

    assert( f == foo1 );
    assert( f == foo2 );
    assert( f != &functor );

    /* Multi signature function fully supports copy semantics */
    msf::function<Signatures> g, h(f);

    assert( g.get<char(string)>().empty() == true );

    g = f;

    assert( g("hello") == 'y' );
    assert( h("hello") == 'y' );

#if COMPILER_SUPPORTS_RESULT_OF

    /* Multi signature, being a polymorphic function object itself
     * supports boost::result_of protocol
     */
    typedef msf::function<Signatures> Msf;

    typedef Msf::result<Msf(char)>::type ret_type_1;
    typedef Msf::result<Msf(string, string, string)>::type ret_type_2;

    bool ok1 = (boost::is_same<ret_type_1, int>::value == 1);
    bool ok2 = (boost::is_same<ret_type_2, void>::value == 1);

    assert( ok1 );
    assert( ok2 );

    /* Directly test with boost::result_of */
    typedef boost::result_of<Msf(char)>::type ret_type_3;
    typedef boost::result_of<Msf(string, string, string)>::type ret_type_4;

    ok1 = (boost::is_same<ret_type_3, int>::value == 1);
    ok2 = (boost::is_same<ret_type_4, void>::value == 1);

    assert( ok1 );
    assert( ok2 );

#endif

    /* It is possible to clear out the function corresponding to a given signature */
    assert( f.get<int(char)>().empty() == false );

    f.get<int(char)>().clear();

    assert( f.get<int(char)>().empty() == true );

    /* Or it is also possible to clear all slots in one go */
    g.clear();

    assert( g.get<int(char)>().empty() == true );
    assert( g.get<int()>().empty() == true );

    /* Correspondingly it is possible to check if all the slots are empty */
    assert( g.empty() == true );
    assert( f.empty() == false );

    /* For API completness contains() is supported as a natural
     * extension of the boost::function one
     */
    g = foo5;

    assert( g.contains(&foo5) );
    assert(!g.contains(&foo1) );

    /* An exception is thrown if an empty slot is called */
    try {
        g('x');
        assert(false);
    }
    catch (boost::bad_function_call& e)
    {
        std::cout << std::endl << e.what() << std::endl;
    }

    std::cout << "\nTest successful\n" << std::endl;

    return 0;
}
