/*=============================================================================
    Copyright (c) 2008 Marco Costalba

    Use, modification and distribution is subject to the Boost Software
    License, Version 1.0. (See accompanying file LICENSE_1_0.txt or copy at
    http://www.boost.org/LICENSE_1_0.txt)
==============================================================================*/
#ifndef DYNAMIC_FACTORY_HPP
#define DYNAMIC_FACTORY_HPP

#include <boost/multi_signature_function.hpp>

#include <boost/control/switch.hpp>
#include <boost/control/case.hpp>
#include <boost/fusion/functional/invocation/invoke.hpp>
#include <boost/fusion/include/make_vector.hpp>
#include <boost/fusion/include/vector.hpp>
#include <boost/fusion/mpl.hpp>
#include <boost/mpl/front.hpp>
#include <boost/mpl/range_c.hpp>
#include <boost/mpl/remove.hpp>
#include <boost/mpl/size.hpp>
#include <boost/mpl/transform.hpp>
#include <boost/type_traits/function_traits.hpp>
#include <map>

namespace dynamic_factory {

namespace ctl = boost::control;
namespace fusion = boost::fusion;
namespace mpl = boost::mpl;
namespace msf = boost::multi_signature_function;

namespace detail {

/* Define ctor wrapper polymorphic function object */
template<typename R>
struct poly_ctor_wrapper
{
    R* operator()() { return new R(); }

    template<typename A0>
    R* operator()(A0 a0) { return new R(a0); }

    template<typename A0, typename A1>
    R* operator()(A0 a0, A1 a1) { return new R(a0, a1); }
};

/* Helper used in our fallback operator(), see below */
struct any_conversion
{
    template<typename T> any_conversion(const volatile T&) {}
    template<typename T> any_conversion(T&) {}
};

/* Define a factory for the class corresponding to Signatures */
template<typename Signatures>
struct one_class_factory : msf::function<Signatures, msf::poly_single_copy>
{
    typedef msf::function<Signatures, msf::poly_single_copy> Base;

    /* Implement boost::result_of protocol used by fusion::invoke, all the Signatures
     * return the same type, so just consider the first one.
     */
    typedef typename boost::function_traits<typename mpl::front<Signatures>::type>::result_type result_type;

    one_class_factory()
    {
        typedef typename boost::remove_pointer<result_type>::type class_type;

        *((Base*)this) = poly_ctor_wrapper<class_type>(); /* Init MSF slots */
    }

    using Base::operator();

    /* These operator() are never called, but are needed to let the thing compile because
     * ctl::switch_ instantiates all the possible cases, also the unreachable ones.
     * Note that here operator() are const qualified to avoid ambiguity with MSF ones
     * that are always preferred, when available, in overload resolution.
     */
    result_type operator()() const { return 0; }
    result_type operator()(any_conversion) const { return 0; }
    result_type operator()(any_conversion, any_conversion) const { return 0; }
};

/* Remove unused signatures and build the sequence of one_class_factory, one per class */
template<typename Sequence>
struct make_factory : mpl::transform<
                                     typename mpl::remove<Sequence, int>::type,
                                     one_class_factory<mpl::_>
                                    >
{};

} // detail

/* This is our run-time factory, it's a sequence of one_class_factory */
template<typename Key, class Base, typename Sig1, typename Sig2 = int, typename Sig3 = int, typename Sig4 = int>
class factory : public detail::make_factory<fusion::vector<Sig1, Sig2, Sig3, Sig4> >::type
{
    std::map<Key, int> m;

    /* Range used by ctl::switch_ */
    typedef mpl::range_c<std::size_t, 0, mpl::size<factory>::value> range;

    template<class Args>
    struct call_ctor
    {
        call_ctor(factory* s, Args const& a): seq(s), args(a) {}

        template<class Case>
        Base* operator()(Case)
        {
            typedef typename fusion::result_of::at<factory, Case>::type f_ref;

            return fusion::invoke<f_ref>(fusion::at<Case>(*seq), args);
        }

        factory* seq; /* non-const to avoid ambiguity with one_class_factory::operator() */
        const Args& args;
    };

    template<typename Args>
    Base* get_by_pos(int pos, Args const& args)
    {
        return ctl::switch_<Base*>(pos, ctl::case_<range>(call_ctor<Args>(this, args)));
    }

public:
    void set_key(Key const& key, int pos)
    {
        if (pos >= 0 && pos < mpl::size<factory>::value)
            m[key] = pos;
    }

    factory() {}
    explicit factory(Key const& k0) { set_key(k0, 0); }
    factory(Key const& k0, Key const& k1) { set_key(k0, 0); set_key(k1, 1); }
    factory(Key const& k0, Key const& k1, Key const& k2) { set_key(k0, 0); set_key(k1, 1); set_key(k2, 2); }

    Base* get_by_key(Key const& key)
    { return (m.find(key) == m.end() ? 0 : get_by_pos(m[key], fusion::make_vector())); }

    template<typename A0>
    Base* get_by_key(Key const& key, A0 a0)
    { return (m.find(key) == m.end() ? 0 : get_by_pos(m[key], fusion::make_vector(a0))); }

    template<typename A0, typename A1>
    Base* get_by_key(Key const& key, A0 a0, A1 a1)
    { return (m.find(key) == m.end() ? 0 : get_by_pos(m[key], fusion::make_vector(a0, a1))); }
};

} // dynamic_factory

#endif
