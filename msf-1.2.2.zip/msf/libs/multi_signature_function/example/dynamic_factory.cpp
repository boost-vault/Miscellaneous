/*
  Author: Marco Costalba (C) 2008

  An object factory builds objects of different classes passing different
  arguments to each class constructor.

  The class of the object to build is chosen by a runtime variable. All
  the classes should derive from a common base class. Different class
  hierarchies require different factories.

  This implementation is based on multisignature function (MSF)

  Requires switch.zip currently in sandbox

  To compile:

    (gcc) g++ -I<boost_dir> -o dynamic_factory dynamic_factory.cpp
*/
#include "dynamic_factory.hpp"

#include <cassert>
#include <iostream>
#include <string>

using std::cout;
using std::endl;
using std::string;

struct Class_1
{
    Class_1() {}
    Class_1(int) {}

    virtual string whoami() { return "\nI'm Class_1\n"; }
};

struct Class_2 : Class_1
{
    Class_2(int) {}
    Class_2(string) {}
    Class_2(string, int) {}

    string whoami() { return "\nI'm Class_2\n"; }
};

int main(int, char**)
{
    /* First define the c'tor signatures we will use, c'tors are supposed to return pointers */
    typedef boost::mpl::vector<Class_1*(), Class_1*(int)> Sig1;
    typedef boost::mpl::vector<Class_2*(int), Class_2*(string), Class_2*(string, int)> Sig2;

    /* Then define the factory, first parameter is the type of the key used to query
     * the factory for objects, second parameter is the base class of our hierarchy
     *
     * In factory ctor we pass the key values associated to signatures
     */
    dynamic_factory::factory<std::string, Class_1, Sig1, Sig2> f("first", "second");

    /* Let's build up an object corresponding to a runtime value of the key */
    cout << f.get_by_key("first")->whoami() << endl;
    cout << f.get_by_key("first", 7)->whoami() << endl;

    string a_string = "hello";

    cout << f.get_by_key("second", 2)->whoami() << endl;
    cout << f.get_by_key("second", a_string)->whoami() << endl;
    cout << f.get_by_key("second", "Implicit conversion")->whoami() << endl;

    /* It is possible to use set_key to add/set a new (key, position) value */
    string my_key = "another_second";

    f.set_key(my_key, 1);

    cout << f.get_by_key(my_key, a_string, 5)->whoami() << endl;

    return 0;
}
