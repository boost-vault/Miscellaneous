/*
  Author: Marco Costalba (C) 2007-2008

  An object factory builds objects of different classes
  passing different arguments to each class constructor.

  The class of the object to build is choosen through
  an index value.

  Note that this is NOT a run-time factory because the
  index value, in this demo, is a compile time costant.

  For a run-time type factory, where the key value is stored
  in a normal, writable variable, see the file factory.zip
  of the same author currently in Boost Vault.

  To compile:

    (gcc) g++ -I<boost_dir> -o factory factory.cpp
*/
#include <boost/multi_signature_function.hpp>

#include <cassert>
#include <iostream>
#include <string>
#include <memory>
#include <boost/mpl/vector.hpp>
#include <boost/tuple/tuple.hpp>

using std::string;
using std::cout;

struct Class_1 {
    Class_1() {}
    Class_1(int) {}

    string whoami() { return "\nI'm Class_1\n"; }
};

struct Class_2 {
    Class_2(int) {}
    Class_2(string) {}

    string whoami() { return "\nI'm Class_2\n"; }
};

template<class T>
T* ctor_wrapper_0() { return new T(); }

template<class T, typename A0>
T* ctor_wrapper_1(A0 a0) { return new T(a0); }

int main(int, char**)
{
    /* First define the signatures we will use */
    typedef boost::mpl::vector<Class_1*(), Class_1*(int)> Sig_1;
    typedef boost::mpl::vector<Class_2*(int), Class_2*(string)> Sig_2;

    /* Then define the multi-signature function types on them */
    typedef boost::multi_signature_function::function<Sig_1> Msf_1;
    typedef boost::multi_signature_function::function<Sig_2> Msf_2;

    /* Instantiate the MSF objects assigning the c'tor wrappers */
    Msf_1 f1(ctor_wrapper_0<Class_1>, ctor_wrapper_1<Class_1, int>);
    Msf_2 f2(ctor_wrapper_1<Class_2, int>, ctor_wrapper_1<Class_2, string>);

    /* Now pack everything in a boost::tuple, this is our factory */
    boost::tuple<Msf_1, Msf_2> factory(f1, f2);

    /* Tuple access key values can be stored in a couple of static
     * const variables, of course others, more flexible, approaches
     * do exsist, this is simple and just enough for this demo
     */
    static const int class_1_key = 0;
    static const int class_2_key = 1;

	/* Finally enjoy the factory... */
	Class_1* c1 = factory.get<class_1_key>()();  // new Class_1() called
	Class_2* c2 = factory.get<class_2_key>()(7); // new Class_2(7) called

	cout << c1->whoami();
	cout << c2->whoami();

	c1 = factory.get<class_1_key>()(8);
	c2 = factory.get<class_2_key>()("Hello");

	cout << c1->whoami();
	cout << c2->whoami();

    cout << "\n\nTest passed succesfully\n\n";

    return 0;
}
