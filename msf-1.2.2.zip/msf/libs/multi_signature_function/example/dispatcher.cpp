/*
 Author: Marco Costalba (C) 2007-2008

 A runtime dynamic dispatch (or dispatcher) is a callback/handler
 registry library which allows developers to create dynamically
 dispatched handlers based on an index.

 This example will show how to build a simple multi signature
 dispatcher with the multi-signature function library.

 We will use a std::map of multi-signature functions to implement
 the dispatcher.

 To compile:

    (gcc) g++ -I<boost_dir> -o dispatcher dispatcher.cpp
*/

#include <boost/multi_signature_function.hpp>

#include <cassert>
#include <iostream>
#include <string>
#include <map>
#include <boost/mpl/vector.hpp>

using std::string;
using std::cout;

int foo1(char) { return -1; }

int foo2(char) { return 8; }

char foo3(string) { return 'x'; }

int main(int, char**)
{
    /* First define the signatures of the functions we will use */
    typedef boost::mpl::vector<int(char), char(string)> Signatures;

    /* Then define the multi-signature function */
    typedef boost::multi_signature_function::function<Signatures> Msf;

    /* This is our dynamic dispatcher with key of type int */
    std::map<int, Msf> d;

    /* Now we can assign functions to dispacther items */
    d[0] = foo1;
    d[0] = foo3;

    d[1] = foo2;

    /* The dispatcher will work as expected */
    assert( d[0]('x') == -1 );
    assert( d[0]("hello") == 'x' );

    assert( d[1]('x') == 8 );

    /* Defining a single signature dispatcher is supported as
     * a sub-case. Here we have the advantage to be able to
     * define the signature in the multi-signature function
     * definition and avoiding to use any mpl sequence.
     */
    typedef boost::multi_signature_function::function<int(char)> Msf_one;

    std::map<string, Msf_one> ds; // here key is of type std::string

    ds["first"] = foo1;
    ds["second"] = foo2;

    try {
        assert( ds["first"]('x') == -1 );
        assert( ds["second"]('x') == 8 );

        /* An exception is raised if an empty element is called */
        ds["other"]('x');
        assert(false);
    }
    catch (std::exception&)
    {
        cout << "\nEmpty element called" << std::endl;
    };

    cout << "\nTest successful\n" << std::endl;

    return 0;
}
