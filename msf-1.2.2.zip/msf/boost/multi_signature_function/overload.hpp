/*=============================================================================
    Copyright (c) 2007-2008 Marco Costalba

    Use, modification and distribution is subject to the Boost Software
    License, Version 1.0. (See accompanying file LICENSE_1_0.txt or copy at
    http://www.boost.org/LICENSE_1_0.txt)
==============================================================================*/
#ifndef OVERLOAD_HPP
#define OVERLOAD_HPP

/* Maximum function arity may be configured by defining
 * MSF_FUNCTION_MAX_ARITY, which defaults to Boost.MPL's
 * arity limit.
 */
#ifndef MSF_FUNCTION_MAX_ARITY
#   include <boost/mpl/limits/arity.hpp>
#   define MSF_FUNCTION_MAX_ARITY BOOST_MPL_LIMIT_METAFUNCTION_ARITY
#endif

#include <boost/multi_signature_function/is_compatible.hpp>

#include <boost/any.hpp>
#include <boost/function.hpp>
#include <boost/mpl/bool.hpp>
#include <boost/mpl/fold.hpp>
#include <boost/mpl/inherit_linearly.hpp>
#include <boost/mpl/identity.hpp>
#include <boost/mpl/if.hpp>
#include <boost/mpl/is_sequence.hpp>
#include <boost/mpl/vector.hpp>
#include <boost/preprocessor/repetition/enum_binary_params.hpp>
#include <boost/preprocessor/repetition/enum_params.hpp>
#include <boost/preprocessor/repetition/enum_trailing_params.hpp>
#include <boost/ref.hpp>
#include <boost/type_traits/is_same.hpp>
#include <boost/utility/enable_if.hpp>

namespace boost { namespace multi_signature_function { namespace detail {

    namespace mpl = boost::mpl;

    using boost::enable_if;

    /* This is the struct that defines operator() for a given signature,
     * each operator() forwards the call to a boost::function class.
     */
    template <typename Base, typename Sig>
    struct function_caller;

    /* This is the base of any function_caller and is used to
     * store and manage the wrapped boost::function object.
     */
    template <typename Base, typename Sig>
    struct function_holder : Base
    {
     protected:
        typedef boost::function<Sig> boost_fun_type;

        boost_fun_type boost_fun;

     public:
        template<typename Fun>
        bool operator==(Fun const& f) const
        {
            return (boost_fun == f) || Base::operator==(f);
        }

        template<typename Fun>
        bool operator!=(Fun const& f) const
        {
            return !operator==(f);
        }

        void clear()
        {
            boost_fun.clear();
            Base::clear();
        }

        bool empty() const
        {
            return boost_fun.empty() && Base::empty();
        }

        template<typename Fun>
        bool contains(Fun const& f) const
        {
            return boost_fun.contains(f) || Base::contains(f);
        }

        template<typename Fun>
        void set_poly(Fun const& f)
        {
            boost_fun = f;
            Base::set_poly(f);
        }

        using Base::set;
        using Base::get;

        template<typename Fun>
        void set(Fun const& f, typename enable_if<is_strictly_compatible<Fun, Sig> >::type* = 0)
        {
            boost_fun = f;
        }

        template<typename Fun>
        boost_fun_type& get(typename enable_if<boost::is_same<Fun, Sig> >::type* = 0)
        {
            return boost_fun;
        }
    };

    /* The base of our overload hierarchy */
    struct final_function_caller
    {
        struct final;
        void operator()(final*);
        void set(final*);
        void get(final*);
        void clear() {}
        bool empty() const { return true; }

        template<typename Fun>
        bool contains(Fun const&) const { return false; }

        template<typename Fun>
        bool operator==(Fun const&) const { return false; }

        template<typename Fun>
        void set_poly(Fun const&) {}
    };

    /* The overload builder, Signatures must be a mpl sequence here */
    template<typename Signatures>
    struct overload_impl : mpl::inherit_linearly<  Signatures
                                                 , function_caller<mpl::_1, mpl::_2>
                                                 , final_function_caller
                                                >::type {};

    template<typename Signatures>
    struct function_base : mpl::if_<  mpl::is_sequence<Signatures>
                                    , overload_impl<Signatures>
                                    , overload_impl<mpl::vector<Signatures> >
                                   >::type {};

    /* Implements the allocation policy for polymorphic function objects */
    template<typename Signatures, typename Tag>
    struct poly_dispatch;

    } /* namespace detail */

    /* Start of our public API
     *
     * Below are the policy tag used as template parameters to specify the
     * type of allocation when a polimorphic function object is assigned
     * to our function.
     *
     * - poly_multi_copy: A copy of the poly object is created for each
     *                    signature slot, this is the default.
     *
     * - poly_single_copy: Only one copy of the poly object is created.
     *                     Every boost::function underlying each signature
     *                     slot keeps a reference to this copy.
     */
    struct poly_multi_copy;
    struct poly_single_copy;

    /* This is the multi signature function. Parameter Signatures can
     * be either a mpl sequence or a single function signature
     */
    template<typename Signatures, typename Tag = poly_multi_copy>
    struct function : detail::poly_dispatch<Signatures, Tag>
    {
        typedef typename detail::poly_dispatch<Signatures, Tag> Base;

        using Base::dispatch;
        using Base::operator(); // fix msvc buggy error C2666 "overloads have similar conversions"

        template<typename Fun>
        function& operator=(Fun const& f)
        {
            this->dispatch(f, (mpl::bool_<detail::is_polymorphic<Fun, Signatures>::value>*)0);
            return *this;
        }

        template<typename Fun>
        void dispatch(Fun const& f, mpl::false_*)
        {
            this->set(f);
        }

        function() {}

        template<typename T1> explicit
        function(T1 t1) { *this = t1; }

        template<typename T1, typename T2>
        function(T1 t1, T2 t2) { *this = t1; *this = t2; }

        template<typename T1, typename T2, typename T3>
        function(T1 t1, T2 t2, T3 t3) { *this = t1; *this = t2; *this = t3; }

        template<typename T1, typename T2, typename T3, typename T4>
        function(T1 t1, T2 t2, T3 t3, T4 t4)
        { *this = t1; *this = t2; *this = t3; *this = t4; }

        template<typename T1, typename T2, typename T3, typename T4, typename T5>
        function(T1 t1, T2 t2, T3 t3, T4 t4, T5 t5)
        { *this = t1; *this = t2; *this = t3; *this = t4; *this = t5; }

        template<typename T1, typename T2, typename T3, typename T4, typename T5, typename T6>
        function(T1 t1, T2 t2, T3 t3, T4 t4, T5 t5, T6 t6)
        { *this = t1; *this = t2; *this = t3; *this = t4; *this = t5; *this = t6; }

        /* Implement boost::result_of protocol */
        template<class Sig>
        struct result : Base::template result<function, Sig> {};
    };
}}


namespace boost { namespace multi_signature_function { namespace detail {

    /* Specialization of poly_dispatch according to the type of
     * allocation for the polymorphic function objects
     */
    template<typename Signatures>
    struct poly_dispatch<Signatures, poly_multi_copy> : function_base<Signatures>
    {
        template<typename Fun>
        void dispatch(Fun const& f, mpl::true_*)
        {
            this->set_poly(f);
        }
    };

    template<typename Signatures>
    struct poly_dispatch<Signatures, poly_single_copy> : function_base<Signatures>
    {
        template<typename Fun>
        void dispatch(Fun const& f, mpl::true_*)
        {
           poly_object_holder = f;
           this->set_poly(boost::ref(any_cast<Fun&>(poly_object_holder)));
        }

     private:
        /* Used to store a single copy of a polymorphic object assigned with
         * operator=(). All the internal boost::function keep a reference to this.
         */
        boost::any poly_object_holder;
    };

    /* Start of argument arity dependant part
     *
     * Define one function_caller specialization each signature arity to
     * guarantee that only the correct operator() will be instantiated
     * for each signature.
     */

#define FUNCTION_CALLER_SPECIALIZATION(z, n, _)                                                                          \
                                                                                                                         \
    template <typename Base, typename R BOOST_PP_ENUM_TRAILING_PARAMS(n, typename A)>                                    \
    struct function_caller<Base, R(BOOST_PP_ENUM_PARAMS(n, A))> : function_holder<Base, R(BOOST_PP_ENUM_PARAMS(n, A))>   \
    {                                                                                                                    \
        using Base::operator();                                                                                          \
                                                                                                                         \
        R operator()(BOOST_PP_ENUM_BINARY_PARAMS(n, A, a))       { return this->boost_fun(BOOST_PP_ENUM_PARAMS(n, a)); } \
        R operator()(BOOST_PP_ENUM_BINARY_PARAMS(n, A, a)) const { return this->boost_fun(BOOST_PP_ENUM_PARAMS(n, a)); } \
                                                                                                                         \
        template<class F, class Sig> struct result : Base::template result<F, Sig> {};                                   \
        template<class F> struct result<F, F(BOOST_PP_ENUM_PARAMS(n, A))> : mpl::identity<R> {};                         \
    };

BOOST_PP_REPEAT(
    BOOST_PP_INC(MSF_FUNCTION_MAX_ARITY)
  , FUNCTION_CALLER_SPECIALIZATION
  , _
)

#undef FUNCTION_CALLER_SPECIALIZATION

}}}

#endif
