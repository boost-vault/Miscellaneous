/*=============================================================================
    Copyright (c) 2007-2008 Marco Costalba

    Use, modification and distribution is subject to the Boost Software
    License, Version 1.0. (See accompanying file LICENSE_1_0.txt or copy at
    http://www.boost.org/LICENSE_1_0.txt)
==============================================================================*/
#ifndef IS_COMPATIBLE_HPP
#define IS_COMPATIBLE_HPP

#include <boost/multi_signature_function/functor_signature.hpp>

#include <boost/function.hpp> // std::allocator<>
#include <boost/mpl/bool.hpp>
#include <boost/mpl/identity.hpp>
#include <boost/mpl/if.hpp>
#include <boost/mpl/fold.hpp>
#include <boost/ref.hpp>
#include <boost/type_traits/is_function.hpp>
#include <boost/type_traits/is_same.hpp>
#include <boost/type_traits/remove_cv.hpp>
#include <boost/type_traits/remove_pointer.hpp>

namespace boost { namespace multi_signature_function { namespace detail {

    namespace mpl = boost::mpl;

    /* Trait to get the signature out of a boost::function */
    template<typename T>
    struct unwrap_boost_function : mpl::identity<T> {};

    template<template<typename, typename = ::std::allocator<void> >class boost_function, typename Sig>
    struct unwrap_boost_function<boost_function<Sig> > : mpl::identity<Sig> {};

    /* Check if a function/functor/boost::function Fun has a given signature Sig */
    template<typename Fun, typename Sig>
    struct is_strictly_compatible
    {
        typedef typename boost::remove_pointer<Fun>::type FFFF;
        typedef typename boost::unwrap_reference<FFFF>::type FFF;
        typedef typename boost::remove_cv<FFF>::type FF;
        typedef typename unwrap_boost_function<FF>::type F;

        static const bool
        value = mpl::if_<  boost::is_function<F>
                         , boost::is_same<F, Sig>
                         , is_functor_signature<F, Sig>
                        >::type::value;
    };

    /* Metafunction to test if a given functor Fun is strictly compatible
     * to all our signatures, in this case is supposed to be polymorphic
     */
    template<typename F>
    struct make_is_poly
    {
        template<typename prev, typename item>
        struct apply : mpl::bool_<prev::value && is_strictly_compatible<F, item>::value>
        {};
    };

    template<typename F, typename Sigs>
    struct is_polymorphic : mpl::fold<Sigs, mpl::bool_<true>, make_is_poly<F> >::type {};
}}}

#endif
