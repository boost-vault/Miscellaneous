/*=============================================================================
    Copyright (c) 2007-2008 Marco Costalba

    Use, modification and distribution is subject to the Boost Software
    License, Version 1.0. (See accompanying file LICENSE_1_0.txt or copy at
    http://www.boost.org/LICENSE_1_0.txt)
==============================================================================*/
#ifndef FUNCTOR_SIGNATURE_HPP
#define FUNCTOR_SIGNATURE_HPP

#include <boost/function_types/member_function_pointer.hpp>
#include <boost/function_types/parameter_types.hpp>
#include <boost/function_types/result_type.hpp>
#include <boost/mpl/push_front.hpp>
#include <boost/type_traits/detail/yes_no_type.hpp>

namespace boost { namespace multi_signature_function { namespace detail {

    using boost::type_traits::yes_type;
    using boost::type_traits::no_type;
    using boost::mpl::push_front;

    namespace ft = boost::function_types;

    template<typename Fun, typename Sig>
    struct is_functor_signature
    {
        /* First setup a function signature derived from Sig where Fun* is the type of first argument */
        typedef typename ft::parameter_types<Sig>::type args;
        typedef typename ft::result_type<Sig>::type ret;
        typedef typename push_front<typename push_front<args, Fun*>::type, ret>::type ptm_sig;

        /* Then check for pointer_to_member of type ptm_sig with any cv qualification */
        template<typename ft::member_function_pointer<ptm_sig, ft::non_cv>::type> struct helper;
        template<typename ft::member_function_pointer<ptm_sig, ft::const_non_volatile>::type> struct helper_c;
        template<typename ft::member_function_pointer<ptm_sig, ft::volatile_non_const>::type> struct helper_v;
        template<typename ft::member_function_pointer<ptm_sig, ft::cv_qualified>::type> struct helper_cv;

        template<class U> static
        yes_type detect(helper<&U::operator()>*);

        template<class U> static
        yes_type detect(helper_c<&U::operator()>*);

        template<class U> static
        yes_type detect(helper_v<&U::operator()>*);

        template<class U> static
        yes_type detect(helper_cv<&U::operator()>*);

        /* Default */
        template<class U> static
        no_type detect(...);

        static const bool
        value = (sizeof(detect<Fun>(0)) == sizeof(yes_type));
    };
}}}

#endif
