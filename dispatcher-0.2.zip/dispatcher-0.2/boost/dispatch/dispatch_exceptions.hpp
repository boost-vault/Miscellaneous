// Copyright 2006 (C) Dean Michael Berris <mikhailberis@gmail.com>
// Distributed under the Boost Software License, Version 1.0. (See accompanying
// file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)

#ifndef __DISPATCH_EXCEPTIONS_HPP_
#define __DISPATCH_EXCEPTIONS_HPP_

#include <exception>

namespace boost {
    namespace dispatch {

        template <typename IndexType>
        struct invalid_index : std::exception {
            invalid_index () : std::exception (), index () { };
            invalid_index (const IndexType & i) : std::exception(), index(i) { };

            ~invalid_index() throw () { };

            const char * what() const throw () {
                return "invalid index passed.";
            };

            IndexType index;
        };

        struct unregistered_handler : std::exception {
            const char * what() const throw () {
                return "unregistered handler called.";
            };
        };

    }; // namespace dispatch
}; // namespace boost

#endif
