// Copyright 2006 (C) Dean Michael Berris <mikhailberis@gmail.com>
// Distributed under the Boost Software License, Version 1.0. (See accompanying
// file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)

#ifndef __FUNCTOR6_HPP_
#define __FUNCTOR6_HPP_

#include <boost/static_assert.hpp>
#include <boost/type_traits/is_same.hpp>
#include <boost/function.hpp>
#include "dispatch_exceptions.hpp"

namespace boost {
    namespace dispatch {
        namespace detail {

            template <
                typename return_type, 
                typename arg1_type, 
                typename arg2_type, 
                typename arg3_type,
                typename arg4_type,
                typename arg5_type,
                typename arg6_type
            >
            class functor_impl_6 {

                BOOST_STATIC_ASSERT((!boost::is_same<arg1_type, void>::value));
                BOOST_STATIC_ASSERT((!boost::is_same<arg2_type, void>::value));
                BOOST_STATIC_ASSERT((!boost::is_same<arg3_type, void>::value));
                BOOST_STATIC_ASSERT((!boost::is_same<arg4_type, void>::value));
                BOOST_STATIC_ASSERT((!boost::is_same<arg5_type, void>::value));
                BOOST_STATIC_ASSERT((!boost::is_same<arg6_type, void>::value));

            public:
                typedef boost::function<return_type (arg1_type, 
                    arg2_type, 
                    arg3_type, 
                    arg4_type, 
                    arg5_type,
                    arg6_type)
                > wrapped_function_type;

				template <typename Sig>
				struct result {
					typedef return_type type;
				};

				typedef return_type result_type;

                functor_impl_6 () : _wrapped_function(default_function) { };

                return_type operator() (const arg1_type & arg1, 
                    const arg2_type & arg2, 
                    const arg3_type & arg3, 
                    const arg4_type & arg4, 
                    const arg5_type & arg5,
                    const arg6_type & arg6) 
                {
                    return _wrapped_function(arg1, arg2, arg3, arg4, arg5, arg6);
                };

            protected:
                wrapped_function_type _wrapped_function;

                static return_type default_function (arg1_type, 
                    arg2_type, 
                    arg3_type, 
                    arg4_type, 
                    arg5_type,
                    arg6_type) 
                {
                    throw unregistered_handler();
                };
            };

            template <typename arg1_type, 
                typename arg2_type, 
                typename arg3_type, 
                typename arg4_type,
                typename arg5_type,
                typename arg6_type
            >
            class functor_impl_6<void, 
                arg1_type, 
                arg2_type, 
                arg3_type,
                arg4_type,
                arg5_type,
                arg6_type
            > {

                BOOST_STATIC_ASSERT((!boost::is_same<arg1_type, void>::value));
                BOOST_STATIC_ASSERT((!boost::is_same<arg2_type, void>::value));
                BOOST_STATIC_ASSERT((!boost::is_same<arg3_type, void>::value));
                BOOST_STATIC_ASSERT((!boost::is_same<arg4_type, void>::value));
                BOOST_STATIC_ASSERT((!boost::is_same<arg5_type, void>::value));
                BOOST_STATIC_ASSERT((!boost::is_same<arg6_type, void>::value));

            public:
                typedef boost::function<void (arg1_type, 
                    arg2_type, 
                    arg3_type, 
                    arg4_type, 
                    arg5_type,
                    arg6_type)
                > wrapped_function_type;

				template <typename Sig>
				struct result {
					typedef void type;
				};

				typedef void result_type;

                functor_impl_6 () : _wrapped_function(default_function) { };

                void operator() (const arg1_type & arg1, 
                    const arg2_type & arg2, 
                    const arg3_type & arg3, 
                    const arg4_type & arg4, 
                    const arg5_type & arg5, 
                    const arg6_type & arg6)
                {
                    _wrapped_function(arg1, arg2, arg3, arg4, arg5, arg6);
                };

            protected:
                wrapped_function_type _wrapped_function;

                static void default_function (arg1_type, 
                    arg2_type, 
                    arg3_type, 
                    arg4_type, 
                    arg5_type, 
                    arg6_type)
                {
                    throw unregistered_handler();
                };
            };

        }; // namespace detail
    }; // namespace dispatch
}; // namespace boost

#endif
