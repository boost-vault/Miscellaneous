// Copyright 2006 (C) Dean Michael Berris <mikhailberis@gmail.com>
// Distributed under the Boost Software License, Version 1.0. (See accompanying
// file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)

#ifndef __DEFAULT_AGGREGATOR_HPP_
#define __DEFAULT_AGGREGATOR_HPP_

namespace boost { namespace dispatch { namespace detail {

    template <typename I>
    struct default_aggregator {
        void operator() (const I &) const { /* ... */ };
    };

    template <>
    struct default_aggregator<void> {
        void operator() ( int ) const { /* ... */ };
    };

}; }; };

#endif

