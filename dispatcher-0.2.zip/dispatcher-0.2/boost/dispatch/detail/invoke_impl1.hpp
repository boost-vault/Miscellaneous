// Copyright 2006 (C) Dean Michael Berris <mikhailberis@gmail.com>
// Distributed under the Boost Software License, Version 1.0. (See accompanying
// file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)

#ifndef __INVOKE_IMPL1_HPP_
#define __INVOKE_IMPL1_HPP_

#include <boost/function.hpp>
#include <boost/dispatch/dispatch_exceptions.hpp>
#include <boost/dispatch/detail/helper.hpp>
#include <boost/fusion/support/is_sequence.hpp>

namespace boost {
	namespace dispatch {
		namespace detail {

			namespace fusion = boost::fusion ;

			template <typename ReturnType, typename DispatcherType,
				typename arg1_type
			>
			struct invoke_impl_1_callable {
				typedef boost::function< void (typename DispatcherType::result_type) > aggregator_t;

				DispatcherType & _dispatcher;
				const aggregator_t _aggregator;
				fusion::tuple<arg1_type> args;

				invoke_impl_1_callable (
					DispatcherType & dispatcher,
					const aggregator_t & aggregator,
					const arg1_type & arg1)
					: _dispatcher(dispatcher),
					_aggregator(aggregator),
					args(arg1)
				{ /*...*/ };

			};

			template <typename DispatcherType,
				typename arg1_type
			>
			struct invoke_impl_1_callable <
				void,
				DispatcherType,
				arg1_type
			>
			{
				typedef boost::function< void ( int ) > aggregator_t;

				DispatcherType & _dispatcher;
				const aggregator_t _aggregator;
				fusion::tuple<arg1_type> args;

				invoke_impl_1_callable (
					DispatcherType & dispatcher,
					const aggregator_t & aggregator,
					const arg1_type & arg1)
					: _dispatcher(dispatcher),
					_aggregator(aggregator),
					args(arg1)
				{ /*...*/ };

			};

			template <typename ReturnType, typename DispatcherType,
				typename arg1_type
			>
			struct invoke_impl_1 {
				typedef boost::function< void (typename DispatcherType::result_type) > aggregator_t;

				DispatcherType & _dispatcher;
				aggregator_t _aggregator;

				invoke_impl_1 (
					DispatcherType & dispatcher,
					aggregator_t aggregator
					) : _dispatcher(dispatcher), _aggregator(aggregator)
				{ } ;

				invoke_impl_1_callable<ReturnType, DispatcherType, 
					arg1_type
				> operator()
				(const arg1_type & arg1) const {
					return 
						invoke_impl_1_callable<ReturnType, DispatcherType, arg1_type> (
						_dispatcher, _aggregator,
						arg1);
				};
			};

			template <typename DispatcherType, typename arg1_type>
			struct invoke_impl_1<void, DispatcherType, arg1_type> {
				typedef boost::function<void (int)> aggregator_t;

				DispatcherType & _dispatcher;
				aggregator_t _aggregator;

				invoke_impl_1 (
					DispatcherType & dispatcher,
					aggregator_t aggregator
					) : _dispatcher(dispatcher), _aggregator(default_aggregator<void>())
				{ } ;

				invoke_impl_1_callable<void, DispatcherType, arg1_type> operator()
					(const arg1_type & arg1) const {
						return invoke_impl_1_callable<void, DispatcherType, arg1_type> (
							_dispatcher, _aggregator,
							arg1
							)
							;
				};
			};

			template <typename ReturnType, typename DispatcherType, typename arg1_type, typename Sequence>
			inline invoke_impl_1_callable<ReturnType, DispatcherType, arg1_type> const & operator<< (
				invoke_impl_1_callable<ReturnType, DispatcherType, arg1_type> const & invoker,
				Sequence const & sequence) {
                helper::body_<
                    typename fusion::traits::is_sequence<Sequence>::type
                >::template impl<
                    ReturnType
                >::eval(invoker, sequence);
                return invoker;
			};

		}; // namespace detail
	}; // namespace dispatch
}; // namespace boost

#endif
