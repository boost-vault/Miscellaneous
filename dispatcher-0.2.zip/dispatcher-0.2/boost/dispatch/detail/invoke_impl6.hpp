// Copyright 2006 (C) Dean Michael Berris <mikhailberis@gmail.com>
// Distributed under the Boost Software License, Version 1.0. (See accompanying
// file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)

#ifndef __INVOKE_IMPL6_HPP_
#define __INVOKE_IMPL6_HPP_

#include <boost/function.hpp>
#include <boost/dispatch/dispatch_exceptions.hpp>
#include <boost/dispatch/detail/helper.hpp>

namespace boost {
    namespace dispatch {
        namespace detail {

			namespace fusion = boost::fusion ;

            template <typename ReturnType, typename DispatcherType,
                typename arg1_type,
                typename arg2_type,
                typename arg3_type,
                typename arg4_type,
                typename arg5_type,
                typename arg6_type
            > 
            struct invoke_impl_6_callable {
                typedef boost::function< void (ReturnType) > aggregator_t;
                DispatcherType & _dispatcher;
                const aggregator_t & _aggregator;
				fusion::tuple<arg1_type, arg2_type, arg3_type, arg4_type, arg5_type, arg6_type> args;

                invoke_impl_6_callable 
                    ( DispatcherType & dispatcher,
                    const aggregator_t & aggregator,
                    const arg1_type & arg1,
                    const arg2_type & arg2,
                    const arg3_type & arg3,
                    const arg4_type & arg4,
                    const arg5_type & arg5,
                    const arg6_type & arg6 ) 
                    : _dispatcher(dispatcher),
                    _aggregator(aggregator),
                    args(arg1, arg2, arg3, arg4, arg5, arg6)
                { /*...*/ };

            };

            template <typename DispatcherType,
                typename arg1_type,
                typename arg2_type,
                typename arg3_type,
                typename arg4_type,
                typename arg5_type,
                typename arg6_type
            > 
            struct invoke_impl_6_callable <
                void,
                DispatcherType,
                arg1_type,
                arg2_type,
                arg3_type,
                arg4_type,
                arg5_type,
                arg6_type
            >
            {
                typedef boost::function< void (int) > aggregator_t;
                DispatcherType & _dispatcher;
                const aggregator_t & _aggregator;
				fusion::tuple<arg1_type, arg2_type, arg3_type, arg4_type, arg5_type, arg6_type> args;

                invoke_impl_6_callable 
                    ( DispatcherType & dispatcher,
                    const aggregator_t & aggregator,
                    const arg1_type & arg1,
                    const arg2_type & arg2,
                    const arg3_type & arg3,
                    const arg4_type & arg4,
                    const arg5_type & arg5,
                    const arg6_type & arg6 ) 
                    : _dispatcher(dispatcher),
                    _aggregator(aggregator),
					args(arg1, arg2, arg3, arg4, arg5, arg6)
                { /*...*/ };

            };

            template <typename ReturnType, typename DispatcherType,
                typename arg1_type,
                typename arg2_type,
                typename arg3_type,
                typename arg4_type,
                typename arg5_type,
                typename arg6_type
            >
            struct invoke_impl_6 {
                typedef typename DispatcherType::index_type index_type;
                typedef boost::function< void (typename DispatcherType::result_type) > aggregator_t;

                DispatcherType & _dispatcher;
                aggregator_t _aggregator;

                invoke_impl_6 (
                    DispatcherType & dispatcher,
                    aggregator_t aggregator
                    ) : _dispatcher(dispatcher), _aggregator(aggregator)
                { } ;

                invoke_impl_6_callable<ReturnType, DispatcherType, 
                    arg1_type, 
                    arg2_type,
                    arg3_type,
                    arg4_type,
                    arg5_type,
                    arg6_type
                > operator()
                    (const arg1_type & arg1, 
                    const arg2_type & arg2,
                    const arg3_type & arg3,
                    const arg4_type & arg4,
                    const arg5_type & arg5,
                    const arg6_type & arg6) const {
                        return 
                            invoke_impl_6_callable <
                                ReturnType,
                                DispatcherType,
                                arg1_type,
                                arg2_type,
                                arg3_type,
                                arg4_type,
                                arg5_type,
                                arg6_type> (
                                    _dispatcher,
                                    _aggregator,
                                    arg1,
                                    arg2,
                                    arg3,
                                    arg4,
                                    arg5,
                                    arg6
                                    )
                            ;
                };
            };

            template <typename DispatcherType,
                typename arg1_type,
                typename arg2_type,
                typename arg3_type,
                typename arg4_type,
                typename arg5_type,
                typename arg6_type
            >
            struct invoke_impl_6<void, DispatcherType, 
                arg1_type, 
                arg2_type,
                arg3_type,
                arg4_type,
                arg5_type,
                arg6_type
            > {
                typedef typename DispatcherType::index_type index_type;
                typedef boost::function<void (int)> aggregator_t;

                DispatcherType & _dispatcher;
                aggregator_t _aggregator;

                invoke_impl_6 (
                    DispatcherType & dispatcher,
                    aggregator_t aggregator
                    ) : _dispatcher(dispatcher), _aggregator(default_aggregator<void>())
                { } ;

                invoke_impl_6_callable<void, DispatcherType, 
                    arg1_type, 
                    arg2_type,
                    arg3_type,
                    arg4_type,
                    arg5_type,
                    arg6_type
                > operator()
                    (const arg1_type & arg1, 
                    const arg2_type & arg2,
                    const arg3_type & arg3,
                    const arg4_type & arg4,
                    const arg5_type & arg5,
                    const arg6_type & arg6) const {
                        return 
                            invoke_impl_6_callable <
                                void,
                                DispatcherType,
                                arg1_type,
                                arg2_type,
                                arg3_type,
                                arg4_type,
                                arg5_type,
                                arg6_type> (
                                    _dispatcher,
                                    _aggregator,
                                    arg1,
                                    arg2,
                                    arg3,
                                    arg4,
                                    arg5,
                                    arg6
                                    )
                            ;
                };
            };

			template <typename ReturnType, typename DispatcherType, typename arg1_type, typename arg2_type, typename arg3_type, typename arg4_type, typename arg5_type, typename arg6_type, typename Sequence>
			inline invoke_impl_6_callable<ReturnType, DispatcherType, arg1_type, arg2_type, arg3_type, arg4_type, arg5_type, arg6_type> const & operator<< (
				invoke_impl_6_callable<ReturnType, DispatcherType, arg1_type, arg2_type, arg3_type, arg4_type, arg5_type, arg6_type> const & invoker,
				Sequence const & sequence) {
                helper::body_<
                    typename fusion::traits::is_sequence<Sequence>::type
                >::template impl<
                    ReturnType
                >::eval(invoker, sequence);
                return invoker;
			};

        }; // namespace detail
    }; // namespace dispatch
}; // namespace boost

#endif
