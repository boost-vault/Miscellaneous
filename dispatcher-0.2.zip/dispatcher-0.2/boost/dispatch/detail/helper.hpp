// Copyright 2006 (C) Dean Michael Berris <mikhailberis@gmail.com>
// Distributed under the Boost Software License, Version 1.0. (See accompanying
// file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)

#ifndef __INVOKER_HELPER_HPP_
#define __INVOKER_HELPER_HPP_

#include <boost/fusion/tuple.hpp>
#include <boost/fusion/functional.hpp>
#include <boost/fusion/algorithm/iteration/for_each.hpp>
#include <boost/fusion/support/is_sequence.hpp>

namespace boost { namespace dispatch { namespace detail { namespace helper {

	namespace fusion = boost::fusion;

	struct short_circuit { };

	template <typename InvokerType>
	struct invoke_if_found_no_aggregate_impl {
		InvokerType const & _invoker;
		explicit invoke_if_found_no_aggregate_impl(InvokerType const & invoker)
			: _invoker(invoker) { };
		template <typename T>
		void operator() (T const & index) const {
			if (_invoker._dispatcher.find(index) != _invoker._dispatcher.end()) {
				fusion::invoke(
					_invoker._dispatcher[index],
					_invoker.args
					);
				throw short_circuit();
			};
		};
	};

	template <typename InvokerType>
	inline invoke_if_found_no_aggregate_impl<InvokerType>
		invoke_if_found_no_aggregate(InvokerType const & invoker) {
			return invoke_if_found_no_aggregate_impl<InvokerType>(invoker);
	};

	template <typename InvokerType>
	struct invoke_if_found_with_aggregate_impl {
		InvokerType const & _invoker;
		explicit invoke_if_found_with_aggregate_impl(InvokerType const & invoker)
			: _invoker(invoker) { };
		template <typename T>
		void operator() (T const & index) const {
			if (_invoker._dispatcher.find(index) != _invoker._dispatcher.end()) {
				_invoker._aggregator(
					fusion::invoke(
						_invoker._dispatcher[index],
						_invoker.args
						)
					);
				throw short_circuit();
			};
		};
	};

	template <typename InvokerType>
	inline invoke_if_found_with_aggregate_impl<InvokerType>
		invoke_if_found_with_aggregate(InvokerType const & invoker) {
			return invoke_if_found_with_aggregate_impl<InvokerType>(invoker);
	};

    namespace mpl = boost::mpl;

    namespace impl_sequence {
        template <class ReturnType>
            struct eval_impl {
                
                template <class InvokerType, class Sequence>
                    static void eval(InvokerType const & invoker, Sequence const & sequence) {
                        try {
                            fusion::for_each(
                                sequence, 
                                invoke_if_found_with_aggregate(invoker)
                                );
                            throw unregistered_handler();
                        } catch (typename helper::short_circuit &) { };
                    };
                
            };

        template <>
            struct eval_impl<void> {
                
                template <class InvokerType, class Sequence>
                    static void eval(InvokerType const & invoker, Sequence const & sequence) {
                        try {
                            fusion::for_each(
                                    sequence,
                                    invoke_if_found_no_aggregate(invoker)
                                    );
                            throw unregistered_handler();
                        } catch (typename helper::short_circuit &) { };
                    };

            };
    }; // namespace impl_sequence

    namespace impl_single {
        template <class ReturnType>
            struct eval_impl {
                template <class InvokerType, typename IndexType>
                    static void eval(InvokerType const & invoker, IndexType const & index) {
                        invoker._aggregator(
                                fusion::invoke(
                                    invoker._dispatcher[index],
                                    invoker.args
                                    )
                                );
                    };
            };

        template <>
            struct eval_impl<void> {
                template <class InvokerType, typename IndexType>
                    static void eval(InvokerType const & invoker, IndexType const & index) {
                        fusion::invoke(
                                invoker._dispatcher[index],
                                invoker.args
                                );
                    };
            };
    }; // namespace impl_single

    template <typename Impl>
        struct body_ { // deal with a sequence!
            template <class ReturnType>
                struct impl : impl_sequence::eval_impl<ReturnType> { };
        };

    template <>
        struct body_<mpl::false_> { // dealing with a non-sequence
            template <class ReturnType>
                struct impl : impl_single::eval_impl<ReturnType> { };
        };
    
}; // namespace helper

}; // namespace detail

}; // namespace dispatch

}; // namespace boost

#endif
