// Copyright 2006,2007 (C) Dean Michael Berris <mikhailberis@gmail.com>
// Distributed under the Boost Software License, Version 1.0. (See accompanying
// file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)
#ifndef __DISPATCHER_ALTERNATOR_HPP__
#define __DISPATCHER_ALTERNATOR_HPP__

#include <boost/fusion/tuple.hpp>
#include <boost/preprocessor/repetition.hpp>
#include <boost/preprocessor/repetition/enum.hpp>
#include <boost/preprocessor/iteration/local.hpp>

namespace boost { namespace dispatch {

    namespace fusion = boost::fusion ;

    template <typename T>
		fusion::tuple<T, T> alt_(T const & arg1, T const & arg2) {
			return fusion::make_tuple(arg1, arg2);
        };

#define ALT_print(z, n, data) data
#define ALT_function(z, n, unused) \
    template <typename T> \
	fusion::tuple<BOOST_PP_ENUM(n, ALT_print, T)> \
        alt_(BOOST_PP_ENUM_PARAMS(n, T const & arg)) { \
			return fusion::make_tuple( BOOST_PP_ENUM_PARAMS(n, arg) ); \
        }; \
    /***/

#define BOOST_PP_LOCAL_MACRO(n) ALT_function(~, n, ~)
#define BOOST_PP_LOCAL_LIMITS   (3,10)
#include BOOST_PP_LOCAL_ITERATE()

#undef ALT_print
#undef ALT_function

}; // namespace dispatch

}; // namespace dispatch

#endif
