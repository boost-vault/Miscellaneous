// Copyright 2006 (C) Dean Michael Berris <mikhailberis@gmail.com>
// Distributed under the Boost Software License, Version 1.0. (See accompanying
// file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)

#ifndef __INVOKE_HPP__
#define __INVOKE_HPP__

#include <boost/type_traits/function_traits.hpp>
#include <boost/dispatch/detail/invoke_impl0.hpp>
#include <boost/dispatch/detail/invoke_impl1.hpp>
#include <boost/dispatch/detail/invoke_impl2.hpp>
#include <boost/dispatch/detail/invoke_impl3.hpp>
#include <boost/dispatch/detail/invoke_impl4.hpp>
#include <boost/dispatch/detail/invoke_impl5.hpp>
#include <boost/dispatch/detail/invoke_impl6.hpp>
#include <boost/dispatch/detail/default_aggregator.hpp>

#include <boost/dispatch/alt.hpp>

namespace boost {
    namespace dispatch {
        namespace detail {

            template <  int Arity, typename DispatcherType, typename Signature >
            struct get_real_invoke_impl;

            template < typename DispatcherType, typename Signature >
            struct get_real_invoke_impl <0, DispatcherType, Signature> {
                typedef invoke_impl_0<
                    typename DispatcherType::result_type,
                    DispatcherType
                > type;
            };

            template < typename DispatcherType, typename Signature >
            struct get_real_invoke_impl <1, DispatcherType, Signature> {
                typedef boost::function_traits<Signature> traits;
                typedef invoke_impl_1<
                    typename DispatcherType::result_type,
                    DispatcherType,
                    typename traits::arg1_type
                > type;
            };

            template < typename DispatcherType, typename Signature >
            struct get_real_invoke_impl <2, DispatcherType, Signature> {
                typedef boost::function_traits<Signature> traits;
                typedef invoke_impl_2<
                    typename DispatcherType::result_type,
                    DispatcherType,
                    typename traits::arg1_type,
                    typename traits::arg2_type
                > type;
            };

            template < typename DispatcherType, typename Signature >
            struct get_real_invoke_impl <3, DispatcherType, Signature> {
                typedef boost::function_traits<Signature> traits;
                typedef invoke_impl_3<
                    typename DispatcherType::result_type,
                    DispatcherType,
                    typename traits::arg1_type,
                    typename traits::arg2_type,
                    typename traits::arg3_type
                > type;
            };

            template < typename DispatcherType, typename Signature >
            struct get_real_invoke_impl <4, DispatcherType, Signature> {
                typedef boost::function_traits<Signature> traits;
                typedef invoke_impl_4<
                    typename DispatcherType::result_type,
                    DispatcherType,
                    typename traits::arg1_type,
                    typename traits::arg2_type,
                    typename traits::arg3_type,
                    typename traits::arg4_type
                > type;
            };

            template < typename DispatcherType, typename Signature >
            struct get_real_invoke_impl <5, DispatcherType, Signature> {
                typedef boost::function_traits<Signature> traits;
                typedef invoke_impl_5<
                    typename DispatcherType::result_type,
                    DispatcherType,
                    typename traits::arg1_type,
                    typename traits::arg2_type,
                    typename traits::arg3_type,
                    typename traits::arg4_type,
                    typename traits::arg5_type
                > type;
            };

            template < typename DispatcherType, typename Signature >
            struct get_real_invoke_impl <6, DispatcherType, Signature> {
                typedef boost::function_traits<Signature> traits;
                typedef invoke_impl_6<
                    typename DispatcherType::result_type,
                    DispatcherType,
                    typename traits::arg1_type,
                    typename traits::arg2_type,
                    typename traits::arg3_type,
                    typename traits::arg4_type,
                    typename traits::arg5_type,
                    typename traits::arg6_type
                > type;
            };

            template <typename DispatcherType>
            struct get_invoke_impl {
                typedef typename get_real_invoke_impl<
                    boost::function_traits<typename DispatcherType::signature>::arity,
                    DispatcherType,
                    typename DispatcherType::signature
                >::type type;
				typedef DispatcherType dispatcher_type;
            };

        }; // namespace detail

        /*
        template <typename T>
        struct invoke_ : detail::get_invoke_impl<T>::type {
            typedef typename detail::get_invoke_impl<T>::type base_type ;
            invoke_ (T & dispatcher, 
                boost::function< void (typename T::index_type) > f 
                = detail::default_aggregator<typename T::result_type>())
                : base_type (dispatcher, f)
            { };
        };*/

        template <typename DispatcherType> 
            inline typename detail::get_invoke_impl<DispatcherType>::type 
            invoke_(DispatcherType & dispatcher) { 
                return typename detail::get_invoke_impl<DispatcherType>::type 
					(dispatcher, detail::default_aggregator<typename DispatcherType::result_type>());
            };

        template <typename DispatcherType, typename AggregatorType>
            inline typename detail::get_invoke_impl<DispatcherType>::type
            invoke_(DispatcherType & dispatcher, 
                    AggregatorType aggregator) {
                return typename detail::get_invoke_impl<DispatcherType>::type(dispatcher, boost::function<void(typename DispatcherType::result_type)>(aggregator));
            };

    }; // namespace dispatch
}; // namespace boost

#endif
