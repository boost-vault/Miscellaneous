// Copyright 2006 (C) Dean Michael Berris <mikhailberis@gmail.com>
// Distributed under the Boost Software License, Version 1.0. (See accompanying
// file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)

#ifndef __DISPATCH_HELPER_HPP_
#define __DISPATCH_HELPER_HPP_

#include <boost/static_assert.hpp>
#include <boost/type_traits/is_same.hpp>
#include <boost/type_traits/function_traits.hpp>
#include <boost/dispatch/functor0.hpp>
#include <boost/dispatch/functor1.hpp>
#include <boost/dispatch/functor2.hpp>
#include <boost/dispatch/functor3.hpp>
#include <boost/dispatch/functor4.hpp>
#include <boost/dispatch/functor5.hpp>
#include <boost/dispatch/functor6.hpp>
#include <boost/dispatch/dispatch_exceptions.hpp>

namespace boost {
    namespace dispatch {
        namespace detail {

            using boost::function_traits;

            template <int ArgumentCount, typename Signature>
            class get_functor_impl;

            template <typename Signature>
            class get_functor_impl<0, Signature> {
                typedef function_traits<Signature> traits;

            public:
                typedef functor_impl_0<typename traits::result_type> type;
            };

            template <typename Signature>
            class get_functor_impl<1, Signature> {
                typedef function_traits<Signature> traits;

            public:
                typedef functor_impl_1<typename traits::result_type, 
                    typename traits::arg1_type
                > type;
            };

            template <typename Signature>
            class get_functor_impl<2, Signature> {
                typedef function_traits<Signature> traits;

            public:
                typedef functor_impl_2<typename traits::result_type, 
                    typename traits::arg1_type, 
                    typename traits::arg2_type
                > type;
            };

            template <typename Signature>
            class get_functor_impl<3, Signature> {
                typedef function_traits<Signature> traits;

            public:
                typedef functor_impl_3<typename traits::result_type, typename traits::arg1_type,
                    typename traits::arg2_type,
                    typename traits::arg3_type
                > type;
            };

            template <typename Signature>
            class get_functor_impl<4, Signature> {
                typedef function_traits<Signature> traits;

            public:
                typedef functor_impl_4<typename traits::result_type,
                    typename traits::arg1_type,
                    typename traits::arg2_type,
                    typename traits::arg3_type,
                    typename traits::arg4_type
                > type;
            };

            template <typename Signature>
            class get_functor_impl<5, Signature> {
                typedef function_traits<Signature> traits;

            public:
                typedef functor_impl_5<typename traits::result_type,
                    typename traits::arg1_type,
                    typename traits::arg2_type,
                    typename traits::arg3_type,
                    typename traits::arg4_type,
                    typename traits::arg5_type
                > type;
            };

            template <typename Signature>
            class get_functor_impl<6, Signature> {
                typedef function_traits<Signature> traits;

            public:
                typedef functor_impl_6 <typename traits::result_type,
                    typename traits::arg1_type,
                    typename traits::arg2_type,
                    typename traits::arg3_type,
                    typename traits::arg4_type,
                    typename traits::arg5_type,
                    typename traits::arg6_type
                > type;
            };

        }; // namespace detail

        template <typename Signature>
        class functor : public detail::get_functor_impl <
            boost::function_traits<Signature>::arity, 
            Signature
        >::type
        {
        protected:
            typedef typename detail::get_functor_impl <
                boost::function_traits<Signature>::arity, 
                Signature
            >::type base_type;

            typedef typename base_type::wrapped_function_type function_type;

        public:

            functor<Signature> & operator= (const function_type & rhs) {
                base_type::_wrapped_function = rhs;
                return *this;
            };
        };				

    }; // namespace dispatch
}; // namespace boost
#endif
