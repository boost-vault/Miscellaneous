// Copyright 2006 (C) Dean Michael Berris <mikhailberis@gmail.com>
// Distributed under the Boost Software License, Version 1.0. (See accompanying
// file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)

#ifndef __STRATEGIZED_MAP_HPP__
#define __STRATEGIZED_MAP_HPP__

#include <map>
#include <boost/mpl/if.hpp>
#include <boost/type_traits/is_same.hpp>

namespace boost {
    namespace detail {

        ///////////////////////////////////////////////////////////////////////////
        // Strategized Map Implementation
        ///////////////////////////////////////////////////////////////////////////
        template <typename KeyType, 
            typename ValueType, 
            typename RoutingStrategy
        >
        struct strategized_map_impl {
        private :
            // Internal instance of a normal sorted map
            std::map<KeyType, ValueType> _map;

            // Internal instance of the RoutingStrategy
            RoutingStrategy _strategy;

        public:
            // Typedef to the iterator types
            typedef std::map<KeyType, ValueType> map_type;
            typedef typename map_type::iterator iterator;
            typedef typename map_type::const_iterator const_iterator;

            // Default Constructor
            inline strategized_map_impl () { };

            // Constructor which takes arguments for the internal
            // routing strategy. Does type deduction and forwarding
            template <typename T0>
            inline explicit strategized_map_impl (T0 const & arg1)
                : _strategy(arg1) { };

            template <typename T0>
            inline explicit strategized_map_impl (T0 & arg1)
                : _strategy(arg1) { };

            // Constructor Overloads.
            template <typename T0, typename T1>
            inline strategized_map_impl (T0 const & arg1, T1 const & arg2)
            : _strategy(arg1, arg2) { };

            template <typename T0, typename T1>
            inline strategized_map_impl (T0 const & arg1, T1 & arg2)
            : _strategy(arg1, arg2) { };

            template <typename T0, typename T1>
            inline strategized_map_impl (T0 & arg1, T1 const & arg2)
            : _strategy(arg1, arg2) { };

            template <typename T0, typename T1>
            inline strategized_map_impl (T0 & arg1, T1 & arg2)
            : _strategy(arg1, arg2) { };

            // TODO: add more constructor overloads
            // Use Boost.PP ?

            // Forwarding Index Operator which invokes
            // the Routing Strategy on the key.
            inline ValueType & operator[] (KeyType const & key) {
                return _map[_strategy(key)];
            };

            // Forwarding `insert' which invokes
            // the Routing Strategy on the key.
            // FIXME: how to get away from "copy" ?
            inline void insert (std::pair<KeyType, ValueType> element) {
                element.first=_strategy(element.first);
                _map.insert(element);
            };

            // Forwarding `erase' which invokes
            // the Routing Strategy on the key.
            inline void erase (KeyType const & key) {
                _map.erase(_strategy(key));
            };

            // Forwarding `begin' returns a copy
            // of the iterator.
            inline iterator begin() {
                return _map.begin();
            };

            // Forwarding `end' returns a copy
            // of the iterator
            inline iterator end() {
                return _map.end();
            };

            // Forwarding `begin' returns a copy
            // of the const_iterator
            const_iterator begin() const {
                return _map.begin();
            };

            // Forwarding `end' returns a copy
            // of the const_iterator
            const_iterator end() const {
                return _map.end();
            };

            // Forwarding `find' returns a copy
            // of the iterator
            inline iterator find (KeyType const & key) {
                return _map.find(_strategy(key));
            };

            // Forwarding `find' returns a copy
            // of the const_iterator
            const_iterator find(KeyType const & key) const {
                return _map.find(_strategy(key));
            };

            // Forwarding `clear'
            inline void clear () {
                _map.clear();
            };

            // Strategy instance reference
            inline RoutingStrategy & strategy () {
                return _strategy;
            };

            // Forwarding `size'
            typename map_type::size_type size() const {
                return _map.size();
            };

        };

        namespace traits = boost::type_traits;
        namespace mpl = boost::mpl;

        // forwarding metafunction
        template <typename KeyType, typename ValueType, typename RoutingStrategy>
        struct get_strat_map_impl {
            typedef typename mpl::if_<
                boost::is_same<RoutingStrategy, void >,
                std::map<KeyType, ValueType>,
                strategized_map_impl<KeyType, ValueType, RoutingStrategy>
            >::type type;
        };

    }; // namespace detail

    template <typename KeyType, 
        typename ValueType, 
        typename RoutingStrategy = void
    >
    struct strategized_map : detail::get_strat_map_impl<KeyType, ValueType, RoutingStrategy>::type {
        typedef typename detail::get_strat_map_impl<KeyType, ValueType, RoutingStrategy>::type base;

        inline strategized_map() : base() { };

        template <typename T0>
        inline explicit strategized_map(T0 const & arg1) : base(arg1) { };

        template <typename T0>
        inline explicit strategized_map(T0 & arg1) : base(arg1) { };

        template <typename T0, typename T1>
        inline explicit strategized_map(T0 const & arg1, T1 const & arg2) : base(arg1, arg2) { };

        template <typename T0, typename T1>
        inline explicit strategized_map(T0 & arg1, T1 & arg2) : base(arg1, arg2) { };

        template <typename T0, typename T1>
        inline explicit strategized_map(T0 & arg1, T1 const & arg2) : base(arg1, arg2) { };

        template <typename T0, typename T1>
        inline explicit strategized_map(T0 const & arg1, T1 & arg2) : base(arg1, arg2) { };

        // TODO: add more constructor overloads
        // Use Boost.PP ?
    };

}; // namespace boost

#endif

