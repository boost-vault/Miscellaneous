// Copyright 2006 (C) Dean Michael Berris <mikhailberis@gmail.com>
// Distributed under the Boost Software License, Version 1.0. (See accompanying
// file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)

#define BOOST_AUTO_TEST_MAIN
#include <boost/test/auto_unit_test.hpp>
#include <boost/bind.hpp>
#include <string>

#include <boost/dispatch.hpp>

void function() {
};

void function_1(int) {
};

void function_2(int, int) {
};

void function_3(int, int, int) {
};

void function_4(int, int, int, int) {
};

void function_5(int, int, int, int, int) {
};

void function_6(int, int, int, int, int, int) {
};

int int_function () {
    return 1;
};

int int_function_1 (int i) {
	return i;
};

int int_function_2 (int i, int j) {
	return i + j;
};

int int_function_3 (int i, int j, int k) {
	return i + j + k;
};

int int_function_4 (int i, int j, int k, int l) {
	return i + j + k + l;
};

int int_function_5 (int i, int j, int k, int l, int m) {
	return i + j + k + l + m;
};

int int_function_6 (int i, int j, int k, int l, int m, int n) {
	return i + j + k + l + m + n;
};

BOOST_AUTO_TEST_CASE ( invoke_alternative_basic ) {
    using namespace boost::dispatch ;
    dispatcher<void()> d;
    d[0] = function;
    BOOST_CHECK_NO_THROW ( invoke_(d)() << alt_(1, 0); );
};

BOOST_AUTO_TEST_CASE ( invoke_alternative_compound ) {
    using namespace boost::dispatch ;
    dispatcher<void()> d;
    d[0] = function;
    BOOST_CHECK_NO_THROW ( invoke_(d)() << alt_(1, 0) << 0 ; );
};

BOOST_AUTO_TEST_CASE ( invoke_alternative_variadic ) {
    using namespace boost::dispatch ;
    dispatcher<void()> d;
    d[9] = function;
	BOOST_CHECK_NO_THROW ( invoke_(d)() << alt_(8, 9); );
    BOOST_CHECK_NO_THROW ( invoke_(d)() << alt_(7, 8, 9); );
    BOOST_CHECK_NO_THROW ( invoke_(d)() << alt_(6, 7, 8, 9); );
    BOOST_CHECK_NO_THROW ( invoke_(d)() << alt_(5, 6, 7, 8, 9); );
    BOOST_CHECK_NO_THROW ( invoke_(d)() << alt_(4, 5, 6, 7, 8, 9); );
    BOOST_CHECK_NO_THROW ( invoke_(d)() << alt_(3, 4, 5, 6, 7, 8, 9); );
    BOOST_CHECK_NO_THROW ( invoke_(d)() << alt_(2, 3, 4, 5, 6, 7, 8, 9); );
    BOOST_CHECK_NO_THROW ( invoke_(d)() << alt_(1, 2, 3, 4, 5, 6, 7, 8, 9); );
    BOOST_CHECK_NO_THROW ( invoke_(d)() << alt_(0, 1, 2, 3, 4, 5, 6, 7, 8, 9); );

    dispatcher<void(int)> d1;
    d1[9] = function_1;
    BOOST_CHECK_NO_THROW ( invoke_(d1)(1) << alt_(8, 9); );
    BOOST_CHECK_NO_THROW ( invoke_(d1)(1) << alt_(7, 8, 9); );
    BOOST_CHECK_NO_THROW ( invoke_(d1)(1) << alt_(6, 7, 8, 9); );
    BOOST_CHECK_NO_THROW ( invoke_(d1)(1) << alt_(5, 6, 7, 8, 9); );
    BOOST_CHECK_NO_THROW ( invoke_(d1)(1) << alt_(4, 5, 6, 7, 8, 9); );
    BOOST_CHECK_NO_THROW ( invoke_(d1)(1) << alt_(3, 4, 5, 6, 7, 8, 9); );
    BOOST_CHECK_NO_THROW ( invoke_(d1)(1) << alt_(2, 3, 4, 5, 6, 7, 8, 9); );
    BOOST_CHECK_NO_THROW ( invoke_(d1)(1) << alt_(1, 2, 3, 4, 5, 6, 7, 8, 9); );
    BOOST_CHECK_NO_THROW ( invoke_(d1)(1) << alt_(0, 1, 2, 3, 4, 5, 6, 7, 8, 9); );

	dispatcher<void(int, int)> d2;
	d2[9] = function_2;
	BOOST_CHECK_NO_THROW ( invoke_(d2)(1, 2) << alt_(8, 9); );
	BOOST_CHECK_NO_THROW ( invoke_(d2)(1, 2) << alt_(7, 8, 9); );
    BOOST_CHECK_NO_THROW ( invoke_(d2)(1, 2) << alt_(6, 7, 8, 9); );
    BOOST_CHECK_NO_THROW ( invoke_(d2)(1, 2) << alt_(5, 6, 7, 8, 9); );
    BOOST_CHECK_NO_THROW ( invoke_(d2)(1, 2) << alt_(4, 5, 6, 7, 8, 9); );
    BOOST_CHECK_NO_THROW ( invoke_(d2)(1, 2) << alt_(3, 4, 5, 6, 7, 8, 9); );
    BOOST_CHECK_NO_THROW ( invoke_(d2)(1, 2) << alt_(2, 3, 4, 5, 6, 7, 8, 9); );
    BOOST_CHECK_NO_THROW ( invoke_(d2)(1, 2) << alt_(1, 2, 3, 4, 5, 6, 7, 8, 9); );
    BOOST_CHECK_NO_THROW ( invoke_(d2)(1, 2) << alt_(0, 1, 2, 3, 4, 5, 6, 7, 8, 9); );

	dispatcher<void(int, int, int)> d3;
	d3[9] = function_3;
	BOOST_CHECK_NO_THROW ( invoke_(d3)(1, 2, 3) << alt_(8, 9); );
	BOOST_CHECK_NO_THROW ( invoke_(d3)(1, 2, 3) << alt_(7, 8, 9); );
    BOOST_CHECK_NO_THROW ( invoke_(d3)(1, 2, 3) << alt_(6, 7, 8, 9); );
    BOOST_CHECK_NO_THROW ( invoke_(d3)(1, 2, 3) << alt_(5, 6, 7, 8, 9); );
    BOOST_CHECK_NO_THROW ( invoke_(d3)(1, 2, 3) << alt_(4, 5, 6, 7, 8, 9); );
    BOOST_CHECK_NO_THROW ( invoke_(d3)(1, 2, 3) << alt_(3, 4, 5, 6, 7, 8, 9); );
    BOOST_CHECK_NO_THROW ( invoke_(d3)(1, 2, 3) << alt_(2, 3, 4, 5, 6, 7, 8, 9); );
    BOOST_CHECK_NO_THROW ( invoke_(d3)(1, 2, 3) << alt_(1, 2, 3, 4, 5, 6, 7, 8, 9); );
    BOOST_CHECK_NO_THROW ( invoke_(d3)(1, 2, 3) << alt_(0, 1, 2, 3, 4, 5, 6, 7, 8, 9); );

	dispatcher<void(int, int, int, int)> d4;
	d4[9] = function_4;
	BOOST_CHECK_NO_THROW ( invoke_(d4)(1, 2, 3, 4) << alt_(8, 9); );
	BOOST_CHECK_NO_THROW ( invoke_(d4)(1, 2, 3, 4) << alt_(7, 8, 9); );
    BOOST_CHECK_NO_THROW ( invoke_(d4)(1, 2, 3, 4) << alt_(6, 7, 8, 9); );
    BOOST_CHECK_NO_THROW ( invoke_(d4)(1, 2, 3, 4) << alt_(5, 6, 7, 8, 9); );
    BOOST_CHECK_NO_THROW ( invoke_(d4)(1, 2, 3, 4) << alt_(4, 5, 6, 7, 8, 9); );
    BOOST_CHECK_NO_THROW ( invoke_(d4)(1, 2, 3, 4) << alt_(3, 4, 5, 6, 7, 8, 9); );
    BOOST_CHECK_NO_THROW ( invoke_(d4)(1, 2, 3, 4) << alt_(2, 3, 4, 5, 6, 7, 8, 9); );
    BOOST_CHECK_NO_THROW ( invoke_(d4)(1, 2, 3, 4) << alt_(1, 2, 3, 4, 5, 6, 7, 8, 9); );
    BOOST_CHECK_NO_THROW ( invoke_(d4)(1, 2, 3, 4) << alt_(0, 1, 2, 3, 4, 5, 6, 7, 8, 9); );

	dispatcher<void(int, int, int, int, int)> d5;
	d5[9] = function_5;
	BOOST_CHECK_NO_THROW ( invoke_(d5)(1, 2, 3, 4, 5) << alt_(8, 9); );
	BOOST_CHECK_NO_THROW ( invoke_(d5)(1, 2, 3, 4, 5) << alt_(7, 8, 9); );
    BOOST_CHECK_NO_THROW ( invoke_(d5)(1, 2, 3, 4, 5) << alt_(6, 7, 8, 9); );
    BOOST_CHECK_NO_THROW ( invoke_(d5)(1, 2, 3, 4, 5) << alt_(5, 6, 7, 8, 9); );
    BOOST_CHECK_NO_THROW ( invoke_(d5)(1, 2, 3, 4, 5) << alt_(4, 5, 6, 7, 8, 9); );
    BOOST_CHECK_NO_THROW ( invoke_(d5)(1, 2, 3, 4, 5) << alt_(3, 4, 5, 6, 7, 8, 9); );
    BOOST_CHECK_NO_THROW ( invoke_(d5)(1, 2, 3, 4, 5) << alt_(2, 3, 4, 5, 6, 7, 8, 9); );
    BOOST_CHECK_NO_THROW ( invoke_(d5)(1, 2, 3, 4, 5) << alt_(1, 2, 3, 4, 5, 6, 7, 8, 9); );
    BOOST_CHECK_NO_THROW ( invoke_(d5)(1, 2, 3, 4, 5) << alt_(0, 1, 2, 3, 4, 5, 6, 7, 8, 9); );

	dispatcher<void(int, int, int, int, int, int)> d6;
	d6[9] = function_6;
	BOOST_CHECK_NO_THROW ( invoke_(d6)(1, 2, 3, 4, 5, 6) << alt_(8, 9); );
	BOOST_CHECK_NO_THROW ( invoke_(d6)(1, 2, 3, 4, 5, 6) << alt_(7, 8, 9); );
    BOOST_CHECK_NO_THROW ( invoke_(d6)(1, 2, 3, 4, 5, 6) << alt_(6, 7, 8, 9); );
    BOOST_CHECK_NO_THROW ( invoke_(d6)(1, 2, 3, 4, 5, 6) << alt_(5, 6, 7, 8, 9); );
    BOOST_CHECK_NO_THROW ( invoke_(d6)(1, 2, 3, 4, 5, 6) << alt_(4, 5, 6, 7, 8, 9); );
    BOOST_CHECK_NO_THROW ( invoke_(d6)(1, 2, 3, 4, 5, 6) << alt_(3, 4, 5, 6, 7, 8, 9); );
    BOOST_CHECK_NO_THROW ( invoke_(d6)(1, 2, 3, 4, 5, 6) << alt_(2, 3, 4, 5, 6, 7, 8, 9); );
    BOOST_CHECK_NO_THROW ( invoke_(d6)(1, 2, 3, 4, 5, 6) << alt_(1, 2, 3, 4, 5, 6, 7, 8, 9); );
    BOOST_CHECK_NO_THROW ( invoke_(d6)(1, 2, 3, 4, 5, 6) << alt_(0, 1, 2, 3, 4, 5, 6, 7, 8, 9); );
};

BOOST_AUTO_TEST_CASE ( invoke_alternative_variadic_aggregating ) {
    using namespace boost::dispatch;
    std::vector<int> _vector;
    dispatcher<int()> d;
    d[9] = int_function ;
    boost::function<void(int)> aggregator(boost::bind(&std::vector<int>::push_back, &_vector, _1));
	BOOST_CHECK_NO_THROW ( invoke_(d, aggregator)() << alt_(8, 9) );
	BOOST_CHECK ( _vector.size() == 1 );
    BOOST_CHECK_NO_THROW ( invoke_(d, aggregator)() << alt_(7, 8, 9); );
	BOOST_CHECK ( _vector.size() == 2 );
    BOOST_CHECK_NO_THROW ( invoke_(d, aggregator)() << alt_(6, 7, 8, 9); );
	BOOST_CHECK ( _vector.size() == 3 );
    BOOST_CHECK_NO_THROW ( invoke_(d, aggregator)() << alt_(5, 6, 7, 8, 9); );
	BOOST_CHECK ( _vector.size() == 4 );
    BOOST_CHECK_NO_THROW ( invoke_(d, aggregator)() << alt_(4, 5, 6, 7, 8, 9); );
	BOOST_CHECK ( _vector.size() == 5 );
    BOOST_CHECK_NO_THROW ( invoke_(d, aggregator)() << alt_(3, 4, 5, 6, 7, 8, 9); );
	BOOST_CHECK ( _vector.size() == 6 );
    BOOST_CHECK_NO_THROW ( invoke_(d, aggregator)() << alt_(2, 3, 4, 5, 6, 7, 8, 9); );
	BOOST_CHECK ( _vector.size() == 7 );
    BOOST_CHECK_NO_THROW ( invoke_(d, aggregator)() << alt_(1, 2, 3, 4, 5, 6, 7, 8, 9); );
	BOOST_CHECK ( _vector.size() == 8 );
    BOOST_CHECK_NO_THROW ( invoke_(d, aggregator)() << alt_(0, 1, 2, 3, 4, 5, 6, 7, 8, 9); );
	BOOST_CHECK ( _vector.size() == 9 );

	_vector.clear(); // clear accumulator vector
	dispatcher<int(int)> d1;
	d1[9] = int_function_1;
	BOOST_CHECK_NO_THROW ( invoke_(d1, aggregator)(1) << alt_(8, 9) );
	BOOST_CHECK (_vector[0] == 1);
    BOOST_CHECK_NO_THROW ( invoke_(d1, aggregator)(1) << alt_(7, 8, 9); );
	BOOST_CHECK (_vector[1] == 1);
    BOOST_CHECK_NO_THROW ( invoke_(d1, aggregator)(1) << alt_(6, 7, 8, 9); );
	BOOST_CHECK (_vector[2] == 1);
    BOOST_CHECK_NO_THROW ( invoke_(d1, aggregator)(1) << alt_(5, 6, 7, 8, 9); );
	BOOST_CHECK (_vector[3] == 1);
    BOOST_CHECK_NO_THROW ( invoke_(d1, aggregator)(1) << alt_(4, 5, 6, 7, 8, 9); );
	BOOST_CHECK (_vector[4] == 1);
    BOOST_CHECK_NO_THROW ( invoke_(d1, aggregator)(1) << alt_(3, 4, 5, 6, 7, 8, 9); );
	BOOST_CHECK (_vector[5] == 1);
    BOOST_CHECK_NO_THROW ( invoke_(d1, aggregator)(1) << alt_(2, 3, 4, 5, 6, 7, 8, 9); );
	BOOST_CHECK (_vector[6] == 1);
    BOOST_CHECK_NO_THROW ( invoke_(d1, aggregator)(1) << alt_(1, 2, 3, 4, 5, 6, 7, 8, 9); );
	BOOST_CHECK (_vector[7] == 1);
    BOOST_CHECK_NO_THROW ( invoke_(d1, aggregator)(1) << alt_(0, 1, 2, 3, 4, 5, 6, 7, 8, 9); );
	BOOST_CHECK (_vector[8] == 1);

	_vector.clear(); // clear accumulator vector
	dispatcher<int(int, int)> d2;
	d2[9] = int_function_2;
	BOOST_CHECK_NO_THROW ( invoke_(d2, aggregator)(1, 1) << alt_(8, 9) );
	BOOST_CHECK (_vector[0] == 2);
    BOOST_CHECK_NO_THROW ( invoke_(d2, aggregator)(1, 1) << alt_(7, 8, 9); );
	BOOST_CHECK (_vector[1] == 2);
    BOOST_CHECK_NO_THROW ( invoke_(d2, aggregator)(1, 1) << alt_(6, 7, 8, 9); );
	BOOST_CHECK (_vector[2] == 2);
    BOOST_CHECK_NO_THROW ( invoke_(d2, aggregator)(1, 1) << alt_(5, 6, 7, 8, 9); );
	BOOST_CHECK (_vector[3] == 2);
    BOOST_CHECK_NO_THROW ( invoke_(d2, aggregator)(1, 1) << alt_(4, 5, 6, 7, 8, 9); );
	BOOST_CHECK (_vector[4] == 2);
    BOOST_CHECK_NO_THROW ( invoke_(d2, aggregator)(1, 1) << alt_(3, 4, 5, 6, 7, 8, 9); );
	BOOST_CHECK (_vector[5] == 2);
    BOOST_CHECK_NO_THROW ( invoke_(d2, aggregator)(1, 1) << alt_(2, 3, 4, 5, 6, 7, 8, 9); );
	BOOST_CHECK (_vector[6] == 2);
    BOOST_CHECK_NO_THROW ( invoke_(d2, aggregator)(1, 1) << alt_(1, 2, 3, 4, 5, 6, 7, 8, 9); );
	BOOST_CHECK (_vector[7] == 2);
    BOOST_CHECK_NO_THROW ( invoke_(d2, aggregator)(1, 1) << alt_(0, 1, 2, 3, 4, 5, 6, 7, 8, 9); );
	BOOST_CHECK (_vector[8] == 2);

	_vector.clear(); // clear accumulator vector
	dispatcher<int(int, int, int)> d3;
	d3[9] = int_function_3;
	BOOST_CHECK_NO_THROW ( invoke_(d3, aggregator)(1, 1, 1) << alt_(8, 9) );
	BOOST_CHECK (_vector[0] == 3);
    BOOST_CHECK_NO_THROW ( invoke_(d3, aggregator)(1, 1, 1) << alt_(7, 8, 9); );
	BOOST_CHECK (_vector[1] == 3);
    BOOST_CHECK_NO_THROW ( invoke_(d3, aggregator)(1, 1, 1) << alt_(6, 7, 8, 9); );
	BOOST_CHECK (_vector[2] == 3);
    BOOST_CHECK_NO_THROW ( invoke_(d3, aggregator)(1, 1, 1) << alt_(5, 6, 7, 8, 9); );
	BOOST_CHECK (_vector[3] == 3);
    BOOST_CHECK_NO_THROW ( invoke_(d3, aggregator)(1, 1, 1) << alt_(4, 5, 6, 7, 8, 9); );
	BOOST_CHECK (_vector[4] == 3);
    BOOST_CHECK_NO_THROW ( invoke_(d3, aggregator)(1, 1, 1) << alt_(3, 4, 5, 6, 7, 8, 9); );
	BOOST_CHECK (_vector[5] == 3);
    BOOST_CHECK_NO_THROW ( invoke_(d3, aggregator)(1, 1, 1) << alt_(2, 3, 4, 5, 6, 7, 8, 9); );
	BOOST_CHECK (_vector[6] == 3);
    BOOST_CHECK_NO_THROW ( invoke_(d3, aggregator)(1, 1, 1) << alt_(1, 2, 3, 4, 5, 6, 7, 8, 9); );
	BOOST_CHECK (_vector[7] == 3);
    BOOST_CHECK_NO_THROW ( invoke_(d3, aggregator)(1, 1, 1) << alt_(0, 1, 2, 3, 4, 5, 6, 7, 8, 9); );
	BOOST_CHECK (_vector[8] == 3);

	_vector.clear(); // clear accumulator vector
	dispatcher<int(int, int, int, int)> d4;
	d4[9] = int_function_4;
	BOOST_CHECK_NO_THROW ( invoke_(d4, aggregator)(1, 1, 1, 1) << alt_(8, 9) );
	BOOST_CHECK (_vector[0] == 4);
    BOOST_CHECK_NO_THROW ( invoke_(d4, aggregator)(1, 1, 1, 1) << alt_(7, 8, 9); );
	BOOST_CHECK (_vector[1] == 4);
    BOOST_CHECK_NO_THROW ( invoke_(d4, aggregator)(1, 1, 1, 1) << alt_(6, 7, 8, 9); );
	BOOST_CHECK (_vector[2] == 4);
    BOOST_CHECK_NO_THROW ( invoke_(d4, aggregator)(1, 1, 1, 1) << alt_(5, 6, 7, 8, 9); );
	BOOST_CHECK (_vector[3] == 4);
    BOOST_CHECK_NO_THROW ( invoke_(d4, aggregator)(1, 1, 1, 1) << alt_(4, 5, 6, 7, 8, 9); );
	BOOST_CHECK (_vector[4] == 4);
    BOOST_CHECK_NO_THROW ( invoke_(d4, aggregator)(1, 1, 1, 1) << alt_(3, 4, 5, 6, 7, 8, 9); );
	BOOST_CHECK (_vector[5] == 4);
    BOOST_CHECK_NO_THROW ( invoke_(d4, aggregator)(1, 1, 1, 1) << alt_(2, 3, 4, 5, 6, 7, 8, 9); );
	BOOST_CHECK (_vector[6] == 4);
    BOOST_CHECK_NO_THROW ( invoke_(d4, aggregator)(1, 1, 1, 1) << alt_(1, 2, 3, 4, 5, 6, 7, 8, 9); );
	BOOST_CHECK (_vector[7] == 4);
    BOOST_CHECK_NO_THROW ( invoke_(d4, aggregator)(1, 1, 1, 1) << alt_(0, 1, 2, 3, 4, 5, 6, 7, 8, 9); );
	BOOST_CHECK (_vector[8] == 4);

	_vector.clear(); // clear accumulator vector
	dispatcher<int(int, int, int, int, int)> d5;
	d5[9] = int_function_5;
	BOOST_CHECK_NO_THROW ( invoke_(d5, aggregator)(1, 1, 1, 1, 1) << alt_(8, 9) );
	BOOST_CHECK (_vector[0] == 5);
    BOOST_CHECK_NO_THROW ( invoke_(d5, aggregator)(1, 1, 1, 1, 1) << alt_(7, 8, 9); );
	BOOST_CHECK (_vector[1] == 5);
    BOOST_CHECK_NO_THROW ( invoke_(d5, aggregator)(1, 1, 1, 1, 1) << alt_(6, 7, 8, 9); );
	BOOST_CHECK (_vector[2] == 5);
    BOOST_CHECK_NO_THROW ( invoke_(d5, aggregator)(1, 1, 1, 1, 1) << alt_(5, 6, 7, 8, 9); );
	BOOST_CHECK (_vector[3] == 5);
    BOOST_CHECK_NO_THROW ( invoke_(d5, aggregator)(1, 1, 1, 1, 1) << alt_(4, 5, 6, 7, 8, 9); );
	BOOST_CHECK (_vector[4] == 5);
    BOOST_CHECK_NO_THROW ( invoke_(d5, aggregator)(1, 1, 1, 1, 1) << alt_(3, 4, 5, 6, 7, 8, 9); );
	BOOST_CHECK (_vector[5] == 5);
    BOOST_CHECK_NO_THROW ( invoke_(d5, aggregator)(1, 1, 1, 1, 1) << alt_(2, 3, 4, 5, 6, 7, 8, 9); );
	BOOST_CHECK (_vector[6] == 5);
    BOOST_CHECK_NO_THROW ( invoke_(d5, aggregator)(1, 1, 1, 1, 1) << alt_(1, 2, 3, 4, 5, 6, 7, 8, 9); );
	BOOST_CHECK (_vector[7] == 5);
    BOOST_CHECK_NO_THROW ( invoke_(d5, aggregator)(1, 1, 1, 1, 1) << alt_(0, 1, 2, 3, 4, 5, 6, 7, 8, 9); );
	BOOST_CHECK (_vector[8] == 5);

	_vector.clear(); // clear accumulator vector
	dispatcher<int(int, int, int, int, int, int)> d6;
	d6[9] = int_function_6;
	BOOST_CHECK_NO_THROW ( invoke_(d6, aggregator)(1, 1, 1, 1, 1, 1) << alt_(8, 9) );
	BOOST_CHECK (_vector[0] == 6);
    BOOST_CHECK_NO_THROW ( invoke_(d6, aggregator)(1, 1, 1, 1, 1, 1) << alt_(7, 8, 9); );
	BOOST_CHECK (_vector[1] == 6);
    BOOST_CHECK_NO_THROW ( invoke_(d6, aggregator)(1, 1, 1, 1, 1, 1) << alt_(6, 7, 8, 9); );
	BOOST_CHECK (_vector[2] == 6);
    BOOST_CHECK_NO_THROW ( invoke_(d6, aggregator)(1, 1, 1, 1, 1, 1) << alt_(5, 6, 7, 8, 9); );
	BOOST_CHECK (_vector[3] == 6);
    BOOST_CHECK_NO_THROW ( invoke_(d6, aggregator)(1, 1, 1, 1, 1, 1) << alt_(4, 5, 6, 7, 8, 9); );
	BOOST_CHECK (_vector[4] == 6);
    BOOST_CHECK_NO_THROW ( invoke_(d6, aggregator)(1, 1, 1, 1, 1, 1) << alt_(3, 4, 5, 6, 7, 8, 9); );
	BOOST_CHECK (_vector[5] == 6);
    BOOST_CHECK_NO_THROW ( invoke_(d6, aggregator)(1, 1, 1, 1, 1, 1) << alt_(2, 3, 4, 5, 6, 7, 8, 9); );
	BOOST_CHECK (_vector[6] == 6);
    BOOST_CHECK_NO_THROW ( invoke_(d6, aggregator)(1, 1, 1, 1, 1, 1) << alt_(1, 2, 3, 4, 5, 6, 7, 8, 9); );
	BOOST_CHECK (_vector[7] == 6);
    BOOST_CHECK_NO_THROW ( invoke_(d6, aggregator)(1, 1, 1, 1, 1, 1) << alt_(0, 1, 2, 3, 4, 5, 6, 7, 8, 9); );
	BOOST_CHECK (_vector[8] == 6);
};

