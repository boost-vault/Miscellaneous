// Copyright 2006 (C) Dean Michael Berris <mikhailberis@gmail.com>
// Distributed under the Boost Software License, Version 1.0. (See accompanying
// file LICENSE_1_0.txt or copy at http://www.boost.org/LICENSE_1_0.txt)

#include <string>
#include <iostream>
#include <vector>
#include <boost/shared_ptr.hpp>
#include <boost/bind.hpp>
#include "boost/dispatch.hpp"

class handler : boost::noncopyable {
	public:
		handler(dispatch::dispatcher<void (), std::string> & d, const std::string & modifier) :
			_dispatcher(d), _modifier(modifier) {
				_dispatcher[modifier + "::handler.function_call"] = boost::bind(&handler::function_call, this);
			};

		void function_call() {
			std::cout << _modifier << "'s handler function call called!" << std::endl;
		};

	protected:
		dispatch::dispatcher<void(), std::string> & _dispatcher;
		std::string _modifier;
};

int main(int argc, char * argv[]) {
	dispatch::dispatcher<void(), std::string> d;
	std::vector< boost::shared_ptr<handler> > handlers;
	
	for (int i = 1; i < argc; i++) 
		handlers.push_back ( boost::shared_ptr<handler> (new handler(d, argv[i])) );

	std::string input;
	while (!std::cin.eof()) {
		std::cin >> input;
		try {
			d[input + "::handler.function_call"]();
		} catch (dispatch::unregistered_handler & e) {
			std::cout << "unregistered handler: " << input << " !!!" << std::endl;
		};
	};

	return 0;
};
