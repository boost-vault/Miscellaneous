#ifndef BINARY_TREE_HPP
#define BINARY_TREE_HPP

#include <stack>
#include <boost/iterator/iterator_facade.hpp>

namespace detail
{
    template<typename T>
    struct binary_tree_node
    {
        binary_tree_node(const T& elem) : element(elem), lft(0), rgt(0)
        {
        }
        
        ~binary_tree_node()
        {
            delete lft;
            delete rgt;
        }
        
        T element;
        binary_tree_node* lft;
        binary_tree_node* rgt;
    };
    
    template<typename T>
    struct binary_tree_generator
    {
        typedef T value_type;
        typedef const T& reference;
        
        binary_tree_generator() : node(0)
        {
        }
        
        binary_tree_generator(const binary_tree_node<T>* node_) : node(node_)
        {
        }
        
        template<typename Out>
        Out operator()(Out out)
        {
            if(node)
            {
                out = binary_tree_generator(node->lft)(out);
                *out++ = node->element;
                return binary_tree_generator(node->rgt)(out);
            }
            return out;
        }
        
    private:
        const binary_tree_node<T>* node;
    };
    
    template<typename T>
    struct binary_tree_iterator
      : boost::iterator_facade<
            binary_tree_iterator<T>,
            T,
            std::forward_iterator_tag,
            const T&
        >
    {
        binary_tree_iterator(const binary_tree_node<T>* root) : node(root), seen_root(0)
        {
            while(node->lft)
            {
                stack.push(node);
                node = node->lft;
            }
        }
        
        binary_tree_iterator(const binary_tree_node<T>* root, bool) : node(root), seen_root(2)
        {
        }
        
    private:
        friend class boost::iterator_core_access;
        
        const T& dereference() const
        {
            return node->element;
        }
        
        void increment()
        {
            if(node->rgt)
            {
                stack.push(node);
                node = node->rgt;
                while(node->lft)
                {
                    stack.push(node);
                    node = node->lft;
                }
            }
            else
            {
                if(!stack.empty())
                {
                    const binary_tree_node<T>* parent_node = stack.top();
                    stack.pop();
                    while(!stack.empty() && node == parent_node->rgt)
                    {
                        node = parent_node;
                        parent_node = stack.top();
                        stack.pop();
                    }
                    node = parent_node;
                }
            }
            
            if(stack.empty())
                seen_root++;
        }
        
        bool equal(const binary_tree_iterator& other) const
        {
            return node == other.node && seen_root == other.seen_root;
        }
        
        std::stack<const binary_tree_node<T>*> stack;
        const binary_tree_node<T>* node;
        int seen_root;
    };
}

template<typename T>
struct binary_tree
{
    typedef detail::binary_tree_generator<T> generator;
    typedef detail::binary_tree_iterator<T>  iterator;
    
    binary_tree() : root(0)
    {
    }
    
    iterator begin() const
    {
        return iterator(root);
    }
    
    iterator end() const
    {
        return iterator(root, true);
    }
    
    generator generate() const
    {
        return generator(root);
    }
    
    void insert(const T& elem)
    {
        if(!root)
        {
            root = new detail::binary_tree_node<T>(elem);
            return;
        }
        
        detail::binary_tree_node<T>* node = root;
        for(;;)
        {
            detail::binary_tree_node<T>*& next = elem < node->element ? node->lft : node->rgt;
            if(next)
            {
                node = next;
            }
            else
            {
                next = new detail::binary_tree_node<T>(elem);
                break;
            }
        }
    }
    
    void debug()
    {
        return debug(root, 0);
    }
    
private:
    void debug(const detail::binary_tree_node<T>* node, size_t level)
    {
        for(size_t i=0; i<level; ++i)
            std::cout << " ";
            
        if(!node)
        {
            std::cout << "-" << std::endl;
            return;
        }
        
        std::cout << node->element << std::endl;
        debug(node->lft, level+1);
        debug(node->rgt, level+1);
    }
    
public:
    ~binary_tree()
    {
        delete root;
    }

    detail::binary_tree_node<T>* root;
};

#endif
