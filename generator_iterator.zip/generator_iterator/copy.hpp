#ifndef COPY_HPP
#define COPY_HPP

#include <boost/range/begin.hpp>
#include <boost/range/end.hpp>
#include <boost/utility/enable_if.hpp>
#include <algorithm>

#include "has_generate.hpp"

template<typename Range, typename Out>
typename boost::enable_if<
    has_generate<Range>,
    Out
>::type copy(const Range& range, Out out)
{
    return range.generate()(out);
}

template<typename Range, typename Out>
typename boost::disable_if<
    has_generate<Range>,
    Out
>::type copy(const Range& range, Out out)
{
    return std::copy(boost::begin(range), boost::end(range), out);
}

#endif
