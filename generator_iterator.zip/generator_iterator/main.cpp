#include <iostream>
#include <iterator>

#include <boost/timer.hpp>

#include "binary_tree.hpp"
#include "copy.hpp"

#include "generator_iterator.hpp"

const size_t tree_size = 1000000;

binary_tree<int> tree;

// we minimize the tree depth to avoid stack explosion
void build_tree(size_t begin, size_t end)
{
    if(end - begin <= 1)
        return;
    
    size_t middle = (end-begin) / 2;
    
    tree.insert(begin+middle);
    build_tree(begin, begin+middle);
    build_tree(begin+middle, end);
}

int main()
{
    std::cout << "Building binary tree of " << tree_size << " elements..." << std::endl;
    build_tree(0, tree_size);
    //tree.debug();
    
    boost::timer timer;
    std::cout << "Iterating with hand-written iterator..." << std::endl;
    std::copy(tree.begin(), tree.end(), std::ostream_iterator<int>(std::cerr, " "));
    std::cerr << std::endl;
    std::cout << timer.elapsed() << std::endl;
    
    timer.restart();
    std::cout << "Iterating with generator..." << std::endl;
    copy(tree, std::ostream_iterator<int>(std::cerr, " "));
    std::cerr << std::endl;
    std::cout << timer.elapsed() << std::endl;
    
    timer.restart();
    std::cout << "Iterating with iterator generated from generator..." << std::endl;
    generator_iterator<binary_tree<int>::generator> begin(tree.generate()), end;
    std::copy(begin, end, std::ostream_iterator<int>(std::cerr, " "));
    std::cerr << std::endl;
    std::cout << timer.elapsed() << std::endl;
}
