#ifndef HAS_GENERATE_HPP
#define HAS_GENERATE_HPP

#include <boost/mpl/has_xxx.hpp>

BOOST_MPL_HAS_XXX_TRAIT_NAMED_DEF(has_generate, generator, false)

#endif
