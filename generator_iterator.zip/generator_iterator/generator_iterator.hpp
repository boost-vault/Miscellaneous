#ifndef GENERATOR_ITERATOR_HPP
#define GENERATOR_ITERATOR_HPP

#include <boost/coroutine/generator.hpp>

#include <boost/bind.hpp>
#include <boost/function_output_iterator.hpp>

template<typename Generator>
struct generator_iterator
  : boost::iterator_facade<
        generator_iterator<Generator>,
        typename Generator::value_type,
        std::forward_iterator_tag,
        const typename Generator::reference
  >
{
    generator_iterator(Generator gen_) : gen(gen_), g(boost::bind(&generator_iterator::generate, this, _1)), index(0)
    {
        increment();
    }
    
    generator_iterator() : index(size_t(-1))
    {
    }
    
    typedef typename generator_iterator::pointer   pointer;
    typedef typename generator_iterator::reference reference;
    
private:
    friend class boost::iterator_core_access;
    typedef boost::coroutines::generator<pointer> generator_type;
    
    reference dereference() const
    {
        return *value;
    }
    
    void increment()
    {
        if(g != generator_type())
        {
            value = g();
            ++index;
        }
        else
        {
            index = size_t(-1);
        }
    }
    
    bool equal(const generator_iterator& other) const
    {
        return index == other.index;
    }
    
    struct yield_function
    {
        typedef void result_type;
        
        yield_function(typename generator_type::self& self_) : self(&self_)
        {
        }
        
        void operator()(reference elem)
        {
            self->yield(&elem);
        }
        
        typename generator_type::self* self;
    };
    
    pointer generate(typename generator_type::self& self)
    {
        gen(boost::make_function_output_iterator(yield_function(self)));
        self.exit();
    }
    
    Generator gen;
    generator_type g;
    
    pointer value;
    size_t index;
};

#endif
