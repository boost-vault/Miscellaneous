#include "ad.h"
#include <iostream>

using namespace std;

int main()
{
	variable<0>::type x;
	variable<1>::type y;

	// create const number
	double x0 = d(pow(x, const_<10>::type()), x)(2.0);

	// operators
	double x1 = d(x * x * x, x)(2.0);
	double x2 = d(x + x + x, x)(2.0);
	double x3 = d(x - x - x, x)(2.0);
	double x4 = d(x / x, x)(2.0);

	// pow
	double x5 = d(pow(x, var(3.0)), x)(2.0);
	double x6 = d(pow(var(3.0), x), x)(2.0);
	double x7 = d(pow(x, x), x)(2.0);

	double x8 = d(log(x), x)(2.0);
	double x9 = d(exp(x), x)(2.0);

	double x10 = d(sin(x), x)(2.0);
	double x11 = d(cos(x), x)(2.0);

	double x12 = d(d(sin(x) * cos(y), x), y)(2.0, 3.0);

	double x13 = (d(log(x) + x, x) * x)(2.0);

	cout<<d(pow(x, const_<10>::type()), x)<<endl;

	cout<<d(x * x * x, x)<<endl;
	cout<<d(x + x + x, x)<<endl;
	cout<<d(x - x - x, x)<<endl;
	cout<<d(x / x / x, x)<<endl;

	cout<<d(pow(x, var(3.0)), x)<<endl;
	cout<<d(pow(var(3.0), x), x)<<endl;
	cout<<d(pow(x, x), x)<<endl;

	cout<<d(log(x), x)<<endl;
	cout<<d(exp(x), x)<<endl;

	cout<<d(sin(x), x)<<endl;
	cout<<d(cos(x), x)<<endl;

	cout<<d(d(sin(x) * cos(y), x), y)<<endl;

	cout<<(d(log(x) + x, x) * x)<<endl;

	return 0;
}