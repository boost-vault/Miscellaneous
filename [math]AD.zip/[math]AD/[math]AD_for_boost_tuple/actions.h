#ifndef ACTIONS_H
#define ACTIONS_H


class action {};
class add_action : public action {};
class sub_action : public action {};
class mul_action : public action {};
class div_action : public action {};

class pow_action : public action {};

class sin_action : public action {};
class cos_action : public action {};

class log_action : public action {};
class exp_action : public action {};


class var_action : public action {};
class const_action : public action {};

#endif //ACTIONS_H