#ifndef EXP_H
#define EXP_H

#include <iostream>

//---------------------------------------------expression----------------------------------------------
template <class Act, class Arg>
struct expression;

template <int N>
struct int_
{
	static const int value = N;
};

template <int N>
struct expression<const_action, int_<N> >
{
	typedef const_action action_type;
	typedef int_<N> argument_type;

	typedef expression opt_type;

	template <class _T>
	_T operator ()(const _T& t1, const _T& t2)
	{
		return _T(argument_type::value);
	}

	template <class _T>
	_T operator ()(const _T& t)
	{
		return _T(argument_type::value);
	}

	friend std::ostream& operator<<(std::ostream& o, const expression& exp)
	{
		o<<argument_type::value;
		return o;
	}
};

template <class Arg>
struct expression<var_action, Arg>
{
	typedef var_action action_type;
	typedef Arg argument_type;

	typedef expression opt_type;

	argument_type arg;

	explicit expression(const Arg& arg)
		: arg(arg)
	{}

	template <class _T>
	_T operator ()(const _T& t1, const _T& t2)
	{
		return _T(arg);
	}

	template <class _T>
	_T operator ()(const _T& t)
	{
		return _T(arg);
	}

	friend std::ostream& operator<<(std::ostream& o, const expression& exp)
	{
		o<<exp.arg;
		return o;
	}
};
template <int N>
struct expression<var_action, int_<N> >
{
	typedef var_action action_type;
	typedef int_<N> argument_type;

	typedef expression opt_type;
};

template <>
struct expression<var_action, int_<0> >
{
	typedef var_action action_type;
	typedef int_<0> argument_type;

	typedef expression opt_type;

	template <class _T>
	_T operator ()(const _T& t1)
	{
		return t1;
	}

	template <class _T>
	_T operator ()(const _T& t1, const _T& t2)
	{
		return t1;
	}

	friend std::ostream& operator<<(std::ostream& o, const expression& exp)
	{
		o<<'x';
		return o;
	}
};

template <>
struct expression<var_action, int_<1> >
{
	typedef var_action action_type;
	typedef int_<1> argument_type;

	typedef expression opt_type;

	template <class _T>
	_T operator ()(const _T& t1, const _T& t2)
	{
		return t2;
	}

	friend std::ostream& operator<<(std::ostream& o, const expression& exp)
	{
		o<<'y';
		return o;
	}
};

template <class Arg>
struct expression<add_action, Arg>
{
	typedef add_action action_type;
	typedef Arg argument_type;

	typedef expression opt_type;

	typedef typename boost::tuples::element<0, argument_type>::type lhs_type;
	typedef typename boost::tuples::element<1, argument_type>::type rhs_type;

	argument_type arg;

	explicit expression(const argument_type& arg)
		: arg(arg)
	{}

	template <class _T>
	_T operator ()(const _T& t1, const _T& t2)
	{
		return boost::tuples::get<0>(arg)(t1, t2) + boost::tuples::get<1>(arg)(t1, t2);
	}

	template <class _T>
	_T operator ()(const _T& t)
	{
		return boost::tuples::get<0>(arg)(t) + boost::tuples::get<1>(arg)(t);
	}

	friend std::ostream& operator<<(std::ostream& o, const expression& exp)
	{
		o<<"("<<boost::tuples::get<0>(exp.arg)<< '+' << boost::tuples::get<1>(exp.arg)<<")";
		return o;
	}
};

template <class Arg>
struct expression<sub_action, Arg>
{
	typedef sub_action action_type;
	typedef Arg argument_type;

	typedef expression opt_type;

	typedef typename boost::tuples::element<0, argument_type>::type lhs_type;
	typedef typename boost::tuples::element<1, argument_type>::type rhs_type;

	argument_type arg;

	explicit expression(const argument_type& arg)
		: arg(arg)
	{}

	template <class _T>
	_T operator ()(const _T& t1, const _T& t2)
	{
		return boost::tuples::get<0>(arg)(t1, t2) - boost::tuples::get<1>(arg)(t1, t2);
	}

	template <class _T>
	_T operator ()(const _T& t)
	{
		return boost::tuples::get<0>(arg)(t) - boost::tuples::get<1>(arg)(t);
	}

	friend std::ostream& operator<<(std::ostream& o, const expression& exp)
	{
		o<<"("<<boost::tuples::get<0>(exp.arg)<< '-' << boost::tuples::get<1>(exp.arg)<<")";
		return o;
	}
};


template <class Arg>
struct expression<mul_action, Arg>
{
	typedef mul_action action_type;
	typedef Arg argument_type;

	typedef expression opt_type;

	typedef typename boost::tuples::element<0, argument_type>::type lhs_type;
	typedef typename boost::tuples::element<1, argument_type>::type rhs_type;

	argument_type arg;

	explicit expression(const argument_type& arg)
		: arg(arg)
	{}

	template <class _T>
	_T operator ()(const _T& t1, const _T& t2)
	{
		return boost::tuples::get<0>(arg)(t1, t2) * boost::tuples::get<1>(arg)(t1, t2);
	}

	template <class _T>
	_T operator ()(const _T& t)
	{
		return boost::tuples::get<0>(arg)(t) * boost::tuples::get<1>(arg)(t);
	}

	friend std::ostream& operator<<(std::ostream& o, const expression& exp)
	{
		o<<"("<<boost::tuples::get<0>(exp.arg)<< '*' << boost::tuples::get<1>(exp.arg)<<")";
		return o;
	}
};

template <class Arg>
struct expression<div_action, Arg>
{
	typedef div_action action_type;
	typedef Arg argument_type;

	typedef expression opt_type;

	typedef typename boost::tuples::element<0, argument_type>::type lhs_type;
	typedef typename boost::tuples::element<1, argument_type>::type rhs_type;

	argument_type arg;

	explicit expression(const argument_type& arg)
		: arg(arg)
	{}

	template <class _T>
	_T operator ()(const _T& t1, const _T& t2)
	{
		return boost::tuples::get<0>(arg)(t1, t2) / boost::tuples::get<1>(arg)(t1, t2);
	}

	template <class _T>
	_T operator ()(const _T& t)
	{
		return boost::tuples::get<0>(arg)(t) / boost::tuples::get<1>(arg)(t);
	}

	friend std::ostream& operator<<(std::ostream& o, const expression& exp)
	{
		o<<"("<<boost::tuples::get<0>(exp.arg)<< '/' << boost::tuples::get<1>(exp.arg)<<")";
		return o;
	}
};

template <class Arg>
struct expression<log_action, Arg>
{
	typedef log_action action_type;
	typedef Arg argument_type;

	typedef expression opt_type;

	typedef typename boost::tuples::element<0, argument_type>::type lhs_type;

	argument_type arg;

	explicit expression(const argument_type& arg)
		: arg(arg)
	{}

	template <class _T>
	_T operator ()(const _T& t1, const _T& t2)
	{
		return std::log(boost::tuples::get<0>(arg)(t1, t2));
	}

	template <class _T>
	_T operator ()(const _T& t)
	{
		return std::log(boost::tuples::get<0>(arg)(t));
	}

	friend std::ostream& operator<<(std::ostream& o, const expression& exp)
	{
		o<<"log("<<boost::tuples::get<0>(exp.arg)<<")";
		return o;
	}
};

template <class Arg>
struct expression<exp_action, Arg>
{
	typedef exp_action action_type;
	typedef Arg argument_type;

	typedef expression opt_type;

	typedef typename boost::tuples::element<0, argument_type>::type lhs_type;

	argument_type arg;

	explicit expression(const argument_type& arg)
		: arg(arg)
	{}

	template <class _T>
	_T operator ()(const _T& t1, const _T& t2)
	{
		return std::exp(boost::tuples::get<0>(arg)(t1, t2));
	}

	template <class _T>
	_T operator ()(const _T& t)
	{
		return std::exp(boost::tuples::get<0>(arg)(t));
	}

	friend std::ostream& operator<<(std::ostream& o, const expression& exp)
	{
		o<<"exp("<<boost::tuples::get<0>(exp.arg)<<")";
		return o;
	}
};

template <class Arg>
struct expression<sin_action, Arg>
{
	typedef sin_action action_type;
	typedef Arg argument_type;

	typedef expression opt_type;

	typedef typename boost::tuples::element<0, argument_type>::type lhs_type;

	argument_type arg;

	explicit expression(const argument_type& arg)
		: arg(arg)
	{}

	template <class _T>
	_T operator ()(const _T& t1, const _T& t2)
	{
		return std::sin(boost::tuples::get<0>(arg)(t1, t2));
	}

	template <class _T>
	_T operator ()(const _T& t)
	{
		return std::sin(boost::tuples::get<0>(arg)(t));
	}

	friend std::ostream& operator<<(std::ostream& o, const expression& exp)
	{
		o<<"sin("<<boost::tuples::get<0>(exp.arg)<<")";
		return o;
	}
};

template <class Arg>
struct expression<cos_action, Arg>
{
	typedef cos_action action_type;
	typedef Arg argument_type;

	typedef expression opt_type;

	typedef typename boost::tuples::element<0, argument_type>::type lhs_type;

	argument_type arg;

	explicit expression(const argument_type& arg)
		: arg(arg)
	{}

	template <class _T>
	_T operator ()(const _T& t1, const _T& t2)
	{
		return std::cos(boost::tuples::get<0>(arg)(t1, t2));
	}

	template <class _T>
	_T operator ()(const _T& t)
	{
		return std::cos(boost::tuples::get<0>(arg)(t));
	}

	friend std::ostream& operator<<(std::ostream& o, const expression& exp)
	{
		o<<"cos("<<boost::tuples::get<0>(exp.arg)<<")";
		return o;
	}
};

template <class Arg>
struct expression<pow_action, Arg>
{
	typedef pow_action action_type;
	typedef Arg argument_type;

	typedef expression opt_type;

	typedef typename boost::tuples::element<0, argument_type>::type lhs_type;
	typedef typename boost::tuples::element<1, argument_type>::type rhs_type;

	argument_type arg;

	explicit expression(const argument_type& arg)
		: arg(arg)
	{}

	template <class _T>
	_T operator ()(const _T& t1, const _T& t2)
	{
		return std::pow(boost::tuples::get<0>(arg)(t1, t2), boost::tuples::get<1>(arg)(t1, t2));
	}

	template <class _T>
	_T operator ()(const _T& t)
	{
		return std::pow(boost::tuples::get<0>(arg)(t), boost::tuples::get<1>(arg)(t));
	}

	friend std::ostream& operator<<(std::ostream& o, const expression& exp)
	{
		o<<"pow("<<boost::tuples::get<0>(exp.arg)<<","<<boost::tuples::get<1>(exp.arg)<<")";
		return o;
	}
};


#endif //EXP_H