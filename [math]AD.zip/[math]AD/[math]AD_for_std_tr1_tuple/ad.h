#ifndef AD_H
#define AD_H

#include <tuple>
#include <cmath>

#include "actions.h"
#include "exp.h"
#include "opt.h"
#include "derit.h"
#include "ops.h"

template <int N>
struct variable
{
	typedef expression<var_action, int_<N> > type;
};

template <int N>
struct const_
{
	typedef expression<const_action, int_<N> > type;
};

template <class Exp, class Var>
typename derivative<Exp, Var>::derivative_type
d(const Exp& exp, const Var& v)
{
	return derivative<Exp, Var>::derivate(exp);
}

#endif //AD_H