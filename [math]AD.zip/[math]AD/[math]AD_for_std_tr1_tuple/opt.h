#ifndef OPT_H
#define OPT_H

#include "exp.h"

// x - x = 0
template <class Exp>
struct expression<sub_action, std::tr1::tuple<Exp, Exp> >
{
	typedef sub_action action_type;
	typedef std::tr1::tuple<Exp, Exp> argument_type;

	typedef expression<const_action, int_<0> > opt_type;

	expression(const argument_type& arg)
	{}

	operator opt_type()
	{
		return opt_type();
	}
};

// N - M = (N - M)
template <int N, int M>
struct expression<sub_action, std::tr1::tuple<expression<const_action, int_<N> >, expression<const_action, int_<M> > > >
{
	typedef sub_action action_type;
	typedef std::tr1::tuple<expression<const_action, int_<N> >, expression<const_action, int_<M> > > argument_type;

	typedef expression<const_action, int_<N - M> > opt_type;

	expression(const argument_type& arg)
	{}

	operator opt_type()
	{
		return opt_type();
	}
};

// 0 + x = x
template <class Exp>
struct expression<add_action, std::tr1::tuple<expression<const_action, int_<0> >, Exp > >
{
	typedef add_action action_type;
	typedef std::tr1::tuple<expression<const_action, int_<0> >, Exp > argument_type;

	typedef Exp opt_type;

	argument_type arg;

	expression(const argument_type& arg)
		: arg(arg)
	{}

	operator opt_type()
	{
		return std::tr1::get<1>(arg);
	}
};

// x + 0 = x
template <class Exp>
struct expression<add_action, std::tr1::tuple<Exp, expression<const_action, int_<0> > > >
{
	typedef add_action action_type;
	typedef std::tr1::tuple<Exp, expression<const_action, int_<0> > > argument_type;

	typedef Exp opt_type;

	argument_type arg;

	expression(const argument_type& arg)
		: arg(arg)
	{}

	operator opt_type()
	{
		return std::tr1::get<0>(arg);
	}
};

// N + M = (M + N)
template <int N, int M>
struct expression<add_action, std::tr1::tuple<expression<const_action, int_<N> >, expression<const_action, int_<M> > > >
{
	typedef add_action action_type;
	typedef std::tr1::tuple<expression<const_action, int_<N> >, expression<const_action, int_<M> > > argument_type;

	typedef expression<const_action, int_<N + M> > opt_type;

	expression(const argument_type& arg)
	{}

	operator opt_type()
	{
		return opt_type();
	}
};

// x / x = 1
template <class Exp>
struct expression<div_action, std::tr1::tuple<Exp, Exp> >
{
	typedef div_action action_type;
	typedef std::tr1::tuple<Exp, Exp> argument_type;

	typedef expression<const_action, int_<1> > opt_type;

	expression(const argument_type& arg)
	{}

	operator opt_type()
	{
		return opt_type();
	}
};

// (1 / x) * x = 1
template <class Exp>
struct expression<mul_action, std::tr1::tuple<expression<div_action, std::tr1::tuple<expression<const_action, int_<1> >, Exp> >, Exp> >
{
	typedef mul_action action_type;
	typedef std::tr1::tuple<expression<div_action, std::tr1::tuple<expression<const_action, int_<1> >, Exp> >, Exp> argument_type;

	typedef expression<const_action, int_<1> > opt_type;

	expression(const argument_type& arg)
	{}

	operator opt_type()
	{
		return opt_type();
	}
};

// x * (1 / x) = 1
template <class Exp>
struct expression<mul_action, std::tr1::tuple<Exp, expression<div_action, std::tr1::tuple<expression<const_action, int_<1> >, Exp> > > >
{
	typedef mul_action action_type;
	typedef std::tr1::tuple<Exp, expression<div_action, std::tr1::tuple<expression<const_action, int_<1> >, Exp> > > argument_type;

	typedef expression<const_action, int_<1> > opt_type;

	expression(const argument_type& arg)
	{}

	operator opt_type()
	{
		return opt_type();
	}
};

//// (M / x) * N = (N*M) / x
//template <int N, int M, class Exp>
//struct expression<mul_action, 
//	std::tr1::tuple<
//		expression<div_action, std::tr1::tuple<
//			expression<const_action, int_<M> >, Exp> >, 
//			expression<const_action, int_<N> > > >
//{
//	typedef mul_action action_type;
//	typedef std::tr1::tuple<
//		expression<div_action, std::tr1::tuple<
//			expression<const_action, int_<M> >, Exp> >, 
//			expression<const_action, int_<N> > > argument_type;
//
//	typedef expression<div_action, std::tr1::tuple<expression<const_action, int_<M * N> >, Exp> > opt_type;
//
//	argument_type arg;
//
//	expression(const argument_type& arg)
//		: arg(arg)
//	{}
//
//	operator opt_type()
//	{
//		return expression<div_action, std::tr1::tuple<expression<const_action, int_<M * N> >, Exp> >
//			(
//				std::tr1::tuple<expression<const_action, int_<M * N> >, Exp>
//				(
//					expression<const_action, int_<M * N> >(),
//					std::tr1::get<1>(std::tr1::get<0>(arg).arg)
//				)
//			);
//	}
//};

// N * (M / x) = (N*M) / x
template <int N, int M, class Exp>
struct expression<mul_action, 
	std::tr1::tuple<
		expression<const_action, int_<N> >, 
		expression<div_action, std::tr1::tuple<
			expression<const_action, int_<M> >, Exp> > > >
{
	typedef mul_action action_type;
	typedef std::tr1::tuple<
		expression<const_action, int_<N> >, 
		expression<div_action, std::tr1::tuple<
			expression<const_action, int_<M> >, Exp> > > argument_type;

	typedef expression<div_action, std::tr1::tuple<expression<const_action, int_<M * N> >, Exp> > opt_type;

	argument_type arg;

	expression(const argument_type& arg)
		: arg(arg)
	{}

	operator opt_type()
	{
		return expression<div_action, std::tr1::tuple<expression<const_action, int_<M * N> >, Exp> >
			(
				std::tr1::tuple<expression<const_action, int_<M * N> >, Exp>
				(
					expression<const_action, int_<M * N> >(),
					std::tr1::get<1>(std::tr1::get<1>(arg).arg)
				)
			);
	}
};

// x * 1 = x
template <class Exp>
struct expression<mul_action, std::tr1::tuple<Exp, expression<const_action, int_<1> > > >
{
	typedef mul_action action_type;
	typedef std::tr1::tuple<Exp, expression<const_action, int_<1> > > argument_type;

	typedef Exp opt_type;

	argument_type arg;

	expression(const argument_type& arg)
		: arg(arg)
	{}

	operator opt_type()
	{
		return std::tr1::get<0>(arg);
	}
};

// 1 * x = x
template <class Exp>
struct expression<mul_action, std::tr1::tuple<expression<const_action, int_<1> >, Exp > >
{
	typedef mul_action action_type;
	typedef std::tr1::tuple<expression<const_action, int_<1> >, Exp > argument_type;

	typedef Exp opt_type;

	argument_type arg;

	expression(const argument_type& arg)
		: arg(arg)
	{}

	operator opt_type()
	{
		return std::tr1::get<1>(arg);
	}
};

// 1 * 1 = 1
template <>
struct expression<mul_action, std::tr1::tuple<expression<const_action, int_<1> >, expression<const_action, int_<1> > > >
{
	typedef mul_action action_type;
	typedef std::tr1::tuple<expression<const_action, int_<1> >, expression<const_action, int_<1> > > argument_type;

	typedef expression<const_action, int_<1> > opt_type;

	expression(const argument_type& arg)
	{}

	operator opt_type()
	{
		return opt_type();
	}
};

// N * M = (M * N)
template <int N, int M>
struct expression<mul_action, std::tr1::tuple<expression<const_action, int_<N> >, expression<const_action, int_<M> > > >
{
	typedef mul_action action_type;
	typedef std::tr1::tuple<expression<const_action, int_<N> >, expression<const_action, int_<M> > > argument_type;

	typedef expression<const_action, int_<N * M> > opt_type;

	expression(const argument_type& arg)
	{}

	operator opt_type()
	{
		return opt_type();
	}
};

// 0 * x = 0
template <class Exp>
struct expression<mul_action, std::tr1::tuple<expression<const_action, int_<0> >, Exp > >
{
	typedef mul_action action_type;
	typedef std::tr1::tuple<expression<const_action, int_<0> >, Exp > argument_type;

	typedef expression<const_action, int_<0> > opt_type;

	expression(const argument_type& arg)
	{}

	operator opt_type()
	{
		return expression<const_action, int_<0> >();
	}
};

// x * 0 = 0
template <class Exp>
struct expression<mul_action, std::tr1::tuple<Exp, expression<const_action, int_<0> > > >
{
	typedef mul_action action_type;
	typedef std::tr1::tuple<Exp, expression<const_action, int_<0> > > argument_type;

	typedef expression<const_action, int_<0> > opt_type;

	expression(const argument_type& arg)
	{}

	operator opt_type()
	{
		return expression<const_action, int_<0> >();
	}
};



// exp(log(x)) = x
template <class Exp>
struct expression<exp_action, std::tr1::tuple<expression<log_action, std::tr1::tuple<Exp> > > >
{
	typedef mul_action action_type;
	typedef std::tr1::tuple<expression<log_action, std::tr1::tuple<Exp> > > argument_type;

	typedef Exp opt_type;

	argument_type arg;

	expression(const argument_type& arg)
		: arg(arg)
	{}

	operator opt_type()
	{
		return std::tr1::get<0>(std::tr1::get<0>(arg).arg);
	}
};

// exp(y*log(x)) = pow(x, y)
template <class Exp1, class Exp2>
struct expression<exp_action, std::tr1::tuple<expression<mul_action, std::tr1::tuple<Exp1, expression<log_action, std::tr1::tuple<Exp2> > > > > >
{
	typedef mul_action action_type;
	typedef std::tr1::tuple<expression<mul_action, std::tr1::tuple<Exp1, expression<log_action, std::tr1::tuple<Exp2> > > > > argument_type;

	typedef expression<pow_action, std::tr1::tuple<Exp2, Exp1> > opt_type;

	typedef expression<mul_action, std::tr1::tuple<Exp1, expression<log_action, std::tr1::tuple<Exp2> > > > lhs_type;

	argument_type arg;

	expression(const argument_type& arg)
		: arg(arg)
	{}

	operator opt_type()
	{
		return opt_type
		(
			std::tr1::tuple<Exp2, Exp1>
			(
				std::tr1::get<0>(std::tr1::get<1>(std::tr1::get<0>(arg).arg).arg),
				                 std::tr1::get<0>(std::tr1::get<0>(arg).arg)
			)
		);
	}

	friend std::ostream& operator<<(std::ostream& o, const expression& exp)
	{
		o<<"exp("<<std::tr1::get<0>(exp.arg)<<")";
		return o;
	}
};

// exp(log(x) * y) = pow(x, y)
template <class Exp1, class Exp2>
struct expression<exp_action, std::tr1::tuple<expression<mul_action, std::tr1::tuple<expression<log_action, std::tr1::tuple<Exp2> >, Exp1> > > >
{
	typedef mul_action action_type;
	typedef std::tr1::tuple<expression<mul_action, std::tr1::tuple<Exp1, expression<log_action, std::tr1::tuple<Exp2> > > > > argument_type;

	typedef expression<pow_action, std::tr1::tuple<Exp2, Exp1> > opt_type;

	typedef expression<mul_action, std::tr1::tuple<Exp1, expression<log_action, std::tr1::tuple<Exp2> > > > lhs_type;

	argument_type arg;

	expression(const argument_type& arg)
		: arg(arg)
	{}

	operator opt_type()
	{
		return opt_type
		(
			std::tr1::tuple<Exp2, Exp1>
			(
				std::tr1::get<0>(std::tr1::get<0>(std::tr1::get<0>(arg).arg).arg),
				                 std::tr1::get<1>(std::tr1::get<0>(arg).arg)
			)
		);
	}

	friend std::ostream& operator<<(std::ostream& o, const expression& exp)
	{
		o<<"exp("<<std::tr1::get<0>(exp.arg)<<")";
		return o;
	}
};

#endif //OPT_H