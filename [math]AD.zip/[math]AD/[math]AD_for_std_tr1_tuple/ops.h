#ifndef OPS_H
#define OPS_H

template <class A, class B, class C, class D>
typename expression<add_action, std::tr1::tuple<expression<A, B>, expression<C, D> > >::opt_type
operator + (const expression<A, B>& lhs, const expression<C, D>& rhs)
{
	return expression<add_action, std::tr1::tuple<expression<A, B>, expression<C, D> > >
		(std::tr1::tuple<expression<A, B>, expression<C, D> >(lhs, rhs));
}

template <class A, class B, class C, class D>
typename expression<mul_action, std::tr1::tuple<expression<A, B>, expression<C, D> > >::opt_type
operator * (const expression<A, B>& lhs, const expression<C, D>& rhs)
{
	return expression<mul_action, std::tr1::tuple<expression<A, B>, expression<C, D> > >
		(std::tr1::tuple<expression<A, B>, expression<C, D> >(lhs, rhs));
}

template <class A, class B, class C, class D>
typename expression<sub_action, std::tr1::tuple<expression<A, B>, expression<C, D> > >::opt_type
operator - (const expression<A, B>& lhs, const expression<C, D>& rhs)
{
	return expression<sub_action, std::tr1::tuple<expression<A, B>, expression<C, D> > >
		(std::tr1::tuple<expression<A, B>, expression<C, D> >(lhs, rhs));
}

template <class A, class B, class C, class D>
typename expression<div_action, std::tr1::tuple<expression<A, B>, expression<C, D> > >::opt_type
operator / (const expression<A, B>& lhs, const expression<C, D>& rhs)
{
	return expression<div_action, std::tr1::tuple<expression<A, B>, expression<C, D> > >
		(std::tr1::tuple<expression<A, B>, expression<C, D> >(lhs, rhs));
}

template <class A, class B, class C, class D>
typename expression<pow_action, std::tr1::tuple<expression<A, B>, expression<C, D> > >::opt_type
pow(const expression<A, B>& lhs, const expression<C, D>& rhs)
{
	return expression<pow_action, std::tr1::tuple<expression<A, B>, expression<C, D> > >
		(std::tr1::tuple<expression<A, B>, expression<C, D> >(lhs, rhs));
}

template <class Exp>
typename expression<log_action, std::tr1::tuple<Exp> >::opt_type
log(const Exp& lhs)
{
	return expression<log_action, std::tr1::tuple<Exp> >(std::tr1::tuple<Exp>(lhs));
}

template <class Exp>
typename expression<exp_action, std::tr1::tuple<Exp> >::opt_type
exp(const Exp& lhs)
{
	return expression<exp_action, std::tr1::tuple<Exp> >(std::tr1::tuple<Exp>(lhs));
}

template <class Exp>
typename expression<sin_action, std::tr1::tuple<Exp> >::opt_type
sin(const Exp& lhs)
{
	return expression<sin_action, std::tr1::tuple<Exp> >(std::tr1::tuple<Exp>(lhs));
}

template <class Exp>
typename expression<cos_action, std::tr1::tuple<Exp> >::opt_type
cos(const Exp& lhs)
{
	return expression<cos_action, std::tr1::tuple<Exp> >(std::tr1::tuple<Exp>(lhs));
}

template <class Arg>
typename expression<var_action, Arg>::opt_type
var(const Arg& lhs)
{
	return expression<var_action, Arg >(lhs);
}

#endif OPS_H