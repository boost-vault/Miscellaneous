#ifndef DERIT_H
#define DERIT_H

//--------------------------------------------------------------------------------------------------------
//--------------------------------------------derivative--------------------------------------------------

template <class Exp, class Var>
struct derivative;

template <class Arg, int N>
struct derivative<expression<var_action, Arg >, expression<var_action, int_<N> > >
{
	typedef expression<var_action, Arg > exp_type;
	typedef expression<var_action, int_<N> > var_type;

	typedef expression<const_action, int_<0> > derivative_type;

	static derivative_type derivate(const exp_type& exp)
	{
		return derivative_type();
	}
};

template <int N>
struct derivative<expression<var_action, int_<N> >, expression<var_action, int_<N> > >
{
	typedef expression<var_action, int_<N> > exp_type;
	typedef expression<var_action, int_<N> > var_type;

	typedef expression<const_action, int_<1> > derivative_type;

	static derivative_type derivate(const exp_type& exp)
	{
		return derivative_type();
	}
};

template <int M, int N>
struct derivative<expression<var_action, int_<M> >, expression<var_action, int_<N> > >
{
	typedef expression<var_action, int_<M> > exp_type;
	typedef expression<var_action, int_<N> > var_type;

	typedef expression<const_action, int_<0> > derivative_type;

	static derivative_type derivate(const exp_type& exp)
	{
		return derivative_type();
	}
};


template <int M, int N>
struct derivative<expression<const_action, int_<M> >, expression<var_action, int_<N> > >
{
	typedef expression<const_action, int_<M> > exp_type;
	typedef expression<var_action, int_<N> > var_type;

	typedef expression<const_action, int_<0> > derivative_type;

	static derivative_type derivate(const exp_type& exp)
	{
		return derivative_type();
	}
};

template <class Arg, class Var>
struct derivative<expression<add_action, Arg>, Var>
{
	typedef expression<add_action, Arg> exp_type;
	typedef Var var_type;

	typedef typename expression
			<
				add_action, 
				std::tr1::tuple
				<
					typename derivative<typename exp_type::lhs_type, Var>::derivative_type,
					typename derivative<typename exp_type::rhs_type, Var>::derivative_type
				>
			>::opt_type
			derivative_type;

	static derivative_type derivate(const exp_type& exp)
	{
		return derivative_type
			(
				expression
				<
					add_action, 
					std::tr1::tuple
					<
						typename derivative<typename exp_type::lhs_type, Var>::derivative_type,
						typename derivative<typename exp_type::rhs_type, Var>::derivative_type
					>
				>
				(
					std::tr1::tuple
					<
						typename derivative<typename exp_type::lhs_type, Var>::derivative_type,
						typename derivative<typename exp_type::rhs_type, Var>::derivative_type
					>
					(
						typename derivative<typename exp_type::lhs_type, Var>::derivate(std::tr1::get<0>(exp.arg)),
						typename derivative<typename exp_type::rhs_type, Var>::derivate(std::tr1::get<1>(exp.arg))
					)
				)
			);
	}
};
template <class Arg, class Var>
struct derivative<expression<sub_action, Arg>, Var>
{
	typedef expression<sub_action, Arg> exp_type;
	typedef Var var_type;

	typedef typename expression
			<
				sub_action, 
				std::tr1::tuple
				<
					typename derivative<typename exp_type::lhs_type, Var>::derivative_type,
					typename derivative<typename exp_type::rhs_type, Var>::derivative_type
				>
			>::opt_type
			derivative_type;

	static derivative_type derivate(const exp_type& exp)
	{
		return derivative_type
			(
				expression
				<
					sub_action, 
					std::tr1::tuple
					<
						typename derivative<typename exp_type::lhs_type, Var>::derivative_type,
						typename derivative<typename exp_type::rhs_type, Var>::derivative_type
					>
				>
				(
					std::tr1::tuple
					<
						typename derivative<typename exp_type::lhs_type, Var>::derivative_type,
						typename derivative<typename exp_type::rhs_type, Var>::derivative_type
					>
					(
						typename derivative<typename exp_type::lhs_type, Var>::derivate(std::tr1::get<0>(exp.arg)),
						typename derivative<typename exp_type::rhs_type, Var>::derivate(std::tr1::get<1>(exp.arg))
					)
				)
			);
	}
};
template <class Arg, class Var>
struct derivative<expression<mul_action, Arg>, Var>
{
	typedef expression<mul_action, Arg> exp_type;
	typedef Var var_type;

	typedef typename expression
			<
				add_action,
				std::tr1::tuple
				<
					typename expression
					<
						mul_action,
						std::tr1::tuple
						<
							typename derivative<typename exp_type::lhs_type, Var>::derivative_type,
							typename exp_type::rhs_type
						>
					>::opt_type,
					typename expression
					<
						mul_action,
						std::tr1::tuple
						<
							typename exp_type::lhs_type,
							typename derivative<typename exp_type::rhs_type, Var>::derivative_type
						>
					>::opt_type
				>
			>::opt_type
			derivative_type;

	static derivative_type derivate(const exp_type& exp)
	{
		return derivative_type
			(
				expression
				<
					add_action,
					std::tr1::tuple
					<
						typename expression
						<
							mul_action,
							std::tr1::tuple
							<
								typename derivative<typename exp_type::lhs_type, Var>::derivative_type,
								typename exp_type::rhs_type
							>
						>::opt_type,
						typename expression
						<
							mul_action,
							std::tr1::tuple
							<
								typename exp_type::lhs_type,
								typename derivative<typename exp_type::rhs_type, Var>::derivative_type
							>
						>::opt_type
					>
				>
				(
					std::tr1::tuple
					<
						typename expression
						<
							mul_action,
							std::tr1::tuple
							<
								typename derivative<typename exp_type::lhs_type, Var>::derivative_type,
								typename exp_type::rhs_type
							>
						>::opt_type,
						typename expression
						<
							mul_action,
							std::tr1::tuple
							<
								typename exp_type::lhs_type,
								typename derivative<typename exp_type::rhs_type, Var>::derivative_type
							>
						>::opt_type
					>
					(
						expression
						<
							mul_action,
							std::tr1::tuple
							<
								typename derivative<typename exp_type::lhs_type, Var>::derivative_type,
								typename exp_type::rhs_type
							>
						>
						(
							std::tr1::tuple
							<
								typename derivative<typename exp_type::lhs_type, Var>::derivative_type,
								typename exp_type::rhs_type
							>
							(
								typename derivative<typename exp_type::lhs_type, Var>::derivate(std::tr1::get<0>(exp.arg)),
								std::tr1::get<1>(exp.arg)
							)
						),
						expression
						<
							mul_action,
							std::tr1::tuple
							<
								typename exp_type::lhs_type,
								typename derivative<typename exp_type::rhs_type, Var>::derivative_type
							>
						>
						(
							std::tr1::tuple
							<
								typename exp_type::lhs_type,
								typename derivative<typename exp_type::rhs_type, Var>::derivative_type
							>
							(
								std::tr1::get<0>(exp.arg),
								typename derivative<typename exp_type::rhs_type, Var>::derivate(std::tr1::get<1>(exp.arg))
							)
						)
					)
				)
			);
	}
};

template <class Arg, class Var>
struct derivative<expression<div_action, Arg>, Var>
{
	typedef expression<div_action, Arg> exp_type;
	typedef Var var_type;

	typedef typename expression
			<
				div_action,
				std::tr1::tuple
				<
					typename expression
					<
						sub_action,
						std::tr1::tuple
						<
							typename expression
							<
								mul_action,
								std::tr1::tuple
								<
									typename derivative<typename exp_type::lhs_type, Var>::derivative_type,
									typename exp_type::rhs_type
								>
							>::opt_type,
							typename expression
							<
								mul_action,
								std::tr1::tuple
								<
									typename exp_type::lhs_type,
									typename derivative<typename exp_type::rhs_type, Var>::derivative_type
								>
							>::opt_type
						>
					>::opt_type,
					typename expression
					<
						mul_action,
						std::tr1::tuple
						<
							typename exp_type::rhs_type,
							typename exp_type::rhs_type
						>
					>::opt_type
				>
			>::opt_type
			derivative_type;

	static derivative_type derivate(const exp_type& exp)
	{
		return derivative_type
			(
				expression
				<
					div_action,
					std::tr1::tuple
					<
						typename expression
						<
							sub_action,
							std::tr1::tuple
							<
								typename expression
								<
									mul_action,
									std::tr1::tuple
									<
										typename derivative<typename exp_type::lhs_type, Var>::derivative_type,
										typename exp_type::rhs_type
									>
								>::opt_type,
								typename expression
								<
									mul_action,
									std::tr1::tuple
									<
										typename exp_type::lhs_type,
										typename derivative<typename exp_type::rhs_type, Var>::derivative_type
									>
								>::opt_type
							>
						>::opt_type,
						typename expression
						<
							mul_action,
							std::tr1::tuple
							<
								typename exp_type::rhs_type,
								typename exp_type::rhs_type
							>
						>::opt_type
					>
				>
				(
					std::tr1::tuple
					<
						typename expression
						<
							sub_action,
							std::tr1::tuple
							<
								typename expression
								<
									mul_action,
									std::tr1::tuple
									<
										typename derivative<typename exp_type::lhs_type, Var>::derivative_type,
										typename exp_type::rhs_type
									>
								>::opt_type,
								typename expression
								<
									mul_action,
									std::tr1::tuple
									<
										typename exp_type::lhs_type,
										typename derivative<typename exp_type::rhs_type, Var>::derivative_type
									>
								>::opt_type
							>
						>::opt_type,
						typename expression
						<
							mul_action,
							std::tr1::tuple
							<
								typename exp_type::rhs_type,
								typename exp_type::rhs_type
							>
						>::opt_type
					>
					(
						expression
						<
							sub_action,
							std::tr1::tuple
							<
								typename expression
								<
									mul_action,
									std::tr1::tuple
									<
										typename derivative<typename exp_type::lhs_type, Var>::derivative_type,
										typename exp_type::rhs_type
									>
								>::opt_type,
								typename expression
								<
									mul_action,
									std::tr1::tuple
									<
										typename exp_type::lhs_type,
										typename derivative<typename exp_type::rhs_type, Var>::derivative_type
									>
								>::opt_type
							>
						>
						(
							std::tr1::tuple
							<
								typename expression
								<
									mul_action,
									std::tr1::tuple
									<
										typename derivative<typename exp_type::lhs_type, Var>::derivative_type,
										typename exp_type::rhs_type
									>
								>::opt_type,
								typename expression
								<
									mul_action,
									std::tr1::tuple
									<
										typename exp_type::lhs_type,
										typename derivative<typename exp_type::rhs_type, Var>::derivative_type
									>
								>::opt_type
							>
							(
								expression
								<
									mul_action,
									std::tr1::tuple
									<
										typename derivative<typename exp_type::lhs_type, Var>::derivative_type,
										typename exp_type::rhs_type
									>
								>
								(
									std::tr1::tuple
									<
										typename derivative<typename exp_type::lhs_type, Var>::derivative_type,
										typename exp_type::rhs_type
									>
									(
										typename derivative<typename exp_type::lhs_type, Var>::derivate(std::tr1::get<0>(exp.arg)),
										std::tr1::get<1>(exp.arg)
									)
								),
								expression
								<
									mul_action,
									std::tr1::tuple
									<
										typename exp_type::lhs_type,
										typename derivative<typename exp_type::rhs_type, Var>::derivative_type
									>
								>
								(
									std::tr1::tuple
									<
										typename exp_type::lhs_type,
										typename derivative<typename exp_type::rhs_type, Var>::derivative_type
									>
									(
										std::tr1::get<0>(exp.arg),
										typename derivative<typename exp_type::rhs_type, Var>::derivate(std::tr1::get<1>(exp.arg))
									)
								)
							)
						),
						expression
						<
							mul_action,
							std::tr1::tuple
							<
								typename exp_type::rhs_type,
								typename exp_type::rhs_type
							>
						>
						(
							std::tr1::tuple
							<
								typename exp_type::rhs_type,
								typename exp_type::rhs_type
							>
							(
								std::tr1::get<1>(exp.arg),
								std::tr1::get<1>(exp.arg)
							)
						)
					)
				)
			);
	}
};

template <class Arg, class Var>
struct derivative<expression<pow_action, Arg>, Var>
{
	typedef expression<pow_action, Arg> exp_type;
	typedef Var var_type;

	typedef typename derivative
		<
			typename expression
			<
				exp_action, 
				std::tr1::tuple
				<
					typename expression
					<
						mul_action,
						std::tr1::tuple
						<
							typename exp_type::rhs_type,
							expression<log_action, std::tr1::tuple<typename exp_type::lhs_type > >
						>
					>
				>
			>,
			Var
		>::derivative_type
		derivative_type;

	static derivative_type derivate(const exp_type& exp)
	{
		return
		typename derivative
		<
			typename expression
			<
				exp_action, 
				std::tr1::tuple
				<
					typename expression
					<
						mul_action,
						std::tr1::tuple
						<
							typename exp_type::rhs_type,
							expression<log_action, std::tr1::tuple<typename exp_type::lhs_type > >
						>
					>
				>
			>,
			Var
		>::derivate
		(
			typename expression
			<
				exp_action, 
				std::tr1::tuple
				<
					typename expression
					<
						mul_action,
						std::tr1::tuple
						<
							typename exp_type::rhs_type,
							expression<log_action, std::tr1::tuple<typename exp_type::lhs_type > >
						>
					>
				>
			>
			(
				std::tr1::tuple
				<
					typename expression
					<
						mul_action,
						std::tr1::tuple
						<
							typename exp_type::rhs_type,
							expression<log_action, std::tr1::tuple<typename exp_type::lhs_type > >
						>
					>
				>
				(
					expression
					<
						mul_action,
						std::tr1::tuple
						<
							typename exp_type::rhs_type,
							expression<log_action, std::tr1::tuple<typename exp_type::lhs_type > >
						>
					>
					(
						std::tr1::tuple
						<
							typename exp_type::rhs_type,
							expression<log_action, std::tr1::tuple<typename exp_type::lhs_type > >
						>
						(
							std::tr1::get<1>(exp.arg),
							expression<log_action, std::tr1::tuple<typename exp_type::lhs_type > >
							(
								 std::tr1::tuple<typename exp_type::lhs_type >(std::tr1::get<0>(exp.arg))
							)
						)
					)
				)
			)
		);
	}
};

template <int N, int M, class Var>
struct derivative<expression<pow_action, std::tr1::tuple<expression<var_action, int_<N> >, expression<const_action, int_<M> > > >, Var>
{
	typedef expression<pow_action, std::tr1::tuple<expression<var_action, int_<N> >, expression<const_action, int_<M> > > > exp_type;
	typedef Var var_type;

	typedef typename expression
			<
				mul_action, 
				std::tr1::tuple
				<
					typename expression<pow_action, std::tr1::tuple<
						expression<var_action, int_<N> >, 
						expression<const_action, int_<M-1> >
						>
					>::opt_type,
					typename derivative<typename exp_type::lhs_type, Var>::derivative_type
				>
			>::opt_type
		derivative_type;

	static derivative_type derivate(const exp_type& exp)
	{
		return
		typename expression
		<
			mul_action, 
			std::tr1::tuple
			<
				typename expression<pow_action, std::tr1::tuple<
					expression<var_action, int_<N> >, 
					expression<const_action, int_<M-1> >
					>
				>::opt_type,
				typename derivative<typename exp_type::lhs_type, Var>::derivative_type
			>
		>
		(
			std::tr1::tuple
			<
				typename expression<pow_action, std::tr1::tuple<
					expression<var_action, int_<N> >, 
					expression<const_action, int_<M-1> >
					>
				>::opt_type,
				typename derivative<typename exp_type::lhs_type, Var>::derivative_type
			>
			(
				typename expression<pow_action, std::tr1::tuple<
					expression<var_action, int_<N> >, 
					expression<const_action, int_<M-1> >
					>
				>
				(
					std::tr1::tuple<
						expression<var_action, int_<N> >, 
						expression<const_action, int_<M-1> >
					>
					(
						expression<var_action, int_<N> >(),
						expression<const_action, int_<M-1> >()
					)
				),
				typename derivative<typename exp_type::lhs_type, Var>::derivate(std::tr1::get<0>(exp.arg))
			)
		);
	}
};


template <class Arg, class Var>
struct derivative<expression<log_action, Arg>, Var>
{
	typedef expression<log_action, Arg> exp_type;
	typedef Var var_type;

	typedef typename expression
			<
				mul_action, 
				std::tr1::tuple
				<
					expression<div_action, std::tr1::tuple<expression<const_action, int_<1> >,typename exp_type::lhs_type> >,
					typename derivative<typename exp_type::lhs_type, Var>::derivative_type
				>
			>::opt_type
			derivative_type;

	static derivative_type derivate(const exp_type& exp)
	{
		return derivative_type
			(
				expression
				<
					mul_action, 
					std::tr1::tuple
					<
						expression<div_action, std::tr1::tuple<expression<const_action, int_<1> >,typename exp_type::lhs_type> >,
						typename derivative<typename exp_type::lhs_type, Var>::derivative_type
					>
				>
				(
					std::tr1::tuple
					<
						expression<div_action, std::tr1::tuple<expression<const_action, int_<1> >,typename exp_type::lhs_type> >,
						typename derivative<typename exp_type::lhs_type, Var>::derivative_type
					>
					(
						expression<div_action, std::tr1::tuple<expression<const_action, int_<1> >,typename exp_type::lhs_type> >
						(
							std::tr1::tuple<expression<const_action, int_<1> >,typename exp_type::lhs_type> 
							(
								expression<const_action, int_<1> >(),
								std::tr1::get<0>(exp.arg)
							)
						),
						typename derivative<typename exp_type::lhs_type, Var>::derivate(std::tr1::get<0>(exp.arg))
					)
				)
			);
	}
};

template <class Arg, class Var>
struct derivative<expression<exp_action, Arg>, Var>
{
	typedef expression<exp_action, Arg> exp_type;
	typedef Var var_type;

	typedef typename expression
			<
				mul_action, 
				std::tr1::tuple
				<
					typename expression<exp_action, std::tr1::tuple<typename exp_type::lhs_type> >::opt_type,
					typename derivative<typename exp_type::lhs_type, Var>::derivative_type
				>
			>::opt_type
			derivative_type;

	static derivative_type derivate(const exp_type& exp)
	{
		return derivative_type
			(
				expression
				<
					mul_action, 
					std::tr1::tuple
					<
						typename expression<exp_action, std::tr1::tuple<typename exp_type::lhs_type> >::opt_type,
						typename derivative<typename exp_type::lhs_type, Var>::derivative_type
					>
				>
				(
					std::tr1::tuple
					<
						typename expression<exp_action, std::tr1::tuple<typename exp_type::lhs_type> >::opt_type,
						typename derivative<typename exp_type::lhs_type, Var>::derivative_type
					>
					(
						typename expression<exp_action, std::tr1::tuple<typename exp_type::lhs_type> >::opt_type
						(
							expression<exp_action, std::tr1::tuple<typename exp_type::lhs_type> >
							(
								std::tr1::tuple<typename exp_type::lhs_type>(std::tr1::get<0>(exp.arg))
							)
						),
						typename derivative<typename exp_type::lhs_type, Var>::derivate(std::tr1::get<0>(exp.arg))
					)
				)
			);
	}
};

template <class Arg, class Var>
struct derivative<expression<sin_action, Arg>, Var>
{
	typedef expression<sin_action, Arg> exp_type;
	typedef Var var_type;

	typedef typename expression
			<
				mul_action, 
				std::tr1::tuple
				<
					typename expression<cos_action, std::tr1::tuple<typename exp_type::lhs_type> >::opt_type,
					typename derivative<typename exp_type::lhs_type, Var>::derivative_type
				>
			>::opt_type
			derivative_type;

	static derivative_type derivate(const exp_type& exp)
	{
		return derivative_type
			(
				expression
				<
					mul_action, 
					std::tr1::tuple
					<
						typename expression<cos_action, std::tr1::tuple<typename exp_type::lhs_type> >::opt_type,
						typename derivative<typename exp_type::lhs_type, Var>::derivative_type
					>
				>
				(
					std::tr1::tuple
					<
						typename expression<cos_action, std::tr1::tuple<typename exp_type::lhs_type> >::opt_type,
						typename derivative<typename exp_type::lhs_type, Var>::derivative_type
					>
					(
						typename expression<cos_action, std::tr1::tuple<typename exp_type::lhs_type> >::opt_type
						(
							expression<cos_action, std::tr1::tuple<typename exp_type::lhs_type> >
							(
								std::tr1::tuple<typename exp_type::lhs_type>(std::tr1::get<0>(exp.arg))
							)
						),
						typename derivative<typename exp_type::lhs_type, Var>::derivate(std::tr1::get<0>(exp.arg))
					)
				)
			);
	}
};

template <class Arg, class Var>
struct derivative<expression<cos_action, Arg>, Var>
{
	typedef expression<cos_action, Arg> exp_type;
	typedef Var var_type;

	typedef typename expression
			<
				mul_action, 
				std::tr1::tuple
				<
					typename expression<sin_action, std::tr1::tuple<typename exp_type::lhs_type> >::opt_type,
					typename derivative<typename exp_type::lhs_type, Var>::derivative_type
				>
			>::opt_type
			derivative_type;

	static derivative_type derivate(const exp_type& exp)
	{
		return derivative_type
			(
				expression
				<
					mul_action, 
					std::tr1::tuple
					<
						typename expression<sin_action, std::tr1::tuple<typename exp_type::lhs_type> >::opt_type,
						typename derivative<typename exp_type::lhs_type, Var>::derivative_type
					>
				>
				(
					std::tr1::tuple
					<
						typename expression<sin_action, std::tr1::tuple<typename exp_type::lhs_type> >::opt_type,
						typename derivative<typename exp_type::lhs_type, Var>::derivative_type
					>
					(
						typename expression<sin_action, std::tr1::tuple<typename exp_type::lhs_type> >::opt_type
						(
							expression<sin_action, std::tr1::tuple<typename exp_type::lhs_type> >
							(
								std::tr1::tuple<typename exp_type::lhs_type>(std::tr1::get<0>(exp.arg))
							)
						),
						typename derivative<typename exp_type::lhs_type, Var>::derivate(std::tr1::get<0>(exp.arg))
					)
				)
			);
	}
};

#endif //DERIT_H