#include "lambda_tuple.hpp"
#include <iostream>
#include <boost/assign.hpp>
#include <boost/tuple/tuple_io.hpp>
#include <iterator>
#include <boost/lambda/bind.hpp>

using namespace boost::lambda;
using namespace std;
using namespace boost::tuples;
using namespace boost::assign;

//#define TYPE pair
#define TYPE tuple

int main(int argc, char* argv[])
{
  list< TYPE< int, double > > l= BOOST_PP_CAT(TYPE, _list_of)
    (1, 2.72)
    (2, 3.14)
    (3, 1.414);
  
  for_each(l.begin(), l.end(), cout << constant("FIRST: ") << get<0>(_1) << "\n");
  for_each(l.begin(), l.end(), cout << constant("SECOND: ") << get<1>(_1) << "\n");
  
  cout << endl;

  vector< TYPE<int, double> > v;
  
  copy(l.begin(), l.end(), back_inserter(v));

  sort(v.begin(), v.end(), get<1>(_1) < get<1>(_2));
  
  for_each(v.begin(), v.end(), cout << get<0>(_1) << " " << get<1>(_1) << "\n");

  tuple<int, double, tuple<int, int> > t3 = make_tuple(4, 5.2, make_tuple(37, 137));
  cout << (get<2>(_1))(t3) << endl;
  
  cout << t3 << endl;

  return 0;
}
