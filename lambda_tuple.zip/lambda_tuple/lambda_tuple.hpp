// get<N> for lambda expressions that evaluate to tuple or pair suggestion
//
// Author: Giuseppe Ottaviano <giuott@tin.it>

#include <boost/tuple/tuple.hpp>

#include <boost/lambda/lambda.hpp>

#include <boost/utility/enable_if.hpp>
#include <boost/type_traits.hpp>
#include <boost/mpl/has_xxx.hpp>

#include <utility>

namespace detail {

  using namespace boost::lambda;
  using boost::enable_if;

  // Assume that a type is a tuple iff has head_type
  BOOST_MPL_HAS_XXX_TRAIT_DEF(head_type);
  // and that a type is a pair iff has first_type
  BOOST_MPL_HAS_XXX_TRAIT_DEF(first_type);

  template<int N, class A, class Enable = void>
  struct result_type_aux {};

  template<int N, class A>
  struct result_type_aux<N, A, typename enable_if<has_head_type<A> >::type > 
    : boost::tuples::element<N, A>    {};

  // What about const, reference, etc... here?
  template<class A>
  struct result_type_aux<0, A, typename enable_if<has_first_type<A> >::type > {
    typedef typename A::first_type type;
  };

  template<class A>
  struct result_type_aux<1, A, typename enable_if<has_first_type<A> >::type > {
    typedef typename A::second_type type;
  };

  template<int N, class RET, class Pair>
  typename boost::enable_if_c<N == 0, RET>::type
  get_pair_aux(Pair& p) {
    return p.first;
  }

  template<int N, class RET, class Pair>
  typename boost::enable_if_c<N == 1, RET>::type
  get_pair_aux(Pair& p) {
    return p.second;
  }
  
  template<int N> 
  class get_action 
  {
  public:
    
    template<class RET, class A>
    static typename enable_if<has_head_type<A>, 
                              RET>::type
    apply(A &a1) {
      return boost::tuples::get<N>(a1);
    }

    template<class RET, class A>
    static typename enable_if<has_first_type<A>, 
                              RET>::type
    apply(A &a1) {
      return get_pair_aux<N, RET>(a1);
    }
  };

  template <int N, class Arg1>
  inline const lambda_functor<
    lambda_functor_base<
      action<1, get_action<N> >, 
      tuple<typename const_copy_argument <const Arg1>::type>
      > 
    >
  get(const Arg1& a1) { 
    return 
      lambda_functor_base<
    action<1, get_action<N> >, 
      tuple<typename const_copy_argument <const Arg1>::type> 
      > 
    ( tuple<typename const_copy_argument <const Arg1>::type>(a1));
  }
  
}

namespace boost { namespace lambda {
    template<int N, class A>
    struct return_type_N< ::detail::get_action<N>, 
                          boost::tuples::cons< A, null_type> > 
    : ::detail::result_type_aux<N, A> {};
  
}}

using detail::get;
