/** \file 
 * \brief Code for a set of classes for working with smooth functions
 *
 *  c2_functions.cc
 *
 *  Created by Marcus H. Mendenhall and R. A. Weller on 7/9/05.
 *  Copyright &copy; 2005 Vanderbilt University. All rights reserved.
 *  to be published under the Boost License
 *
 */

#include <iostream>
#include <vector>
#include <algorithm>
#include <cstdlib>
#include <numeric>
#include <functional>
#include <iterator>
#include <cmath>
#include <limits>

#include "c2_function.h"

//! the versioning string for the file
const char c2_function::cvs_vers[]="$Id: c2_function.cc,v 1.15 2006/03/25 16:23:34 marcus Exp $";

// find a pre-bracketed root of a c2_function, which is a MUCH easier job than general root finding
// since the derivatives are known exactly, and smoothness is guaranteed.
// this searches for f(x)=value, to make life a little easier than always searching for f(x)=0
double c2_function::find_root(double lower_bracket, double upper_bracket, double start, double value, 
        int *error, int *evaluations) const
{
    // find f(x)=value within the brackets, 
    // using the guarantees of smoothness associated with a c2_function
    // can use local f(x)=a*x**2 + b*x + c and solve quadratic to find root, then iterate
    
    double ftol=5*(std::numeric_limits<double>::epsilon()*std::abs(value)+
                std::numeric_limits<double>::min());
    double xtol=5*(std::numeric_limits<double>::epsilon()*(std::abs(upper_bracket)+
                std::abs(lower_bracket))+std::numeric_limits<double>::min());
    
    double root=start; // start looking in the middle
    if(error) *error=0; // start out with error flag set to OK, if it is expected
    
    double c, b, ypp;
    double cupper=value_with_derivatives(upper_bracket, &b, &ypp)-value;
    if(*evaluations) (*evaluations)++;
    if(std::abs(cupper) < ftol) return upper_bracket;
    double clower=value_with_derivatives(lower_bracket, &b, &ypp)-value;
    if(*evaluations) (*evaluations)++;
    if(std::abs(clower) < ftol) return lower_bracket;
    
    if(cupper*clower >0) { 
        // argh, no sign change in here!
        if(error) { *error=1; return 0.0; }
        else { 
            char buf[256]; 
            snprintf(buf, sizeof(buf)-1, 
                    "unbracketed root in find_root at xlower=%g, xupper=%g, bailing\n", 
                     lower_bracket, upper_bracket);
            throw c2_exception(buf);
        }
    }
           
   double delta=upper_bracket-lower_bracket; // first error step
   c=value_with_derivatives(root, &b, &ypp)-value; // compute initial values
   if(*evaluations) (*evaluations)++;
   
   while(std::abs(delta) > xtol) { // can allow quite small steps, since we have exact derivatives!
       double a=ypp/2; // second derivative is 2*a
       double disc=b*b-4*a*c;
       
       if(disc >= 0) {
           double q=-0.5*((b>=0)?(b+std::sqrt(disc)):(b-std::sqrt(disc)));
           if(q*q > std::abs(a*c)) delta=c/q; // since x1=q/a, x2=c/q, x1/x2=q^2/ac, this picks smaller step
           else delta=q/a;
           root+=delta;
       }
       
       if(disc < 0 || root<lower_bracket || root>upper_bracket) { // if we jump out of the bracket, bisect
           root=0.5*(lower_bracket+upper_bracket);
           delta=upper_bracket-lower_bracket;
       }
       c=value_with_derivatives(root, &b, &ypp)-value; // get local curvature and value
       if(*evaluations) (*evaluations)++;
       
       if(std::abs(c) < ftol || std::abs(c) < xtol*std::abs(b) ) return root; // got it exactly

       // now, close in bracket on whichever side this still brackets
       if(c*clower < 0.0) {
           cupper=c;
           upper_bracket=root;
       } else {
           clower=c;
           lower_bracket=root;
       }
       // std::cout << "find_root_debug x, y, dx " << root << " "  << c << " " << delta << std::endl;
   }
   return root;
}

//! \struct fblock structure used for recursion in adaptive integrator
struct fblock {    double x, y, yp, ypp; };
//! \struct recur structure used for recursion in adaptive integrator
struct recur { struct fblock *f0, *f1, *f2;
    double abs_tol, rel_tol, *lr, eps_scale, extrap_coef, extrap2;
    int depth, derivs, evaluations;
    bool adapt, extrapolate;
};

// the recursive part of the integrator is agressively designed to minimize copying of data... lots of pointers
double c2_function::integrate_step(struct recur &rb) const
{
    struct fblock *fbl[3]={rb.f0, rb.f1, rb.f2}; 
    struct fblock f1; // will hold new middle values
    double retvals[2]={0.0,0.0};
    double lr[2];

    // std::cout << "entering with " << rb.f0->x << " " << rb.f1->x << " " << rb.f2->x << std::endl;
    
    int depth=rb.depth; // save this from the recursion block
    double abs_tol=rb.abs_tol;  // this is the value we will pass down
    double *rblr=rb.lr; // save pointer to our parent's lr[2] array since it will get trampled in recursion
    
    if(!depth) {
        switch(rb.derivs) {
            case 0:
                rb.eps_scale=0.1; rb.extrap_coef=16; break;
            case 1:
                rb.eps_scale=0.1; rb.extrap_coef=64; break;
            case 2:
                rb.eps_scale=0.02; rb.extrap_coef=1024; break;
            default:
                throw c2_exception("derivs must be 0, 1 or 2 in partial_integrals");
        }
        
        rb.extrap2=1.0/(rb.extrap_coef-1.0);
    }
    
    for (int i=0; i<(depth==0?1:2); i++) { // handle left and right intervals, but only left one for depth=0
        struct fblock *f0=fbl[i], *f2=fbl[i+1];
        f1.x=0.5*(f0->x + f2->x); // center of interval
        double dx=f2->x - f0->x;
        double dx2 = 0.5*dx;
        double total;
        
        f1.y=value_with_derivatives(f1.x, &(f1.yp), &(f1.ypp));
        rb.evaluations++; 
        
        // check for underflow on step size, which prevents us from achieving specified accuracy. 
        if(std::abs(dx) < std::abs(f1.x)*rb.rel_tol) {
            char buf[256]; 
            snprintf(buf, sizeof(buf)-1, 
                     "Step size underflow in adaptive_partial_integrals at depth=%d, x=%.4g", 
                     depth, f1.x);
            throw c2_exception(buf);
        }
        
        if(!depth) { // top level, total has not been initialized yet
            switch(rb.derivs) { // create estimate of next lower order for first try
                case 0:
                    total=0.5*(f0->y+f2->y)*dx; break;
                case 1:
                    total=(f0->y+4.0*f1.y+f2->y)*dx/6.0; break;
                case 2:
                    total=( (14*f0->y + 32*f1.y + 14*f2->y) +  dx * (f0->yp - f2->yp) ) * dx /60.; break;
                default:
                    total=0.0; // just to suppress missing default warnings
            }
        } else total=rblr[i]; // otherwise, get it from previous level
        
        double left, right;
        
        switch(rb.derivs) {
            case 2:
                // use ninth-order estimates for each side, from full set of all values (!) (Thanks, Mathematica!)
                left=  ( ( (169*f0->ypp + 1024*f1.ypp - 41*f2->ypp)*dx2 + (2727*f0->yp - 5040*f1.yp + 423*f2->yp) )*dx2 + (17007*f0->y + 24576*f1.y - 1263*f2->y) )* (dx2/40320.0);
                right= ( ( (169*f2->ypp + 1024*f1.ypp - 41*f0->ypp)*dx2 - (2727*f2->yp - 5040*f1.yp + 423*f0->yp) )*dx2 + (17007*f2->y + 24576*f1.y - 1263*f0->y) )* (dx2/40320.0);
                // std::cout << f0->x << " " << f1.x << " " << f2->x <<  std::endl ;
                // std::cout << f0->y << " " << f1.y << " " << f2->y << " " << left << " " << right << " " << total << std::endl ;
                break;
            case 1:
                left=  ( (202*f0->y + 256*f1.y + 22*f2->y) + dx*(13*f0->yp - 40*f1.yp - 3*f2->yp) ) * dx /960.;
                right= ( (202*f2->y + 256*f1.y + 22*f0->y) - dx*(13*f2->yp - 40*f1.yp - 3*f0->yp) ) * dx /960.;
                break;
            case 0:
                left=  (5*f0->y + 8*f1.y - f2->y)*dx/24.;
                right= (5*f2->y + 8*f1.y - f0->y)*dx/24.;
                break;
            default:
                left=right=0.0; // suppress warnings about missing default
                break;
        }
        
        lr[0]= left; // left interval
        lr[1]= right; // right interval
        double lrsum=left+right;

        double eps=std::abs(total-lrsum)*rb.eps_scale; 
        if(rb.extrapolate) eps*=rb.eps_scale; 

        // std::cout << rb.depth << " " << eps << " " << left << " " << right << " " << total << " " << lrsum << " " << eps/abs_tol << std::endl;
        
        if(!rb.adapt || eps < abs_tol ||  eps < std::abs(total)*rb.rel_tol) {
            if(depth==0 || !rb.extrapolate) retvals[i]=lrsum;
            else {
                retvals[i]=(rb.extrap_coef*lrsum - total)*rb.extrap2;     
                // std::cout << "extrapolating " << lrsum << " " << total << " " << retvals[i] << std::endl;
                
            }
        } else {
            rb.depth=depth+1; // increment depth counter
            rb.lr=lr;  // point to our left-right values array for recursion
            rb.abs_tol=abs_tol*0.5; // each half has half the error budget
            rb.f0=f0; rb.f1=&f1; rb.f2=f2; // insert pointers to data into our recursion block
            // std::cout << "recurring with " << f0->x << " " << f1.x << " " << f2->x <<  std::endl ;
            retvals[i]=integrate_step(rb); // and recur
        }
    }    
    return retvals[0]+retvals[1];
}

std::vector<double> &c2_function::get_sampling_grid(double xmin, double xmax) const 
{
    std::vector<double> *result=new std::vector<double>;
    
    if( !(sampling_grid) || !(sampling_grid->size()) || (xmax <= sampling_grid->front()) || (xmin >= sampling_grid->back()) ) { 
        // nothing is known about the function in this region, return xmin and xmax        
        result->push_back(xmin);
        result->push_back(xmax);
    } else {    
        std::vector<double> &sg=*sampling_grid; // just a shortcut
        int np=sg.size();
        int klo=0, khi=np-1, firstindex=0, lastindex=np-1;
        
        result->push_back(xmin);

        if(xmin > sg.front() ) {
            // hunt through table for position bracketing starting point
            while(khi-klo > 1) {
                int km=(khi+klo)/2;
                if(sg[km] > xmin) khi=km;
                else klo=km;
            }
            khi=klo+1;
            // khi now points to first point definitively beyond our first point, or last point of array
            firstindex=khi;
            khi=np-1; // restart upper end of search
        }
        
        if(xmax < sg.back()) {
            // hunt through table for position bracketing starting point
            while(khi-klo > 1) {
                int km=(khi+klo)/2;
                if(sg[km] > xmax) khi=km;
                else klo=km;
            }
            khi=klo+1;
            // khi now points to first point definitively beyond our last point, or last point of array
            lastindex=klo;
        }
        
        int initsize=result->size();
        result->resize(initsize+(lastindex-firstindex+2));
        std::copy(sg.begin()+firstindex, sg.begin()+lastindex+1, result->begin()+initsize);
        result->back()=xmax;
        
        //  this is the unrefined sampling grid... now check for very close points on front & back and fix if needed.
        preen_sampling_grid(result);
    }
    return *result;
}

void c2_function::preen_sampling_grid(std::vector<double> *result) 
{        
    //  this is the unrefined sampling grid... now check for very close points on front & back and fix if needed.
    if(result->size() > 2) { 
        // may be able to prune dangerously close points near the ends if there are at least 3 points
        bool deleteit=false;
        double x0=(*result)[0], x1=(*result)[1];
        double dx1=x1-x0;
        
        double ftol=10.0*(std::numeric_limits<double>::epsilon()*(std::abs(x0)+std::abs(x1))+
                          std::numeric_limits<double>::min());
        if(dx1 < ftol) deleteit=true;
        double dx2=(*result)[2]-x0;
        if(dx1/dx2 < 0.1) deleteit=true; // endpoint is very close to internal interesting point
        
        if(deleteit) result->erase(result->begin()+1); // delete redundant interesting point
    }
    
    if(result->size() > 2) { 
        // may be able to prune dangerously close points near the ends if there are at least 3 points
        bool deleteit=false;
        int pos=result->size()-3;
        double x0=(*result)[pos+1], x1=(*result)[pos+2];
        double dx1=x1-x0;
        
        double ftol=10.0*(std::numeric_limits<double>::epsilon()*(std::abs(x0)+std::abs(x1))+
                          std::numeric_limits<double>::min());
        if(dx1 < ftol) deleteit=true;
        double dx2=x1-(*result)[pos];
        if(dx1/dx2 < 0.1) deleteit=true; // endpoint is very close to internal interesting point
        
        if(deleteit) result->erase(result->end()-2); // delete redundant interesting point
    }
}

std::vector<double> &c2_function::refine_sampling_grid(const std::vector<double> &grid, size_t refinement) 
{
    size_t np=grid.size();
    size_t count=(np-1)*refinement + 1;
    double dxscale=1.0/refinement;
    
    std::vector<double> *result=new std::vector<double>(count);
    std::vector<double>::iterator out=result->begin();
    
    for(size_t i=0; i<(np-1); i++) {
        double x=grid[i];
        double dx=(grid[i+1]-x)*dxscale;
        for(size_t j=0; j<refinement; j++, x+=dx) *(out++)=x;
    }
    *out=grid.back();
    return *result;
}
double c2_function::integral(double xmin, double xmax, std::vector<double> *partials,
                                     double abs_tol, double rel_tol, int derivs, bool adapt, 
                                     bool extrapolate, int *evaluations) const
{
    std::vector<double> &grid=get_sampling_grid(xmin, xmax);
    double intg=partial_integrals(grid, partials, abs_tol, rel_tol, adapt, extrapolate, evaluations);
    delete &grid;
    return intg;
}

c2_function &c2_function::normalized_function(double xmin, double xmax, double norm) 
{
    double intg=integral(xmin, xmax);
    return *new c2_scaled_function(*this, norm/intg);
}

c2_function &c2_function::square_normalized_function(double xmin, double xmax, double norm) 
{
    c2_quadratic q(0., 0., 0., 1.);
    c2_composed_function mesquared(q,*this);
    
    std::vector<double> grid(get_sampling_grid(xmin, xmax));        
    double intg=mesquared.partial_integrals(grid);
    
    return *new c2_scaled_function(*this, std::sqrt(norm/intg));
}

c2_function &c2_function::square_normalized_function(double xmin, double xmax, const c2_function &weight, double norm)
{
    c2_quadratic q(0., 0., 0., 1.);
    c2_composed_function mesquared(q,*this);
    c2_product weighted(mesquared, weight); 

    std::vector<double> grid(get_sampling_grid(xmin, xmax));    
    double intg=weighted.partial_integrals(grid);

    return *new c2_scaled_function(*this, std::sqrt(norm/intg));
}

double c2_function::partial_integrals(std::vector<double> &xgrid, std::vector<double> *partials,
                                             double abs_tol, double rel_tol, int derivs, bool adapt, 
                                             bool extrapolate, int *evaluations) const
{
    int np=xgrid.size();
    
    struct fblock f0, f2;
    struct recur rb;
    rb.rel_tol=rel_tol;
    rb.extrapolate=extrapolate;
    rb.adapt=adapt;
    rb.derivs=derivs;
    rb.evaluations=0;
        
    if(partials) partials->resize(np-1);
    
    double sum=0.0;
    
    f2.x=xgrid[0];
    f2.y=value_with_derivatives(f2.x, &f2.yp, &f2.ypp);
    rb.evaluations++;
    
    for(int i=0; i<np-1; i++) {
        f0=f2; // copy upper bound to lower before computing new upper bound
        
        f2.x=xgrid[i+1];
        f2.y=value_with_derivatives(f2.x, &f2.yp, &f2.ypp);
        rb.evaluations++;
        
        rb.depth=0;
        rb.abs_tol=abs_tol;
        rb.f0=&f0; rb.f1=&f2; rb.f2=&f2; // we are really only using the left half for the top level
        rb.lr=0; // pointer is meaningless; will be filled in in recursion
        double ps=integrate_step(rb);
        sum+=ps;
        if(partials) (*partials)[i]=ps;
    }
    if(*evaluations) *evaluations+=rb.evaluations;
    return sum;
}

// declare singleton functions for most common c2_function instances 
c2_sin c2_sin::sin=c2_sin();
c2_cos c2_cos::cos=c2_cos();
c2_log c2_log::log=c2_log();
c2_exp c2_exp::exp=c2_exp();
c2_sqrt c2_sqrt::sqrt=c2_sqrt();
c2_recip c2_recip::recip=c2_recip();
c2_identity c2_identity::identity=c2_identity();

// generate a sampling grid at points separated by dx=5, which is intentionally
// incommensurate with pi and 2*pi so grid errors are somewhat randomized
std::vector<double> &c2_sin::trig_grid(double xmin, double xmax)
{
    std::vector<double> *result=new std::vector<double>;
    
    for(; xmin < xmax; xmin+=5.0) result->push_back(xmin);
    result->push_back(xmax);
    preen_sampling_grid(result);
    return *result;
}

static double identity(double x) { return x; } // a useful function
static double f_one(double x) { return 1.0; } // the first derivative of identity
static double f_zero(double x) { return 0.0; } // the second derivative of identity

//  The constructor
void interpolating_function::init(const std::vector<double> &x, const std::vector<double> &f, 
                                 bool lowerSlopeNatural, double lowerSlope, 
                                 bool upperSlopeNatural, double upperSlope,
                                 double (*inputXConversion)(double), 
                                 double (*inputXConversionPrime)(double), 
                                 double (*inputXConversionDPrime)(double), 
                                 double (*inputYConversion)(double), 
                                 double (*inputYConversionPrime)(double), 
                                 double (*inputYConversionDPrime)(double), 
                                 double (*outputYConversion)(double)
                                 )  
{
    X= x;
    F= f;
    
    // Xraw is useful in some of the arithmetic operations between interpolating functions
    Xraw=x;
    set_sampling_grid_pointer(Xraw); // our intial grid of x values is certainly a good guess for 'interesting' points
    
    set_domain(Xraw[0],Xraw[Xraw.size()-1]);
    
    fXin=inputXConversion;
    fXinPrime=inputXConversionPrime;
    fXinDPrime=inputXConversionDPrime;
    fYin=inputYConversion;
    fYinPrime=inputYConversionPrime;
    fYinDPrime=inputYConversionDPrime;
    fYout=outputYConversion;
    
    if(x.size() != f.size()) {
        std::cerr << "Error: interpolating_function constructor inputs are of different size.\n";
        throw c2_exception("interpolating_function::init() -- x & y inputs are of different size");
    }
    
    size_t np=X.size(); // they are the same now, so lets take a short cut
    
    if(np < 4) {
        std::cerr << "Error: interpolating_function constructor input vectors have < than 4 elements.\n";
        throw c2_exception("interpolating_function::init() -- input < 4 elements ");
    }
    
    if(fXin) { // check if X scale is nonlinear, and if so, do transform
        if(!lowerSlopeNatural) lowerSlope /= fXinPrime(X[0]);
        if(!upperSlopeNatural) upperSlope /= fXinPrime(X[np-1]);
        for(size_t i=0; i<np; i++) X[i]=fXin(X[i]);
    } else {
        fXin=identity;
        fXinPrime=f_one;
        fXinDPrime=f_zero;
    }
    
    if(inputYConversion) {  // check if Y scale is nonlinear, and if so, do transform
        if(!lowerSlopeNatural) lowerSlope *= fYinPrime(F[0]);
        if(!upperSlopeNatural) upperSlope *= fYinPrime(F[np-1]);
        for(size_t i=0; i<np; i++) F[i]=inputYConversion(F[i]);
    } else {
        fYin=identity;
        fYinPrime=f_one;
        fYinDPrime=f_zero;
        fYout=identity;
    }
          
    if( (xInverted=(X[0] > X[1])) != 0) { // reverse the vectors if x values are decreasing (after transform!)
        std::reverse(X.begin(), X.end());
        std::reverse(F.begin(), F.end());
    }
    
    for(size_t i = 1; i < np; ++i) {
        if(x[i-1] < x[i])
            continue;
        else {
            std::cerr << "Error: Interpolating function x values are not monotonic.\n";
            throw c2_exception("interpolating_function::init() non-monotonic x input");
        }
    }
    // construct spline tables here.  
    // this code is a re-translation of the pythonlabtools spline algorithm from pythonlabtools.sourceforge.net
    
    std::vector<double> u(np),  dy(np-1), dx(np-1), dxi(np-1), dx2i(np-2), siga(np-2), dydx(np-1);
    
    std::transform(X.begin()+1, X.end(), X.begin(), dx.begin(), std::minus<double>() ); // dx=X[1:] - X [:-1]
    for(size_t i=0; i<dxi.size(); i++) dxi[i]=1.0/dx[i]; // dxi = 1/dx
    for(size_t i=0; i<dx2i.size(); i++) dx2i[i]=1.0/(X[i+2]-X[i]); 
    
    std::transform(F.begin()+1, F.end(), F.begin(), dy.begin(), std::minus<double>() ); // dy = F[i+1]-F[i]
    std::transform(dx2i.begin(), dx2i.end(), dx.begin(), siga.begin(), std::multiplies<double>()); // siga = dx[:-1]*dx2i
    std::transform(dxi.begin(), dxi.end(), dy.begin(), dydx.begin(), std::multiplies<double>()); // dydx=dy/dx
    
    // for(int i=0; i<np; i++) printf("%4d %10.4f %10.4f %10.4f %10.4f %10.4f %10.4f %10.4f %10.4f \n", i, X[i], F[i], dx[i], dxi[i], dx2i[i], dy[i], siga[i], dydx[i]);
    
    // u[i]=(y[i+1]-y[i])/float(x[i+1]-x[i]) - (y[i]-y[i-1])/float(x[i]-x[i-1])
    std::transform(dydx.begin()+1, dydx.end(), dydx.begin(), u.begin()+1, std::minus<double>() ); // incomplete rendering of u = dydx[1:]-dydx[:-1]
    
    y2.resize(np,0.0);  
    
    if(lowerSlopeNatural) {
        y2[0]=u[0]=0.0;
    } else {
        y2[0]= -0.5;
        u[0]=(3.0*dxi[0])*(dy[0]*dxi[0] -lowerSlope);
    }
    
    for(size_t i=1; i < np -1; i++) { // the inner loop
        double sig=siga[i-1];
        double p=sig*y2[i-1]+2.0;
        y2[i]=(sig-1.0)/p;
        u[i]=(6.0*u[i]*dx2i[i-1] - sig*u[i-1])/p;
    }
    
    double qn, un;
    
    if(upperSlopeNatural) {
        qn=un=0.0;
    } else {
        qn= 0.5;
        un=(3.0*dxi[dxi.size()-1])*(upperSlope- dy[dy.size()-1]*dxi[dxi.size()-1] );
    }
    
    y2[np-1]=(un-qn*u[np-2])/(qn*y2[np-2]+1.0);
    for (size_t k=np-1; k != 0; k--) y2[k-1]=y2[k-1]*y2[k]+u[k-1];
    
    lastKLow=-1; // flag  new X search required for next evaluation
}

// This function is the reason for this class to exist
// it computes the interpolated function, and (if requested) its proper first and second derivatives including all coordinate transforms
double interpolating_function::splint(double x, double *yprime, double *yprimeprime) const 
{
    if(x < xmin() || x > xmax()) {
        char buf[256];
        snprintf(buf, sizeof(buf)-1, "Interpolating function argument %g out of range %g -- %g", x, xmin(), xmax());
        std::cerr << buf << std::endl;
        throw c2_exception(buf);
    }
    
    double xraw=x;
    
    if(fXin != identity) x=fXin(x); // save time by explicitly testing for identity function here
    
    int klo=0, khi=X.size()-1;
    
    if(lastKLow >=0 && (X[lastKLow] <= x) && (X[lastKLow+1] >= x) ) { // already bracketed
        klo=lastKLow;
    } else if(lastKLow >=0 && (X[lastKLow+1] <= x) && (X[lastKLow+2] > x)) { // in next bracket to the right
        klo=lastKLow+1;        
    } else if(lastKLow >=0 && (X[lastKLow-1] <= x) && (X[lastKLow] > x)) { // in next bracket to the left
        klo=lastKLow-1;        
    } else { // not bracketed, not close, start over
             // search for new KLow
        while(khi-klo > 1) {
            int km=(khi+klo)/2;
            if(X[km] > x) khi=km;
            else klo=km;
        }
    }
    khi=klo+1;
    (const_cast<interpolating_function *>(this))->lastKLow=klo; // cast away our constant nature to change lastKLow, which is a 'safe' change
    
    double h=X[khi]-X[klo];
    
    double a=(X[khi]-x)/h; 
    double b=1.0-a;
    double ylo=F[klo], yhi=F[khi], y2lo=y2[klo], y2hi=y2[khi];
    double y=a*ylo+b*yhi+((a*a*a-a)*y2lo+(b*b*b-b)*y2hi)*(h*h)/6.0;
    
    if(fYin != identity) y=fYout(y); // save time by explicitly testing for identity function here
    
    if(yprime || yprimeprime) {
        double fpi=1.0/fYinPrime(y);
        double gp=fXinPrime(xraw);
        double yp0=(yhi-ylo)/h+((3*b*b-1)*y2hi-(3*a*a-1)*y2lo)*h/6.0; // the derivative in interpolating table coordinates
        
        // from Mathematica Dt[InverseFunction[f][g[y[x]]], x]
        if(yprime) *yprime=gp*yp0*fpi; // the real derivative of the inverse transformed output 
        if(yprimeprime) {
            double ypp0=b*y2hi+a*y2lo;
            double fpp=fYinDPrime(y);
            double gpp=fXinDPrime(xraw);
            // also from Mathematica Dt[InverseFunction[f][g[y[x]]], {x,2}]
            *yprimeprime=(gp*gp*ypp0 + yp0*gpp - gp*gp*yp0*yp0*fpp*fpi*fpi)*fpi; 
        }
    }
    
    return y;
}

void interpolating_function::set_lower_extrapolation(double bound) {
    int kl = xInverted? X.size()-2 : 0 ;
    int kh=kl+1;
    double xx=fXin(bound);
    double h0=X[kh]-X[kl];
    double h1=xx-X[kl];
    double yextrap=F[kl]+((F[kh]-F[kl])/h0 - h0*(y2[kl]+2.0*y2[kh])/6.0)*h1+y2[kl]*h1*h1/2.0;
    
    X.insert(xInverted? X.end() : X.begin(), xx);
    F.insert(xInverted? F.end() : F.begin(), yextrap);
    y2.insert(xInverted? y2.end() : y2.begin(), *(xInverted? y2.end()-1 : y2.begin())); // duplicate first or last element
    Xraw.insert(Xraw.begin(), bound);
    xMin=bound;
    //printf("%10.4f %10.4f %10.4f %10.4f %10.4f\n", bound, xx, h0, h1, yextrap);
    //for(int i=0; i<X.size(); i++) printf("%4d %10.4f %10.4f %10.4f %10.4f \n", i, Xraw[i], X[i], F[i], y2[i]);    
}

void interpolating_function::set_upper_extrapolation(double bound) {
    int kl = (!xInverted)? X.size()-2 : 0 ;
    int kh=kl+1;
    double xx=fXin(bound);
    double h0=X[kh]-X[kl];
    double h1=xx-X[kl];
    double yextrap=F[kl]+((F[kh]-F[kl])/h0 - h0*(y2[kl]+2.0*y2[kh])/6.0)*h1+y2[kl]*h1*h1/2.0;
    
    X.insert((!xInverted)? X.end() : X.begin(), xx);
    F.insert((!xInverted)? F.end() : F.begin(), yextrap);
    y2.insert((!xInverted)? y2.end() : y2.begin(), *((!xInverted)? y2.end()-1 : y2.begin())); // duplicate first or last element
    Xraw.insert(Xraw.end(), bound);
    xMax=bound;
    //printf("%10.4f %10.4f %10.4f %10.4f %10.4f\n", bound, xx, h0, h1, yextrap);
    //for(int i=0; i<X.size(); i++) printf("%4d %10.4f %10.4f %10.4f %10.4f \n", i, Xraw[i], X[i], F[i], y2[i]);
}

// move derivatives into our internal coordinates (use splint to go the other way!)
void interpolating_function::localize_derivatives(double xraw, double y, double yp, double ypp, double *y0, double *yprime, double *yprime2) const {
    double fp=fYinPrime(y);
    double gp=fXinPrime(xraw);
    double fpp=fYinDPrime(y);
    double gpp=fXinDPrime(xraw);
    
    if(y0) *y0=fYin(y);
    if(yprime) *yprime=yp*fp/gp; // Mathematica Dt[f[y[InverseFunction[g][x]]], x]
    if(yprime2) *yprime2=( yp*yp*fpp - fp*yp*gpp/gp + fp*ypp )/(gp*gp) ; // Mathematica Dt[f[y[InverseFunction[g][x]]], {x,2}]
}

// return a new interpolating_function which is the unary function of an existing interpolating_function
// can also be used to generate a resampling of another c2_function on a different grid
// by creating a=interpolating_function(x,x)
// and doing b=a.UnaryOperator(c) where c is a c2_function (probably another interpolating_function)

interpolating_function & interpolating_function::unary_operator( const c2_function &source) const 
{
    std::vector<double>yv(X.size());
    double yp0=0, yp=0, ypp=0;
    
    int xidx=xInverted?X.size()-1: 0, xstep=xInverted?-1:1;
        
    for(size_t i=0; i<X.size(); i++, xidx += xstep) { 
        yv[i]=source.compose( (*this), Xraw[xidx], &yp, &ypp);
        if(i==0) yp0=yp;
    }
    return  *new interpolating_function(Xraw, yv, false, yp0, false, yp,
                                       fXin, fXinPrime, fXinDPrime,
                                       fYin, fYinPrime, fYinDPrime, fYout);
}

interpolating_function & interpolating_function::y_to_x() const
{
    
    std::vector<double>yv(X.size());
    
    for(unsigned int i=0; i<X.size(); i++) yv[i]=fYout(F[i]);
    if(yv[1]<yv[0]) std::reverse(yv.begin(), yv.end());
    
    return  *new interpolating_function(yv, yv, false, 1.0, false, 1.0,
                                       fXin, fXinPrime, fXinDPrime,
                                       fYin, fYinPrime, fYinDPrime, fYout);
}

interpolating_function & interpolating_function::binary_operator(const c2_function &rhs,
                                                            double (&combiner)(const c2_function &, const c2_function &, 
                                                                               double x, double *yp, double *ypp)) const
{    
    c2_binary_function bf((*this), rhs, combiner);
    
    std::vector<double> yv(X.size());
    double yp0=0, yp=0, ypp=0;
    
    int xidx=xInverted?X.size()-1: 0, xstep=xInverted?-1:1;
        
    for(unsigned int i=0; i<X.size(); i++, xidx += xstep) { 
        yv[i]=bf.value_with_derivatives(Xraw[xidx], &yp, &ypp);
        if(i==0) yp0=yp;
    }
    return  *new interpolating_function(Xraw, yv, false, yp0, false, yp,
                                       fXin, fXinPrime, fXinDPrime,
                                       fYin, fYinPrime, fYinDPrime, fYout);    
}

static double logprime(double x) { return 1.0/x; } // the derivative of log(x)
static double logprime2(double x) { return -1.0/(x*x); } // the second derivative of log(x)

log_lin_interpolating_function::log_lin_interpolating_function(const std::vector<double> x, const std::vector<double> f, 
                                                         bool lowerSlopeNatural, double lowerSlope, 
                                                         bool upperSlopeNatural, double upperSlope) {
    init(x, f, lowerSlopeNatural, lowerSlope, upperSlopeNatural, upperSlope,
         std::log, logprime, logprime2, 0, 0, 0, 0);
}

lin_log_interpolating_function::lin_log_interpolating_function(const std::vector<double> x, const std::vector<double> f, 
                                                         bool lowerSlopeNatural, double lowerSlope, 
                                                         bool upperSlopeNatural, double upperSlope) {
    init(x, f, lowerSlopeNatural, lowerSlope, upperSlopeNatural, upperSlope,
         0, 0, 0, std::log, logprime, logprime2, std::exp );
}

log_log_interpolating_function::log_log_interpolating_function(const std::vector<double> x, const std::vector<double> f, 
                                                         bool lowerSlopeNatural, double lowerSlope, 
                                                         bool upperSlopeNatural, double upperSlope) {
    init(x, f, lowerSlopeNatural, lowerSlope, upperSlopeNatural, upperSlope,
         std::log, logprime, logprime2, std::log, logprime, logprime2, std::exp );
}


//AccumulatedHistogram starts with binned data, generates the integral, and generates a piecewise linear interpolating_function
//If drop_zeros is true, it merges empty bins together before integration
//Note that the resulting interpolating_function is guaranteed to be increasing (if drop_zeros is false)
//    or stricly increasing (if drop_zeros is true)
//If inverse_function is true, it drop zeros, integrates, and returns the inverse function which is useful
//    for random number generation based on the input distribution.
//If normalize is true, the big end of the integral is scaled to 1. 
//If the data are passed in reverse order (large X first), the integral is carried out from the big end,
//    and then the data are reversed to the result in in increasing X order.  
accumulated_histogram::accumulated_histogram(const std::vector<double>binedges, const std::vector<double> binheights,
                                           bool normalize, bool inverse_function, bool drop_zeros) 
{
    
    int np=binheights.size();
    
    std::vector<double> be, bh;
    if(drop_zeros || inverse_function) { //inverse functions cannot have any zero bins or they have vertical sections
        if(binheights[0] || !inverse_function) { // conserve lower x bound if not an inverse function
            be.push_back(binedges[0]);
            bh.push_back(binheights[0]);
        }
        for(int i=1; i<np-1; i++) {
            if(binheights[i]) {
                be.push_back(binedges[i]);
                bh.push_back(binheights[i]);
            }
        }
        if(binheights[np-1] || !inverse_function) {
            bh.push_back(binheights[np-1]);            
            be.push_back(binedges[np-1]);
            be.push_back(binedges[np]); // push both sides of the last bin if needed
        }
        np=bh.size(); // set np to compressed size of bin array
    } else {
        be=binedges;
        bh=binheights;
    }
    std::vector<double> cum(np+1, 0.0);
    for(int i=1; i<=np; i++) cum[i]=bh[i]*(be[i]-be[i-1])+cum[i-1]; // accumulate bins, leaving bin 0 as 0
    if(be[1] < be[0]) { // if bins passed in backwards, reverse them
        std::reverse(be.begin(), be.end());
        std::reverse(cum.begin(), cum.end());
        for(unsigned int i=0; i<cum.size(); i++) cum[i]*=-1; // flip sign on reversed data
    }
    if(normalize) {
        double m=1.0/std::max(cum[0], cum[np]);
        for(int i=0; i<=np; i++) cum[i]*=m;
    }
    if(inverse_function) interpolating_function(cum, be); // use cum as x axis in inverse function
    else interpolating_function(be, cum); // else use lower bin edge as x axis
    std::fill(y2.begin(), y2.end(), 0.0); // clear second derivatives, to we are piecewise linear
}

c2_inverse_function::c2_inverse_function(const c2_function &fn) :
    c2_scaled_function(fn,0.0), hint_func(0)
{
    double y1=fn(fn.xmin()), y2=fn(fn.xmax());
    if(y1<y2) set_domain(y1,y2);
    else set_domain(y2,y1); // pick off domain assuming host func is monotonic
    start_hint=(fn.xmin()+fn.xmax())*0.5; // start looking in the middle, by default
}

c2_inverse_function::c2_inverse_function(const c2_function &fn, const c2_function &approximate_inverse_fn) :
c2_scaled_function(fn, 0.0), hint_func(&approximate_inverse_fn)
{
    double y1=fn(fn.xmin()), y2=fn(fn.xmax());
    if(y1<y2) set_domain(y1,y2);
    else set_domain(y2,y1); // pick off domain assuming host func is monotonic
}

void c2_inverse_function::create_hinting_function()
{
    std::vector<double> &grid=Left.get_sampling_grid(Left.xmin(), Left.xmax());
    create_hinting_function(grid);
    delete &grid;
}

void c2_inverse_function::create_hinting_function(std::vector<double> &xgrid)
{
    std::vector<double> *grid;
    bool cleanup;
    if(xgrid.size() <5) {
        grid=&Left.refine_sampling_grid(xgrid, 3); // 3* more points is more than 5!
        cleanup=true;
    } else {
        grid=&xgrid;
        cleanup=false;
    }
    std::vector<double> ygrid(grid->size());
    double yp0, ypp0, yp1, ypp1;
    ygrid.front()=Left(grid->front(), &yp0, &ypp0); // need derivs at both ends
    ygrid.back()=Left(grid->back(), &yp1, &ypp1);
    for(size_t i=1; i<grid->size()-1; i++) ygrid[i]=Left((*grid)[i]); // don't need derivs in middle
    hint_func=new interpolating_function(ygrid, *grid, false, 1.0/yp0, false, 1.0/yp1);
    owns_hint=true;
    if(cleanup) delete grid;
}

double c2_inverse_function::value_with_derivatives(double x, double *yprime, double *yprime2) const
{
    double start;
    if(hint_func) start=(*hint_func)(x); // if we ave a hinting function, use it to get the starting estimate
    else start=start_hint; // otherwise, use the stored hint for where to start
    
    double y=Left.find_root(Left.xmin(), Left.xmax(), start, x);
    double y0, yp, ypp;
    y0=Left.value_with_derivatives(y, &yp, &ypp);
    if(yprime) *yprime=1.0/yp;
    if(yprime2) *yprime2=-ypp/(yp*yp*yp);
    (const_cast<c2_inverse_function *>(this))->start_hint=y; // harmless change, effectively constant
    return y;
}

#if 0 // test to make sure templates can be instantiated
static interpolating_function &testit(void) {
    std::vector<double> xvals(10);
    return inverse_integrated_density<lin_log_interpolating_function>(xvals, c2_sin::sin);
}

static interpolating_function &testit2(void) {
    std::vector<double> xvals(10), yvals(10);
    return inverse_integrated_density<log_log_interpolating_function, lin_log_interpolating_function>(xvals, yvals);
}
#endif
