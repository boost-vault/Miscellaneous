/**  \file 
* \brief headers for a set of classes for working with smooth functions
*
*  c2_functions.h
*
*  Created by Marcus H. Mendenhall and R. A. Weller on 7/9/05.
*  Copyright 2005 Vanderbilt University. All rights reserved.
*  to be published under the Boost License
*
*/

/** \mainpage
Created by Marcus H. Mendenhall and R. A. Weller on 7/9/05.

Copyright &copy; 2005 Vanderbilt University. All rights reserved.

Published and licensed under the Boost License

\section intro_sec Introduction to C2Functions
This work presents an approach to numerical computation based on implicit 
assumptions of smoothness of the underlying functions. Many common computational 
techniques are based on knowledge of only the value of a function, and are 
therefore robust but inefficient. In contrast, we discuss methods in which 
functions and their first two derivatives are carried through, allowing 
O(h<sup>10</sup>) integration and O(h<sup>3</sup>) root-finding algorithms to be very easily 
implemented. The increase in efficiency in many procedures more than pays 
for the extra effort of carrying the value and two derivatives for a function 
at each point, especially since many functions have a fairly low incremental cost to
evaluate the derivatives along with the function value. Such methods are applicable to analytic 
functions, to smoothly (cubic spline) interpolated tabular data, and to analytic 
functions of tabular data. The last case is particularly interesting, since it 
permits efficient representation of 'stiff' functions with very different length scales.

\section overview_sec Overview
Overview: (n) a broad summary

The first class in the package to look at is its namesake, c2_function.  This provides the core of fuctionality
which defines all the other members of the package.  

The next most interesting class for most users is interpolating_function and its children.  This
is the original reason the package was created, and many of the features of the class are most useful
in combination with various interpolating_function objects.  

Another feature of primary interest in inverse_function, which provides a c2_function which is the 
exact functional inverse of another c2_function, including carrying through first and second derivatives.
Although it uses root finding through c2_function::find_root to locate the solution point, it does this
efficientloy by providing a number of mechanisms for hinting the root finder to a faster start. 

\section use_case Typical Use Cases

\subsection rootfinder_subsec Root Finding
This package was originally developed to provide support for the rapid solution of classical screened
Coulomb scattering problems, where one needs an accurate computation of the scattering angle for 
a projectile through a potenial \f$\mathrm{U}(r)=k \phi(r)/r \f$ where \f$ \phi(r) \f$ is known as
the screening function, and is an empirically derived quantity dependent upon the atomic models chosen.
We store it in an interpolating_function after computing it oce on a grid at the start of a program run.

To solve the problem, we first need to solve for the classical turning radius (apsis) \a x<sub>0</sub> 
in terms of the impact parameter \a beta. This requires solving 
\f[ f(z)=\left(1-\frac{\phi(z)}{z\,\varepsilon}-\frac{\beta^{2}}{z^{2}}\right)^{-1/2} = 0 \f]
to find \a x<sub>0</sub>

The code for this looks like <tt> <pre>

    c2_function &phiData=*(screen->EMphiData); // this is usually an interpolating_function
    %// instantiate all the needed functions statically, so no allocation is done at run time
    %// we will be solving x^2 - x phi(x*au)/eps - beta^2 == 0.0
    %// or, for easier scaling, x'^2 - x' au phi(x')/eps - beta^2 au^2
    static c2_variable_function phifunc;
    static c2_quadratic xsq(0., 0., 0., 1.); //  x^2
    static c2_linear xovereps(0., 0.); // will fill this in with the right slope at run time
    static c2_function &xphi=xovereps*phifunc;
    static c2_function &diff=xsq-xphi;

    xovereps.reset(0.0, au/eps); // slope of x*au/eps term
    phifunc.set_function(phiData); // install interpolating table

    xx0=diff.find_root(phifunc.xmin(), std::min(10*xx0*au,phifunc.xmax()), xx0*au, beta*beta*au*au)/au; 
    phifunc.unset_function(); // throws an exception if used without setting again

    %// compute phi' as needed for lambda
    double phip, phip2;
    phiData.value_with_derivatives(xx0*au, &phip, &phip2);	// only need derivative, not return value
    %// phiprime is scaled by one factor of au because phi is evaluated at (xx0*au),
    double phiprime=phip*au;

</pre> </tt>

Note in particular that all the functions are statically allocated in this case, and 
all that happens at run time is some constants are adjusted and the appropriate screening
function is dropped in.  This produces code that is extremely fast, and yet takes
full advantage of the derivative information available.

\subsection integrator_subsec Random  Number Generation
A common problem which arises in much computational physics is the generation of random numbers 
according to an arbitrary distribution f(x) between \a x<sub>0</sub> and \a x<sub>1</sub>
from a uniform random variate u on (0,1).  The solution to such
a problem is well known:  if 
\f[ g(x) = \frac{\int_{x_0}^{x} f(x') dx'}{\int_{x_0}^{x_1} f(x') dx'} \f] 
then g<sup>-1</sup>(u) will be the appropriate random variate, where the inversion is
functional inversion, not the reciprocal.

The package provides a very simple template to construct such functions.  They are templatized since
it is often the case that one is generating randoms over a huge range, and optimum performace 
may be provided by, for example, lin_log_interpolating_function, and since
c++ has no concept of virtual constructors, this must be accomplished with a template.  

To generate the function, start with an interpolating_function (or any other c2_function!) which represents
the distrubtion to be produced.  It MUST be STRICTLY POSITIVE or the world will end.  Also, 
provide a sampling grid for the function which is fine enough to cover all the salient features.  If you
are generating randoms which include very sharp peaks (gamma ray spectra, for example), make sure the grid puts a few
points on each peak.

Then, just do <br>
<tt> c2_function &myrand= ::inverse_integrated_density < lin_lin_interpolating_function > (sampling_grid, spectrum) </tt> <br>
and myrand(u) where \a u is a random unit variate will produce random numbers with exactly the original distribution.

Looking in the template classes shows how the integrator is actually used here.

Note that these templates use an approximate inverse function generated by a splining of a function with 
the coordinates reversed.  It would be very easy to use c2_inverse_function to provide exact inversion, but since
random generation usually needs to be very fast, I have implemented it this way.  The more sophisticated 
approach requires about one more line of code, but is left as an exercise for the reader, at least for now.


*/


#ifndef BOOST_C2_FUNCTIONS_H_
#define BOOST_C2_FUNCTIONS_H_

#if (defined _MSC_VER) && (_MSC_VER >= 1200)
#  pragma once
#endif

#include <cmath>
#include <vector>
#include <string>
#include <exception>

class c2_exception : public std::exception {
public:
    c2_exception(const char msgcode[]) : info(msgcode) { }
    virtual ~c2_exception() throw();
    /** Returns a C-style character string describing the general cause
    *  of the current error.  */
    virtual const char* what() const throw() { return info.c_str(); }
private:
    std::string info;
};

// WARNING:  the composite flavors of c2_functions (c2_sum..., c2_Composed...) make no effort to manage deletion of their component functions.
// These are just container classes, and the user (along with normal automatic variable semantics) is responsible for the lifetime of components.
// Inappropriate attention to this can cause massive memory leaks.  However, in most cases these do exactly what is intended.
// The classes will be left this way since the only other option is to use copy constructors on everything, which would make this all very slow.

/// \class c2_function 
/// A c2_function is a smooth, twice differentiable function which is the center of this whole construct.
/// These functions support a number of important concepts.  They have a specified domain, are differentiable twice,
/// at least at almost all points.  They can carry with them a grid of 'interesting' points to hint algorithms
/// such as adaptive integrators and, potentially, plotters.  
///
/// c2_functions also carry with them a functional algebra for creating functions of functions,
/// with the package handling all the hard work of keeping exact first and second derivatives 
/// of the combination.
///
/// One of the most important members of this class is interpolating_function.

//! c2_function is the point of this whole package... read this first!
class c2_function {

public:
    //! get the versioning information for the header file
    static const std::string cvs_header_vers() { return 
        "$Id: c2_function.h,v 1.19 2006/03/25 19:34:56 marcus Exp $";
    }
    
    //! get the versioning information for the main file
    static const std::string cvs_file_vers() { return cvs_vers; }
    
private:
    static const char cvs_vers[];
    
    // a class of functions which will tell you the value, first & second derivative
public:
    
    virtual ~c2_function() { if(sampling_grid && !no_delete_grid) delete sampling_grid; }
    
    //! get the value and derivatives.  There is no guaranteed checking for null pointers, so this should always be called with valid pointers
    virtual double value_with_derivatives(double x, double *yprime, double *yprime2) const =0 ; // { return 0; };
    
    //! get the value of the function, without derivatives.  f(x) is just what you expect
    double operator () (double x) const { double yp, ypp; return value_with_derivatives(x, &yp, &ypp); } 
    
    //! get the value of the function with derivatives.  This is equivalent to value_with_derivatives()
    double operator () (double x, double *yp, double *ypp) const { return value_with_derivatives(x, yp, ypp); } 
    
    /// find_root solves by iterated inverse quadratic extrapolation for a solution to f(x)=y.  It
    /// includes checks against bad convergence, so it should never be able to fail.  Unlike typical
    /// secant method or fancier Brent's method finders, this does not depend in any strong wasy on the
    /// brackets, unless the finder has to resort to successive approximations to close in on a root.
    /// Often, it is possible to make the brackets equal to the domain of the function, if there is
    /// any clue as to where the root lies, as given by the parameter \a start.  
    /// \param lower_bracket the lower bound which is ever permitted in the search.
    /// \param upper_bracket the upper bound. Note that the function have opposite signs at these two points
    /// \param start an initial guess for where to start the search
    /// \param value the target value of the function
    /// \param error if non-null, an error value is returned in the variable, otherwise an exception is thrown.
    /// \param evaluations if non-null, adds the total number of function evaluations to the integer
    
    //! solve f(x)==value very efficiently, with explicit knowledge of derivatives of the function
    double find_root(double lower_bracket, double upper_bracket, double start, double value, 
                     int *error=0, int *evaluations=0) const; // solve f(x)=value

    /// For points in \a xgrid, compute {\f$ \int_{x_i}^{x_{i+1}} f(x) dx \f$} and return in vector \a partials, along with sum.
    /// Note that the length of \a partials is one less than the length of \a xgrid. 
    /// partial_integrals() uses a method with an error O(dx**10) with full  information from the derivatives
    ///
    /// the integration is adaptive, starting from the grid provided, and returning data in the intervals
    /// between the grid points. 
    /// \param xgrid grid defining the subdomains over which the integral is computed, and hints for the adaptive algorithm
    /// \param partials vector in which results from subdomains are returned, if not null.  It will automatically be set to the right size (1 less than the number of points in \a xgrid)
    /// \param abs_tol total absolute error allowed on each explicit subdomain
    /// \param rel_tol total relative error allowed on each explicit subdomain
    /// \param derivs how much continuity?  derivs=2 => full method, 1 => less smooth function, 0 => Simpson's rule
    /// \param adapt allow adaptive behavior if true, otherwise just use subdomains provided
    /// \param extrapolate carry out simple Richardson-Romberg extrapolation if true
    /// \param evaluations if non-null, returns count of evaluations of the function
    
    //! compute the numerical integral of the function on the subdomains provided
    double partial_integrals(
                             std::vector<double> &xgrid, std::vector<double> *partials = 0,
                             double abs_tol=1e-12, double rel_tol=1e-12, 
                             int derivs=2, bool adapt=true, bool extrapolate=true, int *evaluations=0) const;
    
    /// this is a fully-automated integrator which uses the information provided my the get_sampling_grid() function
    /// to figure out what to do and returns the integral of the function over the domain requested
    /// with error tolerances as specified.  It is just a front-end to partial_integrals()
    /// 
    /// Sample of use:  
    //! return the integral of a function from xmin to xmax using sampling information from get_sampling_grid()
    double integral(
                    //! start of domain for integration
                    double xmin, 
                    //! end of domain for integration
                    double xmax, 
                    //! partials will be filled on the same grid as returned by get_sampling_grid(xmin, xmax) if non-null
                    std::vector<double> *partials = 0,
                    //! everything else as in partial_integrals()
                    double abs_tol=1e-12, double rel_tol=1e-12, int derivs=2, bool adapt=true, 
                    bool extrapolate=true, int *evaluations=0) const;

    //! get the left-hand extent of the domain of this function
    inline double xmin() const { return xMin; }
    //! get the right-hand extent of the domain of this function
    inline double xmax() const { return xMax; }
    //! set the domain of this function
    void set_domain(double xmin, double xmax) { xMin=xmin; xMax=xmax; }
    
    //! y=f.compose(g, x, &yp, &ypp) returns f(g(x)) and its derivatives.  
    inline double compose(const c2_function &inner_function, double x, double *yp, double *ypp) const {
        double yp0, ypp0, yp1, ypp1;
        double y0=inner_function.value_with_derivatives(x, &yp0, &ypp0);
        double y1=value_with_derivatives(y0, &yp1, &ypp1);
        *yp=yp1*yp0;
        *ypp=ypp0*yp1+yp0*yp0*ypp1;
        return y1;
    }    
        
    /// establish a grid of points which describes a reasonable initial set of points to look at the function
    /// this should generally be set at a scale which is quite coarse, and sufficient for initializing
    /// adaptive integration or possibly root bracketing. For sampling a function to build a new interpolating
    /// function, one may want to refine this for accuracy.  However, interpolating_functions themselves
    /// return their original X grid by default, so refining the grid in this case might be a bad idea.
    
    //! establish a grid of 'interesting' points on the function
    virtual void set_sampling_grid(const std::vector<double> &grid) { 
        if(!sampling_grid || no_delete_grid) sampling_grid=new std::vector<double>;
        (*sampling_grid)=grid; no_delete_grid=0;  }
    
    /// return a reasonable set of points to sample the function between xmin and xmax
    /// if a sampling grid is defined, work from there, otherwise return vector of (xmin, xmax)
    
    //! return the grid of 'interesting' points along this function
    virtual std::vector<double> &get_sampling_grid(double xmin, double xmax) const ;
    
    //! clean up endpoints on a grid of points, removing points too close together at the ends
    static void preen_sampling_grid(std::vector<double> *result);        
    //! refine a grid by splitting each interval into more intervals. The returned grid is a new std::vector<double>
    static std::vector<double> & refine_sampling_grid(const std::vector<double> &grid, size_t refinement);        
    
    //! return a new c2_function from this one which is normalized  on the interval 
    c2_function &normalized_function(double xmin, double xmax, double norm=1.0);
    //! return a new c2_function from this one which is square-normalized on the interval 
    c2_function &square_normalized_function(double xmin, double xmax, double norm=1.0);
    //! return a new c2_function from this one which is square-normalized on the interval with a weight function
    c2_function &square_normalized_function(double xmin, double xmax, const c2_function &weight, double norm=1.0);
    
protected:
    c2_function(const c2_function  &src) : xMin(src.xMin), xMax(src.xMax), sampling_grid(0),
        no_delete_grid(0) {} // copy constructor only copies domain, and is only for internal use
    c2_function() : 
            xMin(-std::numeric_limits<double>::max()), 
            xMax(std::numeric_limits<double>::max()),
            sampling_grid(0), no_delete_grid(0)
        {} // prevent accidental naked construction (impossible any since this has pure virtual methods)
    
    // this should only be called very early on, by a constructor, before anyone else
    // sets a sampling grid, or it will leak memory
    virtual void set_sampling_grid_pointer(std::vector<double> &grid) { 
        sampling_grid=&grid; no_delete_grid=1; }
    
    double xMin, xMax;
    
    double integrate_step(struct recur &) const;
    
    std::vector<double> *sampling_grid;
    bool no_delete_grid;
    
};

/// \class c2_variable_function 
///  a container into which any other c2_function can be dropped, to allow expressions
/// with replacable components.  It is useful for plugging different interpolating_functions into a c2_function expression.
/// it saves a lot of effort in other places with casting away const declarations.

//! A c2_function which is dynamically 'pluggable' with another c2_function.  
class c2_variable_function : public c2_function {
public:
    c2_variable_function() : c2_function(), func(0)  {} //!< create the empty function
    c2_variable_function(c2_function &f) : c2_function(f), func(&f)  {} //!< create the function already plugged in with \a f.
    void set_function(c2_function &f) { func=&f; set_domain(f.xmin(), f.xmax()); } //!< assign a new function
    virtual double value_with_derivatives(double x, double *yprime, double *yprime2) const {
        if(!func) throw c2_exception("c2_variable_function called uninitialized");
        return func->value_with_derivatives(x, yprime, yprime2); }
    void unset_function(void) { func=0; } //!< unassign the function, so an exception is thrown if usageis attempted.
    
protected:
    c2_function *func;
    
};

/// \class c2_binary_function
/// The $name class provides support for c2_function objects which are constructed from two ther c2_function
/// objects.  
///
/// It provides a very primitive ownership concept, so that the creator can tag a function
/// as being owned by this function, so that when this function is deleted, the owned function will be deleted, too.
/// This allows a piece of code to create various c2function objects, combine them with binary operators,
/// appropriately mark wich ones have no other possible owners, and return the final function with
/// reasonable faith that eerything will get cleaned up when the final function is deleted.  Note that
/// none of this marking is automatic, to keep this class very lightweight.

//! a general wrapper class for all binary functions
class c2_binary_function : public c2_function {
    // create a binary function using a helper function which computes the derivatives
public:
    virtual double value_with_derivatives(double x, double *yprime, double *yprime2) const { 
        return (*Comb)(Left, Right, x, yprime, yprime2);
    }
    
    //! mark the left-hand function of the pair as being deleted when this is deleted
    void set_left_ownership(void) { leftown=true; }
    //! mark the right-hand function of the pair as being deleted when this is deleted
    void set_right_ownership(void) { rightown=true; }
    //! mark both the left-hand and right-hand function of the pair as being deleted when this is deleted
    void set_ownership(void) { leftown=rightown=true; }
    
    virtual ~c2_binary_function() {
        if(leftown) delete &Left;
        if(rightown) delete &Right;
    }
    
    //! construct a c2_binary_function from two functions and a function which provides the rules for the combination
    c2_binary_function( const c2_function &left,  const c2_function &right,
                      double (&combiner)(const c2_function &, const c2_function &, double x, double *yp, double *ypp)
                      ) : Left(left), Right(right), Comb(&combiner), leftown(false), rightown(false) { 
                          xMin=(left.xmin() > right.xmin()) ? left.xmin() : right.xmin();
                          xMax=(left.xmax() < right.xmax()) ? left.xmax() : right.xmax();
                      } 
    
    //! construct for the case where there is no combiner, such as when value_with_derivatives explicitly manages the combination.
    c2_binary_function( const c2_function &left,  const c2_function &right
                      ) : Left(left), Right(right), Comb(0), leftown(false), rightown(false) { 
                          xMin=(left.xmin() > right.xmin()) ? left.xmin() : right.xmin();
                          xMax=(left.xmax() < right.xmax()) ? left.xmax() : right.xmax();
                      } 
    

protected:
   const  c2_function &Left,  &Right;
    double (*Comb)(const c2_function &, const c2_function &, double x, double *yp, double *ypp);
    bool leftown, rightown;
        
};

//! A super-lightweight binary function in which the result is a scalar multiplying the function.
class c2_scaled_function : public c2_binary_function {
    // create a very lightweight method to return a scalar multiple of another function
    // this is a degenerate c2_binary_function, since it contains only one function and 
    // doesn't use the combine() method
    // this is only a BinaryFunction to inherit ownership code.
public:
    /// Construct the function.
    /// \param outer the function to be scaled
    /// \param scale the vertical scale factor
    
    //! create the function from a c2_function and a scale factor
    c2_scaled_function(const c2_function &outer, double scale) : 
        c2_binary_function(outer, outer), yscale(scale) { }

    //! provide our own 'value...' which bypasses the combiner for quicker operation
    virtual double value_with_derivatives(double x, double *yprime, double *yprime2) const { 
        double y=Left(x, yprime, yprime2); (*yprime)*=yscale; (*yprime2)*=yscale; 
        return y*yscale; }

    void set_scale_factor(double scale) { yscale=scale; } //!< adjust the scale factor to the specified value (non-cumulatively!)
    double get_scale_factor() { return yscale; }  //!< get the scale factor 

    void set_ownership(void) { leftown=true; rightown=false; } //!< special case: there is no righthand function
    
protected:
    double yscale;
};

/// \class c2_cached_function 
/// This is a container into which any other c2_function can be dropped.
/// It allows a function to be pre-evaluated at a point, and used at multiple places in an expression
/// efficiently.
/// The only reason it is a c2_scaled_function is to inherit single-function ownership

//! create a function which remember the last point at which it was evaluated, and returns it quickly if needed.
class c2_cached_function : public c2_scaled_function {
public:
    c2_cached_function(const c2_function &f) : c2_scaled_function(f, 0.0), init(false)  {}
    virtual double value_with_derivatives(double x, double *yprime, double *yprime2) const {
        if(!init || x != x0) {
            y=Left.value_with_derivatives(x, &yp, &ypp);
            x0=x;
            init=true;
        }
        *yprime=yp;
        *yprime2=ypp;
        return y; 
    }
    
protected:
    mutable bool init;
    mutable double x0, y, yp, ypp;
    
};

//! create a composed function outer(inner(...))
class c2_composed_function : public c2_binary_function {
public:
    
    //! construct outer(inner(\a x))
    c2_composed_function(const c2_function &outer, const c2_function &inner) : c2_binary_function(outer, inner) {}

    // special-case value_with_derivatives for composite function for speed
    virtual double value_with_derivatives(double x, double *yp, double *ypp) const { 
        double yp0, ypp0, yp1, ypp1;
        double y0=Right.value_with_derivatives(x, &yp0, &ypp0);
        double y1=Left.value_with_derivatives(y0, &yp1, &ypp1);
        *yp=yp1*yp0;
        *ypp=ypp0*yp1+yp0*yp0*ypp1;
        return y1;
    }

    //! freestanding combiner function to do the same, used by interpolating_function
    static double combine(const c2_function &left, const c2_function &right, 
                          double x, double *yp, double *ypp) {
        double yp0,ypp0, yp1,ypp1;
        double y0=right.value_with_derivatives(x, &yp0, &ypp0);
        double y1=left.value_with_derivatives(y0, &yp1, &ypp1);
        *yp=yp1*yp0;
        *ypp=ypp0*yp1+yp0*yp0*ypp1;
        return y1;
    }
    
};

//! create a c2_function which is the sum of two c2_function objects
class c2_sum : public c2_binary_function {
public:    
    c2_sum(const c2_function &left, const c2_function &right) : c2_binary_function(left, right) {}

    // function to do derivative arithmetic for sums
    virtual double value_with_derivatives(double x, double *yp, double *ypp) const { 
        double y0,yp0,ypp0, y1,yp1,ypp1;
        y0=Left.value_with_derivatives(x, &yp0, &ypp0);
        y1=Right.value_with_derivatives(x, &yp1, &ypp1);
        *yp=yp0+yp1;
        *ypp=ypp0+ypp1;
        return y0+y1;
    }

    // function to do derivative arithmetic for sums
    static double combine(const c2_function &left, const c2_function &right, 
                          double x, double *yp, double *ypp) {
        double y0,yp0,ypp0, y1,yp1,ypp1;
        y0=left.value_with_derivatives(x, &yp0, &ypp0);
        y1=right.value_with_derivatives(x, &yp1, &ypp1);
        *yp=yp0+yp1;
        *ypp=ypp0+ypp1;
        return y0+y1;
    }
};

//! create a c2_function which is the difference of two c2_function objects
class c2_diff : public c2_binary_function {
public:    
    c2_diff(const c2_function &left, const c2_function &right) : c2_binary_function(left, right) {}

    // function to do derivative arithmetic for diffs
    virtual double value_with_derivatives(double x, double *yp, double *ypp) const { 
        double y0,yp0,ypp0, y1,yp1,ypp1;
        y0=Left.value_with_derivatives(x, &yp0, &ypp0);
        y1=Right.value_with_derivatives(x, &yp1, &ypp1);
        *yp=yp0-yp1;
        *ypp=ypp0-ypp1;
        return y0-y1;
    }

    // function to do derivative arithmetic for diffs
    static double combine(const c2_function &left, const c2_function &right, 
                          double x, double *yp, double *ypp) {
        double y0,yp0,ypp0, y1,yp1,ypp1;
        y0=left.value_with_derivatives(x, &yp0, &ypp0);
        y1=right.value_with_derivatives(x, &yp1, &ypp1);
        *yp=yp0-yp1;
        *ypp=ypp0-ypp1;
        return y0-y1;
    }
};

//! create a c2_function which is the product of two c2_function objects
class c2_product : public c2_binary_function {
public:    
    c2_product(const c2_function &left, const c2_function &right) : c2_binary_function(left, right) {}

    virtual double value_with_derivatives(double x, double *yp, double *ypp) const { 
        double y0,yp0,ypp0, y1,yp1,ypp1;
        y0=Left.value_with_derivatives(x, &yp0, &ypp0);
        y1=Right.value_with_derivatives(x, &yp1, &ypp1);
        *yp=y1*yp0+y0*yp1;
        *ypp=ypp0*y1+2.0*yp0*yp1+ypp1*y0;
        return y0*y1;
    }

    static double combine(const c2_function &left, const c2_function &right, 
                                   double x, double *yp, double *ypp) {
        double y0,yp0,ypp0, y1,yp1,ypp1;
        y0=left.value_with_derivatives(x, &yp0, &ypp0);
        y1=right.value_with_derivatives(x, &yp1, &ypp1);
        *yp=y1*yp0+y0*yp1;
        *ypp=ypp0*y1+2.0*yp0*yp1+ypp1*y0;
        return y0*y1;
    }
};

//! create a c2_function which is the ratio of two c2_function objects
class c2_ratio : public c2_binary_function {
public:    
    c2_ratio(const c2_function &left, const c2_function &right) : c2_binary_function(left, right) {}
    
    virtual double value_with_derivatives(double x, double *yp, double *ypp) const { 
        double y0,yp0,ypp0, y1,yp1,ypp1;
        y0=Left.value_with_derivatives(x, &yp0, &ypp0);
        y1=Right.value_with_derivatives(x, &yp1, &ypp1);
        *yp=(yp0*y1-y0*yp1)/(y1*y1); // first deriv of ratio
        *ypp=(y1*y1*ypp0+y0*(2*yp1*yp1-y1*ypp1)-2*y1*yp0*yp1)/(y1*y1*y1); // second deriv of ratio 
        return y0/y1;
    }

    static double combine(const c2_function &left, const c2_function &right, 
                                    double x, double *yp, double *ypp) {
        double y0,yp0,ypp0, y1,yp1,ypp1;
        y0=left.value_with_derivatives(x, &yp0, &ypp0);
        y1=right.value_with_derivatives(x, &yp1, &ypp1);
        *yp=(yp0*y1-y0*yp1)/(y1*y1); // first deriv of ratio
        *ypp=(y1*y1*ypp0+y0*(2*yp1*yp1-y1*ypp1)-2*y1*yp0*yp1)/(y1*y1*y1); // second deriv of ratio 
        return y0/y1;
    }
};

//! factory function operator for adding, returns a new c2_function
inline c2_sum &operator + (const c2_function &lhs, const c2_function &rhs)  { return *new c2_sum(lhs, rhs); }
//! factory function operator for subtracting, returns a new c2_function
inline c2_diff &operator - (const c2_function &lhs, const c2_function &rhs)  { return *new c2_diff(lhs, rhs); }
//! factory function operator for multiplying, returns a new c2_function
inline c2_product &operator * (const c2_function &lhs, const c2_function &rhs)  { return *new c2_product(lhs, rhs); }
//! factory function operator for dividing, returns a new c2_function
inline c2_ratio &operator / (const c2_function &lhs, const c2_function &rhs)  { return *new c2_ratio(lhs, rhs); }

//! a c2_function which is constant : can do interpolating_function f2=f1 + c2_constant(11.3)
class c2_constant : public c2_function {
public:
    c2_constant(double x) : value(x) {}
    void reset(double val) { value=val; }
    virtual double value_with_derivatives(double x, double *yprime, double *yprime2) const 
    { *yprime=0; *yprime2=0; return value; }
    
private:
        double value;
};

/** \class interpolating_function
 This class provides support for cubic spline interpolation of data provides from tables of \a x, \a y pairs.
 It supports automatic, transparent linearization of the data before storing in its tables (through
 subclasses such as 
 lin_lin_interpolating_function, log_lin_interpolating_function, lin_log_interpolating_function, and
 log_log_interpolating_function) to permit very high accuracy representations of data which have a suitable
 structure.  

 In its simplest form, an untransformed cubic spline of a data set, using natural boundary conditions
 (vanishing second derivative), is created as:

 vector<double> xvals(10), yvals(10); <br>
 < fill in xvals and yvals > <br>
 lin_lin_interpolating_function &myfunc=lin_lin_interpolating_function(xvals, yvals); <br>

 and it can be evaluated at a point for its value only by:

 double y=f(x);

 or it can be evaluated with its derivatives by

 double yprime, yprime2; <br>
 double y=f(x,&yprime, &yprime2);

*/

//! A class which allows very clean handling of interpolated tabulated data.
class interpolating_function : public c2_function {
public:
    
    /// Construct the interpolating_function, with auxiliary functions to define linearization
    /// if called with no auxiliary functions, creates a simple cubic spline with no transformation.
    /// \param x a list of ordinates
    /// \param f a list of abscissas
    /// \param lowerSlopeNatural if true, lower second derivative is zero, else lower first derivative is in \a lowerSlope
    /// \param lowerSlope contains the boundary condition at the left edge, if \a lowerSlopeNatural is \a false.
    /// \param upperSlopeNatural if true, upper second derivative is zero, else upper first derivative is in \a upperSlope
    /// \param upperSlope contains the boundary condition at the left edge, if \a upperSlopeNatural is \a false.
    /// \param inputXConversion a function (not a c2_function) which converts \a x into the internal space
    /// \param inputYConversion a function (not a c2_function) which converts \a y into the internal space
    /// \param outputYConversion a function (not a c2_function) which converts \a y out of the internal space
    /// \param inputXConversionPrime the derivative of \a inputXConversion
    /// \param inputYConversionPrime the derivative of \a inputYConversion
    /// \param inputXConversionDPrime the second derivative of \a inputXConversion
    /// \param inputYConversionDPrime the second derivative of \a inputYConversion
    
    //! Construct the interpolating_function.  With <= 6 arguments, a simple untransformed cubic spline
    interpolating_function(const std::vector<double> &x, const std::vector<double> &f, 
                          bool lowerSlopeNatural=true, double lowerSlope=0.0, 
                          bool upperSlopeNatural=true, double upperSlope=0.0,
                          double (*inputXConversion)(double)=0, 
                          double (*inputYConversion)(double)=0, 
                          double (*outputYConversion)(double)=0, 
                          double (*inputXConversionPrime)(double)=0, 
                          double (*inputYConversionPrime)(double)=0, 
                          double (*inputXConversionDPrime)(double)=0, 
                          double (*inputYConversionDPrime)(double)=0 
                          ) { init(x, f, lowerSlopeNatural, lowerSlope, upperSlopeNatural, upperSlope, 
                                   inputXConversion, inputYConversion, outputYConversion,
                                   inputXConversionPrime, inputYConversionPrime, 
                                   inputXConversionDPrime, inputYConversionDPrime 
                                   );
                            }
    
    //! copy another interpolating_function
    interpolating_function(const interpolating_function &rhs) : c2_function(rhs), 
        Xraw(rhs.Xraw), X(rhs.X), F(rhs.F), y2(rhs.y2),
        fXin(rhs.fXin), fYin(rhs.fYin), fYout(rhs.fYout), 
        fXinPrime(rhs.fXinPrime), fYinPrime(rhs.fYinPrime), 
        fXinDPrime(rhs.fXinDPrime), fYinDPrime(rhs.fYinDPrime) ,
        xInverted(rhs.xInverted), lastKLow(-1)
    {    set_sampling_grid_pointer(Xraw); }
    
    virtual ~interpolating_function() { } // just to suppress warnings about no virtual destructor
    
    //! copy the x values into the output of the interpolating_function, creating a gridded identity mapping 
    interpolating_function & y_to_x() const;
    
    //! set the bound for extrapolation to the left
    void set_lower_extrapolation(double);
    //! set the bound for extrapolation to the right
    void set_upper_extrapolation(double);
    
    // these functions correctly combine the interpolating function with another interpolating function 
    // preserving the X bounds and mapping functions of the host (left hand) function.
    
    interpolating_function & unary_operator(const c2_function &source) const;

    interpolating_function & binary_operator(const c2_function &rhs,
                                           double (&combiner)(const c2_function &fn, const c2_function &, double x, double *yp, double *ypp)
                                           ) const;
    
    
    // interpolating_functions override the c2_function operators, since they explicitly re-generate the interpolation table
    // when they are applied.  If this is not desired, these operators are not virtual, so the interpolating_function
    // can be upcast back to a c2_function to produce unprocessed binaries.
    
    //! create a new interpolating_function which is the sum of the left-side and an arbitrary c2_function \a rhs.
    interpolating_function & operator + (const c2_function &rhs) const { return binary_operator(rhs, c2_sum::combine); }
    //! create a new interpolating_function which is the difference of the left-side and an arbitrary c2_function \a rhs.
    interpolating_function & operator - (const c2_function &rhs) const { return binary_operator(rhs, c2_diff::combine); }
    //! create a new interpolating_function which is the product of the left-side and an arbitrary c2_function \a rhs.
    interpolating_function & operator * (const c2_function &rhs) const { return binary_operator(rhs, c2_product::combine); }
    //! create a new interpolating_function which is the ratio of the left-side and an arbitrary c2_function \a rhs.
    interpolating_function & operator / (const c2_function &rhs) const { return binary_operator(rhs, c2_ratio::combine); }
    
    //! inline operator for efficient adding of a constant, returning a new interpolating_function (convenience)
    interpolating_function & operator + (double rhs) const { return (*this)+c2_constant(rhs); }
    //! inline operator for efficient subtracting of a constant, returning a new interpolating_function (convenience)
    interpolating_function & operator - (double rhs) const { return (*this)-c2_constant(rhs); }
    //! inline operator for efficient multiplying by a constant, returning a new interpolating_function (convenience)
    interpolating_function & operator * (double rhs) const { return (*this)*c2_constant(rhs); }
    //! inline operator for efficient dividing by a constant, returning a new interpolating_function (convenience)
    interpolating_function & operator / (double rhs) const { return (*this)/c2_constant(rhs); }
    
    //! simple evaluation of the function with no derivatives
    double operator () (double x) const { return splint(x, 0, 0); }
    
    /// Carry out data conversion and spline interpolation
    /// \param x the position at which the function is to be evaluated
    /// \param [out] yprime if non-null, compute and return first derivative
    /// \param [out] yprime2 if non-null, compute and return second derivative
    
    //! Carry out the actually interpolation from the tables.
    double splint(double x, double *yprime, double *yprime2) const;
    
    virtual double value_with_derivatives(double x, double *yprime, double *yprime2) const
        { return splint(x, yprime, yprime2); }
    
    //! move value & derivatives into our internal coordinates (use splint to go the other way!)
    void localize_derivatives(double xraw, double y, double yp, double ypp, double *y0, double *yp0, double *ypp0) const;
    
protected:
        
    interpolating_function() { } // default constructor is never used, prevent accidents by protecting it.
    
    /// init() does the hard work of setting up the spline tables.  It is responsible for transforming the 
    /// data into the internal space, building the second-derivative table for the spline, and lots of other 
    /// book-keeping. 
    void init(const std::vector<double> &, const std::vector<double> &, 
              bool lowerSlopeNatural, double lowerSlope, 
              bool upperSlopeNatural, double upperSlope,
              double (*inputXConversion)(double)=0, 
              double (*inputXConversionPrime)(double)=0, 
              double (*inputXConversionDPrime)(double)=0, 
              double (*inputYConversion)(double)=0, 
              double (*inputYConversionPrime)(double)=0, 
              double (*inputYConversionDPrime)(double)=0, 
              double (*outputYConversion)(double)=0
              );

    std::vector<double> Xraw, X, F, y2;
    
    double (*fXin)(double), (*fYin)(double), (*fYout)(double);
    double (*fXinPrime)(double), (*fYinPrime)(double);
    double (*fXinDPrime)(double), (*fYinDPrime)(double);
    
    int xInverted, lastKLow;
};

//! stores an interpolating_function with no transform.  This is just a shortcut for the main interpolating_function class
class lin_lin_interpolating_function : public interpolating_function {
public:    
    //! Construct a simple untransformed cubic spline
    lin_lin_interpolating_function(const std::vector<double> x, const std::vector<double> f, 
                                   bool lowerSlopeNatural=true, double lowerSlope=0.0, 
                                   bool upperSlopeNatural=true, double upperSlope=0.0)
    { init(x, f, lowerSlopeNatural, lowerSlope, upperSlopeNatural, upperSlope, 
             0, 0, 0, 0, 0, 0, 0 ); }

protected:
    lin_lin_interpolating_function() {} // do not allow naked construction... it is usually an accident.
};

//! stores an interpolating_function with log(x) as its internal ordinate.  Especially suitable for nearly logarithmic data, or data covering a very wide dynamic range of \a x.
class log_lin_interpolating_function : public interpolating_function {
public:
    log_lin_interpolating_function(const std::vector<double> x, const std::vector<double> f, 
                                bool lowerSlopeNatural=true, double lowerSlope=0.0, 
                                bool upperSlopeNatural=true, double upperSlope=0.0);
protected:
    log_lin_interpolating_function() {} // do not allow naked construction... it is usually an accident.
};

//! stores an interpolating_function with log(y) as its internal abscissa.  Especially suitable for nearly exponential data, or data covering a very wide dynamic range in \a y.
class lin_log_interpolating_function : public interpolating_function {
public:
    lin_log_interpolating_function(const std::vector<double> x, const std::vector<double> f, 
                                bool lowerSlopeNatural=true, double lowerSlope=0.0, 
                                bool upperSlopeNatural=true, double upperSlope=0.0);
protected:
    lin_log_interpolating_function() {} // do not allow naked construction... it is usually an accident.
};

//! stores an interpolating_function with log(x), log(y) as its internal coordinates.  Especially suitable for data with power-law dependence.
class log_log_interpolating_function : public interpolating_function {
public:
    log_log_interpolating_function(const std::vector<double> x, const std::vector<double> f, 
                                bool lowerSlopeNatural=true, double lowerSlope=0.0, 
                                bool upperSlopeNatural=true, double upperSlope=0.0);
protected:
    log_log_interpolating_function() {} // do not allow naked construction... it is usually an accident.
};

/// create a linear-linear interpolating grid with both x & y set to (xmin, xmin+dx, ... xmin + dx*(count -1) ).
/// Very useful for transformaiton with other functions e.g. 
/// f=c2_sin::sin(LinearInterpolatingGrid(-0.1,0.1, 65)) creates a spline table of sin(x) slightly beyond the first period

//! create a uniformly-spaced grid of points in an interpolating_function
inline interpolating_function &linear_interpolating_grid(double xmin, double dx, int count) {
    std::vector<double> x(count);
    for(int i=0; i<count; i++) x[i]=xmin + i * dx;
    return *new interpolating_function(x,x);
}

//! create a log-log interpolating grid with both x & y set to (xmin, xmin*dx, ... xmin * dx**(count -1) )
inline interpolating_function &log_log_interpolating_grid(double xmin, double dx, int count) {
    std::vector<double> x(count);
    x[0]=xmin;
    for(int i=1; i<count; i++) x[i]=dx*x[i-1];
    return *new log_log_interpolating_function::log_log_interpolating_function(x,x);
}

//! this just wraps a c2_function with an operator () which knows specifically about applying itself to interppolating functions
class c2_ifun_operator : public c2_function {
public:
    //! apply the specified function immediately to the interpolating_function, creating new tables
    interpolating_function & apply(const interpolating_function &ifunc) const { return ifunc.unary_operator(*this); }
    //! compose the function with another in a short notation: c2_function &f=g(h)
    c2_composed_function & operator ()(const c2_function &inner) const { return *new c2_composed_function((*this), inner); }
protected:
    c2_ifun_operator() {} // do not allow naked construction... it is usually an accident.
};

// create a bunch of useful subclasses with singleton instances of the functions

//! the sine function, with derivatives and smarts with respect to apllication to interpolating_functions and composition.
class c2_sin : public c2_ifun_operator {
public:
    virtual double value_with_derivatives(double x, double *yprime, double *yprime2) const
    { double q=std::sin(x); *yprime=std::cos(x); *yprime2=-q; return q; }    
    static std::vector<double> &trig_grid(double xmin, double xmax); 
    //! create a special, dynamic sampling grid rather than having a fixed lookup table
    virtual std::vector<double> &get_sampling_grid(double xmin, double xmax) const { return c2_sin::trig_grid(xmin, xmax); }
    static c2_sin sin;
protected:
        c2_sin() {} // do not allow naked construction... it is usually an accident.
};

//! the cosine function, with derivatives and smarts with respect to apllication to interpolating_functions and composition.
class c2_cos : public c2_ifun_operator {
public:
    virtual double value_with_derivatives(double x, double *yprime, double *yprime2) const 
    { double q=std::cos(x); *yprime=-std::cos(x); *yprime2=-q; return q; }    
    virtual std::vector<double> &get_sampling_grid(double xmin, double xmax) const { return c2_sin::trig_grid(xmin, xmax); }
    static c2_cos cos;
protected:
        c2_cos() {} // do not allow naked construction... it is usually an accident.
};

//! the natural log function, with derivatives and smarts with respect to apllication to interpolating_functions and composition.
class c2_log : public c2_ifun_operator {
public:
    virtual double value_with_derivatives(double x, double *yprime, double *yprime2) const
    { *yprime=1.0/x; *yprime2=-1.0/(x*x); return std::log(x); }    
    static c2_log log;
protected:
        c2_log() {} // do not allow naked construction... it is usually an accident.
};

//! the exponential function, with derivatives and smarts with respect to apllication to interpolating_functions and composition.
class c2_exp : public c2_ifun_operator {
public:
    virtual double value_with_derivatives(double x, double *yprime, double *yprime2) const
    { double q=std::exp(x); *yprime=q; *yprime2=q; return q; }
    static c2_exp exp;
protected:
        c2_exp() {} // do not allow naked construction... it is usually an accident.
};

//! the sqrt function, with derivatives and smarts with respect to apllication to interpolating_functions and composition.
class c2_sqrt : public c2_ifun_operator {
public:
    virtual double value_with_derivatives(double x, double *yprime, double *yprime2) const
    { double q=std::sqrt(x); *yprime=0.5/q; *yprime2=-0.25/(x*q); return q; }
    static c2_sqrt sqrt;
protected:
        c2_sqrt() {} // do not allow naked construction... it is usually an accident.
};

//! the reciprocal function, with derivatives and smarts with respect to apllication to interpolating_functions and composition.
class c2_recip : public c2_ifun_operator {
public:
    virtual double value_with_derivatives(double x, double *yprime, double *yprime2) const
    { double q=1/x; *yprime=-(q*q); *yprime2=2*q*q*q; return q; }
    static c2_recip recip;
protected:
        c2_recip() {} // do not allow naked construction... it is usually an accident.
};

//! the identity function, with derivatives and smarts with respect to apllication to interpolating_functions and composition.
class c2_identity : public c2_ifun_operator {
public:
    c2_identity() {} 
    virtual double value_with_derivatives(double x, double *yprime, double *yprime2) const
    { *yprime=1.0; *yprime2=0; return x; }
    static c2_identity identity;
};

// some more useful subclasses, without singletons, since these are parametric families of functions
// a c2_ifun_operator which is a line so interpolating_function f1=c2_Linear(1.2, 2.0)(f) computes f1=1.2+2.0*f

//! a linear function y=y0+slope*x
class c2_linear : public c2_ifun_operator {
public:
    //! create the function with an initial slope and intercetp
    c2_linear(double y0, double slope) : intercept(y0), m(slope) {}
    //! set a new slope and intercept
    void reset(double y0, double slope) { intercept=y0; m=slope; } 
    virtual double value_with_derivatives(double x, double *yprime, double *yprime2) const
    { *yprime=m; *yprime2=0; return m*x+intercept; }
    
private:
        double intercept, m;
protected:
        c2_linear() {} // do not allow naked construction... it is usually an accident.
};

//! a c2_ifun_operator which is a parabola a*(x-x0)^2 + b*(x-x0) + y0. Note that the parameters are overdetermined, but allows the flexibility of two different representations
class c2_quadratic : public c2_ifun_operator {
public:
    //! create the quadratic  y= a*(x-x0)^2 + b*(x-x0) + y0
    c2_quadratic(double x0, double y0, double xcoef, double x2coef) : intercept(y0), center(x0), a(x2coef), b(xcoef) {}
    //! set new values for the parameters
    void reset(double x0, double y0, double xcoef, double x2coef) { intercept=y0; center=x0; a=x2coef; b=xcoef; } 
    virtual double value_with_derivatives(double x, double *yprime, double *yprime2) const
    { double dx=x-center; *yprime=2*a*dx+b; *yprime2=2*a; return a*dx*dx+b*dx+intercept; }
    
private:
        double intercept, center, a, b;
protected:
        c2_quadratic() {} // do not allow naked construction... it is usually an accident.
};

//! a c2_ifun_operator which is a power law y=a*x**b so one can do f1=c2_power_law(3,2.5)(f) to compute f1=3*f**2.5
class c2_power_law : public c2_ifun_operator {
public:
    //! create the power low y=a*x**b
    c2_power_law(double scale, double power) : a(scale), b(power) {}
    //! reset the parameters
    void reset(double scale, double power) { a=scale; b=power; }
    virtual double value_with_derivatives(double x, double *yprime, double *yprime2) const
    { double q=a*std::pow(x,b-2); *yprime=b*q*x; *yprime2=b*(b-1)*q; return q*x*x; }
    
private:
        double a, b;
protected:
        c2_power_law() {} // do not allow naked construction... it is usually an accident.
};

/// \class c2_inverse_function
/// A function which is the functional inverse of another function.  Inversion is done with c2_function::find_root
/// and then followed by exact computation of the appropriate derivatives.  Note that the host function
/// must be monotonic on its domain, so the result is unique.  For functions which are not globally monotonic,
/// their domain should be restricted using c2_function::set_domain to a valid region.

//!The functional inverse of another function
class c2_inverse_function : public c2_scaled_function  // c2_scaled_function to manage ownership issues
{
public:
    /// Construct the inverse function from a given function.  The domain of the inverse is set to
    /// the range of the parent function at the edges of its domain.  If this is not the desired domain,
    /// the domain should be reset with set_domain() afterwards.  Also, the initial guess used for 
    /// finding the inverse is set to the middle of this function's domain.
    /// \param fn the parent function
    /// 
    
    //! create the inverse function from a parent \a fn 
    c2_inverse_function(const c2_function &fn);

    /// Construct the inverse function from a host function and from an approximate inverse, which will
    /// typically be in interpolating_function with a few points scattered along it to hint the search.
    /// \param fn the host c2_function
    /// \param approximate_inverse_fn a c2_funciton which is an approximation to the inverse
    
    //! create the inverse function with a hinting function to make the inversion faster.
    c2_inverse_function(const c2_function &fn, const c2_function &approximate_inverse_fn);

    /// Create an interpolating_function (linear/linear) to hint the inversion process from the specified grid.
    /// Note that if linear interpolation is not appropriate, the function should be built externally, 
    /// and this class should be constructed with it. 
    /// \param xgrid a grid of points which are dense enough to nicely sample the host function. 
    
    //! create an inverse function hinting table from the host function and the specified grid. If the grid has less than 5 points, it will be refined.
    void create_hinting_function(std::vector<double> &xgrid);

    //! create an inverse function hinting table from the host function and the sampling grid it provides automatically. If the grid has less than 5 points, it will be refined.
    void create_hinting_function();
    
    //! provide a hint as to where to look for the inverse.  Automatically set at instantiation to the center of the domain.
    void set_start_hint(double start) { start_hint=start; }
    
    /// Use c2_functions::find_root() to find the solution to invert the function, starting the search
    /// at the value stored by set_start_hint, or at the last place a solution was found.  
    ///
    //! Find the solution for the inverse, and its derivatives.
    virtual double value_with_derivatives(double x, double *yprime, double *yprime2) const;
	
    //! mark our hint_func as being owned by this, so it gets deleted on the way out
    void set_hint_ownership() { owns_hint=true; }
    
    virtual ~c2_inverse_function() { if(owns_hint && hint_func) delete hint_func; }
    
private:
    double start_hint;
    const c2_function *hint_func;
    bool owns_hint;
};

//An interpolating_function which is the cumulative integral of the (histogram) specified by binedges and binheights.
//Note than binedges should be one element longer than binheights, since the lower & upper edges are specified. 
//Note that this is a malformed spline, since the second derivatives are all zero, so it has less continuity.
//Also, note that the bin edges can be given in backwards order to generate the 
// reversed accumulation (starting at the high end) 

class accumulated_histogram : public interpolating_function {
public:
    accumulated_histogram(const std::vector<double>binedges, const std::vector<double> binheights,
                         bool normalize=false, bool inverse_function=false, bool drop_zeros=true);
    
};

///InverseIntegratedDensity<interpolating_functionFlavor> starts with a probability density c2_function, generates the integral, 
/// and generates an interpolating_function which, when evaluated using a uniform random on [0,1] returns values
/// with a density distribution equal to the input distribution
/// If the data are passed in reverse order (large X first), the integral is carried out from the big end
/// \param binedges a list of the edges of the bins to be used to sample \a binheights
/// \param binheights a c2_function which is the probability distribution for which a random generator is needed.

//! Create an inverse integral suitable for random number generation from bins and heights
template <typename Final>
Final &inverse_integrated_density(const std::vector<double>binedges, c2_function &binheights)
{    
    std::vector<double> integral;
    
    // integrate from first to last bin in original order, leaving results in integral
    // ask for relative error of 1e-6 on each bin, with absolute error set to 0 (since we don't know the data scale).
    double sum=binheights.partial_integrals(binedges, &integral, 0.0, 1e-6); 
    // the integral vector now has partial integrals... it must be accumulated by summing
    integral.insert(integral.begin(), 0.0); // integral from start to start is 0
    double scale=1.0/sum;
    for(size_t i=1; i<integral.size(); i++) integral[i]=integral[i]*scale + integral[i-1];
    integral.back()=1.0; // force exact value on boundary
    
    return  *new Final(integral, binedges, 
                       false, 1.0/(scale*binheights(binedges.front() )), 
                       false, 1.0/(scale*binheights(binedges.back() ))
                       ); // use integral as x axis in inverse function
}

/// This variant of InverseIntegratedDensity starts with a data table and constructs an intermediate interpolating_function
/// of type class::IntermediateInterpolator then does the integral.
template <typename Intermediate, typename Final> Final &inverse_integrated_density(const std::vector<double>binedges, const std::vector<double> binheights) 
{    
    std::vector<double> be(binedges), bh(binheights);
    
    if(be[1] < be[0]) { // reverse data for interpolator if x axis passed in backwards
        std::reverse(be.begin(), be.end());
        std::reverse(bh.begin(), bh.end());
    }
    
    Intermediate *temp=new Intermediate(be, bh); // create a temporary interpolating_function to integrate
    Final &result=inverse_integrated_density<Final>(binedges, *temp);
    delete temp;
    
    return result;
}


#endif 
