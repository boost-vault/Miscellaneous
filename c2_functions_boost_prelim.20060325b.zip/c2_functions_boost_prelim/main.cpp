#include <iostream>
#include <iomanip>
#include <vector>
#include <cmath>
#include <algorithm>

#include "c2_functions.h"

int main (int argc, char * const argv[]) {
	
#if 0
	// generate a set of values to use as a test. x and sin(x) in [0,6]...
    std::vector<double> x;
    std::vector<double> s;
    for(int i = 0; i <= 50; ++i) {
		x.push_back((double)(i/10.0+0.25));
		s.push_back(std::pow(x[i],-2.5));
    }
	// create the interpolating function
	//interpolating_function f(x,s, false, -2.5*std::pow(x[0],-3.5), false, -2.5*std::pow(x[x.size()-1],-3.5));
	//LogLoginterpolating_function f(x,s, false, -2.5*std::pow(x[0],-3.5), false, -2.5*std::pow(x[x.size()-1],-3.5) );
	//LogLoginterpolating_function f(x,s);
#endif
	
#if 0
	// sample this very curved function on a modest linear grid, where the errors will be significant at low x
	interpolating_function &f=c2_power_law(1.0, -2.5).apply(linear_interpolating_grid(0.1, 0.05,100));
#elif 1
	// sample this very curved function on a modest square-law grid, where the errors will be significant at low x
	interpolating_function &f=c2_power_law(1.0, -2.5).apply(c2_power_law(0.75,2.0).apply(linear_interpolating_grid(0.1, 0.025,100)).YtoX());
#else
	// sample this very curved function on a coarse log-log grid, but power laws are exact on log-log so the results are exact
	interpolating_function &f=c2_power_law(1.0, -2.5).apply(log_log_interpolating_grid(0.1, 2, 6));
	f.set_lower_extrapolation(0.0001);
	f.set_upper_extrapolation(10);
#endif
	
	interpolating_function &fsq=f*f;
	
	c2_function &f2=c2_sqrt::sqrt(fsq);
	interpolating_function &f3a=f/fsq;
	
	// casting the interpolating_function causes the final sum to be c2_function::operator + so the sum is evaluated dynamically
	// this allows the high-precision of the log-log interpolation for a power law to be preserved, while creating a sum function
	// c2_function &f3=(static_cast<c2_function &>(f3a*f3a))+c2_consttant(1.0); 
	// this example is broken with respect to temporary alocation semantics... cannot nest temporary c2_functions
	
	// can also do this in this case by making the c2_consttant the left element, so it controls the semantics
	c2_constant C2one(1);
	interpolating_function &f33=f3a*f3a;
	c2_function &f3=C2one+f33; 
	
	// print the limits
    std::cout << "\nxmin = " << f.xmin() << "  xmax = " << f.xmax() << "\n\n";
	// read in test values and print the results
    for(int i = 0; i < 10; ++i) {
		double z;
		std::cout << "Enter an x value: ";
		std::cin >> z;
		double fzp, fzpp;
		try {
			double fz=f.splint(z, &fzp, &fzpp);
			std::cout << "z = " << z <<  "  z^(-2.5) = " << std::pow(z, -2.5) << "  f(z) = " << fz <<  "  f'(z) = " << fzp << "  f''(z) = " << fzpp << std::endl;
			
			double f2z=f2(z, &fzp, &fzpp);
			std::cout << "z = " << z <<  "  sqrt( (z^(-2.5)) ^2 ) = " << std::pow(z, -2.5) << "  f(z) = " << f2z <<  "  f'(z) = " << fzp << "  f''(z) = " << fzpp << std::endl;
			
			
			double f3z=f3(z, &fzp, &fzpp);
			std::cout << "z = " << z <<  "  z^5 + 1 = " << std::pow(z, 5)+1 << "  f(z) = " << f3z <<  "  f'(z) = " << fzp << "  f''(z) = " << fzpp << std::endl;
			
			double xroot=f3.find_root(f3.xmin(), f3.xmax(), 0.5*(f3.xmin()+f3.xmax()), f3z); // call with default error flag to allow exceptions
			std::cout << "root finder: " << xroot << " " <<  xroot-z << " " << f3(xroot)-f3z << std::endl;
			
		} 
		catch (c2_exception exc) {
			std::cerr << "caught error "  << exc << " trying again." << std::endl;
		} 
		catch (...) {
			std::cerr << "caught unknown error "  << std::endl;
		};
		
		// do these constructions statically, so if this were in a fast loop, the objects would not
		// have to be allocated repeatedly, just to change a function on the inside.
		static c2_qauadratic xsq(0., 0., 0., 1.);
		static c2_variable_function vf;
		static c2_function &fresn=c2_sin::sin(vf);

		fresn.reset_evaluations(); // reset evaluation counter to monitor adaptive integration
		
		// do fresnel integral sin(x^2), and test static declarations with run-time variable function
		vf.set_function(xsq); // initialize the plug-in function to the actual function to be used.
		
		int np=int(std::abs(z)*2) + 2;
		std::vector<double> frx(np);
		for(int j=0; j<np; j++) frx[j]=z*double(j)/(np-1);
		try {
			// note: the tolerances for the adaptive integral are dangerously small (intentionally).  
			// It will throw an exception for some values of its arguments.  
			// Normally, the defaults of 1e-12, 1e-12 are pretty good.  The relative tolerance should probably not be < 1e-14 ordinarily.
			std::cout << "Fresnel Sine Integral = " << std::setprecision(15) << 
				fresn.partial_integrals(frx) << " " << fresn.get_evaluations() << " " << 
				fresn.partial_integrals(frx, 0, 1e-17, 1e-15) << " " << 
				fresn.get_evaluations() << std::setprecision(8) << std::endl;
		} catch (c2_exception exc) {
			std::cerr << "caught error "  << exc << " trying again." << std::endl;
		} 

		if(i==0) { // only do this test on first pass
			vf.unset_function();
			try {
				z=vf(0.0);
			} catch (c2_exception exc) {
				std::cerr << "caught expected error: "  << exc << std::endl;
				continue;
			} 
			std::cerr << "failed to catch expected error on uninitialized C2VariableFunction"  << std::endl;
		}
	}
	return 0;
}
